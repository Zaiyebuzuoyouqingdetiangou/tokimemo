import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './helpers/r847Host.mjs';
import * as patch from '../src/core/cgImagePatch.js';
import * as album from '../src/modes/album.js';
import * as advEvent from '../src/modes/advEvent.js';
import * as heart from '../src/modes/heart.js';
import * as appearance from '../src/generation/cgAppearance.js';
import * as constants from '../src/core/constants.js';
import * as context from '../src/core/context.js';
import * as client from '../src/generation/client.js';
import * as cache from '../src/core/cache.js';
import * as library from '../src/archive/library.js';
import * as overlay from '../src/ui/overlay.js';
import { state } from '../src/core/state.js';

const img = (name, extra = {}) => ({ url: `/user/images/${name}.png`, prompt: '画面', provider: 'baibai-image', generatedAt: 1, ...extra });

function albumSession(image = null, history = undefined) {
    const item = { id: 'CG01', title: '庭院', desc: '画面', unlocked: true, comments: [] };
    if (image) item.cgImage = image;
    if (history !== undefined) item.cgImageHistory = history;
    return { kind: 'album', chatId: 'chat-a', archiveRevision: 'rev-1', entries: [item] };
}

function patchFor(session, image) {
    const item = session.entries[0];
    return { version: 1, mode: 'album', itemId: 'CG01', expectedSignature: patch.cgItemSignature(item), image };
}

test('legacy metadata rejects duplicated roles instead of silently dropping them (P1-7)', () => {
    const row = { role: 'char', name: '沙', tag: '银发' };
    assert.throws(() => appearance.normalizeCgPromptMetadata({ sceneTags: '', characters: [row, { ...row, tag: '黑发' }] }),
        error => error?.code === 'RMT_CG_PROMPT_INVALID');
    const single = appearance.normalizeCgPromptMetadata({ sceneTags: '', characters: [row] });
    assert.equal(single.characters.length, 1);
    assert.equal(single.characters[0].tag, '银发');
    const none = appearance.normalizeCgPromptMetadata({ sceneTags: '', characters: [] });
    assert.equal(none, null);
    const mixed = appearance.normalizeCgPromptMetadata({ sceneTags: '', characters: [row, { role: 'user', name: '玩家', tag: '斗篷' }] });
    assert.equal(mixed.characters.length, 2);
});

test('cgImageHistory normalization dedupes, bounds and rejects non-gallery references', () => {
    assert.deepEqual(patch.normalizeCgImageHistory(null), []);
    assert.deepEqual(patch.normalizeCgImageHistory('junk'), []);
    const rows = [img('a'), img('a'), img('b'), { url: 'data:image/png;base64,AAAA' }, { url: 'https://evil.example/x.png' },
        { url: '/user/images/../escape.png' }, img('c', { url: '/user/images/c.png%2f..png' })];
    const history = patch.normalizeCgImageHistory(rows);
    assert.deepEqual(history.map(record => record.url), ['/user/images/a.png', '/user/images/b.png']);
    const many = Array.from({ length: 9 }, (_, index) => img(`v${index}`));
    const bounded = patch.normalizeCgImageHistory(many);
    assert.equal(bounded.length, constants.CG_IMAGE_HISTORY_LIMIT);
    assert.equal(bounded[0].url, `/user/images/v${9 - constants.CG_IMAGE_HISTORY_LIMIT}.png`);
    assert.equal(bounded.at(-1).url, '/user/images/v8.png');
});

test('cgImageHistoryWith appends once and never evicts below the limit', () => {
    let history = null;
    for (const name of ['a', 'b', 'a', 'c']) history = patch.cgImageHistoryWith(history, img(name));
    assert.deepEqual(history.map(record => record.url), ['/user/images/a.png', '/user/images/b.png', '/user/images/c.png']);
    for (const name of ['d', 'e', 'f', 'g']) history = patch.cgImageHistoryWith(history, img(name));
    assert.deepEqual(history.map(record => record.url), ['/user/images/c.png', '/user/images/d.png', '/user/images/e.png', '/user/images/f.png', '/user/images/g.png']);
});

test('applying a redraw patch moves the replaced image into bounded history', () => {
    const session = albumSession(img('old'));
    const first = patch.applyCgImagePatch(session, patchFor(session, img('new')));
    assert.equal(first.status, 'applied');
    const item = first.session.entries[0];
    assert.equal(item.cgImage.url, '/user/images/new.png');
    assert.deepEqual(patch.normalizeCgImageHistory(item.cgImageHistory).map(record => record.url), ['/user/images/old.png']);
    // Applying the same durable patch again is an idempotent no-op for history.
    const again = patch.applyCgImagePatch(first.session, patchFor(session, img('new')));
    assert.equal(again.status, 'already-applied');
    assert.deepEqual(patch.normalizeCgImageHistory(again.session.entries[0].cgImageHistory).map(record => record.url), ['/user/images/old.png']);
    // A second redraw keeps both versions, newest last.
    const second = patch.applyCgImagePatch(first.session, patchFor(first.session, img('newer')));
    assert.deepEqual(patch.normalizeCgImageHistory(second.session.entries[0].cgImageHistory).map(record => record.url),
        ['/user/images/old.png', '/user/images/new.png']);
});

test('swapCgImageToVersion swaps pointers only and supports exact rollback', () => {
    const item = { id: 'CG01', title: 't', cgImage: img('current'), cgImageHistory: [img('v1'), img('v2')] };
    const before = patch.swapCgImageToVersion(item, '/user/images/v1.png');
    assert.ok(before);
    assert.equal(item.cgImage.url, '/user/images/v1.png');
    assert.deepEqual(patch.normalizeCgImageHistory(item.cgImageHistory).map(record => record.url),
        ['/user/images/v2.png', '/user/images/current.png']);
    assert.equal(patch.swapCgImageToVersion(item, '/user/images/missing.png'), null);
    assert.equal(item.cgImage.url, '/user/images/v1.png');
    // Restoring the current image's own url is not offered (it is not in history).
    assert.equal(patch.swapCgImageToVersion(item, '/user/images/v1.png'), null);
    assert.equal(patch.swapCgImageToVersion(null, '/user/images/v1.png'), null);
    // A hostile url can never match.
    assert.equal(patch.swapCgImageToVersion(item, 'javascript:alert(1)'), null);
    // Rollback restores the exact previous fields.
    item.cgImage = before.image;
    item.cgImageHistory = before.history;
    assert.equal(item.cgImage.url, '/user/images/current.png');
    assert.deepEqual(patch.normalizeCgImageHistory(item.cgImageHistory).map(record => record.url),
        ['/user/images/v1.png', '/user/images/v2.png']);
});

test('cgImageHistory survives text regeneration projection and reopening (cache whitelist)', async t => {
    const f = await fixture(t);
    const origin = context.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision);
    const handle = await client.beginModeRecovery('album', f.ctx, f.liveBank, origin, { existing: null });
    const draftId = handle.journal.draftId;
    const session = { kind: 'album', chatId: f.liveBank.chatId, archiveRevision: f.liveBank.archiveRevision,
        title: '部分相簿', selectedId: 'CG01', page: 1, pageSize: 6, category: '全部',
        entries: [{ id: 'CG01', title: 'CG01', desc: '原画面', unlocked: true, comments: ['原对白'] }],
        readableProgress: { version: 1, draftId, pageId: 'album', complete: false } };
    await cache.saveGenerationTaskResult(f.ctx, 'album', session, origin, { draftId, sourceMemory: f.liveBank, memoryBank: f.liveBank, complete: false });
    await library.openGenerationTaskResult(draftId, f.ctx);
    await overlay.saveActiveSessionEdit(draft => {
        draft.entries[0].cgImage = img('live');
        draft.entries[0].cgImageHistory = [img('v1'), img('v2')];
        return draft;
    }, { select: draft => draft.entries[0] });
    const incoming = structuredClone(session);
    incoming.entries[0].comments.push('后来生成的第二句');
    await cache.saveGenerationTaskResult(f.ctx, 'album', incoming, origin, {
        draftId, sourceMemory: f.liveBank, memoryBank: f.liveBank, complete: false });
    await library.openGenerationTaskResult(draftId, f.ctx);
    assert.equal(state.activeSession.entries[0].cgImage.url, '/user/images/live.png');
    assert.deepEqual(patch.normalizeCgImageHistory(state.activeSession.entries[0].cgImageHistory).map(record => record.url),
        ['/user/images/v1.png', '/user/images/v2.png']);
    state.runtimeSessionCache.clear();
    await cache.ensureCacheHydrated(f.ctx);
    const final = structuredClone(state.activeSession);
    delete final.readableProgress;
    assert.equal(await cache.commitSession('album', final, f.liveBank.chatId, origin), true);
    state.runtimeSessionCache.clear();
    await cache.ensureCacheHydrated(f.ctx);
    const raw = (await f.persisted()).album;
    assert.equal(raw.entries[0].cgImage.url, '/user/images/live.png');
    assert.deepEqual(patch.normalizeCgImageHistory(raw.entries[0].cgImageHistory).map(record => record.url),
        ['/user/images/v1.png', '/user/images/v2.png']);
    assert.equal(f.requests.length, 0);
});

test('cgImageHistory limit literal stays at five versions', () => {
    assert.equal(constants.CG_IMAGE_HISTORY_LIMIT, 5);
});

const histBank = { characterName: '沙盒卡标题', userName: '玩家', archiveName: '庭院相遇', archiveSummary: '', memories: [
    { id: 'M001', title: '一起栽花。', summary: '两人一同在庭院栽花。', anchors: ['庭院'], participants: [] },
    { id: 'M002', title: '门口相遇。', summary: '两人在门口相遇。', anchors: ['门口'], participants: [] },
] };
const histEntry = { id: 'CG01', title: '庭院', date: '待定', desc: '两人站在庭院', unlocked: true,
    sourceMemoryIds: ['M001'], sourceMemoryAnchor: '庭院', visualSeed: ['树', '花', '手', '门'], imagePrompt: '庭院',
    comments: ['第一句。', '第二句。', '第三句。', '第四句。'] };

test('album restore re-normalization keeps cgImageHistory', () => {
    const full = album.normalizeAlbum({ entries: [{ ...histEntry,
        cgImage: img('live'), cgImageHistory: [img('v1'), { url: 'data:image/png;base64,AA' }, img('v2')] }] }, histBank);
    assert.equal(full.entries[0].cgImage.url, '/user/images/live.png');
    assert.deepEqual(patch.normalizeCgImageHistory(full.entries[0].cgImageHistory).map(record => record.url),
        ['/user/images/v1.png', '/user/images/v2.png']);
});

test('album locked-to-unlocked merge prefers the old entry history', () => {
    const filler = { ...histEntry, id: 'CG02', title: '门口', sourceMemoryIds: ['M002'], sourceMemoryAnchor: '门口',
        comments: ['一。', '二。', '三。', '四。'] };
    const oldAlbum = album.normalizeAlbum({ entries: [{ ...histEntry, unlocked: false, hintLines: ['继续聊天可解锁。'],
        cgImage: img('old-live'), cgImageHistory: [img('old-v1')] }, filler] }, histBank);
    const fresh = album.normalizeAlbumIndex({ entries: [{ ...histEntry, cgImageHistory: [img('model-v9')] }] }, histBank);
    const merged = album.mergeAlbumIncremental(oldAlbum, fresh);
    const row = merged.entries.find(item => item.id === 'CG01');
    assert.equal(row.cgImage.url, '/user/images/old-live.png');
    assert.deepEqual(patch.normalizeCgImageHistory(row.cgImageHistory).map(record => record.url),
        ['/user/images/old-v1.png']);
});

test('ADV derivation from album keeps cgImageHistory', () => {
    const derived = advEvent.deriveAdvFromAlbum({ entries: [{ ...histEntry,
        cgImage: img('adv-live'), cgImageHistory: [img('adv-v1')] }] });
    assert.deepEqual(patch.normalizeCgImageHistory(derived.events[0].cgImageHistory).map(record => record.url),
        ['/user/images/adv-v1.png']);
});

test('heart strip normalization keeps cgImageHistory', () => {
    const strips = heart.normalizeHeartStripsPart({ dailyStrips: [{ id: 'S1', title: '一格', subtitle: '短句',
        panelCount: 1, panels: [{ caption: '字', action: '动作。' }], visualSeed: ['树', '花', '手'],
        imagePrompt: '庭院', cgImage: img('h-live'), cgImageHistory: [img('h-v1')] }] });
    assert.deepEqual(patch.normalizeCgImageHistory(strips[0].cgImageHistory).map(record => record.url), ['/user/images/h-v1.png']);
    const batch = heart.normalizeHeartCollectionBatch({ dailyStrips: [{ id: 'S2', title: '一格', subtitle: '短句',
        panelCount: 1, panels: [{ caption: '字', action: '动作。' }], visualSeed: ['树', '花', '手'],
        imagePrompt: '庭院', cgImage: img('h2-live'), cgImageHistory: [img('h2-v1')] }] }, 'strips');
    const row = batch.dailyStrips ? batch.dailyStrips[0] : batch.items?.[0] ?? batch[0];
    assert.deepEqual(patch.normalizeCgImageHistory(row.cgImageHistory).map(record => record.url), ['/user/images/h2-v1.png']);
});
