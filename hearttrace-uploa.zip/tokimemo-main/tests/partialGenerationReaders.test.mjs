// Pure received-data projection plus the actual cache reader/strict final validators.
import test from 'node:test';
import assert from 'node:assert/strict';
import { parsePartialJsonObject } from '../src/generation/jsonParser.js';
import * as progressRecovery from '../src/generation/recovery.js';
import { projectGenerationProgress } from '../src/generation/partialProgress.js';
import * as cache from '../src/core/cache.js';
import * as items from '../src/modes/items.js';
import * as cabinet from '../src/modes/cabinet.js';
import * as inbox from '../src/modes/inbox.js';
import * as song from '../src/modes/themeSong.js';
import * as songContract from '../src/core/themeSongContract.js';
import * as timeStories from '../src/modes/timeStories.js';
import * as timeView from '../src/ui/timeStoriesView.js';
import * as travel from '../src/modes/travel.js';
import * as calendar from '../src/modes/calendar.js';
import * as relations from '../src/modes/relations.js';
import * as achievements from '../src/modes/achievements.js';
import { location as postcardLocation } from './helpers/r8416DesignFixtures.mjs';
import { fixture as hostFixture } from './helpers/r847Host.mjs';
import * as client from '../src/generation/client.js';
import * as contextApi from '../src/core/context.js';
import * as constants from '../src/core/constants.js';
import * as inboxView from '../src/ui/inboxView.js';
import * as songView from '../src/ui/themeSongView.js';
import { state } from '../src/core/state.js';

test('partial parser exposes only closed array items and never completes the truncated tail', () => {
    const parsed = parsePartialJsonObject('{"entries":[{"id":"A","text":"first"},{"id":"B","text":"second"},{"id":"C","text":"unfinished');
    assert.deepEqual(parsed.items('/entries'), [{ id: 'A', text: 'first' }, { id: 'B', text: 'second' }]);
    assert.equal(parsed.complete, false);
    assert.equal(parsed.has('/entries'), false);
    assert.equal(parsed.has('/entries/1'), true);
    assert.equal(parsed.has('/entries/2'), false);
    assert.equal(parsed.has('/entries/2/text'), false);
    assert.deepEqual(parsed.at('/entries/2'), { id: 'C' });
});

test('partial parser retains a parent shell so nested completed nodes keep their original positions', () => {
    const parsed = parsePartialJsonObject('{"spaces":[{"id":"room-a","label":"study","objects":[{"id":"one"},{"id":"two"},{"id":"unfinished');
    assert.deepEqual(parsed.value, { spaces: [] });
    assert.equal(parsed.partialValue.spaces[0].label, 'study');
    assert.equal(parsed.at('/spaces/0').id, 'room-a');
    assert.deepEqual(parsed.items('/spaces/0/objects'), [{ id: 'one' }, { id: 'two' }]);
    assert.equal(parsed.has('/spaces/0/id'), true);
    assert.equal(parsed.has('/spaces/0'), false);
    assert.deepEqual(parsed.items('/spaces'), []);
});

test('partial parser returns complete JSON exactly with escaped strings and pointer keys', () => {
    const value = { 'a/b': { '~key': [{ text: 'quote " slash \\ braces } ] comma ,\nnext' }] }, truth: true, zero: 0, nothing: null };
    const parsed = parsePartialJsonObject(JSON.stringify(value));
    assert.deepEqual(parsed.value, value);
    assert.deepEqual(parsed.partialValue, value);
    assert.equal(parsed.complete, true);
    assert.equal(parsed.has(''), true);
    assert.equal(parsed.has('/a~1b/~0key/0/text'), true);
    assert.deepEqual(parsed.items('/a~1b/~0key'), value['a/b']['~key']);
});

test('partial parser omits unfinished scalars rather than inventing a string literal number or null', () => {
    for (const tail of ['"unfinished', 'tru', 'nul', '-', '12', '12e', '12.']) {
        const parsed = parsePartialJsonObject('{"done":"yes","tail":' + tail);
        assert.deepEqual(parsed.value, { done: 'yes' }, tail);
        assert.equal(parsed.has('/tail'), false, tail);
        assert.equal(parsed.at('/tail'), undefined, tail);
    }
    const delimited = parsePartialJsonObject('{"number":12, "next":');
    assert.equal(delimited.has('/number'), true);
    assert.equal(delimited.at('/number'), 12);
});

test('partial parser invalidates an overwritten key even if the new value is incomplete', () => {
    const parsed = parsePartialJsonObject('{"row":{"text":"old"},"row":{"id":"new","text":"unfinished');
    assert.deepEqual(parsed.value, { row: { id: 'new' } });
    assert.deepEqual(parsed.partialValue, { row: { id: 'new' } });
    assert.equal(parsed.has('/row/text'), false);
    assert.equal(parsed.at('/row/text'), undefined);
    assert.equal(parsed.at('/row/id'), 'new');
});

test('partial parser does not reinterpret prototype property names as executable object behavior', () => {
    const parsed = parsePartialJsonObject('{"__proto__":{"polluted":"no"},"constructor":"literal"}');
    assert.equal(Object.getPrototypeOf(parsed.partialValue), Object.prototype);
    assert.equal(Object.hasOwn(parsed.partialValue, '__proto__'), true);
    assert.deepEqual(parsed.at('/__proto__'), { polluted: 'no' });
    assert.equal({}.polluted, undefined);
});

test('partial parser accepts fenced prefixes while malformed separators never close a parent', () => {
    const parsed = parsePartialJsonObject('```json\n{"items":[{"id":"first"},],"fake":"later"}');
    assert.deepEqual(parsed.items('/items'), [{ id: 'first' }]);
    assert.equal(parsed.has('/items'), false);
    assert.equal(parsed.has('/fake'), false);
    assert.equal(parsed.complete, false);
});

test('partial parser views are independent clones and cannot change later reads', () => {
    const parsed = parsePartialJsonObject('{"rows":[{"id":"kept"},{"id":"tail","text":"unfinished');
    parsed.items('/rows')[0].id = 'mutated';
    parsed.at('/rows/0').id = 'mutated';
    parsed.partialValue.rows[0].id = 'mutated';
    assert.deepEqual(parsed.items('/rows'), [{ id: 'kept' }]);
    assert.equal(parsed.at('/rows/0/id'), 'kept');
});

function progressOrigin() {
    return { characterKey: 'synthetic-character', characterId: '0', characterAvatar: 'synthetic.png',
        chatId: 'synthetic-chat', archiveRevision: 'source-revision', archiveTargetEntryId: 'synthetic-entry' };
}

test('progress publication acknowledges durable JSON first and repeated replay publishes once without a second request', async t => {
    const origin = progressOrigin(), order = []; let durable, requests = 0, notices = 0;
    const handle = await progressRecovery.createGenerationRecovery({ origin, mode: 'inbox', settingsIdentity: 'synthetic',
        save: journal => { durable = structuredClone(journal); order.push('save'); return true; },
        onProgress: async journal => {
            order.push('publish'); notices++;
            assert.deepEqual(journal, durable);
            assert.equal(journal.segments[0].state, 'complete');
        } });
    progressRecovery.attachGenerationRecovery(origin, handle);
    t.after(() => progressRecovery.detachGenerationRecovery(origin));
    const options = { origin, taskKey: 'synthetic:one', contextEnvelope: 'original' };
    const validator = raw => { assert.deepEqual(raw, { letters: [{ text: 'received' }] }); return raw; };
    const run = async (_prompt, _options, accepted) => { requests++; const raw = { letters: [{ text: 'received' }] }; await accepted(raw); return raw; };
    await progressRecovery.withRecoverySegment('original', options, validator, run);
    await progressRecovery.withRecoverySegment('original', options, validator, run);
    await progressRecovery.publishGenerationRecoveryProgress(handle);
    assert.equal(requests, 1);
    assert.equal(notices, 1);
    assert.deepEqual(order, ['save', 'publish']);
});

test('readable projection storage failure retains a paid complete segment and retry replays without provider use', async t => {
    const origin = progressOrigin(); let saved, requests = 0, failPublish = true, publications = 0;
    const handle = await progressRecovery.createGenerationRecovery({ origin, mode: 'inbox', settingsIdentity: 'synthetic',
        save: journal => { saved = structuredClone(journal); return true; },
        onProgress: () => { publications++; if (failPublish) throw new Error('synthetic view storage failure'); } });
    progressRecovery.attachGenerationRecovery(origin, handle);
    t.after(() => progressRecovery.detachGenerationRecovery(origin));
    const options = { origin, taskKey: 'synthetic:one' }, validator = raw => raw;
    const run = async (_prompt, _options, accepted) => { requests++; await accepted({ title: 'paid' }); return { title: 'paid' }; };
    await assert.rejects(progressRecovery.withRecoverySegment('original', options, validator, run), { code: 'RMT_RECOVERY_PROGRESS_STORAGE' });
    assert.equal(saved.segments[0].state, 'complete');
    assert.equal(saved.segments[0].rawJson, '{"title":"paid"}');
    failPublish = false;
    assert.deepEqual(await progressRecovery.withRecoverySegment('original', options, validator, run), { title: 'paid' });
    assert.equal(requests, 1);
    assert.equal(publications, 2);
});

test('a failed durable journal write never publishes a readable result and preserves the received in-page complete data', async t => {
    const origin = progressOrigin(); let notices = 0, requests = 0;
    const handle = await progressRecovery.createGenerationRecovery({ origin, mode: 'inbox', settingsIdentity: 'synthetic',
        save: () => false, onProgress: () => { notices++; } });
    progressRecovery.attachGenerationRecovery(origin, handle);
    t.after(() => progressRecovery.detachGenerationRecovery(origin));
    await assert.rejects(progressRecovery.withRecoverySegment('original', { origin, taskKey: 'synthetic:one' }, raw => raw,
        async (_prompt, _options, accepted) => { requests++; await accepted({ title: 'paid' }); }), { code: 'RMT_RECOVERY_STORAGE' });
    assert.equal(requests, 1);
    assert.equal(notices, 0);
    assert.equal(progressRecovery.generationRecoverySnapshot(handle).segments[0].state, 'complete');
});

test('truncated publication preserves exact raw bytes and disables implicit retries', async t => {
    const origin = progressOrigin(), raw = '{"entries":[{"text":"already received"},{"text":" unfinished  ';
    let saved, published;
    const handle = await progressRecovery.createGenerationRecovery({ origin, mode: 'inbox', settingsIdentity: 'synthetic',
        save: journal => { saved = structuredClone(journal); return true; },
        onProgress: journal => { published = structuredClone(journal); } });
    progressRecovery.attachGenerationRecovery(origin, handle);
    t.after(() => progressRecovery.detachGenerationRecovery(origin));
    let error;
    await assert.rejects(progressRecovery.withRecoverySegment('original', { origin, taskKey: 'synthetic:one' }, value => value,
        async (_prompt, options) => {
            error = Object.assign(new Error('cut off'), { code: 'RMT_JSON_TRUNCATED', retryable: true, retryableJson: true });
            await progressRecovery.recordRecoveryTruncation(options, raw, error);
            throw error;
        }), { code: 'RMT_JSON_TRUNCATED' });
    assert.equal(saved.segments[0].partial, raw);
    assert.equal(published.segments[0].partial, raw);
    assert.equal(error.retryable, false);
    assert.equal(error.retryableJson, false);
    assert.deepEqual(parsePartialJsonObject(published.segments[0].partial).items('/entries'), [{ text: 'already received' }]);
});

test('simultaneous received segments serialize readable publications and never regress the published content', async t => {
    const origin = progressOrigin(); let active = 0, maximum = 0; const sizes = [];
    const handle = await progressRecovery.createGenerationRecovery({ origin, mode: 'inbox', settingsIdentity: 'synthetic',
        save: () => true,
        onProgress: async journal => { active++; maximum = Math.max(maximum, active); await Promise.resolve(); sizes.push(journal.segments.length); active--; } });
    progressRecovery.attachGenerationRecovery(origin, handle);
    t.after(() => progressRecovery.detachGenerationRecovery(origin));
    const run = async (_prompt, options, accepted) => { await accepted({ title: options.taskKey }); };
    await Promise.all(['one', 'two'].map(slot => progressRecovery.withRecoverySegment('original', { origin, taskKey: slot }, raw => raw, run)));
    assert.equal(maximum, 1);
    assert.equal(sizes.at(-1), 2);
    assert.ok(sizes.every((size, index) => !index || size >= sizes[index - 1]));
    assert.equal(progressRecovery.generationRecoverySnapshot(handle).segments.filter(row => row.state === 'complete').length, 2);
});

// Synthetic source fixtures: each evidence-based assertion uses this frozen bank,
// never a current chat, a selected live worldbook, or a freshly sampled wall clock.
const sourceTime = Date.parse('2008-05-18T10:00:00.000Z');
const sourceBank = () => ({ chatId: 'partial-source-chat', archiveRevision: 'partial-source-rev',
    characterName: '林舟', userName: '小月', memories: [
        { id: 'M001', date: '2008/05/18', title: '初见与信封', summary: '林舟把信封交给小月。', anchors: ['信封'], participants: ['林舟', '小月'] },
        { id: 'M002', date: '2008/05/19', title: '保留票根', summary: '林舟与小月保存了票根。', anchors: ['票根'], participants: ['林舟', '小月'] },
        { id: 'M003', date: '2008/05/20', title: '书房交谈', summary: '林舟与阿青、白泽、迟雨在书房交谈。', anchors: ['书房'], participants: ['林舟', '阿青', '白泽', '迟雨'] },
        { id: 'M004', date: '2008/05/17', title: '收起日记', summary: '林舟收起日记。', anchors: ['日记'], participants: ['林舟'] },
    ] });
const sourceContext = bank => ({ characterId: 0, name1: bank.userName, name2: bank.characterName,
    chatId: bank.chatId, characters: [{ name: bank.characterName, avatar: 'partial-source.png' }],
    getCurrentChatId() { return this.chatId; }, powerUserSettings: { persona_description: '原任务的人设' } });
const reference = (id, anchor) => ({ sourceMemoryIds: [id], sourceMemoryAnchor: anchor });
const arrayPrefix = (key, rows, tail = '{"id":"UNFINISHED_TAIL","text":"DO_NOT_INVENT') =>
    '{"' + key + '":[' + rows.map(row => JSON.stringify(row)).join(',') + ',' + tail;

async function project(mode, raw, { bank = sourceBank(), previousSession = null, operation = {}, frozenInputs = {}, contract = undefined } = {}) {
    const context = sourceContext(bank);
    const journal = { identity: { mode }, draftId: 'partial-test-' + mode, pageId: mode, createdAt: sourceTime,
        operation, frozenInputs: Object.fromEntries(Object.entries(frozenInputs).map(([key, value]) => [key, JSON.stringify(value)])),
        contentSnapshotVersion: 1, contentSnapshot: { version: 1, fields: { characterId: context.characterId,
            name1: context.name1, name2: context.name2, characters: context.characters, powerUserSettings: context.powerUserSettings },
            memoryBank: bank, contentInputs: { previousSession } },
        segments: [{ slot: 'fixture:' + mode, state: 'truncated', partial: raw, ...(contract ? { contract } : {}) }] };
    // context is explicitly provided because the journal normally contains only
    // the serializable fields; a source-owned view supplies host helpers at runtime.
    const session = await projectGenerationProgress(journal, { context, memoryBank: bank, previousSession });
    return { session, bank, context, journal };
}

function readable(mode, projected) {
    const { session, bank, context } = projected;
    assert.ok(session, `${mode} should expose its accepted received fields`);
    const stored = { chatId: bank.chatId, archiveRevision: bank.archiveRevision, [mode]: session };
    const result = cache.loadSession(mode, { context, memoryBank: bank, cache: stored, includePartial: true, clone: true });
    assert.ok(result, `${mode} actual cache reader must accept the marked partial session`);
    assert.equal(cache.loadSession(mode, { context, memoryBank: bank, cache: stored }), null,
        `${mode} default generation read must not consume a partial session`);
    assert.equal(result.readableProgress.complete, false);
    assert.equal(result.archiveRevision, 'partial-source-rev');
    assert.doesNotMatch(JSON.stringify(result), /UNFINISHED_TAIL|DO_NOT_INVENT/);
    return result;
}

const itemNode = (id, label) => ({ id, label, kind: 'item', basis: '推演', summary: label + '静静放在架上。', line: '请慢慢看看' + label + '。', children: [] });
test('items parser to projector to reader retains two closed nodes in an unclosed box', async () => {
    const rows = [itemNode('I1', '铅笔'), itemNode('I2', '书签')];
    const raw = '{"containers":[{"id":"B1","label":"书桌抽屉","description":"放文具的抽屉。","nodes":['
        + rows.map(JSON.stringify).join(',') + ',{"id":"UNFINISHED_TAIL","label":"DO_NOT_INVENT';
    const shown = readable('items', await project('items', raw));
    assert.deepEqual(shown.containers[0].nodes.map(row => row.label), ['铅笔', '书签']);
    assert.equal(items.normalizeItems(shown, sourceBank()).containers[0].nodes.length, 2);
});

test('items keeps closed nested children while their container node and box are both unfinished', async () => {
    const parent = { id: 'NEST', kind: 'container', basis: '推演', label: '笔盒', summary: '收纳文具的小盒子。', line: '里面还有几样文具。' };
    const raw = '{"containers":[{"id":"B1","label":"抽屉","description":"普通抽屉。","nodes":['
        + JSON.stringify(parent).slice(0, -1) + ',"children":['
        + [itemNode('I1', '铅笔'), itemNode('I2', '橡皮')].map(JSON.stringify).join(',')
        + ',{"id":"UNFINISHED_TAIL","label":"DO_NOT_INVENT';
    const shown = readable('items', await project('items', raw));
    assert.equal(shown.containers[0].nodes[0].label, '笔盒');
    assert.deepEqual(shown.containers[0].nodes[0].children.map(row => row.label), ['铅笔', '橡皮']);
});

test('cabinet shows two evidenced objects and rejects unrelated current-source evidence', async () => {
    const rows = [
        { name: '信封', objectEvidence: '林舟把信封交给小月。', ...reference('M001', '信封') },
        { name: '票根', objectEvidence: '林舟与小月保存了票根。', ...reference('M002', '票根') },
        { name: '戒指', objectEvidence: '林舟把戒指送给小月。', ...reference('M999', '戒指') },
    ];
    const projected = await project('cabinet', arrayPrefix('items', rows));
    const shown = readable('cabinet', projected);
    assert.deepEqual(shown.items.map(item => item.name), ['信封', '票根']);
    assert.match(cabinet.cabinetHtml(shown), /林舟把信封交给小月/);
    assert.doesNotMatch(cabinet.cabinetHtml(shown), /戒指|DO_NOT_INVENT/);
    assert.deepEqual(cabinet.normalizeCabinet(shown, projected.bank).items, shown.items);
});

test('inbox shows two closed planned letters and keeps the original local date and source IDs', async () => {
    const letter = (slot, title) => ({ slot, title, greeting: '小月：', body: '此刻窗边的风很安静，我想把这一点轻松的心情写给你，愿你今天也能慢慢歇一会。', closing: '林舟' });
    const operation = { inboxDate: '2008-05-18T10:00:00.000Z' };
    const projected = await project('inbox', arrayPrefix('letters', [letter('stage', '信封后的问候'), letter('daily', '窗边的短笺')]), { operation });
    const shown = readable('inbox', projected);
    assert.deepEqual(shown.letters.map(item => item.type), ['stage', 'daily']);
    assert.ok(shown.letters.every(item => item.createdAt === sourceTime));
    assert.deepEqual(shown.letters[0].sourceMemoryIds, ['M001']);
    assert.deepEqual(shown.letters[1].sourceMemoryIds, []);
    const replay = await project('inbox', projected.journal.segments[0].partial, { operation });
    assert.deepEqual(replay.session.letters, shown.letters);
    assert.deepEqual(inbox.mergeInboxLatest(shown, replay.session).letters, shown.letters);
});

const fixedSongPlan = (id = 'SONG_partial_1') => ({ id, subject: 'event', eventId: 'M001', language: 'zh', voice: 'char', direction: '', createdAt: sourceTime });
test('theme song exposes closed title and descriptions without fabricating unclosed lyrics', async () => {
    const raw = '{"title":"信封上的风","vocalDescription":"轻声独唱","styleDescription":"木吉他与安静的节奏","stylePrompt":"soft acoustic folk","lyrics":"DO_NOT_INVENT';
    const projected = await project('themeSong', raw, { operation: { themeSongPlan: fixedSongPlan() } });
    const shown = readable('themeSong', projected);
    assert.equal(shown.songs[0].title, '信封上的风');
    assert.equal(shown.songs[0].vocalDescription, '轻声独唱');
    assert.equal(shown.songs[0].lyrics, '');
    assert.deepEqual(shown.songs[0].sourceMemoryIds, ['M001']);
    assert.equal(shown.songs[0].createdAt, sourceTime);
    assert.ok(song.readableThemeSongProgressSession(shown, projected.bank));
    assert.throws(() => songContract.normalizeStoredThemeSongs(shown, projected.bank), 'partial reading must not weaken final lyrics validation');
});

test('theme song missing invalid or foreign-source plans return null without interrupting request recovery', async () => {
    const raw = '{"title":"已经收到的标题","lyrics":"unfinished';
    for (const plan of [undefined, {}, { ...fixedSongPlan(), eventId: 'M999' }]) {
        const result = await project('themeSong', raw, { operation: plan ? { themeSongPlan: plan } : {} });
        assert.equal(result.session, null);
    }
});

const timePrefix = () => JSON.stringify({ title: '雨中的回声', opening: '林舟听见了从旧匣传来的风声。',
    medium: { kind: 'object', label: '旧木匣' }, ends: [{ role: 'char', time: '今夜' }, { role: 'user', time: '明夜' }] }).slice(0, -1)
    + ',"lines":[{"speaker":"a","text":"你听见窗外的风了吗？"},{"speaker":"b","text":"我听见了，先把那封信收好。"},{"speaker":"a","text":"DO_NOT_INVENT';
test('time story preserves two closed dialogue lines and unfinished closing stays explicitly incomplete', async () => {
    const projected = await project('timeEcho', timePrefix(), { frozenInputs: { 'presentation:timeEcho': { profile: { technology: 'low', worldStyle: 'historical' } } } });
    const shown = readable('timeEcho', projected);
    assert.deepEqual(shown.episodes[0].lines.map(line => line.speaker), ['a', 'b']);
    assert.equal(shown.episodes[0].closing, '');
    assert.deepEqual(shown.episodes[0].medium, { kind: 'object', label: '旧木匣' });
    assert.equal(timeStories.readableTimeStoriesSession(shown, projected.bank), null);
    assert.ok(timeStories.readableTimeStoriesProgressSession(shown, projected.bank));
    assert.match(timeView.timeStoriesHtml({ ...shown, reading: true, dialogueIndex: 1 }), /我听见了，先把那封信收好/);
});

test('partial time story reader validates medium shape and source ownership', async () => {
    const projected = await project('timeEcho', timePrefix());
    for (const medium of [{ kind: 'javascript', label: 'fake' }, { kind: 'object', label: {} }, { kind: 'object', label: '' }]) {
        const forged = structuredClone(projected.session); forged.episodes[0].medium = medium;
        assert.equal(timeStories.readableTimeStoriesProgressSession(forged, projected.bank), null);
    }
    const noMedium = structuredClone(projected.session); noMedium.episodes[0].medium = null;
    assert.ok(timeStories.readableTimeStoriesProgressSession(noMedium, projected.bank));
    assert.equal(timeStories.readableTimeStoriesProgressSession(projected.session, { ...projected.bank, archiveRevision: 'new-source' }), null);
});

test('travel exposes two closed stops and uses the saved structured-design contract', async () => {
    const rows = [postcardLocation('pavilion', 'F1'), postcardLocation('lake', 'F2')];
    const projected = await project('travel', arrayPrefix('locations', rows), {
        contract: 'travel-sketch-design-r8418', frozenInputs: { 'presentation:travel': { profile: { mapTheme: 'neutral', allowedKeepsakes: ['postcard'] } } },
    });
    const shown = readable('travel', projected);
    assert.deepEqual(shown.locations.map(row => row.id), ['F1', 'F2']);
    assert.equal(shown.locations[0].keepsake.picturePlan, null);
    assert.ok(shown.locations[0].keepsake.design);
    assert.ok(shown.locations.every(row => row.basis === '推演' && row.sourceMemoryIds.length === 0));
    assert.equal(travel.normalizeTravel(shown, projected.bank, { allowPartial: true, structuredDesign: true }).locations.length, 2);
});

test('calendar partial refresh retains old entries and synchronizes their original date page membership', async () => {
    const bank = sourceBank();
    const old = calendar.normalizeCalendar({ past: [{ id: 'OLD', title: '收起日记', ...reference('M004', '日记') }] }, bank);
    old.dayPages['date:2008/05/17'].drafts = [{ id: 'MY_DRAFT', text: '旧日手写内容', updatedAt: sourceTime }];
    const before = JSON.stringify(old);
    const rows = [{ id: 'P1', title: '初见与信封', ...reference('M001', '信封') }, { id: 'P2', title: '保留票根', ...reference('M002', '票根') }];
    const shown = readable('calendar', await project('calendar', arrayPrefix('past', rows), {
        bank, previousSession: old, operation: { calendarDate: '2008/05/20', calendarTimeBasis: 'story' },
    }));
    assert.equal(JSON.stringify(old), before, 'projection never edits any content or ordering of the stored old calendar');
    assert.deepEqual(shown.entries.map(row => row.id).sort(), ['OLD', 'P1', 'P2']);
    for (const entry of shown.entries) assert.ok(shown.dayPages['date:' + entry.date].entryIds.includes(entry.id));
    assert.ok(shown.dayPages['date:2008/05/17'].drafts.some(row => row.text === '旧日手写内容'));
    assert.equal(shown.generatedAt, sourceTime);
    assert.equal(shown.storyDate, '2008/05/17', 'story reference follows the frozen archive order, not device time');
});

const npc = (name, id) => ({ id, name, relation: '书房的熟人', summary: name + '在书房参与交谈。',
    npcPerspective: '我正听林舟谈这本书。', isUser: false, ...reference('M003', '书房') });
test('relations retains two valid NPCs when a separate closed NPC lacks perspective and the final row is cut off', async () => {
    const invalid = npc('迟雨', 'BAD'); delete invalid.npcPerspective;
    const raw = arrayPrefix('relationships', [npc('阿青', 'R1'), invalid, npc('白泽', 'R2')]);
    const projected = await project('relations', raw);
    const shown = readable('relations', projected);
    assert.deepEqual(shown.relationships.map(row => row.name), ['阿青', '白泽']);
    assert.deepEqual(shown.relationships.map(row => row.sourceMemoryIds), [['M003'], ['M003']]);
    assert.equal(relations.normalizeRelations(shown, projected.bank, projected.context).relationships.length, 2);
    assert.match(relations.relationGardenHtml({ characterName: '林舟', dynamicRelations: shown.relationships }), /阿青/);
    assert.throws(() => relations.normalizeRelations({ relationships: [invalid] }, projected.bank, projected.context), /npcPerspective/,
        'the original complete-response contract stays strict');
});

test('relations setting people use only the saved selected worldbook evidence', async () => {
    const rows = [{ name: '青禾', sourceWorld: '原人物书', sourceUid: '1', sourceEvidence: '青禾负责书房的日常整理。', npcPerspective: '我在整理书本。' },
        { name: '新人物', sourceWorld: '后来另选的书', sourceUid: '9', sourceEvidence: '新人物负责庭院的日常整理。' }];
    const projected = await project('relations', arrayPrefix('settingRelationships', rows), { frozenInputs: {
        'relations:setting-books': { entries: [{ world: '原人物书', uid: 1, content: '青禾负责书房的日常整理。', historySource: false }] },
    } });
    const shown = readable('relations', projected);
    assert.deepEqual(shown.settingRelationships.map(row => row.name), ['青禾']);
});

test('achievements exposes two closed valid achievements and does not unlock an unevidenced one', async () => {
    const rows = [{ id: 'A1', title: '信封留下的记号', description: '信封被妥善保存。', unlocked: true, ...reference('M001', '信封') },
        { id: 'A2', title: '票根的记号', description: '票根被妥善保存。', unlocked: true, ...reference('M002', '票根') },
        { id: 'FAKE', title: '不存在的礼物', description: '未有证据的戒指。', unlocked: true, ...reference('M999', '戒指') }];
    const projected = await project('achievements', arrayPrefix('entries', rows));
    const shown = readable('achievements', projected);
    assert.deepEqual(shown.entries.map(row => row.id), ['A1', 'A2']);
    assert.equal(achievements.normalizeAchievements(shown, projected.bank).entries.length, 2);
});

async function generateRealPartial(f, mode, raw, options = {}) {
    const service = f.ctx.ConnectionManagerRequestService, send = service.sendRequest;
    service.sendRequest = async function(profileId, messages, length, requestOptions, overridePayload) {
        const profile = f.ctx.extensionSettings.connectionManager.profiles.find(row => row.id === profileId);
        const payload = { secret_id: profile['secret-id'], model: profile.model, ...overridePayload };
        assert.ok(payload.secret_id);
        f.requests.push(structuredClone(messages));
        return { content: raw, finish_reason: 'length' };
    };
    try { await client.generateMode(mode, { background: true, ...options }); }
    finally { service.sendRequest = send; }
    const draft = cache.loadGenerationRecovery(mode, f.ctx);
    assert.ok(draft, JSON.stringify(f.notices));
    assert.equal(draft.segments[0].state, 'truncated');
    const saved = await cache.readGenerationTaskResult(f.ctx, draft.draftId);
    assert.equal(saved.status, 'open');
    await f.open(mode);
    assert.equal(state.activeSession.readableProgress.draftId, draft.draftId);
    return draft;
}

test('real partial inbox read and favorite actions survive hydration without touching the formal mailbox', async t => {
    const f = await hostFixture(t), before = await f.persisted();
    const letter = { slot: 'daily', title: '窗边的短笺', greeting: '小月：',
        body: '此刻窗边的风很安静，我想把这一点轻松的心情写给你，愿你今天也能慢慢歇一会。', closing: '林舟' };
    const draft = await generateRealPartial(f, 'inbox', arrayPrefix('letters', [letter]));
    const id = state.activeSession.letters[0].id;
    await inboxView.handleInboxAction('read', id);
    await inboxView.handleInboxAction('favorite', id);
    const result = await cache.readGenerationTaskResult(f.ctx, draft.draftId);
    assert.ok(result.session.letters[0].readAt > 0);
    assert.equal(result.session.letters[0].favorite, true);
    assert.deepEqual((await f.persisted()).inbox, before.inbox);
    state.runtimeSessionCache.clear(); state.activeSession = null; state.activeMode = null;
    await cache.ensureCacheHydrated(f.ctx); await f.open('inbox');
    assert.equal(state.activeSession.letters[0].favorite, true);
    assert.equal(state.activeSession.letters[0].readAt, result.session.letters[0].readAt);
    assert.equal(f.requests.length, 1);
});

test('real partial time-story connect and next-line actions preserve their reading position after reload', async t => {
    const f = await hostFixture(t);
    const draft = await generateRealPartial(f, 'timeEcho', timePrefix());
    assert.equal(await timeView.handleTimeStoryAction('connect'), true);
    assert.equal(await timeView.handleTimeStoryAction('next-line'), true);
    const result = await cache.readGenerationTaskResult(f.ctx, draft.draftId);
    assert.equal(result.session.reading, true);
    assert.equal(result.session.dialogueIndex, 1);
    assert.equal((await f.persisted()).timeEcho, undefined);
    state.runtimeSessionCache.clear(); state.activeSession = null; state.activeMode = null;
    await cache.ensureCacheHydrated(f.ctx); await f.open('timeEcho');
    assert.equal(state.activeSession.dialogueIndex, 1);
    assert.equal(state.activeSession.reading, true);
    assert.match(f.body.innerHTML, /我听见了，先把那封信收好/);
    assert.equal(f.requests.length, 1);
});

test('real partial song copies received text and deletion stays deleted when the original task later completes', async t => {
    const f = await hostFixture(t);
    const draft = await generateRealPartial(f, 'themeSong', '{"title":"留在风里的歌","vocalDescription":"轻声独唱","lyrics":"DO_NOT_INVENT',
        { songOptions: { subject: 'character', language: 'zh', voice: 'char' } });
    const id = state.activeSession.songs[0].id;
    const navDescriptor = Object.getOwnPropertyDescriptor(globalThis, 'navigator'), copies = [];
    Object.defineProperty(globalThis, 'navigator', { configurable: true, value: { clipboard: { writeText: async value => { copies.push(value); } } } });
    t.after(() => navDescriptor ? Object.defineProperty(globalThis, 'navigator', navDescriptor) : delete globalThis.navigator);
    await songView.handleThemeSongAction('copy-title', id);
    assert.deepEqual(copies, ['留在风里的歌']);
    assert.equal(await songView.deleteThemeSong(id), true);
    assert.equal((await cache.readGenerationTaskResult(f.ctx, draft.draftId)).session.songs.length, 0);
    assert.equal((await f.persisted()).themeSong, undefined);
    state.runtimeSessionCache.clear(); state.activeSession = null; state.activeMode = null;
    await cache.ensureCacheHydrated(f.ctx); await f.open('themeSong');
    assert.equal(state.activeSession.songs.length, 0);
    f.setResponse({ title: '留在风里的歌', vocalDescription: '轻声独唱', styleDescription: '安静的木吉他伴奏', stylePrompt: 'soft acoustic folk',
        lyrics: '[Verse]\n风穿过窗边\n[Chorus]\n把声音留在此刻\n[End]' });
    await client.continueSavedGeneration('themeSong', { draftId: draft.draftId });
    assert.equal(f.requests.length, 2, 'copy/delete/reload add zero provider requests; only the explicit continuation sends');
    assert.equal((await f.persisted()).themeSong.songs.length, 0, 'completion cannot resurrect the deliberately deleted song');
});

test('applied old-source inbox song and time-story stay readable under current names while foreign target chats still reject', async t => {
    const f = await hostFixture(t), bank = f.liveBank;
    const oldBank = { ...structuredClone(bank), archiveRevision: 'old-source-revision', characterName: '旧名字', userName: '旧用户' };
    const oldContext = { ...f.ctx, name1: oldBank.userName, name2: oldBank.characterName };
    const provenance = { sourceMemory: oldBank, sourceIdentity: { chatId: oldBank.chatId, archiveRevision: oldBank.archiveRevision } };
    const wrap = (mode, session) => ({ ...session, chatId: bank.chatId, archiveRevision: bank.archiveRevision,
        generationSources: { [mode]: provenance }, ownerKey: 'old-name-owner-key' });
    const mail = inbox.emptyInbox(oldBank, oldContext);
    state.activeMode = 'inbox'; state.activeSession = wrap('inbox', mail);
    assert.doesNotThrow(() => inboxView.assertShownInboxTarget());

    const songset = songContract.emptyThemeSongs(oldBank, 'old-name-owner-key');
    state.activeMode = 'themeSong'; state.activeSession = wrap('themeSong', songset);
    assert.doesNotThrow(() => songView.assertThemeSongReader());
    const story = timeStories.emptyTimeStories('timeEcho', oldBank, oldContext);
    state.activeMode = 'timeEcho'; state.activeSession = wrap('timeEcho', story);
    assert.equal(timeView.handleTimeStoryAction('library'), true);
    for (const [mode, session, verify] of [['inbox', mail, () => inboxView.assertShownInboxTarget()],
        ['themeSong', songset, () => songView.assertThemeSongReader()]]) {
        state.activeMode = mode; state.activeSession = { ...wrap(mode, session), chatId: 'foreign-chat' };
        assert.throws(verify);
    }
    state.activeMode = 'timeEcho'; state.activeSession = { ...wrap('timeEcho', story), chatId: 'foreign-chat' };
    assert.equal(timeView.handleTimeStoryAction('library'), false);
    assert.equal(f.requests.length, 0);
});

async function editableProgressFixture(f, mode, pageId, fields) {
    const bank = structuredClone(f.liveBank), origin = contextApi.captureTaskOrigin(f.ctx, bank.archiveRevision);
    await client.beginModeRecovery(mode, f.ctx, bank, origin, { existing: null, pageId });
    const draftId = origin.generationRecoveryDraftId;
    const session = { kind: mode, chatId: bank.chatId, archiveRevision: bank.archiveRevision, ...structuredClone(fields),
        readableProgress: { version: 1, complete: false, draftId, pageId } };
    await cache.saveGenerationTaskResult(f.ctx, mode, session, origin, { complete: false, memoryBank: bank, sourceMemory: bank });
    return { bank, origin, draftId, session };
}

test('partial target resolution follows the shown HEART page instead of the last merged draft marker', async t => {
    const f = await hostFixture(t);
    const spring = await editableProgressFixture(f, 'heart', 'spring', { voiceDramas: [{ id: 'SAME', kind: 'spring', title: '春篇' }] });
    const summer = await editableProgressFixture(f, 'heart', 'summer', { voiceDramas: [{ id: 'SAME', kind: 'summer', title: '夏篇' }] });
    t.after(() => { progressRecovery.detachGenerationRecovery(spring.origin); progressRecovery.detachGenerationRecovery(summer.origin); });
    const shown = cache.loadReadableGenerationProgress('heart', { context: f.ctx, memoryBank: spring.bank });
    assert.equal(shown.readableProgress.draftId, summer.draftId);
    const selected = await cache.resolveGenerationProgressTarget(f.ctx, shown, value => value.voiceDramas?.find(item => item.kind === 'spring'));
    assert.equal(selected.draftId, spring.draftId); assert.equal(selected.pageId, 'spring');
    assert.equal(selected.contentSnapshot.memoryBank.archiveRevision, spring.bank.archiveRevision);
    const stale = structuredClone(shown); stale.voiceDramas.find(item => item.kind === 'spring').title = '界面上的过期文字';
    assert.equal(await cache.resolveGenerationProgressTarget(f.ctx, stale, value => value.voiceDramas?.find(item => item.kind === 'spring')), null);
    assert.equal(f.requests.length, 0);
});

test('a just-completed matching partial target resolves to formal content without accepting a stale same ID', async t => {
    const f = await hostFixture(t), item = { id: 'ONE', title: '完整原条目', desc: '正文' };
    const draft = await editableProgressFixture(f, 'album', 'album', { entries: [item] });
    t.after(() => progressRecovery.detachGenerationRecovery(draft.origin));
    const final = structuredClone(draft.session); delete final.readableProgress;
    assert.equal(await cache.commitSession('album', final, draft.bank.chatId, draft.origin), true);
    const selected = await cache.resolveGenerationProgressTarget(f.ctx, draft.session, value => value.entries?.find(row => row.id === 'ONE'));
    assert.equal(selected.status, 'formal'); assert.equal(selected.draftId, '');
    const stale = structuredClone(draft.session); stale.entries[0].desc = '别的正文';
    assert.equal(await cache.resolveGenerationProgressTarget(f.ctx, stale, value => value.entries?.find(row => row.id === 'ONE')), null);
});

for (const status of ['open', 'formal']) test(`partial target resolution ignores object key insertion order for ${status} content while preserving content and identity checks`, async t => {
    const f = await hostFixture(t);
    const item = { id: 'ONE', title: '完整原条目', desc: '正文',
        details: { camera: { angle: 'from above', distance: 'close-up' }, actions: ['站立', '回头'] } };
    const draft = await editableProgressFixture(f, 'album', 'album', { entries: [item] });
    t.after(() => progressRecovery.detachGenerationRecovery(draft.origin));
    if (status === 'formal') {
        const final = structuredClone(draft.session); delete final.readableProgress;
        assert.equal(await cache.commitSession('album', final, draft.bank.chatId, draft.origin), true);
    }
    const shown = structuredClone(draft.session);
    shown.entries[0] = { details: { actions: ['站立', '回头'], camera: { distance: 'close-up', angle: 'from above' } },
        desc: '正文', title: '完整原条目', id: 'ONE' };
    const select = session => session.entries?.find(row => row.id === 'ONE');
    const selected = await cache.resolveGenerationProgressTarget(f.ctx, shown, select);
    assert.ok(selected, 'the identical displayed item must resolve regardless of nested object key order');
    assert.equal(selected.status, status);
    assert.equal(selected.draftId, status === 'open' ? draft.draftId : '');
    assert.deepEqual(selected.session.entries[0], item);
    const conflicts = [
        session => { session.entries[0].details.camera.angle = 'from below'; },
        session => { session.entries[0].details.actions.reverse(); },
        session => { delete session.entries[0].details.camera.distance; },
        session => { session.entries[0].details.camera.extra = '未显示的新增字段'; },
        session => { session.chatId = 'foreign-chat'; },
        session => { session.archiveRevision = 'foreign-revision'; },
    ];
    for (const change of conflicts) {
        const stale = structuredClone(shown); change(stale);
        assert.equal(await cache.resolveGenerationProgressTarget(f.ctx, stale, select), null,
            'ignoring property order cannot ignore changed values, array order, missing/extra data or source identity');
    }
    assert.equal(f.requests.length, 0, 'resolving a displayed target never generates');
});

test('trusted partial text overrides survive reordered projections final completion and reload while later CG stays local', async t => {
    const f = await hostFixture(t);
    const draft = await editableProgressFixture(f, 'phone', 'phone', { apps: [
        { id: 'A', entries: [{ id: 'SAME', title: 'A 原文', cgImage: { url: '/old.png' } }] },
        { id: 'B', entries: [{ id: 'SAME', title: 'B 原文' }] },
    ] });
    t.after(() => progressRecovery.detachGenerationRecovery(draft.origin));
    const contentOverride = { pageId: 'phone', target: { type: 'phone-entry', id: 'SAME', parentId: 'B' },
        path: ['apps', { id: 'B' }, 'entries', { id: 'SAME' }], set: { title: '用户确认的新文', cgImage: null }, unset: [] };
    await cache.commitGenerationTaskResultMutation(f.ctx, draft.draftId, session => {
        Object.assign(session.apps[1].entries[0], contentOverride.set); session.userManaged = true; return session;
    }, { expectedTaskOrigin: draft.origin, contentOverride });
    const image = { url: '/after-user-redraw.png' };
    await cache.commitGenerationTaskResultMutation(f.ctx, draft.draftId, session => {
        session.apps[1].entries[0].cgImage = image; return session;
    }, { expectedTaskOrigin: draft.origin });
    const later = structuredClone(draft.session);
    later.apps.reverse(); later.apps[0].entries[0].title = '原任务迟到的旧文';
    later.apps[0].entries.push({ id: 'LATER', title: '后续完整新条目' });
    await cache.saveGenerationTaskResult(f.ctx, 'phone', later, draft.origin, { complete: false, memoryBank: draft.bank, sourceMemory: draft.bank });
    state.runtimeSessionCache.clear(); await cache.ensureCacheHydrated(f.ctx);
    const partial = (await cache.readGenerationTaskResult(f.ctx, draft.draftId)).session;
    assert.equal(partial.apps[0].entries[0].title, '用户确认的新文');
    assert.deepEqual(partial.apps[0].entries[0].cgImage, image);
    assert.equal(partial.apps[1].entries[0].title, 'A 原文');
    assert.equal(partial.userManaged, true);
    delete later.readableProgress;
    assert.equal(await cache.commitSession('phone', later, draft.bank.chatId, draft.origin), true);
    state.runtimeSessionCache.clear(); await cache.ensureCacheHydrated(f.ctx);
    const final = (await f.persisted()).phone;
    assert.equal(final.apps[0].entries[0].title, '用户确认的新文');
    assert.deepEqual(final.apps[0].entries[0].cgImage, image);
    assert.deepEqual(final.apps[0].entries.map(item => item.id), ['SAME', 'LATER']);
    assert.equal(final.userManaged, true); assert.equal(f.requests.length, 0);
});

for (const mode of ['adv', 'room']) test(`explicit partial ${mode} field clearing survives reprojection final completion and reload`, async t => {
    const f = await hostFixture(t);
    const fields = mode === 'adv' ? { events: [{ id: 'E1', title: '事件保留', adv: { text: '主动删除的正文' } }] }
        : { spaces: [{ id: 'ROOM', label: '房间保留' }], lifePlan: { beats: [{ time: '10:00', activity: '主动删除的生活' }] } };
    const draft = await editableProgressFixture(f, mode, mode, fields);
    t.after(() => progressRecovery.detachGenerationRecovery(draft.origin));
    await cache.commitGenerationTaskResultMutation(f.ctx, draft.draftId, session => {
        if (mode === 'adv') session.events[0].adv = null; else delete session.lifePlan;
        session.userManaged = true; return session;
    }, { expectedTaskOrigin: draft.origin });
    await cache.saveGenerationTaskResult(f.ctx, mode, structuredClone(draft.session), draft.origin,
        { complete: false, memoryBank: draft.bank, sourceMemory: draft.bank });
    const partial = (await cache.readGenerationTaskResult(f.ctx, draft.draftId)).session;
    if (mode === 'adv') assert.equal(partial.events[0].adv, null); else assert.equal(Object.hasOwn(partial, 'lifePlan'), false);
    const final = structuredClone(draft.session); delete final.readableProgress;
    assert.equal(await cache.commitSession(mode, final, draft.bank.chatId, draft.origin), true);
    state.runtimeSessionCache.clear(); await cache.ensureCacheHydrated(f.ctx);
    const saved = (await f.persisted())[mode];
    if (mode === 'adv') assert.equal(saved.events[0].adv, null); else assert.equal(Object.hasOwn(saved, 'lifePlan'), false);
    assert.equal(saved.userManaged, true); assert.equal(f.requests.length, 0);
});

test('explicit same-value text override remains authoritative when the original task later changes that field', async t => {
    const f = await hostFixture(t);
    const draft = await editableProgressFixture(f, 'album', 'album', { entries: [{ id: 'P', title: '同值确认', desc: '旧正文' }] });
    t.after(() => progressRecovery.detachGenerationRecovery(draft.origin));
    await cache.commitGenerationTaskResultMutation(f.ctx, draft.draftId, session => session, { expectedTaskOrigin: draft.origin,
        contentOverride: { pageId: 'album', target: { type: 'album-entry', id: 'P', parentId: '' }, path: ['entries', { id: 'P' }], set: { title: '同值确认' }, unset: [] } });
    const later = structuredClone(draft.session); later.entries[0].title = '迟到的新字';
    await cache.saveGenerationTaskResult(f.ctx, 'album', later, draft.origin, { complete: false, memoryBank: draft.bank, sourceMemory: draft.bank });
    assert.equal((await cache.readGenerationTaskResult(f.ctx, draft.draftId)).session.entries[0].title, '同值确认');
});

test('travel partial remains durable when a newer host mirror still contains the earlier journal without its result', async t => {
    const f = await hostFixture(t);
    const journal = await generateRealPartial(f, 'travel',
        '{"locations":[' + JSON.stringify(postcardLocation('pavilion', 'F1')) + ',{"id":"TAIL","text":"unfinished');
    assert.equal(f.requests.length, 1);
    assert.equal(journal.segments[0].state, 'truncated');
    assert.ok((await f.persisted())[cache.GENERATION_DRAFTS_CACHE_KEY].records[journal.draftId].result,
        'the real initial generation must durably publish its received travel location');
    const before = await cache.readGenerationTaskResult(f.ctx, journal.draftId);
    assert.equal(before.session.locations[0].name, '山间');
    const stale = structuredClone(await f.persisted());
    delete stale[cache.GENERATION_DRAFTS_CACHE_KEY].records[journal.draftId].result;
    stale.commitToken = Number(stale.commitToken || 0) + 100000;
    stale.updatedAt = Number(stale.updatedAt || 0) + 100;
    f.ctx.chatMetadata[constants.CACHE_KEY] = stale;
    state.runtimeSessionCache.clear();
    await cache.ensureCurrentArchiveBackup(f.ctx);
    state.runtimeSessionCache.clear(); await cache.ensureCacheHydrated(f.ctx);
    assert.ok((await f.persisted())[cache.GENERATION_DRAFTS_CACHE_KEY].records[journal.draftId].result,
        'a newer stale host mirror must not erase the canonical readable result');
    const after = await cache.readGenerationTaskResult(f.ctx, journal.draftId);
    assert.deepEqual(after.session, before.session);
    assert.equal(cache.loadSession('travel', { context: f.ctx }), null, 'reading recovery does not produce a completed map');
    await f.open('travel');
    assert.match(f.body.innerHTML, /山间/);
    assert.equal(f.requests.length, 1, 'mirror repair and reopening send no new request');
    assert.equal((await f.persisted())[cache.GENERATION_DRAFTS_CACHE_KEY].records[journal.draftId].journal.segments[0].partial, journal.segments[0].partial);
});
