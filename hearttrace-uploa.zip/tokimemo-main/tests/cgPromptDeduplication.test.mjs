import test from 'node:test';
import assert from 'node:assert/strict';
import * as appearance from '../src/generation/cgAppearance.js';
import * as images from '../src/generation/imageGeneration.js';
import * as provider from '../src/generation/baibaiImage.js';
import * as imagePatch from '../src/core/cgImagePatch.js';

// These expected strings are fixture constants, not output from a production
// formatter/preview helper. API fields are asserted separately: repeated words
// authored by the user and appearances belonging to two people must survive.
const VISUAL = '甲站在左侧扶花苗，乙坐在右侧浇水。镜头从下方拍摄，用户手写：慢慢，慢慢。';
const TAG_SCENE = '2people, courtyard, left holding seedling, right watering, (from below:1.4), slowly, slowly';
const TAG_FLAT = '1boy, left, (black hair:1.25), blue eyes, holding seedling, 1girl, right, (black hair:1.25), green eyes, watering, courtyard, (from below:1.4), slowly, slowly';
const NATURAL_FLAT = '用户手写完整画面：左边的甲扶苗，右边的乙浇水；两人都保留 (black hair:1.25)，并保留 slowly, slowly。';
const CHAR_TAG = '(black hair:1.25), blue eyes, freckles';
const USER_TAG = '(black hair:1.25), green eyes, scar';
const CHAR_NL = '用户填写甲的自然外貌，保留原句。';
const USER_NL = '用户填写乙的自然外貌，保留原句。';
const RAW_CHAR = Object.freeze({ role: 'char', name: '甲', tag: CHAR_TAG, nl: CHAR_NL });
const RAW_USER = Object.freeze({ role: 'user', name: '乙', tag: USER_TAG, nl: USER_NL });
const PUBLIC_CHAR = Object.freeze({ name: '甲', tag: CHAR_TAG, nl: CHAR_NL });
const PUBLIC_USER = Object.freeze({ name: '乙', tag: USER_TAG, nl: USER_NL });
const NAI_TAG_CHAR = Object.freeze({ name: '甲', tag: CHAR_TAG });
const NAI_TAG_USER = Object.freeze({ name: '乙', tag: USER_TAG });
const LEGACY_TAG_CHAR = Object.freeze({ name: '甲', tag: CHAR_TAG, nl: CHAR_TAG });
const LEGACY_TAG_USER = Object.freeze({ name: '乙', tag: USER_TAG, nl: USER_TAG });
const APPEARANCE_SUFFIX = '\n\n人物外貌（分别对应上述人物，保持原场景与动作）：\n甲：(black hair:1.25), blue eyes, freckles\n乙：(black hair:1.25), green eyes, scar';
const COMPOSED_VISUAL = VISUAL + APPEARANCE_SUFFIX;
const SAVED_PATH = '/user/images/dedup-fixture/confirmed.png';

function deepFreeze(value) {
    if (!value || typeof value !== 'object' || Object.isFrozen(value)) return value;
    for (const child of Object.values(value)) deepFreeze(child);
    return Object.freeze(value);
}

function metadata(promptFormat, { flat = false, people = 2, sceneTags = TAG_SCENE } = {}) {
    return {
        ...(promptFormat ? { promptFormat } : {}),
        sceneTags,
        flatPrompt: flat ? (promptFormat === 'nai45-tags' ? TAG_FLAT : NATURAL_FLAT) : '',
        characters: [RAW_CHAR, RAW_USER].slice(0, people).map(row => ({ ...row })),
    };
}

function publicProvider(t, { backend, supportsCharacters }) {
    const descriptors = new Map();
    const replace = (key, value) => {
        descriptors.set(key, Object.getOwnPropertyDescriptor(globalThis, key));
        Object.defineProperty(globalThis, key, { configurable: true, writable: true, value });
    };
    const calls = [], forbidden = [];
    replace('location', { href: 'tauri://localhost/' });
    replace('fetch', () => { forbidden.push('network'); throw new Error('No text model or HTTP request is authorized by this fixture'); });
    replace('STBaiBaiImage', {
        apiVersion: 1,
        capabilities: { generate: true, saveToGallery: true },
        getBackendStatus: () => ({ configured: true, supportsCharacters,
            ...(backend === undefined ? {} : { backend }) }),
        generate: async (request, options) => {
            calls.push({ request: structuredClone(request), options });
            return { path: SAVED_PATH, dataUrl: 'data:image/png;base64,UNUSED_PROVIDER_BINARY' };
        },
    });
    const context = {
        name1: '乙', name2: '甲',
        getCharacterCardFields() { forbidden.push('card-read'); throw new Error('No card reread'); },
        saveMetadataDebounced() { forbidden.push('metadata-write'); },
        saveChat() { forbidden.push('chat-write'); },
    };
    t.after(() => {
        for (const [key, descriptor] of descriptors) {
            if (descriptor) Object.defineProperty(globalThis, key, descriptor); else delete globalThis[key];
        }
    });
    return { calls, forbidden, context };
}

// One formatter check, one real preview-boundary check, and one API v1 send.
// Persistence itself is not mocked as a successful draw here: this function
// verifies that assembling/sending a new request cannot mutate an old record.
async function assertPublicCase(t, {
    backend, supportsCharacters, raw, expected, scene = VISUAL,
    mode = 'album', item = {}, legacy = false, orientation = 'landscape',
}) {
    const f = publicProvider(t, { backend, supportsCharacters });
    const rawBefore = JSON.stringify(raw);
    deepFreeze(raw);
    const oldItem = deepFreeze({
        id: 'old-memory', title: '旧图与原始手写内容', date: '剧情历三年', desc: '旧正文不能改写',
        imagePrompt: '原来确认的旧画面', visualSeed: ['花苗', '水壶'],
        cgImage: { url: '/user/images/dedup-fixture/old.png', prompt: '旧图手写提示：保留，保留。',
            provider: 'baibai-image', generatedAt: 123, promptMetadata: raw },
    });
    const oldBefore = JSON.stringify(oldItem);
    const signatureBefore = imagePatch.cgItemSignature(oldItem);
    const normalizedBefore = imagePatch.normalizeCgImageRecord(oldItem.cgImage);

    if (legacy) {
        assert.equal(appearance.formattedCgProviderPrompts(scene, raw, supportsCharacters, backend), null,
            'no-format legacy metadata keeps the original provider adapter path');
    } else {
        assert.deepEqual(appearance.formattedCgProviderPrompts(scene, raw, supportsCharacters, backend), expected);
        assert.deepEqual(images.cgEditorSendPreview(mode, item, scene, raw, raw.promptFormat), expected,
            'preview must obtain the same public backend capability, with independent expected fields');
    }
    assert.equal(JSON.stringify(raw), rawBefore, 'formatter and preview leave all raw metadata intact');
    assert.equal(JSON.stringify(oldItem), oldBefore);
    assert.equal(imagePatch.cgItemSignature(oldItem), signatureBefore);
    assert.equal(f.calls.length, 0, 'preview never generates an image');

    const result = await images.invokeImageGeneration(scene, f.context, {
        provider: 'baibai-image', promptMetadata: raw, orientation, characterName: '图库标签保持原样',
        targetKey: 'dedup-independent-fixture',
    });
    assert.equal(f.calls.length, 1, 'the public API is called exactly once');
    assert.deepEqual(f.calls[0].request, {
        ...expected, size: orientation, save: true, character: '图库标签保持原样',
    }, 'no model override, duplicate request, altered save option, or added private field');
    assert.ok(f.calls[0].options.signal instanceof AbortSignal);
    assert.deepEqual(result, { url: SAVED_PATH, provider: 'baibai-image' }, 'durable provider path is returned unchanged');
    assert.equal(provider.baiBaiImagePendingCount(), 0);
    assert.deepEqual(f.forbidden, []);
    assert.equal(JSON.stringify(raw), rawBefore, 'sending does not migrate or erase old metadata');
    assert.equal(JSON.stringify(oldItem), oldBefore, 'old image, scene, appearance and provider path stay byte-identical');
    assert.equal(imagePatch.cgItemSignature(oldItem), signatureBefore, 'old pending-write signatures are unchanged');
    assert.deepEqual(imagePatch.normalizeCgImageRecord(oldItem.cgImage), normalizedBefore);
}

// Eight NAI cases: both formats, a present/absent complete prompt, and one/two
// separately named people. Two people intentionally share a weighted hair tag.
for (const promptFormat of ['nai45-tags', 'nai5-natural']) {
    for (const flat of [false, true]) for (const people of [1, 2]) {
        test(`NAI character backend: ${promptFormat}, flat=${flat}, people=${people}`, async t => {
            const chars = promptFormat === 'nai45-tags'
                ? [NAI_TAG_CHAR, NAI_TAG_USER].slice(0, people)
                : [PUBLIC_CHAR, PUBLIC_USER].slice(0, people);
            const expected = {
                prompt: promptFormat === 'nai45-tags' ? TAG_SCENE : flat ? NATURAL_FLAT : VISUAL,
                nl: '', characters: chars,
            };
            await assertPublicCase(t, { backend: 'nai', supportsCharacters: true,
                raw: metadata(promptFormat, { flat, people }), expected });
            if (promptFormat === 'nai45-tags') for (const row of expected.characters) assert.equal(Object.hasOwn(row, 'nl'), false);
        });
    }
}

for (const flat of [false, true]) {
    test(`NAI tags with no sceneTags preserve the confirmed mixed-language scene, flat=${flat}`, async t => {
        await assertPublicCase(t, { backend: 'nai', supportsCharacters: true,
            raw: metadata('nai45-tags', { flat, sceneTags: '' }),
            expected: { prompt: VISUAL, nl: '', characters: [NAI_TAG_CHAR, NAI_TAG_USER] } });
    });
}

for (const promptFormat of ['nai45-tags', 'nai5-natural']) for (const flat of [false, true]) {
    test(`NAI character capability with no actual character metadata: ${promptFormat}, flat=${flat}`, async t => {
        await assertPublicCase(t, { backend: 'nai', supportsCharacters: true,
            raw: metadata(promptFormat, { flat, people: 0 }),
            expected: { prompt: flat ? promptFormat === 'nai45-tags' ? TAG_FLAT : NATURAL_FLAT : VISUAL, nl: '' } });
    });
}

// Compatibility is an explicit contract: unknown / absent backend names cannot
// activate NAI-specific rewriting, even when character capability is true.
const COMPATIBILITY = [
    { label: 'ComfyUI separate fields', backend: 'comfyui', supportsCharacters: true },
    { label: 'ComfyUI single field', backend: 'comfyui', supportsCharacters: false },
    { label: 'unknown backend', backend: 'future-provider', supportsCharacters: true },
    { label: 'backend omitted', backend: undefined, supportsCharacters: true },
    { label: 'empty backend single field', backend: '', supportsCharacters: false },
    { label: 'NAI without character capability', backend: 'nai', supportsCharacters: false },
    { label: 'case-distinct unknown backend', backend: 'NAI', supportsCharacters: true },
];
const COMPATIBILITY_FIELDS = {
    'nai45-tags': {
        multi: { withoutFlat: TAG_SCENE, withFlat: TAG_SCENE, characters: [LEGACY_TAG_CHAR, LEGACY_TAG_USER] },
        single: { withoutFlat: COMPOSED_VISUAL, withFlat: TAG_FLAT },
    },
    'nai5-natural': {
        multi: { withoutFlat: COMPOSED_VISUAL, withFlat: NATURAL_FLAT, characters: [PUBLIC_CHAR, PUBLIC_USER] },
        single: { withoutFlat: COMPOSED_VISUAL, withFlat: NATURAL_FLAT },
    },
};
for (const status of COMPATIBILITY) for (const promptFormat of ['nai45-tags', 'nai5-natural']) for (const flat of [false, true]) {
    test(`unchanged compatibility payload: ${status.label}, ${promptFormat}, flat=${flat}`, async t => {
        const fields = COMPATIBILITY_FIELDS[promptFormat][status.supportsCharacters ? 'multi' : 'single'];
        const prompt = flat ? fields.withFlat : fields.withoutFlat;
        const expected = { prompt, nl: prompt, ...(fields.characters ? { characters: fields.characters } : {}) };
        await assertPublicCase(t, { ...status, raw: metadata(promptFormat, { flat }), expected });
    });
}

const LEGACY_BACKENDS = [
    { label: 'NAI multi', backend: 'nai', supportsCharacters: true },
    { label: 'NAI single', backend: 'nai', supportsCharacters: false },
    { label: 'ComfyUI', backend: 'comfyui', supportsCharacters: true },
    { label: 'unknown', backend: 'future-provider', supportsCharacters: true },
    { label: 'missing', backend: undefined, supportsCharacters: true },
];
for (const status of LEGACY_BACKENDS) for (const flat of [false, true]) {
    test(`legacy metadata without a format stays on its original contract: ${status.label}, flat=${flat}`, async t => {
        const prompt = status.supportsCharacters ? TAG_SCENE : flat ? NATURAL_FLAT : COMPOSED_VISUAL;
        await assertPublicCase(t, { ...status, legacy: true, raw: metadata('', { flat }),
            expected: { prompt, nl: COMPOSED_VISUAL,
                ...(status.supportsCharacters ? { characters: [PUBLIC_CHAR, PUBLIC_USER] } : {}) } });
    });
}

const FOUR_TAG_SCENE = 'panel 1 holding seedling, panel 2 pouring water, panel 3 opening umbrella, panel 4 sitting together';
const FOUR_NATURAL_SCENE = '第1格甲扶苗。第2格乙浇水。第3格甲撑伞。第4格两人坐下。';
const FOUR_TAG_PREFIX = 'chibi, super deformed, 4koma, comic, vertical composition, consistent characters, distinct poses, no text, no speech bubble, no watermark, ';
const FOUR_NATURAL_PREFIX = 'Chibi visual story with oversized heads and tiny bodies, 4 vertically arranged panels. Keep the same characters and clothing, with distinct actions and framing in each panel. No text, speech bubbles, subtitles, logos or watermarks.\n';
for (const promptFormat of ['nai45-tags', 'nai5-natural']) for (const backend of ['nai', 'comfyui']) {
    test(`four-panel comic wraps once and keeps all actions: ${promptFormat}, backend=${backend}`, async t => {
        const tagMode = promptFormat === 'nai45-tags';
        const scene = tagMode ? FOUR_TAG_SCENE : FOUR_NATURAL_SCENE;
        const prefix = tagMode ? FOUR_TAG_PREFIX : FOUR_NATURAL_PREFIX;
        const prompt = prefix + scene + (!tagMode && backend === 'comfyui' ? APPEARANCE_SUFFIX : '');
        const expected = { prompt, nl: backend === 'nai' ? '' : prompt,
            characters: tagMode ? backend === 'nai' ? [NAI_TAG_CHAR, NAI_TAG_USER] : [LEGACY_TAG_CHAR, LEGACY_TAG_USER]
                : [PUBLIC_CHAR, PUBLIC_USER] };
        await assertPublicCase(t, { backend, supportsCharacters: true, scene, mode: 'heart', orientation: 'portrait',
            item: { panelCount: 4, panels: [{ action: '扶苗' }, { action: '浇水' }, { action: '撑伞' }, { action: '坐下' }] },
            raw: { ...metadata(promptFormat, { sceneTags: scene }), comicPanels: 4 }, expected });
    });
}

for (const promptFormat of ['nai45-tags', 'nai5-natural']) {
    test(`omitting the new backend argument preserves the old formatter contract: ${promptFormat}`, () => {
        const raw = deepFreeze(metadata(promptFormat));
        const before = JSON.stringify(raw);
        const fields = COMPATIBILITY_FIELDS[promptFormat].multi;
        assert.deepEqual(appearance.formattedCgProviderPrompts(VISUAL, raw, true), {
            prompt: fields.withoutFlat, nl: fields.withoutFlat, characters: fields.characters,
        });
        assert.equal(JSON.stringify(raw), before);
    });
}
