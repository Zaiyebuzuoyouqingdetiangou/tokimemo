// Exercises index.js byte-for-byte in a temporary module tree. The runtime module
// boundary is a declared spy; this does NOT prove the real runtime settings UI.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir, mkdtemp, rm } from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const SETTINGS = 'heartbeat_memories_settings';
const MENU = 'heartbeat_memories_menu_item';
const DIAGNOSTIC = 'heartbeat_memories_external_diagnostic';
let sequence = 0;

// Adapted from tests/r75DiagnosticEntry.test.mjs. It is a DOM/event fixture,
// not a screenshot/layout substitute. Unlike that fixture, it models timers
// and can create the menu host after bootstrap has already started.
class ElementFixture {
    constructor(tag, ownerDocument) {
        this.tagName = tag.toUpperCase(); this.ownerDocument = ownerDocument;
        this.children = []; this.attributes = new Map(); this.listeners = new Map();
        this.dataset = {}; this.hidden = false; this.className = ''; this.style = {};
        this.textContent = ''; this.innerHTML = ''; this.value = ''; this.open = false;
    }
    get isConnected() { return this === this.ownerDocument || !!this.parentNode?.isConnected; }
    setAttribute(key, value) { this.attributes.set(key, String(value)); }
    getAttribute(key) { return this.attributes.get(key) ?? null; }
    hasAttribute(key) { return this.attributes.has(key); }
    matches(selector) {
        return selector.split(',').some(part => {
            const one = part.trim();
            if (one.startsWith('#')) return this.id === one.slice(1);
            if (one.startsWith('.')) return this.className.split(/\s+/).includes(one.slice(1));
            const attr = one.match(/^\[([^=\]]+)(?:="([^"]*)")?\]$/);
            if (attr) return this.hasAttribute(attr[1]) && (attr[2] === undefined || this.getAttribute(attr[1]) === attr[2]);
            return this.tagName.toLowerCase() === one;
        });
    }
    closest(selector) { for (let node = this; node; node = node.parentNode) if (node.matches(selector)) return node; return null; }
    querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
    querySelectorAll(selector) {
        return this.children.flatMap(child => [...(child.matches(selector) ? [child] : []), ...child.querySelectorAll(selector)]);
    }
    appendChild(node) { node.remove(); this.children.push(node); node.parentNode = this; return node; }
    remove() {
        if (!this.parentNode) return;
        this.parentNode.children.splice(this.parentNode.children.indexOf(this), 1); this.parentNode = null;
    }
    addEventListener(type, callback, options = {}) {
        const list = this.listeners.get(type) || [];
        list.push({ callback, capture: options === true || options.capture === true, once: options.once === true });
        this.listeners.set(type, list);
    }
    removeEventListener(type, callback, options = {}) {
        const capture = options === true || options.capture === true;
        this.listeners.set(type, (this.listeners.get(type) || []).filter(row => row.callback !== callback || row.capture !== capture));
    }
    dispatch(type, fields = {}) {
        const eventPath = []; for (let node = this; node; node = node.parentNode) eventPath.push(node);
        const event = { type, target: this, button: 0, preventDefault() {}, composedPath: () => eventPath, ...fields };
        const deliver = (node, capture) => {
            for (const row of [...(node.listeners.get(type) || [])]) {
                if (row.capture !== capture) continue;
                row.callback(event);
                if (row.once) node.removeEventListener(type, row.callback, { capture });
            }
        };
        for (const node of [...eventPath].reverse()) deliver(node, true);
        for (const node of eventPath) deliver(node, false);
    }
    click() {
        if (this.tagName === 'SUMMARY') { this.parentNode.open = !this.parentNode.open; this.parentNode.dispatch('toggle'); }
        this.dispatch('click');
    }
}

async function fixture(t, { menuPresent = true, runtimeAvailable = true } = {}) {
    const descriptors = new Map();
    const replace = (key, value) => {
        if (!descriptors.has(key)) descriptors.set(key, Object.getOwnPropertyDescriptor(globalThis, key));
        Object.defineProperty(globalThis, key, { configurable: true, writable: true, value });
    };
    const document = new ElementFixture('#document'); document.ownerDocument = document;
    document.readyState = 'loading'; document.createElement = tag => new ElementFixture(tag, document);
    document.getElementById = id => document.querySelector('#' + id);
    document.head = document.createElement('head'); document.body = document.createElement('body');
    document.appendChild(document.head); document.appendChild(document.body);
    const host = document.createElement('div'); host.id = 'extensions_settings2'; document.body.appendChild(host);
    // Sentinel proves cleanup/removal is scoped to this plugin.
    const sentinel = document.createElement('details'); sentinel.id = 'other-extension-settings'; host.appendChild(sentinel);
    const mountMenuHost = () => {
        let menu = document.getElementById('extensionsMenu');
        if (!menu) { menu = document.createElement('div'); menu.id = 'extensionsMenu'; document.body.appendChild(menu); }
        return menu;
    };
    if (menuPresent) mountMenuHost();
    const intervals = new Map(); let timerId = 0; let ticks = 0;
    const forbidden = [], events = [];
    const context = { extensionSettings: {}, chatMetadata: {}, chat: [] };
    for (const name of ['getCharacterCardFields', 'getWorldInfoPrompt', 'getTokenCountAsync', 'saveMetadataDebounced']) {
        context[name] = () => { forbidden.push(name); throw new Error('Unexpected source/save access: ' + name); };
    }
    replace('document', document); replace('SillyTavern', { getContext: () => context });
    replace('indexedDB', { open() { forbidden.push('idb'); throw new Error('Unexpected IDB access'); } });
    replace('STBaiBaiImage', { generate() { forbidden.push('provider'); throw new Error('Unexpected generation'); } });
    replace('localStorage', Object.fromEntries(['getItem', 'setItem', 'removeItem'].map(name => [name, () => { forbidden.push(name); throw new Error('Unexpected local storage access'); }])));
    replace('fetch', () => { forbidden.push('fetch'); throw new Error('Unexpected network access'); });
    replace('toastr', { error: () => {}, warning: () => {} });
    replace('setInterval', (callback, milliseconds) => { const id = ++timerId; intervals.set(id, { callback, milliseconds }); return id; });
    replace('clearInterval', id => intervals.delete(id));
    replace('__hearttracePanelRemovalRuntimeSpy', events);
    // Restore diagnostic globals installed/removed by index.js as well as spies.
    for (const key of ['__heartbeatMemoriesGetPerformanceDiagnostic', '__heartbeatMemoriesRenderPerformanceDiagnostic',
        '__heartbeatMemoriesHidePerformanceDiagnostic', '__heartbeatMemoriesTogglePerformanceDiagnostic',
        '__heartbeatMemoriesMountDiagnostics', '__heartbeatMemoriesRemoveDiagnostics', '__heartbeatMemoriesDeliverDiagnostic',
        '__heartbeatMemoriesRuntimeLoaded', '__heartbeatMemoriesBuild']) replace(key, globalThis[key]);

    const tempBase = path.resolve(os.tmpdir());
    const temporaryRoot = await mkdtemp(path.join(tempBase, 'hearttrace-panel-review-'));
    let api;
    t.after(async () => {
        try { api?.onClean(); }
        finally {
            for (const [key, descriptor] of descriptors) {
                if (descriptor) Object.defineProperty(globalThis, key, descriptor); else delete globalThis[key];
            }
            const resolved = path.resolve(temporaryRoot);
            assert.equal(path.dirname(resolved), tempBase, 'cleanup stays within the explicit temporary parent');
            assert.ok(path.basename(resolved).startsWith('hearttrace-panel-review-'));
            await rm(resolved, { recursive: true, force: true });
        }
    });
    await writeFile(path.join(temporaryRoot, 'package.json'), '{"type":"module"}\n');
    // No source replacement, regex patch, exported private function, or test hook
    // is injected into the bootstrap. It executes exactly the candidate bytes.
    await writeFile(path.join(temporaryRoot, 'index.js'), await readFile(path.join(root, 'index.js')));
    if (runtimeAvailable) {
        await mkdir(path.join(temporaryRoot, 'dist'));
        await writeFile(path.join(temporaryRoot, 'dist', 'heartbeatMemories.bundle.js'), `
const events = globalThis.__hearttracePanelRemovalRuntimeSpy;
events.push({type: 'evaluated'});
export function initMemoryTheater() { events.push({type: 'initialized'}); }
export function openArchiveLibrary(source) { events.push({type: 'opened', source}); }
export function destroyMemoryTheater() { events.push({type: 'destroyed'}); }
export function isGenerationBusy() { return false; }
`);
    }
    api = await import(pathToFileURL(path.join(temporaryRoot, 'index.js')).href + '?test=' + (++sequence));
    return {
        api, document, host, sentinel, intervals, events, forbidden, mountMenuHost,
        start: () => document.dispatch('DOMContentLoaded'),
        tick() { ticks += 1; for (const [id, timer] of [...intervals]) if (intervals.has(id)) timer.callback(); },
        get ticks() { return ticks; },
    };
}

function assertHostHasNoSettings(f, { diagnosticAllowed = false } = {}) {
    assert.equal(f.document.getElementById(SETTINGS), null, 'no external settings panel, even hidden');
    assert.equal(f.document.getElementById(SETTINGS + '_launcher'), null, 'no folded/launcher replacement');
    const owned = f.host.children.filter(node => node !== f.sentinel);
    assert.deepEqual(owned.map(node => node.id), diagnosticAllowed ? [DIAGNOSTIC] : [], 'no replacement entry under the host drawer');
    assert.equal(f.sentinel.parentNode, f.host, 'other plugin settings survive');
}

test('cold bootstrap keeps host settings empty and does not wait for a removed panel', async t => {
    const f = await fixture(t); f.start();
    assertHostHasNoSettings(f);
    assert.ok(f.document.getElementById(MENU));
    assert.equal(f.intervals.size, 0, 'a ready menu ends mounting without a settings ID');
    assert.equal(f.api.bootPromise, null); assert.deepEqual(f.events, []);
    assert.deepEqual(f.forbidden, []);
});

test('late menu stops retrying on first successful mount with no settings panel', async t => {
    const f = await fixture(t, { menuPresent: false }); f.start();
    assertHostHasNoSettings(f); assert.equal(f.intervals.size, 1);
    assert.equal([...f.intervals.values()][0].milliseconds, 500);
    f.tick(); f.tick(); f.mountMenuHost(); f.tick();
    assert.equal(f.ticks, 3); assert.ok(f.document.getElementById(MENU));
    assert.equal(f.intervals.size, 0); assertHostHasNoSettings(f);
    assert.equal(f.api.bootPromise, null); assert.deepEqual(f.events, []); assert.deepEqual(f.forbidden, []);
});

test('missing menu retains the existing 30-attempt bound without creating settings', async t => {
    const f = await fixture(t, { menuPresent: false }); f.start();
    for (let i = 0; i < 29; i += 1) f.tick();
    assert.equal(f.intervals.size, 1); f.tick();
    assert.equal(f.ticks, 30); assert.equal(f.intervals.size, 0);
    assert.equal(f.document.getElementById(MENU), null); assertHostHasNoSettings(f);
    assert.deepEqual(f.events, []); assert.deepEqual(f.forbidden, []);
});

for (const trigger of ['click', 'enter', 'space', 'pointerdown', 'touchstart']) {
    test(`existing ${trigger} menu action lazily loads the runtime exactly once`, async t => {
        const f = await fixture(t); f.start(); const menu = f.document.getElementById(MENU);
        assert.ok(menu); assert.deepEqual(f.events, []); assert.equal(f.api.bootPromise, null);
        if (trigger === 'enter' || trigger === 'space') menu.dispatch('keydown', { key: trigger === 'enter' ? 'Enter' : ' ' });
        else menu.dispatch(trigger);
        assert.ok(f.api.bootPromise, 'the actual menu event starts the deferred import');
        await f.api.bootPromise;
        // ensureRuntime is async; drain its caller's chained open before observing the spy.
        await new Promise(resolve => setImmediate(resolve));
        assert.deepEqual(f.events.map(event => event.type), ['evaluated', 'initialized', 'opened']);
        assert.match(f.events[2].source, /^bootstrap-/);
        assert.equal(f.intervals.size, 0); assertHostHasNoSettings(f); assert.deepEqual(f.forbidden, []);
    });
}

test('a missing runtime retains only the established diagnostic fallback and disable clears it', async t => {
    const f = await fixture(t, { runtimeAvailable: false }); f.start();
    assertHostHasNoSettings(f);
    const menu = f.document.getElementById(MENU); menu.click();
    const pending = f.api.bootPromise; assert.ok(pending); await assert.rejects(pending);
    assert.equal(f.api.bootPromise, null); assertHostHasNoSettings(f, { diagnosticAllowed: true });
    const diagnostic = f.document.getElementById(DIAGNOSTIC);
    diagnostic.querySelector('summary').click();
    diagnostic.querySelector('[data-rmt-diagnostic-action="show"]').click();
    assert.equal(JSON.parse(diagnostic.querySelector('textarea').value).plugin.runtimeLoaded, false);
    assert.deepEqual(f.forbidden, []);
    f.api.onDisable();
    assertHostHasNoSettings(f); assert.equal(f.document.getElementById(MENU), null);
    assert.equal(f.intervals.size, 0); assert.equal(f.api.mountExternalDiagnostic(), false);
});

test('disable before a late menu prevents bootstrap resurrection', async t => {
    const f = await fixture(t, { menuPresent: false }); f.start();
    const callback = [...f.intervals.values()][0].callback;
    f.api.onDisable(); f.mountMenuHost(); callback();
    assertHostHasNoSettings(f); assert.equal(f.document.getElementById(MENU), null);
    assert.equal(f.intervals.size, 0); assert.deepEqual(f.events, []); assert.deepEqual(f.forbidden, []);
});
