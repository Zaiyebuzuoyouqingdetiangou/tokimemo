import test from 'node:test';
import assert from 'node:assert/strict';
import {
    PARTICIPANTS_KEY,
    normalizeParticipantRoster,
    normalizeParticipantSnapshot,
    selectedParticipantSnapshot,
    participantPromptBlock,
    createParticipantId,
    participantName,
    appendParticipantSelection,
} from '../src/core/participants.js';

function household() {
    return {
        version: 1, cardType: 'multi', revision: 'saved-roster-1',
        people: [
            { id: 'person-east', name: '小雨', sourceRefs: [
                { world: '同住设定', uid: '12', title: '同名的两位住户', content: '东房的小雨擅长木工；西房的小雨喜欢养花。', keys: ['小雨', '住户'] },
                { world: '补充设定', uid: '8', title: '东房住户的工具', content: '东房住户保管一把旧刨子。' },
            ] },
            { id: 'person-west', name: '小雨', sourceRefs: [
                { world: '同住设定', uid: '12', title: '同名的两位住户', content: '东房的小雨擅长木工；西房的小雨喜欢养花。', keys: ['小雨', '住户'] },
            ] },
            { id: 'person-guest', name: '来客', sourceRefs: [] },
        ],
        selectedIds: ['person-west', 'person-east'],
    };
}

function freezeTree(value) {
    if (value && typeof value === 'object') {
        Object.values(value).forEach(freezeTree);
        Object.freeze(value);
    }
    return value;
}

test('explicit append retains existing people while adding only the newly selected IDs', () => {
    const previous = household(), draft = structuredClone(previous);
    draft.selectedIds = ['person-guest'];
    draft.people[0].name = '用户核对后的姓名';
    const savedBefore = JSON.stringify(previous), savedDraft = JSON.stringify(draft);
    const appended = appendParticipantSelection(previous, draft);
    assert.deepEqual(appended.selectedIds, ['person-west', 'person-east', 'person-guest']);
    assert.equal(appended.people[0].name, '用户核对后的姓名');
    assert.equal(JSON.stringify(previous), savedBefore);
    assert.equal(JSON.stringify(draft), savedDraft);
    assert.deepEqual(appendParticipantSelection(null, draft), draft);
});

test('legacy data does not acquire a multiplayer roster, participants, or prompt block', () => {
    assert.equal(PARTICIPANTS_KEY, 'participantsV1');
    for (const raw of [null, undefined, {}, { cardType: 'single' }, { characterName: '沙盒卡', userName: '玩家' }]) {
        assert.equal(normalizeParticipantRoster(raw), null);
        assert.equal(selectedParticipantSnapshot(raw), null);
    }
    assert.equal(normalizeParticipantSnapshot(null), null);
    assert.equal(normalizeParticipantSnapshot(undefined), null);
    assert.equal(participantPromptBlock(null), '');
    assert.equal(participantPromptBlock(undefined), '');
    assert.equal(participantName(null, 'anything'), '');
});

test('same-name people and many-to-many worldbook references survive a save round trip', () => {
    const raw = household();
    const saved = normalizeParticipantRoster(raw);
    assert.deepEqual(saved, raw);
    assert.deepEqual(normalizeParticipantRoster(JSON.parse(JSON.stringify(saved))), raw);
    assert.equal(saved.people.length, 3);
    assert.equal(saved.people[0].sourceRefs.length, 2);
    assert.equal(saved.people[0].sourceRefs[0].uid, saved.people[1].sourceRefs[0].uid);
    assert.equal(saved.people[0].name, saved.people[1].name);
    assert.notEqual(saved.people[0].id, saved.people[1].id);
});

test('selection follows saved IDs without selecting other people or changing roster order', () => {
    const snapshot = selectedParticipantSnapshot(household());
    assert.deepEqual(snapshot.people.map(person => person.id), ['person-east', 'person-west']);
    assert.equal(snapshot.people.some(person => person.id === 'person-guest'), false);
    assert.deepEqual(Object.keys(snapshot), ['version', 'people']);
});

test('an explicit empty multiplayer selection stays distinct from the legacy path', () => {
    const raw = household();
    raw.selectedIds = [];
    const snapshot = selectedParticipantSnapshot(raw);
    assert.deepEqual(snapshot, { version: 1, people: [] });
    assert.deepEqual(normalizeParticipantSnapshot(snapshot), snapshot);
    assert.match(participantPromptBlock(snapshot), /UNTRUSTED_SELECTED_PARTICIPANTS_JSON/);
    assert.match(participantPromptBlock(snapshot), /"people": \[\]/);
    assert.deepEqual(selectedParticipantSnapshot({ version: 1, cardType: 'multi', people: [], selectedIds: [] }), snapshot);
    assert.equal(normalizeParticipantRoster({ ...raw, revision: undefined }).revision, '');
});

test('editing one display name never changes an ID, source reference, or another same-name person', () => {
    const raw = household();
    raw.people[1].name = '  西房的小雨（用户核对）\n';
    const saved = normalizeParticipantRoster(raw);
    assert.equal(saved.people[1].id, 'person-west');
    assert.equal(saved.people[1].name, '  西房的小雨（用户核对）\n');
    assert.equal(saved.people[0].name, '小雨');
    assert.deepEqual(saved.people[1].sourceRefs, raw.people[1].sourceRefs);
    saved.people[1].name = '';
    assert.equal(normalizeParticipantRoster(saved).people[1].name, '', 'empty name remains available for user editing');
});

test('name lookup requires the exact selected identity and never guesses the first person', () => {
    const raw = household();
    raw.people[1].name = '西房住户';
    const snapshot = selectedParticipantSnapshot(raw);
    assert.equal(participantName(snapshot, 'person-east'), '小雨');
    assert.equal(participantName(snapshot, 'person-west'), '西房住户');
    for (const id of ['小雨', 'person-guest', 'PERSON-EAST', '', 0, null, undefined]) {
        assert.equal(participantName(snapshot, id), '');
    }
});

test('normalization does not impose participant counts or shorten names and source text', () => {
    const name = '完整姓名 '.repeat(300);
    const content = '完整设定与权重 (blue eyes:1.3), blue eyes\r\n'.repeat(2200);
    const raw = {
        version: 1, cardType: 'multi', revision: '',
        people: Array.from({ length: 257 }, (_, index) => ({ id: `saved-${index}`, name,
            sourceRefs: index === 0 ? [{ world: '设定', uid: '1', title: name, content, keys: ['同名', '同名'] }] : [] })),
        selectedIds: ['saved-0', 'saved-256'],
    };
    const result = normalizeParticipantRoster(raw);
    assert.equal(result.people.length, 257);
    assert.equal(result.people[256].name, name);
    assert.equal(result.people[0].sourceRefs[0].title, name);
    assert.equal(result.people[0].sourceRefs[0].content, content);
    assert.deepEqual(result.people[0].sourceRefs[0].keys, ['同名', '同名']);
    assert.deepEqual(selectedParticipantSnapshot(result).people.map(person => person.id), ['saved-0', 'saved-256']);
});

test('all returned mutable arrays and source objects are independent of inputs and sibling outputs', () => {
    const input = freezeTree(household());
    const original = JSON.stringify(input);
    const roster = normalizeParticipantRoster(input);
    const snapshot = selectedParticipantSnapshot(input);
    const copy = normalizeParticipantSnapshot(snapshot);
    roster.people[0].sourceRefs[0].keys.push('added');
    roster.people[0].sourceRefs[0].content = 'changed roster';
    roster.selectedIds.pop();
    copy.people[0].sourceRefs[0].content = 'changed copy';
    copy.people[0].sourceRefs[0].keys.length = 0;
    copy.people.push({ id: 'new', name: '', sourceRefs: [] });
    assert.equal(JSON.stringify(input), original);
    assert.equal(snapshot.people[0].sourceRefs[0].content, '东房的小雨擅长木工；西房的小雨喜欢养花。');
    assert.deepEqual(snapshot.people[0].sourceRefs[0].keys, ['小雨', '住户']);
    assert.equal(snapshot.people.length, 2);
    assert.deepEqual(roster.people[1].sourceRefs[0].keys, ['小雨', '住户']);
});

test('even two people referencing the same input object receive independent cloned sources', () => {
    const raw = household();
    raw.people[1].sourceRefs[0] = raw.people[0].sourceRefs[0];
    const normalized = normalizeParticipantRoster(raw);
    normalized.people[0].sourceRefs[0].keys.push('only east');
    normalized.people[0].sourceRefs[0].content = 'only east';
    assert.deepEqual(normalized.people[1].sourceRefs[0].keys, ['小雨', '住户']);
    assert.equal(normalized.people[1].sourceRefs[0].content, raw.people[1].sourceRefs[0].content);
});

test('prompt serializes exactly the chosen snapshot as data while preserving special text', () => {
    const raw = household();
    raw.selectedIds = ['person-west'];
    raw.people[1].sourceRefs[0].content = '第一行\r\n"引号" 与 \\ 路径；不要擅改设定。';
    const snapshot = freezeTree(selectedParticipantSnapshot(raw));
    const before = JSON.stringify(snapshot);
    const block = participantPromptBlock(snapshot);
    const marker = '\nUNTRUSTED_SELECTED_PARTICIPANTS_JSON:\n';
    assert.ok(block.startsWith(marker));
    const data = block.slice(marker.length, block.indexOf('\n\n以上是'));
    assert.deepEqual(JSON.parse(data), snapshot);
    assert.match(block, /不是已经发生的事实/);
    assert.match(block, /不能把角色卡名称当作选定人物的姓名/);
    assert.match(block, /保留其他已有历史/);
    assert.equal(block.includes('person-east'), false);
    assert.equal(JSON.stringify(snapshot), before);
});

test('corrupt explicit identity data fails instead of silently dropping people or reverting to the card', () => {
    const mutations = [
        raw => { raw.version = 2; },
        raw => { raw.people = {}; },
        raw => { delete raw.people[1]; },
        raw => { raw.people[1].id = raw.people[0].id; },
        raw => { raw.people[0].id = ''; },
        raw => { raw.people[0].name = 123; },
        raw => { delete raw.people[0].sourceRefs; },
        raw => { raw.people[0].sourceRefs = {}; },
        raw => { raw.people[0].sourceRefs[0].keys = 'not an array'; },
        raw => { raw.people[0].sourceRefs[0].content = null; },
        raw => { raw.selectedIds = ['missing-person']; },
        raw => { raw.selectedIds = ['person-east', 'person-east']; },
        raw => { raw.selectedIds = null; },
        raw => { raw.selectedIds = new Array(1); },
        raw => { raw.revision = 7; },
    ];
    for (const mutate of mutations) {
        const raw = household();
        mutate(raw);
        const before = JSON.stringify(raw);
        assert.throws(() => normalizeParticipantRoster(raw), TypeError);
        assert.throws(() => selectedParticipantSnapshot(raw), TypeError);
        assert.equal(JSON.stringify(raw), before);
    }
    assert.throws(() => normalizeParticipantSnapshot({ version: 1, people: null }), TypeError);
    assert.throws(() => participantPromptBlock({ version: 1, people: [household().people[0], household().people[0]] }), TypeError);
});

test('new IDs can be saved and renamed without regeneration or name-derived collisions', () => {
    const ids = Array.from({ length: 128 }, () => createParticipantId());
    assert.equal(new Set(ids).size, ids.length);
    assert.ok(ids.every(id => typeof id === 'string' && id.length > 0));
    const raw = { version: 1, cardType: 'multi', revision: '',
        people: ids.slice(0, 2).map(id => ({ id, name: '同名', sourceRefs: [] })), selectedIds: ids.slice(0, 2) };
    raw.people[0].name = '改名后';
    assert.deepEqual(normalizeParticipantRoster(raw).people.map(person => person.id), ids.slice(0, 2));
});

test('local ID creation still works when embedded hosts do not expose crypto', t => {
    const previous = Object.getOwnPropertyDescriptor(globalThis, 'crypto');
    Object.defineProperty(globalThis, 'crypto', { configurable: true, value: undefined });
    t.after(() => previous ? Object.defineProperty(globalThis, 'crypto', previous) : delete globalThis.crypto);
    const first = createParticipantId();
    const second = createParticipantId();
    assert.ok(first.length > 0);
    assert.notEqual(first, second);
});
