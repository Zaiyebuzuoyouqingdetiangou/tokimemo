import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './helpers/r847Host.mjs';
import { parsePartialJsonObject } from '../src/generation/jsonParser.js';
import { projectGenerationProgress } from '../src/generation/partialProgress.js';
import * as album from '../src/modes/album.js';
import * as butterfly from '../src/modes/butterfly.js';
import * as ending from '../src/modes/ending.js';
import * as past from '../src/modes/pastLives.js';
import * as adv from '../src/modes/advEvent.js';
import * as overlay from '../src/ui/overlay.js';
import * as client from '../src/generation/client.js';
import * as cache from '../src/core/cache.js';
import { state } from '../src/core/state.js';
import { renderAlbum, renderSharedMemory } from '../src/ui/albumView.js';
import { renderButterfly } from '../src/ui/butterflyView.js';
import { renderEnding } from '../src/ui/endingView.js';
import { pastLivesHtml, renderPastLives } from '../src/ui/pastLivesView.js';
import { renderAdvMode } from '../src/ui/advEventView.js';

const memory = { chatId: 'partial-chat', archiveRevision: 'partial-revision', characterName: '林舟', userName: '小月',
    memories: [{ id: 'M001', title: '栽花', summary: '两人一同在庭院栽花。', anchors: ['庭院'] }] };
const ref = { sourceMemoryIds: ['M001'], sourceMemoryAnchor: '庭院' };
const cg = { id: 'CG01', title: '庭院里的花', desc: '林舟站在庭院花架旁。', unlocked: true, category: '日常', ...ref };
const index = { title: '相簿草稿', entries: [cg] };
const main = { label: '主时间线', monologue: '我记得庭院的花。', intervention: '这段记录留在当前庭院。', systemNote: '记录已接收。', branchAxes: ['decision'], ...ref };
const branch = { label: '沿河的花店', monologue: '我决定沿河开一家花店。', intervention: '我想读完这个选择。', systemNote: '分支已接收。',
    primaryAxis: 'decision', worldSpec: { era: '现代都市', identity: '花店店主', occupation: '花艺师', location: '河边街区',
        keyDecision: '留下开店', encounterWithUser: '在花店相遇', bondWithUser: '同伴互助', finalFate: '花店继续营业', thirdPartyRomance: false } };
const outline = { title: '结局草稿', relationshipState: '同伴', relationshipSummary: '两人一同在庭院栽花。',
    relationshipSourceMemoryIds: ['M001'], relationshipSourceMemoryAnchor: '庭院',
    endings: ['route', 'romance', 'reverse', 'bond', 'open'].map((type, i) => ({ id: `END${i + 1}`, type,
        title: `庭院路线${i + 1}`, available: true, subtitle: '未来的一种可能', ...ref })) };
const plan = { title: '旧花笺', opening: { title: '纸页', motif: '一片花瓣', text: '假如旧时的花笺落在桌边。', ...ref },
    dossiers: [{ title: '河畔旧卷', era: '旧城', intent: '读一封未寄出的信。' }] };
const dossier = { title: '河畔旧卷', era: '旧城', synopsis: '另一段虚构人生里，林舟沿河送信。',
    clues: [{ kind: 'object', title: '花笺', speaker: 'narrator', text: '纸上留着干燥的花瓣。', revealedText: '' }] };
const segment = (slot, raw) => ({ slot, state: typeof raw === 'string' ? 'truncated' : 'complete',
    ...parsePartialJsonObject(typeof raw === 'string' ? raw : JSON.stringify(raw)) });
const mark = session => ({ ...session, readableProgress: { version: 1, complete: false, pageId: session.kind, draftId: 'partial-test' } });

test('album keeps an index and closed dialogue strings before the final row closes, without accepting it as complete', () => {
    const inputs = [segment('mode:index', index), segment('mode:comments:0', '{"items":[{"id":"CG01","comments":["第一句已付费的对白","第二句已付费的对白","还没闭合')];
    const before = JSON.stringify(inputs.map(item => item.value));
    const session = album.projectAlbumProgress({ segments: inputs, memoryBank: memory });
    assert.deepEqual(session.entries[0].comments, ['第一句已付费的对白', '第二句已付费的对白']);
    assert.deepEqual(session.entries[0].progressPending, ['共同回忆']);
    assert.throws(() => album.normalizeAlbum(session, memory));
    assert.equal(JSON.stringify(inputs.map(item => item.value)), before);
});

test('a malformed album record does not hide a different completed valid index record', () => {
    const session = album.projectAlbumProgress({ segments: [segment('x:index', { entries: [cg, { id: 'bad', unlocked: false, ...ref }] })], memoryBank: memory });
    assert.deepEqual(session.entries.map(item => item.id), ['CG01']);
});

test('butterfly reads MAIN and a completed branch before Omega, without reclassifying the branch as the ending', () => {
    const session = butterfly.projectButterflyProgress({ segments: [segment('x:slot:0', { node: main }), segment('x:slot:1', { node: branch })], memoryBank: memory,
        context: { name1: memory.userName, name2: memory.characterName } });
    assert.equal(session.nodes.length, 2); assert.equal(session.nodes[1].trueEnding, false);
    assert.deepEqual(session.progressPending, ['Ω 观测收尾']);
    assert.throws(() => butterfly.normalizeButterfly(session, memory));
});

test('ending retains completed route prose and closed epilogue scenes from an interrupted detail', () => {
    const raw = '{"id":"END1","endingScene":"已经写好的终章正文。","epilogue":{"scenes":[{"title":"翌日","text":"已经写好的后日谈。"},{"title":"未写完';
    const session = ending.projectEndingProgress({ segments: [segment('x:outline', outline), segment('x:route:END1', raw)], memoryBank: memory });
    assert.equal(session.endings[0].endingScene, '已经写好的终章正文。');
    assert.deepEqual(session.endings[0].epilogue.scenes, [{ title: '翌日', text: '已经写好的后日谈。' }]);
    assert.equal(session.endings[1].endingScene, '');
    assert.ok(session.endings[0].progressPending.length);
    assert.throws(() => ending.normalizeEnding(session, memory));
});

test('past lives reads a completed opening, dossier and echo without inventing an ending', () => {
    const session = mark(past.projectPastLivesProgress({ segments: [segment('x:past-lives-plan', plan), segment('x:past-lives-dossier:D01', dossier),
        segment('x:past-lives-finale', '{"echoes":[{"kind":"memory","text":"两人一同在庭院栽花。","reflection":"这一页值得细读。","sourceMemoryIds":["M001"],"sourceMemoryAnchor":"庭院"}],"closing":{"text":"未闭合')], memoryBank: memory }));
    assert.equal(session.episodes[0].dossiers[0].synopsis, dossier.synopsis);
    assert.equal(session.episodes[0].echoes[0].text, memory.memories[0].summary);
    assert.equal(session.episodes[0].closing, null);
    assert.equal(past.readablePastLivesProgressSession(session, memory), session);
    assert.equal(past.readablePastLivesSession(session, memory), null);
    assert.equal(past.readablePastLivesProgressSession({ ...session, readableProgress: undefined }, memory), null);
    const closingHtml = pastLivesHtml({ ...session, view: 'closing', pastLivesClosing: true });
    assert.match(closingHtml, /落款尚未完成/); assert.doesNotMatch(closingHtml, /暂不可读取/);
});

test('ADV keeps completed paragraphs inside an unclosed item and binds them only to its original event', () => {
    const previousSession = adv.normalizeEventList({ events: [{ ...cg, id: 'EV01', cgDesc: cg.desc }] }, memory);
    const before = structuredClone(previousSession);
    const session = adv.projectAdvProgress({ previousSession, memoryBank: memory, operation: { kind: 'adv-bulk', eventIds: ['EV01'] },
        segments: [segment('adv-bulk:scope', '{"items":[{"eventId":"EV01","narrator":"char_first_person","sections":[{"type":"past","paragraphs":["我留下了已经写完的第一段。","第二段还没闭合') ] });
    assert.ok(session?.events[0].adv?.paragraphs?.length, 'known narrative section must be readable');
    assert.deepEqual(previousSession, before);
    assert.ok(session.events[0].progressPending.length);
    const wrong = adv.projectAdvProgress({ previousSession, memoryBank: memory, operation: { kind: 'adv-single', eventId: 'missing' },
        segments: [segment('adv:missing', { narrator: 'char_first_person', sections: [] })] });
    assert.equal(wrong, null);
});

test('all five existing readers show saved partial content through their normal pages', async t => {
    const f = await fixture(t);
    const context = f.ctx, bank = f.liveBank;
    const rows = [
        ['album', album.projectAlbumProgress({ segments: [segment('x:index', index)], memoryBank: bank }), renderAlbum],
        ['butterfly', butterfly.projectButterflyProgress({ segments: [segment('x:slot:0', { node: main })], memoryBank: bank, context }), renderButterfly],
        ['ending', ending.projectEndingProgress({ segments: [segment('x:outline', outline)], memoryBank: bank }), renderEnding],
        ['pastLives', past.projectPastLivesProgress({ segments: [segment('x:past-lives-plan', plan)], memoryBank: bank, context }), renderPastLives],
        ['adv', adv.projectAdvProgress({ segments: [segment('x:index', { events: [{ ...cg, id: 'EV01', cgDesc: cg.desc }] })], memoryBank: bank }), renderAdvMode],
    ];
    for (const [mode, value, render] of rows) {
        assert.ok(value, mode); state.activeMode = mode; state.activeSession = mark({ ...value, chatId: bank.chatId, archiveRevision: bank.archiveRevision });
        state.activeArchiveSnapshot = { chatId: bank.chatId, memory: bank, cache: {}, backupOnly: true }; state.activeArchiveReadOnly = true;
        render(); assert.match(f.body.innerHTML, /未完成/, mode); assert.doesNotMatch(f.body.innerHTML, /暂不可读取/, mode);
        if (mode === 'butterfly') assert.match(f.body.innerHTML, /我记得庭院的花/);
        if (mode === 'album') { renderSharedMemory(); assert.match(f.body.innerHTML, /对白尚未生成/); }
    }
    assert.equal(f.requests.length, 0, 'reading performs no generation request');
});

test('past-lives reader uses original source names and memory IDs after a result is applied to a newer archive', async t => {
    const f = await fixture(t);
    const sourceMemory = { ...structuredClone(f.liveBank), archiveRevision: 'old-source-revision', characterName: '旧名字' };
    const session = mark(past.projectPastLivesProgress({ segments: [segment('x:past-lives-plan', plan)], memoryBank: sourceMemory, context: f.ctx }));
    session.archiveRevision = f.liveBank.archiveRevision;
    session.generationSources = { pastLives: { sourceMemory } };
    state.activeMode = 'pastLives'; state.activeSession = session;
    state.activeArchiveSnapshot = { chatId: f.liveBank.chatId, memory: f.liveBank, cache: {}, backupOnly: true };
    state.activeArchiveReadOnly = true;
    renderPastLives();
    assert.match(f.body.innerHTML, /旧名字/); assert.match(f.body.innerHTML, /旧花笺/);
    assert.doesNotMatch(f.body.innerHTML, /暂不可读取|不一致/);
    assert.equal(session.archiveRevision, f.liveBank.archiveRevision, 'reading never rewrites canonical target identity');
    assert.equal(f.requests.length, 0);
});

test('ADV real bulk truncation durably retains closed paragraphs while its canonical event stays unchanged', async t => {
    const f = await fixture(t);
    f.setResponse({ title: '事件', events: [{ ...cg, id: 'EV01', cgDesc: cg.desc }] });
    const original = await client.generateMode('adv', { background: true });
    assert.ok(original, JSON.stringify(f.diagnostics));
    state.activeMode = 'adv'; state.activeSession = structuredClone(original);
    const before = structuredClone((await f.persisted()).adv);
    const send = f.ctx.ConnectionManagerRequestService.sendRequest;
    let calls = 0;
    f.setResponse(() => { if (++calls > 1) throw Object.assign(new Error('Continuation unavailable'), { code: 'RMT_MANUAL_HTTP', status: 400 }); return {}; });
    f.ctx.ConnectionManagerRequestService.sendRequest = async (profileId, messages, outputTokens, options, overridePayload) => {
        const profile = f.ctx.extensionSettings.connectionManager.profiles[0];
        const payload = { secret_id: profile['secret-id'], model: profile.model, ...overridePayload };
        assert.equal(payload.secret_id, 'fixture-only');
        return { ...await send(profileId, messages, outputTokens, options, overridePayload),
            content: '{"items":[{"eventId":"EV01","narrator":"char_first_person","sections":[{"type":"past","paragraphs":["我已经写下这一段庭院里的回忆。","还没完成' };
    };
    await adv.generateAllAdvForSession();
    const stored = await f.persisted();
    assert.deepEqual(stored.adv.events, before.events, 'incomplete text never replaces the old canonical event');
    const results = cache.listGenerationTaskResults(f.ctx, stored).filter(item => item.mode === 'adv');
    assert.ok(results.length, JSON.stringify({ calls, diagnostics: f.diagnostics, notices: f.notices,
        draft: cache.loadGenerationRecovery('adv', f.ctx, stored), requests: f.requests.length }));
    const saved = await cache.readGenerationTaskResult(f.ctx, results.at(-1).draftId, { cache: stored });
    assert.deepEqual(saved.session.events[0].adv.paragraphs, ['我已经写下这一段庭院里的回忆。']);
    assert.equal(saved.session.readableProgress.complete, false);
    assert.equal(saved.sourceMemory.archiveRevision, f.liveBank.archiveRevision);
});

for (const [mode, firstReply] of [['album', index], ['butterfly', { node: main }], ['ending', outline], ['pastLives', plan]]) {
    test(`${mode}: real generation saves its successful first stage when a later provider request fails`, async t => {
        const f = await fixture(t); const originalCache = structuredClone(f.liveCache);
        let calls = 0;
        f.setResponse(() => { if (++calls === 1) return firstReply; throw Object.assign(new Error('Later stage unavailable'), { code: 'RMT_MANUAL_HTTP', status: 400 }); });
        assert.equal(await client.generateMode(mode, { background: true }), null);
        const stored = await f.persisted();
        assert.deepEqual(stored.phone, originalCache.phone); assert.deepEqual(stored.cabinet, originalCache.cabinet);
        assert.equal(stored[mode], undefined, 'partial result does not masquerade as a full canonical work');
        const results = cache.listGenerationTaskResults(f.ctx, stored).filter(item => item.mode === mode);
        assert.equal(results.length, 1, JSON.stringify(f.diagnostics));
        const saved = await cache.readGenerationTaskResult(f.ctx, results[0].draftId, { cache: stored });
        assert.equal(saved.session.readableProgress.complete, false);
        assert.equal(saved.sourceMemory.archiveRevision, f.liveBank.archiveRevision);
        const journal = cache.loadGenerationRecovery(mode, f.ctx, stored);
        assert.ok(journal.segments.some(item => item.state === 'complete'));
        const projected = await projectGenerationProgress(JSON.parse(JSON.stringify(journal)), { context: f.ctx });
        assert.ok(projected, 'a persisted journal can project again after reload');
        assert.equal(projected.readableProgress.complete, false);
        assert.ok(calls >= 2);
    });
}

// Append to the already approved tests/partialGenerationProgress.test.mjs.
// Reuses its test/assert/fixture/client/cache/state/projectGenerationProgress imports.
import * as roomMode from '../src/modes/room.js';
import * as contextApi from '../src/core/context.js';
import * as recovery from '../src/generation/recovery.js';
const storagePartialProse = '我把书放回窗边，院里的新花还沾着雨水。等天气晴些，一起去小店挑个花盆吧。你可以慢慢看，我在门口等你。';
const storagePartialScript = count => Array.from({ length: count }, (_, index) => ({ speaker: 'char', text: `${index + 1}。${storagePartialProse}` }));
const storagePartialDrama = (kind, prefix = 'NEW') => ({ id: `${prefix}_${kind}`, kind, title: `${prefix}_${kind}`, setting: '未来普通一天', script: storagePartialScript(10) });
const storagePartialScenario = season => ({ id: `NEW_SCENE_${season}`, season, title: `NEW_SCENE_${season}`, setting: '未来普通一天', script: storagePartialScript(10) });
function storagePartialHeartBase(f) {
    return { kind: 'heart', chatId: f.liveBank.chatId, archiveRevision: f.liveBank.archiveRevision,
        relationshipSummary: '旧关系原文。', greetings: { morning: ['旧台词。'] },
        voiceDramas: [storagePartialDrama('spring', 'OLD')], scenarioDramas: [{ ...storagePartialScenario('spring'), id: 'OLD_SCENE', title: '原来保存的春日场景' }],
        dailyStrips: [{ id: 'OLD_STRIP', title: '旧一格', panels: [{ action: '旧动作。' }], cgImage: { url: '/old-image.png' } }], fireflyVoices: [] };
}
function progressJournal(mode, pageId, segments, extra = {}) {
    return { identity: { mode }, pageId, draftId: `progress-${pageId}`, createdAt: 1234, operation: {}, segments, ...extra };
}

for (const withFormal of [false, true]) test(`partial management delete uses the displayed draft and survives completion (formal=${withFormal})`, async t => {
    const f = await fixture(t);
    const original = { ...album.normalizeAlbumIndex(index, f.liveBank), kind: 'album',
        chatId: f.liveBank.chatId, archiveRevision: f.liveBank.archiveRevision, selectedId: 'CG01', category: '全部', page: 1 };
    if (withFormal) await cache.commitSession('album', { ...structuredClone(original),
        entries: original.entries.map(item => ({ ...item, title: '旧相簿春游' })) }, f.liveBank.chatId);
    const formalBefore = structuredClone((await f.persisted()).album);
    const origin = contextApi.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision);
    await client.beginModeRecovery('album', f.ctx, f.liveBank, origin, { existing: null, pageId: 'album', operation: { kind: 'mode', mode: 'album' } });
    const partial = { ...original, entries: original.entries.map(item => ({ ...item, title: '新相簿生日' })),
        readableProgress: { version: 1, complete: false, draftId: origin.generationRecoveryDraftId, pageId: 'album' } };
    await cache.saveGenerationTaskResult(f.ctx, 'album', partial, origin, { complete: false, memoryBank: f.liveBank, sourceMemory: f.liveBank });
    recovery.detachGenerationRecovery(origin);
    state.activeMode = 'album'; state.activeSession = structuredClone(partial);
    const noticeCount = f.notices.length;
    overlay.handleOverlayClick({ target: { closest: selector => selector === '[data-rmt-action]' ? { dataset: {
        rmtAction: 'manage-delete-target', rmtManageType: 'album-entry', rmtManageId: 'CG01', rmtManageParent: '',
    } } : null } });
    for (let attempt = 0; attempt < 200 && f.notices.length === noticeCount; attempt++) await new Promise(resolve => setTimeout(resolve, 5));
    assert.equal(f.notices.at(-1)?.kind, 'success', JSON.stringify(f.notices));
    assert.deepEqual((await f.persisted()).album, formalBefore, 'deleting the new birthday never edits the old spring trip');
    assert.equal((await cache.readGenerationTaskResult(f.ctx, origin.generationRecoveryDraftId)).session.entries.length, 0);
    const next = { ...structuredClone(partial), entries: [...partial.entries, { ...partial.entries[0], id: 'CG02', title: '后续生成的第二张' }] };
    await cache.saveGenerationTaskResult(f.ctx, 'album', next, origin, { complete: false, memoryBank: f.liveBank, sourceMemory: f.liveBank });
    assert.deepEqual((await cache.readGenerationTaskResult(f.ctx, origin.generationRecoveryDraftId)).session.entries.map(item => item.id), ['CG02']);
    const complete = structuredClone(next); delete complete.readableProgress;
    assert.ok(await cache.commitSession('album', complete, f.liveBank.chatId, origin));
    state.runtimeSessionCache.clear(); await cache.ensureCacheHydrated(f.ctx);
    assert.deepEqual(cache.loadSession('album', { context: f.ctx }).entries.map(item => item.id), ['CG02']);
    assert.equal(f.requests.length, 0);
});

test('writable historical archive refreshes its saved partial page without touching the live archive', async t => {
    const f = await fixture(t), before = JSON.stringify(f.ctx.chatMetadata);
    const partial = { ...album.normalizeAlbumIndex({ ...index, entries: [{ ...cg, title: '历史档案已完成画面' }] }, f.otherBank),
        kind: 'album', chatId: f.otherBank.chatId, archiveRevision: f.otherBank.archiveRevision, selectedId: 'CG01', category: '全部', page: 1,
        readableProgress: { version: 1, complete: false, draftId: 'history-partial', pageId: 'album' } };
    const target = { ...f.bEntry, memory: structuredClone(f.otherBank), cache: { ...structuredClone(f.otherCache),
        [cache.GENERATION_DRAFTS_CACHE_KEY]: { version: 1, records: { 'history-partial': { status: 'open', result: {
            mode: 'album', pageId: 'album', createdAt: 1, sourceMemory: structuredClone(f.otherBank), session: partial,
        } } } } } };
    const snapshot = { ...f.bEntry, memory: structuredClone(f.otherBank), cache: structuredClone(f.otherCache) };
    state.activeArchiveSnapshot = snapshot; state.activeArchiveReadOnly = false;
    state.activeMode = 'album'; state.activeSession = null;
    assert.equal(await overlay.refreshPartialGenerationView('album', f.ctx, { draftId: 'history-partial', pageId: 'album', archiveTarget: target }), true);
    assert.match(f.body.innerHTML, /历史档案已完成画面/);
    assert.equal(state.activeSession.chatId, f.otherBank.chatId);
    assert.equal(JSON.stringify(f.ctx.chatMetadata), before);
    assert.equal(f.requests.length, 0);
});

test('HEART progress reads closed seasonal items and language strings without accepting an unfinished sibling', async t => {
    const f = await fixture(t), previous = storagePartialHeartBase(f);
    const journal = progressJournal('heart', 'spring', [
        { slot: 'spring:voice', state: 'complete', rawJson: JSON.stringify({ voiceDramas: [storagePartialDrama('spring')] }) },
        { slot: 'spring:scenario', state: 'truncated', partial: `{"scenarioDramas":[${JSON.stringify(storagePartialScenario('spring'))},{"id":"unfinished","script":[` },
    ]);
    const result = await projectGenerationProgress(journal, { memoryBank: f.liveBank, previousSession: previous });
    assert.equal(result.voiceDramas.length, previous.voiceDramas.length + 1);
    assert.equal(result.scenarioDramas.length, previous.scenarioDramas.length + 1);
    assert.deepEqual(result.dailyStrips, previous.dailyStrips);
    assert.equal(result.readableProgress.complete, false);
    assert.equal(JSON.stringify(result).includes('unfinished'), false);
    const languageResult = await projectGenerationProgress(progressJournal('heart', 'language', [
        { slot: 'language', state: 'truncated', partial: '{"greetings":{"morning":["写好的第一句。","写好的第二句。","还没写完' },
    ]), { memoryBank: f.liveBank });
    assert.deepEqual(languageResult.greetings.morning, ['写好的第一句。', '写好的第二句。']);
    assert.equal(languageResult.relationshipSummary, '', 'a summary is not invented to pass full acceptance');
    assert.equal(f.requests.length, 0);
});

test('phone progress preserves two validated entries inside an unfinished App container', async t => {
    const f = await fixture(t);
    const plan = { deviceKind: 'phone', apps: [{ id: 'A1', label: '备忘', kind: 'notes', entries: [{ id: 'E1' }, { id: 'E2' }, { id: 'E3' }] }] };
    const entry = id => ({ id, title: `便笺${id}`, preview: '明天整理书架。', detail: '准备把正在看的几本书放到窗边。', basis: '推演', sourceMemoryIds: [], sourceMemoryAnchor: '' });
    const result = await projectGenerationProgress(progressJournal('phone', 'phone', [
        { slot: 'phone:plan', state: 'complete', rawJson: JSON.stringify(plan) },
        { slot: 'phone:app:A1:key', state: 'truncated', partial: `{"app":{"id":"A1","entries":[${JSON.stringify(entry('E1'))},${JSON.stringify(entry('E2'))},{"id":"E3","detail":"半` },
    ]), { memoryBank: f.liveBank });
    assert.deepEqual(result.apps[0].entries.map(item => item.id), ['E1', 'E2']);
    assert.equal(result.readableProgress.complete, false);
    assert.equal(f.requests.length, 0);
});

test('room progress exposes closed objects from an unfinished space without inventing resident dialogue', async t => {
    const f = await fixture(t);
    const object = id => ({ id, label: id === 'O1' ? '书架' : '木桌', description: '常用的木制家具。', line: '东西放在这里。', basis: '设定' });
    const result = await projectGenerationProgress(progressJournal('room', 'room', [
        { slot: 'room', state: 'truncated', partial: `{"spaces":[{"id":"SP01","label":"书房","objects":[${JSON.stringify(object('O1'))},${JSON.stringify(object('O2'))},{"id":"O3","description":"还` },
    ]), { memoryBank: f.liveBank });
    assert.deepEqual(result.spaces[0].objects.map(item => item.id), ['O1', 'O2']);
    assert.deepEqual(result.dayparts, {});
    assert.equal(roomMode.roomCurrentSlot(result), null, 'unfinished rooms do not get synthesized daily activity');
    assert.equal(result.readableProgress.complete, false);
    assert.equal(f.requests.length, 0);
});

for (const withFormal of [false, true]) test(`room life uses the visible partial blueprint and durably saves independently (formal=${withFormal})`, async t => {
    const f = await fixture(t);
    const room = { kind: 'room', chatId: f.liveBank.chatId, archiveRevision: f.liveBank.archiveRevision,
        homeName: 'PARTIAL_ROOM_MARK', homeSummary: '正在整理的书房。', dayparts: {},
        spaces: [{ id: 'SP01', label: 'PARTIAL_SPACE_MARK', spaceType: '书房', atmosphere: '窗边有书架。',
            objects: [{ id: 'O1', label: '阅读桌', description: '书桌摆在窗边。', line: '书在桌上。', basis: '设定', sourceMemoryIds: [], sourceMemoryAnchor: '' }] }] };
    if (withFormal) await cache.commitSession('room', { ...structuredClone(room), homeName: 'FORMAL_ROOM_MARK',
        spaces: [{ ...structuredClone(room.spaces[0]), label: 'FORMAL_SPACE_MARK' }] }, f.liveBank.chatId);
    const prior = (await f.persisted()).room;
    const origin = contextApi.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision);
    await client.beginModeRecovery('room', f.ctx, f.liveBank, origin,
        { existing: null, pageId: 'room', operation: { kind: 'mode', mode: 'room' }, contentInputs: { previousSession: prior || null } });
    const partial = { ...room, readableProgress: { version: 1, complete: false, draftId: origin.generationRecoveryDraftId, pageId: 'room' } };
    await cache.saveGenerationTaskResult(f.ctx, 'room', partial, origin, { complete: false, memoryBank: f.liveBank, sourceMemory: f.liveBank });
    recovery.detachGenerationRecovery(origin);
    state.activeMode = 'room'; state.activeSession = partial; f.host.hidden = true;
    f.setResponse({ beats: [{ time: '06:40', spaceId: 'SP01', focusObjectId: 'O1', activity: '整理桌上的书。', line: '这本书放在窗边。',
        ambient: '晨光照在书桌上。', trace: '桌上摊着一本书。', temporaryObjects: [], sourceMemoryIds: [], sourceMemoryAnchor: '' }] });
    const result = await roomMode.ensureRoomLifePlan({ context: f.ctx, roomSession: partial, force: true, quiet: true });
    assert.equal(result.status, 'awaiting-choice'); assert.equal(f.requests.length, 1);
    const sent = JSON.stringify(f.requests[0]);
    assert.ok(sent.includes('PARTIAL_ROOM_MARK') && sent.includes('PARTIAL_SPACE_MARK'));
    assert.equal(sent.includes('FORMAL_SPACE_MARK'), false, 'the visible unfinished room is the actual model input');
    const savedRoom = (await f.persisted()).room;
    // Task admission reserves the existing write fence. All authored content,
    // selectors and fields must still be identical; only that lock may advance.
    const roomContent = value => value && Object.fromEntries(Object.entries(value).filter(([key]) => key !== '_rmtModeWriteFence'));
    assert.deepEqual(roomContent(savedRoom), roomContent(prior), 'life completion cannot silently complete or overwrite a room');
    state.runtimeSessionCache.clear(); await cache.ensureCacheHydrated(f.ctx);
    const saved = await cache.readGenerationTaskResult(f.ctx, result.draftId);
    assert.equal(saved.session.lifePlan.beats.length, 1);
    assert.equal(saved.session.spaces[0].label, 'PARTIAL_SPACE_MARK');
    assert.equal(saved.session.readableProgress.complete, false, 'the source room body remains unfinished');
    assert.deepEqual(saved.sourceMemory, f.liveBank);
    assert.equal(cache.loadGenerationRecovery('room', f.ctx, null, { draftId: origin.generationRecoveryDraftId }).pageId, 'room');
});

test('an explicitly opened story draft refreshes in place even when its background task does not own the original reader', async t => {
    const f = await fixture(t), origin = contextApi.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision);
    await client.beginModeRecovery('timeEcho', f.ctx, f.liveBank, origin, { existing: null });
    t.after(() => recovery.detachGenerationRecovery(origin));
    const draftId = origin.generationRecoveryDraftId;
    const received = count => '{"title":"正在写下的回声","opening":"林舟拿起了旧听筒。","medium":{"kind":"phone","label":"旧电话"},'
        + '"ends":[{"role":"char","time":"今夜"},{"role":"user","time":"明夜"}],"lines":['
        + [{ speaker: 'a', text: '你听见窗外的风了吗？' }, { speaker: 'b', text: '听见了，窗边的灯还亮着。' }]
            .slice(0, count).map(row => JSON.stringify(row)).join(',') + ',{"speaker":"a","text":"尚未闭合';
    const publish = async count => {
        const session = await projectGenerationProgress(progressJournal('timeEcho', 'timeEcho', [
            { slot: 'timeEcho', state: 'truncated', partial: received(count) },
        ], { draftId }), { context: f.ctx, memoryBank: f.liveBank });
        assert.ok(session?.readableProgress);
        await cache.saveGenerationTaskResult(f.ctx, 'timeEcho', session, origin,
            { draftId, pageId: 'timeEcho', complete: false, memoryBank: f.liveBank, sourceMemory: f.liveBank });
    };
    await f.open('timeEcho');
    const originalEmpty = state.activeSession;
    await publish(1);
    assert.equal(await overlay.refreshPartialGenerationView('timeEcho', f.ctx,
        { draftId, pageId: 'timeEcho', readerStillCurrent: () => false }), false);
    assert.equal(state.activeSession, originalEmpty, 'background progress does not replace an unrelated empty reader');
    assert.equal(state.activeSession.episodes.length, 0);

    // Opening is a user action: it opts this exact saved draft into progress.
    await f.open('timeEcho');
    const opened = state.activeSession;
    assert.equal(opened.readableProgress.draftId, draftId);
    Object.assign(opened, { selectedId: 'TS01', view: 'story', reading: true, dialogueIndex: 0 });
    overlay.renderActive(); f.body.scrollTop = 51;
    const firstPassage = f.body.innerHTML;
    assert.equal(await overlay.refreshPartialGenerationView('timeEcho', f.ctx,
        { draftId: 'another-draft', pageId: 'timeEcho', readerStillCurrent: () => false }), false);
    assert.equal(f.body.innerHTML, firstPassage, 'another task cannot take over the chosen draft reader');
    await publish(2);
    assert.equal(await overlay.refreshPartialGenerationView('timeEcho', f.ctx,
        { draftId, pageId: 'timeEcho', readerStillCurrent: () => false }), true);
    assert.equal(state.activeSession, opened, 'progress retains the selected reader object');
    assert.equal(opened.episodes[0].lines.length, 2);
    assert.equal(opened.selectedId, 'TS01'); assert.equal(opened.reading, true); assert.equal(opened.dialogueIndex, 0);
    assert.equal(f.body.scrollTop, 51);
    assert.match(f.body.innerHTML, /你听见窗外的风了吗/);
    assert.doesNotMatch(f.body.innerHTML, /尚未闭合/);
    assert.equal((await f.persisted()).timeEcho, undefined, 'reading progress cannot promote an incomplete story');
    assert.equal(f.requests.length, 0, 'opening and refreshing already received content never requests generation');
});
