import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './helpers/r847Host.mjs';
import * as cache from '../src/core/cache.js';
import * as C from '../src/core/constants.js';
import * as contextApi from '../src/core/context.js';
import * as backup from '../src/archive/backupStore.js';
import * as participants from '../src/core/participants.js';
import * as generation from '../src/generation/client.js';
import * as recovery from '../src/generation/recovery.js';
import * as library from '../src/archive/library.js';
import * as inbox from '../src/modes/inbox.js';
import * as song from '../src/modes/themeSong.js';
import * as songContract from '../src/core/themeSongContract.js';
import * as archiveDrafts from '../src/archive/importRecovery.js';
import * as repository from '../src/archive/repository.js';
import { localFixture } from './helpers/r8425LocalHost.mjs';
import { state } from '../src/core/state.js';
import * as roomMode from '../src/modes/room.js';
import * as recoveryView from '../src/ui/recoveryView.js';

const KEY = participants.PARTICIPANTS_KEY;
const clone = value => structuredClone(value);
const roster = (id = 'person-a', name = '同名人物') => ({
    version: 1, cardType: 'multi', revision: '',
    people: [{ id, name, sourceRefs: [{ world: 'A-book', uid: id, title: name, content: `${id} 的人物资料`, keys: [name] }] }],
    selectedIds: [id],
});
const archiveOptions = bank => ({ expectedPreviousArchiveState: { present: true, revision: bank.archiveRevision } });

test('participant save is canonical, isolated from card/source identity, and survives compressed reload', async t => {
    const f = await fixture(t);
    const before = clone(f.ctx.chatMetadata[C.MEMORY_KEY]);
    const sourceSelection = clone(f.ctx.chatMetadata[C.MEMORY_WORLD_INFO_SETTINGS_KEY]);
    const priorModes = await f.persisted();
    const saved = await cache.commitParticipantRoster(f.ctx, roster());
    assert.ok(saved.revision);
    assert.equal(saved.people[0].name, '同名人物');
    assert.deepEqual(f.ctx.chatMetadata[C.MEMORY_KEY], before);
    assert.deepEqual(f.ctx.chatMetadata[C.MEMORY_WORLD_INFO_SETTINGS_KEY], sourceSelection);
    const disk = await f.persisted();
    assert.deepEqual(disk[KEY], saved);
    assert.deepEqual(disk.phone, priorModes.phone);
    assert.deepEqual(disk.cabinet, priorModes.cabinet);
    state.runtimeSessionCache.clear();
    await cache.ensureCacheHydrated(f.ctx);
    assert.deepEqual(cache.readParticipantRoster(f.ctx), saved);
    saved.people[0].name = 'caller mutation';
    assert.equal(cache.readParticipantRoster(f.ctx).people[0].name, '同名人物');
    assert.equal(f.requests.length, 0);
});

test('concurrent participant edits compare opaque roster revisions instead of names or clocks', async t => {
    const f = await fixture(t);
    const a = await cache.commitParticipantRoster(f.ctx, roster());
    const results = await Promise.allSettled([
        cache.commitParticipantRoster(f.ctx, roster('person-b'), { expectedRevision: a.revision }),
        cache.commitParticipantRoster(f.ctx, roster('person-c'), { expectedRevision: a.revision }),
    ]);
    assert.equal(results.filter(item => item.status === 'fulfilled').length, 1);
    const rejected = results.find(item => item.status === 'rejected');
    assert.equal(rejected.reason.code, 'RMT_PARTICIPANTS_CAS_CONFLICT');
    const winner = results.find(item => item.status === 'fulfilled').value;
    assert.notEqual(winner.revision, a.revision);
    assert.deepEqual((await f.persisted())[KEY], winner);
    assert.deepEqual(cache.readParticipantRoster(f.ctx), winner);
});

test('late cache compression with a newer content clock cannot roll back the canonical roster', async t => {
    const f = await fixture(t);
    const a = await cache.commitParticipantRoster(f.ctx, roster());
    const staleCache = clone(cache.getCache(f.ctx));
    const b = await cache.commitParticipantRoster(f.ctx, roster('person-b'), { expectedRevision: a.revision });
    staleCache.cabinet.items.push({ id: 'late-content', text: '生成开始时的旧人物内容' });
    cache.stampCacheCommit(staleCache, cache.cacheScopeFromContext(f.ctx));
    assert.equal(await cache.persistCompressedCacheNow(f.ctx, staleCache), true);
    const disk = await f.persisted();
    assert.deepEqual(disk[KEY], b);
    assert.equal(disk.cabinet.items.at(-1).id, 'late-content');
    assert.deepEqual(cache.readParticipantRoster(f.ctx), b);
});

test('restoring a newer-clock host mirror preserves the latest canonical participant choice', async t => {
    const f = await fixture(t);
    const a = await cache.commitParticipantRoster(f.ctx, roster());
    const oldMirror = clone(cache.getCache(f.ctx));
    const b = await cache.commitParticipantRoster(f.ctx, roster('person-b'), { expectedRevision: a.revision });
    cache.stampCacheCommit(oldMirror, cache.cacheScopeFromContext(f.ctx));
    cache.rememberRuntimeSessionCache(cache.cacheScopeFromContext(f.ctx), oldMirror);
    await cache.ensureCurrentArchiveBackup(f.ctx);
    assert.deepEqual((await f.persisted())[KEY], b);
    assert.deepEqual(cache.readParticipantRoster(f.ctx), b);
});

test('recovery resumes its frozen participants without replacing the later current roster', async t => {
    const f = await fixture(t);
    const a = await cache.commitParticipantRoster(f.ctx, roster());
    const bank = clone(f.ctx.chatMetadata[C.MEMORY_KEY]);
    const origin = contextApi.captureTaskOrigin(f.ctx, bank.archiveRevision);
    const operation = { kind: 'mode', mode: C.MODE.ROOM };
    await generation.beginModeRecovery(C.MODE.ROOM, f.ctx, bank, origin, { operation });
    const frozen = await recovery.frozenGenerationInput(origin, 'participants:room', () => participants.selectedParticipantSnapshot(a));
    const b = await cache.commitParticipantRoster(f.ctx, roster('person-b'), { expectedRevision: a.revision });
    recovery.detachGenerationRecovery(origin);
    const loaded = cache.loadGenerationRecovery(C.MODE.ROOM, f.ctx);
    assert.ok(loaded);
    const resumed = contextApi.captureTaskOrigin(f.ctx, bank.archiveRevision);
    t.after(() => recovery.detachGenerationRecovery(resumed));
    await generation.beginModeRecovery(C.MODE.ROOM, f.ctx, bank, resumed, { operation: loaded.operation, existing: loaded });
    const actual = await recovery.frozenGenerationInput(resumed, 'participants:room', () => { throw new Error('must use frozen participants'); });
    assert.deepEqual(actual, frozen);
    assert.deepEqual((await f.persisted())[KEY], b);
    assert.equal(f.requests.length, 0);
});

test('an archive with only a roster retains it across incremental evidence revisions', async t => {
    const f = await fixture(t);
    const bank = clone(f.ctx.chatMetadata[C.MEMORY_KEY]);
    const empty = { chatId: bank.chatId, archiveRevision: bank.archiveRevision };
    await backup.replaceArchiveBackup(f.aEntry, bank, empty, { present: true, revision: bank.archiveRevision });
    state.runtimeSessionCache.clear();
    f.ctx.chatMetadata[C.CACHE_KEY] = clone(empty);
    const saved = await cache.commitParticipantRoster(f.ctx, roster());
    const next = { ...bank, archiveRevision: 'participants-increment', updatedAt: 2 };
    await cache.saveImportedMemory(f.ctx, next, next.chatId, { ...archiveOptions(bank), preserveDerivedCache: true });
    const disk = await f.persisted();
    assert.deepEqual(disk[KEY], saved);
    assert.equal(disk.archiveRevision, next.archiveRevision);
    assert.equal(disk.room, undefined);
    assert.deepEqual(cache.readParticipantRoster(f.ctx), saved);
});

test('full rebuild clears generated modes while preserving the independently saved roster', async t => {
    const f = await fixture(t);
    const saved = await cache.commitParticipantRoster(f.ctx, roster());
    const bank = clone(f.ctx.chatMetadata[C.MEMORY_KEY]);
    const next = { ...bank, archiveRevision: 'participants-full-rebuild', updatedAt: 2 };
    await cache.saveImportedMemory(f.ctx, next, next.chatId, archiveOptions(bank));
    const disk = await f.persisted();
    assert.deepEqual(disk[KEY], saved);
    assert.equal(disk.phone, undefined);
    assert.equal(disk.cabinet, undefined);
});

test('first archive uses latest same-chat draft B while retaining request A as its immutable seed', async t => {
    const f = await fixture(t);
    delete f.ctx.chatMetadata[C.MEMORY_KEY];
    delete f.ctx.chatMetadata[C.CACHE_KEY];
    f.records.delete(f.aEntry.entryId);
    state.runtimeSessionCache.clear();
    const a = await cache.commitParticipantRoster(f.ctx, roster());
    const requestBank = { ...clone(f.liveBank), archiveRevision: 'participants-first-archive', [KEY]: clone(a) };
    const b = await cache.commitParticipantRoster(f.ctx, roster('person-b'), { expectedRevision: a.revision });
    assert.equal(f.records.has(f.aEntry.entryId), false, 'staging a picker is not a formal archive write');
    await cache.saveImportedMemory(f.ctx, requestBank, requestBank.chatId, { expectedPreviousArchiveState: { present: false, revision: '' } });
    assert.deepEqual((await f.persisted())[KEY], b);
    assert.deepEqual(cache.readParticipantRoster(f.ctx), b);
    assert.deepEqual(f.ctx.chatMetadata[C.MEMORY_KEY][KEY], a);
    assert.equal(f.requests.length, 0);
});

test('first archive restored from a frozen recipe seeds participants without a page draft', async t => {
    const f = await fixture(t);
    delete f.ctx.chatMetadata[C.MEMORY_KEY];
    delete f.ctx.chatMetadata[C.CACHE_KEY];
    f.records.delete(f.aEntry.entryId);
    state.runtimeSessionCache.clear();
    const frozen = { ...roster(), revision: 'frozen-first-selection' };
    const bank = { ...clone(f.liveBank), archiveRevision: 'resumed-first-archive', [KEY]: frozen };
    await cache.saveImportedMemory(f.ctx, bank, bank.chatId, { expectedPreviousArchiveState: { present: false, revision: '' } });
    assert.deepEqual((await f.persisted())[KEY], frozen);
    assert.deepEqual(cache.readParticipantRoster(f.ctx), frozen);
});

test('legacy single-card writes add no participant fields and retain the original full-rebuild clearing behavior', async t => {
    const f = await fixture(t);
    assert.equal(cache.readParticipantRoster(f.ctx), null);
    const bank = clone(f.ctx.chatMetadata[C.MEMORY_KEY]);
    const next = { ...bank, archiveRevision: 'single-unchanged-path', updatedAt: 2 };
    await cache.saveImportedMemory(f.ctx, next, next.chatId, archiveOptions(bank));
    assert.equal(f.ctx.chatMetadata[C.MEMORY_KEY][KEY], undefined);
    assert.equal(f.ctx.chatMetadata[C.CACHE_KEY], undefined);
    assert.equal(f.ctx.chatMetadata[cache.PARTICIPANT_DRAFT_METADATA_KEY], undefined);
    assert.equal((await backup.readArchiveBackup(f.aEntry)).cache, null);
    assert.equal(f.requests.length, 0);
});

test('draft queue failure restores the previous choice and never claims a canonical save', async t => {
    const f = await fixture(t);
    delete f.ctx.chatMetadata[C.MEMORY_KEY];
    const a = await cache.commitParticipantRoster(f.ctx, roster());
    const before = clone(f.ctx.chatMetadata[cache.PARTICIPANT_DRAFT_METADATA_KEY]);
    f.ctx.saveMetadataDebounced = async () => { throw new Error('fixture metadata queue failure'); };
    await assert.rejects(cache.commitParticipantRoster(f.ctx, roster('person-b'), { expectedRevision: a.revision }), /fixture metadata queue failure/);
    assert.deepEqual(f.ctx.chatMetadata[cache.PARTICIPANT_DRAFT_METADATA_KEY], before);
    assert.deepEqual(cache.readParticipantRoster(f.ctx), a);
});

test('failed canonical participant writes preserve the old roster and generated content', async t => {
    const f = await fixture(t);
    const a = await cache.commitParticipantRoster(f.ctx, roster());
    const before = await f.persisted();
    f.failCompletedSave(C.MODE.PHONE, () => true);
    await assert.rejects(cache.commitParticipantRoster(f.ctx, roster('person-b'), { expectedRevision: a.revision }));
    assert.deepEqual(await f.persisted(), before);
    assert.deepEqual(cache.readParticipantRoster(f.ctx), a);
    assert.equal(f.requests.length, 0);
});

test('switching chat before a queued selection commits does not write into the new chat', async t => {
    const f = await fixture(t);
    const before = await f.persisted();
    const pending = cache.commitParticipantRoster(f.ctx, roster());
    f.ctx.chatId = 'a-different-chat';
    await assert.rejects(pending, error => error.code === 'RMT_RECOVERY_ORIGIN_CHANGED');
    assert.deepEqual(await f.persisted(), before);
    assert.equal(f.ctx.chatMetadata[cache.PARTICIPANT_DRAFT_METADATA_KEY], undefined);
});

test('saved versions survive compressed reload, retain old roster, and never recursively contain history', async t => {
    const f = await fixture(t);
    const a = await cache.commitParticipantRoster(f.ctx, roster());
    const old = await f.persisted();
    const memory = clone(f.ctx.chatMetadata[C.MEMORY_KEY]);
    const first = await cache.saveArchiveVersion(f.ctx, { selectedPages: ['phone'], expectedRosterRevision: a.revision });
    const b = await cache.commitParticipantRoster(f.ctx, roster('person-b'), { expectedRevision: a.revision });
    const second = await cache.saveArchiveVersion(f.ctx, { selectedPages: ['cabinet'], expectedRosterRevision: b.revision });
    state.runtimeSessionCache.clear();
    await cache.ensureCacheHydrated(f.ctx);
    const records = await cache.listArchiveVersions(f.ctx);
    assert.deepEqual(records.map(item => item.versionId), [first.versionId, second.versionId]);
    const saved = await cache.readArchiveVersion(f.ctx, first.versionId);
    assert.deepEqual(saved.memory, memory);
    assert.deepEqual(saved.cache.phone, old.phone);
    assert.deepEqual(saved.roster, a);
    assert.equal(saved.cache[cache.ARCHIVE_VERSIONS_CACHE_KEY], undefined);
    assert.equal((await cache.readArchiveVersion(f.ctx, second.versionId)).cache[cache.ARCHIVE_VERSIONS_CACHE_KEY], undefined);
    saved.cache.phone.title = 'caller mutation';
    assert.deepEqual((await cache.readArchiveVersion(f.ctx, first.versionId)).cache.phone, old.phone);
    assert.deepEqual(cache.readParticipantRoster(f.ctx), b);
    assert.equal(f.requests.length, 0);
});

test('later normal content writes and newer stale mirrors cannot erase saved versions', async t => {
    const f = await fixture(t);
    const oldMirror = clone(cache.getCache(f.ctx));
    const version = await cache.saveArchiveVersion(f.ctx, { selectedPages: ['cabinet'] });
    oldMirror.cabinet.items.push({ id: 'after-version', text: '后来保存的陈列品' });
    cache.stampCacheCommit(oldMirror, cache.cacheScopeFromContext(f.ctx));
    await cache.persistCompressedCacheNow(f.ctx, oldMirror);
    assert.equal((await cache.listArchiveVersions(f.ctx))[0].versionId, version.versionId);
    assert.ok((await f.persisted()).cabinet.items.some(item => item.id === 'after-version'));
    const bank = clone(f.ctx.chatMetadata[C.MEMORY_KEY]);
    await cache.saveImportedMemory(f.ctx, { ...bank, archiveRevision: 'version-history-next-revision' }, bank.chatId,
        { ...archiveOptions(bank), preserveDerivedCache: true });
    assert.equal((await cache.listArchiveVersions(f.ctx))[0].versionId, version.versionId);
    assert.equal((await cache.readArchiveVersion(f.ctx, version.versionId)).archiveRevision, bank.archiveRevision);
    await assert.rejects(cache.assertArchiveVersionReplacement(f.ctx, { versionId: version.versionId, pageId: 'cabinet' }, 'cabinet'),
        error => error.code === 'RMT_ARCHIVE_VERSION_REQUIRED');
});

test('version parking retains completed paid segments separately after new success clears active recovery', async t => {
    const f = await fixture(t);
    const bank = clone(f.ctx.chatMetadata[C.MEMORY_KEY]);
    const origin = contextApi.captureTaskOrigin(f.ctx, bank.archiveRevision);
    t.after(() => recovery.detachGenerationRecovery(origin));
    await generation.beginModeRecovery('phone', f.ctx, bank, origin, { operation: { kind: 'mode', mode: 'phone' } });
    await recovery.withRecoverySegment('合成已通过校验的第一段', { origin, taskKey: 'phone:part-one', mode: 'phone', context: f.ctx },
        raw => { assert.equal(raw.paid, '已保存第一段'); return raw; },
        async (_prompt, _options, accepted) => {
            const raw = { paid: '已保存第一段' };
            await accepted(raw);
            return raw;
        });
    const journal = cache.loadGenerationRecovery('phone', f.ctx);
    assert.ok(journal, 'accepted production recovery checkpoint must be persisted before parking');
    assert.equal(journal.segments[0].state, 'complete');
    const version = await cache.saveArchiveVersion(f.ctx, { selectedPages: ['phone'], parkDrafts: true });
    assert.equal(cache.loadGenerationRecovery('phone', f.ctx, null, { draftId: journal.draftId }).segments[0].rawJson, journal.segments[0].rawJson,
        'saving an old version must retain this unfinished task as selectable recovery');
    const saved = await cache.readArchiveVersion(f.ctx, version.versionId);
    assert.equal(saved.cache[recovery.GENERATION_RECOVERY_CACHE_KEY], undefined);
    const versionJournal = saved.drafts.tasks?.[journal.draftId] || saved.drafts.modules.phone;
    assert.equal(versionJournal.segments[0].rawJson, '{"paid":"已保存第一段"}');
    const newOrigin = contextApi.captureTaskOrigin(f.ctx, bank.archiveRevision);
    t.after(() => recovery.detachGenerationRecovery(newOrigin));
    await generation.beginModeRecovery('phone', f.ctx, bank, newOrigin, { existing: null, operation: { kind: 'mode', mode: 'phone' } });
    await recovery.withRecoverySegment('第二份任务', { origin: newOrigin, taskKey: 'phone:part-new', mode: 'phone', context: f.ctx }, raw => raw,
        async (_prompt, _options, accepted) => { const raw = { paid: '第二份完成' }; await accepted(raw); return raw; });
    assert.notEqual(newOrigin.generationRecoveryDraftId, journal.draftId);
    await cache.saveGenerationRecovery(f.ctx, bank, 'phone', null, newOrigin);
    assert.equal(cache.loadGenerationRecovery('phone', f.ctx, null, { draftId: newOrigin.generationRecoveryDraftId }), null);
    assert.equal(cache.loadGenerationRecovery('phone', f.ctx, null, { draftId: journal.draftId }).segments[0].rawJson, journal.segments[0].rawJson);
    assert.deepEqual((await cache.readArchiveVersion(f.ctx, version.versionId)).drafts, saved.drafts);
    assert.equal(f.requests.length, 0);
});

test('failed old-version persistence leaves content, current roster and active drafts untouched', async t => {
    const f = await fixture(t);
    await cache.commitParticipantRoster(f.ctx, roster());
    const before = await f.persisted();
    f.failCompletedSave(C.MODE.PHONE, () => true);
    await assert.rejects(cache.saveArchiveVersion(f.ctx, { selectedPages: ['phone'], parkDrafts: true }));
    assert.deepEqual(await f.persisted(), before);
    assert.deepEqual(await cache.listArchiveVersions(f.ctx), []);
    assert.equal(f.requests.length, 0);
});

test('replacement permission is tied to durable archive and selected page, not the later roster', async t => {
    const f = await fixture(t);
    const a = await cache.commitParticipantRoster(f.ctx, roster());
    const version = await cache.saveArchiveVersion(f.ctx, { selectedPages: ['cabinet'], expectedRosterRevision: a.revision });
    await cache.commitParticipantRoster(f.ctx, roster('new-person'), { expectedRevision: a.revision });
    const ticket = { versionId: version.versionId, pageId: 'cabinet' };
    assert.deepEqual(await cache.assertArchiveVersionReplacement(f.ctx, ticket, 'cabinet'), ticket);
    await assert.rejects(cache.assertArchiveVersionReplacement(f.ctx, { ...ticket, pageId: 'phone' }, 'phone'),
        error => error.code === 'RMT_ARCHIVE_VERSION_REQUIRED');
    const bank = f.ctx.chatMetadata[C.MEMORY_KEY];
    const fresh = clone((await f.persisted()).cabinet);
    fresh.items.push({ id: 'changed-after-version', text: '版本保存后另一项正常更新' });
    await cache.commitSession('cabinet', fresh, bank.chatId);
    await assert.rejects(cache.assertArchiveVersionReplacement(f.ctx, ticket, 'cabinet'),
        error => error.code === 'RMT_RECOVERY_TARGET_CHANGED');
});

function inboxVersion(memory, title) {
    const plan = [{ slot: 'daily', eventKey: `daily:${title}`, sourceMemoryIds: [], sourceMemoryAnchor: '' }];
    return inbox.normalizeInboxLetters({ letters: [{ slot: 'daily', title, greeting: '你好',
        body: '今天在屋里整理书架，先把桌面腾出来，等雨停后再去附近走走。', closing: '留字' }] }, memory, plan, new Date('2026-09-19T12:00:00'));
}

function songVersion(memory, title) {
    const plan = song.createThemeSongPlan({ subject: 'character', language: 'zh', voice: 'char', direction: `安静钢琴，${title}` }, memory);
    const item = song.normalizeGeneratedSong({ title, vocalDescription: '低声独唱', styleDescription: '安静钢琴',
        stylePrompt: 'Piano ballad, quiet vocals, 80 BPM',
        lyrics: '[Verse 1]\n窗边的风轻轻吹过\n我把书页慢慢翻过\n[Chorus]\n留一盏安静的灯\n等这阵雨停\n[Outro]\n天色渐渐明亮\n[End]' }, plan, memory);
    return { ...songContract.emptyThemeSongs(memory), songs: [item], selectedId: item.id };
}

for (const [mode, make] of [['inbox', inboxVersion], ['themeSong', songVersion]]) {
    test(`${mode} ordinary commits append but saved-version replacement keeps reopenable old collection`, async t => {
        const f = await fixture(t), bank = f.ctx.chatMetadata[C.MEMORY_KEY];
        await cache.commitSession(mode, make(bank, '第一份'), bank.chatId);
        await cache.commitSession(mode, make(bank, '第二份'), bank.chatId);
        const old = (await f.persisted())[mode], field = mode === 'inbox' ? 'letters' : 'songs';
        assert.equal(old[field].length, 2);
        const version = await cache.saveArchiveVersion(f.ctx, { selectedPages: [mode] });
        const fresh = make(bank, '重新生成的一份');
        fresh[cache.PARTICIPANT_REPLACEMENT_KEY] = { versionId: version.versionId, pageId: mode };
        assert.equal(await cache.commitSession(mode, fresh, bank.chatId), true);
        const disk = await f.persisted();
        assert.equal(disk[mode][field].length, 1);
        assert.equal(disk[mode][field][0].title, '重新生成的一份');
        assert.equal(disk[mode][cache.PARTICIPANT_REPLACEMENT_KEY], undefined);
        assert.equal(await cache.commitSession(mode, fresh, bank.chatId), true, 'deferred acknowledgement may replay exactly the saved replacement');
        assert.equal((await f.persisted())[mode][field].length, 1);
        assert.deepEqual((await cache.readArchiveVersion(f.ctx, version.versionId)).cache[mode], old);
        state.runtimeSessionCache.clear();
        await cache.ensureCacheHydrated(f.ctx);
        const opened = await library.openArchiveVersion(version.versionId, f.ctx);
        assert.equal(opened.backupOnly, true);
        assert.equal(opened.historyVersionId, version.versionId);
        assert.deepEqual(opened.cache[mode], old);
        assert.equal(library.promoteSnapshotToLiveIfCurrent(), false);
        library.setArchiveReadOnly(false);
        assert.equal(state.activeArchiveReadOnly, true);
        await assert.rejects(library.fetchIndexedArchiveSnapshot(opened, f.ctx), /不能刷新/);
        assert.equal(f.reads.length, 0);
        assert.equal(f.requests.length, 0);
    });
}

async function seedPaidArchiveDraft(f, operation = 'profile', { profileOnly = false } = {}) {
    const origin = contextApi.captureTaskOrigin(f.ctx, f.ctx.chatMetadata[C.MEMORY_KEY].archiveRevision);
    const ticket = await archiveDrafts.beginArchiveRecovery({ origin, operation,
        sourceIdentity: 'old-paid-source', sourceFragments: ['old-paid-fragment'], settingsIdentity: 'old-settings',
        inputs: { contextEnvelope: '原名单的背景', originalMarker: `${operation}-paid-input` } });
    await recovery.withRecoverySegment(`原来的${operation}分段`, { origin: ticket.origin, taskKey: 'paid-old-segment' }, raw => raw,
        async (_prompt, _options, accepted) => {
            const value = { paid: `${operation}-original-success` }; await accepted(value); return value;
        });
    if (profileOnly) archiveDrafts.stageArchiveRecoveryCommit(ticket, origin.archiveRevision, { profilePending: true });
    archiveDrafts.releaseArchiveRecovery(ticket);
    if (profileOnly) archiveDrafts.acknowledgeArchiveRecoveryCommit(origin);
    await archiveDrafts.flushArchiveRecovery(origin, operation);
    return { origin, exported: archiveDrafts.exportArchiveRecovery(origin, operation) };
}

const replacementProfileReply = () => ({ archiveName: '一同栽花', verdictStyle: 'quiet-life',
    relationshipReading: { char: '共同栽花', user: '共同参与', relation: '相伴', tension: '未记载', direction: '相伴' },
    archiveVerdict: '两个人一起在庭院栽花，这份记录呈现的是他们共同参与一件小事的经历。花苗慢慢立在土中，他们的关系仍应由已经发生的事实来理解，不需要提前给尚未表达的感情加上名字。对话没有说明更远的约定，档案也只留下这次相伴本身，以及两人愿意共同花费的时间。',
    verdictSources: [{ memoryId: 'M001', anchor: '庭院' }], keywords: ['庭院', '栽花'] });

test('profile parking uses its own durable scope and leaves default import export unchanged after reload', async t => {
    const f = await fixture(t); localFixture(t);
    const oldImport = await seedPaidArchiveDraft(f, 'import');
    const oldProfile = await seedPaidArchiveDraft(f, 'profile');
    assert.equal(archiveDrafts.parkArchiveRecovery(oldProfile.origin, 'profile'), true);
    await archiveDrafts.flushArchiveRecovery(oldProfile.origin, 'profile');
    assert.equal(archiveDrafts.archiveRecoverySummary(oldProfile.origin, 'profile'), null);
    assert.deepEqual(archiveDrafts.exportArchiveRecovery(oldImport.origin), oldImport.exported);
    archiveDrafts.resetArchiveRecoveryMemoryForTests();
    await archiveDrafts.hydrateArchiveRecovery(oldImport.origin);
    await archiveDrafts.hydrateArchiveRecovery(oldProfile.origin, 'profile');
    assert.deepEqual(archiveDrafts.exportArchiveRecovery(oldProfile.origin, 'profile'), oldProfile.exported);
    assert.deepEqual(archiveDrafts.exportArchiveRecovery(oldImport.origin), oldImport.exported);
    assert.equal(f.requests.length, 0);
});

test('explicit profile replacement parks both paid profile and import profile-only drafts before one new request', async t => {
    const f = await fixture(t); localFixture(t);
    const oldImport = await seedPaidArchiveDraft(f, 'import', { profileOnly: true });
    const oldProfile = await seedPaidArchiveDraft(f, 'profile');
    const memories = clone(f.ctx.chatMetadata[C.MEMORY_KEY].memories);
    const priorCache = await f.persisted();
    const version = await cache.saveArchiveVersion(f.ctx, { selectedPages: ['archiveProfile'], parkDrafts: true });
    f.setResponse(() => {
        assert.equal(archiveDrafts.archiveRecoverySummary(oldImport.origin), null);
        assert.deepEqual(archiveDrafts.exportArchiveRecovery(oldProfile.origin, 'profile')[0], oldProfile.exported[0]);
        assert.deepEqual(archiveDrafts.exportArchiveRecovery(oldImport.origin), oldImport.exported);
        return replacementProfileReply();
    });
    const result = await repository.rewriteCurrentArchiveVerdict({ participantRegeneration: {
        versionId: version.versionId, pageId: 'archiveProfile', participantSnapshot: participants.selectedParticipantSnapshot(roster('new-person', '新人物')) } });
    assert.equal(result.status, 'committed', JSON.stringify(result));
    assert.equal(f.requests.length, 1);
    assert.match(JSON.stringify(f.requests[0]), /新人物/);
    assert.deepEqual(f.ctx.chatMetadata[C.MEMORY_KEY].memories, memories);
    assert.deepEqual((await f.persisted()).phone, priorCache.phone);
    archiveDrafts.resetArchiveRecoveryMemoryForTests();
    await archiveDrafts.hydrateArchiveRecovery(oldImport.origin);
    await archiveDrafts.hydrateArchiveRecovery(oldProfile.origin, 'profile');
    assert.deepEqual(archiveDrafts.exportArchiveRecovery(oldProfile.origin, 'profile'), oldProfile.exported);
    assert.deepEqual(archiveDrafts.exportArchiveRecovery(oldImport.origin), oldImport.exported);
});

test('failed profile parking flush sends no request and a later retry persists the same paid draft before generating', async t => {
    const f = await fixture(t), local = localFixture(t);
    const old = await seedPaidArchiveDraft(f);
    const before = clone(f.ctx.chatMetadata[C.MEMORY_KEY]);
    const version = await cache.saveArchiveVersion(f.ctx, { selectedPages: ['archiveProfile'] });
    const options = { participantRegeneration: { versionId: version.versionId, pageId: 'archiveProfile',
        participantSnapshot: participants.selectedParticipantSnapshot(roster()) } };
    local.fail();
    const failed = await repository.rewriteCurrentArchiveVerdict(options);
    assert.equal(failed.status, 'failed');
    assert.equal(failed.error?.code, 'RMT_ARCHIVE_DRAFT_STORAGE');
    assert.equal(f.requests.length, 0);
    assert.deepEqual(f.ctx.chatMetadata[C.MEMORY_KEY], before);
    assert.deepEqual(archiveDrafts.exportArchiveRecovery(old.origin, 'profile'), old.exported);
    local.fail(false); f.setResponse(replacementProfileReply);
    const retried = await repository.rewriteCurrentArchiveVerdict(options);
    assert.equal(retried.status, 'committed', JSON.stringify(retried));
    assert.equal(f.requests.length, 1);
    archiveDrafts.resetArchiveRecoveryMemoryForTests();
    await archiveDrafts.hydrateArchiveRecovery(old.origin, 'profile');
    assert.deepEqual(archiveDrafts.exportArchiveRecovery(old.origin, 'profile'), old.exported);
});

async function paidModuleDraft(f, mode, pageId, textValue) {
    const bank = clone(f.ctx.chatMetadata[C.MEMORY_KEY]);
    const origin = contextApi.captureTaskOrigin(f.ctx, bank.archiveRevision);
    const operation = mode === 'heart' ? { kind: 'heart-season', season: pageId, batchId: textValue } : { kind: 'mode', mode };
    const handle = await generation.beginModeRecovery(mode, f.ctx, bank, origin, { existing: null, pageId, operation });
    await recovery.withRecoverySegment(`paid source ${textValue}`, { origin, taskKey: `${pageId}:paid`, mode, context: f.ctx }, raw => raw,
        async (_prompt, _options, accepted) => { const value = { text: textValue }; await accepted(value); return value; });
    recovery.detachGenerationRecovery(origin);
    return { origin, bank, handle, draftId: origin.generationRecoveryDraftId,
        journal: cache.loadGenerationRecovery(mode, f.ctx, null, { draftId: origin.generationRecoveryDraftId }) };
}

test('multiple drafts of the same HEART page and another page survive reload and a new archive revision', async t => {
    const f = await fixture(t);
    const drafts = [await paidModuleDraft(f, 'heart', 'spring', '春甲原付费段'),
        await paidModuleDraft(f, 'heart', 'summer', '夏原付费段'), await paidModuleDraft(f, 'heart', 'spring', '春乙原付费段')];
    assert.equal(new Set(drafts.map(row => row.draftId)).size, 3);
    state.runtimeSessionCache.clear(); await cache.ensureCacheHydrated(f.ctx);
    assert.equal(cache.listGenerationDrafts(f.ctx, null, 'heart').length, 3);
    const bank = clone(f.ctx.chatMetadata[C.MEMORY_KEY]);
    await cache.saveImportedMemory(f.ctx, { ...bank, archiveRevision: 'drafts-next-revision' }, bank.chatId,
        { ...archiveOptions(bank), preserveDerivedCache: true });
    state.runtimeSessionCache.clear(); await cache.ensureCacheHydrated(f.ctx);
    for (const draft of drafts) assert.equal(cache.loadGenerationRecovery('heart', f.ctx, null, { draftId: draft.draftId }).segments[0].rawJson,
        draft.journal.segments[0].rawJson, 'new evidence must not erase or relabel the original paid segment');
    assert.equal(f.requests.length, 0);
});

test('finishing one draft removes only its raw checkpoint and stale compression cannot resurrect it', async t => {
    const f = await fixture(t);
    const spring = await paidModuleDraft(f, 'heart', 'spring', '仍未完成的春'), summer = await paidModuleDraft(f, 'heart', 'summer', '完成的夏');
    const stale = clone(cache.getCache(f.ctx));
    await cache.saveGenerationRecovery(f.ctx, summer.bank, 'heart', null, summer.origin);
    const finished = (await f.persisted())[cache.GENERATION_DRAFTS_CACHE_KEY].records[summer.draftId];
    assert.equal(finished.status, 'complete'); assert.equal(finished.journal, undefined);
    cache.stampCacheCommit(stale, cache.cacheScopeFromContext(f.ctx));
    await cache.persistCompressedCacheNow(f.ctx, stale);
    assert.equal(cache.loadGenerationRecovery('heart', f.ctx, null, { draftId: summer.draftId }), null);
    assert.equal(cache.loadGenerationRecovery('heart', f.ctx, null, { draftId: spring.draftId }).segments[0].rawJson, spring.journal.segments[0].rawJson);
    await assert.rejects(cache.saveGenerationRecovery(f.ctx, summer.bank, 'heart', summer.journal, summer.origin), { code: 'RMT_RECOVERY_CLEARED' });
});

test('a failed draft completion keeps every original paid checkpoint and old versions have no invented phone draft', async t => {
    const f = await fixture(t), draft = await paidModuleDraft(f, 'heart', 'spring', '不能丢失');
    const before = await f.persisted();
    f.failCompletedSave('phone', () => true);
    await assert.rejects(cache.saveGenerationRecovery(f.ctx, draft.bank, 'heart', null, draft.origin));
    assert.deepEqual(await f.persisted(), before);
    f.failCompletedSave('', () => false);
    const version = await cache.saveArchiveVersion(f.ctx, { selectedPages: ['spring'], parkDrafts: true });
    const saved = await cache.readArchiveVersion(f.ctx, version.versionId);
    assert.equal(saved.drafts.phone, null);
    assert.equal(saved.drafts.tasks[draft.draftId].segments[0].rawJson, draft.journal.segments[0].rawJson);
    assert.equal(cache.loadGenerationRecovery('heart', f.ctx, null, { draftId: draft.draftId }).segments[0].rawJson, draft.journal.segments[0].rawJson);
});

test('cross-revision completed result is durable before choice and applying it snapshots current content with original evidence', async t => {
    const f = await fixture(t), old = await paidModuleDraft(f, 'cabinet', 'cabinet', '原任务输出');
    const newBank = { ...old.bank, archiveRevision: 'rebuilt-with-reused-M001', memories: [{ id: 'M001', title: '新事实', summary: '这个编号现在指向完全不同的事。', anchors: ['新事实'] }] };
    await cache.saveImportedMemory(f.ctx, newBank, old.bank.chatId, { ...archiveOptions(old.bank), preserveDerivedCache: true });
    const before = await f.persisted();
    const origin = contextApi.captureTaskOrigin(f.ctx, newBank.archiveRevision);
    const existing = cache.loadGenerationRecovery('cabinet', f.ctx, null, { draftId: old.draftId });
    await generation.beginModeRecovery('cabinet', f.ctx, newBank, origin, { existing, pageId: 'cabinet', operation: existing.operation });
    t.after(() => recovery.detachGenerationRecovery(origin));
    const session = { ...clone(before.cabinet), items: [{ id: 'NEW_ITEM', text: '原栽花经历留下的物品', sourceMemoryIds: ['M001'] }] };
    const outcome = await cache.saveGenerationTaskResult(f.ctx, 'cabinet', session, origin,
        { draftId: old.draftId, pageId: 'cabinet', memoryBank: newBank, sourceMemory: old.bank });
    assert.equal(outcome.status, 'awaiting-choice');
    assert.deepEqual((await f.persisted()).cabinet, before.cabinet, 'completion cannot choose its own destination');
    state.runtimeSessionCache.clear(); await cache.ensureCacheHydrated(f.ctx);
    const result = await cache.readGenerationTaskResult(f.ctx, old.draftId);
    assert.deepEqual(result.sourceMemory, old.bank);
    assert.notDeepEqual(result.sourceMemory.memories, newBank.memories);
    assert.ok(result.createdAt > 0); assert.equal(result.entryId, f.aEntry.entryId);
    await cache.resolveGenerationTaskResult(f.ctx, old.draftId, 'independent');
    assert.deepEqual((await f.persisted()).cabinet, before.cabinet);
    await cache.resolveGenerationTaskResult(f.ctx, old.draftId, 'apply');
    const after = await f.persisted();
    assert.deepEqual(after.phone, before.phone);
    assert.equal(after.cabinet.items[0].id, 'NEW_ITEM');
    assert.deepEqual(after.cabinet.generationSources.cabinet.sourceMemory, old.bank);
    const versions = await cache.listArchiveVersions(f.ctx);
    const saved = await cache.readArchiveVersion(f.ctx, versions.at(-1).versionId);
    assert.deepEqual(saved.cache.cabinet, before.cabinet);
    assert.deepEqual(saved.memory, newBank);
    assert.deepEqual((await cache.readGenerationTaskResult(f.ctx, old.draftId)).sourceMemory, old.bank);
    assert.equal(after[cache.GENERATION_DRAFTS_CACHE_KEY].records[old.draftId].journal, undefined);
});

test('partial result reading is opt-in, reprojection keeps local images and completion moves them to formal content', async t => {
    const f = await fixture(t), draft = await paidModuleDraft(f, 'album', 'album', '原始相册段');
    const other = await paidModuleDraft(f, 'heart', 'spring', '另一个仍需继续的段');
    const partial = { kind: 'album', chatId: draft.bank.chatId, archiveRevision: draft.bank.archiveRevision,
        entries: [{ id: 'PIC1', title: '窗边', desc: '书架旁的一束光。', imagePrompt: 'a quiet library', unlocked: true }], selectedId: 'PIC1',
        readableProgress: { version: 1, complete: false, draftId: draft.draftId, pageId: 'album' } };
    await cache.saveGenerationTaskResult(f.ctx, 'album', partial, draft.origin, { complete: false, memoryBank: draft.bank, sourceMemory: draft.bank });
    assert.equal(cache.loadSession('album', { context: f.ctx }), null, 'generation must not consume a reading projection as previous formal content');
    const first = cache.loadSession('album', { context: f.ctx, includePartial: true });
    assert.equal(first.entries.length, 1);
    const image = { url: '/user/images/test/progress-saved.png', provider: 'baibai-image', prompt: 'already paid', generatedAt: 111 };
    await cache.commitGenerationTaskResultMutation(f.ctx, draft.draftId, session => {
        session.entries[0].cgImage = image; session.entries[0].favorite = true; session.entries[0].readAt = 333;
        session.selectedId = 'PIC1'; session.view = 'detail'; return session;
    }, { expectedTaskOrigin: draft.origin });
    await cache.saveGenerationTaskResult(f.ctx, 'album', { ...partial, entries: [...partial.entries, { id: 'PIC2', title: '第二张', unlocked: true }], selectedId: 'PIC2' }, draft.origin,
        { complete: false, memoryBank: draft.bank, sourceMemory: draft.bank });
    const second = await cache.readGenerationTaskResult(f.ctx, draft.draftId);
    assert.deepEqual(second.session.entries[0].cgImage, image);
    assert.equal(second.session.entries[0].favorite, true); assert.equal(second.session.entries[0].readAt, 333);
    assert.equal(second.session.selectedId, 'PIC1'); assert.equal(second.session.view, 'detail');
    const reading = cache.loadSession('album', { context: f.ctx, includePartial: true });
    reading.entries[0].title = '不能从阅读副本改正式文本'; reading.view = 'list';
    await cache.commitSession('album', reading, draft.bank.chatId, draft.origin);
    assert.equal(cache.loadSession('album', { context: f.ctx }), null);
    assert.equal((await cache.readGenerationTaskResult(f.ctx, draft.draftId)).session.entries[0].title, '窗边');
    const final = { ...partial }; delete final.readableProgress;
    assert.equal(await cache.commitSession('album', final, draft.bank.chatId, draft.origin), true);
    assert.deepEqual((await f.persisted()).album.entries[0].cgImage, image);
    assert.equal((await f.persisted())[cache.GENERATION_DRAFTS_CACHE_KEY].records[draft.draftId].result, undefined);
    assert.equal(cache.loadGenerationRecovery('heart', f.ctx, null, { draftId: other.draftId }).segments[0].rawJson, other.journal.segments[0].rawJson);
    assert.equal(f.requests.length, 0);
});

test('generic HEART completion applies its full content and explicit snapshot reads never consult another live archive', async t => {
    const f = await fixture(t), draft = await paidModuleDraft(f, 'heart', 'heart', '完整基础互动');
    const session = { kind: 'heart', chatId: draft.bank.chatId, archiveRevision: draft.bank.archiveRevision,
        relationshipSummary: '原资料中的摘要', greetings: { morning: ['原资料中的完整台词。'] }, voiceDramas: [], scenarioDramas: [], dailyStrips: [], fireflyVoices: [] };
    await cache.saveGenerationTaskResult(f.ctx, 'heart', session, draft.origin, { memoryBank: draft.bank, sourceMemory: draft.bank });
    const explicitCache = await f.persisted();
    const read = await cache.readGenerationTaskResult(null, draft.draftId, { cache: explicitCache });
    assert.deepEqual(read.sourceMemory, draft.bank);
    const readonly = recoveryView.recoveryBannerHtml(explicitCache, draft.bank, { readOnly: true });
    assert.ok(readonly.includes('data-rmt-task-result-open'));
    assert.equal(readonly.includes('data-rmt-task-result-choose'), false);
    assert.equal(readonly.includes('data-rmt-recovery-mode'), false);
    await cache.resolveGenerationTaskResult(f.ctx, draft.draftId, 'apply');
    assert.deepEqual((await f.persisted()).heart.greetings, session.greetings);
    assert.equal((await f.persisted()).heart.relationshipSummary, session.relationshipSummary);
});

test('applying life keeps its original space and evidence when current SP01 and M001 have different meanings', async t => {
    const f = await fixture(t), draft = await paidModuleDraft(f, 'room', 'roomLife', '旧房间生活');
    const oldBank = { ...draft.bank, memories: [{ id: 'M001', title: '旧花园记忆', summary: '旧花园的花盆仍在。', anchors: ['旧花园的花盆'] }] };
    const oldRoom = { kind: 'room', chatId: draft.bank.chatId, archiveRevision: draft.bank.archiveRevision,
        spaces: [{ id: 'SP01', label: '旧花园', objects: [{ id: 'O1', label: '旧花盆', description: '陶土花盆', line: '花盆在这里。' }] }], dayparts: {},
        lifePlan: { dateKey: '2026-09-19', beats: [{ time: '06:40', minute: 400, spaceId: 'SP01', focusObjectId: 'O1', activity: '看看旧花园的花盆。', line: '花又开了。', sourceMemoryIds: ['M001'], sourceMemoryAnchor: '旧花园的花盆' }] } };
    const currentRoom = { ...clone(oldRoom), spaces: [{ id: 'SP01', label: '新工坊', objects: [{ id: 'O1', label: '新工具', description: '铁制工具' }] }], lifePlan: undefined };
    await cache.commitSession('room', currentRoom, draft.bank.chatId);
    await cache.saveGenerationTaskResult(f.ctx, 'room', oldRoom, draft.origin, { pageId: 'roomLife', memoryBank: draft.bank, sourceMemory: oldBank });
    await cache.resolveGenerationTaskResult(f.ctx, draft.draftId, 'apply');
    const result = (await f.persisted()).room;
    assert.equal(result.spaces[0].label, '新工坊', 'applying life does not replace an unselected room');
    assert.equal(roomMode.roomLifeUsesDifferentBlueprint(result), true);
    const html = roomMode.roomPreservedLifeHtml(result);
    assert.ok(html.includes('旧花园')); assert.ok(html.includes('旧花盆')); assert.equal(html.includes('新工具'), false);
    assert.equal(roomMode.roomLifeBeat(result, new Date('2026-09-19T07:00:00')), null, 'old SP01 must not animate the unrelated new SP01');
    const source = cache.generationPageReadingSource(result, 'roomLife', { ...draft.bank, memories: [{ id: 'M001', title: '新工坊记忆' }] });
    assert.equal(source.memoryBank.memories[0].title, '旧花园记忆');
    assert.equal(result.archiveRevision, draft.bank.archiveRevision, 'reading source does not mutate formal target identity');
});

test('explicitly deleted progress items stay deleted through reprojection and detached final completion', async t => {
    const f = await fixture(t), draft = await paidModuleDraft(f, 'album', 'album', '保留用户删除动作');
    const partial = { kind: 'album', chatId: draft.bank.chatId, archiveRevision: draft.bank.archiveRevision,
        entries: [{ id: 'KEEP', title: '保留' }, { id: 'DELETE', title: '用户要删除' }],
        readableProgress: { version: 1, complete: false, draftId: draft.draftId, pageId: 'album' } };
    await cache.saveGenerationTaskResult(f.ctx, 'album', partial, draft.origin, { complete: false, sourceMemory: draft.bank });
    const target = { ...f.aEntry, memory: draft.bank, cache: await f.persisted() }, unrelated = await f.persisted(f.bEntry);
    Object.assign(f.ctx, { characterId: 1, chatId: f.otherBank.chatId, name1: f.otherBank.userName, name2: f.otherBank.characterName,
        chatMetadata: { [C.MEMORY_KEY]: clone(f.otherBank), [C.CACHE_KEY]: clone(unrelated) } });
    const changed = await cache.commitGenerationTaskResultMutation(f.ctx, draft.draftId, session => {
        session.entries = session.entries.filter(item => item.id !== 'DELETE'); return session;
    }, { archiveTarget: target, expectedTaskOrigin: draft.origin, stillCurrent: () => true });
    assert.deepEqual(changed.entries.map(item => item.id), ['KEEP']);
    await cache.saveGenerationTaskResult(f.ctx, 'album', { ...partial, entries: [...partial.entries, { id: 'LATER', title: '后来完成' }] }, draft.origin,
        { complete: false, archiveTarget: target, memoryBank: draft.bank, sourceMemory: draft.bank });
    const reopened = await cache.readGenerationTaskResult(null, draft.draftId, { cache: target.cache });
    assert.deepEqual(reopened.session.entries.map(item => item.id), ['KEEP', 'LATER']);
    const final = { ...partial, entries: [...partial.entries, { id: 'LATER', title: '后来完成' }] }; delete final.readableProgress;
    await cache.commitDetachedArchiveSession(target, 'album', final, () => true, draft.origin);
    assert.deepEqual((await f.persisted()).album.entries.map(item => item.id), ['KEEP', 'LATER']);
    assert.deepEqual(await f.persisted(f.bEntry), unrelated, 'an explicit writable target never falls through to the live archive');
    assert.equal((await f.persisted())[cache.GENERATION_DRAFTS_CACHE_KEY].records[draft.draftId].result, undefined);
});

test('applied calendar migration reads its original dated evidence when rebuilt M001 names a different day', async t => {
    const f = await fixture(t), draft = await paidModuleDraft(f, 'calendar', 'calendar', '原资料日历');
    const oldBank = { ...draft.bank, memories: [{ id: 'M001', title: '旧花园', date: '1901/04/05', summary: '旧花园。', anchors: ['旧花园'] }] };
    const currentBank = { ...draft.bank, archiveRevision: 'calendar-rebuilt', memories: [{ id: 'M001', title: '新工坊', date: '2099/09/09', summary: '新工坊。', anchors: ['新工坊'] }] };
    await cache.saveImportedMemory(f.ctx, currentBank, draft.bank.chatId, { ...archiveOptions(draft.bank), preserveDerivedCache: true });
    const origin = contextApi.captureTaskOrigin(f.ctx, currentBank.archiveRevision); origin.generationRecoveryDraftId = draft.draftId;
    const calendar = { kind: 'calendar', chatId: draft.bank.chatId, archiveRevision: draft.bank.archiveRevision,
        calendarVersion: C.CALENDAR_SESSION_VERSION, entries: [], dayPages: {}, selectedDateKey: '', selectedMonth: '' };
    await cache.saveGenerationTaskResult(f.ctx, 'calendar', calendar, origin, { memoryBank: currentBank, sourceMemory: oldBank });
    await cache.resolveGenerationTaskResult(f.ctx, draft.draftId, 'apply');
    const read = cache.loadSession('calendar', { context: f.ctx });
    assert.equal(read.storyDate, '1901/04/05');
    assert.equal(read.archiveRevision, currentBank.archiveRevision);
    assert.equal(cache.generationPageSourceMemory(read, 'calendar', currentBank).memories[0].title, '旧花园');
});
