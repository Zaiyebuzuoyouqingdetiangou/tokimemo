import {r8412ContractSource} from './helpers/r8412SourceCompatibility.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {r8411ContractSource} from './helpers/r8411SourceCompatibility.mjs';
import * as constants from '../src/core/constants.js';
import * as policy from '../src/core/autoUpdatePolicy.js';

// The user approved phase3 and its unified partial-reader file scope. Historical
// hashes remain unchanged below. This inverse accepts only the reviewed bytes;
// it is not used by any runtime behavior, reader, provider, or mutation test.
const phase3AuthorizedDeltas = {
  "src/modes/themeSong.js": {
    "beforeSha256": "e48c533fb0bf9fad7999930055d565c6545431d54eb25eb0de2cbe52f3ac3c18",
    "afterSha256": "ebd5c258314df754914cac4456feaecfd5fa9cb40b9b3289148d23406eb0f050",
    "changes": [
      {
        "start": 76,
        "remove": 53,
        "old": "",
        "new": "\nexport function projectThemeSongProgress({ segments, memoryBank, context, previousSession, operation = {} }) {\n    let plan;\n    try { plan = validateThemeSongPlan(operation.themeSongPlan, memoryBank); }\n    catch { return null; }\n    const keys = { title: L.title, vocalDescription: L.vocal, styleDescription: L.description, stylePrompt: L.style, lyrics: L.lyrics };\n    const segment = segments.findLast(item => Object.keys(keys).some(key => item.has('/' + key)));\n    if (!segment) return null;\n    let song;\n    try { song = normalizeGeneratedSong(segment.value, plan, memoryBank); }\n    catch {\n        song = { id: plan.id, subject: plan.subject, subjectTitle: plan.subjectTitle, language: plan.language,\n            ...(plan.language === 'custom' ? { customLanguage: plan.customLanguage } : {}),\n            voice: plan.voice, singer: plan.singer, createdAt: plan.createdAt, sourceMemoryIds: plan.sourceMemoryIds,\n            sourceMemoryAnchor: plan.sourceMemoryAnchor, fiction: true, generationIncomplete: true };\n        for (const [key, maximum] of Object.entries(keys)) {\n            song[key] = '';\n            if (!segment.has('/' + key)) continue;\n            try {\n                const value = contract.songText(segment.value[key], maximum);\n                if (key !== 'stylePrompt' || !/[^\\x09\\x0a\\x0d\\x20-\\x7e]/u.test(value)) song[key] = value;\n            } catch { /* Keep the unaccepted field in the original draft, never fabricate a replacement. */ }\n        }\n        if (!Object.keys(keys).some(key => song[key])) return null;\n    }\n    const session = previousSession ? structuredClone(previousSession)\n        : contract.emptyThemeSongs(memoryBank, contextApi.currentCharacterRuntimeKey(context));\n    session.songs = [...session.songs.filter(item => item.id !== song.id), song];\n    session.selectedId = song.id;\n    return session;\n}\n\n// This reader accepts an explicitly marked unfinished song, never a final saved song.\nexport function readableThemeSongProgressSession(value, memory) {\n    try {\n        if (value?.readableProgress?.version !== 1 || value.readableProgress.complete !== false) return null;\n        const raw = contract.songData(value);\n        const completed = raw.songs.filter(song => song.generationIncomplete !== true);\n        contract.normalizeStoredThemeSongs({ ...raw, songs: completed }, memory);\n        const ids = new Set(completed.map(song => song.id));\n        for (const song of raw.songs.filter(song => song.generationIncomplete === true)) {\n            if (!/^SONG_[a-z0-9_-]{1,80}$/u.test(song.id || '') || ids.has(song.id) || song.fiction !== true\n                || !Object.hasOwn(contract.SONG_LANGUAGES, song.language) || !Object.hasOwn(contract.SONG_VOICES, song.voice)\n                || !['character', 'event'].includes(song.subject) || !Number.isFinite(song.createdAt)) return null;\n            ids.add(song.id);\n            if (song.language === 'custom') contract.customSongLanguage(song.customLanguage);\n            for (const [key, maximum] of Object.entries({ title: L.title, vocalDescription: L.vocal, styleDescription: L.description, stylePrompt: L.style, lyrics: L.lyrics }))\n                contract.songText(song[key], maximum);\n            if (/[^\\x09\\x0a\\x0d\\x20-\\x7e]/u.test(song.stylePrompt || '')) return null;\n        }\n        return value;\n    } catch { return null; }\n}\n"
      }
    ]
  },
  "src/ui/themeSongView.js": {
    "beforeSha256": "35540b9f19ab998c2d113122d6e6bc867490ae4ddf564dfb8ba11b7de00ff06b",
    "afterSha256": "d4210724752b4eb69e8292ca26bc5fa41ea565056a3bc5157e658574ca7efbf1",
    "changes": [
      {
        "start": 1,
        "remove": 1,
        "old": "",
        "new": "import * as songMode from '../modes/themeSong.js';\n"
      },
      {
        "start": 47,
        "remove": 7,
        "old": "    contract.normalizeStoredThemeSongs(session, memory);\n    if (!runtimeState.activeArchiveSnapshot && session.ownerKey\n",
        "new": "    if (session.chatId !== memory.chatId || session.archiveRevision !== memory.archiveRevision)\n        throw contract.songError('SOURCE', '显示的印象曲与目标档案不一致。');\n    const source = cache.generationPageReadingSource(session, MODE, memory);\n    if (session.readableProgress?.version === 1) {\n        if (!songMode.readableThemeSongProgressSession(source.session, source.memoryBank)) throw contract.songError('SOURCE', '这份歌曲草稿暂时无法读取，原内容仍保留。');\n    } else contract.normalizeStoredThemeSongs(source.session, source.memoryBank);\n    if (!runtimeState.activeArchiveSnapshot && !source.source && session.ownerKey\n"
      },
      {
        "start": 57,
        "remove": 19,
        "old": "",
        "new": "}\n\nasync function mutatePartialSong(shown, mutate) {\n    const snapshot = runtimeState.activeArchiveSnapshot, lifecycle = runtimeState.runtimeLifecycleEpoch;\n    let context, target = null;\n    if (snapshot) {\n        const options = library.archiveTargetGenerationOptions(snapshot);\n        target = await options.revalidateArchiveTarget(options.archiveTarget, lifecycle);\n        context = options.context;\n        context.chatMetadata[constants.MEMORY_KEY] = target.memory;\n        context.chatMetadata[constants.CACHE_KEY] = target.cache;\n    } else context = contextApi.currentCharacterGuard();\n    const memory = target?.memory || repository.requireArchive(context);\n    const origin = contextApi.captureTaskOrigin(context, memory.archiveRevision);\n    const updated = await cache.commitGenerationTaskResultMutation(context, shown.readableProgress.draftId, mutate,\n        { expectedTaskOrigin: origin, archiveTarget: target, stillCurrent: () => contextApi.runtimeLifecycleStillCurrent(lifecycle) });\n    if (!updated) throw contract.songError('SAVE', '未能确认歌曲阅读操作已保存，原作品保留。');\n    if (snapshot && runtimeState.activeArchiveSnapshot?.entryId === snapshot.entryId) runtimeState.activeArchiveSnapshot.cache = target.cache;\n    return updated;\n"
      },
      {
        "start": 104,
        "remove": 1,
        "old": "      <section class=\"rmt-song-lyrics\"><div class=\"rmt-song-toolbar\"><h3>完整歌词</h3>${button('copy-lyrics','复制歌词')}</div><pre>${esc(selected.lyrics)}</pre></section>\n",
        "new": "      <section class=\"rmt-song-lyrics\"><div class=\"rmt-song-toolbar\"><h3>${selected.generationIncomplete ? '已收到的歌词 · 未完成' : '完整歌词'}</h3>${button('copy-lyrics','复制歌词')}</div><pre>${esc(selected.lyrics)}</pre></section>\n"
      },
      {
        "start": 119,
        "remove": 4,
        "old": "    const recovery = recoveryView.recoveryBannerHtml({ __generationRecoveryV1: { [MODE]: allCache?.__generationRecoveryV1?.[MODE] } }, memory, { readOnly: readonly() });\n    overlay.bodyEl().innerHTML = `<main class=\"rmt-theme-song\"><header class=\"rmt-song-heading\"><div class=\"rmt-song-emblem\" aria-hidden=\"true\">♫</div><div><h2>角色印象曲</h2><p>${session.songs.length ? `已收录 ${session.songs.length} 首` : '歌名 · 曲风 · 完整歌词'}</p></div></header><p class=\"rmt-song-note\">生成歌曲文本与编曲说明，不生成音频。</p>${switcher}${recovery}${form}<div class=\"rmt-song-layout ${list ? 'has-songs' : ''}\">${list}${details}</div></main>`;\n",
        "new": "    const recovery = recoveryView.recoveryBannerHtml(allCache, memory, { readOnly: readonly() });\n    const partial = selected?.generationIncomplete ? '<p class=\"rmt-recovery-status\" role=\"status\">这首歌尚未写完；已收到的歌名、曲风和歌词分别保留，空白部分仍待生成。</p>' : '';\n    const completedCount = session.songs.filter(song => !song.generationIncomplete).length;\n    overlay.bodyEl().innerHTML = `<main class=\"rmt-theme-song\"><header class=\"rmt-song-heading\"><div class=\"rmt-song-emblem\" aria-hidden=\"true\">♫</div><div><h2>角色印象曲</h2><p>${session.songs.length ? `已收录 ${completedCount} 首${completedCount < session.songs.length ? ' · 另有未完成草稿' : ''}` : '歌名 · 曲风 · 完整歌词'}</p></div></header><p class=\"rmt-song-note\">生成歌曲文本与编曲说明，不生成音频。</p>${partial}${switcher}${recovery}${form}<div class=\"rmt-song-layout ${list ? 'has-songs' : ''}\">${list}${details}</div></main>`;\n"
      },
      {
        "start": 138,
        "remove": 1,
        "old": "    const mutate = latest => {\n",
        "new": "    const mutate = (latest, memory) => {\n"
      },
      {
        "start": 140,
        "remove": 6,
        "old": "        const current = contract.normalizeStoredThemeSongs(latest);\n",
        "new": "        let current;\n        if (latest.readableProgress?.complete === false) {\n            const source = cache.generationPageReadingSource(latest, MODE, memory || shownMemory());\n            if (!songMode.readableThemeSongProgressSession(source.session, source.memoryBank)) throw contract.songError('SOURCE', '这份歌曲草稿暂时无法读取，原内容仍保留。');\n            current = structuredClone(latest);\n        } else current = contract.normalizeStoredThemeSongs(latest);\n"
      },
      {
        "start": 152,
        "remove": 3,
        "old": "    if (snapshot) {\n",
        "new": "    if (shown.readableProgress?.complete === false && shown.readableProgress.draftId) {\n        updated = await mutatePartialSong(shown, mutate);\n    } else if (snapshot) {\n"
      },
      {
        "start": 196,
        "remove": 10,
        "old": "            if (session.songs.some(song => song.id === id)) { session.selectedId = id; renderThemeSongs(); }\n",
        "new": "            if (session.songs.some(song => song.id === id)) {\n                if (session.readableProgress?.complete === false && session.readableProgress.draftId && !readonly()) {\n                    const updated = await mutatePartialSong(session, latest => {\n                        if (latest.songs.some(song => song.id === id)) latest.selectedId = id;\n                        return latest;\n                    });\n                    if (runtimeState.activeSession === session) runtimeState.activeSession = updated;\n                } else session.selectedId = id;\n                if (runtimeState.activeMode === MODE) renderThemeSongs();\n            }\n"
      }
    ]
  }
};
function phase3AuthorizedSource(path, value) {
 const raw=String(value),spec=phase3AuthorizedDeltas[path];if(!spec)return value;
 const digest=createHash('sha256').update(raw).digest('hex');
 if(digest===spec.beforeSha256)return raw;
 assert.equal(digest,spec.afterSha256,path+' contains an unreviewed phase3 change');
 const lines=raw.match(/[^\n]*\n|[^\n]+$/g)||[];
 for(const part of [...spec.changes].reverse()){
  assert.equal(lines.slice(part.start,part.start+part.remove).join(''),part.new,'authorized hunk differs');
  lines.splice(part.start,part.remove,...(part.old.match(/[^\n]*\n|[^\n]+$/g)||[]));
 }
 const restored=lines.join('');
 assert.equal(createHash('sha256').update(restored).digest('hex'),spec.beforeSha256,'phase3 inverse differs from original');
 return restored;
}

const read=p=>r8412ContractSource(p,phase3AuthorizedSource(p,fs.readFileSync(new URL('../'+p,import.meta.url),'utf8')));
const sha=v=>createHash('sha256').update(v).digest('hex');
const same=JSON.parse(read('tests/helpers/r8411-unchanged.json'));
const changes=JSON.parse(read('tests/helpers/r8411-source-deltas.json'));
for(const dir of ['src/archive/','src/core/','src/generation/','src/modes/','src/ui/'])test('all untouched production files match r84.10: '+dir,()=>{
 for(const [path,hash] of Object.entries(same).filter(([path])=>path.startsWith(dir)))assert.equal(sha(read(path)),hash,path);
});
for(const [path,spec]of Object.entries(changes))test('r84.11 exact authorized diff and reversible baseline: '+path,()=>{
 assert.equal(sha(read(path)),spec.candidateSha256,path);assert.equal(sha(r8411ContractSource(path,read(path))),spec.baselineSha256);
});
test('bootstrap has only new version/cache identity and startup still cannot load song work',()=>{
 const stripped=read('index.js').replace("const VERSION = '0.8.87';","const VERSION = '0.8.86';")
  .replace("const BUILD = '0.8.87-tt-cg-r84.11-song-reader';","const BUILD = '0.8.86-tt-cg-r84.10-reader-cg';");
 assert.equal(sha(stripped),changes['index.js'].baselineSha256);
 assert.equal(policy.AUTO_UPDATE_MODES.includes(constants.MODE.THEME_SONG),false);
 const m=JSON.parse(read('manifest.json'));assert.equal(m.version,'0.8.87');assert.equal(m.js,'index.js?heartbeat=0.8.87-tt-cg-r84.11-song-reader');
});
function funcs(s){return [...s.matchAll(/^(?:export )?(?:async )?function ([\w$]+)\(/gm)].map((m,i,all)=>({name:m[1],source:s.slice(m.index,all[i+1]?.index??s.length)}));}
test('all existing HEART prompt builders and narrative validators remain verbatim',()=>{
 const s=read('src/modes/heart.js'),old=r8411ContractSource('src/modes/heart.js',s);
 for(const f of funcs(old).filter(x=>/Prompt|^normalize(HeartCore|HeartScript|HeartStripsPart|Heart$|VoiceDrama|ScenarioDrama|Firefly)/.test(x.name))) {
  const current=funcs(s).find(x=>x.name===f.name);assert.ok(current);assert.equal(current.source,f.source,f.name);
 }
});
test('single song uses existing generation/canonical cache pipeline and no external service/client',()=>{
 const s=read('src/modes/themeSong.js');assert.equal((s.match(/generation\.requestValidatedSegment\(/g)||[]).length,1);
 for(const file of ['src/core/themeSongContract.js','src/modes/themeSong.js','src/ui/themeSongStyles.js']) {
  assert.doesNotMatch(read(file),/\bfetch\s*\(|\beval\s*\(|\bFunction\s*\(|\blocalStorage\b|\bindexedDB\b|\bAuthorization\b|\bmanualApiKey\b|\bSuno\b/i,file);
 }
 assert.doesNotMatch(read('src/ui/themeSongView.js'),/\bfetch\s*\(|\beval\s*\(|\bFunction\s*\(|\bAuthorization\b|\bmanualApiKey\b|\.innerHTML\s*=\s*(?:song|content|lyrics|raw)|\bSuno\b/i);
 assert.match(read('src/ui/themeSongView.js'),/confirmExplicitActionTwice/);assert.match(read('src/ui/themeSongView.js'),/commitSessionMutation/);
});
test('all previous CG format and image transport modules remain byte identical',()=>{
 for(const [path,hash] of Object.entries(same).filter(([p])=>/cg[A-Z]|imageGeneration|baibaiImage|independentApi/.test(p)))assert.equal(sha(read(path)),hash,path);
 assert.equal(sha(read('src/generation/prompts.js')),'70a615e2af5dd680e80ba7b06f7ad502cffacf4a8c4d9ed22ea67039c3a5ff25');
});

test('phase3 exact authorized inverses reject additional source edits',()=>{
 for(const path of Object.keys(phase3AuthorizedDeltas)){
  const raw=fs.readFileSync(new URL('../'+path,import.meta.url),'utf8');
  assert.equal(createHash('sha256').update(String(phase3AuthorizedSource(path,raw))).digest('hex'),phase3AuthorizedDeltas[path].beforeSha256);
  assert.throws(()=>phase3AuthorizedSource(path,raw+'\n// unapproved mutation\n'),/unreviewed phase3 change/);
 }
});
