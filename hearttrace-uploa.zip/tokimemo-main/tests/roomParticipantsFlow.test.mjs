import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './helpers/r847Host.mjs';
import * as C from '../src/core/constants.js';
import * as cache from '../src/core/cache.js';
import * as participants from '../src/core/participants.js';
import * as contextApi from '../src/core/context.js';
import * as room from '../src/modes/room.js';
import * as client from '../src/generation/client.js';
import * as recovery from '../src/generation/recovery.js';
import * as coordinator from '../src/core/requestCoordinator.js';
import { state } from '../src/core/state.js';

const clone = value => structuredClone(value);
function roster(ids = ['p-east', 'p-west']) {
    return { version: 1, cardType: 'multi', revision: '', people: ids.map((id, index) => ({
        id, name: index === 0 ? '东房住户' : '西房住户',
        sourceRefs: [{ world: '同住设定', uid: String(index + 1), title: id,
            content: `${id} 的人物设定；${index === 0 ? '长发。' : '短发。'}` }],
    })), selectedIds: [...ids] };
}
function resident(id) {
    return { participantId: id, visualProfile: {},
        dayparts: Object.fromEntries(C.ROOM_DAYPART_KEYS.map(key => [key, {
            spaceId: 'SP01', activity: `${id}正在整理书架。`, line: `${id}：现在可以读书了。`, focusObjectId: 'OBJ01',
        }])), presenceLines: [`${id}的第一句。`, `${id}的第二句。`] };
}
function blueprint(ids = ['p-east', 'p-west']) {
    return { title: '共同房间', homeName: '共同住处', homeSummary: '住户们平日共用这间书房。', visualProfile: {},
        spaces: [{ id: 'SP01', label: '共用书房', spaceType: '书房', atmosphere: '晨光落在沿墙的书架上。', objects: [{
            id: 'OBJ01', label: '木盒', zone: '中央', basis: '设定', searchable: true,
            description: '一只装着常用工具的木盒。', line: '工具就在这里。', speakerId: ids[0] || '', sourceMemoryIds: [], sourceMemoryAnchor: '',
        }] }], residents: ids.map(resident) };
}
function lifeActor(id, line = `${id}：该读书了。`) {
    return { participantId: id, spaceId: 'SP01', activity: `${id}正在整理书页。`, line, focusObjectId: 'OBJ01',
        ambient: '晨光照亮书桌。', trace: '书页摊开着。', visualState: {}, temporaryObjects: [], sourceMemoryIds: [], sourceMemoryAnchor: '' };
}
async function multiplayerFixture(t, ids) {
    const f = await fixture(t);
    t.after(() => room.stopRoomClock());
    const saved = await cache.commitParticipantRoster(f.ctx, roster(ids));
    const snapshot = participants.selectedParticipantSnapshot(saved);
    return { ...f, roster: saved, snapshot };
}

test('one real ROOM request produces two independent residents inside one shared room and renders both', async t => {
    const f = await multiplayerFixture(t);
    const oldName = f.ctx.name2;
    f.setResponse(blueprint());
    const generated = await client.generateMode(C.MODE.ROOM, { background: true });
    assert.ok(generated, JSON.stringify(f.diagnostics));
    assert.equal(f.requests.length, 1, 'one valid reply covers all selected people');
    assert.equal(f.ctx.name2, oldName, 'host card identity is never rewritten');
    assert.deepEqual(generated.participantSnapshot, f.snapshot);
    assert.deepEqual(generated.residents.map(row => row.participantId), ['p-east', 'p-west']);
    assert.equal(generated.spaces.length, 1);
    assert.equal(generated.spaces[0].objects[0].speakerId, 'p-east');
    const stored = await f.persisted();
    assert.deepEqual(stored.room.participantSnapshot, f.snapshot);
    assert.deepEqual(stored[participants.PARTICIPANTS_KEY], f.roster);
    state.activeMode = C.MODE.ROOM; state.activeSession = generated;
    room.renderRoom();
    assert.match(f.body.innerHTML, /data-rmt-participant-state="p-east"/);
    assert.match(f.body.innerHTML, /data-rmt-participant-state="p-west"/);
    assert.match(f.body.innerHTML, /东房住户的话/);
    assert.equal((f.body.innerHTML.match(/class="rmt-room-resident-figure"/g) || []).length, 2);
    const beforeRoster = clone(cache.readParticipantRoster(f.ctx));
    room.roomSelectParticipant('p-west');
    assert.match(f.body.innerHTML, /p-west的第一句/);
    room.roomSelectParticipant('p-west');
    assert.match(f.body.innerHTML, /p-west的第二句/);
    assert.equal(generated.residents[0].presenceIndex, 0);
    assert.deepEqual(cache.readParticipantRoster(f.ctx), beforeRoster, 'view selection does not edit injection selection');
});

test('a provider response for roster A keeps A while a foreground roster B commit remains current', async t => {
    const f = await multiplayerFixture(t);
    f.setResponse(blueprint());
    const pause = f.pauseProvider();
    const pending = client.generateMode(C.MODE.ROOM, { background: true });
    await pause.ready;
    let newer;
    try { newer = await cache.commitParticipantRoster(f.ctx, roster(['p-new']), { expectedRevision: f.roster.revision }); }
    finally { pause.release(); }
    const generated = await pending;
    assert.ok(generated, JSON.stringify(f.diagnostics));
    assert.deepEqual(generated.participantSnapshot, f.snapshot);
    assert.deepEqual(cache.readParticipantRoster(f.ctx), newer);
    const stored = await f.persisted();
    assert.deepEqual(stored.room.participantSnapshot, f.snapshot);
    assert.deepEqual(stored[participants.PARTICIPANTS_KEY], newer);
});

test('repair and recovery retain the original people, replay saved blueprint, and request only the unfinished fields', async t => {
    const f = await multiplayerFixture(t);
    const raw = blueprint(); raw.residents[0].dayparts.morning.line = '';
    let calls = 0;
    f.setResponse(() => {
        calls++;
        if (calls === 1) return raw;
        throw Object.assign(new Error('synthetic repair failure'), { code: 'RMT_MANUAL_HTTP', status: 400 });
    });
    assert.equal(await client.generateMode(C.MODE.ROOM, { background: true }), null);
    const draft = cache.loadGenerationRecovery(C.MODE.ROOM, f.ctx);
    assert.ok(draft?.segments.some(segment => segment.state === 'complete'));
    assert.deepEqual(JSON.parse(draft.frozenInputs['participants:room']), f.snapshot);
    const next = await cache.commitParticipantRoster(f.ctx, roster(['p-new']), { expectedRevision: f.roster.revision });
    f.setResponse({ repairs: [{ path: ['residents', 0, 'dayparts', 'morning', 'line'], text: '现在书架已经整理好了。' }] });
    const count = f.requests.length;
    const resumed = await client.generateMode(C.MODE.ROOM, { background: true, continueRecovery: true });
    assert.ok(resumed, JSON.stringify(f.diagnostics));
    assert.equal(f.requests.length, count + 1);
    assert.deepEqual(resumed.participantSnapshot, f.snapshot);
    assert.deepEqual(cache.readParticipantRoster(f.ctx), next);
    assert.equal(resumed.residents[0].dayparts.morning.line, '现在书架已经整理好了。');
});

test('legacy retained ROOM recovery does not suddenly inject a later multiplayer selection', async t => {
    const f = await multiplayerFixture(t);
    const origin = contextApi.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision);
    let journal;
    const handle = await recovery.createGenerationRecovery({ origin, mode: C.MODE.ROOM, settingsIdentity: 'test', save: raw => { journal = clone(raw); return true; } });
    recovery.attachGenerationRecovery(origin, handle);
    t.after(() => recovery.detachGenerationRecovery(origin));
    assert.equal(await client.captureRoomParticipantSnapshot(f.ctx, origin, { existing: { segments: [] } }), null);
    assert.equal(journal, undefined, 'legacy recovery must not write a new multiplayer key');
});

test('same-minute participants and all later independent locations survive shared-life normalization', async t => {
    const f = await multiplayerFixture(t);
    const session = room.normalizeRoom(blueprint(), f.liveBank, { participantSnapshot: f.snapshot });
    const date = new Date(2026, 8, 19, 12, 0);
    const raw = { beats: [
        { time: '06:40', participants: [lifeActor('p-east')] },
        { time: '06:40', participants: [lifeActor('p-west')] },
        { time: '09:30', participants: [lifeActor('p-west', '现在换一本书。')] },
    ] };
    const before = clone(raw);
    const plan = room.normalizeRoomLifePlan(raw, session, f.liveBank, date, { participantSnapshot: f.snapshot });
    assert.equal(plan.beats.length, 2);
    assert.deepEqual(plan.beats[0].participants.map(row => row.participantId), ['p-east', 'p-west']);
    session.lifePlan = plan;
    const current = room.roomParticipantSlots(session, date);
    assert.equal(current.find(row => row.participantId === 'p-east').line, 'p-east：该读书了。');
    assert.equal(current.find(row => row.participantId === 'p-west').line, '现在换一本书。');
    assert.deepEqual(raw, before);
    assert.throws(() => room.normalizeRoomLifePlan({ beats: [{ time: '06:40', participants: [lifeActor('unknown')] }] }, session, f.liveBank, date, { participantSnapshot: f.snapshot }));
});

test('daily-life uses one actual request for all residents and persists its captured snapshot', async t => {
    const f = await multiplayerFixture(t);
    f.setResponse(blueprint());
    const generated = await client.generateMode(C.MODE.ROOM, { background: true });
    state.activeMode = C.MODE.ROOM; state.activeSession = generated;
    f.setResponse({ beats: [{ time: '06:40', participants: [lifeActor('p-east'), lifeActor('p-west')] }] });
    const before = f.requests.length;
    const plan = await room.ensureRoomLifePlan({ force: true, quiet: true });
    assert.ok(plan, JSON.stringify(f.diagnostics));
    assert.equal(f.requests.length, before + 1);
    assert.deepEqual(plan.participantSnapshot, f.snapshot);
    assert.equal(plan.beats[0].participants.length, 2);
    assert.deepEqual((await f.persisted()).room.lifePlan.participantSnapshot, f.snapshot);
});

test('multiplayer incremental additions retain every old object, image, unattributed line, and resident', async t => {
    const f = await multiplayerFixture(t);
    const old = room.normalizeRoom(blueprint(), f.liveBank, { participantSnapshot: f.snapshot });
    old.spaces[0].objects[0].imageUrl = 'local-old-image-sentinel';
    delete old.spaces[0].objects[0].speakerId;
    old.presenceLines = ['旧台词的原文。'];
    const before = clone(old), requests = [];
    const nextRoster = roster(['p-east', 'p-west', 'p-new']);
    const next = participants.selectedParticipantSnapshot(nextRoster);
    const fresh = await room.generateRoomIncrementalWithRepair(f.ctx, f.liveBank, null, 'test-increment', old, {
        participantSnapshot: next, allowPersonaExpansion: true,
        request: async (prompt, status, options, validate) => {
            requests.push(prompt);
            return validate({ additions: [{ spaceId: 'SP01', objects: [{ id: 'NEW01', label: '便签纸', zone: '中央', basis: '推演',
                description: '空白便签整齐叠在桌边。', line: '可以用这些便签。', speakerId: 'p-new', sourceMemoryIds: [], sourceMemoryAnchor: '' }] }], residents: [resident('p-new')] });
        },
    });
    assert.equal(requests.length, 1);
    assert.deepEqual(fresh.spaces[0].objects[0], before.spaces[0].objects[0]);
    assert.deepEqual(fresh.presenceLines, before.presenceLines);
    assert.deepEqual(fresh.residents.slice(0, 2), before.residents);
    assert.equal(fresh.spaces[0].objects[1].speakerId, 'p-new');
    assert.deepEqual(old, before);
    state.activeMode = C.MODE.ROOM; state.activeSession = fresh;
    room.renderRoom();
    assert.match(f.body.innerHTML, /未标注说话人/);
    assert.match(f.body.innerHTML, /旧台词的原文/);
});

test('figure refresh binds each appearance to its own selected source without replacing room content', async t => {
    const f = await multiplayerFixture(t);
    const old = room.normalizeRoom(blueprint(), f.liveBank, { participantSnapshot: f.snapshot });
    old.spaces[0].objects[0].imageUrl = 'unchanged-image';
    const before = clone(old), prompts = [];
    const result = await room.refreshRoomFigure(f.ctx, f.liveBank, null, 'figure-test', old, {
        participantSnapshot: f.snapshot, request: async (prompt, status, options, validate) => {
            prompts.push(prompt);
            return validate({ residents: [
                { participantId: 'p-east', visualProfile: { figure: { hairShape: 'long' }, explicitFields: ['figure.hairShape'], explicitEvidence: { 'figure.hairShape': '长发。' } } },
                { participantId: 'p-west', visualProfile: { figure: { hairShape: 'short' }, explicitFields: ['figure.hairShape'], explicitEvidence: { 'figure.hairShape': '短发。' } } },
            ] });
        },
    });
    assert.equal(prompts.length, 1);
    assert.equal(result.residents[0].visualProfile.figure.hairShape, 'long');
    assert.equal(result.residents[1].visualProfile.figure.hairShape, 'short');
    assert.deepEqual(result.spaces, before.spaces);
    assert.deepEqual(result.residents.map(row => row.dayparts), before.residents.map(row => row.dayparts));
    assert.deepEqual(old, before);
});

test('legacy normalization adds no participant fields and keeps legacy daily schema', async t => {
    const f = await fixture(t);
    const raw = blueprint(['legacy']);
    raw.dayparts = resident('legacy').dayparts;
    raw.presenceLines = ['这是原来的单人台词。'];
    const normalized = room.normalizeRoom(raw, f.liveBank);
    assert.equal(Object.hasOwn(normalized, 'participantSnapshot'), false);
    assert.equal(Object.hasOwn(normalized, 'residents'), false);
    assert.equal(Object.hasOwn(normalized.spaces[0].objects[0], 'speakerId'), false);
    const single = { ...lifeActor('legacy'), time: '07:00' }; delete single.participantId;
    const plan = room.normalizeRoomLifePlan({ beats: [single] }, normalized, f.liveBank, new Date(2026, 8, 19));
    assert.equal(Object.hasOwn(plan, 'participantSnapshot'), false);
    assert.equal(Object.hasOwn(plan.beats[0], 'participants'), false);
});

test('cancelling the whole daily task settles without fallback or late provider writes', { timeout: 10000 }, async t => {
    const f = await multiplayerFixture(t);
    f.setResponse(blueprint());
    const generated = await client.generateMode(C.MODE.ROOM, { background: true });
    state.activeMode = C.MODE.ROOM; state.activeSession = generated;
    const before = clone((await f.persisted()).room);
    f.setResponse({ beats: [{ time: '06:40', participants: [lifeActor('p-east'), lifeActor('p-west')] }] });
    const gate = f.pauseProvider();
    const running = room.ensureRoomLifePlan({ force: true, quiet: true });
    await gate.ready;
    const tasks = coordinator.queryParticipantGenerationTasks(f.ctx);
    const task = tasks.find(row => row.kind === 'room-daily-life');
    assert.ok(task, 'UI can identify the complete daily task');
    const settled = await coordinator.cancelParticipantGenerationTasks([task.id]);
    assert.equal(settled[0].status, 'cancelled');
    assert.equal(await running, null);
    const cancelledRoom = clone((await f.persisted()).room);
    assert.notEqual(cancelledRoom[C.SESSION_MODE_WRITE_FENCE_KEY], before[C.SESSION_MODE_WRITE_FENCE_KEY], 'the admitted task legitimately claimed a new write fence');
    assert.deepEqual({ ...cancelledRoom, [C.SESSION_MODE_WRITE_FENCE_KEY]: before[C.SESSION_MODE_WRITE_FENCE_KEY] }, before,
        'only the admission fence may change; no content, attempt count, or fallback is written');
    assert.equal(state.roomLifeRefreshPromise, null);
    gate.release();
    await new Promise(resolve => setImmediate(resolve));
    assert.deepEqual((await f.persisted()).room, cancelledRoom, 'a billed transport may finish late but cannot replace saved content or its fence');
    assert.equal(coordinator.queryParticipantGenerationTasks(f.ctx).length, 0);
});

test('a cancelled plan propagates to its current real child and remains pending until owner cleanup', { timeout: 10000 }, async t => {
    const f = await multiplayerFixture(t);
    f.setResponse(blueprint());
    const origin = contextApi.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision);
    const plan = coordinator.beginLogicalGenerationTask({ kind: 'participant-plan', pageIds: ['room', 'inbox'], context: f.ctx, origin });
    const gate = f.pauseProvider();
    const running = client.generateMode(C.MODE.ROOM, { background: true, logicalParentTaskId: plan.id });
    await gate.ready;
    const child = coordinator.queryParticipantGenerationTasks(f.ctx).find(row => row.parentTaskId === plan.id);
    assert.equal(child.mode, C.MODE.ROOM);
    let settled = false;
    const cancelled = coordinator.cancelParticipantGenerationTasks([plan.id]).then(value => { settled = true; return value; });
    assert.equal(await running, null);
    assert.equal(settled, false, 'cancelling a segment does not declare the owner loop complete');
    assert.throws(() => coordinator.assertLogicalGenerationTaskCurrent(plan), { name: 'AbortError' });
    coordinator.finishLogicalGenerationTask(plan, { status: 'cancelled' });
    assert.equal((await cancelled)[0].status, 'cancelled');
    gate.release();
    await new Promise(resolve => setImmediate(resolve));
    assert.equal(cache.loadSession(C.MODE.ROOM, { context: f.ctx, memoryBank: f.liveBank }), null);
    assert.equal(f.requests.length, 1);
});

test('room-only replacement preserves every old linked ID through canonical save and reload without title matching', async t => {
    const f = await multiplayerFixture(t);
    const previous = room.normalizeRoom(blueprint(), f.liveBank, { participantSnapshot: f.snapshot });
    previous.spaces = Array.from({ length: 13 }, (_, index) => ({ ...clone(previous.spaces[0]), id: `SP${index + 1}`,
        objects: [{ ...clone(previous.spaces[0].objects[0]), id: `OLD_OBJ_${index + 1}`, imageUrl: `old-image-${index + 1}` }] }));
    previous.lifePlan = { dateKey: '2026-09-19', beats: [{ time: '06:40', spaceId: 'SP13', focusObjectId: 'OLD_OBJ_13', line: '原生活' }] };
    previous.lifePlanAttempt = { dateKey: '2026-09-19', count: 0, failedAt: 0 };
    const fresh = room.normalizeRoom(blueprint(), f.liveBank, { participantSnapshot: f.snapshot });
    fresh.spaces[0].id = 'SP1';
    for (const resident of fresh.residents) for (const slot of Object.values(resident.dayparts)) slot.spaceId = 'SP1';
    fresh.selectedSpaceId = 'SP1';
    const expectedOld = clone(previous);
    const merged = room.preserveRoomLinkedContent(previous, fresh);
    assert.notEqual(merged.residents[0].dayparts.morning.spaceId, 'SP1', 'same title and reused generated ID must not bind a new room to an old physical target');
    assert.deepEqual(merged.lifePlan, previous.lifePlan);
    for (const space of previous.spaces) assert.deepEqual(merged.spaces.find(row => row.id === space.id), space);
    assert.deepEqual(previous, expectedOld);
    assert.ok(await cache.commitSession(C.MODE.ROOM, merged, f.liveBank.chatId));
    const reopened = cache.loadSession(C.MODE.ROOM, { context: f.ctx, memoryBank: f.liveBank, clone: true });
    assert.equal(reopened.spaces.length, 14);
    for (const space of previous.spaces) assert.deepEqual(reopened.spaces.find(row => row.id === space.id), space);
    assert.deepEqual(reopened.lifePlan, previous.lifePlan);
});

for (const legacyResume of [false, true]) test(`real room-only regeneration preserves unselected life and linked content (${legacyResume ? 'legacy saved task resume' : 'new task'})`, async t => {
    const f = await multiplayerFixture(t);
    f.setResponse(blueprint());
    const original = await client.generateMode(C.MODE.ROOM, { background: true });
    state.activeMode = C.MODE.ROOM; state.activeSession = original;
    f.setResponse({ beats: [{ time: '06:40', participants: [lifeActor('p-east', 'UNSELECTED_LIFE_SENTINEL'), lifeActor('p-west')] }] });
    await room.ensureRoomLifePlan({ force: true, quiet: true });
    const previous = clone((await f.persisted()).room);
    assert.ok(previous.lifePlan?.beats?.length, 'the actual earlier life task must already be durable');
    const version = await cache.saveArchiveVersion(f.ctx, { selectedPages: ['room'] });
    const nextRoster = await cache.commitParticipantRoster(f.ctx, roster(['p-east', 'p-west', 'p-new']), { expectedRevision: f.roster.revision });
    const ticket = { versionId: version.versionId, pageId: 'room', participantSnapshot: participants.selectedParticipantSnapshot(nextRoster) };
    const beforeRequests = f.requests.length;
    if (legacyResume) {
        f.setResponse(() => { throw Object.assign(new Error('synthetic retained room request'), { code: 'RMT_MANUAL_HTTP', status: 400 }); });
        await client.generateMode(C.MODE.ROOM, { background: true, participantRegeneration: ticket });
        const stored = await f.persisted(), draft = cache.loadGenerationRecovery(C.MODE.ROOM, f.ctx, stored);
        assert.ok(draft?.segments.some(row => row.state === 'retry'));
        // Old drafts froze previousSession:null for replacement. Their durable
        // version remains the authoritative source of unselected linked content.
        delete draft.contentSnapshot.contentInputs.linkedRoomSession;
        stored[cache.GENERATION_DRAFTS_CACHE_KEY].records[draft.draftId].journal = draft;
        const record = clone(f.records.get(f.aEntry.entryId)); record.cache = stored; f.records.set(f.aEntry.entryId, record);
        f.ctx.chatMetadata[C.CACHE_KEY] = clone(stored);
        state.runtimeSessionCache.clear(); await cache.ensureCacheHydrated(f.ctx);
    }
    f.setResponse(blueprint(['p-east', 'p-west', 'p-new']));
    if (legacyResume) await client.continueSavedGeneration(C.MODE.ROOM);
    else await client.generateMode(C.MODE.ROOM, { background: true, participantRegeneration: ticket });
    const saved = (await f.persisted()).room;
    assert.deepEqual(saved.lifePlan, previous.lifePlan, 'unselected life remains exact after the real replacement pipeline');
    assert.deepEqual(saved.lifePlanAttempt, previous.lifePlanAttempt);
    assert.deepEqual(saved.pets, previous.pets);
    for (const space of previous.spaces) assert.deepEqual(saved.spaces.find(row => row.id === space.id), space);
    assert.equal(saved.residents.length, 3);
    assert.notEqual(saved.residents[0].dayparts.morning.spaceId, previous.spaces[0].id, 'new room must not steal the old linked space ID');
    assert.equal(f.requests.length, beforeRequests + (legacyResume ? 2 : 1));
    assert.doesNotMatch(JSON.stringify(f.requests.slice(beforeRequests)), /UNSELECTED_LIFE_SENTINEL/, 'linked content is preservation data, not extra prompt context');
    if (legacyResume) assert.deepEqual(f.requests.at(-1), f.requests.at(-2), 'resume retains the actual original replacement request');
    assert.deepEqual((await cache.readArchiveVersion(f.ctx, version.versionId)).cache.room, previous);
    state.runtimeSessionCache.clear(); await cache.ensureCacheHydrated(f.ctx);
    assert.deepEqual(cache.loadSession(C.MODE.ROOM, { context: f.ctx, memoryBank: f.liveBank }).lifePlan, previous.lifePlan);
});
