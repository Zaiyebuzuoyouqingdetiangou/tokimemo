import test from 'node:test';
import assert from 'node:assert/strict';
import {fixture} from './helpers/r847Host.mjs';
import * as R from '../src/archive/repository.js';
import * as recovery from '../src/archive/importRecovery.js';
import * as context from '../src/core/context.js';
import * as settings from '../src/core/settings.js';
import * as client from '../src/generation/client.js';
import * as cache from '../src/core/cache.js';
import * as C from '../src/core/constants.js';
import {state} from '../src/core/state.js';
import * as runtime from '../src/heartbeatMemories.js';
const clone=x=>structuredClone(x);
const profile={archiveName:'一同栽花',relationshipReading:{char:'共同栽花',user:'共同参与',relation:'相伴',tension:'未记载',direction:'相伴'},verdictStyle:'quiet-life',archiveVerdict:'两个人一起在庭院栽花，这份记录呈现的是他们共同参与一件小事的经历。花苗慢慢立在土中，他们的关系仍应由已经发生的事实来理解，不需要提前给尚未表达的感情加上名字。对话没有说明更远的约定，档案也只留下这次相伴本身，以及两人愿意共同花费的时间。',verdictSources:[{memoryId:'M001',anchor:'庭院'}],keywords:['庭院','栽花']};
function encode(value,{format='sse',broken=false,truncated=false,type=null}={}) {
 let data;
 if(broken)data='data: {invalid\n\n';
 else if(format==='json')data=JSON.stringify({choices:[{index:0,message:{role:'assistant',content:JSON.stringify(value)},finish_reason:'stop'}]});
 else data=`data: ${JSON.stringify({choices:[{index:0,delta:{content:JSON.stringify(value)},finish_reason:null}]})}\n\n`+(truncated?'':'data: {"choices":[{"index":0,"delta":{},"finish_reason":"stop"}]}\n\n');
 const raw=new TextEncoder().encode(data);let offset=0;
 const body=new ReadableStream({pull(c){if(offset>=raw.length){c.close();return;}const end=Math.min(offset+13,raw.length);c.enqueue(raw.subarray(offset,end));offset=end;}},{highWaterMark:0});
 return new Response(body,{headers:type?{'Content-Type':type}:{}});
}
async function setup(t,options={}) {
 const f=await fixture(t);settings.updatePluginSettings({apiConnectionMode:'manual',manualApiBaseUrl:'https://fixture.invalid/api/coding/v3',manualApiModel:'fixture-model',manualApiKey:'',manualApiStreaming:options.requested??true,maxTokens:12000});
 R.setMemoryWorldInfoSelection(f.ctx,{books:[]});const origin=context.captureTaskOrigin(f.ctx,f.liveBank.archiveRevision);recovery.clearArchiveRecovery(origin);
 t.after(()=>{recovery.clearArchiveRecovery(origin);recovery.clearArchiveRecovery(context.captureTaskOrigin(f.ctx,R.getImportedMemory(f.ctx)?.archiveRevision||''));});
 let responseOptions={...options},hook=null;const calls=[];const originalFetch=globalThis.fetch;
 globalThis.fetch=async(url,opts)=>{
  if(url!=='/api/backends/chat-completions/generate')return originalFetch(url,opts);
  const body=JSON.parse(opts.body);assert.equal(body.custom_url,'https://fixture.invalid/api/coding/v3');assert.equal(body.stream,options.requested??true);calls.push(clone(body));if(hook)await hook();
  const prompt=body.messages.map(x=>x.content).join('\n');const value=prompt.includes('UNTRUSTED_CHAT_JSON:')?{memories:[{title:'栽花',summary:'两人一同在庭院栽花。',anchors:['庭院','花'],participants:['林舟','小月'],messageStart:0,messageEnd:0}]}:profile;
  return encode(value,responseOptions);
 };
 return {...f,calls,origin,reply:opt=>{responseOptions={...options,...opt}},pause:()=>{let enter,release;const ready=new Promise(r=>enter=r),wait=new Promise(r=>release=r);hook=async()=>{enter();await wait;};return{ready,release}}};
}
for(const opt of [{requested:true,type:null},{requested:false,type:null},{requested:true,type:'application/json'},{requested:true,type:'text/plain'},{requested:false,type:'text/event-stream',format:'json'},{requested:true,type:null,format:'json'}])test('real archive import -> transport -> evidence -> canonical save -> reopen '+JSON.stringify(opt),async t=>{
 const f=await setup(t,opt),chat=JSON.stringify(f.ctx.chat);const result=await R.importCurrentChatMemory({fullRebuild:true,automatic:true});assert.equal(result.status,'committed',JSON.stringify(f.notices));
 const bank=R.getImportedMemory(f.ctx);assert.equal(bank.memories.length,1);assert.equal(bank.memories[0].summary,'两人一同在庭院栽花。');assert.ok(bank.memories[0].anchors.includes('庭院'));assert.equal(f.calls.length,2,'one extraction + one archive profile, no retry');
 assert.equal(JSON.stringify(f.ctx.chat),chat);const saved=[...f.records.values()].find(r=>r.memory?.archiveRevision===bank.archiveRevision);assert.ok(saved);assert.deepEqual(saved.memory.memories,bank.memories);
 state.runtimeSessionCache.clear();await cache.ensureCacheHydrated(f.ctx);assert.deepEqual(R.getImportedMemory(f.ctx).memories,saved.memory.memories);
 assert.equal(state.activeProviderRequestCount,0);assert.equal(state.providerRequestQueue.length,0);
});
for(const opt of [{broken:true},{truncated:true}])test('bad/incomplete transport never commits archive or retries silently '+JSON.stringify(opt),async t=>{
 const f=await setup(t,opt),before=JSON.stringify(f.ctx.chatMetadata),records=JSON.stringify([...f.records]),chat=JSON.stringify(f.ctx.chat);
 const result=await R.importCurrentChatMemory({fullRebuild:true,automatic:true});assert.equal(result.status,'failed');assert.equal(f.calls.length,1);assert.equal(JSON.stringify(f.ctx.chatMetadata),before);assert.equal(JSON.stringify([...f.records]),records);assert.equal(JSON.stringify(f.ctx.chat),chat);assert.equal(state.activeProviderRequestCount,0);
});
test('explicit retry of failed zero-success archive uses same prompt and no implicit restart',async t=>{
 const f=await setup(t,{broken:true});assert.equal((await R.importCurrentChatMemory({fullRebuild:true,automatic:true})).status,'failed');assert.equal(f.calls.length,1);
 f.reply({broken:false});const result=await R.continueCurrentArchiveImport();assert.equal(result.status,'committed',JSON.stringify(f.notices));assert.equal(f.calls.length,3);assert.deepEqual(f.calls[0],f.calls[1]);assert.equal(state.activeProviderRequestCount,0);
});
for(const change of ['model','chat-body','persona'])test('archive retry preserves its captured content after changed '+change,async t=>{
 const f=await setup(t,{broken:true});await R.importCurrentChatMemory({fullRebuild:true,automatic:true});f.reply({broken:false});
 if(change==='model')settings.updatePluginSettings({manualApiModel:'different-model'});if(change==='chat-body')f.ctx.chat[0].mes+=' changed';if(change==='persona')f.ctx.userAvatar='different-persona';
 const result=await R.continueCurrentArchiveImport().catch(e=>{assert.equal(e.code,'RMT_RECOVERY_INPUT_CHANGED');return null});
 assert.equal(result?.status,'committed',JSON.stringify(f.notices));assert.equal(f.calls.length,3);
 assert.deepEqual(f.calls[1].messages,f.calls[0].messages,'the original request content survives later source changes');
 assert.equal(f.calls[1].model,change==='model'?'different-model':'fixture-model');
 assert.equal(f.calls[2].model,change==='model'?'different-model':'fixture-model');
});
test('a delayed successful response after lifecycle end cannot replace the old archive',async t=>{
 const f=await setup(t),before=JSON.stringify(f.ctx.chatMetadata[C.MEMORY_KEY]),pause=f.pause();const pending=R.importCurrentChatMemory({fullRebuild:true,automatic:true});await pause.ready;runtime.destroyMemoryTheater();pause.release();
 const result=await pending;assert.notEqual(result.status,'committed');assert.equal(f.calls.length,1);assert.equal(JSON.stringify(f.ctx.chatMetadata[C.MEMORY_KEY]),before);assert.equal(state.activeProviderRequestCount,0);
});
for(const format of ['sse','json'])test('regular non-archive request uses unchanged final JSON and domain validation '+format,async t=>{
 const f=await setup(t,{format});globalThis.fetch=async()=>encode({hello:'普通模式 JSON',num:1},{format});const before=JSON.stringify(f.ctx.chatMetadata);
 const value=await client.requestJson('合成模式请求','',{background:true});assert.deepEqual(value,{hello:'普通模式 JSON',num:1});assert.equal(JSON.stringify(f.ctx.chatMetadata),before);assert.equal(state.activeProviderRequestCount,0);
});
test('profile connection does not enter manual transport or change outputs',async t=>{
 const f=await fixture(t);f.setResponse({marker:'profile-unmodified'});const value=await client.requestJson('PROFILE_SYNTHETIC','',{background:true});assert.deepEqual(value,{marker:'profile-unmodified'});assert.equal(f.requests.length,1);assert.equal(f.reads.length,0);
});
