import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { mkdtempSync, readFileSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { archiveFixture, sourceRows, memoryReply, requestRows } from './helpers/r8422ArchiveHost.mjs';
import { localFixture } from './helpers/r8425LocalHost.mjs';
import * as R from '../src/archive/repository.js';
import * as D from '../src/archive/importRecovery.js';
import * as settings from '../src/core/settings.js';
import * as C from '../src/core/constants.js';
import * as cache from '../src/core/cache.js';
import * as context from '../src/core/context.js';
import * as library from '../src/archive/library.js';
import { state } from '../src/core/state.js';

const clone = value => structuredClone(value);
const sha = value => createHash('sha256').update(JSON.stringify(value)).digest('hex');
const addedA = 'ADDED_AFTER_PAID_DRAFT_A：后来又一起整理花架。';
const addedB = 'ADDED_AFTER_PAID_DRAFT_B：随后两人检查了新花盆。';
const profileReply = () => ({ archiveName: '一同栽花', verdictStyle: 'quiet-life',
    relationshipReading: { char: '共同栽花', user: '共同参与', relation: '相伴', tension: '未记载', direction: '相伴' },
    archiveVerdict: '两个人一起在庭院栽花，这份记录呈现的是他们共同参与一件小事的经历。花苗慢慢立在土中，他们的关系仍应由已经发生的事实来理解，不需要提前给尚未表达的感情加上名字。对话没有说明更远的约定，档案也只留下这次相伴本身，以及两人愿意共同花费的时间。',
    verdictSources: [{ memoryId: 'M001', anchor: '庭院' }], keywords: ['庭院', '栽花'] });
const validReply = messages => requestRows(messages).kind === 'profile' ? profileReply() : memoryReply(messages);

async function make(t, operation) {
    const f = await archiveFixture(t, { rows: operation === 'import' ? sourceRows(18, 5200) : [] });
    const local = localFixture(t);
    return { ...f, local, operation };
}
async function seed(f) {
    let calls = 0;
    f.setResponse(messages => {
        calls++;
        if (calls === (f.operation === 'import' ? 2 : 1)) throw Object.assign(new Error('synthetic interrupted request'), { code: 'RMT_JSON_INVALID' });
        return validReply(messages);
    });
    const oldMemory = clone(R.getImportedMemory(f.ctx)), oldCache = await f.persisted();
    const result = f.operation === 'import' ? await R.importCurrentChatMemory() : await R.rewriteCurrentArchiveVerdict();
    assert.equal(result.status, 'failed', JSON.stringify(f.notices));
    const origin = context.captureTaskOrigin(f.ctx, oldMemory.archiveRevision);
    await D.flushArchiveRecovery(origin, f.operation);
    const draft = D.exportArchiveRecovery(origin, f.operation)[0];
    assert.ok(draft.inputs?.taskInputV1, 'a real failed task must save the original content snapshot');
    assert.doesNotMatch(JSON.stringify(draft), /fixture-only|private-api-secret/, 'no transport credentials enter the content checkpoint');
    assert.equal(draft.journal.segments.filter(row => row.state === 'complete').length, f.operation === 'import' ? 1 : 0);
    assert.deepEqual(R.getImportedMemory(f.ctx), oldMemory);
    return { oldMemory, oldCache, firstRequests: clone(f.requests), draft };
}
function changeInputs(f, scenario) {
    if (scenario.includes('append')) f.ctx.chat.push(
        { is_user: true, name: f.ctx.name1, mes: addedA },
        { is_user: false, name: f.ctx.name2, mes: addedB });
    const routes = [];
    if (scenario.includes('api')) {
        settings.updatePluginSettings({ apiConnectionMode: 'manual', manualApiBaseUrl: 'https://resume.invalid/v1',
            manualApiModel: 'new-resume-model', manualApiKey: '', manualApiStreaming: false });
        const previousFetch = globalThis.fetch;
        globalThis.fetch = async (url, options) => {
            if (url !== '/api/backends/chat-completions/generate') return previousFetch(url, options);
            const body = JSON.parse(options.body);
            routes.push({ url: body.custom_url, model: body.model });
            f.requests.push(clone(body.messages));
            return new Response(JSON.stringify({ choices: [{ message: { content: JSON.stringify(validReply(body.messages)) }, finish_reason: 'stop' }] }),
                { headers: { 'Content-Type': 'application/json' } });
        };
    } else f.setResponse(validReply);
    if (scenario.includes('content')) settings.updatePluginSettings({ creativeSupplementEnabled: true, creativeSupplement: 'NEW_CONTENT_MUST_NOT_ENTER_OLD_TASK' });
    return routes;
}

function rawTransport(f, respond) {
    settings.updatePluginSettings({ apiConnectionMode: 'manual', manualApiBaseUrl: 'https://archive-reader.invalid/v1',
        manualApiModel: 'archive-reader-model', manualApiKey: '', manualApiStreaming: false });
    const previousFetch = globalThis.fetch;
    globalThis.fetch = async (url, options) => {
        if (url !== '/api/backends/chat-completions/generate') return previousFetch(url, options);
        const body = JSON.parse(options.body);
        f.requests.push(clone(body.messages));
        const reply = await respond(body.messages);
        return new Response(JSON.stringify({ choices: [{ message: { content: reply.raw ?? JSON.stringify(reply.value) },
            finish_reason: reply.finish || 'stop' }] }), { headers: { 'Content-Type': 'application/json' } });
    };
}

function profileFromImportedRows(messages) {
    const prompt = messages.map(row => row.content).join('\n');
    const marker = 'UNTRUSTED_MEMORY_LIST:\n', at = prompt.lastIndexOf(marker);
    const memories = JSON.parse(prompt.slice(at + marker.length));
    return { ...profileReply(), verdictSources: [{ memoryId: memories[0].id, anchor: memories[0].anchors?.[0] || memories[0].title }] };
}
async function resumeAndCheck(f, before, scenario, { reloaded = false } = {}) {
    const routes = changeInputs(f, scenario);
    await R.hydrateCurrentArchiveRecovery(f.ctx);
    const start = f.requests.length;
    const result = f.operation === 'import' ? await R.continueCurrentArchiveImport() : await R.rewriteCurrentArchiveVerdict();
    assert.equal(result.status, 'committed', JSON.stringify(f.notices));
    const sent = f.requests.slice(start);
    assert.ok(sent.length > 0);
    assert.equal(sha(sent[0]), sha(before.firstRequests.at(-1)), 'the original failed request resumes byte for byte');
    if (f.operation === 'import') {
        assert.equal(sent.filter(row => sha(row) === sha(before.firstRequests[0])).length, 0, 'the paid successful segment is never sent again');
        assert.deepEqual(R.getImportedMemory(f.ctx).memories[0], before.oldMemory.memories[0]);
    } else assert.deepEqual(R.getImportedMemory(f.ctx).memories, before.oldMemory.memories);
    assert.doesNotMatch(JSON.stringify(sent), /ADDED_AFTER_PAID_DRAFT|NEW_CONTENT_MUST_NOT_ENTER_OLD_TASK/);
    if (scenario.includes('api')) assert.deepEqual(routes, sent.map(() => ({ url: 'https://resume.invalid/v1', model: 'new-resume-model' })));
    const afterCache = await f.persisted();
    for (const mode of ['phone', 'cabinet']) {
        const oldSession = before.oldCache[mode], savedSession = afterCache[mode];
        if (f.operation === 'profile') {
            assert.deepEqual(savedSession, oldSession);
            continue;
        }
        // Import already migrates the revision and captures the old coverage cursor.
        // Every content, image, selection and other pre-existing field must survive.
        const { archiveRevision: oldRevision, generationMeta: oldMeta, ...oldContent } = oldSession;
        const { archiveRevision: newRevision, generationMeta: newMeta, ...newContent } = savedSession;
        assert.deepEqual(newContent, oldContent);
        assert.equal(newRevision, R.getImportedMemory(f.ctx).archiveRevision);
        assert.notEqual(newRevision, oldRevision);
        if (oldMeta) assert.deepEqual(newMeta, oldMeta);
        else {
            assert.equal(newMeta.expansionRound, 0);
            assert.deepEqual(newMeta.parts.mode.coveredMemoryIds, before.oldMemory.memories.map(item => item.id));
        }
    }
    if (scenario.includes('append') && f.operation === 'import') {
        const afterOldTask = f.requests.length;
        const followup = await R.importCurrentChatMemory();
        assert.equal(followup.status, 'committed', JSON.stringify(f.notices));
        const newRequests = JSON.stringify(f.requests.slice(afterOldTask));
        assert.match(newRequests, /ADDED_AFTER_PAID_DRAFT_A/);
        assert.match(newRequests, /ADDED_AFTER_PAID_DRAFT_B/);
    }
    return { operation: f.operation, scenario, reloaded, status: result.status, resumedRequests: sent.length,
        originalFailedPromptSha256: sha(before.firstRequests.at(-1)), resumedPromptSha256: sha(sent[0]), routes };
}

// A fresh child imports the actual production ESM graph, restoring only JSON
// records from the host/storage boundary. No recovery handle or closure survives.
async function childStage(stage, file, operation, scenario) {
    const cleanups = [], t = { after(fn) { cleanups.push(fn); } };
    try {
        const f = await make(t, operation);
        if (stage === 'seed') {
            const before = await seed(f);
            writeFileSync(file, JSON.stringify({ before, metadata: f.ctx.chatMetadata, chat: f.ctx.chat,
                settings: f.ctx.extensionSettings, records: [...f.records], local: [...f.local.records], ledger: [...f.stores] }));
        } else {
            const saved = JSON.parse(readFileSync(file, 'utf8'));
            f.ctx.chatMetadata = saved.metadata; f.ctx.chat = saved.chat; f.ctx.extensionSettings = saved.settings;
            for (const [map, values] of [[f.records, saved.records], [f.local.records, saved.local], [f.stores, saved.ledger]]) {
                map.clear(); for (const [key, value] of values) map.set(key, value);
            }
            D.resetArchiveRecoveryMemoryForTests(); state.runtimeSessionCache.clear(); state.memoryPreflightCache.clear();
            const result = await resumeAndCheck(f, saved.before, scenario, { reloaded: true });
            writeFileSync(file + '.result', JSON.stringify(result));
        }
    } finally { for (const cleanup of cleanups) await cleanup(); }
}

const childFlag = process.argv.indexOf('--archive-resume-child');
if (childFlag >= 0) {
    await childStage(...process.argv.slice(childFlag + 1));
} else {
    for (const operation of ['import', 'profile']) for (const scenario of ['unchanged', 'api', 'append', 'api-append', 'api-content']) {
        test(`${operation}: original task survives ${scenario}; only unfinished work uses the current API`, async t => {
            const f = await make(t, operation), before = await seed(f);
            await resumeAndCheck(f, before, scenario);
        });
    }
    for (const operation of ['import', 'profile']) for (const scenario of ['unchanged', 'api-append']) {
        test(`${operation}: disk JSON restored in a fresh process continues ${scenario}`, () => {
            const directory = mkdtempSync(join(tmpdir(), 'hearttrace-archive-resume-'));
            try {
                const file = join(directory, 'checkpoint.json'), self = fileURLToPath(import.meta.url);
                execFileSync(process.execPath, [self, '--archive-resume-child', 'seed', file, operation, scenario], { stdio: 'pipe' });
                execFileSync(process.execPath, [self, '--archive-resume-child', 'resume', file, operation, scenario], { stdio: 'pipe' });
                const result = JSON.parse(readFileSync(file + '.result', 'utf8'));
                assert.equal(result.status, 'committed'); assert.equal(result.reloaded, true);
                assert.equal(result.originalFailedPromptSha256, result.resumedPromptSha256);
            } finally { rmSync(directory, { recursive: true, force: true }); }
        });
    }
    test('automatic archive sync retains its existing skip while a manual draft is unfinished', async t => {
        const f = await make(t, 'import'), before = await seed(f);
        changeInputs(f, 'append');
        const count = f.requests.length, draft = clone(D.exportArchiveRecovery(context.captureTaskOrigin(f.ctx, before.oldMemory.archiveRevision)));
        assert.equal((await R.importCurrentChatMemory({ automatic: true })).status, 'blocked');
        assert.equal(f.requests.length, count);
        assert.deepEqual(D.exportArchiveRecovery(context.captureTaskOrigin(f.ctx, before.oldMemory.archiveRevision)), draft);
    });
    for (const operation of ['import', 'profile']) for (const damage of ['saved-content', 'content-digest']) {
        test(`${operation}: damaged ${damage} stays stored and cannot trigger a request or replace the archive`, async t => {
            const f = await make(t, operation), before = await seed(f);
            const stored = [...f.local.records.entries()].find(([, record]) => record.payload?.rows?.some(([, row]) => row.operation === operation));
            assert.ok(stored, 'the actual local storage checkpoint must exist');
            const [key, originalRecord] = stored, damagedRecord = clone(originalRecord);
            const row = damagedRecord.payload.rows.find(([, value]) => value.operation === operation)[1];
            if (damage === 'saved-content') row.inputs.taskInputV1.data.names.name2 = 'CORRUPTED_SAVED_CHARACTER';
            else row.journal.contentSnapshot.archiveInputsHash = '0'.repeat(64);
            f.local.records.set(key, damagedRecord);
            const durableBefore = clone([...f.local.records]), canonicalBefore = clone([...f.records]);
            const requestsBefore = f.requests.length;
            f.setResponse(() => assert.fail('damaged original materials must be rejected before contacting the provider'));
            D.resetArchiveRecoveryMemoryForTests();
            const origin = context.captureTaskOrigin(f.ctx, before.oldMemory.archiveRevision);
            await assert.rejects(D.hydrateArchiveRecovery(origin, operation), { code: 'RMT_ARCHIVE_DRAFT_READ' });
            await assert.rejects(operation === 'import'
                ? R.importCurrentChatMemory() : R.rewriteCurrentArchiveVerdict(), { code: 'RMT_ARCHIVE_DRAFT_READ' });
            assert.equal(f.requests.length, requestsBefore);
            assert.deepEqual(R.getImportedMemory(f.ctx), before.oldMemory);
            assert.deepEqual(await f.persisted(), before.oldCache);
            assert.deepEqual([...f.records], canonicalBefore);
            assert.deepEqual([...f.local.records], durableBefore, 'including all paid successful segments, damaged data remains available for recovery');
        });
    }

    test('archive reader opens successful paid import chunks after a later failure without touching the formal bank or provider', async t => {
        const f = await make(t, 'import'), before = await seed(f);
        const origin = context.captureTaskOrigin(f.ctx, before.oldMemory.archiveRevision);
        const descriptor = D.listArchiveRecoveryDrafts(origin, 'import')[0];
        const count = f.requests.length, oldCache = await f.persisted();
        const record = await library.openArchiveRecoveryDraft(descriptor.draftId, f.ctx);
        assert.ok(record.sections.some(section => section.kind === 'memories' && section.items.length));
        const item = record.sections.find(section => section.kind === 'memories').items[0];
        assert.ok(f.body.innerHTML.includes(item.title));
        assert.ok(f.body.innerHTML.includes(item.summary));
        assert.match(f.body.innerHTML, /data-rmt-archive-draft-memory/);
        assert.equal(f.requests.length, count);
        assert.deepEqual(R.getImportedMemory(f.ctx), before.oldMemory);
        assert.deepEqual(await f.persisted(), oldCache);
    });

    test('truncated archive reply exposes only closed memory items in the actual draft reader', async t => {
        const f = await make(t, 'import'), before = clone(R.getImportedMemory(f.ctx));
        let fullItem;
        rawTransport(f, messages => {
            fullItem = memoryReply(messages).memories[0];
            return { raw: `{"memories":[${JSON.stringify(fullItem)},{"title":"UNFINISHED_ITEM_MUST_NOT_APPEAR","summary":"half`, finish: 'length' };
        });
        assert.equal((await R.importCurrentChatMemory()).status, 'failed');
        const origin = context.captureTaskOrigin(f.ctx, before.archiveRevision);
        const id = D.listArchiveRecoveryDrafts(origin, 'import')[0].draftId;
        const count = f.requests.length;
        const record = await library.openArchiveRecoveryDraft(id, f.ctx);
        assert.equal(record.sections.flatMap(section => section.items || []).length, 1);
        assert.ok(f.body.innerHTML.includes(fullItem.title));
        assert.doesNotMatch(f.body.innerHTML, /UNFINISHED_ITEM_MUST_NOT_APPEAR/);
        assert.equal(f.requests.length, count);
        assert.deepEqual(R.getImportedMemory(f.ctx), before);
    });

    test('profile closed fields are readable after truncation while the previous profile remains unchanged', async t => {
        const f = await make(t, 'profile'), before = clone(R.getImportedMemory(f.ctx));
        rawTransport(f, () => ({ raw: '{"archiveName":"一起栽花","relationshipReading":{"char":"共同栽花","user":"尚未写完', finish: 'length' }));
        assert.equal((await R.rewriteCurrentArchiveVerdict()).status, 'failed');
        const origin = context.captureTaskOrigin(f.ctx, before.archiveRevision);
        const id = D.listArchiveRecoveryDrafts(origin, 'profile')[0].draftId;
        const count = f.requests.length;
        const record = await library.openArchiveRecoveryDraft(id, f.ctx);
        assert.deepEqual(record.sections[0].fields, { archiveName: '一起栽花' });
        assert.deepEqual(record.sections[0].readings, { char: '共同栽花' });
        assert.match(f.body.innerHTML, /一起栽花/); assert.match(f.body.innerHTML, /共同栽花/);
        assert.doesNotMatch(f.body.innerHTML, /尚未写完/);
        assert.equal(f.requests.length, count);
        assert.deepEqual(R.getImportedMemory(f.ctx), before);
    });

    test('first import profile-only continuation reuses its truncated prefix after reload, API change and new chat messages', async t => {
        const f = await archiveFixture(t), local = localFixture(t);
        let profilePrompt, fullProfile;
        const prefix = '{"archiveName":"一同栽花","verdictStyle":"quiet-life","relationshipReading":{"char":"共同栽花",';
        rawTransport(f, messages => {
            if (requestRows(messages).kind !== 'profile') return { value: memoryReply(messages) };
            profilePrompt = clone(messages); fullProfile = profileFromImportedRows(messages);
            return { raw: prefix, finish: 'length' };
        });
        const first = await R.importCurrentChatMemory({ fullRebuild: true });
        assert.equal(first.status, 'committed', JSON.stringify(f.notices));
        const memory = clone(R.getImportedMemory(f.ctx)), oldCache = await f.persisted();
        const origin = context.captureTaskOrigin(f.ctx, memory.archiveRevision);
        await D.flushArchiveRecovery(origin);
        assert.ok(local.records.size);
        const id = D.listArchiveRecoveryDrafts(origin, 'import').find(row => row.stage === 'profile-only').draftId;
        D.resetArchiveRecoveryMemoryForTests();
        f.ctx.chat.push({ is_user: true, name: f.ctx.name1, mes: addedA });
        const resumed = [];
        rawTransport(f, messages => { resumed.push(clone(messages)); return { value: fullProfile }; });
        settings.updatePluginSettings({ manualApiBaseUrl: 'https://other-route.invalid/v1', manualApiModel: 'other-model' });
        const result = await R.rewriteCurrentArchiveVerdict({ draftId: id });
        assert.equal(result.status, 'committed', JSON.stringify(f.notices));
        assert.equal(resumed.length, 1, 'already paid extraction is not requested again');
        const prompt = resumed[0].map(row => row.content).join('\n');
        assert.ok(prompt.includes(profilePrompt.at(-1).content));
        assert.ok(prompt.includes(JSON.stringify({ draft: prefix })));
        assert.doesNotMatch(prompt, /ADDED_AFTER_PAID_DRAFT/);
        assert.deepEqual(R.getImportedMemory(f.ctx).memories, memory.memories);
        const withoutCommitMetadata = value => Object.fromEntries(Object.entries(value || {}).filter(([key]) => !['updatedAt', 'commitToken'].includes(key)));
        assert.deepEqual(withoutCommitMetadata(await f.persisted()), withoutCommitMetadata(oldCache), 'profile-only continuation does not alter any generated content');
        assert.equal(D.listArchiveRecoveryDrafts(origin, 'import').length, 0);
    });

    test('paused profile remains explicitly selectable and retries only its original failed profile request', async t => {
        const f = await make(t, 'profile'), before = await seed(f);
        const origin = context.captureTaskOrigin(f.ctx, before.oldMemory.archiveRevision);
        const id = D.listArchiveRecoveryDrafts(origin, 'profile')[0].draftId;
        assert.equal(D.parkArchiveRecovery(origin, 'profile'), true);
        await D.flushArchiveRecovery(origin, 'profile');
        D.resetArchiveRecoveryMemoryForTests();
        f.setResponse(profileReply);
        const count = f.requests.length;
        assert.equal((await R.rewriteCurrentArchiveVerdict({ draftId: id })).status, 'committed', JSON.stringify(f.notices));
        assert.equal(f.requests.length, count + 1);
        assert.deepEqual(R.getImportedMemory(f.ctx).memories, before.oldMemory.memories);
        assert.equal(D.listArchiveRecoveryDrafts(origin, 'profile').length, 0);
    });

    test('a paid complete profile survives failed canonical storage and retry performs no provider request', async t => {
        const f = await make(t, 'profile'), before = clone(R.getImportedMemory(f.ctx));
        f.setResponse(profileReply);
        f.failCompletedSave('phone', () => true);
        assert.equal((await R.rewriteCurrentArchiveVerdict()).status, 'failed');
        const origin = context.captureTaskOrigin(f.ctx, before.archiveRevision);
        await D.flushArchiveRecovery(origin, 'profile');
        assert.equal(D.exportArchiveRecovery(origin, 'profile')[0].journal.segments.find(row => row.slot === 'profile').state, 'complete');
        assert.deepEqual(R.getImportedMemory(f.ctx), before);
        D.resetArchiveRecoveryMemoryForTests();
        f.failCompletedSave('', () => false);
        f.setResponse(() => assert.fail('the complete paid profile must replay locally'));
        const count = f.requests.length;
        assert.equal((await R.rewriteCurrentArchiveVerdict()).status, 'committed', JSON.stringify(f.notices));
        assert.equal(f.requests.length, count);
        assert.equal(D.listArchiveRecoveryDrafts(origin, 'profile').length, 0);
    });

    test('completed import save retry has priority over its source journal after a same-slot card rename', async t => {
        const f = await make(t, 'profile'), before = clone(R.getImportedMemory(f.ctx));
        f.setResponse(messages => requestRows(messages).kind === 'profile' ? profileFromImportedRows(messages) : memoryReply(messages));
        f.failCompletedSave('phone', () => true);
        assert.equal((await R.importCurrentChatMemory({ automatic: true, fullRebuild: true })).status, 'failed');
        const pending = [...state.deferredChatCommits.values()].flat().find(row => row.kind === 'archive');
        assert.ok(pending?.memoryBank, 'the complete paid result must remain in the actual pending-save queue');
        const origin = context.captureTaskOrigin(f.ctx, before.archiveRevision);
        await D.flushArchiveRecovery(origin);
        assert.ok(D.exportArchiveRecovery(origin)[0].journal.segments.every(row => row.state === 'complete'));
        assert.deepEqual(R.getImportedMemory(f.ctx), before);
        D.resetArchiveRecoveryMemoryForTests();
        await D.hydrateArchiveRecovery(origin);
        assert.equal(D.exportArchiveRecovery(origin)[0].stage,'segments', 'an uncommitted restored journal must not outrank its completed pending save');
        const count = f.requests.length;
        f.ctx.name2 = '同槽改名';
        f.ctx.characters[f.ctx.characterId].name = '同槽改名';
        f.ctx.characters[f.ctx.characterId].data.name = '同槽改名';
        f.failCompletedSave('', () => false);
        f.setResponse(() => assert.fail('saving a completed import must not request any paid segment again'));
        let result;
        await assert.doesNotReject(async () => {
            result = await R.continueCurrentArchiveImport();
        }, 'a completed pending save must survive a display-name-only rename without source-journal admission');
        assert.equal(result.status, 'committed', JSON.stringify(f.notices));
        assert.equal(f.requests.length, count);
        assert.equal(R.getImportedMemory(f.ctx).archiveRevision, pending.memoryBank.archiveRevision);
        assert.equal(R.getImportedMemory(f.ctx).characterName, '同槽改名');
        assert.deepEqual(R.getImportedMemory(f.ctx).memories, pending.memoryBank.memories);
        assert.equal([...state.deferredChatCommits.values()].flat().filter(row => row.kind === 'archive').length, 0);
    });

    test('completed import save retry still rejects changed card facts without reissuing paid work', async t => {
        const f = await make(t, 'profile'), before = clone(R.getImportedMemory(f.ctx));
        f.setResponse(messages => requestRows(messages).kind === 'profile' ? profileFromImportedRows(messages) : memoryReply(messages));
        f.failCompletedSave('phone', () => true);
        assert.equal((await R.importCurrentChatMemory({ automatic: true, fullRebuild: true })).status, 'failed');
        const pending = [...state.deferredChatCommits.values()].flat().find(row => row.kind === 'archive');
        assert.ok(pending?.memoryBank);
        const records = clone([...f.records]), count = f.requests.length;
        f.ctx.characters[f.ctx.characterId].data.description += ' CHANGED_CARD_FACTS';
        f.failCompletedSave('', () => false);
        f.setResponse(() => assert.fail('a changed card must not cause another paid request during save retry'));
        assert.equal((await R.continueCurrentArchiveImport()).status, 'failed');
        assert.equal(f.requests.length, count);
        assert.deepEqual(R.getImportedMemory(f.ctx), before);
        assert.deepEqual([...f.records], records);
        assert.equal([...state.deferredChatCommits.values()].flat().find(row => row.kind === 'archive'), pending);
    });

    test('old profile continues after an ordinary incremental revision and saves independently with original evidence', async t => {
        const f = await make(t, 'profile'), before = await seed(f);
        const origin = context.captureTaskOrigin(f.ctx, before.oldMemory.archiveRevision);
        const id = D.listArchiveRecoveryDrafts(origin, 'profile')[0].draftId;
        f.ctx.chat.push({ is_user: true, name: f.ctx.name1, mes: addedA });
        f.setResponse(memoryReply);
        assert.equal((await R.importCurrentChatMemory()).status, 'committed', JSON.stringify(f.notices));
        const current = clone(R.getImportedMemory(f.ctx));
        assert.notEqual(current.archiveRevision, before.oldMemory.archiveRevision);
        assert.deepEqual(current.memories.slice(0, before.oldMemory.memories.length), before.oldMemory.memories);
        f.setResponse(profileReply);
        const count = f.requests.length, formalCache = await f.persisted();
        const result = await R.rewriteCurrentArchiveVerdict({ draftId: id });
        assert.equal(result.status, 'independent', JSON.stringify(f.notices));
        assert.equal(f.requests.length, count + 1);
        assert.deepEqual(R.getImportedMemory(f.ctx), current);
        assert.deepEqual(await f.persisted(), formalCache);
        D.resetArchiveRecoveryMemoryForTests();
        const record = await library.openArchiveRecoveryDraft(result.draftId, f.ctx);
        assert.deepEqual(record.profileResult.sourceMemory.memories, before.oldMemory.memories);
        assert.match(f.body.innerHTML, /独立保存的简介成果/);
        assert.match(f.body.innerHTML, /一同栽花/);
    });

    test('selecting a paused import at its original revision replays paid chunks and leaves a second draft intact', async t => {
        const f = await make(t, 'import'), first = await seed(f);
        const origin = context.captureTaskOrigin(f.ctx, first.oldMemory.archiveRevision);
        const firstId = D.listArchiveRecoveryDrafts(origin, 'import')[0].draftId;
        D.parkArchiveRecovery(origin); await D.flushArchiveRecovery(origin);
        const second = await seed(f);
        const secondId = D.listArchiveRecoveryDrafts(origin, 'import').find(row => !row.paused).draftId;
        const secondBefore = D.readArchiveRecoveryDraft(origin, secondId).journal;
        assert.notEqual(firstId, secondId);
        f.setResponse(validReply);
        const count = f.requests.length;
        const result = await R.continueCurrentArchiveImport({ draftId: firstId });
        assert.equal(result.status, 'committed', JSON.stringify(f.notices));
        assert.equal(sha(f.requests[count]), sha(first.firstRequests.at(-1)));
        assert.ok(f.requests.slice(count).every(request => sha(request) !== sha(first.firstRequests[0])));
        assert.deepEqual(D.readArchiveRecoveryDraft(context.captureTaskOrigin(f.ctx, R.getImportedMemory(f.ctx).archiveRevision), secondId).journal, secondBefore);
        assert.deepEqual(R.getImportedMemory(f.ctx).memories.slice(0, first.oldMemory.memories.length), first.oldMemory.memories);
        assert.equal(D.listArchiveRecoveryDrafts(origin, 'import').some(row => row.draftId === firstId), false);
        assert.equal(second.draft.journal.segments.filter(row => row.state === 'complete').length, 1);
    });

    test('paused import continues original sources after new archive revision and reload, then opens a durable independent memory result', async t => {
        const f = await make(t, 'import'), before = await seed(f);
        const origin = context.captureTaskOrigin(f.ctx, before.oldMemory.archiveRevision);
        const id = D.listArchiveRecoveryDrafts(origin, 'import')[0].draftId;
        D.parkArchiveRecovery(origin); await D.flushArchiveRecovery(origin);
        f.ctx.chat.push({ is_user: true, name: f.ctx.name1, mes: addedA });
        f.setResponse(validReply);
        assert.equal((await R.importCurrentChatMemory()).status, 'committed', JSON.stringify(f.notices));
        const current = clone(R.getImportedMemory(f.ctx)), currentCache = await f.persisted();
        assert.notEqual(current.archiveRevision, before.oldMemory.archiveRevision);
        D.resetArchiveRecoveryMemoryForTests();
        const routes = changeInputs(f, 'api-append'), count = f.requests.length;
        const result = await R.continueCurrentArchiveImport({ draftId: id });
        assert.equal(result.status, 'independent', JSON.stringify(f.notices));
        assert.equal(sha(f.requests[count]), sha(before.firstRequests.at(-1)));
        assert.doesNotMatch(JSON.stringify(f.requests.slice(count)), /ADDED_AFTER_PAID_DRAFT/);
        assert.ok(f.requests.slice(count).every(request => sha(request) !== sha(before.firstRequests[0])));
        assert.ok(routes.length > 0);
        assert.deepEqual(R.getImportedMemory(f.ctx), current);
        assert.deepEqual(await f.persisted(), currentCache);
        D.resetArchiveRecoveryMemoryForTests();
        const readCount = f.requests.length;
        const record = await library.openArchiveRecoveryDraft(result.draftId, f.ctx);
        assert.equal(record.durable, true);
        assert.deepEqual(record.archiveResult.sourceMemory.memories, before.oldMemory.memories);
        assert.ok(record.archiveResult.memoryBank.memories.length > before.oldMemory.memories.length);
        assert.match(f.body.innerHTML, /data-rmt-independent-archive-memory/);
        assert.equal(f.requests.length, readCount);
        assert.equal((await R.continueCurrentArchiveImport({ draftId: id })).status, 'independent');
        assert.equal(f.requests.length, readCount, 'a fully saved independent result needs no further provider request');
    });

    test('independent import batches keep original sources and prior results while later batches continue separately', async t => {
        const f = await archiveFixture(t, { rows: sourceRows(48, 5200) }), local = localFixture(t);
        let calls = 0;
        f.setResponse(messages => { if (++calls === 2) throw Object.assign(new Error('interrupted'), { code: 'RMT_JSON_INVALID' }); return validReply(messages); });
        assert.equal((await R.importCurrentChatMemory()).status, 'failed');
        const origin = context.captureTaskOrigin(f.ctx, R.getImportedMemory(f.ctx).archiveRevision);
        const id = D.listArchiveRecoveryDrafts(origin, 'import')[0].draftId;
        D.parkArchiveRecovery(origin); await D.flushArchiveRecovery(origin);
        f.setResponse(validReply);
        assert.equal((await R.importCurrentChatMemory()).status, 'committed', JSON.stringify(f.notices));
        const target = clone(R.getImportedMemory(f.ctx)), targetCache = await f.persisted();
        const first = await R.continueCurrentArchiveImport({ draftId: id });
        assert.equal(first.status, 'independent', JSON.stringify(f.notices));
        const savedFirst = await R.readCurrentArchiveRecoveryDraft(id, f.ctx);
        assert.equal(savedFirst.hasNextBatch, true);
        const firstMemories = clone(savedFirst.archiveResult.memoryBank.memories);
        assert.ok(local.records.size);
        D.resetArchiveRecoveryMemoryForTests();
        f.ctx.chat.push({ is_user: true, name: f.ctx.name1, mes: addedB });
        const count = f.requests.length;
        const next = await R.continueCurrentArchiveImport({ draftId: id });
        assert.equal(next.status, 'independent', JSON.stringify(f.notices));
        assert.equal(next.draftId, id);
        assert.doesNotMatch(JSON.stringify(f.requests.slice(count)), /ADDED_AFTER_PAID_DRAFT/);
        const final = await library.openArchiveRecoveryDraft(id, f.ctx);
        assert.equal(final.hasNextBatch, false);
        assert.deepEqual(final.archiveResult.memoryBank.memories.slice(0, firstMemories.length), firstMemories);
        assert.deepEqual(R.getImportedMemory(f.ctx), target);
        assert.deepEqual(await f.persisted(), targetCache);
    });
}
