import test from 'node:test';
import assert from 'node:assert/strict';
import { archiveFixture, sourceRows, memoryReply, requestRows, clickImport, waitForIdle, clone } from './helpers/r8422ArchiveHost.mjs';
import * as overlay from '../src/ui/overlay.js';
import * as budget from '../src/archive/requestBudget.js';
import * as R from '../src/archive/repository.js';
import * as B from '../src/archive/importBatches.js';
import * as C from '../src/core/constants.js';
import * as settings from '../src/core/settings.js';
import * as context from '../src/core/context.js';
import * as client from '../src/generation/client.js';
import * as archiveRecovery from '../src/archive/importRecovery.js';
import * as recovery from '../src/generation/recovery.js';
import * as trace from '../src/core/taskTrace.js';
import * as text from '../src/core/text.js';
import * as cache from '../src/core/cache.js';
import { state } from '../src/core/state.js';

function captureOutput(f) {
    const calls = [], send = f.ctx.ConnectionManagerRequestService.sendRequest;
    const profile = settings.rawConnectionProfile(settings.getPluginSettings(f.ctx).connectionProfileId, f.ctx);
    f.ctx.ConnectionManagerRequestService.sendRequest = async (id, messages, output, options, overridePayload) => {
        const payload = { secret_id: profile['secret-id'], model: profile.model, ...overridePayload };
        assert.equal(payload.secret_id, 'fixture-only');
        calls.push({ profile: id, output, model: payload.model });
        return send(id, messages, output, options, overridePayload);
    };
    return calls;
}

test('reported 64004 UTF16 / 47030 estimated input + 60000 output: unknown is not a 32000 model limit', async t => {
    const f = await archiveFixture(t);
    settings.updatePluginSettings({ maxTokens: 60000 });
    f.ctx.getTokenCountAsync = async () => 47030;
    // Synthetic text reproduces all length measurements without copying user content.
    const actual = '中'.repeat(39015) + 'a'.repeat(24964) + '🙂'.repeat(12) + 'é';
    assert.equal(actual.length, 64004);
    const value = await budget.measureArchiveRequest(f.ctx, actual);
    assert.equal(value.utf8Bytes, 142059);
    assert.equal(value.unicodeCharacters, 63992);
    assert.equal(value.inputTokens, 47030);
    assert.equal(value.outputTokens, 60000);
    assert.equal(value.combinedTokens, 107030);
    assert.equal(value.contextTokens, null);
    assert.equal(value.maximumOutputTokens, null);
    assert.equal(value.tokenBasis, 'host-tokenizer-estimate');
    assert.equal(value.exceeded, null);
    assert.doesNotThrow(() => budget.assertArchiveRequestBudget(value));
});

for (const [label, input] of [
    ['Chinese-80k', '中'.repeat(80000)],
    ['mixed-80k', 'a中🙂'.repeat(20000)],
    ['beyond-old-96k', '背景'.repeat(65000)],
    ['single-300k', '中'.repeat(300000)],
]) test(`unknown capacity allows ${label}; neither UTF8 bytes nor host estimates become model caps`, async t => {
    const f = await archiveFixture(t); settings.updatePluginSettings({ maxTokens: 60000 });
    f.ctx.getTokenCountAsync = async value => Array.from(value).length;
    const value = await budget.measureArchiveRequest(f.ctx, input);
    assert.equal(value.exceeded, null); assert.equal(value.outputTokens, 60000);
    assert.equal(value.utf16Chars, input.length); assert.equal(value.utf8Bytes, new TextEncoder().encode(input).length);
    assert.equal(f.requests.length, 0, 'Accounting is not generation');
});

for (const raw of [null, undefined, '', 'not-a-number', NaN, Infinity, -1]) test(`unavailable tokenizer (${String(raw)}) stays unknown and does not force a character cap`, async t => {
    const f = await archiveFixture(t); f.ctx.getTokenCountAsync = async () => raw;
    const value = await budget.measureArchiveRequest(f.ctx, '中'.repeat(100000));
    assert.equal(value.inputTokens, null); assert.equal(value.combinedTokens, null);
    assert.equal(value.tokenBasis, 'unavailable'); assert.equal(value.exceeded, null);
});

test('missing/throwing/timed-out tokenizer remains diagnostic only, while cancellation still aborts', async t => {
    const f = await archiveFixture(t);
    delete f.ctx.getTokenCountAsync;
    assert.equal((await budget.measureArchiveRequest(f.ctx, '中'.repeat(110000))).exceeded, null);
    f.ctx.getTokenCountAsync = async () => { throw new Error('SYNTHETIC_SECRET_NOT_FOR_LOGS'); };
    assert.equal((await budget.measureArchiveRequest(f.ctx, '中'.repeat(110000))).exceeded, null);
    f.ctx.getTokenCountAsync = () => new Promise(() => {});
    assert.equal((await budget.measureArchiveRequest(f.ctx, '中'.repeat(110000))).inputTokens, null);
    const controller = new AbortController();
    const pending = budget.measureArchiveRequest(f.ctx, '中'.repeat(110000), { signal: controller.signal });
    controller.abort(); await assert.rejects(pending, { name: 'AbortError' });
    assert.equal(f.requests.length, 0);
    assert.ok(!JSON.stringify(f.diagnostics).includes('SYNTHETIC_SECRET_NOT_FOR_LOGS'));
});

for (const [limits, expected] of [
    [{ contextTokens: 107030 }, null],
    [{ contextTokens: 107029 }, 'context'],
    [{ contextTokens: 128000, maximumOutputTokens: 65536 }, null],
    [{ contextTokens: 128000, maximumOutputTokens: 32000 }, 'output'],
    [{ contextTokens: 0, maximumOutputTokens: null }, null],
    [{ contextTokens: -1, maximumOutputTokens: Infinity }, null],
]) test(`only explicitly confirmed capability can reject: ${JSON.stringify(limits)}`, async t => {
    const f = await archiveFixture(t); settings.updatePluginSettings({ maxTokens: 60000 });
    f.ctx.getTokenCountAsync = async () => 47030;
    const value = await budget.measureArchiveRequest(f.ctx, '中'.repeat(100000), { confirmedLimits: limits });
    assert.equal(value.exceeded, expected);
    assert.equal(settings.getPluginSettings(f.ctx).maxTokens, 60000);
    assert.equal(f.requests.length, 0);
    if (expected) {
        assert.throws(() => budget.assertArchiveRequestBudget(value), error => {
            const summary = text.safeErrorSummary(error);
            assert.ok(summary.includes('已确认')); assert.ok(!summary.includes('本地输入'));
            assert.ok(!JSON.stringify(error.archiveBudget).includes('requestHash')); return true;
        });
    }
});

test('shared non-archive input policy remains unchanged; archive opt-in does not leak to other modes', async t => {
    const f = await archiveFixture(t); f.ctx.getTokenCountAsync = async () => 47030;
    await assert.rejects(client.generateConfiguredJson('正文', { context: f.ctx, contextEnvelope: '' }), { code: 'RMT_INPUT_BUDGET' });
    await assert.rejects(client.generateConfiguredJson('中'.repeat(100000), { context: f.ctx, contextEnvelope: '' }), { code: 'RMT_INPUT_BUDGET' });
    assert.equal(f.requests.length, 0);
    assert.equal(C.MAX_GENERATION_INPUT_TOKENS, 32000); assert.equal(C.MAX_GENERATION_INPUT_CHARS, 96000);
    assert.equal(C.MAX_MEMORY_ITEMS, 240); assert.equal(C.MAX_CACHE_SOURCE_BYTES, 12 * 1000 * 1000);
});

test('ordinary UI sends the full high-estimate request, commits, and never lowers 60000 output', async t => {
    const f = await archiveFixture(t, { rows: sourceRows(2, 4000) });
    f.ctx.getTokenCountAsync = async () => 47030;
    settings.updatePluginSettings({ maxTokens: 60000 });
    const outputs = captureOutput(f), old = clone(R.getImportedMemory(f.ctx).memories);
    await clickImport(f);
    const bank = R.getImportedMemory(f.ctx);
    assert.equal(bank[B.IMPORT_PROGRESS_KEY]?.nextBatch, 1, JSON.stringify(f.notices));
    assert.deepEqual(bank.memories.slice(0, old.length), old);
    assert.equal(f.requests.length, 1); assert.equal(outputs[0].output, 60000);
    const actual = f.requests[0][0].content;
    const task = trace.taskTraceSnapshot().filter(row => row.mode === 'archive').at(-1);
    assert.equal(task.archiveBudget.utf16Chars, actual.length);
    assert.equal(task.archiveBudget.utf8Bytes, new TextEncoder().encode(actual).length);
    assert.equal(task.archiveBudget.inputTokens, 47030); assert.equal(task.archiveBudget.outputTokens, 60000);
    assert.equal(task.archiveBudget.contextTokens, null); assert.equal(task.providerRequests, 1);
    assert.equal(task.archiveBudget.exceeded, null);
    assert.ok(R.requireArchive(f.ctx).memories.length > old.length);
    await new Promise(resolve => setTimeout(resolve, 20)); assert.equal(f.requests.length, 1);
});

test('selected large worldbooks exceed 96k in a real UI request; no clipping, repeated background or invented capacity', async t => {
    const f = await archiveFixture(t, { rows: sourceRows(2, 2000) });
    settings.updatePluginSettings({ maxTokens: 60000 });
    f.ctx.getTokenCountAsync = async () => 80000;
    const books = Array.from({ length: 6 }, (_, i) => `B${i}`);
    f.ctx.getWorldInfoNames = () => books;
    f.ctx.loadWorldInfo = async name => ({ entries: { 1: { uid: 1, comment: name, content: `START_${name}_` + '景'.repeat(7500) + `_TAIL_${name}` } } });
    // Keep each book below the EXISTING 52k combined background bound.
    // Independent card fields make the FULL request larger than 96k.
    for (const key of ['description', 'personality', 'scenario', 'depth_prompt', 'creator_notes', 'occupation', 'school', 'species', 'residence', 'era', 'world_setting', 'technology']) f.ctx.characters[0].data[key] = '设'.repeat(4800);
    R.setMemoryWorldInfoSelection(f.ctx, { books: books.map(name => ({ name, all: true, historySource: false })) });
    await R.readCurrentChatMemoryPlugins();
    const outputs = captureOutput(f);
    await clickImport(f, 'import-memory');
    assert.equal(R.getImportedMemory(f.ctx)[B.IMPORT_PROGRESS_KEY]?.nextBatch, 1, JSON.stringify(f.notices));
    assert.equal(f.requests.length, 1); const actual = f.requests[0][0].content;
    assert.ok(actual.length > 96000, `Expected large full request, got ${actual.length}`);
    for (const name of books) {
        assert.equal(actual.split(`START_${name}_`).length - 1, 1);
        assert.equal(actual.split(`_TAIL_${name}`).length - 1, 1);
    }
    assert.equal(outputs[0].output, 60000);
});

test('provider rejection is reached once and preserves draft/bank; next ordinary click explicitly retries the failed source', async t => {
    const f = await archiveFixture(t, { rows: sourceRows(2, 2000) });
    f.ctx.getTokenCountAsync = async () => 47030; settings.updatePluginSettings({ maxTokens: 60000 });
    const old = clone(R.getImportedMemory(f.ctx)), outputs = captureOutput(f);
    f.setResponse(() => { throw Object.assign(new Error('SYNTHETIC_UPSTREAM_SECRET'), { status: 413 }); });
    await clickImport(f); assert.equal(f.requests.length, 1); assert.deepEqual(R.getImportedMemory(f.ctx), old);
    assert.equal(R.getCurrentArchiveImportRecoverySummary(f.ctx).completed, 0);
    assert.ok(!JSON.stringify(f.notices).includes('SYNTHETIC_UPSTREAM_SECRET'));
    await new Promise(resolve => setTimeout(resolve, 30)); assert.equal(f.requests.length, 1);
    f.setResponse(messages => memoryReply(messages)); await clickImport(f);
    assert.equal(f.requests.length, 2); assert.deepEqual(f.requests[0], f.requests[1]);
    assert.ok(outputs.every(row => row.output === 60000));
    assert.equal(R.getImportedMemory(f.ctx)[B.IMPORT_PROGRESS_KEY]?.nextBatch, 1, JSON.stringify(f.notices));
});

test('high-token three-batch plan stays manual, durable checkpoints readable between batches, no saved sources resent', async t => {
    const f = await archiveFixture(t, { rows: sourceRows(610, 1000) });
    f.ctx.getTokenCountAsync = async () => 47030; settings.updatePluginSettings({ maxTokens: 60000 });
    const outputs = captureOutput(f);
    for (let n = 1; n <= 3; n++) {
        await clickImport(f);
        const bank = R.getImportedMemory(f.ctx);
        assert.equal(bank[B.IMPORT_PROGRESS_KEY]?.nextBatch, n, JSON.stringify(f.notices));
        assert.equal(bank[B.IMPORT_PROGRESS_KEY].batches.length, 3);
        assert.ok(R.requireArchive(f.ctx).memories.length);
        const count = f.requests.length; await new Promise(resolve => setTimeout(resolve, 10)); assert.equal(f.requests.length, count);
        archiveRecovery.clearArchiveRecovery(context.captureTaskOrigin(f.ctx, bank.archiveRevision));
        state.runtimeSessionCache.clear(); state.memoryPreflightCache.clear();
        f.ctx.chatMetadata[C.MEMORY_KEY] = clone(f.records.get(f.aEntry.entryId).memory);
    }
    const sent = f.requests.flatMap(messages => requestRows(messages).rows);
    assert.equal(sent.length, 610); assert.equal(new Set(sent.map(row => row.externalId)).size, 610);
    assert.ok(outputs.every(row => row.output === 60000));
});

test('legacy archive ticket uses archive accounting at dispatch only: request hash, prompt and per-item validator unchanged', async t => {
    const f = await archiveFixture(t); settings.updatePluginSettings({ maxTokens: 60000 });
    let tokenCalls = 0; f.ctx.getTokenCountAsync = async () => { tokenCalls++; return 47030; };
    const outputs = captureOutput(f), origin = context.captureTaskOrigin(f.ctx, R.getImportedMemory(f.ctx).archiveRevision);
    const prompt = '原草稿请求与来源不变', envelope = '背景'.repeat(55000), options = { context: f.ctx, contextEnvelope: envelope, maxTokens: 8192, temperature: 0.3, archiveRequestBudget: false, skipTokenCount: true };
    const begin = { origin, sourceIdentity: 'synthetic-legacy-source', settingsIdentity: 'synthetic-legacy-settings', sourceFragments: ['one'] };
    const ticket = await archiveRecovery.beginArchiveRecovery(begin);
    f.setResponse(() => ({ marker: 'VALIDATED_SYNTHETIC' }));
    let validations = 0;
    const validator = raw => { validations++; assert.equal(raw.marker, 'VALIDATED_SYNTHETIC'); return raw; };
    const result = await archiveRecovery.requestArchiveRecoverySegment(ticket, 'external:0', prompt, options, validator);
    assert.equal(result.marker, 'VALIDATED_SYNTHETIC'); archiveRecovery.releaseArchiveRecovery(ticket);
    assert.equal(f.requests.length, 1); assert.equal(outputs[0].output, 60000);
    assert.equal(f.requests[0][0].content, budget.composeArchiveRequest(f.ctx, prompt, envelope));
    assert.equal(options.archiveRequestBudget, false, 'Dispatch does not mutate old options/normalizers');
    assert.equal(tokenCalls, 0, 'Legacy skipTokenCount remains respected, without new per-chunk waits');
    const [draft] = archiveRecovery.exportArchiveRecovery(origin);
    const expectedHash = await recovery.generationRecoveryDigest({ prompt, contextEnvelope: envelope, temperature: 0.3, model: '', maxTokens: 8192, mode: '', phrasePolicy: true });
    assert.equal(draft.journal.segments[0].requestHash, expectedHash);
    const retry = await archiveRecovery.beginArchiveRecovery({ ...begin, continueApproved: true });
    await archiveRecovery.requestArchiveRecoverySegment(retry, 'external:0', prompt, options, validator);
    assert.equal(f.requests.length, 1); assert.equal(validations, 2);
    await assert.rejects(archiveRecovery.requestArchiveRecoverySegment(retry, 'external:0', prompt + 'CHANGED', options, validator), { code: 'RMT_RECOVERY_INPUT_CHANGED' });
    assert.equal(f.requests.length, 1); archiveRecovery.releaseArchiveRecovery(retry);
});

test('first build with no archive still reaches the cover request at high estimated tokens, output unchanged', async t => {
    const f = await archiveFixture(t, { rows: sourceRows(2, 2000) });
    delete f.ctx.chatMetadata[C.MEMORY_KEY]; f.records.delete(f.aEntry.entryId);
    f.ctx.getTokenCountAsync = async () => 47030; settings.updatePluginSettings({ maxTokens: 60000 });
    const outputs = captureOutput(f);
    // This budget fixture starts after the user's explicit single-card choice.
    // Actual picker clicks and cancellation are exercised in the dist browser flow.
    overlay.requestCurrentArchiveImport({ cardTypeConfirmed: true, participantRoster: null });
    await waitForIdle(f);
    // The synthetic provider intentionally rejects the cover: valid memories must
    // still save with the original profile-pending fallback, not a new count gate.
    assert.ok(f.requests.some(messages => requestRows(messages).kind === 'profile'), JSON.stringify(f.notices));
    assert.ok(outputs.every(row => row.output === 60000));
    assert.ok(R.getImportedMemory(f.ctx)?.memories.length, JSON.stringify(f.notices));
});

test('high-estimate cancellation keeps old bank and releases task/provider slots without retry', async t => {
    const f = await archiveFixture(t, { rows: sourceRows(2, 2000) });
    f.ctx.getTokenCountAsync = async () => 47030;
    const old = clone(R.getImportedMemory(f.ctx)), pause = f.pauseProvider();
    const pending = clickImport(f); await pause.ready; state.activeTaskAbortController.abort(); pause.release(); await pending;
    assert.deepEqual(R.getImportedMemory(f.ctx), old); assert.equal(f.requests.length, 1);
    assert.equal(state.busy, false); assert.equal(state.activeProviderRequestCount, 0);
});
