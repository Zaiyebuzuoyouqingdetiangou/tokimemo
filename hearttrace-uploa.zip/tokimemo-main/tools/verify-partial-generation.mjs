// Browser evidence only: public menu -> index.js -> shipped dist, synthetic
// provider replies and native IndexedDB. No production source module imports.
// Rebuild dist first. Root runs this script; authoring does not execute it.
// Env: PARTIAL_OUTPUT_DIR, PARTIAL_CASES (comma-separated modes, lifecycle, source-result),
// PARTIAL_WIDTHS=390,1280, PLAYWRIGHT_CHROMIUM_EXECUTABLE.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import http from 'node:http';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { location as postcardLocation } from '../tests/helpers/r8416DesignFixtures.mjs';

const { chromium } = createRequire(import.meta.url)('playwright');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const output = path.resolve(process.env.PARTIAL_OUTPUT_DIR || path.join(root, 'artifacts', 'partial-generation'));
const prefix = '/scripts/extensions/third-party/hearttrace/';
const build = JSON.parse(await readFile(path.join(root, 'manifest.json'), 'utf8')).js;
const sha = value => createHash('sha256').update(value).digest('hex');
const pageContent = value => { const copy = structuredClone(value); if (copy) delete copy._rmtModeWriteFence; return copy; };
const hashes = Object.fromEntries(await Promise.all(['index.js', 'dist/heartbeatMemories.bundle.js'].map(async file => [file, sha(await readFile(path.join(root, file)))])));
const widths = (process.env.PARTIAL_WIDTHS || '390,1280').split(',').map(Number);
const ref = (id = 'M001', anchor = '庭院') => ({ sourceMemoryIds: [id], sourceMemoryAnchor: anchor });
const cg = { id: 'CG01', title: '庭院的已完成画面', desc: '林舟站在庭院的花架旁。', date: '2008/05/18', unlocked: true, category: '日常', ...ref() };
const albumIndex = { title: '相簿试读', entries: [cg] };
const prefixArray = (key, rows, head = {}) => JSON.stringify(head).slice(0, -1) + (Object.keys(head).length ? ',' : '')
    + JSON.stringify(key) + ':[' + rows.map(row => JSON.stringify(row)).join(',') + ',{"id":"TAIL_NOT_CLOSED","text":"DO_NOT_INVENT';
const unfinishedRoot = value => JSON.stringify(value).slice(0, -1) + ',"unfinished":"DO_NOT_INVENT';
const mainNode = { label: '庭院主线', monologue: '我记得庭院里的一盆花。', intervention: '我正在读这份观测记录。', systemNote: '已保存这条主线记录。', branchAxes: ['decision'], ...ref() };
const endingHead = { title: '庭院结局', relationshipState: '同伴', relationshipSummary: '林舟和小月在庭院栽花。',
    relationshipSourceMemoryIds: ['M001'], relationshipSourceMemoryAnchor: '庭院' };
const opening = { title: '虚构花笺', text: '假如另一段人生从一张花笺开始。', motif: '一片花瓣', ...ref() };
const notesPlan = { title: '私人终端', deviceKind: 'phone', deviceName: '手机', apps: [{ id: 'notes', kind: 'notes', label: '已完成便签',
    entries: [{ id: 'N1', title: '窗边的便签' }, { id: 'N2', title: '尚待完成' }] }] };
const notesRow = { id: 'N1', title: '窗边的便签', preview: '此刻窗边很安静。', detail: '此刻窗边很安静，我准备整理书桌，再把用过的文具放回抽屉。', basis: '推演',
    sourceMemoryIds: [], sourceMemoryAnchor: '', sourceMemoryEvidence: '', sourceSettingEvidence: '' };
const item = { id: 'I1', kind: 'item', basis: '推演', label: '已完成铅笔', summary: '铅笔静静放在架上。', line: '请慢慢看看这支铅笔。', children: [] };
const letter = { slot: 'daily', title: '已完成短笺', greeting: '小月：', body: '此刻窗边的风很安静，我想把这一点轻松的心情写给你，愿你今天也能慢慢歇一会。', closing: '林舟' };
// The fixture's controlled world profile is neutral, whose existing contract
// permits letters/journals. Reuse the drawing/body fixture with that valid kind.
const travelLetter = postcardLocation('pavilion', 'F1');
travelLetter.keepsake = { ...travelLetter.keepsake, kind: 'letter', closing: '林舟' };
const cases = [
    { mode: 'album', group: 'memory', sentinel: cg.title, responses: [prefixArray('entries', [cg], { title: albumIndex.title })] },
    { mode: 'butterfly', group: 'stories', sentinel: mainNode.monologue, responses: [unfinishedRoot({ node: mainNode })] },
    { mode: 'ending', group: 'stories', sentinel: '已完成路线', responses: [prefixArray('endings', [{ id: 'END1', type: 'route', title: '已完成路线', available: true, ...ref() }], endingHead)] },
    { mode: 'pastLives', group: 'stories', sentinel: '已完成前世引子', button: '[data-rmt-past-lives="generate"]', responses: [unfinishedRoot({ title: '已完成前世引子', opening, dossiers: [] })] },
    { mode: 'adv', group: 'memory', sentinel: '已完成事件', responses: [prefixArray('events', [{ ...cg, id: 'EV01', title: '已完成事件', cgDesc: cg.desc }])] },
    { mode: 'phone', group: 'life', sentinel: '已完成便签', responses: [JSON.stringify(notesPlan),
        '{"app":{"id":"notes","entries":[' + JSON.stringify(notesRow) + ',{"id":"N2","detail":"DO_NOT_INVENT'] },
    { mode: 'room', group: 'life', sentinel: '已完成书房', responses: ['{"spaces":[{"id":"SP01","label":"已完成书房","spaceType":"书房","atmosphere":"书架靠墙摆放。","objects":['
        + JSON.stringify({ id: 'OBJ01', label: '木盒', zone: '中央', basis: '设定', searchable: true, description: '木盒里放着常用文具。', line: '文具就在这里。', sourceMemoryIds: [], sourceMemoryAnchor: '' }) + ',{"id":"TAIL_NOT_CLOSED","text":"DO_NOT_INVENT'] },
    { mode: 'heart', route: 'language', group: 'interaction', sentinel: '早晨的已完成台词', button: '[data-rmt-action="heart-add-language"]', responses: [unfinishedRoot({ greetings: { morning: ['早晨的已完成台词。'] } })] },
    { mode: 'items', group: 'life', sentinel: '已完成铅笔', button: '[data-rmt-action="room-open-items"]', responses: ['{"containers":[{"id":"B1","label":"书桌抽屉","description":"放文具的抽屉。","nodes":[' + JSON.stringify(item) + ',{"id":"TAIL_NOT_CLOSED","text":"DO_NOT_INVENT'] },
    { mode: 'cabinet', group: 'memory', sentinel: '信封', responses: [prefixArray('items', [{ name: '信封', objectEvidence: '林舟把信封交给小月。', ...ref('M002', '信封') }])] },
    { mode: 'inbox', group: 'life', sentinel: '已完成短笺', button: '[data-rmt-inbox="receive"]', responses: [prefixArray('letters', [letter])] },
    { mode: 'themeSong', group: 'interaction', sentinel: '已完成歌名', button: '[data-rmt-song="generate"]', responses: ['{"title":"已完成歌名","vocalDescription":"轻声独唱","styleDescription":"木吉他与安静的节奏","stylePrompt":"soft acoustic folk","lyrics":"DO_NOT_INVENT'] },
    { mode: 'timeEcho', group: 'stories', sentinel: '已完成时空开场', responses: [JSON.stringify({ title: '已完成时空开场', opening: '林舟听见了从旧匣传来的风声。', medium: { kind: 'object', label: '旧木匣' }, ends: [{ role: 'char', time: '今夜' }, { role: 'user', time: '明夜' }] }).slice(0, -1) + ',"lines":[{"speaker":"a","text":"你听见窗外的风了吗？"},{"speaker":"b","text":"DO_NOT_INVENT'] },
    { mode: 'travel', group: 'life', sentinel: '山间', responses: [prefixArray('locations', [travelLetter])] },
    { mode: 'calendar', group: 'life', sentinel: '庭院栽花', responses: [prefixArray('past', [{ id: 'P1', title: '庭院栽花', ...ref() }])] },
    { mode: 'relations', group: 'interaction', sentinel: '阿青', responses: [prefixArray('relationships', [{ id: 'R1', name: '阿青', relation: '书房的熟人', summary: '阿青在书房参与交谈。', npcPerspective: '我正听林舟谈这本书。', isUser: false, ...ref('M003', '书房') }])] },
    { mode: 'achievements', group: 'interaction', sentinel: '已完成花圃记号', responses: [prefixArray('entries', [{ id: 'A1', title: '已完成花圃记号', description: '在庭院共同栽花。', unlocked: true, unlockCondition: '一起完成栽花', ...ref() }])] },
];
const requested = (process.env.PARTIAL_CASES || cases.map(item => item.mode).concat('lifecycle', 'source-result').join(',')).split(',').filter(Boolean);
for (const name of requested) assert.ok(['lifecycle', 'source-result'].includes(name) || cases.some(item => item.mode === name), `Unknown case ${name}`);
function seed(spec, width) {
    const chatId = `partial-${spec.mode}-${width}`;
    const bank = { version: 3, chatId, archiveRevision: chatId + '-source-A', characterName: '林舟', userName: '小月',
        archiveName: '原资料 A', archiveSummary: '现代都市中的日常记录。', createdAt: 1, updatedAt: 1, memories: [
            { id: 'M001', date: '2008/05/18', title: '庭院栽花', summary: '林舟和小月在庭院共同栽花。', anchors: ['庭院'], participants: ['林舟', '小月'] },
            { id: 'M002', date: '2008/05/19', title: '初见与信封', summary: '林舟把信封交给小月。', anchors: ['信封'], participants: ['林舟', '小月'] },
            { id: 'M003', date: '2008/05/20', title: '书房交谈', summary: '林舟与阿青、白泽在书房交谈。', anchors: ['书房'], participants: ['林舟', '阿青', '白泽'] },
        ] };
    const cache = { chatId, archiveRevision: bank.archiveRevision };
    if (spec.mode === 'items') cache.room = { kind: 'room', roomVersion: 3, chatId, archiveRevision: bank.archiveRevision,
        title: '他的房间', homeName: '原有书房', homeSummary: '放书和文具的地方。', pets: [], presenceLines: [], presenceIndex: 0,
        selectedSpaceId: 'SP01', selectedObjectId: 'OBJ01', visualProfile: {},
        spaces: [{ id: 'SP01', label: '书房', spaceType: '书房', atmosphere: '木盒摆在桌上。', objects: [{ id: 'OBJ01', label: '木盒', searchable: true, zone: '中央', basis: '设定', description: '木盒用于存放文具。', line: '文具在木盒里。', sourceMemoryIds: [], sourceMemoryAnchor: '' }] }],
        dayparts: Object.fromEntries(['morning','daytime','evening','night'].map(key => [key, { spaceId: 'SP01', activity: '整理文具。', line: '文具就在这里。', focusObjectId: 'OBJ01' }])) };
    return { ...spec, width, bank, cache, albumIndex,
        relationship: { charState: '同伴', userState: '共同参与', relationshipState: '同伴', relationshipSummary: '在庭院一起栽花。', relationshipSourceMemoryIds: ['M001'], relationshipSourceMemoryAnchor: '庭院' },
        comments: { items: [{ id: 'CG01', comments: Array.from({ length: 6 }, (_, i) => `这是已经完成的第${i + 1}句共同回忆，此刻正看着照片里的花架与光线。`) }] } };
}
function hostPage(data) {
    return `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0;font-family:sans-serif}*{box-sizing:border-box}#extensionsMenu,#extensions_settings2{padding:8px}</style><div id="extensions_settings2"></div><div id="extensionsMenu"></div><script>
const seed=${JSON.stringify(data).replace(/</g, '\\u003c')};
const copy=x=>x==null?x:JSON.parse(JSON.stringify(x));
const metadataKey='partial-fixture-metadata',settingsKey='partial-fixture-settings',callKey='partial-fixture-calls';
if(!localStorage.getItem('heartbeatMemoriesWorkspaceUiV1'))localStorage.setItem('heartbeatMemoriesWorkspaceUiV1',JSON.stringify({expanded:true,startup:'content',restore:false,group:seed.group||'memory'}));
const calls=JSON.parse(localStorage.getItem(callKey)||'[]'),notices=[];
let phase=localStorage.getItem('partial-phase')||'prefix',releaseWait=null;
const profile={id:'partial-profile',name:'Synthetic profile',mode:'cc',api:'openai',model:'fixture-model','secret-id':'synthetic-only'};
const context={characterId:0,groupId:null,chatId:seed.bank.chatId,name1:seed.bank.userName,name2:seed.bank.characterName,
 characters:[{name:'林舟',avatar:'fixture.png',data:{name:'林舟',description:'现代都市，日常使用手机。认真整理书架，常用木盒、铅笔与便签。',personality:'认真克制。'}}],chat:[{is_user:true,name:'小月',mes:'林舟和小月在庭院共同栽花。'}],
 chatMetadata:JSON.parse(localStorage.getItem(metadataKey)||JSON.stringify({heartbeatMemoriesArchiveV3:seed.bank,heartbeatMemoriesTheaterV3:seed.cache})),
 powerUserSettings:{persona_description:'温和的花店店主。'},extensionSettings:JSON.parse(localStorage.getItem(settingsKey)||JSON.stringify({heartbeatMemories:{apiConnectionMode:'profile',connectionProfileId:profile.id,useActivatedWorldInfo:false,useCurrentChatExternalMemory:false,maxTokens:12000},connectionManager:{profiles:[profile]}})),
 getCurrentChatId(){return this.chatId},getCharacterCardFields(){return copy(this.characters[0].data)},getRequestHeaders:()=>({'Content-Type':'application/json'}),getTokenCountAsync:async()=>100,
 getWorldInfoNames:()=>[],saveMetadataDebounced(){localStorage.setItem(metadataKey,JSON.stringify(context.chatMetadata))},saveSettingsDebounced(){localStorage.setItem(settingsKey,JSON.stringify(context.extensionSettings))},eventTypes:{},eventSource:{on(){},off(){}},
 ConnectionManagerRequestService:{validateProfile:()=>({selected:'openai',source:'openai'}),async sendRequest(profileId,messages,outputTokens,options,overridePayload){
  const payload={secret_id:profile['secret-id'],model:profile.model,...overridePayload};if(profileId!==profile.id||payload.secret_id!=='synthetic-only')throw new Error('Unexpected route');
  const text=messages.map(item=>item.content||'').join('\\n');calls.push({messages:copy(messages),outputTokens,phase,hasSignal:options?.signal instanceof AbortSignal});localStorage.setItem(callKey,JSON.stringify(calls));
  if(['lifecycle','source-result'].includes(seed.mode)){
   if(text.includes('EXISTING_ALBUM_INDEX_JSON'))return {content:JSON.stringify(seed.albumIndex)};
   if(phase==='prefix')await new Promise((resolve,reject)=>{releaseWait=()=>reject(Object.assign(new Error('Synthetic later-stage failure'),{code:'RMT_MANUAL_HTTP',status:400}));options?.signal?.addEventListener('abort',()=>reject(new DOMException('Aborted','AbortError')),{once:true})});
   if(phase==='resume')return {content:JSON.stringify(text.includes('ALBUM_RELATIONSHIP_FULL_ARCHIVE_JSON')?seed.relationship:seed.comments)};
   throw Object.assign(new Error('Synthetic stopped phase'),{code:'RMT_MANUAL_HTTP',status:400});
  }
  const index=calls.length-1;if(index>=seed.responses.length)throw Object.assign(new Error('Unexpected extra synthetic request'),{code:'RMT_MANUAL_HTTP',status:400});
  return {content:seed.responses[index]};
 }}};
globalThis.SillyTavern={getContext:()=>context};globalThis.toastr=Object.fromEntries(['info','success','warning','error'].map(level=>[level,(...args)=>notices.push({level,message:args.map(String).join(' ')})]));
async function decode(value){if(value?.format!=='gzip-base64-v1')return copy(value);return JSON.parse(await new Response(new Blob([Uint8Array.from(atob(value.data),x=>x.charCodeAt(0))]).stream().pipeThrough(new DecompressionStream('gzip'))).text())}
async function snapshot(){return {bank:copy(context.chatMetadata.heartbeatMemoriesArchiveV3),cache:await decode(context.chatMetadata.heartbeatMemoriesTheaterV3),calls:copy(calls),notices:copy(notices)}}
async function canonical(){if(!(await indexedDB.databases()).some(row=>row.name==='heartbeatMemoriesArchiveBackupsV1'))return [];const db=await new Promise((resolve,reject)=>{const r=indexedDB.open('heartbeatMemoriesArchiveBackupsV1');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)});try{const rows=await new Promise((resolve,reject)=>{const r=db.transaction('archives','readonly').objectStore('archives').getAll();r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)});return await Promise.all(rows.map(async row=>({...row,cache:await decode(row.cache)})))}finally{db.close()}}
// This fixture-only transition models an already completed archive update in
// durable storage. The old task/journal/result are copied byte-for-byte; resume,
// result choices, version preservation and readers run through shipped UI code.
async function advanceArchive(){
 const rows=await canonical(),row=rows.find(row=>row.chatId===seed.bank.chatId);if(!row)throw new Error('Missing durable source A');
 const records=row.cache.__generationDraftsV2?.records||{},pair=Object.entries(records).find(([,record])=>record.result?.mode==='album');if(!pair)throw new Error('Missing real partial album');
 const [draftId,record]=pair,original=JSON.stringify(record),bank=copy(row.memory);
 bank.archiveRevision=seed.bank.chatId+'-current-B';bank.archiveName='当前资料 B';bank.updatedAt=Date.now();
 bank.memories=[{id:'M900',title:'CURRENT_B_ONLY',summary:'林舟独自在海边读书。',anchors:['海边'],participants:['林舟']}];
 const currentAlbum=copy(record.result.session);delete currentAlbum.readableProgress;
 currentAlbum.archiveRevision=bank.archiveRevision;currentAlbum.title='当前 B 相簿';currentAlbum.entries=currentAlbum.entries.slice(0,1).map(entry=>({...entry,id:'B_CG',title:'当前 B 已有画面',desc:'林舟在海边读书。',sourceMemoryIds:['M900'],sourceMemoryAnchor:'海边',comments:['当前 B 的原有说明。']}));currentAlbum.selectedId='B_CG';
 row.archiveRevision=bank.archiveRevision;row.archiveName=bank.archiveName;row.memory=bank;row.updatedAt=bank.updatedAt;
 const fence=row.cache.modeWriteFencesV1?.album;if(!fence?.generation||!fence?.token)throw new Error('Fixture requires the current album fence');
 currentAlbum._rmtModeWriteFence=fence.generation+':'+fence.token;
 row.cache.archiveRevision=bank.archiveRevision;row.cache.album=currentAlbum;
 if(JSON.stringify(row.cache.__generationDraftsV2.records[draftId])!==original)throw new Error('Fixture must not rewrite paid journal');
 const db=await new Promise((resolve,reject)=>{const request=indexedDB.open('heartbeatMemoriesArchiveBackupsV1');request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error)});
 try{await new Promise((resolve,reject)=>{const tx=db.transaction('archives','readwrite');tx.objectStore('archives').put(row);tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error)})}finally{db.close()}
 context.chatMetadata.heartbeatMemoriesArchiveV3=copy(bank);context.chatMetadata.heartbeatMemoriesTheaterV3=copy(row.cache);context.saveMetadataDebounced();
 return {draftId,bank,currentAlbum,sourceMemory:copy(record.result.sourceMemory),journal:copy(record.journal)};
}
globalThis.__fixture={snapshot,canonical,advanceArchive,release(){releaseWait?.();releaseWait=null;phase='failed';localStorage.setItem('partial-phase',phase)},resume(){phase='resume';localStorage.setItem('partial-phase',phase)},pending:()=>!!releaseWait};
</script><script type="module" src="${prefix}${build}"></script>`;
}
let activeSeed;
const routes = { bundle: [], sourceBlocked: [], external: [], unexpected: [] };
const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://127.0.0.1'); res.setHeader('Cache-Control', 'no-store');
    if (url.pathname.startsWith(prefix)) {
        const relative = decodeURIComponent(url.pathname.slice(prefix.length)); const target = path.resolve(root, relative);
        if (!target.startsWith(root + path.sep) || relative.startsWith('src/')) { routes.sourceBlocked.push(relative); res.writeHead(403); return res.end(); }
        try { const bytes = await readFile(target); if (relative.startsWith('dist/')) routes.bundle.push(relative); res.setHeader('Content-Type', relative.endsWith('.json') ? 'application/json' : 'text/javascript; charset=utf-8'); return res.end(bytes); }
        catch { routes.unexpected.push(url.pathname); res.writeHead(404); return res.end(); }
    }
    if (url.pathname === '/favicon.ico') { res.writeHead(204); return res.end(); }
    if (url.pathname === '/thumbnail' || url.pathname.startsWith('/characters/')) { res.setHeader('Content-Type', 'image/svg+xml'); return res.end('<svg xmlns="http://www.w3.org/2000/svg" width="1" height="1"/>'); }
    if (url.pathname !== '/') { routes.unexpected.push(url.pathname); res.writeHead(500); return res.end('Unexpected host request'); }
    res.setHeader('Content-Type', 'text/html; charset=utf-8'); res.end(hostPage(activeSeed));
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const origin = `http://127.0.0.1:${server.address().port}`;
await mkdir(output, { recursive: true });
const browser = await chromium.launch({ headless: true, ...(process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE ? { executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE } : {}) });
const report = { hashes, evidence: 'index.js -> dist UI; synthetic provider; native IndexedDB', unverified: ['real SillyTavern/TT host', 'real provider/model', 'mobile operating-system background suspension'], matrix: [], routes };
async function openMenu(page) { await page.locator('#heartbeat_memories_menu_item').click(); }
async function openMode(page, spec, { reading = false } = {}) {
    if (spec.mode === 'calendar') {
        await page.locator('.rmt-workspace-tabs [data-rmt-workspace-tab="archive"]').click();
        const open = page.locator('[data-rmt-mode="calendar"]');
        if (reading) {
            await open.filter({ visible: true }).first().waitFor({ state: 'visible', timeout: 15000 });
            await open.filter({ visible: true }).first().click();
        } else if (await open.count()) await open.first().click();
        return;
    }
    await page.locator('.rmt-workspace-tabs [data-rmt-workspace-tab="content"]').click();
    await page.locator(`[data-rmt-workspace-group="${spec.mode === 'timeEcho' ? 'life' : spec.group}"]`).click();
    const route = spec.mode === 'items' ? 'room' : spec.mode === 'timeEcho' ? 'phone' : spec.route || spec.mode;
    await page.locator(`[data-rmt-workspace-route="${route}"]`).click();
    if (spec.mode === 'timeEcho') await page.locator('[data-rmt-mode="timeEcho"]').click();
    if (spec.mode === 'items' && reading) await page.locator('[data-rmt-action="room-open-items"]').click();
}
async function generate(page, spec) {
    const button = page.locator([spec.button, `[data-rmt-generate-mode="${spec.mode}"]`].filter(Boolean).join(',')).first();
    await button.evaluate(node => { for (let parent=node.parentElement;parent;parent=parent.parentElement) if(parent.tagName==='DETAILS')parent.open=true; });
    await button.click();
}
async function waitCanonical(page, predicate, label, timeout = 20000) {
    // Some bundled browser runners resolve async waitForFunction predicates to
    // false without polling. Await the native IDB read explicitly in Node, then
    // test the resolved records; a journal alone is never a readable result.
    const deadline = Date.now() + timeout;
    let rows = [];
    do {
        rows = await page.evaluate(() => __fixture.canonical());
        if (predicate(rows) === true) return rows;
        await new Promise(resolve => setTimeout(resolve, 100));
    } while (Date.now() < deadline);
    assert.fail(`Timed out waiting for ${label}; durable draft states: ${JSON.stringify(rows.flatMap(row => Object.entries(row.cache?.__generationDraftsV2?.records || {}).map(([id,record]) => ({id,status:record.status,mode:record.result?.mode,pageId:record.result?.pageId,hasResult:!!record.result}))))}`);
}
async function waitPartial(page, mode, pageId = mode === 'heart' ? 'language' : mode) {
    return waitCanonical(page, rows => rows.some(row => Object.entries(row.cache?.__generationDraftsV2?.records || {}).some(([draftId,record]) => record.result?.mode === mode
        && record.result.pageId === pageId && record.result.session?.kind === mode
        && record.result.session?.readableProgress?.draftId === draftId
        && record.result.session.readableProgress.pageId === pageId
        && record.result.session.readableProgress.complete === false)), `readable ${mode}/${pageId} result`);
}
async function waitStoppedDraft(page, mode) {
    return waitCanonical(page, rows => rows.some(row => Object.values(row.cache?.__generationDraftsV2?.records || {}).some(record => record.result?.mode === mode
        && (record.journal?.failureCode || record.journal?.segments?.some(segment => ['failed', 'truncated'].includes(segment.state))))), `stopped ${mode} draft with a saved result`);
}
async function readPage(page, spec) {
    await openMode(page, spec, { reading: true });
    const body = page.locator('.rmt-body');
    if (spec.mode === 'phone') {
        const entryBack = body.locator('[data-rmt-action="phone-entry-back"]');
        if (await entryBack.isVisible()) await entryBack.click();
        const home = body.locator('[data-rmt-action="phone-home"]');
        if (await home.isVisible()) await home.click();
        await body.locator('[data-rmt-phone-app="notes"]').filter({ visible: true }).first().click();
        await body.locator('[data-rmt-phone-entry="N1"]').click();
        await body.getByText(notesRow.detail, { exact: false }).filter({ visible: true }).first().waitFor();
    }
    if (spec.mode === 'inbox') {
        const back = body.locator('[data-rmt-inbox="back"]');
        if (await back.isVisible()) await back.click();
        await body.locator('[data-rmt-inbox="read"]').filter({ visible: true }).first().click();
        await body.getByText(letter.body, { exact: false }).filter({ visible: true }).first().waitFor();
    }
    if (spec.mode === 'calendar') await body.locator('[data-rmt-calendar-date="date:2008/05/18"]').filter({ visible: true }).first().click();
    await body.getByText(spec.sentinel, { exact: false }).filter({ visible: true }).first().waitFor({ state: 'visible', timeout: 15000 });
    const text = await body.innerText(); assert.ok(text.includes(spec.sentinel)); assert.ok(!text.includes('DO_NOT_INVENT'));
    return text;
}
try {
    for (const width of widths) for (const name of requested) {
        const spec = ['lifecycle','source-result'].includes(name) ? { mode: name, group: 'memory', route: 'album', sentinel: cg.title } : cases.find(item => item.mode === name);
        activeSeed = seed(spec, width);
        const context = await browser.newContext({ viewport: { width, height: 900 } });
        await context.route('**/*', async route => { if (!route.request().url().startsWith(origin + '/')) { routes.external.push(route.request().url()); return route.abort(); } return route.continue(); });
        const page = await context.newPage(); page.on('dialog', dialog => dialog.accept());
        const errors = []; page.on('pageerror', error => errors.push(String(error)));
        const result = { mode: name, width, status: 'running', errors };
        report.matrix.push(result);
        try {
            await page.goto(origin); await page.locator('#heartbeat_memories_menu_item').waitFor(); await openMenu(page); await openMode(page, spec);
            if (['lifecycle','source-result'].includes(name)) {
                await generate(page, { mode: 'album' }); await page.waitForFunction(() => __fixture.pending()); await waitPartial(page, 'album');
                result.whileGenerating = await readPage(page, spec);
                await page.locator('.rmt-topbar [data-rmt-action="close"]').click(); await openMenu(page); await readPage(page, spec);
                await page.evaluate(() => __fixture.release());
                await waitStoppedDraft(page, 'album');
            } else { await generate(page, spec); await waitPartial(page, spec.mode); result.beforeReload = await readPage(page, spec); }
            const before = await page.evaluate(() => __fixture.canonical());
            result.beforeReloadNativeRows = before;
            await page.screenshot({ path: path.join(output, `${name}-${width}-partial.png`), fullPage: true });
            await page.reload(); await page.locator('#heartbeat_memories_menu_item').waitFor(); await openMenu(page);
            result.afterReload = await readPage(page, spec);
            const callsBefore = await page.evaluate(async () => (await __fixture.snapshot()).calls.length);
            await readPage(page, spec); assert.equal(await page.evaluate(async () => (await __fixture.snapshot()).calls.length), callsBefore, 'opening a partial reader must not generate');
            if (['lifecycle','source-result'].includes(name)) {
                if (name === 'source-result') {
                    result.archiveTransition = await page.evaluate(() => __fixture.advanceArchive());
                    await page.reload(); await page.locator('#heartbeat_memories_menu_item').waitFor(); await openMenu(page);
                }
                await page.evaluate(() => __fixture.resume());
                await page.locator('.rmt-workspace-tabs [data-rmt-workspace-tab="archive"]').click();
                await page.locator('[data-rmt-recovery-mode="album"]').first().click();
                if (name === 'lifecycle') await waitCanonical(page, rows => rows.some(row => row.cache?.album?.entries?.[0]?.comments?.length === 6), 'completed album comments');
                else {
                    const { draftId, bank, currentAlbum, sourceMemory } = result.archiveTransition;
                    await waitCanonical(page, rows => rows.some(row => row.cache?.__generationDraftsV2?.records?.[draftId]?.status === 'awaiting-choice'), 'saved result awaiting choice');
                    await page.locator('.rmt-participant-dialog').waitFor();
                    result.beforeChoice = await page.evaluate(() => __fixture.canonical());
                    const beforeChoiceRow = result.beforeChoice.find(row => row.memory.archiveRevision === bank.archiveRevision);
                    const beforeChoiceAlbum = beforeChoiceRow?.cache.album;
                    assert.deepEqual(pageContent(beforeChoiceAlbum), pageContent(currentAlbum), 'continuing source A must preserve every current B content field');
                    assert.equal(beforeChoiceAlbum._rmtModeWriteFence, beforeChoiceRow.cache.modeWriteFencesV1.album.generation + ':' + beforeChoiceRow.cache.modeWriteFencesV1.album.token, 'current B page retains the active storage fence');
                    // Dispatch the real close button event while its modal backdrop
                    // covers it; this checks cleanup, not pointer reachability.
                    await page.locator('.rmt-topbar [data-rmt-action="close"]').dispatchEvent('click');
                    await page.locator('.rmt-participant-dialog').waitFor({ state: 'detached' });
                    result.closeTrigger = 'existing overlay close button DOM click event';
                    await page.reload(); await page.locator('#heartbeat_memories_menu_item').waitFor(); await openMenu(page);
                    await page.locator('.rmt-workspace-tabs [data-rmt-workspace-tab="archive"]').click();
                    let stored = (await page.evaluate(() => __fixture.canonical())).find(row => row.memory.archiveRevision === bank.archiveRevision);
                    assert.equal(stored.cache.__generationDraftsV2.records[draftId].status, 'awaiting-choice');
                    assert.deepEqual(stored.cache.album, beforeChoiceAlbum, 'closing a saved-result choice must leave current work unchanged');
                    const count = await page.evaluate(async () => (await __fixture.snapshot()).calls.length);
                    await page.locator(`[data-rmt-task-result-open="${draftId}"]`).click();
                    result.independentReading = await readPage(page, spec);
                    assert.ok(!result.independentReading.includes('CURRENT_B_ONLY'));
                    await page.reload(); await page.locator('#heartbeat_memories_menu_item').waitFor(); await openMenu(page);
                    await page.locator('.rmt-workspace-tabs [data-rmt-workspace-tab="archive"]').click();
                    await page.locator(`[data-rmt-task-result-choose="${draftId}"]`).click();
                    await page.locator('[data-rmt-task-result-decision="independent"]').click();
                    await readPage(page, spec);
                    await page.reload(); await page.locator('#heartbeat_memories_menu_item').waitFor(); await openMenu(page);
                    await page.locator('.rmt-workspace-tabs [data-rmt-workspace-tab="archive"]').click();
                    await page.locator(`[data-rmt-task-result-choose="${draftId}"]`).click();
                    await page.locator('[data-rmt-task-result-decision="apply"]').click();
                    await waitCanonical(page, rows => rows.some(row => row.cache?.__generationDraftsV2?.records?.[draftId]?.status === 'applied'), 'applied saved result');
                    stored = (await page.evaluate(() => __fixture.canonical())).find(row => row.memory.archiveRevision === bank.archiveRevision);
                    assert.deepEqual(stored.memory.memories, bank.memories);
                    assert.deepEqual(stored.cache.album.generationSources.album.sourceMemory, sourceMemory);
                    assert.ok(stored.cache.__archiveVersionsV1.some(version => JSON.stringify(version.cache.album) === JSON.stringify(beforeChoiceAlbum)), 'applying the saved result retains exact previous page B');
                    assert.equal(await page.evaluate(async () => (await __fixture.snapshot()).calls.length), count, 'reading and result choices cannot call generation API');
                    await readPage(page, spec);
                    result.sourcePreserved = true; result.closeSavedChoicePreserved = true; result.previousVersionPreserved = true;
                }
                const snapshot = await page.evaluate(() => __fixture.snapshot());
                assert.equal(snapshot.calls.filter(call => call.messages.some(message => message.content.includes('EXISTING_ALBUM_INDEX_JSON'))).length, 1, 'successful index must not be sent again');
                result.completedComments = 6;
            }
            result.final = await page.evaluate(() => __fixture.snapshot());
            result.nativeRows = await page.evaluate(() => __fixture.canonical());
            assert.ok(result.nativeRows.length, 'native IndexedDB must contain the durable result');
            assert.deepEqual(result.final.bank.memories, result.archiveTransition?.bank.memories || activeSeed.bank.memories, 'partial output never rewrites source memories');
            assert.equal(errors.length, 0, errors.join('\n')); result.status = 'passed';
            await page.screenshot({ path: path.join(output, `${name}-${width}-reopened.png`), fullPage: true });
        } catch (error) {
            result.status = 'failed'; result.error = String(error.stack || error);
            result.state = await page.evaluate(() => __fixture.snapshot()).catch(() => null);
            result.nativeRows = await page.evaluate(() => __fixture.canonical()).catch(() => null);
            result.html = await page.content().catch(() => '');
            await page.screenshot({ path: path.join(output, `${name}-${width}-failure.png`), fullPage: true }).catch(() => {});
        } finally { await context.close(); await writeFile(path.join(output, 'report.json'), JSON.stringify(report, null, 2)); }
    }
    assert.ok(routes.bundle.length, 'shipped dist was loaded'); assert.equal(routes.sourceBlocked.length, 0, 'no source module import was attempted');
    assert.equal(routes.external.length, 0, 'no external service request was attempted');
    assert.ok(report.matrix.every(row => row.status === 'passed'), 'one or more UI workflows failed; inspect report.json');
} finally {
    await writeFile(path.join(output, 'report.json'), JSON.stringify(report, null, 2));
    await browser.close(); await new Promise(resolve => server.close(resolve));
}
console.log(JSON.stringify({ passed: report.matrix.length, output, hashes }));
