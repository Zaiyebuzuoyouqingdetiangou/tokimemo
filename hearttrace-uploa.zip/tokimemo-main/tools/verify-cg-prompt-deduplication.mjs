// Real browser UI verification against index.js -> the shipped dist bundle.
// No production modules/hooks are imported, no IndexedDB replacement is installed,
// and no live image/text provider is contacted. The synthetic public image API is
// deliberately pending until the runner resolves or rejects that exact request.
// Run after rebuilding dist. Optional env: CG_DEDUP_OUTPUT_DIR,
// PLAYWRIGHT_CHROMIUM_EXECUTABLE. Requires the existing Playwright installation.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import http from 'node:http';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const outputDir = path.resolve(process.env.CG_DEDUP_OUTPUT_DIR || path.join(repoRoot, 'artifacts', 'cg-prompt-deduplication'));
const prefix = '/scripts/extensions/third-party/hearttrace/';
const build = JSON.parse(await readFile(path.join(repoRoot, 'manifest.json'), 'utf8')).js;
const sha256 = value => createHash('sha256').update(value).digest('hex');
const artifactPaths = ['index.js', 'dist/heartbeatMemories.bundle.js'];
const artifactHashes = Object.fromEntries(await Promise.all(artifactPaths.map(async name => [name, sha256(await readFile(path.join(repoRoot, name)))])));
const viewports = [390, 1280];
const names = { char: '林舟', user: '小月' };
const looks = { char: 'black hair, (blue eyes:1.15), black hair', user: 'white hair, green eyes' };
const naturalScene = '林舟站在窗边，小月坐在桌旁。保留手写重复：雨声，雨声。';
const tagScene = '2people, standing, sitting, (window light:1.2), window light';
const flatPrompt = 'USER_FLAT: (window light:1.2), window light; 林舟黑发蓝眼，小月白发绿眼。手写重复保留。';
const scenarios = [
    { id: 'nai-natural-no-flat', backend: 'nai', supportsCharacters: true, format: 'nai5-natural', scene: naturalScene, sceneTags: '', flat: '' },
    { id: 'nai-tags', backend: 'nai', supportsCharacters: true, format: 'nai45-tags', scene: tagScene, sceneTags: tagScene, flat: '' },
    { id: 'nai-natural-user-flat', backend: 'nai', supportsCharacters: true, format: 'nai5-natural', scene: naturalScene, sceneTags: '', flat: flatPrompt },
    { id: 'comfy-natural-no-flat', backend: 'comfyui', supportsCharacters: false, format: 'nai5-natural', scene: naturalScene, sceneTags: '', flat: '' },
    { id: 'comfy-tags-no-flat', backend: 'comfyui', supportsCharacters: false, format: 'nai45-tags', scene: tagScene, sceneTags: tagScene, flat: '' },
];
const originalImage = { url: '/user/images/fixture/original.png', prompt: 'ORIGINAL_MANUAL_PROMPT', provider: 'baibai-image', generatedAt: 1 };
const selectors = {
    menu: '#heartbeat_memories_menu_item', content: '.rmt-workspace-tabs [data-rmt-workspace-tab="content"]',
    memoryGroup: '[data-rmt-workspace-group="memory"]', album: '[data-rmt-workspace-route="album"]',
    settings: '[data-rmt-album-prompt="visual"]', dialog: '.rmt-cg-prompt-dialog',
    format: '[data-rmt-cg-editor-format]', scene: '[data-rmt-cg-prompt-input]',
    appearance: '[data-rmt-cg-appearance] > summary', sceneTags: '[data-rmt-cg-scene-tags]',
    flat: '[data-rmt-cg-flat-prompt]', preview: '[data-rmt-cg-send-preview]',
    draw: '[data-rmt-cg-prompt-action="draw"]', close: '[data-rmt-cg-prompt-action="close"]',
};

// Expected bytes are specified independently, without calling the formatter under test.
function expectedRequest(scenario) {
    const prompt = scenario.backend === 'nai'
        ? scenario.flat || (scenario.format === 'nai45-tags' ? scenario.sceneTags : scenario.scene)
        : `${scenario.scene}\n\n人物外貌（分别对应上述人物，保持原场景与动作）：\n${names.char}：${looks.char}\n${names.user}：${looks.user}`;
    return { prompt, nl: scenario.backend === 'nai' ? '' : prompt, size: 'landscape', save: true, character: names.char,
        ...(scenario.supportsCharacters ? { characters: ['char', 'user'].map(role => ({ name: names[role], tag: looks[role] })) } : {}) };
}
function expectedPreview(scenario) {
    const request = expectedRequest(scenario);
    return scenario.backend === 'nai'
        ? `prompt:\n${request.prompt}\n\n人物标签：\n${names.char}: ${looks.char}\n${names.user}: ${looks.user}`
        : `prompt / nl（相同，仅显示一次）:\n${request.prompt}`;
}

function makeSeed(scenario, width) {
    const chatId = `cg-dedup-${scenario.id}-${width}`;
    const bank = { version: 3, chatId, archiveRevision: `${chatId}-revision`, characterName: names.char, userName: names.user,
        archiveName: '浏览器合成旧档案', archiveSummary: '只用于离线验收。', createdAt: 1, updatedAt: 1,
        memories: [{ id: 'M001', title: '窗边阅读', summary: '林舟与小月在窗边一起阅读。', anchors: ['窗边'] }] };
    const item = { id: 'visual', title: '窗边阅读', date: '2008/05/10', desc: '原相册正文保留。', cgDesc: naturalScene,
        imagePrompt: naturalScene, unlocked: true, category: '日常', visualSeed: ['窗边'], cgImage: originalImage };
    const untouched = { ...item, id: 'untouched', title: '另一张旧图', cgImage: { ...originalImage, prompt: 'OTHER_IMAGE_MUST_STAY' } };
    const cache = { chatId, archiveRevision: bank.archiveRevision,
        album: { kind: 'album', chatId, archiveRevision: bank.archiveRevision, title: '旧相册', entries: [item, untouched],
            selectedId: 'visual', page: 1, pageSize: 6, category: '全部' },
        cabinet: { kind: 'cabinet', chatId, archiveRevision: bank.archiveRevision, items: [{ id: 'keep', text: 'OTHER_MODE_MUST_STAY' }] } };
    return { scenario, chatId, bank, cache, metadata: { heartbeatMemoriesArchiveV3: bank, heartbeatMemoriesTheaterV3: cache },
        newPath: `/user/images/fixture/${scenario.id}-${width}.png` };
}

function hostPage(seed) {
    // Host-owned methods and image public API only. These globals are fixture
    // instrumentation, never runtime hooks into the compiled plugin.
    return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<style>*{box-sizing:border-box}html,body{margin:0;width:100%;font-family:sans-serif;background:#eee}
#extensions_settings2,#extensionsMenu{padding:8px}.list-group-item{display:flex;gap:8px;padding:8px}.menu_button{font:inherit}</style>
</head><body><div id="extensions_settings2"><details id="other-extension"><summary>其他扩展</summary></details></div>
<div id="extensionsMenu"></div><script>
const seed = ${JSON.stringify(seed).replace(/</g, '\\u003c')};
const metadataKey = 'cg-dedup-host-metadata', settingsKey = 'cg-dedup-host-settings';
const copy = value => JSON.parse(JSON.stringify(value));
const listeners = new Map();
const calls = { requests: [], text: 0, metadataSave: 0, settingsSave: 0, notices: [] };
const pending = new Map();
const forbiddenText = () => { calls.text++; throw new Error('Unexpected text generation in image UI verification'); };
const context = { characterId: 0, groupId: null, chatId: seed.chatId, name1: '小月', name2: '林舟',
    characters: [{ name: '林舟', avatar: 'fixture.png', data: { name: '林舟', description: '合成角色资料。', personality: '认真。' } }],
    chat: [{ is_user: true, name: '小月', mes: '林舟与小月在窗边一起阅读。' }],
    chatMetadata: JSON.parse(localStorage.getItem(metadataKey) || JSON.stringify(seed.metadata)),
    extensionSettings: JSON.parse(localStorage.getItem(settingsKey) || JSON.stringify({ heartbeatMemories: {
        useCurrentChatExternalMemory: false, useActivatedWorldInfo: false, cgPromptFormat: seed.scenario.format } })),
    powerUserSettings: { persona_description: '合成用户资料。' },
    getCurrentChatId() { return this.chatId; }, getCharacterCardFields() { return copy(this.characters[0].data); },
    getRequestHeaders: () => ({ 'Content-Type': 'application/json' }), getTokenCountAsync: async () => 100,
    saveMetadataDebounced() { calls.metadataSave++; localStorage.setItem(metadataKey, JSON.stringify(context.chatMetadata)); },
    saveSettingsDebounced() { calls.settingsSave++; localStorage.setItem(settingsKey, JSON.stringify(context.extensionSettings)); },
    eventTypes: {}, eventSource: { on: (key, fn) => listeners.set(key, fn), off: key => listeners.delete(key) },
    generateRaw: forbiddenText, generateQuietPrompt: forbiddenText,
    ConnectionManagerRequestService: { sendRequest: forbiddenText },
};
globalThis.SillyTavern = { getContext: () => context };
globalThis.toastr = Object.fromEntries(['error', 'warning', 'info', 'success'].map(level =>
    [level, (...args) => calls.notices.push({ level, message: args.map(String).join(' ') })]));
globalThis.STBaiBaiImage = { apiVersion: 1, capabilities: { generate: true, saveToGallery: true },
    getBackendStatus: () => ({ configured: true, backend: seed.scenario.backend, supportsCharacters: seed.scenario.supportsCharacters }),
    generate(request, options) {
        const id = calls.requests.length + 1;
        calls.requests.push({ id, request: copy(request), hasAbortSignal: options?.signal instanceof AbortSignal });
        return new Promise((resolve, reject) => pending.set(id, { resolve, reject }));
    },
};
async function decodeMetadata(metadata) {
    const stored = metadata.heartbeatMemoriesTheaterV3;
    const cache = stored?.format === 'gzip-base64-v1'
        ? JSON.parse(await new Response(new Blob([Uint8Array.from(atob(stored.data), ch => ch.charCodeAt(0))])
            .stream().pipeThrough(new DecompressionStream('gzip'))).text()) : copy(stored);
    return { bank: copy(metadata.heartbeatMemoriesArchiveV3), cache,
        image: copy(cache?.album?.entries?.find(item => item.id === 'visual')?.cgImage || null) };
}
globalThis.__fixture = {
    calls, snapshot: () => decodeMetadata(context.chatMetadata),
    saved: () => decodeMetadata(JSON.parse(localStorage.getItem(metadataKey) || 'null') || seed.metadata),
    settle(id, outcome) {
        const task = pending.get(id); if (!task) throw new Error('No pending synthetic request ' + id);
        pending.delete(id);
        if (outcome === 'fail') task.reject(Object.assign(new Error('Synthetic image failure'), { code: 'backend_error' }));
        else if (outcome === 'success') task.resolve({ path: seed.newPath });
        else throw new Error('Unknown fixture outcome');
    },
};
</script><script type="module" src="${prefix}${build}"></script></body></html>`;
}

const routes = { runtime: [], sourceModules: [], api: [], external: [], unexpected: [] };
let activeSeed = null;
const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aH9sAAAAASUVORK5CYII=', 'base64');
const server = http.createServer(async (request, response) => {
    const url = new URL(request.url || '/', 'http://127.0.0.1');
    response.setHeader('Cache-Control', 'no-store');
    if (url.pathname.startsWith(prefix)) {
        const relative = decodeURIComponent(url.pathname.slice(prefix.length));
        const target = path.resolve(repoRoot, relative);
        if (!target.startsWith(repoRoot + path.sep)) { response.writeHead(403); response.end(); return; }
        if (relative.startsWith('src/')) { routes.sourceModules.push(relative); response.writeHead(403); response.end(); return; }
        try {
            const bytes = await readFile(target);
            if (relative === 'dist/heartbeatMemories.bundle.js') routes.runtime.push(request.url);
            response.setHeader('Content-Type', target.endsWith('.json') ? 'application/json' : 'text/javascript; charset=utf-8');
            response.end(bytes);
        } catch { routes.unexpected.push(url.pathname); response.writeHead(404); response.end(); }
        return;
    }
    if (url.pathname.startsWith('/api/')) {
        let body = ''; for await (const chunk of request) body += chunk;
        routes.api.push({ path: url.pathname, method: request.method, body });
        response.writeHead(500, { 'Content-Type': 'application/json' });
        response.end(JSON.stringify({ error: 'Unexpected host API; no real API is allowed in this fixture' })); return;
    }
    if (url.pathname.startsWith('/user/images/fixture/') || url.pathname === '/thumbnail' || url.pathname === '/characters/fixture.png') {
        response.setHeader('Content-Type', 'image/png'); response.end(png); return;
    }
    if (url.pathname === '/favicon.ico') { response.writeHead(204); response.end(); return; }
    if (url.pathname !== '/' || !activeSeed) { routes.unexpected.push(url.pathname); response.writeHead(404); response.end(); return; }
    response.setHeader('Content-Type', 'text/html; charset=utf-8'); response.end(hostPage(activeSeed));
});

async function openAlbum(page) {
    await page.locator(selectors.menu).waitFor({ state: 'visible' });
    await page.locator(selectors.menu).click();
    await page.locator(selectors.content).click();
    await page.locator(selectors.memoryGroup).click();
    await page.locator(selectors.album).click();
    await page.locator(selectors.settings).waitFor({ state: 'visible' });
}
async function openEditor(page) {
    await page.locator(selectors.settings).click();
    await page.locator(selectors.dialog).waitFor({ state: 'visible' });
}
async function editAndRead(page, scenario) {
    await page.locator(selectors.format).selectOption(scenario.format);
    await page.locator(selectors.scene).fill(scenario.scene);
    await page.locator(selectors.appearance).click();
    for (const role of ['char', 'user']) await page.locator(`[data-rmt-cg-tag-input="${role}"]`).fill(looks[role]);
    await page.locator(selectors.sceneTags).fill(scenario.sceneTags);
    await page.locator(selectors.flat).fill(scenario.flat); // last: edits to dependent fields invalidate flat
    const previewDetails = page.locator(`${selectors.dialog} details`).filter({ has: page.locator(selectors.preview) });
    await previewDetails.locator('summary').click();
    const preview = await page.locator(selectors.preview).inputValue();
    assert.equal(preview, expectedPreview(scenario), `${scenario.id}: exact visible send preview`);
    return preview;
}
async function snapshot(page, saved = false) { return page.evaluate(saved => saved ? __fixture.saved() : __fixture.snapshot(), saved); }
function assertOld(snapshotValue, seed, stage) {
    assert.deepEqual(snapshotValue.bank, seed.bank, `${stage}: memory archive unchanged`);
    assert.deepEqual(snapshotValue.image, originalImage, `${stage}: original image unchanged`);
    assert.deepEqual(snapshotValue.cache.album.entries, seed.cache.album.entries, `${stage}: original album content unchanged`);
    assert.deepEqual(snapshotValue.cache.cabinet, seed.cache.cabinet, `${stage}: other module unchanged`);
}
function assertSuccessful(value, seed, scenario) {
    assert.deepEqual(value.bank, seed.bank, 'successful image save preserves the memory archive');
    assert.equal(value.image.url, seed.newPath);
    assert.equal(value.image.prompt, scenario.scene, 'save retains the authored scene separately from provider composition');
    assert.equal(value.image.provider, 'baibai-image');
    assert.ok(value.image.generatedAt > 1);
    const metadata = { sceneTags: scenario.sceneTags, characters: ['char', 'user'].map(role =>
        ({ role, name: names[role], tag: looks[role], nl: '' })),
        ...(scenario.flat ? { flatPrompt: scenario.flat } : {}), promptFormat: scenario.format };
    assert.deepEqual(value.image.promptMetadata, metadata, 'saved editor fields retain authored duplicate tags/weights/flat');
    const withoutImage = item => Object.fromEntries(Object.entries(item).filter(([key]) => key !== 'cgImage'));
    assert.deepEqual(withoutImage(value.cache.album.entries[0]), withoutImage(seed.cache.album.entries[0]));
    assert.deepEqual(value.cache.album.entries[1], seed.cache.album.entries[1]);
    assert.deepEqual(value.cache.cabinet, seed.cache.cabinet);
}

await mkdir(outputDir, { recursive: true });
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const baseUrl = `http://127.0.0.1:${server.address().port}`;
const results = [];
const report = { ok: false, host: 'synthetic local SillyTavern public context',
    runtime: 'manifest index.js -> shipped dist; src browser imports forbidden', artifactHashes, selectors,
    storage: 'native Chromium IndexedDB; host saveMetadataDebounced mirror simulated by localStorage',
    coverage: scenarios.map(s => ({ id: s.id, backend: s.backend, supportsCharacters: s.supportsCharacters, format: s.format, flat: !!s.flat })),
    viewports, results, notVerified: ['real SillyTavern/TT/cloud host', 'physical mobile device',
        'live BaiBai/NAI/Comfy execution or model image quality', 'comic, legacy untyped direct calls, other modes or all domains'] };
let browser;
try {
    browser = await chromium.launch({ headless: true, executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || chromium.executablePath() });
    for (const width of viewports) for (const scenario of scenarios) {
        activeSeed = makeSeed(scenario, width);
        const seed = activeSeed;
        for (const values of Object.values(routes)) values.length = 0;
        const context = await browser.newContext({ viewport: { width, height: 900 }, deviceScaleFactor: 1 });
        const page = await context.newPage();
        page.setDefaultTimeout(15000);
        const result = { id: scenario.id, width, ok: false, stages: [], confirmations: [], pageErrors: [], consoleErrors: [] };
        results.push(result);
        let decisions = [];
        page.on('pageerror', error => result.pageErrors.push(error.message));
        page.on('console', message => { if (message.type() === 'error') result.consoleErrors.push(message.text()); });
        page.on('dialog', async dialog => {
            const decision = decisions.shift();
            result.confirmations.push({ type: dialog.type(), message: dialog.message(), accepted: decision === true });
            if (dialog.type() !== 'confirm' || typeof decision !== 'boolean') result.pageErrors.push('Unexpected native dialog');
            if (decision === true) await dialog.accept(); else await dialog.dismiss();
        });
        await page.route('**/*', route => {
            if (new URL(route.request().url()).origin === baseUrl) return route.continue();
            routes.external.push(route.request().url()); return route.abort();
        });
        try {
            await page.goto(baseUrl);
            await page.locator(selectors.menu).waitFor({ state: 'visible' });
            assert.equal(routes.runtime.length, 0, 'cold bootstrap stays lazy');
            await openAlbum(page);
            assert.equal(routes.runtime.length, 1, 'UI uses the shipped dist exactly once');
            assertOld(await snapshot(page), seed, 'open album');
            await openEditor(page);
            const preview = await editAndRead(page, scenario);
            result.preview = preview; result.previewSha256 = sha256(preview);
            assertOld(await snapshot(page), seed, 'edit preview');
            assert.equal(await page.evaluate(() => __fixture.calls.requests.length), 0);
            await page.locator(selectors.preview).scrollIntoViewIfNeeded();
            await page.screenshot({ path: path.join(outputDir, `${scenario.id}-${width}-preview.png`), fullPage: true });
            await page.locator(selectors.close).click();
            assertOld(await snapshot(page), seed, 'close draft');
            result.stages.push('open/edit/close: zero image requests; existing images and prose unchanged');

            await openEditor(page);
            assert.equal(await page.locator(selectors.scene).inputValue(), originalImage.prompt, 'closing discards the scene draft');
            await editAndRead(page, scenario);
            for (const answerSet of [[false], [true, false]]) {
                decisions = [...answerSet];
                await page.locator(selectors.draw).click();
                assert.deepEqual(decisions, [], 'all expected native confirmations were exercised');
                assert.equal(await page.locator(selectors.dialog).count(), 1, 'cancel keeps the draft open');
                assert.equal(await page.evaluate(() => __fixture.calls.requests.length), 0, 'cancel never calls the image API');
                assertOld(await snapshot(page), seed, `cancel confirmation ${answerSet.length}`);
            }
            result.stages.push('first/second confirmation cancelled: zero image requests; original image retained');

            decisions = [true, true];
            await page.locator(selectors.draw).click();
            await page.waitForFunction(() => __fixture.calls.requests.length > 0);
            assert.deepEqual(decisions, []);
            assert.equal(await page.locator(selectors.dialog).count(), 0, 'accepted draw closes editor');
            let requests = await page.evaluate(() => __fixture.calls.requests);
            assert.equal(requests.length, 1, 'one click submits exactly one public image request');
            assert.deepEqual(requests[0].request, expectedRequest(scenario));
            assert.equal(requests[0].hasAbortSignal, true);
            assertOld(await snapshot(page), seed, 'pending failed request');
            await page.evaluate(() => __fixture.settle(1, 'fail'));
            await page.waitForFunction(() => __fixture.calls.notices.some(row => row.level === 'error' && row.message.includes('旧图已保留')));
            await page.waitForFunction(selector => !document.querySelector(selector)?.disabled, selectors.settings);
            assertOld(await snapshot(page), seed, 'provider failure');
            assert.equal(await page.evaluate(() => __fixture.calls.requests.length), 1, 'failure has no automatic retry');
            result.stages.push('synthetic provider failure: one request; original image/prose retained; no automatic retry');

            await openEditor(page);
            await editAndRead(page, scenario);
            decisions = [true, true];
            await page.locator(selectors.draw).click();
            await page.waitForFunction(() => __fixture.calls.requests.length > 1);
            assert.deepEqual(decisions, []);
            requests = await page.evaluate(() => __fixture.calls.requests);
            assert.equal(requests.length, 2, 'success attempt adds exactly one request');
            assert.deepEqual(requests[1].request, expectedRequest(scenario));
            assert.equal(requests[1].hasAbortSignal, true);
            assertOld(await snapshot(page), seed, 'pending successful request');
            await page.evaluate(() => __fixture.settle(2, 'success'));
            await page.waitForFunction(async expected => (await __fixture.saved()).image?.url === expected, seed.newPath);
            await page.waitForFunction(() => __fixture.calls.notices.some(row => row.level === 'success' && row.message.includes('CG 已绘制')));
            const saved = await snapshot(page, true);
            assertSuccessful(saved, seed, scenario);
            result.savedImage = saved.image;
            result.requests = await page.evaluate(() => __fixture.calls.requests);
            result.requestJsonSha256 = result.requests.map(row => sha256(JSON.stringify(row.request)));
            result.callsBeforeReload = await page.evaluate(() => __fixture.calls);
            assert.equal(result.callsBeforeReload.requests.length, 2);
            assert.equal(result.callsBeforeReload.text, 0, 'UI edit/draw never starts text generation');
            result.stages.push('success: one additional request; saved image metadata matches edited fields; other item/module retained');

            await page.reload();
            await page.locator(selectors.menu).waitFor({ state: 'visible' });
            assert.equal(routes.runtime.length, 1, 'reload bootstrap remains lazy');
            await openAlbum(page);
            assert.equal(routes.runtime.length, 2, 'reopened page loads dist, not source');
            assertSuccessful(await snapshot(page), seed, scenario);
            const visibleImage = page.locator('[data-rmt-album-id="visual"] img');
            assert.equal(await visibleImage.getAttribute('src'), seed.newPath, 'reopened album renders saved image');
            await openEditor(page);
            assert.equal(await page.locator(selectors.scene).inputValue(), scenario.scene);
            assert.equal(await page.locator(selectors.format).inputValue(), scenario.format);
            assert.equal(await page.locator(selectors.flat).inputValue(), scenario.flat);
            assert.equal(await page.locator(selectors.preview).inputValue(), expectedPreview(scenario));
            for (const role of ['char', 'user']) assert.equal(await page.locator(`[data-rmt-cg-tag-input="${role}"]`).inputValue(), looks[role]);
            await page.locator(selectors.close).click();
            const callsAfterReload = await page.evaluate(() => __fixture.calls);
            assert.equal(callsAfterReload.requests.length, 0, 'reopen sends no image request');
            assert.equal(callsAfterReload.text, 0);
            result.callsAfterReload = callsAfterReload;
            result.indexedDbNames = await page.evaluate(async () => (await indexedDB.databases()).map(db => db.name));
            assert.ok(result.indexedDbNames.includes('heartbeatMemoriesArchiveBackupsV1'), 'real canonical IndexedDB exists');
            await page.screenshot({ path: path.join(outputDir, `${scenario.id}-${width}-saved-reopened.png`), fullPage: true });
            result.stages.push('fresh page: persisted image rendered; editor fields/preview restored; zero new provider requests');
            await page.evaluate(async entry => { const api = await import(entry); api.onDisable(); }, prefix + build);
            assert.equal(await page.locator(selectors.menu).count(), 0);
            assert.equal(await page.locator('#heartbeat_memories_overlay').count(), 0);
            assert.deepEqual(result.pageErrors, []);
            assert.deepEqual(routes.sourceModules, []);
            assert.deepEqual(routes.api, [], 'no unexpected host API calls');
            assert.deepEqual(routes.external, [], 'no live remote network attempts');
            assert.deepEqual(routes.unexpected, []);
            assert.equal(result.confirmations.length, 7, 'cancel first + cancel second + fail + success confirmations');
            result.routes = structuredClone(routes);
            result.ok = true;
        } catch (error) {
            result.error = { message: error.message, stack: error.stack };
            result.routes = structuredClone(routes);
            try { result.fixtureCallsAtFailure = await page.evaluate(() => __fixture.calls); } catch {}
            try { await page.screenshot({ path: path.join(outputDir, `${scenario.id}-${width}-failure.png`), fullPage: true }); } catch {}
            throw error;
        } finally { await context.close(); }
    }
    for (const name of artifactPaths) assert.equal(sha256(await readFile(path.join(repoRoot, name))), artifactHashes[name], `${name} unchanged during verification`);
    report.ok = true;
} catch (error) { report.error = { message: error.message, stack: error.stack }; process.exitCode = 1; }
finally {
    if (browser) await browser.close();
    await new Promise(resolve => server.close(resolve));
    await writeFile(path.join(outputDir, 'report.json'), JSON.stringify(report, null, 2));
    console.log(JSON.stringify(report, null, 2));
}
