// UI: real index.js -> dist, no production source imports and native IndexedDB.
// Database contracts: a separate page imports the real backupStore source module;
// no test backend/put replacement is installed. These two evidence levels are reported separately.
// Run after rebuilding dist. Env: PARTICIPANTS_OUTPUT_DIR, PLAYWRIGHT_CHROMIUM_EXECUTABLE,
// PARTICIPANTS_BROWSER_CASES=single,multi,database; PARTICIPANTS_SKIP_ROOM=1.
// All four native database contracts are approved and run unconditionally.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import http from 'node:http';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const outputDir = path.resolve(process.env.PARTICIPANTS_OUTPUT_DIR || path.join(repoRoot, 'artifacts', 'room-participants'));
const prefix = '/scripts/extensions/third-party/hearttrace/';
const sourcePrefix = '/contract-source/';
const build = JSON.parse(await readFile(path.join(repoRoot, 'manifest.json'), 'utf8')).js;
const sha = value => createHash('sha256').update(value).digest('hex');
const artifactNames = ['index.js', 'dist/heartbeatMemories.bundle.js', 'src/archive/backupStore.js'];
const artifactHashes = Object.fromEntries(await Promise.all(artifactNames.map(async name => [name, sha(await readFile(path.join(repoRoot, name)))])));
const requestedCases = (process.env.PARTICIPANTS_BROWSER_CASES || 'single,multi,database').split(',').filter(Boolean);
for (const name of requestedCases) assert.ok(['single', 'multi', 'database'].includes(name), `Unsupported case ${name}`);
const viewports = [390, 1280];
const cardName = '刀剑神域—沙盒';
const scene = '小月、林舟、沈砚和阿青在庭院一起栽花。林舟扶住花苗，沈砚递来工具，阿青和小月浇水。';
const selectedNames = ['林舟（已核对）', '沈砚', '阿青'];
const selectors = {
    menu: '#heartbeat_memories_menu_item', archiveTab: '.rmt-workspace-tabs [data-rmt-workspace-tab="archive"]',
    settingsTab: '.rmt-workspace-tabs [data-rmt-workspace-tab="settings"]',
    import: '[data-rmt-action="import-memory"]', picker: '.rmt-participant-dialog',
    single: '[data-rmt-card-type="single"]', multi: '[data-rmt-card-type="multi"]',
    book: '[data-rmt-participant-book]', entry: '[data-rmt-participant-entry]', name: '[data-rmt-participant-name]',
    confirm: '[data-rmt-participant-confirm]', close: '[data-rmt-participant-close]',
    status: '[data-rmt-participant-status]', reopen: '[data-rmt-action="participants-picker"]',
};
const chunkReply = { memories: [{ title: '一起栽花', summary: scene, anchors: ['庭院', '花苗'],
    participants: ['小月', '林舟', '沈砚', '阿青'], messageStart: 1, messageEnd: 1 }] };
const profileReply = {
    archiveName: '一起栽花', archiveSummary: '住户在庭院共同照料花苗。', keywords: ['庭院', '花苗'],
    relationshipReading: { char: '认真配合', user: '共同投入', relation: '一起劳动', tension: '尚无明确矛盾', direction: '合作逐渐熟悉' },
    verdictStyle: 'quiet-life',
    archiveVerdict: '一盆花的生长还需要往后的许多日子，彼此的配合也从这样具体的小事开始。他们没有急着给关系下定义，只把注意力放在眼前需要完成的事情上。在彼此都愿意投入的这段时间里，默契获得了一个可以慢慢生长的位置。故事没有把未来提前写好，留下的只是这次共同劳动，以及下一回仍有机会一起照料的期待。',
    verdictSources: [{ memoryId: 'M001', anchor: '庭院' }],
};

function seedFor(kind, width) {
    const chatId = `participants-${kind}-${width}`;
    const bank = { version: 3, chatId, archiveRevision: `${chatId}-old`, characterName: cardName, userName: '小月',
        archiveName: '旧档案保留', archiveSummary: '旧档案正文。', createdAt: 1, updatedAt: 1,
        memories: [{ id: 'M001', title: '一起栽花', summary: scene, anchors: ['庭院', '花苗'] }] };
    const cache = { chatId, archiveRevision: bank.archiveRevision,
        cabinet: { kind: 'cabinet', chatId, archiveRevision: bank.archiveRevision, items: [{ id: 'keep', text: 'OLD_CONTENT_KEEP' }] },
        album: { kind: 'album', chatId, archiveRevision: bank.archiveRevision, entries: [{ id: 'old-image', title: '旧照片',
            desc: 'OLD_IMAGE_TEXT_KEEP', imagePrompt: 'OLD_PROMPT_KEEP', unlocked: true, category: '日常',
            cgImage: { url: '/user/images/fixture/old.png', prompt: 'OLD_IMAGE_PROMPT_KEEP', provider: 'baibai-image', generatedAt: 1 } }],
            selectedId: 'old-image', page: 1, pageSize: 6, category: '全部' } };
    return { kind, width, chatId, cardName, scene, chunkReply, profileReply,
        metadata: kind === 'existing' ? { heartbeatMemoriesArchiveV3: bank, heartbeatMemoriesTheaterV3: cache } : {}, bank, cache };
}

function hostPage(seed) {
    return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<style>*{box-sizing:border-box}body{margin:0;font-family:sans-serif;background:#eee}#extensionsMenu,#extensions_settings2{padding:8px}</style>
</head><body><div id="extensions_settings2"></div><div id="extensionsMenu"></div><script>
const seed=${JSON.stringify(seed).replace(/</g, '\\u003c')};
const copy=value=>value==null?value:JSON.parse(JSON.stringify(value));
const metadataKey='participants-host-metadata',settingsKey='participants-host-settings';
const calls={requests:[],books:[],metadataSaves:0,settingsSaves:0,notices:[]};
const profile={id:'participants-profile',name:'Synthetic profile',mode:'cc',api:'openai',model:'fixture-model','secret-id':'synthetic-only'};
let replyKind='archive';
const context={characterId:0,groupId:null,chatId:seed.chatId,name1:'小月',name2:seed.cardName,
 characters:[{name:seed.cardName,avatar:'fixture.png',data:{name:seed.cardName,description:'现代都市合租住处。这里是多人沙盒卡，卡名不是人物。',personality:'按各自世界书人物资料行动。'}}],
 chat:[{is_user:true,name:'小月',mes:seed.scene}],powerUserSettings:{persona_description:'温和的花店店主。'},
 chatMetadata:JSON.parse(localStorage.getItem(metadataKey)||JSON.stringify(seed.metadata)),
 extensionSettings:JSON.parse(localStorage.getItem(settingsKey)||JSON.stringify({heartbeatMemories:{apiConnectionMode:'profile',connectionProfileId:profile.id,
 useCurrentChatExternalMemory:false,useActivatedWorldInfo:false,maxTokens:12000},connectionManager:{profiles:[profile]}})),
 getCurrentChatId(){return this.chatId},getCharacterCardFields(){return copy(this.characters[0].data)},
 getRequestHeaders:()=>({'Content-Type':'application/json'}),getTokenCountAsync:async()=>100,
 getWorldInfoNames:()=>['人物书'],loadWorldInfo:async name=>{calls.books.push(name);return {entries:{
 1:{uid:1,comment:'林舟',key:['林舟'],content:'林舟黑发蓝眼，认真而克制，住在现代都市的共用书房。这个条目也可以由用户确认用于另一人。'},
 2:{uid:2,comment:'沈砚',key:['沈砚'],content:'沈砚白发绿眼，喜欢整理书架，和其他住户共用书房。'}}}},
 saveMetadataDebounced(){calls.metadataSaves++;localStorage.setItem(metadataKey,JSON.stringify(context.chatMetadata))},
 saveSettingsDebounced(){calls.settingsSaves++;localStorage.setItem(settingsKey,JSON.stringify(context.extensionSettings))},
 eventTypes:{},eventSource:{on(){},off(){}},
 ConnectionManagerRequestService:{validateProfile:()=>({selected:'openai',source:'openai'}),
 async sendRequest(profileId,messages,outputTokens,options,overridePayload){
  const payload={secret_id:profile['secret-id'],model:profile.model,...overridePayload};
  if(profileId!==profile.id||payload.secret_id!=='synthetic-only')throw new Error('Unexpected profile route');
  calls.requests.push({profileId,messages:copy(messages),outputTokens,payload:copy(payload),hasSignal:options?.signal instanceof AbortSignal,replyKind});
  let response;
  if(replyKind==='archive'){
   const count=calls.requests.filter(row=>row.replyKind==='archive').length;
   if(count>2)throw new Error('Unexpected archive retry or extra model request');
   response=count===1?seed.chunkReply:seed.profileReply;
  }else{
   const state=await snapshot();const people=state.cache?.participantsV1?.people||[];const selected=new Set(state.cache?.participantsV1?.selectedIds||[]);
   const cast=people.filter(person=>selected.has(person.id));
   if(replyKind==='room')response={title:'共同房间',homeName:'共用住处',homeSummary:'住户共同使用的书房。',visualProfile:{},
    spaces:[{id:'SP01',label:'共用书房',spaceType:'书房',atmosphere:'书架沿墙摆放。',objects:[{id:'OBJ01',label:'木盒',zone:'中央',basis:'设定',searchable:true,
    description:'木盒中放着常用工具。',line:'工具在这里。',speakerId:cast[0]?.id,sourceMemoryIds:[],sourceMemoryAnchor:''}]}],
    residents:cast.map(person=>({participantId:person.id,visualProfile:{},dayparts:Object.fromEntries(['morning','daytime','evening','night'].map(key=>[key,
     {spaceId:'SP01',activity:person.name+'整理书架',line:person.name+'现在正在整理书架。',focusObjectId:'OBJ01'}])),presenceLines:[person.name+'的第一句',person.name+'的第二句']}))};
   else if(replyKind==='room-life')response={beats:[{time:'00:00',participants:cast.map(person=>({participantId:person.id,spaceId:'SP01',activity:person.name+'整理书架',
    line:person.name+'该读书了',focusObjectId:'OBJ01',ambient:'灯光照进书房',trace:'书页展开着',visualState:{},temporaryObjects:[],sourceMemoryIds:[],sourceMemoryAnchor:''}))}]};
   else throw new Error('Unknown synthetic response kind');
  }
  return {content:JSON.stringify(response)};
 }} };
globalThis.SillyTavern={getContext:()=>context};
globalThis.toastr=Object.fromEntries(['error','warning','info','success'].map(level=>[level,(...args)=>calls.notices.push({level,message:args.map(String).join(' ')})]));
async function decode(value){if(value?.format!=='gzip-base64-v1')return copy(value);return JSON.parse(await new Response(new Blob([Uint8Array.from(atob(value.data),ch=>ch.charCodeAt(0))]).stream().pipeThrough(new DecompressionStream('gzip'))).text())}
async function snapshot(){return {bank:copy(context.chatMetadata.heartbeatMemoriesArchiveV3),cache:await decode(context.chatMetadata.heartbeatMemoriesTheaterV3),
 cardName:context.name2,characterName:context.characters[0].name,chat:copy(context.chat),metadata:copy(context.chatMetadata)}}
async function canonical(){
 const names=await indexedDB.databases();if(!names.some(row=>row.name==='heartbeatMemoriesArchiveBackupsV1'))return [];
 const db=await new Promise((resolve,reject)=>{const r=indexedDB.open('heartbeatMemoriesArchiveBackupsV1');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)});
 try{const rows=await new Promise((resolve,reject)=>{const tx=db.transaction('archives','readonly'),r=tx.objectStore('archives').getAll();r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)});
 return await Promise.all(rows.map(async row=>({...row,cache:await decode(row.cache)})))}finally{db.close()}
}
globalThis.__fixture={calls,snapshot,canonical,setReplyKind:value=>{replyKind=value},seed:copy(seed)};
</script><script type="module" src="${prefix}${build}"></script></body></html>`;
}

const routeLog = { runtime: [], uiSourceRejected: [], contractSource: [], api: [], external: [], unexpected: [] };
let activeSeed;
const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aH9sAAAAASUVORK5CYII=', 'base64');
const server = http.createServer(async (request, response) => {
    const url = new URL(request.url || '/', 'http://127.0.0.1');
    response.setHeader('Cache-Control', 'no-store');
    const isContract = url.pathname.startsWith(sourcePrefix);
    if (url.pathname.startsWith(prefix) || isContract) {
        const relative = decodeURIComponent(url.pathname.slice((isContract ? sourcePrefix : prefix).length));
        const target = path.resolve(repoRoot, relative);
        if (!target.startsWith(repoRoot + path.sep)) { response.writeHead(403); response.end(); return; }
        if (!isContract && relative.startsWith('src/')) { routeLog.uiSourceRejected.push(relative); response.writeHead(403); response.end(); return; }
        if (isContract) routeLog.contractSource.push(relative);
        try { const bytes = await readFile(target); if (relative === 'dist/heartbeatMemories.bundle.js') routeLog.runtime.push(request.url);
            response.setHeader('Content-Type', target.endsWith('.json') ? 'application/json' : 'text/javascript; charset=utf-8'); response.end(bytes);
        } catch { routeLog.unexpected.push(url.pathname); response.writeHead(404); response.end(); }
        return;
    }
    if (url.pathname === '/database-contract') { response.setHeader('Content-Type', 'text/html'); response.end('<!doctype html><meta charset="utf-8"><title>Native IndexedDB source contracts</title>'); return; }
    if (url.pathname.startsWith('/api/')) { let body = ''; for await (const chunk of request) body += chunk;
        routeLog.api.push({ path: url.pathname, body }); response.writeHead(500); response.end('Unexpected host request'); return; }
    if (url.pathname.startsWith('/user/images/fixture/') || url.pathname === '/characters/fixture.png' || url.pathname === '/thumbnail') {
        response.setHeader('Content-Type', 'image/png'); response.end(png); return;
    }
    if (url.pathname === '/favicon.ico') { response.writeHead(204); response.end(); return; }
    if (url.pathname !== '/' || !activeSeed) { routeLog.unexpected.push(url.pathname); response.writeHead(404); response.end(); return; }
    response.setHeader('Content-Type', 'text/html; charset=utf-8'); response.end(hostPage(activeSeed));
});

async function openArchive(page) {
    await page.locator(selectors.menu).waitFor({ state: 'visible' });
    await page.locator(selectors.menu).click();
    await page.locator(selectors.archiveTab).click();
    await page.locator(selectors.import).waitFor({ state: 'visible' });
}
async function chooseThree(page) {
    await page.locator(selectors.book).selectOption('人物书');
    await page.locator('[data-rmt-participant-entry="0"]').check();
    await page.locator('[data-rmt-participant-entry="1"]').check();
    assert.equal(await page.locator('[data-rmt-participant-name="0"]').inputValue(), '林舟', 'title is only the editable initial name');
    await page.locator('[data-rmt-participant-name="0"]').fill(selectedNames[0]);
    await page.locator('[data-rmt-participant-duplicate="0"]').click();
    await page.locator('[data-rmt-participant-name="2"]').fill(selectedNames[2]);
    assert.equal(await page.locator(selectors.name).count(), 3);
    assert.equal(await page.evaluate(() => __fixture.calls.requests.length), 0, 'selection/editing does not invoke a model');
}
async function openSavedPicker(page) {
    await page.locator(selectors.settingsTab).click();
    const control = page.locator(selectors.reopen);
    await control.evaluate(button => { let ancestor = button.parentElement; while (ancestor) { if (ancestor.tagName === 'DETAILS') ancestor.open = true; ancestor = ancestor.parentElement; } });
    await control.click();
    await page.locator(selectors.picker).waitFor({ state: 'visible' });
}
async function stateOf(page) { return page.evaluate(() => __fixture.snapshot()); }
async function waitForSavedState(page, predicate, label) {
    const deadline = Date.now() + 15000;
    while (Date.now() < deadline) {
        const state = await stateOf(page);
        if (predicate(state)) return state;
        await new Promise(resolve => setTimeout(resolve, 50));
    }
    throw new Error(`Timed out waiting for ${label}`);
}
function checkCast(roster) {
    assert.equal(roster?.cardType, 'multi');
    assert.equal(roster.people.length, 3); assert.equal(roster.selectedIds.length, 3);
    assert.deepEqual(roster.people.map(person => person.name), selectedNames);
    assert.equal(new Set(roster.people.map(person => person.id)).size, 3);
    assert.deepEqual(roster.people[0].sourceRefs, roster.people[2].sourceRefs, 'one source entry may describe two distinct selected people');
}
function checkHost(value, seed) {
    assert.equal(value.cardName, seed.cardName); assert.equal(value.characterName, seed.cardName);
    assert.deepEqual(value.chat, [{ is_user: true, name: '小月', mes: seed.scene }]);
    if (seed.kind === 'existing') {
        assert.deepEqual(value.bank, seed.bank); assert.deepEqual(value.cache.album, seed.cache.album); assert.deepEqual(value.cache.cabinet, seed.cache.cabinet);
    }
}

async function verifyRoom(page, result, decisions) {
    const before = await stateOf(page), roster = before.cache.participantsV1;
    await page.evaluate(() => __fixture.setReplyKind('room'));
    await page.locator('.rmt-workspace-tabs [data-rmt-workspace-tab="content"]').click();
    await page.locator('[data-rmt-workspace-group="life"]').click();
    await page.locator('[data-rmt-workspace-route="room"]').click();
    const generate = page.locator('[data-rmt-generate-mode="room"]');
    await generate.waitFor({ state: 'visible' });
    await generate.click();
    await page.locator('.rmt-room-resident-figure').first().waitFor({ state: 'visible' });
    assert.equal(await page.locator('.rmt-room-resident-figure').count(), 3);
    for (const person of roster.people) {
        await page.locator(`.rmt-room-participant[data-rmt-participant-id="${person.id}"]`).click();
        const text = await page.locator(`[data-rmt-participant-state="${person.id}"]`).innerText();
        assert.ok(text.includes(person.name)); assert.ok(text.includes('第一句') || text.includes('第二句'));
    }
    let calls = await page.evaluate(() => __fixture.calls.requests);
    assert.equal(calls.filter(row => row.replyKind === 'room').length, 1, 'one room request includes all people');
    assert.deepEqual((await stateOf(page)).cache.participantsV1, roster, 'clicking a person does not change the selected cast');
    await page.evaluate(() => __fixture.setReplyKind('room-life'));
    decisions.push(true, true);
    await page.locator('[data-rmt-action="room-life-refresh"]').click();
    await waitForSavedState(page, state => state.cache?.room?.lifePlan?.beats?.[0]?.participants?.length === 3, 'persisted multiplayer life plan');
    calls = await page.evaluate(() => __fixture.calls.requests);
    assert.equal(calls.filter(row => row.replyKind === 'room-life').length, 1);
    const after = await stateOf(page);
    assert.equal(after.cache.room.lifePlan.beats[0].participants.length, 3);
    assert.deepEqual(after.cache.participantsV1, roster);
    result.room = { people: roster.people.map(person => ({ id: person.id, name: person.name })), sameTimeBeat: after.cache.room.lifePlan.beats[0],
        requests: calls.filter(row => row.replyKind !== 'archive') };
    result.stages.push('dist shared room: three figures; each person has an attributed clickable line; one room request and one shared-time life request');
}

async function verifyCompletedChanges(page, result) {
    await page.locator('.rmt-inline-status:visible').waitFor({ state: 'hidden' });
    await openSavedPicker(page);
    const before = await stateOf(page);
    const count = await page.evaluate(() => __fixture.calls.requests.length);
    await page.locator('[data-rmt-participant-name="0"]').fill('这次取消的名字');
    await page.locator(selectors.confirm).click();
    await page.locator('[data-rmt-participant-decision="append"]').waitFor();
    await page.locator(selectors.close).click();
    assert.deepEqual((await stateOf(page)).cache, before.cache, 'cancelled decision saves nothing');
    assert.equal(await page.evaluate(() => __fixture.calls.requests.length), count);

    await openSavedPicker(page);
    await page.locator('[data-rmt-participant-add]').click();
    await page.locator('[data-rmt-participant-name="3"]').fill('新住户');
    await page.locator('[data-rmt-participant-selected="3"]').check();
    await page.locator(selectors.confirm).click();
    await page.locator('[data-rmt-participant-decision="append"]').click();
    const appended = await waitForSavedState(page, state => state.cache?.participantsV1?.selectedIds?.length === 4, 'append fourth person');
    assert.deepEqual(appended.cache.room, before.cache.room, 'append retains complete old room and life');
    assert.deepEqual(appended.bank, before.bank);
    assert.equal(await page.evaluate(() => __fixture.calls.requests.length), count, 'append makes zero API calls');
    result.stages.push('completed-task decisions: cancel saves nothing; append adds one person with zero API requests and preserves room/life');

    await openSavedPicker(page);
    await page.locator('[data-rmt-participant-name="3"]').fill('新住户（已核对）');
    await page.locator(selectors.confirm).click();
    await page.locator('[data-rmt-participant-decision="select-scopes"]').click();
    assert.equal(await page.locator('[data-rmt-participant-scope]:checked').count(), 0, 'user selects regeneration scope');
    await page.locator('[data-rmt-participant-decision="regenerate"]').click();
    assert.ok((await page.locator(selectors.status).innerText()).includes('请勾选'));
    assert.equal(await page.evaluate(() => __fixture.calls.requests.length), count);
    await page.locator('[data-rmt-participant-scope="room"]').check();
    await page.screenshot({ path: path.join(outputDir, `multi-${result.width}-regeneration-scope.png`), fullPage: true });
    await page.evaluate(() => __fixture.setReplyKind('room'));
    await page.locator('[data-rmt-participant-decision="regenerate"]').click();
    const regenerated = await waitForSavedState(page, state => state.cache?.room?.residents?.length === 4, 'only selected room regenerated');
    assert.deepEqual(regenerated.bank, appended.bank);
    assert.deepEqual(regenerated.cache.room.lifePlan, appended.cache.room.lifePlan, 'unselected life remains exact');
    for (const [key, value] of Object.entries(appended.cache)) {
        if (['room', 'participantsV1', '__archiveVersionsV1', 'commitToken', 'updatedAt'].includes(key)) continue;
        if (['modeWriteFencesV1', '__generationRecoveryClearedV1', '__generationRecoveryV1'].includes(key)) {
            const withoutRoom = data => Object.fromEntries(Object.entries(data || {}).filter(([mode]) => mode !== 'room'));
            assert.deepEqual(withoutRoom(regenerated.cache[key]), withoutRoom(value), `unselected mode metadata retained: ${key}`);
            continue;
        }
        if (key === '__generationDraftsV2') {
            // This explicit room replacement creates/completes its own draft.
            // Keep exact checks for every other page, including roomLife, rather
            // than treating the selected page's new tombstone as content loss.
            const withoutRoomPage = data => ({ ...data, records: Object.fromEntries(Object.entries(data?.records || {}).filter(([, row]) =>
                !((row.mode || row.journal?.identity?.mode || row.result?.mode) === 'room'
                    && (row.pageId || row.journal?.pageId || row.result?.pageId || 'room') === 'room'))) });
            assert.deepEqual(withoutRoomPage(regenerated.cache[key]), withoutRoomPage(value), 'unselected page drafts remain exact');
            continue;
        }
        assert.deepEqual(regenerated.cache[key], value, `unselected cache field retained: ${key}`);
    }
    assert.equal(regenerated.cache.modeWriteFencesV1.room.generation, appended.cache.modeWriteFencesV1.room.generation + 1,
        'the selected room advances its existing write fence exactly once');
    assert.equal(await page.evaluate(() => __fixture.calls.requests.length), count + 1, 'only one selected room request');
    const versions = regenerated.cache.__archiveVersionsV1;
    assert.equal(versions.length, 1);
    assert.deepEqual(versions[0].cache.room, appended.cache.room);
    result.stages.push('room-only regeneration: no default checked scope; one room request; old life and other cache fields preserved; version saved');

    await page.reload(); await openArchive(page);
    assert.equal(await page.evaluate(() => __fixture.calls.requests.length), 0);
    await page.locator(selectors.settingsTab).click();
    const versionsButton = page.locator('[data-rmt-action="participants-versions"]');
    await versionsButton.evaluate(button => { let node = button.parentElement; while (node) { if (node.tagName === 'DETAILS') node.open = true; node = node.parentElement; } });
    await versionsButton.click();
    await page.locator('[data-rmt-participant-version="0"]').waitFor();
    const beforeViewing = await stateOf(page);
    for (const [key, value] of Object.entries(regenerated.cache)) {
        if (['commitToken', 'updatedAt'].includes(key)) continue;
        assert.deepEqual(beforeViewing.cache[key], value, `fresh reload retains content: ${key}`);
    }
    await page.locator('[data-rmt-participant-version="0"]').click();
    await page.getByText('重做前旧版本 · 永久只读', { exact: false }).waitFor();
    assert.equal(await page.locator('[data-rmt-readonly-toggle]').isDisabled(), true);
    await page.screenshot({ path: path.join(outputDir, `multi-${result.width}-previous-version.png`), fullPage: true });
    await page.locator('.rmt-workspace-tabs [data-rmt-workspace-tab="content"]').click();
    await page.locator('[data-rmt-workspace-group="life"]').click();
    await page.locator('[data-rmt-workspace-route="room"]').click();
    await page.locator('.rmt-room-resident-figure').first().waitFor({ state: 'visible' });
    assert.equal(await page.locator('.rmt-room-resident-figure').count(), 3, 'old version displays old three-resident room');
    assert.equal(await page.evaluate(() => __fixture.calls.requests.length), 0, 'reading history sends zero API requests');
    assert.deepEqual((await stateOf(page)).cache, beforeViewing.cache, 'viewing history does not write or replace current data');
    result.stages.push('reload and open previous version: old three-person room remains readable; permanently read-only; current four-person room unchanged');
}

async function nativeDatabaseContracts(page) {
    return page.evaluate(async ({ moduleUrl }) => {
        const store = await import(moduleUrl);
        const rows = [];
        const ensure = (condition, message) => { if (!condition) throw new Error(message); };
        const make = id => {
            const entry = { entryId: `participants-contract-${id}`, chatId: `contract-${id}`, characterName: 'Contract sandbox', avatar: `contract-${id}.png`, characterIndexHint: 0 };
            const memory = revision => ({ version: 3, chatId: entry.chatId, archiveRevision: revision, characterName: entry.characterName, userName: 'User', archiveName: 'Native IDB contract', memories: [] });
            const cache = (revision, order, selected) => ({ chatId: entry.chatId, archiveRevision: revision, commitToken: order, updatedAt: order,
                participantsV1: { version: 1, cardType: 'multi', revision: selected, people: [], selectedIds: [] } });
            return { entry, memory, cache };
        };
        const run = async (name, check) => {
            const result = { name, ok: false, status: 'executed' }; rows.push(result);
            try { result.evidence = await check(); result.ok = true; }
            catch (error) { result.error = { message: error.message, code: error.code || '', stack: error.stack }; } };
        await run('comparePreviousCache cross-revision write succeeds when prior cache order still matches', async () => {
            const f = make('cross-success'); await store.seedArchiveBackup(f.entry, f.memory('A'), f.cache('A', 10, 'roster-A'));
            await store.replaceArchiveBackup(f.entry, f.memory('B'), f.cache('B', 11, 'roster-A'), { present: true, revision: 'A' }, { expectedCacheOrder: 10, comparePreviousCache: true });
            const actual = await store.readArchiveBackup(f.entry); ensure(actual.archiveRevision === 'B', 'new archive revision not persisted'); return actual;
        }, true);
        await run('a same-revision edit after the read prevents the stale cross-revision replacement', async () => {
            const f = make('cross-conflict'); await store.seedArchiveBackup(f.entry, f.memory('A'), f.cache('A', 10, 'roster-A'));
            const earlier = await store.readArchiveBackup(f.entry);
            await store.updateArchiveBackupCache(f.entry, f.memory('A'), f.cache('A', 20, 'roster-B'), { expectedCacheOrder: 10 });
            let conflict; try { await store.replaceArchiveBackup(f.entry, f.memory('B'), f.cache('B', 21, 'roster-A'), { present: true, revision: 'A' },
                { expectedCacheOrder: earlier.cache.commitToken, comparePreviousCache: true }); } catch (error) { conflict = error; }
            ensure(conflict?.code === 'RMT_CACHE_CAS_CONFLICT', 'stale cross-revision write was not rejected with the existing CAS code');
            const actual = await store.readArchiveBackup(f.entry); ensure(actual.archiveRevision === 'A' && actual.cache.participantsV1.revision === 'roster-B', 'newer selection was overwritten');
            return { code: conflict.code, record: actual };
        }, true);
        await run('without the new option the original cross-revision cache-CAS behavior is retained', async () => {
            const f = make('old-option'); await store.seedArchiveBackup(f.entry, f.memory('A'), f.cache('A', 10, 'roster-A'));
            let conflict; try { await store.replaceArchiveBackup(f.entry, f.memory('B'), f.cache('B', 11, 'roster-A'), { present: true, revision: 'A' }, { expectedCacheOrder: 10 }); }
            catch (error) { conflict = error; }
            ensure(conflict?.code === 'RMT_CACHE_CAS_CONFLICT', 'legacy expectedCacheOrder behavior changed');
            await store.replaceArchiveBackup(f.entry, f.memory('B'), f.cache('B', 11, 'roster-A'), { present: true, revision: 'A' });
            const actual = await store.readArchiveBackup(f.entry); ensure(actual.archiveRevision === 'B', 'legacy no-CAS replacement no longer works'); return actual;
        });
        await run('original same-revision cache CAS rejects stale order and accepts the exact order', async () => {
            const f = make('same-revision'); await store.seedArchiveBackup(f.entry, f.memory('A'), f.cache('A', 10, 'roster-A'));
            let conflict; try { await store.updateArchiveBackupCache(f.entry, f.memory('A'), f.cache('A', 20, 'wrong'), { expectedCacheOrder: 9 }); } catch (error) { conflict = error; }
            ensure(conflict?.code === 'RMT_CACHE_CAS_CONFLICT', 'stale same-revision write accepted');
            await store.updateArchiveBackupCache(f.entry, f.memory('A'), f.cache('A', 20, 'roster-B'), { expectedCacheOrder: 10 });
            const actual = await store.readArchiveBackup(f.entry); ensure(actual.cache.participantsV1.revision === 'roster-B', 'exact-order update not persisted'); return actual;
        });
        return { evidenceLevel: 'real backupStore source module + native browser IndexedDB; separate from dist UI',
            testBackendInstalled: false, databases: await indexedDB.databases(), cases: rows,
            ok: rows.filter(row => row.ok !== null).every(row => row.ok), complete: rows.every(row => row.ok === true && row.status === 'executed') };
    }, { moduleUrl: sourcePrefix + 'src/archive/backupStore.js' });
}

await mkdir(outputDir, { recursive: true });
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const baseUrl = `http://127.0.0.1:${server.address().port}`;
const report = { ok: false, artifactHashes, requestedCases, viewports, selectors, ui: [], database: null,
    evidence: { ui: 'manifest index.js -> shipped dist; production source import forbidden', storage: 'native Chromium IndexedDB; synthetic host metadata mirror uses localStorage',
        provider: 'synthetic five-parameter profile service with unchanged secret/model capability checks; no paid request' },
    notVerified: ['real SillyTavern/TT/cloud integration', 'physical mobile background/suspend behavior', 'live model/provider output quality',
        'interrupting a live request is covered separately from the completed-task UI cases in this harness',
        ...(['single', 'multi', 'database'].filter(name => !requestedCases.includes(name)).map(name => `case omitted by configuration: ${name}`)),
        ...(process.env.PARTICIPANTS_SKIP_ROOM === '1' ? ['room interaction omitted by PARTICIPANTS_SKIP_ROOM'] : [])] };
let browser;
try {
    browser = await chromium.launch({ headless: true, executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || chromium.executablePath() });
    for (const width of viewports) for (const kind of requestedCases.filter(name => name !== 'database')) {
        activeSeed = seedFor(kind, width); const seed = activeSeed;
        const context = await browser.newContext({ viewport: { width, height: 900 }, deviceScaleFactor: 1 });
        const page = await context.newPage(); page.setDefaultTimeout(15000);
        const result = { kind, width, ok: false, stages: [], confirmations: [], pageErrors: [], consoleErrors: [] }; report.ui.push(result);
        const decisions = [];
        page.on('pageerror', error => result.pageErrors.push(error.message));
        page.on('console', message => { if (message.type() === 'error') result.consoleErrors.push(message.text()); });
        page.on('dialog', async dialog => { const accepted = decisions.shift(); result.confirmations.push({ message: dialog.message(), accepted: accepted === true });
            if (typeof accepted !== 'boolean') result.pageErrors.push('Unexpected native confirmation');
            if (accepted === true) await dialog.accept(); else await dialog.dismiss(); });
        await page.route('**/*', route => { const url = new URL(route.request().url());
            if (url.origin === baseUrl && !url.pathname.startsWith(sourcePrefix)) return route.continue();
            routeLog.external.push(url.href); return route.abort(); });
        try {
            await page.goto(baseUrl); await openArchive(page); const initial = await stateOf(page);
            checkHost(initial, seed);
            {
                await page.locator(selectors.import).click();
                assert.equal(await page.locator(selectors.single).count(), 1); assert.equal(await page.locator(selectors.multi).count(), 1);
                assert.equal(await page.evaluate(() => __fixture.calls.requests.length), 0);
                if (kind === 'single') {
                    decisions.push(false); await page.locator(selectors.single).click();
                    assert.equal(await page.evaluate(() => __fixture.calls.requests.length), 0);
                    await page.locator(selectors.import).click(); decisions.push(true, true); await page.locator(selectors.single).click();
                } else await page.locator(selectors.multi).click();
            }
            if (kind !== 'single') {
                if (kind === 'multi') { await page.locator(selectors.confirm).click();
                    assert.ok((await page.locator(selectors.status).innerText()).includes('请先勾选')); assert.equal(await page.locator(selectors.picker).count(), 1); }
                await chooseThree(page); await page.locator(selectors.close).click();
                assert.equal(await page.evaluate(() => __fixture.calls.requests.length), 0); checkHost(await stateOf(page), seed);
                assert.deepEqual((await stateOf(page)).metadata, initial.metadata, 'cancelled selection writes no metadata');
                await page.locator(selectors.archiveTab).click(); await page.locator(selectors.import).click(); await page.locator(selectors.multi).click();
                await chooseThree(page); if (kind === 'multi') decisions.push(true, true); await page.locator(selectors.confirm).click();
                result.stages.push('editable worldbook titles, two entries, one entry assigned to a second person; cancel and empty selection send zero model requests');
            }
            await page.waitForFunction(() => __fixture.calls.notices.some(row => row.level === 'success' && row.message.includes('创建完成')));
            await waitForSavedState(page, state => state.bank?.memories?.length > 0, 'saved archive');
            const saved = await stateOf(page); checkHost(saved, seed);
            const calls = await page.evaluate(() => __fixture.calls); result.callsBeforeReload = calls;
            assert.equal(calls.requests.length, 2, 'archive flow is one extraction + one profile request, never one request per selected NPC');
            assert.deepEqual(decisions, []);
            if (kind === 'single') { assert.equal(saved.bank.participantsV1, undefined); assert.equal(saved.cache?.participantsV1, undefined); }
            else { checkCast(saved.cache.participantsV1); const records = await page.evaluate(() => __fixture.canonical());
                const canonical = records.find(row => row.chatId === seed.chatId); checkCast(canonical?.cache?.participantsV1);
                assert.deepEqual(canonical.cache.participantsV1, saved.cache.participantsV1); result.canonicalRoster = canonical.cache.participantsV1; }
            result.stages.push(kind === 'single' ? 'single-card path: original two generation requests; no participant fields' : 'native canonical archive contains the exact saved cast');
            await page.screenshot({ path: path.join(outputDir, `${kind}-${width}-saved.png`), fullPage: true });
            await page.reload(); await openArchive(page); const reopened = await stateOf(page); checkHost(reopened, seed);
            assert.equal(await page.evaluate(() => __fixture.calls.requests.length), 0, 'fresh-page reopen does not generate');
            if (kind !== 'single') { checkCast(reopened.cache.participantsV1); await openSavedPicker(page);
                assert.deepEqual(await page.locator(selectors.name).evaluateAll(nodes => nodes.map(node => node.value)), selectedNames);
                await page.screenshot({ path: path.join(outputDir, `${kind}-${width}-reopened-picker.png`), fullPage: true });
                await page.locator(selectors.close).click(); }
            result.stages.push('fresh page reload: saved names/IDs retained; no additional generation');
            if (kind === 'multi' && process.env.PARTICIPANTS_SKIP_ROOM !== '1') {
                await verifyRoom(page, result, decisions);
                await verifyCompletedChanges(page, result);
            }
            result.finalState = await stateOf(page); result.callsAfterReload = await page.evaluate(() => __fixture.calls);
            checkHost(result.finalState, seed); assert.deepEqual(result.pageErrors, []); assert.deepEqual(decisions, []);
            result.ok = true;
        } catch (error) { result.error = { message: error.message, stack: error.stack };
            try { result.callsAtFailure = await page.evaluate(() => __fixture.calls); result.stateAtFailure = await stateOf(page); } catch {}
            try { await page.screenshot({ path: path.join(outputDir, `${kind}-${width}-failure.png`), fullPage: true }); } catch {}
        } finally { await context.close(); }
    }
    if (requestedCases.includes('database')) {
        const context = await browser.newContext(); const page = await context.newPage();
        try { await page.goto(baseUrl + '/database-contract'); report.database = await nativeDatabaseContracts(page); }
        catch (error) { report.database = { ok: false, error: { message: error.message, stack: error.stack } }; }
        finally { await context.close(); }
    }
    for (const name of artifactNames) assert.equal(sha(await readFile(path.join(repoRoot, name))), artifactHashes[name], `${name} changed during verification`);
    assert.deepEqual(routeLog.uiSourceRejected, []); assert.deepEqual(routeLog.api, []); assert.deepEqual(routeLog.external, []); assert.deepEqual(routeLog.unexpected, []);
    report.ok = report.ui.every(row => row.ok) && (!requestedCases.includes('database') || report.database?.ok === true);
    report.complete = report.ok && report.database?.complete === true && !report.notVerified.some(item => item.includes('not authorized'));
    if (!report.ok) process.exitCode = 1;
} catch (error) { report.error = { message: error.message, stack: error.stack }; process.exitCode = 1; }
finally {
    report.routes = routeLog;
    if (browser) await browser.close(); await new Promise(resolve => server.close(resolve));
    await writeFile(path.join(outputDir, 'report.json'), JSON.stringify(report, null, 2));
    console.log(JSON.stringify(report, null, 2));
}
