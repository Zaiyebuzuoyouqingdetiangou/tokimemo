import assert from 'node:assert/strict';
import http from 'node:http';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const outputDir = path.resolve(process.env.BOOTSTRAP_SCREENSHOT_DIR || path.join(repoRoot, 'artifacts', 'bootstrap-layout'));
const executablePath = process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || chromium.executablePath();
const prefix = '/scripts/extensions/third-party/hearttrace/';
const build = JSON.parse(await readFile(path.join(repoRoot, 'manifest.json'), 'utf8')).js;
const viewports = [320, 375, 390, 430, 768, 1280];
const runtimeRequests = [], hostCalls = [];
const hostPage = `<!doctype html><html><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<style>*{box-sizing:border-box}html,body{margin:0;width:100%;font-family:sans-serif;background:#eee}
#extensions_settings2,#extensionsMenu{padding:8px}.list-group-item{display:flex;gap:8px;padding:8px}
.menu_button{font:inherit}.text_pole{max-width:100%}</style></head><body>
<div id="extensions_settings2"><details id="another-extension"><summary>其他扩展</summary></details></div>
<div id="extensionsMenu"></div><script>
const listeners = new Map();
globalThis.__fixtureCalls = { generation:0, metadataSave:0, settingsSave:0 };
const forbidden = () => { __fixtureCalls.generation++; throw new Error('Generation is forbidden in UI verification'); };
const context = {extensionSettings:{},chatMetadata:{},chat:[],characterId:0,chatId:'ui-test',name1:'用户',name2:'阿遥',
characters:[{name:'阿遥',avatar:'fixture.png'}],getCurrentChatId:()=> 'ui-test',
getRequestHeaders:()=>({'Content-Type':'application/json'}),
saveMetadataDebounced:()=>{__fixtureCalls.metadataSave++},saveSettingsDebounced:()=>{__fixtureCalls.settingsSave++},
eventTypes:{},eventSource:{on:(k,fn)=>listeners.set(k,fn),off:(k)=>listeners.delete(k)},
generateRaw:forbidden,generateQuietPrompt:forbidden};
globalThis.SillyTavern={getContext:()=>context};globalThis.STBaiBaiImage={generate:forbidden};
globalThis.toastr={error:console.error,warning:console.warn,info:()=>{},success:()=>{}};
globalThis.confirm=()=>true;
</script><script type="module" src="${prefix}${build}"></script></body></html>`;

const server = http.createServer(async (request, response) => {
    const url = new URL(request.url || '/', 'http://127.0.0.1');
    if (url.pathname.startsWith('/api/')) {
        let body = ''; for await (const chunk of request) body += chunk;
        hostCalls.push({ path:url.pathname, method:request.method, body });
        response.setHeader('Content-Type', 'application/json');
        const remoteUrl = 'https://github.com/zaiyebuzuoyouqingdetiangou/tokimemo';
        const replies = {
            '/api/extensions/discover': [{name:'third-party/hearttrace',type:'local'}],
            '/api/extensions/version': {currentCommitHash:'abcdef1234567',remoteUrl},
            '/api/extensions/update': {shortCommitHash:'abcdef1',remoteUrl,isUpToDate:true},
        };
        if (!(url.pathname in replies)) response.statusCode = 404;
        response.end(JSON.stringify(replies[url.pathname] || {error:'Unexpected fixture API'})); return;
    }
    if (url.pathname.startsWith(prefix)) {
        const target = path.resolve(repoRoot, decodeURIComponent(url.pathname.slice(prefix.length)));
        if (!target.startsWith(repoRoot + path.sep)) { response.writeHead(403); response.end(); return; }
        try {
            const bytes = await readFile(target);
            if (target.endsWith('heartbeatMemories.bundle.js')) runtimeRequests.push(request.url);
            response.setHeader('Content-Type', target.endsWith('.json') ? 'application/json' : 'text/javascript; charset=utf-8');
            response.end(bytes);
        } catch { response.writeHead(404); response.end(); }
        return;
    }
    response.setHeader('Content-Type','text/html; charset=utf-8'); response.end(hostPage);
});

await mkdir(outputDir, { recursive:true });
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const baseUrl = `http://127.0.0.1:${server.address().port}`;
const browser = await chromium.launch({ headless:true,executablePath });
const results = [];
try {
    for (const width of viewports) {
        runtimeRequests.length=0; hostCalls.length=0;
        const page=await browser.newPage({viewport:{width,height:900},deviceScaleFactor:1});
        const pageErrors=[]; page.on('pageerror',error=>pageErrors.push(error.message));
        await page.route('**/*', route => new URL(route.request().url()).origin === baseUrl ? route.continue() : route.abort());
        await page.goto(baseUrl);
        await page.waitForSelector('#heartbeat_memories_menu_item');
        const inspectHost=()=>page.evaluate(()=>({
            children:[...document.querySelector('#extensions_settings2').children].map(x=>x.id),
            panelCount:document.querySelectorAll('#extensions_settings2 #heartbeat_memories_settings').length,
            documentWidth:document.documentElement.scrollWidth,
        }));
        const before=await inspectHost();
        assert.deepEqual(before.children,['another-extension']);
        assert.equal(before.panelCount,0); assert.ok(before.documentWidth<=width);
        assert.equal(runtimeRequests.length,0,'cold start stays lazy');
        await page.screenshot({path:path.join(outputDir,`bootstrap-${width}.png`),fullPage:true});
        await page.click('#heartbeat_memories_menu_item');
        await page.waitForSelector('[data-rmt-workspace-tab="settings"]');
        await page.click('[data-rmt-workspace-tab="settings"]');
        await page.waitForSelector('[data-rmt-settings-section="api"]');
        assert.equal(await page.locator('[data-rmt-self-update]').count(),1);
        await page.locator('[data-rmt-settings-section="api"]').evaluate(el=>{el.open=true});
        await page.click('[data-rmt-api-select-manual]');
        await page.locator('[data-rmt-manual-api-base]').waitFor({state:'visible'});
        assert.equal(await page.locator('[data-rmt-manual-api-save]').count(),1);
        const after=await inspectHost(); assert.deepEqual(after.children,['another-extension']);
        assert.equal(after.panelCount,0); assert.equal(runtimeRequests.length,1);
        const calls=await page.evaluate(()=>__fixtureCalls); assert.equal(calls.generation,0);
        assert.equal(calls.metadataSave,0,'opening settings must preserve original chat metadata');
        assert.deepEqual(hostCalls,[],'opening the UI must not invoke update or generation APIs');
        await page.screenshot({path:path.join(outputDir,`internal-settings-${width}.png`),fullPage:true});
        await page.click('[data-rmt-self-update]');
        await page.waitForFunction(()=>document.querySelector('[data-rmt-self-update-status]')?.textContent.includes('没有新更新'));
        assert.deepEqual(hostCalls.map(x=>x.path),['/api/extensions/discover','/api/extensions/version','/api/extensions/update']);
        for (const call of hostCalls.slice(1)) assert.deepEqual(JSON.parse(call.body),{extensionName:'hearttrace',global:false});
        await page.evaluate(async entry=>{const api=await import(entry);api.onDisable();},prefix+build);
        assert.equal(await page.locator('#heartbeat_memories_menu_item').count(),0);
        assert.equal(await page.locator('#heartbeat_memories_overlay').count(),0);
        assert.deepEqual((await inspectHost()).children,['another-extension']);
        assert.deepEqual(pageErrors,[]);
        results.push({width,before,after,runtimeLoads:runtimeRequests.length,generationCalls:calls.generation,
            updateCalls:hostCalls.slice(),pageErrors,internalApiVisible:true,cleanup:true});
        await page.close();
    }
} finally { await browser.close(); await new Promise(resolve=>server.close(resolve)); }
const report={ok:true,host:'simulated local SillyTavern context',runtime:'unaltered shipped dist bundle',viewports:results,
    notVerified:['real SillyTavern/TT/cloud host','physical mobile browser','real remote update']};
await writeFile(path.join(outputDir,'report.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify(report,null,2));
