// View a saved local image inside the existing archive dialog. No navigation,
// generation, cache writes, or listeners survive this temporary view.
import * as core_constants from '../core/constants.js';
import * as image_patch from '../core/cgImagePatch.js';
import * as core_text from '../core/text.js';

let viewer = null;

export function hasCgImageViewer() { return !!viewer?.element?.isConnected; }

export function closeCgImageViewer({ restoreFocus = true } = {}) {
    const current = viewer;
    if (!current) return false;
    viewer = null;
    current.observer?.disconnect();
    current.document.removeEventListener('keydown', current.onKeydown, true);
    current.host.removeEventListener('cancel', current.onCancel, true);
    current.element.removeEventListener('click', current.onClick);
    current.element.removeEventListener('pointerdown', current.onEarlyClose, true);
    current.element.removeEventListener('touchstart', current.onEarlyClose, true);
    current.image.removeEventListener('load', current.onLoad);
    current.image.removeEventListener('error', current.onError);
    current.element.remove();
    if (restoreFocus && current.opener?.isConnected) current.opener.focus({ preventScroll: true });
    return true;
}

export function openCgImageViewer(record, title = '原图', { opener = null, versions = [], currentUrl = '' } = {}) {
    const imageRecord = image_patch.normalizeCgImageRecord(record);
    const availableVersions = [...(Array.isArray(versions) ? versions : []), imageRecord].map(item => image_patch.normalizeCgImageRecord(item)).filter(Boolean)
        .filter((item, index, list) => list.findIndex(other => other.url === item.url) === index);
    if (!imageRecord) {
        globalThis.toastr?.warning?.('这张图片没有可查看的本地路径。', '心迹回廊');
        return false;
    }
    const doc = globalThis.document;
    const host = doc?.getElementById(core_constants.OVERLAY_ID);
    const shell = host?.querySelector('.rmt-shell');
    if (!shell || host.hidden) return false;
    const previousOpener = opener || doc.activeElement;
    closeCgImageViewer({ restoreFocus: false });
    const make = (tag, className, text) => {
        const node = doc.createElement(tag);
        node.className = className;
        if (text !== undefined) node.textContent = text;
        return node;
    };
    const element = make('section', 'rmt-cg-viewer');
    element.setAttribute('role', 'dialog');
    element.setAttribute('aria-modal', 'true');
    element.setAttribute('aria-label', '查看原图');
    const toolbar = make('div', 'rmt-cg-viewer-toolbar');
    const close = make('button', 'rmt-cg-viewer-close', '返回');
    close.type = 'button';
    close.setAttribute('aria-label', '关闭原图，返回上一层');
    const previous = make('button', 'rmt-cg-viewer-prev', '上一张');
    previous.type = 'button';
    const heading = make('b', 'rmt-cg-viewer-title', core_text.normalizeText(title, 120) || '原图');
    const count = make('span', 'rmt-cg-viewer-count');
    const next = make('button', 'rmt-cg-viewer-next', '下一张');
    next.type = 'button';
    const toggle = make('button', 'rmt-cg-viewer-toggle', '原尺寸');
    toggle.type = 'button';
    toggle.disabled = true;
    toggle.setAttribute('aria-pressed', 'false');
    toolbar.appendChild(close);
    toolbar.appendChild(heading);
    toolbar.appendChild(toggle);
    const navigation = make('nav', 'rmt-cg-viewer-toolbar rmt-cg-viewer-navigation');
    navigation.setAttribute('aria-label', '已保存图片历史');
    navigation.style.justifyContent = 'center';
    previous.setAttribute('aria-label', '上一张已保存图片');
    next.setAttribute('aria-label', '下一张已保存图片');
    navigation.appendChild(previous);
    navigation.appendChild(count);
    navigation.appendChild(next);
    const status = make('p', 'rmt-cg-viewer-status', '正在加载图片…');
    status.setAttribute('role', 'status');
    status.setAttribute('aria-live', 'polite');
    const stage = make('div', 'rmt-cg-viewer-stage');
    stage.tabIndex = 0;
    stage.setAttribute('role', 'region');
    stage.setAttribute('aria-label', '原图，原尺寸模式下可滚动查看');
    const image = make('img', 'rmt-cg-viewer-image');
    image.alt = core_text.normalizeText(title, 120) || '原图';
    image.decoding = 'async';
    image.referrerPolicy = 'no-referrer';
    stage.appendChild(image);
    element.appendChild(toolbar);
    element.appendChild(status);
    element.appendChild(stage);
    element.appendChild(navigation);
    const current = { element, host, document: doc, image, opener: previousOpener, observer: null, count, previous, next, versions: availableVersions,
        versionIndex: Math.max(0, availableVersions.findIndex(item => item.url === image_patch.normalizeCgImageUrl(currentUrl || imageRecord?.url))) };

    let lastEarlyDismissAt = 0;
    const syncVersionUi = () => {
        const multiple = current.versions.length > 1;
        navigation.hidden = !multiple;
        navigation.style.display = multiple ? 'flex' : 'none';
        const item = current.versions[current.versionIndex] || imageRecord;
        if (current.count) current.count.textContent = multiple ? `${current.versionIndex + 1} / ${current.versions.length}` : '';
        if (current.previous) current.previous.hidden = !multiple;
        if (current.next) current.next.hidden = !multiple;
        if (current.previous) current.previous.disabled = !multiple;
        if (current.next) current.next.disabled = !multiple;
        if (item && image.src !== item.url) {
            status.textContent = '正在加载图片…';
            status.setAttribute('role', 'status');
            image.hidden = false;
            toggle.disabled = true;
            image.src = item.url;
        }
    };
    const dismiss = event => {
        event.preventDefault();
        event.stopImmediatePropagation();
        closeCgImageViewer();
    };
    current.onCancel = dismiss;
    // Touch fallback for the close button: iOS/TT WebViews can swallow the click
    // after pinch or momentum-scroll gestures. Mirror overlay.js
    // bindOverlayCloseFallback: capture-phase pointerdown/touchstart runs the same
    // dismiss path, deduped with the click path within 500ms. The viewer must be
    // exitable while loading, zoomed, or after dragging, so no state is checked.
    current.onEarlyClose = event => {
        if (event.type === 'pointerdown' && (Number(event.button ?? 0) !== 0 || event.isPrimary === false)) return;
        const path = typeof event.composedPath === 'function' ? event.composedPath() : [];
        if (!path.includes(close) && event.target !== close && !close.contains(event.target)) return;
        const now = Date.now();
        if (now - lastEarlyDismissAt < 500) return;
        lastEarlyDismissAt = now;
        dismiss(event);
    };
    current.onKeydown = event => {
        if (event.key === 'Escape') { dismiss(event); return; }
        if (event.key !== 'Tab') return;
        const controls = [close, toggle, stage, previous, next].filter(control => !control.hidden && !control.disabled);
        const active = doc.activeElement;
        if (!element.contains(active) || (event.shiftKey && active === controls[0])) {
            event.preventDefault();
            (event.shiftKey ? controls[controls.length - 1] : controls[0]).focus();
        } else if (!event.shiftKey && active === controls[controls.length - 1]) {
            event.preventDefault(); close.focus();
        }
    };
    current.onClick = event => {
        event.stopPropagation();
        // Swallow the trailing synthetic click when the touch fallback just dismissed.
        if (event.target === close) {
            if (Date.now() - lastEarlyDismissAt >= 500) dismiss(event);
            return;
        }
        if (event.target === previous || event.target === next) {
            if (current.versions.length > 1) {
                const delta = event.target === previous ? -1 : 1;
                current.versionIndex = (current.versionIndex + delta + current.versions.length) % current.versions.length;
                stage.scrollTop = 0;
                stage.scrollLeft = 0;
                syncVersionUi();
            }
            return;
        }
        if (event.target !== toggle || toggle.disabled) return;
        const native = !element.classList.contains('rmt-cg-viewer-native');
        element.classList.toggle('rmt-cg-viewer-native', native);
        toggle.textContent = native ? '适屏' : '原尺寸';
        toggle.setAttribute('aria-pressed', String(native));
        stage.scrollTop = 0;
        stage.scrollLeft = 0;
    };
    current.onLoad = () => {
        if (viewer !== current) return;
        status.textContent = '';
        image.hidden = false;
        toggle.disabled = false;
    };
    current.onError = () => {
        if (viewer !== current) return;
        image.hidden = true;
        toggle.disabled = true;
        status.setAttribute('role', 'alert');
        status.textContent = '图片加载失败，请返回后重试。原图和档案没有改变。';
    };
    viewer = current;
    image.addEventListener('load', current.onLoad);
    image.addEventListener('error', current.onError);
    element.addEventListener('click', current.onClick);
    element.addEventListener('pointerdown', current.onEarlyClose, true);
    element.addEventListener('touchstart', current.onEarlyClose, { capture: true, passive: false });
    doc.addEventListener('keydown', current.onKeydown, true);
    host.addEventListener('cancel', current.onCancel, true);
    shell.appendChild(element);
    // Watch only structural replacements while the viewer is open. Ordinary
    // text/animation changes do not trigger a document-wide subtree observer.
    if (typeof globalThis.MutationObserver === 'function') {
        const body = host.querySelector('.rmt-body');
        const content = body?.firstChild;
        current.observer = new MutationObserver(() => {
            if (viewer !== current) return;
            if (!element.isConnected || !host.isConnected || body?.firstChild !== content) {
                closeCgImageViewer({ restoreFocus: false });
            }
        });
        current.observer.observe(doc.body, { childList: true });
        current.observer.observe(shell, { childList: true });
        if (body) current.observer.observe(body, { childList: true });
    }
    syncVersionUi();
    close.focus({ preventScroll: true });
    return true;
}
