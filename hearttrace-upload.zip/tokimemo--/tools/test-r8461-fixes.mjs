import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import * as patch from '../src/core/cgImagePatch.js';
import * as targets from '../src/core/cgTargets.js';
import * as constants from '../src/core/constants.js';
import * as generation from '../src/generation/imageGeneration.js';
import { expandedCgHtml } from '../src/ui/expandedCgView.js';
import { inboxPrompt, recentLetterDigest } from '../src/modes/inbox.js';
import { CONTRACT, normalizeGenerated } from '../src/core/letterIllustrationV2.js';

// r84.61 的定向回归：相簿小图切换器、大图内切换、后日谈整篇入口、邮箱话题与小画合同。

const image = (name, at = 1) => ({ url: `/user/images/${name}.png`, prompt: 'soft visual novel CG', provider: 'baibai-image', generatedAt: at });

// ── ① 相簿小图不带切换器，大图带 ─────────────────────────────────────
test('album thumbnails omit the version switcher while large views keep it', () => {
    const item = { id: 'A1', title: '纯阳真气护持', cgImage: image('b', 2), cgImageHistory: [image('a', 1)] };
    const large = generation.cgImageLayerHtml(item, { lazy: false });
    const thumb = generation.cgImageLayerHtml(item, { history: false });
    assert.match(large, /data-rmt-cg-history-controls/, '大图必须能切换');
    assert.doesNotMatch(thumb, /data-rmt-cg-history-controls/, '小图不得出现切换器');
    assert.match(thumb, /data-rmt-cg-image/, '小图仍然显示图片');
});

test('the album grid thumbnail is rendered without the switcher', async () => {
    const source = await readFile(new URL('../src/ui/albumView.js', import.meta.url), 'utf8');
    assert.match(source, /<div class="rmt-thumb">\$\{item\.unlocked \? generation_imageGeneration\.cgImageLayerHtml\(item, \{ history: false \}\)/);
});

// ── ① 大图里切换后仍停留在大图 ───────────────────────────────────────
test('switching a version inside the shared-memory view keeps the reader there', async () => {
    const source = await readFile(new URL('../src/generation/imageGeneration.js', import.meta.url), 'utf8');
    const start = source.indexOf('export async function restoreSelectedCgImageVersion(');
    const end = source.indexOf('\nexport function handleOverlayMediaError', start);
    const session = { kind: 'album', chatId: 'c', archiveRevision: 'r', sharedMemory: true, dialogueIndex: 3, selectedId: 'A1',
        entries: [{ id: 'A1', title: 't', cgImage: image('current', 2), cgImageHistory: [image('older')] }] };
    const target = { mode: 'album', session, itemId: 'A1', origin: {}, signature: patch.cgItemSignature(session.entries[0]) };
    let renders = 0;
    const deps = {
        archive_library: { requireWritableArchiveAction: () => true }, cgItemInSession: patch.cgItemInSession, isCgImageDrawing: () => false,
        image_patch: patch, cgItemSignature: patch.cgItemSignature, assertCgImageTargetCurrent: () => {},
        core_context: { currentCharacterGuard: () => ({}), getChatId: () => 'c', isCurrentTaskOrigin: () => true },
        runtimeState: { activeSession: session }, renderCurrentCgMode: () => { renders += 1; },
        core_cache: { commitSessionMutation: async (m, c, o, mutate) => {
            // 存档里是更早保存的界面状态：不在大图、对白从头开始。
            const latest = structuredClone(session);
            latest.sharedMemory = false; latest.dialogueIndex = 0; latest.selectedId = '';
            return mutate(latest);
        } },
    };
    const restore = new Function(...Object.keys(deps), `${source.slice(start, end).replace(/^export /, '')};return restoreSelectedCgImageVersion;`)(...Object.values(deps));
    assert.equal(await restore(image('older').url, target, { confirm: false }), true);
    assert.equal(session.entries[0].cgImage.url, image('older').url, '图片必须切换成功');
    assert.equal(session.sharedMemory, true, '切换后必须仍停留在共同回忆大图');
    assert.equal(session.dialogueIndex, 3, '对白进度不得被重置');
    assert.equal(session.selectedId, 'A1');
    assert.equal(renders, 1);
});

// ── ② 后日谈整篇入口不再单独出现，已存的整篇图仍保留 ─────────────────
function endingSession() {
    return { kind: constants.MODE.ENDING, endings: [{ id: 'END_1', type: 'soft', title: '归处', subtitle: '终章', endingScene: '他们在傍晚回到熟悉的房间。', creditsLine: '未完待续。',
        epilogue: { timeSkip: '三年后', scenes: [{ title: '街市', text: '两人去街市上走走。' }], finalLine: '以后也一起。' } }] };
}

test('the whole-epilogue entry is hidden when nothing was drawn for it', () => {
    const html = expandedCgHtml(endingSession(), { kind: 'ending-epilogue', containerId: 'END_1' }, false, { savedOnly: true });
    assert.equal(html, '', '未生成过整篇图时不显示入口');
});

test('a previously drawn whole-epilogue image is still shown', () => {
    let session = endingSession();
    const slot = targets.describeExpandedCgTarget(session, { kind: 'ending-epilogue', containerId: 'END_1' });
    const item = targets.expandedCgItem(session, slot).item;
    session = patch.applyCgImagePatch(session, { version: 1, mode: constants.MODE.ENDING, itemId: item.id, expectedSignature: patch.cgItemSignature(item), image: image('epilogue') }).session;
    const html = expandedCgHtml(session, { kind: 'ending-epilogue', containerId: 'END_1' }, false, { savedOnly: true });
    assert.match(html, /epilogue\.png/, '已有的整篇图不得凭空消失');
});

test('the ending view requests the whole-epilogue slot as saved-only', async () => {
    const source = await readFile(new URL('../src/ui/endingView.js', import.meta.url), 'utf8');
    assert.match(source, /\{kind:'ending-epilogue',containerId:selected\.id\}, !!runtimeState\.activeArchiveSnapshot, \{ savedOnly: true \}\)/);
});

test('per-scene epilogue drawing is unchanged', () => {
    const html = expandedCgHtml(endingSession(), { kind: 'ending-epilogue-scene', containerId: 'END_1', slot: 'scene:0' }, false);
    assert.notEqual(html, '', '每个场景的生图入口保持不变');
});

// ── ④ 邮箱：告诉模型最近寄过的信 ─────────────────────────────────────
const bank = { characterName: '方祁洛', userName: '纪时卿', memories: [], chatId: 'c', archiveRevision: 'r' };

test('the inbox prompt lists recent letters so the next one changes topic', () => {
    const previous = { letters: Array.from({ length: 9 }, (unused, i) => ({ title: `第${i}封·桂花糖糕`, body: `我方才轻手轻脚下楼，第${i}次给你买糕点。` })) };
    const prompt = inboxPrompt(bank, [], previous);
    assert.match(prompt, /RECENT_LETTERS:/);
    assert.match(prompt, /不同的话题/);
    assert.match(prompt, /第8封·桂花糖糕/, '最近一封必须在列表里');
    assert.doesNotMatch(prompt, /第2封·桂花糖糕/, '只附最近 6 封，控制长度');
    assert.equal(recentLetterDigest(previous).length, 6);
});

test('the inbox prompt is unchanged when there are no previous letters', () => {
    assert.equal(inboxPrompt(bank, [], null), inboxPrompt(bank, []));
    assert.doesNotMatch(inboxPrompt(bank, [], { letters: [] }), /RECENT_LETTERS/);
});

test('recent letter excerpts are length-bounded', () => {
    const [row] = recentLetterDigest({ letters: [{ title: '题'.repeat(200), body: '字'.repeat(500) }] });
    assert.ok(row.title.length <= 40 && row.opening.length <= 60);
});

// ── ③ 小画合同告诉模型关键词，校验本身不变 ───────────────────────────
test('the illustration contract now names the required scene keywords', () => {
    assert.match(CONTRACT, /只能使用 v2/);
    assert.match(CONTRACT, /walk=散步\/走走\/漫步/);
    assert.match(CONTRACT, /tea=茶\/咖啡/);
    assert.match(CONTRACT, /长发/);
    assert.match(inboxPrompt(bank, []), /"letterIllustration":"可选的受控小画结构"/);
});

test('illustration validation is not loosened', () => {
    const art = { version: 2, characterName: '方祁洛', focus: 'person',
        visualFacts: [{ kind: 'hairLength', value: 'long', evidence: '他留着长发' }], scene: { kind: 'walk', evidence: '去街市上走走' } };
    const ok = { characterEvidence: '方祁洛，他留着长发。', letterText: '明天我们去街市上走走吧。', characterNames: ['方祁洛'] };
    assert.ok(normalizeGenerated(art, ok), '合规的小画仍然通过');
    assert.equal(normalizeGenerated({ ...art, scene: { kind: 'walk', evidence: '去街市上' } }, { ...ok, letterText: '明天我们去街市上吧。' }), null, '场景引文缺关键词仍被拒绝');
    assert.equal(normalizeGenerated(art, { ...ok, characterEvidence: '方祁洛。' }), null, '外观缺原文依据仍被拒绝');
});
