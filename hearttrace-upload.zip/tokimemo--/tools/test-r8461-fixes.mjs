import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import * as patch from '../src/core/cgImagePatch.js';
import * as targets from '../src/core/cgTargets.js';
import * as constants from '../src/core/constants.js';
import * as generation from '../src/generation/imageGeneration.js';
import { expandedCgHtml } from '../src/ui/expandedCgView.js';
import { inboxPrompt, recentLetterDigest } from '../src/modes/inbox.js';
import { CONTRACT, normalizeGenerated } from '../src/core/letterIllustrationV2.js';

// r84.61 的定向回归：相簿小图切换器、大图内切换、后日谈整篇入口、邮箱话题与小画合同。

const image = (name, at = 1) => ({ url: `/user/images/${name}.png`, prompt: 'soft visual novel CG', provider: 'baibai-image', generatedAt: at });

// ── ① 相簿小图不带切换器，大图带 ─────────────────────────────────────
test('album thumbnails omit the version switcher while large views keep it', () => {
    const item = { id: 'A1', title: '纯阳真气护持', cgImage: image('b', 2), cgImageHistory: [image('a', 1)] };
    const large = generation.cgImageLayerHtml(item, { lazy: false });
    const thumb = generation.cgImageLayerHtml(item, { history: false });
    assert.match(large, /data-rmt-cg-history-controls/, '大图必须能切换');
    assert.doesNotMatch(thumb, /data-rmt-cg-history-controls/, '小图不得出现切换器');
    assert.match(thumb, /data-rmt-cg-image/, '小图仍然显示图片');
});

test('the album grid thumbnail is rendered without the switcher', async () => {
    const source = await readFile(new URL('../src/ui/albumView.js', import.meta.url), 'utf8');
    assert.match(source, /<div class="rmt-thumb">\$\{item\.unlocked \? generation_imageGeneration\.cgImageLayerHtml\(item, \{ history: false \}\)/);
});

// ── ① 大图里切换后仍停留在大图 ───────────────────────────────────────
test('switching a version inside the shared-memory view keeps the reader there', async () => {
    const source = await readFile(new URL('../src/generation/imageGeneration.js', import.meta.url), 'utf8');
    const start = source.indexOf('export async function restoreSelectedCgImageVersion(');
    const end = source.indexOf('\nexport function handleOverlayMediaError', start);
    const session = { kind: 'album', chatId: 'c', archiveRevision: 'r', sharedMemory: true, dialogueIndex: 3, selectedId: 'A1',
        entries: [{ id: 'A1', title: 't', cgImage: image('current', 2), cgImageHistory: [image('older')] }] };
    const target = { mode: 'album', session, itemId: 'A1', origin: {}, signature: patch.cgItemSignature(session.entries[0]) };
    let renders = 0;
    const deps = {
        archive_library: { requireWritableArchiveAction: () => true }, cgItemInSession: patch.cgItemInSession, isCgImageDrawing: () => false,
        image_patch: patch, cgItemSignature: patch.cgItemSignature, assertCgImageTargetCurrent: () => {},
        core_context: { currentCharacterGuard: () => ({}), getChatId: () => 'c', isCurrentTaskOrigin: () => true },
        runtimeState: { activeSession: session }, renderCurrentCgMode: () => { renders += 1; },
        core_cache: { commitSessionMutation: async (m, c, o, mutate) => {
            // 存档里是更早保存的界面状态：不在大图、对白从头开始。
            const latest = structuredClone(session);
            latest.sharedMemory = false; latest.dialogueIndex = 0; latest.selectedId = '';
            return mutate(latest);
        } },
    };
    const restore = new Function(...Object.keys(deps), `${source.slice(start, end).replace(/^export /, '')};return restoreSelectedCgImageVersion;`)(...Object.values(deps));
    assert.equal(await restore(image('older').url, target, { confirm: false }), true);
    assert.equal(session.entries[0].cgImage.url, image('older').url, '图片必须切换成功');
    assert.equal(session.sharedMemory, true, '切换后必须仍停留在共同回忆大图');
    assert.equal(session.dialogueIndex, 3, '对白进度不得被重置');
    assert.equal(session.selectedId, 'A1');
    assert.equal(renders, 1);
});

// ── ② 后日谈整篇入口不再单独出现，已存的整篇图仍保留 ─────────────────
function endingSession() {
    return { kind: constants.MODE.ENDING, endings: [{ id: 'END_1', type: 'soft', title: '归处', subtitle: '终章', endingScene: '他们在傍晚回到熟悉的房间。', creditsLine: '未完待续。',
        epilogue: { timeSkip: '三年后', scenes: [{ title: '街市', text: '两人去街市上走走。' }], finalLine: '以后也一起。' } }] };
}

test('the whole-epilogue entry is hidden when nothing was drawn for it', () => {
    const html = expandedCgHtml(endingSession(), { kind: 'ending-epilogue', containerId: 'END_1' }, false, { savedOnly: true });
    assert.equal(html, '', '未生成过整篇图时不显示入口');
});

test('a previously drawn whole-epilogue image is still shown', () => {
    let session = endingSession();
    const slot = targets.describeExpandedCgTarget(session, { kind: 'ending-epilogue', containerId: 'END_1' });
    const item = targets.expandedCgItem(session, slot).item;
    session = patch.applyCgImagePatch(session, { version: 1, mode: constants.MODE.ENDING, itemId: item.id, expectedSignature: patch.cgItemSignature(item), image: image('epilogue') }).session;
    const html = expandedCgHtml(session, { kind: 'ending-epilogue', containerId: 'END_1' }, false, { savedOnly: true });
    assert.match(html, /epilogue\.png/, '已有的整篇图不得凭空消失');
});

test('the ending view requests the whole-epilogue slot as saved-only', async () => {
    const source = await readFile(new URL('../src/ui/endingView.js', import.meta.url), 'utf8');
    assert.match(source, /\{kind:'ending-epilogue',containerId:selected\.id\}, !!runtimeState\.activeArchiveSnapshot, \{ savedOnly: true \}\)/);
});

test('per-scene epilogue drawing is unchanged', () => {
    const html = expandedCgHtml(endingSession(), { kind: 'ending-epilogue-scene', containerId: 'END_1', slot: 'scene:0' }, false);
    assert.notEqual(html, '', '每个场景的生图入口保持不变');
});

// ── ④ 邮箱：告诉模型最近寄过的信 ─────────────────────────────────────
const bank = { characterName: '方祁洛', userName: '纪时卿', memories: [], chatId: 'c', archiveRevision: 'r' };

test('the inbox prompt lists recent letters so the next one changes topic', () => {
    const previous = { letters: Array.from({ length: 9 }, (unused, i) => ({ title: `第${i}封·桂花糖糕`, body: `我方才轻手轻脚下楼，第${i}次给你买糕点。` })) };
    const prompt = inboxPrompt(bank, [], previous);
    assert.match(prompt, /RECENT_LETTERS:/);
    assert.match(prompt, /不同的话题/);
    assert.match(prompt, /第8封·桂花糖糕/, '最近一封必须在列表里');
    assert.doesNotMatch(prompt, /第2封·桂花糖糕/, '只附最近 6 封，控制长度');
    assert.equal(recentLetterDigest(previous).length, 6);
});

test('the inbox prompt is unchanged when there are no previous letters', () => {
    assert.equal(inboxPrompt(bank, [], null), inboxPrompt(bank, []));
    assert.doesNotMatch(inboxPrompt(bank, [], { letters: [] }), /RECENT_LETTERS/);
});

test('recent letter excerpts are length-bounded', () => {
    const [row] = recentLetterDigest({ letters: [{ title: '题'.repeat(200), body: '字'.repeat(500) }] });
    assert.ok(row.title.length <= 40 && row.opening.length <= 60);
});

// ── ③ 小画合同告诉模型关键词，校验本身不变 ───────────────────────────
test('the illustration contract now names the required scene keywords', () => {
    assert.match(CONTRACT, /只能使用 v2/);
    assert.match(CONTRACT, /walk=散步\/走走\/漫步/);
    assert.match(CONTRACT, /tea=茶\/咖啡/);
    assert.match(CONTRACT, /长发/);
    assert.match(inboxPrompt(bank, []), /"letterIllustration":"可选的受控小画结构"/);
});

test('illustration validation is not loosened', () => {
    const art = { version: 2, characterName: '方祁洛', focus: 'person',
        visualFacts: [{ kind: 'hairLength', value: 'long', evidence: '他留着长发' }], scene: { kind: 'walk', evidence: '去街市上走走' } };
    const ok = { characterEvidence: '方祁洛，他留着长发。', letterText: '明天我们去街市上走走吧。', characterNames: ['方祁洛'] };
    assert.ok(normalizeGenerated(art, ok), '合规的小画仍然通过');
    assert.equal(normalizeGenerated({ ...art, scene: { kind: 'walk', evidence: '去街市上' } }, { ...ok, letterText: '明天我们去街市上吧。' }), null, '场景引文缺关键词仍被拒绝');
    assert.equal(normalizeGenerated(art, { ...ok, characterEvidence: '方祁洛。' }), null, '外观缺原文依据仍被拒绝');
});

// ── r84.62：古风人物的衣服按古装画 ──────────────────────────────────
test('ancient garment words now count as robe evidence', () => {
    const opts = { characterEvidence: '方祁洛，常穿一袭青色长衫，腰间束带。', letterText: '午后我沿着溪水边漫步走走。', characterNames: ['方祁洛'] };
    const art = { version: 2, characterName: '方祁洛', focus: 'person', visualFacts: [{ kind: 'outfitKind', value: 'robe', evidence: '常穿一袭青色长衫' }], scene: { kind: 'walk', evidence: '溪水边漫步走走' } };
    assert.ok(normalizeGenerated(art, opts), '长衫必须能作为 robe 的依据');
    const coat = { ...art, visualFacts: [{ kind: 'outfitKind', value: 'coat', evidence: '常穿一袭青色长衫' }] };
    assert.equal(normalizeGenerated(coat, opts), null, '长衫不能被当成现代大衣');
    assert.doesNotMatch(CONTRACT, /一律用 robe/, '不再给古风人物预设服装');
});

// ── r84.63：任务面板高度跟随窗口，手机上能滚动 ──────────────────────
test('the task panel is bounded by the window so it can scroll on phones', async () => {
    const css = await readFile(new URL('../src/ui/styles.js', import.meta.url), 'utf8');
    const base = css.match(/\.rmt-task-center\{position:absolute;[^}]*\}/)?.[0] || '';
    assert.match(base, /max-height:min\(72vh,620px,calc\(100% - 74px\)\)/, '桌面端高度不得超过窗口');
    assert.match(base, /overflow:auto/);
    assert.match(base, /-webkit-overflow-scrolling:touch/);
    assert.match(base, /overscroll-behavior:contain/);
    assert.match(css, /\.rmt-task-center\{top:54px;right:8px;left:8px;width:auto;max-height:min\(calc\(100vh - 70px\),calc\(100% - 62px\)\)\}/, '手机端高度必须同时受窗口限制');
    assert.doesNotMatch(css, /\.rmt-task-center\{[^}]*max-height:calc\(100vh - 70px\)\}/, '不得只按屏幕高度计算');
});

// ── r84.64：旧暂存记录可导出并丢弃；邮箱失败显示真实原因；小人不预设衣服 ──
import { createPendingStore } from '../src/generation/mergedGeneration.js';
import { sketchPerson } from '../src/core/letterSketch.js';
import * as inbox from '../src/modes/inbox.js';

test('discarding legacy pending rows removes only the exported unattributed ones', () => {
    const memory = new Map();
    const storage = { getItem: k => memory.get(k) ?? null, setItem: (k, v) => memory.set(k, String(v)), removeItem: k => memory.delete(k) };
    const pending = createPendingStore(storage);
    pending.write('c', [{ id: 'old1', route: 'inbox' }, { id: 'old2', route: 'room' }]);
    const before = pending.read('c').length;
    assert.equal(pending.discardUnattributed('c', ['old1']), 1, '只删除传入的那一条');
    assert.deepEqual(pending.read('c').map(row => row.id), ['old2']);
    assert.equal(pending.discardUnattributed('c', []), 0, '没有指定就不删除');
    assert.equal(pending.discardUnattributed('c', ['not-exist']), 0);
    assert.equal(before, 2);
});

test('the legacy card offers export-and-discard behind a destructive confirmation', async () => {
    const source = await readFile(new URL('../src/ui/taskCenter.js', import.meta.url), 'utf8');
    assert.match(source, /data-rmt-action="merged-discard-legacy">导出并丢弃</);
    assert.match(source, /action === 'merged-discard-legacy'\) \{ discardLegacyPending\(\)/);
    const body = source.slice(source.indexOf('function discardLegacyPending'), source.indexOf('function refreshTaskCenterView'));
    assert.match(body, /confirmExplicitAction\([^]*destructive: true/);
    const exportAt = body.indexOf('exportMergedResult(');
    const discardAt = body.indexOf('discardUnattributed(');
    assert.ok(exportAt >= 0, '丢弃前必须导出');
    assert.ok(discardAt >= 0);
    assert.ok(exportAt < discardAt, '必须先导出再删除');
});

test('inbox failures now carry a displayable reason instead of "reason not recorded"', () => {
    const bank = { characterName: '方祁洛', userName: '纪时卿', memories: [], chatId: 'c', archiveRevision: 'r' };
    let caught = null;
    try { inbox.mergeInboxLatest({ kind: 'inbox', letters: [] }, null); } catch (error) { caught = error; }
    assert.ok(caught, '结构不可读取时必须抛错');
    assert.equal(caught.safeToDisplay, true, '邮箱错误必须可安全显示');
    assert.equal(caught.message, '邮箱结构不可读取。');
    assert.match(caught.code, /^RMT_/);
});

test('inbox source no longer throws bare errors', async () => {
    const source = await readFile(new URL('../src/modes/inbox.js', import.meta.url), 'utf8');
    assert.doesNotMatch(source, /throw new Error\(/, '邮箱里的错误都必须带编号并可显示');
    const merged = await readFile(new URL('../src/generation/mergedGeneration.js', import.meta.url), 'utf8');
    assert.match(merged, /safeUserError\('邮箱今天的来信已经收过了，明天再来收新信吧。', 'RMT_LOCAL_OPERATION', \{ retryable: false \}\)/);
});

test('a figure without clothing evidence is drawn without a preset coat collar', () => {
    const base = { version: 2, characterName: '甲', focus: 'person', visualFacts: [{ kind: 'hairLength', value: 'long', evidence: '长发' }], scene: { kind: 'walk', evidence: '散步' } };
    const plain = sketchPerson(base);
    assert.doesNotMatch(plain, /m130 136 20 16 20-16/, '未写明衣服时不画 V 领门襟');
    const robe = sketchPerson({ ...base, visualFacts: [...base.visualFacts, { kind: 'outfitKind', value: 'robe', evidence: '长衫' }] });
    assert.match(robe, /m128 135 32 28 14-26/, '有依据的衣服照常画');
});

// ── r84.65：小画按人设画古风衣着与配饰 ─────────────────────────────
const CARD = '方祁洛，一身墨色劲装，玉冠束发，腰悬玉佩，背负长剑，剑眉星目，手中常持折扇，雨天披一件青色斗篷。';
const LETTER = '午后我沿着城外的溪水边漫步走走。';
const draw = facts => normalizeGenerated({ version: 2, characterName: '方祁洛', focus: 'person', visualFacts: facts, scene: { kind: 'walk', evidence: '漫步走走' } },
    { characterEvidence: CARD, letterText: LETTER, characterNames: ['方祁洛'] });

test('an ancient persona is drawn with its own outfit and accessories', () => {
    const design = draw([
        { kind: 'outfitKind', value: 'martial', evidence: '一身墨色劲装' },
        { kind: 'hairStyle', value: 'bun', evidence: '玉冠束发' },
        { kind: 'marker', value: 'crown', evidence: '玉冠束发' },
        { kind: 'marker', value: 'jade', evidence: '腰悬玉佩' },
        { kind: 'marker', value: 'sword', evidence: '背负长剑' },
        { kind: 'marker', value: 'fan', evidence: '手中常持折扇' },
        { kind: 'marker', value: 'cloak', evidence: '雨天披一件青色斗篷' },
    ]);
    assert.ok(design, '按人设原文写的古风外观必须通过');
    const svg = sketchPerson(design);
    assert.match(svg, /data-rmt-letter-outfit="martial:/);
    for (const marker of ['crown', 'jade', 'sword', 'fan', 'cloak']) {
        assert.match(svg, new RegExp(`data-rmt-letter-marker="${marker}"`), `必须画出 ${marker}`);
    }
});

test('ruqun draws a long skirt with a high sash', () => {
    const design = normalizeGenerated({ version: 2, characterName: '纪时卿', focus: 'person',
        visualFacts: [{ kind: 'outfitKind', value: 'ruqun', evidence: '一袭齐胸襦裙' }], scene: { kind: 'walk', evidence: '漫步走走' } },
        { characterEvidence: '纪时卿，一袭齐胸襦裙。', letterText: LETTER, characterNames: ['纪时卿'] });
    assert.ok(design);
    assert.match(sketchPerson(design), /data-rmt-letter-outfit="ruqun:/);
});

test('"sword brows" never produce a sword', () => {
    assert.equal(draw([{ kind: 'marker', value: 'sword', evidence: '剑眉星目' }]), null, '「剑眉」不是佩剑');
});

test('accessories still require the persona to actually say so', () => {
    assert.equal(draw([{ kind: 'marker', value: 'hairpin', evidence: '玉冠束发' }]), null, '写的是玉冠，不能画成发簪');
    assert.equal(draw([{ kind: 'outfitKind', value: 'ruqun', evidence: '一身墨色劲装' }]), null, '劲装不能画成襦裙');
});

test('the contract tells the model about the new outfits and accessories', () => {
    assert.match(CONTRACT, /outfitKind=[^；]*\|martial\|ruqun/);
    assert.match(CONTRACT, /marker=[^；]*\|crown\|hairpin\|jade\|sword\|fan\|cloak/);
    assert.match(CONTRACT, /「剑眉」不算/);
});

// 严格解析 SVG 的地方（图片预览、导出）遇到重复属性会整张判为无效。
test('rendered sketches never repeat an attribute on one element', async () => {
    const { render } = await import('../src/core/letterIllustrationV2.js');
    const outfits = ['shirt', 'hoodie', 'coat', 'robe', 'martial', 'ruqun', 'uniform', 'sweater'];
    const markers = ['glasses', 'earrings', 'crown', 'hairpin', 'jade', 'sword', 'fan', 'cloak', 'scarf', 'hat'];
    for (const scene of ['walk', 'read', 'flower', 'window']) {
        for (const outfit of outfits) {
            const svg = render({ version: 2, characterName: '甲', focus: 'person', scene: { kind: scene, evidence: 'x' },
                visualFacts: [{ kind: 'outfitKind', value: outfit, evidence: 'x' }, ...markers.map(value => ({ kind: 'marker', value, evidence: 'x' }))] });
            assert.ok(svg.length > 0, `${scene}/${outfit} 必须能渲染`);
            for (const tag of svg.match(/<[a-zA-Z][^>]*>/g) || []) {
                const names = [...tag.matchAll(/\s([a-zA-Z_:][-a-zA-Z0-9_:.]*)=/g)].map(m => m[1]);
                assert.equal(new Set(names).size, names.length, `重复属性：${tag.slice(0, 90)}`);
            }
        }
    }
});

test('a back-worn sword and cloak are drawn behind the body', () => {
    const design = draw([{ kind: 'marker', value: 'sword', evidence: '背负长剑' }, { kind: 'marker', value: 'cloak', evidence: '雨天披一件青色斗篷' }]);
    const svg = sketchPerson(design);
    const body = svg.indexOf('data-rmt-letter-outfit=');
    assert.ok(svg.indexOf('data-rmt-letter-marker="sword"') < body, '剑在身后');
    assert.ok(svg.indexOf('data-rmt-letter-marker="cloak"') < body, '斗篷在身后');
});

test('one unsupported detail no longer throws away the whole drawing', () => {
    const design = draw([{ kind: 'outfitKind', value: 'martial', evidence: '一身墨色劲装' }, { kind: 'marker', value: 'sword', evidence: '剑眉星目' }]);
    assert.ok(design, '有依据的劲装照画');
    assert.deepEqual(design.visualFacts.map(fact => fact.value), ['martial'], '没有依据的「剑」被单独丢掉');
});

test('classical colour words are understood', () => {
    const design = draw([{ kind: 'outfitColor', value: 'black', evidence: '一身墨色劲装' }]);
    assert.ok(design, '墨色劲装应识别为黑色衣服');
});

// ── r84.66：邮箱失败原因细分到卡片与重试提示；最近来信不许被当作往事引用 ──
import { generationRetryFeedbackText } from '../src/generation/recovery.js';
import { safeUserError } from '../src/core/text.js';

test('each inbox validation failure gets its own retry instruction', () => {
    const cases = [
        ['来信未完整返回，请只补齐计划中的信件。', /封数/],
        ['来信类型重复或缺失。', /slot 重复或缺失/],
        ['来信正文还未写完。', /标题或正文是空的/],
        ['称呼超出了两人当前关系，请按真实关系写来信。', /真实关系/],
        ['来信把未有依据的共同往事写成了事实；请写当下心情或未来邀请。', /不要写「上次」「那天」/],
    ];
    for (const [message, expected] of cases) {
        const text = generationRetryFeedbackText('RMT_SEGMENT_VALIDATION', safeUserError(message, 'RMT_SEGMENT_VALIDATION'));
        assert.match(text, expected, `「${message}」必须得到针对性的重试要求`);
    }
});

test('other structure failures keep the general instruction', () => {
    const text = generationRetryFeedbackText('RMT_SEGMENT_VALIDATION', safeUserError('房间结构不完整。', 'RMT_SEGMENT_VALIDATION'));
    assert.match(text, /结构或完整度未通过/);
});

test('provider text can never pick a mail category', () => {
    const forged = new Error('称呼超出了两人当前关系');
    forged.code = 'RMT_SEGMENT_VALIDATION';
    assert.match(generationRetryFeedbackText('RMT_SEGMENT_VALIDATION', forged), /结构或完整度未通过/, '只认插件自己写的提示');
});

// r84.67：来信是衍生作品，不进入记忆证据；回忆往事不再校验出处。
test('a daily letter may freely recall the past', () => {
    const memory = { characterName: '方祁洛', userName: '遂鋆', memories: [], chatId: 'c', archiveRevision: 'r' };
    const plan = [{ slot: 'daily', eventKey: 'daily:2026-09-25', sourceMemoryIds: [], sourceMemoryAnchor: '' }];
    const result = inbox.normalizeInboxLetters({ letters: [{ slot: 'daily', title: '想你', greeting: '遂鋆：',
        body: '还记得那天我们一起在溪边看月亮吗？上次信里说的包子，我又买了一笼。', closing: '方祁洛' }] }, memory, plan);
    const letters = Array.isArray(result) ? result : result.letters;
    assert.equal(letters.length, 1, '回忆往事的日常信必须能收下');
    assert.match(letters[0].body, /还记得那天/);
});

test('the prompt neither forces nor forbids recalling the past', () => {
    const prompt = inbox.inboxPrompt({ characterName: '方祁洛', userName: '遂鋆', memories: [], chatId: 'c', archiveRevision: 'r' }, [],
        { letters: [{ title: '醒了就乖乖在榻上等我', body: '你昨天非说剑灵不畏寒。' }] });
    assert.doesNotMatch(prompt, /不要提起这些信里写过的事/, '不再禁止提旧信');
    assert.doesNotMatch(prompt, /只能直接引用真实记忆原句/, '不再要求逐字引用往事');
    assert.doesNotMatch(prompt, /不要回放过去情节/);
    assert.doesNotMatch(prompt, /不要将后者冒充事实/);
    assert.match(prompt, /没有过去记录时照样能写信/, '仍然不强迫信里提往事');
    assert.match(prompt, /不同的话题/, '避免话题重复的要求保留');
});

test('new failure categories are registered for the task card and saved journals', async () => {
    const source = await readFile(new URL('../src/generation/recovery.js', import.meta.url), 'utf8');
    for (const key of ['mailCount', 'mailSlot', 'mailEmpty', 'mailAddress', 'mailHistory']) {
        const retry = source.slice(source.indexOf('const RETRY_FEEDBACK'), source.indexOf('const FAILURE_DETAIL'));
        const detail = source.slice(source.indexOf('const FAILURE_DETAIL'), source.indexOf('const MAIL_FAILURE'));
        assert.match(retry, new RegExp(`\\n    ${key}: '`), `${key} 必须能通过恢复日志的类别校验`);
        assert.match(detail, new RegExp(`\\n    ${key}: '`), `${key} 必须有卡片文案`);
    }
});
