// Heartbeat Memories r35 modular runtime.
// Extracted from r34 without changing archive/cache storage contracts.
import * as core_digest from './digest.js';
// C-3c（r84.100）：别名沿用 archive_groups，函数体一字不改；characterDescriptor 已挪到 core 层，不再 import archive 层。
import * as archive_groups from './characterDescriptor.js';
import * as core_constants from './constants.js';
import * as core_evidence from './evidence.js';
import { state as runtimeState } from './state.js';
import * as core_text from './text.js';
import * as core_contextTags from './contextTags.js';
import * as chat_read_range from './chatReadRange.js';
import * as host_compatibility from './hostCompatibility.js';

const adaptHostContext = host_compatibility.createHostContextAdapter({ getEpoch: () => runtimeState.runtimeLifecycleEpoch });

export function getContext() {
    const context = globalThis.SillyTavern?.getContext?.();
    if (!context) throw new Error('未检测到 SillyTavern 扩展上下文。');
    return adaptHostContext(context);
}

export function currentCharacterGuard() {
    const context = getContext();
    if (context.groupId) {
        throw new Error('“心迹回廊”当前只支持单角色聊天，请打开一个角色对话后再使用。');
    }
    if (context.characterId === undefined || context.characterId === null) {
        throw new Error('请先打开一个角色聊天。');
    }
    return context;
}

export function getChatId(context = getContext()) {
    try {
        const id = context.getCurrentChatId?.() ?? context.chatId;
        return core_text.normalizeText(id, 240);
    } catch {
        return core_text.normalizeText(context.chatId, 240);
    }
}

export function yieldToUi() {
    return new Promise(resolve => setTimeout(resolve, 0));
}

export function runtimeLifecycleStillCurrent(lifecycleEpoch) {
    return Number(lifecycleEpoch) === runtimeState.runtimeLifecycleEpoch;
}

export function assertRuntimeLifecycleCurrent(lifecycleEpoch) {
    if (!runtimeLifecycleStillCurrent(lifecycleEpoch)) {
        throw new DOMException('Runtime destroyed', 'AbortError');
    }
    return true;
}

// ST/TT hide normal dialogue by toggling is_system, not by removing a floor.
// Recover only explicitly attributed dialogue, never system/tool messages or guessed names.
export function isArchiveDialogueMessage(message, context) {
    if (!message?.is_system) return true;
    if (typeof message.is_user !== 'boolean' || ['system', 'tool', 'developer'].includes(message.role)
        || message.extra?.type || message.extra?.uses_system_ui || message.extra?.tool_invocations) return false;
    const name = core_text.normalizeText(message.name, 120);
    const expected = core_text.normalizeText(message.is_user ? context?.name1 : context?.name2, 120);
    return !!name && !!expected && name === expected;
}

export async function buildChatSnapshot(context = currentCharacterGuard(), options = {}) {
    const rawChat = Array.isArray(context.chat) ? context.chat : [];
    const tagPolicy = core_contextTags.tagPolicyForContext(context);
    const usable = [];
    const fullSignatures = [];
    const prefixCount = Math.max(0, Math.floor(Number(options.prefixCount) || 0));
    let fingerprint = 2166136261;
    let prefixFingerprint = 2166136261;
    const mix = (state, value) => {
        let next = state >>> 0;
        for (const ch of String(value ?? '')) {
            next ^= ch.codePointAt(0);
            next = Math.imul(next, 16777619);
        }
        return next >>> 0;
    };
    const chatId = comparableChatId(options.expectedChatId) || comparableChatId(getChatId(context));
    const assertStillCurrent = () => {
        if (typeof options.stillCurrent === 'function' && options.stillCurrent() === false) {
            throw new DOMException('Chat changed', 'AbortError');
        }
    };
    assertStillCurrent();
    fingerprint = mix(fingerprint, chatId);
    prefixFingerprint = mix(prefixFingerprint, chatId);
    for (let index = 0; index < rawChat.length; index += 1) {
        const message = rawChat[index];
        const text = core_text.normalizeText(message?.mes, 8000);
        // hiddenMode 只用于核对旧档案基线：exclude = 旧版不收隐藏楼层；include = 隐藏楼层一律按对话算。
        const dialogue = options.hiddenMode === 'exclude' ? !message?.is_system
            : options.hiddenMode === 'include' ? (!message?.is_system || (typeof message?.is_user === 'boolean' && !['system', 'tool', 'developer'].includes(message?.role) && !message?.extra?.type && !message?.extra?.uses_system_ui))
            : isArchiveDialogueMessage(message, context);
        if (text && dialogue) {
            const isUser = message?.is_user === true;
            const item = {
                index: index + 1,
                role: isUser ? 'user' : 'char',
                name: core_text.normalizeText(message?.name || (isUser ? context.name1 : context.name2), 120),
                date: core_text.normalizeText(message?.send_date || message?.date || '', 80),
                text: options.completeSource === true ? core_text.normalizeText(message?.mes, Number.MAX_SAFE_INTEGER) : text,
            };
            usable.push(item);
            const signature = `${item.index}|${item.role}|${item.date}|${text}`;
            if (options.completeSource === true) fullSignatures.push(`${item.index}|${item.role}|${item.date}|${item.text}`);
            fingerprint = mix(fingerprint, signature);
            if (usable.length <= prefixCount) prefixFingerprint = mix(prefixFingerprint, signature);
        }
        if (index && index % 60 === 0) {
            await yieldToUi();
            assertStillCurrent();
        }
    }
    const totalMessages = usable.length;
    fingerprint = mix(fingerprint, String(totalMessages));
    if (prefixCount > 0) prefixFingerprint = mix(prefixFingerprint, String(Math.min(prefixCount, totalMessages)));

    const capMessages = source => {
        if (options.completeSource === true) return { selected: source,
            selectedChars: source.reduce((sum, item) => sum + item.text.length + item.name.length + item.date.length + 32, 0), truncated: false };
        const cappedByCount = source.length > core_constants.MAX_IMPORT_MESSAGES ? core_evidence.evenlySample(source, core_constants.MAX_IMPORT_MESSAGES) : source;
        let selected = cappedByCount;
        let selectedChars = selected.reduce((sum, item) => sum + item.text.length + item.name.length + item.date.length + 32, 0);
        if (selectedChars > core_constants.MAX_IMPORT_TOTAL_CHARS) {
            const ratio = core_constants.MAX_IMPORT_TOTAL_CHARS / Math.max(1, selectedChars);
            const limit = Math.max(64, Math.floor(selected.length * ratio));
            selected = core_evidence.evenlySample(selected, limit);
            selectedChars = selected.reduce((sum, item) => sum + item.text.length + item.name.length + item.date.length + 32, 0);
        }
        return { selected, selectedChars, truncated: source.length > selected.length };
    };

    // Selection controls model input only: keep the full canonical history and prefix
    // fingerprints above intact for stale-write protection and existing archive baselines.
    const selectedFloors = options.readRange ? new Set(chat_read_range.selectChatReadRange(context, options.readRange).map(row => row.index)) : null;
    const selectedUsable = selectedFloors ? usable.filter(item => selectedFloors.has(item.index)) : usable;
    const full = capMessages(selectedUsable);
    const incrementalRaw = prefixCount > 0 && totalMessages >= prefixCount ? usable.slice(prefixCount) : usable;
    const incremental = capMessages(selectedFloors ? incrementalRaw.filter(item => selectedFloors.has(item.index)) : incrementalRaw);
    assertStillCurrent();
    return {
        chatId,
        ...(options.completeSource === true ? {
            fullFingerprint: core_digest.sha256Bytes(new TextEncoder().encode(JSON.stringify([chatId, fullSignatures]))),
            fullPrefixFingerprint: core_digest.sha256Bytes(new TextEncoder().encode(JSON.stringify([chatId, fullSignatures.slice(0, prefixCount)]))),
        } : {}),
        totalMessages,
        usedMessages: full.selected.length,
        usedChars: full.selectedChars,
        truncated: full.truncated,
        coverageMode: options.readRange ? 'selected-floors' : full.truncated ? 'evenly-sampled-full-window' : 'full-window',
        readRange: options.readRange ? chat_read_range.normalizeChatReadRange(options.readRange) : null,
        messages: full.selected.map(item => ({ ...item, text: core_contextTags.filterContextTags(item.text, tagPolicy) })),
        fingerprint: String(fingerprint >>> 0),
        prefixCount,
        prefixFingerprint: prefixCount > 0 && totalMessages >= prefixCount ? String(prefixFingerprint >>> 0) : '',
        incrementalMessages: incremental.selected.map(item => ({ ...item, text: core_contextTags.filterContextTags(item.text, tagPolicy) })),
        incrementalUsedMessages: incremental.selected.length,
        incrementalUsedChars: incremental.selectedChars,
        incrementalTruncated: incremental.truncated,
    };
}

// Used only while a batch is explicitly committing (including its deferred save),
// never by ordinary startup or message listeners. Mirrors the full snapshot identity.
export function completeArchiveChatFingerprint(context = currentCharacterGuard()) {
    const signatures = [];
    const chat = Array.isArray(context.chat) ? context.chat : [];
    for (let index = 0; index < chat.length; index++) {
        const message = chat[index];
        const value = core_text.normalizeText(message?.mes, Number.MAX_SAFE_INTEGER);
        if (value && isArchiveDialogueMessage(message, context)) {
            const role = message?.is_user === true ? 'user' : 'char';
            const date = core_text.normalizeText(message?.send_date || message?.date || '', 80);
            signatures.push(`${index + 1}|${role}|${date}|${value}`);
        }
    }
    return core_digest.sha256Bytes(new TextEncoder().encode(JSON.stringify([comparableChatId(getChatId(context)), signatures])));
}

export function comparableChatId(value) {
    return core_text.normalizeText(value, 260).replace(/\.jsonl$/i, '').trim();
}

export function contextCharacterAvatar(context = getContext(), preferredName = '') {
    const characters = Array.isArray(context?.characters) ? context.characters : [];
    const id = context?.characterId;
    const requestedName = core_text.normalizeText(preferredName, 120);
    const currentName = core_text.normalizeText(context?.name2, 120);
    const preferred = requestedName || currentName;
    const direct = id !== undefined && id !== null ? characters[id] : null;
    const candidates = [];
    if (requestedName) {
        const byName = characters.find(item => core_text.normalizeText(item?.name || item?.data?.name, 120) === requestedName);
        if (byName) candidates.push(byName);
        const directName = core_text.normalizeText(direct?.name || direct?.data?.name, 120);
        if (direct && directName === requestedName && direct !== byName) candidates.push(direct);
    } else {
        if (direct) candidates.push(direct);
        if (preferred) {
            const byName = characters.find(item => core_text.normalizeText(item?.name || item?.data?.name, 120) === preferred);
            if (byName && byName !== direct) candidates.push(byName);
        }
    }
    for (const item of candidates) {
        const avatar = core_text.normalizeText(item?.avatar || item?.data?.avatar, 300);
        if (avatar) return avatar;
    }
    return '';
}

export function archiveEntryAvatarName(entry, context = getContext()) {
    const stored = core_text.normalizeText(entry?.avatar, 300);
    if (stored) return stored;
    const key = core_text.normalizeText(entry?.characterKey, 300);
    if (key && !key.startsWith('character:')) return key;
    return contextCharacterAvatar(context, core_text.normalizeText(entry?.characterName, 120));
}

export function archiveCanonicalCharacterKey(entry, context = getContext()) {
    return archiveEntryAvatarName(entry, context) || core_text.normalizeText(entry?.characterKey, 300);
}

export function stableArchiveHash(value) {
    const text = String(value ?? '');
    let hash = 2166136261;
    for (let i = 0; i < text.length; i += 1) {
        hash ^= text.charCodeAt(i);
        hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(36);
}

export function archiveStoredAvatar(entry) {
    const avatar = core_text.normalizeText(entry?.avatar, 300);
    if (avatar) return avatar;
    const key = core_text.normalizeText(entry?.characterKey, 300);
    return key && !key.startsWith('character:') ? key : '';
}

export function archiveSourceIdentityKey(entry) {
    const fingerprint = core_text.normalizeText(entry?.characterFingerprint, 160);
    const characterIndexHint = Number.isInteger(Number(entry?.characterIndexHint)) ? Number(entry.characterIndexHint) : -1;
    if (fingerprint) return `fingerprint:${fingerprint}${characterIndexHint >= 0 ? `\u001fcharacter:${characterIndexHint}` : ''}`;
    const avatar = archiveStoredAvatar(entry);
    const name = core_text.normalizeText(entry?.characterName, 120).toLocaleLowerCase();
    const fallback = core_text.normalizeText(entry?.characterKey, 300);
    return `${avatar || fallback}\u001f${name}`;
}

export function archiveAutoGroupId(entry) {
    return `auto:${stableArchiveHash(archiveSourceIdentityKey(entry))}`;
}

export function archiveLegacyScanKey(entry) {
    const avatar = archiveStoredAvatar(entry) || core_text.normalizeText(entry?.characterKey, 300);
    const name = core_text.normalizeText(entry?.characterName, 120).toLocaleLowerCase();
    return `${avatar}\u001f${name}\u001f${comparableChatId(entry?.chatId)}`;
}

export function archiveIndexEntryId(entry) {
    const existing = core_text.normalizeText(entry?.entryId, 120);
    if (existing) return existing;
    return `AE:${stableArchiveHash(`${archiveSourceIdentityKey(entry)}\u001f${comparableChatId(entry?.chatId)}`)}`;
}

export function archiveEntryMatchesContextCharacter(entry, context = getContext()) {
    if (!entry || !context) return false;
    const entryName = core_text.normalizeText(entry?.characterName, 120);
    const descriptor = archive_groups.characterDescriptor(context, Number(context?.characterId));
    const currentName = core_text.normalizeText(context?.name2 || descriptor?.name, 120);
    const entryAvatar = archiveStoredAvatar(entry);
    const currentAvatar = core_text.normalizeText(context?.characters?.[context?.characterId]?.avatar || context?.characters?.[context?.characterId]?.data?.avatar, 300);
    if (entryAvatar && currentAvatar && entryAvatar !== currentAvatar) return false;
    const entryHint = Number.isInteger(Number(entry?.characterIndexHint)) ? Number(entry.characterIndexHint) : -1;
    const currentHint = Number.isInteger(Number(context?.characterId)) ? Number(context.characterId) : -1;
    // A character slot is only a locator, never a complete identity proof. SillyTavern can
    // reuse the same slot (and even the same avatar/chat filename) for a different card.
    if (entryHint >= 0 && currentHint >= 0 && entryHint !== currentHint) return false;
    if (entryName && entryName !== '未命名角色' && currentName && entryName !== currentName) return false;
    const entryFingerprint = core_text.normalizeText(entry?.characterFingerprint, 160);
    const currentFingerprint = core_text.normalizeText(descriptor?.fingerprint, 160);
    if (entryFingerprint && currentFingerprint) {
        if (entryFingerprint !== currentFingerprint) return false;
        const sameFingerprint = (Array.isArray(context?.characters) ? context.characters : [])
            .map((_, index) => archive_groups.characterDescriptor(context, index))
            .filter(item => item?.fingerprint === entryFingerprint);
        if (sameFingerprint.length !== 1) return false;
    }
    if (entryName || entryAvatar || entryHint >= 0) return true;
    return core_text.normalizeText(entry?.characterKey, 300) === `character:${String(context?.characterId ?? '')}`;
}

export function currentCharacterKey(context = currentCharacterGuard()) {
    const avatar = core_text.normalizeText(context.characters?.[context.characterId]?.avatar || context.characters?.[context.characterId]?.data?.avatar, 300);
    return avatar || `character:${String(context.characterId ?? '')}`;
}

export function currentCharacterAvatar(context = currentCharacterGuard()) {
    return core_text.normalizeText(context.characters?.[context.characterId]?.avatar || context.characters?.[context.characterId]?.data?.avatar, 300);
}

export function currentCharacterRuntimeKey(context = currentCharacterGuard()) {
    const descriptor = archive_groups.characterDescriptor(context, Number(context.characterId));
    const identity = descriptor?.fingerprint || `${currentCharacterKey(context)}\u001f${core_text.normalizeText(context.name2, 120)}`;
    return `${identity}\u001fcharacter:${String(context.characterId ?? '')}`;
}

export function chatScopeKey(context = currentCharacterGuard(), chatId = getChatId(context)) {
    return `${currentCharacterRuntimeKey(context)}|${comparableChatId(chatId)}`;
}

export function captureTaskOrigin(context = currentCharacterGuard(), archiveRevision = '') {
    const rawCache = context?.__rmtArchiveTargetEntryId
        ? context?.chatMetadata?.[core_constants.CACHE_KEY]
        : runtimeState.runtimeSessionCache.get(chatScopeKey(context)) || context?.chatMetadata?.[core_constants.CACHE_KEY];
    const rawFences = rawCache && typeof rawCache === 'object' && rawCache[core_constants.MODE_WRITE_FENCES_CACHE_KEY]
        && typeof rawCache[core_constants.MODE_WRITE_FENCES_CACHE_KEY] === 'object'
        ? rawCache[core_constants.MODE_WRITE_FENCES_CACHE_KEY]
        : {};
    const modeWriteFences = Object.create(null);
    for (const mode of Object.values(core_constants.MODE)) {
        const fence = rawFences[mode];
        const generation = Math.max(0, Math.floor(Number(fence?.generation) || 0));
        const token = core_text.normalizeText(fence?.token, 160);
        if (generation > 0 && token) modeWriteFences[mode] = { generation, token };
    }
    return {
        startedAt: Date.now(),
        lifecycleEpoch: runtimeState.runtimeLifecycleEpoch,
        characterKey: currentCharacterRuntimeKey(context),
        characterAvatar: currentCharacterAvatar(context),
        characterId: String(context.characterId ?? ''),
        characterName: core_text.normalizeText(context.name2, 120),
        chatId: comparableChatId(getChatId(context)),
        archiveRevision: core_text.normalizeText(archiveRevision, 240),
        archivePresent: !!core_text.normalizeText(archiveRevision, 240),
        modeWriteFences,
    };
}

export function deferredCommitOriginMatchesContext(origin, context = getContext()) {
    try {
        if (!origin || comparableChatId(getChatId(context)) !== comparableChatId(origin.chatId)) return false;
        const originCharacterId = core_text.normalizeText(origin.characterId, 40);
        if (originCharacterId && originCharacterId !== String(context?.characterId ?? '')) return false;
        if (currentCharacterRuntimeKey(context) === origin.characterKey) return true;
        const originAvatar = core_text.normalizeText(origin.characterAvatar, 300);
        const currentAvatar = currentCharacterAvatar(context);
        if (!originAvatar || originAvatar !== currentAvatar) return false;
        // Modern deferred rows capture the live SillyTavern card slot. Once that exact
        // slot and its avatar still agree, ordinary edits/renames are safe even when a
        // second card intentionally uses the same avatar. A different slot already
        // failed above, so cloned cards can never inherit each other's completed work.
        if (originCharacterId) {
            const expectedRevision = core_text.normalizeText(origin.archiveRevision, 240);
            const liveMemory = context?.chatMetadata?.[core_constants.MEMORY_KEY];
            const liveCache = runtimeState.runtimeSessionCache.get(chatScopeKey(context))
                || context?.chatMetadata?.[core_constants.CACHE_KEY];
            const liveRevision = core_text.normalizeText(liveMemory?.archiveRevision || liveCache?.archiveRevision, 240);
            return !!expectedRevision
                && liveRevision === expectedRevision
                && comparableChatId(liveMemory?.chatId || liveCache?.chatId) === comparableChatId(origin.chatId);
        }
        const matches = (Array.isArray(context.characters) ? context.characters : []).filter((character, index) => {
            const avatar = core_text.normalizeText(character?.avatar || character?.data?.avatar, 300);
            return avatar === originAvatar && characterDescriptorExists(context, index);
        });
        return matches.length === 1;
    } catch {
        return false;
    }
}

function characterDescriptorExists(context, index) {
    return !!archive_groups.characterDescriptor(context, Number(index));
}

// Same-person check for task gates. The runtime key embeds a card-content
// fingerprint, so any ordinary card edit (or host-side normalization on save)
// drifts it even though the person, the slot, and the chat are unchanged —
// the archive grouping layer and the deferred-commit lane already treat such
// edits as the same person. Once the exact card slot and a non-empty avatar
// still agree, fingerprint drift alone does not abort or block a task. A real
// character switch changes the slot (or the avatar) and still hard-fails.
export function taskOriginCharacterMatches(origin, context = getContext()) {
    try {
        if (!origin) return false;
        if (currentCharacterRuntimeKey(context) === origin.characterKey) return true;
        const originCharacterId = core_text.normalizeText(origin.characterId, 40);
        if (!originCharacterId || originCharacterId !== String(context?.characterId ?? '')) return false;
        const originAvatar = core_text.normalizeText(origin.characterAvatar, 300);
        return !!originAvatar && originAvatar === currentCharacterAvatar(context);
    } catch {
        return false;
    }
}

export function isCurrentTaskOrigin(origin, context = getContext()) {
    try {
        return !!origin
            && Number(origin.lifecycleEpoch) === runtimeState.runtimeLifecycleEpoch
            && currentCharacterRuntimeKey(context) === origin.characterKey
            && comparableChatId(getChatId(context)) === origin.chatId;
    } catch {
        return false;
    }
}

// Task-run gates that only need the person binding, not the card text: epoch +
// same-person (card edits tolerated) + same chat. Late read/repaint paths keep
// the stricter isCurrentTaskOrigin so a view opened under one card never
// rebinds under edited card text mid-read.
export function isCurrentTaskRunOrigin(origin, context = getContext()) {
    try {
        return !!origin
            && Number(origin.lifecycleEpoch) === runtimeState.runtimeLifecycleEpoch
            && taskOriginCharacterMatches(origin, context)
            && comparableChatId(getChatId(context)) === origin.chatId;
    } catch {
        return false;
    }
}
