// Heartbeat's independent, browser-local archive content store.
// This module is reachable only from the full runtime bundle; index.js/bootstrap never imports it.
import * as core_constants from '../core/constants.js';
import * as core_context from '../core/context.js';
import * as core_text from '../core/text.js';
import * as core_backupDiagnostics from '../core/backupDiagnostics.js';
import * as core_archiveBridge from '../core/archiveBridge.js';
import * as relay_policy from '../core/archiveRelayPolicy.js';

let databasePromise = null;
let openedDatabase = null;
let testBackend = null;
const backupWriteChains = new Map();

function assertBackupWriteCurrent(options = {}) {
    if (typeof options.stillCurrent === 'function' && options.stillCurrent() === false) {
        throw new Error('这份档案的写入任务已被撤销，旧结果没有写入。');
    }
}

function cloneValue(value) {
    if (value == null) return value;
    try {
        if (typeof structuredClone === 'function') return structuredClone(value);
        return JSON.parse(JSON.stringify(value));
    } catch (error) { throw core_backupDiagnostics.backupFailureError(error, 'serialize', 'clone'); }
}

function utf8JsonSize(value) {
    let json;
    try { json = JSON.stringify(value); }
    catch (error) { throw core_backupDiagnostics.backupFailureError(error, 'serialize', 'clone'); }
    const bytes = new Blob([json], { type: 'application/json' }).size;
    if (bytes > core_constants.MAX_CACHE_SOURCE_BYTES) {
        throw core_backupDiagnostics.backupFailureError(null, 'serialize', 'schema');
    }
    return bytes;
}

function normalizedCharacterIndexHint(value) {
    return Number.isInteger(Number(value)) ? Number(value) : -1;
}

function normalizedIdentity(entry, memory = null) {
    const chatId = core_context.comparableChatId(memory?.chatId || entry?.chatId);
    const characterName = core_text.normalizeText(entry?.characterName || memory?.characterName, 120) || '未命名角色';
    const avatar = core_text.normalizeText(core_context.archiveStoredAvatar(entry), 300);
    const characterKey = core_text.normalizeText(entry?.characterKey, 300) || avatar;
    const characterFingerprint = core_text.normalizeText(entry?.characterFingerprint, 160);
    const characterIndexHint = normalizedCharacterIndexHint(entry?.characterIndexHint);
    const identity = { ...entry, characterKey, avatar, characterName, characterFingerprint, characterIndexHint, chatId };
    return {
        entryId: core_context.archiveIndexEntryId(identity),
        characterKey,
        avatar,
        characterName,
        characterFingerprint,
        characterIndexHint,
        chatId,
    };
}

function identityMatches(record, entry) {
    const wanted = normalizedIdentity(entry);
    if (!record || !wanted.chatId || core_context.comparableChatId(record.chatId) !== wanted.chatId) return false;
    const recordName = core_text.normalizeText(record.characterName, 120);
    const recordAvatar = core_text.normalizeText(record.avatar, 300);
    const recordKey = core_text.normalizeText(record.characterKey, 300);
    const recordFingerprint = core_text.normalizeText(record.characterFingerprint, 160);
    const recordHint = normalizedCharacterIndexHint(record.characterIndexHint);
    if ((wanted.characterIndexHint >= 0 || recordHint >= 0)
        && (wanted.characterIndexHint < 0 || recordHint < 0 || wanted.characterIndexHint !== recordHint)) return false;
    if (wanted.characterFingerprint && recordFingerprint && wanted.characterFingerprint !== recordFingerprint) return false;
    if (wanted.characterName && wanted.characterName !== '未命名角色' && recordName && recordName !== wanted.characterName) return false;
    if (wanted.avatar && recordAvatar && recordAvatar !== wanted.avatar) return false;
    if (wanted.characterKey && recordKey && recordKey !== wanted.characterKey) return false;
    return true;
}

// A deletion fence must survive ordinary character-card edits that change the card
// fingerprint/derived key. Keep this exceptional matcher deliberately narrower than a
// live-record matcher: same chat file, same non-empty avatar, and same slot.
// This prevents a different clone from inheriting the fence while stopping stale source
// metadata from resurrecting the deleted archive after a description edit.
function deletionIdentityMatches(record, entry) {
    const wanted = normalizedIdentity(entry);
    if (!record?.deleted || !wanted.chatId || core_context.comparableChatId(record.chatId) !== wanted.chatId) return false;
    if (core_text.normalizeText(record.entryId, 120) === core_context.archiveIndexEntryId(entry)) return true;
    const recordAvatar = core_text.normalizeText(record.avatar, 300);
    const recordHint = normalizedCharacterIndexHint(record.characterIndexHint);
    return !!wanted.avatar && !!recordAvatar && wanted.avatar === recordAvatar
        && wanted.characterIndexHint >= 0 && recordHint >= 0 && wanted.characterIndexHint === recordHint;
}

function exactIdentityCompatibleWithMissing(record, entry) {
    const wanted = normalizedIdentity(entry);
    if (!record || !wanted.chatId || core_context.comparableChatId(record.chatId) !== wanted.chatId) return false;
    const comparableText = (left, right, limit, ignored = '') => {
        const a = core_text.normalizeText(left, limit);
        const b = core_text.normalizeText(right, limit);
        if (!a || !b || (ignored && (a === ignored || b === ignored))) return true;
        return a === b;
    };
    if (!comparableText(record.characterName, wanted.characterName, 120, '未命名角色')) return false;
    if (!comparableText(core_context.archiveStoredAvatar(record), wanted.avatar, 300)) return false;
    if (!comparableText(record.characterKey, wanted.characterKey, 300)) return false;
    if (!comparableText(record.characterFingerprint, wanted.characterFingerprint, 160)) return false;
    const recordHasHint = Object.prototype.hasOwnProperty.call(record, 'characterIndexHint')
        && normalizedCharacterIndexHint(record.characterIndexHint) >= 0;
    const wantedHasHint = normalizedCharacterIndexHint(wanted.characterIndexHint) >= 0;
    if (recordHasHint && wantedHasHint
        && normalizedCharacterIndexHint(record.characterIndexHint) !== normalizedCharacterIndexHint(wanted.characterIndexHint)) return false;
    return true;
}

function identityMatchesExceptName(record, entry) {
    const wanted = normalizedIdentity(entry);
    if (!record || !wanted.chatId || core_context.comparableChatId(record.chatId) !== wanted.chatId) return false;
    const recordAvatar = core_text.normalizeText(record.avatar, 300);
    const recordKey = core_text.normalizeText(record.characterKey, 300);
    const recordHint = normalizedCharacterIndexHint(record.characterIndexHint);
    // Exact-key card edits may adopt a newly introduced slot hint, but an existing
    // non-matching hint is never transferable to another card.
    if (recordHint >= 0 && wanted.characterIndexHint >= 0 && recordHint !== wanted.characterIndexHint) return false;
    if (recordHint >= 0 && wanted.characterIndexHint < 0) return false;
    // A rename capability is deliberately unavailable when either stable locator is
    // absent. This keeps the exceptional path narrower than the ordinary matcher.
    if (!wanted.avatar || !recordAvatar || wanted.avatar !== recordAvatar) return false;
    if (!wanted.characterKey || !recordKey || wanted.characterKey !== recordKey) return false;
    return true;
}

function backupRecordsEquivalent(previous, incoming) {
    if (!previous || !incoming || previous.entryId !== incoming.entryId
        || previous.archiveRevision !== incoming.archiveRevision) return false;
    try {
        return JSON.stringify(previous.memory) === JSON.stringify(incoming.memory)
            && JSON.stringify(previous.cache ?? null) === JSON.stringify(incoming.cache ?? null);
    } catch { return false; }
}

function cacheCommitOrder(value) {
    const token = Math.floor(Number(value?.commitToken) || 0);
    if (Number.isSafeInteger(token) && token > 0) return token;
    return Math.min(Number.MAX_SAFE_INTEGER - 1, Math.max(0, Math.floor(Number(value?.updatedAt) || 0)) * 1000);
}

function cachesEquivalent(left, right) {
    try { return JSON.stringify(left ?? null) === JSON.stringify(right ?? null); }
    catch { return false; }
}

async function serializeBackupWrite(entry, operation) {
    const key = core_context.archiveIndexEntryId(entry);
    const previous = backupWriteChains.get(key) || Promise.resolve();
    const current = previous.catch(() => {}).then(operation);
    backupWriteChains.set(key, current);
    try { return await current; }
    finally { if (backupWriteChains.get(key) === current) backupWriteChains.delete(key); }
}

export function hasMatchingArchiveDeletionFence(records, entry) {
    const entryId = core_context.archiveIndexEntryId(entry);
    return (Array.isArray(records) ? records : [])
        .some(record => record?.deleted === true && (
            core_text.normalizeText(record?.entryId, 120) === entryId
            || deletionIdentityMatches(record, entry)
        ));
}

function compatibleCacheValue(cache, memory) {
    if (!cache || typeof cache !== 'object') return null;
    const chatId = core_context.comparableChatId(memory?.chatId);
    const archiveRevision = core_text.normalizeText(memory?.archiveRevision, 240);
    const cacheChatId = core_context.comparableChatId(cache?.chatId);
    const cacheRevision = core_text.normalizeText(cache?.archiveRevision, 240);
    if (cacheChatId && cacheChatId !== chatId) return null;
    if (cacheRevision && cacheRevision !== archiveRevision) return null;
    if (cache.format === core_constants.CACHE_STORAGE_FORMAT) {
        if (Number(cache.storageVersion) !== core_constants.CACHE_STORAGE_VERSION) return null;
        if (typeof cache.data !== 'string' || !cache.data || cache.data.length > core_constants.MAX_CACHE_COMPRESSED_BASE64_CHARS) return null;
        if (Number(cache.sourceBytes) > core_constants.MAX_CACHE_SOURCE_BYTES) return null;
        return cloneValue(cache);
    }
    utf8JsonSize(cache);
    return cloneValue(cache);
}

function normalizeRecord(raw, entry = null) {
    if (!raw || typeof raw !== 'object' || Number(raw.storageVersion) !== core_constants.ARCHIVE_BACKUP_STORAGE_VERSION) return null;
    const exactEntryId = entry
        && core_text.normalizeText(raw?.entryId, 120)
        && core_text.normalizeText(raw.entryId, 120) === core_context.archiveIndexEntryId(entry);
    if (entry && !identityMatches(raw, entry)
        && !(exactEntryId && exactIdentityCompatibleWithMissing(raw, entry))
        && !(entry?.allowCharacterRename === true && exactEntryId && identityMatchesExceptName(raw, entry))) return null;
    const memory = cloneValue(raw.memory);
    if (!memory || typeof memory !== 'object' || !Array.isArray(memory.memories)) return null;
    const identity = normalizedIdentity(raw, memory);
    if (!identity.entryId || !identity.chatId || identity.chatId !== core_context.comparableChatId(memory.chatId)) return null;
    const revision = core_text.normalizeText(memory.archiveRevision, 240);
    if (!revision || revision !== core_text.normalizeText(raw.archiveRevision, 240)) return null;
    utf8JsonSize(memory);
    const cache = compatibleCacheValue(raw.cache, memory);
    return {
        storageVersion: core_constants.ARCHIVE_BACKUP_STORAGE_VERSION,
        ...identity,
        archiveName: core_text.normalizeText(raw.archiveName || memory.archiveName, 160) || '未命名档案',
        archiveRevision: revision,
        memory,
        cache,
        createdAt: Math.max(0, Number(raw.createdAt) || Number(memory.createdAt) || Date.now()),
        updatedAt: Math.max(0, Number(raw.updatedAt) || Number(memory.updatedAt) || Date.now()),
    };
}

function buildRecord(entry, memory, cache = null) {
    const identity = normalizedIdentity(entry, memory);
    if (!identity.entryId || !identity.chatId) throw core_backupDiagnostics.backupFailureError(null, 'normalize', 'schema');
    const safeMemory = cloneValue(memory);
    if (!safeMemory || !Array.isArray(safeMemory.memories)) throw core_backupDiagnostics.backupFailureError(null, 'normalize', 'schema');
    safeMemory.chatId = identity.chatId;
    const archiveRevision = core_text.normalizeText(safeMemory.archiveRevision, 240);
    if (!archiveRevision) throw core_backupDiagnostics.backupFailureError(null, 'normalize', 'schema');
    utf8JsonSize(safeMemory);
    return {
        storageVersion: core_constants.ARCHIVE_BACKUP_STORAGE_VERSION,
        ...identity,
        archiveName: core_text.normalizeText(safeMemory.archiveName, 160) || '未命名档案',
        archiveRevision,
        memory: safeMemory,
        cache: compatibleCacheValue(cache, safeMemory),
        createdAt: Math.max(0, Number(safeMemory.createdAt) || Date.now()),
        updatedAt: Math.max(0, Number(safeMemory.updatedAt) || Date.now()),
    };
}

// iOS Safari 会在页面进后台或存储紧张时关掉 IndexedDB 连接，不一定发 close 事件。
// 之后在旧连接上开事务报 InvalidStateError，读写请求报 UnknownError。缓存着旧连接，
// 每次保存都会失败到刷新为止，而刷新会丢掉暂存在页面里、还没回填的生图结果。
function connectionLost(error) {
    try { return error?.name === 'InvalidStateError' || error?.name === 'UnknownError'; } catch { return false; }
}

function forgetDatabase(db) {
    if (!db || openedDatabase !== db) return;
    openedDatabase = null;
    databasePromise = null;
    try { db.close(); } catch {}
}

// 只在事务还没开起来时换连接重试：这时什么都没写入。run 必须在开事务的同一轮里发出第一个请求。
async function backupTransaction(mode, stage, run) {
    for (let attempt = 0; ; attempt += 1) {
        const db = await openDatabase();
        let transaction;
        try { transaction = db.transaction(core_constants.ARCHIVE_BACKUP_STORE_NAME, mode); }
        catch (error) {
            const lost = connectionLost(error);
            if (lost) forgetDatabase(db);
            if (lost && attempt === 0) continue;
            throw stage ? core_backupDiagnostics.backupFailureError(error, stage, 'transaction') : error;
        }
        return { db, result: run(transaction) };
    }
}

// Relay records and archive records must commit in the SAME database transaction.
export async function archiveBackupTransaction(mode, run) {
    for (let attempt = 0; ; attempt++) {
        const { db, result } = await backupTransaction(mode, mode === 'readwrite' ? 'write' : 'read', run);
        try { return await result; }
        catch (error) {
            const lost = connectionLost(error);
            if (lost) forgetDatabase(db);
            if (lost && mode === 'readonly' && attempt === 0) continue;
            // Never replay a write whose outcome may be uncertain.
            throw error;
        }
    }
}

export function prepareArchiveBackupRecord(entry, memory, cache) { return buildRecord(entry, memory, cache); }

export function normalizeArchiveBackupRecord(raw, entry) { return normalizeRecord(raw, entry); }

export async function readArchiveRelayState(entry) {
    if (testBackend && typeof testBackend.readRelay !== 'function') return relay_policy.rememberRelayFence(entry, null);
    const value = testBackend ? await testBackend.readRelay(entry) : await archiveBackupTransaction('readonly', tx => new Promise((resolve, reject) => {
        let found = null;
        const request = tx.objectStore(core_constants.ARCHIVE_BACKUP_STORE_NAME).get(relay_policy.relayMemberKey(entry));
        request.onsuccess = () => { found = request.result || null; };
        request.onerror = () => reject(request.error);
        tx.oncomplete = () => resolve(found);
        tx.onabort = () => reject(tx.error || relay_policy.relayError('接力登记读取失败，原内容保留。'));
    }));
    return relay_policy.rememberRelayFence(entry, value);
}

export async function assertArchiveRelayWritable(entry, memory = null) {
    let fence;
    try { fence = await readArchiveRelayState(entry); }
    catch (error) {
        // An optional relay lookup must not introduce a new preparation/storage
        // requirement for ordinary chats. Their existing durable-save checks
        // still apply. Known relay members remain fail-closed, including a
        // malformed registry; canonical put/delete always check in-transaction.
        if (memory?.archiveRelayV1 || relay_policy.relayUiState(entry)
            || String(error?.code || '').startsWith('RMT_RELAY_')) throw error;
        return null;
    }
    return relay_policy.assertRelayWrite(entry, fence, memory);
}

function openDatabase() {
    if (databasePromise) return databasePromise;
    // Getter/open may throw synchronously in restricted webviews. Every failed
    // attempt releases the cached promise so a later explicit retry is possible.
    const pending = new Promise((resolve, reject) => {
        let settled = false;
        let request;
        const fail = (error, stage = 'open', category = 'unknown') => {
            if (settled) return;
            settled = true;
            reject(core_backupDiagnostics.backupFailureError(error, stage, category));
        };
        try {
            if (typeof globalThis.indexedDB?.open !== 'function') return fail(null, 'open', 'unavailable');
            request = globalThis.indexedDB.open(core_constants.ARCHIVE_BACKUP_DB_NAME, core_constants.ARCHIVE_BACKUP_STORAGE_VERSION);
        } catch (error) { fail(error); return; }
        request.onupgradeneeded = () => {
            if (settled) { try { request.transaction?.abort(); } catch {} return; }
            try {
                const db = request.result;
                const store = db.objectStoreNames.contains(core_constants.ARCHIVE_BACKUP_STORE_NAME)
                    ? request.transaction.objectStore(core_constants.ARCHIVE_BACKUP_STORE_NAME)
                    : db.createObjectStore(core_constants.ARCHIVE_BACKUP_STORE_NAME, { keyPath: 'entryId' });
                if (!store.indexNames.contains('chatId')) store.createIndex('chatId', 'chatId', { unique: false });
                if (!store.indexNames.contains('updatedAt')) store.createIndex('updatedAt', 'updatedAt', { unique: false });
            } catch (error) {
                fail(error, 'upgrade', 'schema');
                try { request.transaction?.abort(); } catch {}
            }
        };
        request.onsuccess = () => {
            if (settled) { try { request.result?.close(); } catch {} return; }
            settled = true;
            const db = request.result;
            openedDatabase = db;
            try { db.onclose = () => forgetDatabase(db); } catch {}
            resolve(db);
        };
        request.onerror = () => fail(request.error);
        request.onblocked = () => fail(null, 'open', 'blocked');
    });
    databasePromise = pending;
    void pending.catch(() => { if (databasePromise === pending) databasePromise = null; });
    return pending;
}

function idbReadRecord(transaction, entry, withRelay = false) {
    return new Promise((resolve, reject) => {
        let settled = false;
        let raw = null, fence = null;
        const finish = (settle, value) => {
            if (withRelay && settle === resolve) { raw = value; return; }
            if (!settled) { settled = true; settle(value); }
        };
        try {
            const identity = normalizedIdentity(entry);
            const store = transaction.objectStore(core_constants.ARCHIVE_BACKUP_STORE_NAME);
            transaction.onabort = () => finish(reject, transaction.error);
            if (withRelay) {
                // Content and holder are one read snapshot, not two transactions.
                const relayRequest = store.get(relay_policy.relayMemberKey(entry));
                relayRequest.onerror = () => finish(reject, relayRequest.error);
                relayRequest.onsuccess = () => { fence = relayRequest.result || null; };
                transaction.oncomplete = () => {
                    if (settled) return;
                    try {
                        const relay = relay_policy.rememberRelayFence(entry, fence);
                        settled = true; resolve({ raw, relay });
                    } catch (error) { finish(reject, error); }
                };
            }
            const exactRequest = store.get(identity.entryId);
            exactRequest.onerror = () => finish(reject, exactRequest.error);
            exactRequest.onsuccess = () => {
                if (exactRequest.result) return finish(resolve, exactRequest.result);
                // 第二次读取在回调里同步发出，不隔 await：回调结束后事务何时失效，各浏览器不一致。
                try {
                    const matchesRequest = store.index('chatId').getAll(identity.chatId);
                    matchesRequest.onerror = () => finish(reject, matchesRequest.error);
                    matchesRequest.onsuccess = () => {
                        const matches = matchesRequest.result;
                        const compatible = (Array.isArray(matches) ? matches : []).filter(item => item?.deleted === true
                            ? deletionIdentityMatches(item, entry)
                            : identityMatches(item, entry));
                        // A legacy entry ID may differ from the newer fingerprint-derived ID. Recover only when the
                        // chat + stable display identity resolve to exactly one record; ambiguity stays fail-closed.
                        finish(resolve, compatible.length === 1 ? compatible[0] : null);
                    };
                } catch (error) { finish(reject, error); }
            };
        } catch (error) { finish(reject, error); }
    });
}

async function idbRead(entry, withRelay = false) {
    for (let attempt = 0; ; attempt += 1) {
        const { db, result } = await backupTransaction('readonly', 'read', transaction => idbReadRecord(transaction, entry, withRelay));
        try { return await result; }
        catch (error) {
            // 读取没有副作用：连接断了就换新连接再读一次。
            const lost = connectionLost(error);
            if (lost) forgetDatabase(db);
            if (lost && attempt === 0) continue;
            throw core_backupDiagnostics.backupFailureError(error, 'read', 'transaction');
        }
    }
}

async function idbPut(record, expected = null, options = {}) {
    const { db, result } = await backupTransaction('readwrite', 'write', transaction => idbPutRecord(transaction, record, expected, options));
    return result.catch(error => {
        if (connectionLost(error)) forgetDatabase(db);
        if (String(error?.code || '').startsWith('RMT_RELAY_')) throw error;
        throw core_backupDiagnostics.backupFailureError(error, 'write', 'transaction');
    });
}

function idbPutRecord(transaction, record, expected, options) {
    return new Promise((resolve, reject) => {
        const store = transaction.objectStore(core_constants.ARCHIVE_BACKUP_STORE_NAME);
        let outcome = false;
        let finalized = false;
        let exactRaw = null;
        let chatRecords = [];
        let exactDone = false;
        let matchesDone = false;
        let relayDone = false;
        let relayState = null;
        let abortReason = null;
        const abortWith = error => {
            // A request error is often more specific than transaction.error (or
            // the later AbortError); retain it before aborting the transaction.
            if (!abortReason) abortReason = error || core_backupDiagnostics.backupFailureError(null, 'write', 'transaction');
            try { transaction.abort(); }
            catch { reject(abortReason); }
        };
        const finalizeWrite = () => {
            assertBackupWriteCurrent(options);
            relay_policy.rememberRelayFence(record, relayState);
            // Opening a frozen source is a read, not an attempt to take ownership.
            if (options.seed === true && relay_policy.relayReadOnly(record, relayState)) { outcome = true; return; }
            const relay = relay_policy.assertRelayWrite(record, relayState, record.memory);
            const aliases = new Map();
            for (const candidate of [exactRaw, ...chatRecords]) {
                const id = core_text.normalizeText(candidate?.entryId, 120);
                if (id && (id === core_text.normalizeText(record.entryId, 120)
                    || identityMatches(candidate, record)
                    || deletionIdentityMatches(candidate, record))) aliases.set(id, candidate);
            }
            const matching = [...aliases.values()];
            const matchingDeletionFences = matching.filter(candidate => candidate?.deleted === true && (
                core_text.normalizeText(candidate?.entryId, 120) === core_context.archiveIndexEntryId(record)
                || deletionIdentityMatches(candidate, record)
            ));
            const recreateStartedAt = Math.max(0, Number(options.recreateStartedAt) || 0);
            const canRecreateDeleted = options.allowDeletedRecreate === true
                && recreateStartedAt > 0
                && matchingDeletionFences.every(candidate => {
                    const deletedAt = Math.max(0, Number(candidate?.deletedAt) || 0);
                    return deletedAt > 0 && deletedAt < recreateStartedAt;
                });
            if (matchingDeletionFences.length && !canRecreateDeleted) {
                abortReason = new Error('这份档案已被明确删除，旧任务不能重新创建它。');
                abortReason.code = 'RMT_ARCHIVE_DELETED_FENCE';
                transaction.abort();
                return;
            }
            const liveAliases = matching.map(candidate => normalizeRecord(candidate)).filter(Boolean);
            if (liveAliases.length > 1) {
                transaction.abort();
                return;
            }
            let previous = normalizeRecord(exactRaw);
            const exactPrevious = previous;
            if (!previous && liveAliases.length === 1) {
                previous = liveAliases[0];
                // Preserve a legacy/index-assigned durable key instead of creating a second
                // record under a newly fingerprinted ID.
                record = { ...record, entryId: previous.entryId };
            }
            const previousRevision = core_text.normalizeText(previous?.archiveRevision, 240);
            const expectedRevision = core_text.normalizeText(expected?.revision, 240);
            const authorizedIdentityRefresh = options.allowCharacterRename === true
                && exactPrevious === previous
                && core_text.normalizeText(previous?.entryId, 120) === core_text.normalizeText(record.entryId, 120)
                && identityMatchesExceptName(previous, record)
                && ((expected?.present === true && previousRevision === expectedRevision)
                    || (options.seed === true && previousRevision === record.archiveRevision));
            const authorizedMissingFieldEnrichment = exactPrevious === previous
                && core_text.normalizeText(previous?.entryId, 120) === core_text.normalizeText(record.entryId, 120)
                && exactIdentityCompatibleWithMissing(exactRaw, record)
                && ((expected?.present === true && previousRevision === expectedRevision)
                    || (options.seed === true && previousRevision === record.archiveRevision));
            if (previous && !identityMatches(previous, record) && !authorizedIdentityRefresh && !authorizedMissingFieldEnrichment) return transaction.abort();
            const idempotentRetry = options.allowIdempotentRetry === true
                && exactPrevious === previous
                && (identityMatches(previous, record) || authorizedMissingFieldEnrichment)
                && backupRecordsEquivalent(previous, record);
            if (expected?.present === false && previous && !idempotentRetry) return transaction.abort();
            if (expected?.present === true && previous && previousRevision !== expectedRevision && !idempotentRetry) return transaction.abort();
            if (expected?.present === true && !previous && options.allowMissingPrevious !== true) return transaction.abort();
            const replacingProvenInvalidCache = options.seed === true && options.replaceInvalidCache === true;
            if (Number.isFinite(Number(options.expectedCacheOrder))) {
                const expectedCacheOrder = Math.max(0, Math.floor(Number(options.expectedCacheOrder) || 0));
                const comparePreviousCache = options.comparePreviousCache === true
                    && expected?.present === true && previousRevision === expectedRevision;
                const currentCacheOrder = previousRevision === record.archiveRevision || comparePreviousCache
                    ? cacheCommitOrder(previous?.cache) : 0;
                if (currentCacheOrder !== expectedCacheOrder) {
                    abortReason = new Error('独立档案备份的派生缓存已被另一个页面更新，本次将重新合并。');
                    abortReason.code = 'RMT_CACHE_CAS_CONFLICT';
                    transaction.abort();
                    return;
                }
            }
            if (!replacingProvenInvalidCache && previous && previousRevision === record.archiveRevision && previous.cache && record.cache) {
                const previousCacheOrder = cacheCommitOrder(previous.cache);
                const incomingCacheOrder = cacheCommitOrder(record.cache);
                if (incomingCacheOrder < previousCacheOrder
                    || (incomingCacheOrder === previousCacheOrder && !cachesEquivalent(previous.cache, record.cache))) return transaction.abort();
            }
            if (canRecreateDeleted) {
                // A deliberate new canonical archive may replace an earlier deletion. Clear
                // every matching tombstone alias in this transaction so future seed/cache
                // updates are not blocked by an older entry ID.
                for (const [id, candidate] of aliases) {
                    if (candidate?.deleted === true && id !== record.entryId) store.delete(id);
                }
            }
            if (options.seed === true && !replacingProvenInvalidCache && previous && previousRevision === record.archiveRevision) {
                const previousCacheTime = Math.max(0, Number(previous.cache?.updatedAt) || 0);
                const incomingCacheTime = Math.max(0, Number(record.cache?.updatedAt) || 0);
                if (previous.cache && (!record.cache || previousCacheTime > incomingCacheTime)) {
                    // Opening a source whose CACHE_KEY is absent/older must never erase the last
                    // same-revision independent cache that could recover generated content.
                    record = { ...record, cache: cloneValue(previous.cache) };
                }
            }
            if (options.seed === true && previous && previousRevision !== record.archiveRevision) {
                // Seeding mirrors a source; it is never allowed to replace a canonical IDB
                // revision. Revision IDs are opaque and wall clocks can tie or move backwards.
                outcome = true;
                return;
            }
            if (!idempotentRetry) {
                if (relay) record.memory.archiveRelayV1 = { version: 1, lineageId: relay.lineageId, epoch: relay.epoch };
                const putRequest = store.put(record);
                if (putRequest) putRequest.onerror = () => abortWith(putRequest.error);
            }
            outcome = true;
        };
        const finalize = () => {
            if (finalized || !exactDone || !matchesDone || !relayDone) return;
            finalized = true;
            try { finalizeWrite(); }
            catch (error) { abortWith(error); }
        };
        const getRequest = store.get(record.entryId);
        getRequest.onerror = () => abortWith(getRequest.error);
        getRequest.onsuccess = () => {
            exactRaw = getRequest.result || null;
            exactDone = true;
            finalize();
        };
        const matchesRequest = store.index('chatId').getAll(record.chatId);
        matchesRequest.onerror = () => abortWith(matchesRequest.error);
        matchesRequest.onsuccess = () => {
            chatRecords = Array.isArray(matchesRequest.result) ? matchesRequest.result : [];
            matchesDone = true;
            finalize();
        };
        const relayRequest = store.get(relay_policy.relayMemberKey(record));
        relayRequest.onerror = () => abortWith(relayRequest.error);
        relayRequest.onsuccess = () => { relayState = relayRequest.result; relayDone = true; finalize(); };
        transaction.oncomplete = () => resolve(outcome);
        transaction.onabort = () => reject(abortReason || transaction.error || core_backupDiagnostics.backupFailureError(null, 'write', 'transaction'));
        transaction.onerror = () => reject(abortReason || transaction.error || core_backupDiagnostics.backupFailureError(null, 'write', 'transaction'));
    });
}

async function idbDeleteOne(db, entry) {
    const identity = normalizedIdentity(entry);
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(core_constants.ARCHIVE_BACKUP_STORE_NAME, 'readwrite');
        const store = transaction.objectStore(core_constants.ARCHIVE_BACKUP_STORE_NAME);
        const ids = new Set();
        const records = new Map();
        let exactDone = false;
        let matchesDone = false;
        const finalize = () => {
            if (!exactDone || !matchesDone) return;
            for (const record of records.values()) {
                if (identityMatches(record, entry)) ids.add(core_text.normalizeText(record.entryId, 120));
            }
            // The explicit durable key remains the deletion authority when card metadata drifts.
            // Identity matching is only needed to discover legacy aliases under other keys.
            if (identity.entryId) ids.add(identity.entryId);
            for (const id of ids) {
                if (!id) continue;
                const source = records.get(id) || entry;
                store.put({
                    storageVersion: core_constants.ARCHIVE_BACKUP_STORAGE_VERSION,
                    ...normalizedIdentity(source),
                    entryId: id,
                    deleted: true,
                    deletedAt: Date.now(),
                    memory: null,
                    cache: null,
                    archiveRevision: '',
                    archiveName: '',
                    createdAt: 0,
                    updatedAt: Date.now(),
                });
            }
        };
        const exactRequest = store.get(identity.entryId);
        exactRequest.onerror = () => transaction.abort();
        exactRequest.onsuccess = () => {
            if (exactRequest.result) records.set(identity.entryId, exactRequest.result);
            exactDone = true;
            finalize();
        };
        const matchesRequest = store.index('chatId').getAll(identity.chatId);
        matchesRequest.onerror = () => transaction.abort();
        matchesRequest.onsuccess = () => {
            for (const record of Array.isArray(matchesRequest.result) ? matchesRequest.result : []) {
                const id = core_text.normalizeText(record?.entryId, 120);
                if (id) records.set(id, record);
            }
            matchesDone = true;
            finalize();
        };
        transaction.oncomplete = () => resolve(true);
        transaction.onabort = () => reject(transaction.error || new Error('独立档案备份删除失败。'));
        transaction.onerror = () => reject(transaction.error || new Error('独立档案备份删除失败。'));
    });
}

async function idbDelete(entries) {
    await openDatabase();
    const targets = (Array.isArray(entries) ? entries : [entries]).filter(Boolean);
    if (!targets.length) return true;
    return (await backupTransaction('readwrite', '', transaction => idbDeleteRecords(transaction, targets))).result;
}

function idbDeleteRecords(transaction, targets) {
    return new Promise((resolve, reject) => {
        // A character group is one user-visible deletion. Resolve every exact/legacy alias and
        // write all tombstones in one IndexedDB transaction so an Nth-record failure cannot
        // leave the first N-1 backups silently deleted while the library index remains intact.
        const store = transaction.objectStore(core_constants.ARCHIVE_BACKUP_STORE_NAME);
        const discovered = targets.map(() => ({ exact: null, chat: [], relay: null }));
        let pending = targets.length * 3;
        let finalized = false;
        const abort = error => {
            if (error) transaction.__rmtAbortReason = error;
            try { transaction.abort(); } catch {}
        };
        const finishDiscovery = () => {
            pending -= 1;
            if (pending || finalized) return;
            finalized = true;
            try {
                for (let i = 0; i < targets.length; i++) {
                    const found = discovered[i];
                    const records = [found.exact, ...found.chat.filter(row => identityMatches(row, targets[i]))].filter(Boolean);
                    relay_policy.assertRelayWrite(targets[i], found.relay);
                    for (const record of records) relay_policy.assertRelayWrite(targets[i], found.relay, record.memory);
                }
            }
            catch (error) { abort(error); return; }
            const tombstones = new Map();
            const deletedAt = Date.now();
            for (let index = 0; index < targets.length; index += 1) {
                const target = targets[index];
                const identity = normalizedIdentity(target);
                const records = new Map();
                const exact = discovered[index].exact;
                if (exact?.entryId) records.set(core_text.normalizeText(exact.entryId, 120), exact);
                for (const record of discovered[index].chat) {
                    const id = core_text.normalizeText(record?.entryId, 120);
                    if (id) records.set(id, record);
                }
                const ids = new Set(identity.entryId ? [identity.entryId] : []);
                for (const record of records.values()) {
                    if (identityMatches(record, target)) ids.add(core_text.normalizeText(record.entryId, 120));
                }
                for (const id of ids) {
                    if (!id) continue;
                    const source = records.get(id) || target;
                    tombstones.set(id, {
                        storageVersion: core_constants.ARCHIVE_BACKUP_STORAGE_VERSION,
                        ...normalizedIdentity(source),
                        entryId: id,
                        deleted: true,
                        deletedAt,
                        memory: null,
                        cache: null,
                        archiveRevision: '',
                        archiveName: '',
                        createdAt: 0,
                        updatedAt: deletedAt,
                    });
                }
            }
            try {
                for (const record of tombstones.values()) store.put(record);
            } catch (error) { abort(error); }
        };
        targets.forEach((target, index) => {
            const identity = normalizedIdentity(target);
            const exactRequest = store.get(identity.entryId);
            exactRequest.onerror = () => abort(exactRequest.error || new Error('独立档案备份删除失败。'));
            exactRequest.onsuccess = () => { discovered[index].exact = exactRequest.result || null; finishDiscovery(); };
            const matchesRequest = store.index('chatId').getAll(identity.chatId);
            matchesRequest.onerror = () => abort(matchesRequest.error || new Error('独立档案备份删除失败。'));
            matchesRequest.onsuccess = () => { discovered[index].chat = Array.isArray(matchesRequest.result) ? matchesRequest.result : []; finishDiscovery(); };
            const relayRequest = store.get(relay_policy.relayMemberKey(target));
            relayRequest.onerror = () => abort(relayRequest.error);
            relayRequest.onsuccess = () => { discovered[index].relay = relayRequest.result; finishDiscovery(); };
        });
        transaction.oncomplete = () => resolve(true);
        transaction.onabort = () => reject(transaction.__rmtAbortReason || transaction.error || new Error('独立档案备份删除失败。'));
        transaction.onerror = () => reject(transaction.error || new Error('独立档案备份删除失败。'));
    });
}

function backend() {
    return testBackend || {
        read: idbRead,
        put: idbPut,
        delete: idbDelete,
    };
}

export function setArchiveBackupBackendForTests(value = null) {
    testBackend = value;
}

export async function readArchiveBackup(entry) {
    let raw;
    try { raw = await backend().read(entry); }
    catch (error) { throw core_backupDiagnostics.annotateBackupFailure(error, 'read'); }
    try { return normalizeRecord(raw, entry); }
    catch (error) { throw core_backupDiagnostics.annotateBackupFailure(error, 'normalize'); }
}

export async function readArchiveBackupState(entry) {
    let raw, relay;
    try {
        if (testBackend) { raw = await testBackend.read(entry); relay = await readArchiveRelayState(entry); }
        else ({ raw, relay } = await idbRead(entry, true));
    }
    catch (error) { throw core_backupDiagnostics.annotateBackupFailure(error, 'read'); }
    const exactEntryId = core_text.normalizeText(raw?.entryId, 120) === core_context.archiveIndexEntryId(entry);
    if (raw?.deleted === true && (exactEntryId || deletionIdentityMatches(raw, entry))) {
        return { deleted: true, deletedAt: Math.max(0, Number(raw.deletedAt) || 0), record: null };
    }
    try { return { deleted: false, deletedAt: 0, record: normalizeRecord(raw, entry), relay }; }
    catch (error) { throw core_backupDiagnostics.annotateBackupFailure(error, 'normalize'); }
}

export async function hasArchiveBackupDeletionFence(entry) {
    return (await readArchiveBackupState(entry)).deleted === true;
}

export async function replaceArchiveBackup(entry, memory, cache, expectedState, options = {}) {
    return serializeBackupWrite(entry, async () => {
        assertBackupWriteCurrent(options);
        const record = buildRecord(entry, memory, cache);
        if (expectedState?.present === true && options.allowMissingPrevious === true && record.cache) {
            const previous = await readArchiveBackup(entry);
            assertBackupWriteCurrent(options);
            if (previous?.archiveRevision === record.archiveRevision && previous.cache) {
                const previousOrder = cacheCommitOrder(previous.cache);
                const incomingOrder = cacheCommitOrder(record.cache);
                if (incomingOrder < previousOrder
                    || (incomingOrder === previousOrder && !cachesEquivalent(previous.cache, record.cache))) {
                    throw new Error('独立档案备份已有更新的派生缓存，本次旧结果没有覆盖备份。');
                }
            }
        }
        assertBackupWriteCurrent(options);
        let saved;
        try { saved = await backend().put(record, expectedState, options); }
        catch (error) { throw core_backupDiagnostics.annotateBackupFailure(error, 'write'); }
        assertBackupWriteCurrent(options);
        if (!saved) throw core_backupDiagnostics.backupFailureError(null, 'write', 'transaction');
        return cloneValue(record);
    });
}

export async function seedArchiveBackup(entry, memory, cache = null, options = {}) {
    return serializeBackupWrite(entry, async () => {
        assertBackupWriteCurrent(options);
        const record = buildRecord(entry, memory, cache);
        const previous = await readArchiveBackup(entry);
        assertBackupWriteCurrent(options);
        if (options.replaceInvalidCache !== true && previous?.archiveRevision === record.archiveRevision && previous.cache
            && (!record.cache || cacheCommitOrder(previous.cache) > cacheCommitOrder(record.cache))) {
            record.cache = cloneValue(previous.cache);
        }
        let saved;
        try {
            saved = await backend().put(record, null, {
                seed: true,
                allowMissingPrevious: true,
                allowCharacterRename: entry?.allowCharacterRename === true,
                replaceInvalidCache: options.replaceInvalidCache === true,
                stillCurrent: options.stillCurrent,
            });
        } catch (error) { throw core_backupDiagnostics.annotateBackupFailure(error, 'write'); }
        assertBackupWriteCurrent(options);
        return saved ? cloneValue(record) : null;
    });
}

export async function updateArchiveBackupCache(entry, memory, cache, options = {}) {
    return replaceArchiveBackup(entry, memory, cache, { present: true, revision: core_text.normalizeText(memory?.archiveRevision, 240) }, {
        allowMissingPrevious: true,
        allowCharacterRename: entry?.allowCharacterRename === true,
        expectedCacheOrder: options.expectedCacheOrder,
        stillCurrent: options.stillCurrent,
    });
}

export async function deleteArchiveBackup(entries) {
    return backend().delete(entries);
}

// 重构清单 C-3c（r84.101）：把 core 层要用的函数登记到 core/archiveBridge.js（core 不再 import 本文件）。
core_archiveBridge.registerArchiveBridge({ readArchiveBackupState, replaceArchiveBackup, seedArchiveBackup, updateArchiveBackupCache });
