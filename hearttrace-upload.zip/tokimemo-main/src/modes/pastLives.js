import * as cg_visual from '../core/cgVisualRules.js';
import * as cg_targets from '../core/cgTargets.js';
import * as contract from '../core/pastLivesContract.js';
import * as text from '../core/text.js';
import * as evidence from '../core/evidence.js';
import * as narrative from '../core/narrativeAuthority.js';
import * as contextApi from '../core/context.js';
import * as participants from '../core/participants.js';
import * as cache from '../core/cache.js';
import * as incremental from '../core/incremental.js';
import * as generation from '../generation/client.js';
import * as prompts from '../generation/prompts.js';
import * as relationshipSafety from '../core/relationshipSafety.js';
import * as requestCoordinator from '../core/requestCoordinator.js';
import * as settings from '../core/settings.js';
import * as core_modesBridge from '../core/modesBridge.js';
import * as generation_modesBridge from '../generation/modesBridge.js';

export const PAST_LIVES_VERSION = contract.PAST_LIVES_VERSION;
export const PAST_LIVES_MODE = contract.PAST_LIVES_MODE;
const L = contract.PAST_LIVES_LIMITS;
const clean = contract.pastLivesText;
const list = contract.pastLivesArray;
const fail = contract.pastLivesError;
const localId = (prefix, index) => `${prefix}${String(index + 1).padStart(2, '0')}`;
const ownerLabel = memory => participants.resolveStoryIdentities(memory).ownerNames.join('、') || text.normalizeText(memory?.characterName, 120);
const roleContext = memory => ({ name1: memory?.userName || '', name2: ownerLabel(memory) });

// r84.171：文字检查不再让整步生成失败。只去掉命中的那几句；
// 必需字段整段都命中时保留原文，非必需字段留空；回响、旁批这类单条内容整条命中时只丢掉那一条。
const SENTENCES = /[^。！？!?；;\n]+[。！？!?；;]*\n?|\n/gu;
function keepSentences(value, ok) {
    if (!value || ok(value)) return value;
    return (value.match(SENTENCES) || []).filter(part => !part.trim() || ok(part)).join('').trim();
}

function fictionalText(value, memory, max = L.prose, required = false, speaker = 'char') {
    const result = clean(value, max, required);
    const context = roleContext(memory);
    if (speaker === 'user') [context.name1, context.name2] = [context.name2, context.name1];
    const ok = part => {
        try { relationshipSafety.assertPairRelationshipSafety(part, context, '前世今生', undefined, { fictionPairScope: true }); return true; }
        catch { return false; }
    };
    const kept = keepSentences(result, ok);
    return kept || (required ? result : '');
}

const PRESENT_CLAIM = /(?:今生|现实|此生).{0,16}(?:已经应验|确实发生|命中注定|注定.{0,6}(?:恋人|夫妻|相爱))/u;
function presentText(value, memory, max = L.prose, required = false, options = {}) {
    const result = fictionalText(value, memory, max, required);
    const ok = part => !narrative.narrativeClaimsSharedHistory(part, { userName: memory?.userName }) && !PRESENT_CLAIM.test(part)
        && relationshipSafety.presentRelationshipAllows(part, memory, options);
    const kept = keepSentences(result, ok);
    // 整段命中：单条回响由调用处丢掉这一条（这里抛出只在逐条 try 里被接住，不会让整步失败）。
    if (!kept && required) throw fail('HISTORY', '这一段今生文字整段都写成了共同往事或超出当前关系，已跳过。');
    return kept;
}

function annotationText(value, memory) {
    const result = fictionalText(value, memory, L.prose, true);
    const ok = sentence => {
        if (!narrative.narrativeClaimsSharedHistory(sentence, { userName: memory?.userName })) return true;
        const explicitStory = /(?:前世|旧世|卷(?:宗|中|内|里)|虚构(?:人生|故事)|这(?:段|个)(?:故事|梦))/u.test(sentence);
        const currentLife = /(?:今生|此生|这一世|这辈子|现实|昨天|昨晚|去年|今年|今天)/u.test(sentence);
        return explicitStory && !currentLife;
    };
    const kept = keepSentences(result, ok);
    if (!kept) throw fail('HISTORY', '这条旁批整条都写成了今生往事，已跳过。');
    return kept;
}

function exactReference(raw, memory) {
    const requested = list(raw.sourceMemoryIds, 16);
    if (!requested.length || requested.some(id => typeof id !== 'string' || !/^M\d+$/u.test(id)))
        throw fail('SOURCE', '引子和真实记忆必须引用当前档案的 Mxxx 与完整 anchor。');
    const reference = evidence.normalizeExactMemoryReference(requested, clean(raw.sourceMemoryAnchor, 120, true), memory, 1);
    if (reference.sourceMemoryIds.length !== new Set(requested).size || !reference.sourceMemoryAnchor)
        throw fail('SOURCE', '记忆来源或完整 anchor 与当前档案不符，不能把番外写成真实往事。');
    return reference;
}

function sourceText(memory, ids) {
    return (memory?.memories || []).filter(item => ids.includes(item.id))
        .flatMap(item => [item.title, item.summary, ...(Array.isArray(item.anchors) ? item.anchors : [])])
        .filter(item => typeof item === 'string').join('\n');
}

export function emptyPastLives(memoryBank, context = null) {
    return { kind: PAST_LIVES_MODE, version: PAST_LIVES_VERSION,
        chatId: text.normalizeText(memoryBank?.chatId, 240), archiveRevision: text.normalizeText(memoryBank?.archiveRevision, 240),
        ownerKey: context ? contextApi.currentCharacterRuntimeKey(context) : '',
        characterName: ownerLabel(memoryBank), userName: text.normalizeText(memoryBank?.userName, 120),
        title: '前世今生', presentation: 'neutral', episodes: [], selectedId: '', selectedEntryId: '', selectedKey: '',
        view: 'library', pastLivesReadMask: '', pastLivesDrawn: false, pastLivesClosing: false };
}

export function normalizePastLivesOpening(value, memory, options = {}) {
    const raw = contract.pastLivesData(value, L.episodeChars);
    const title = fictionalText(raw.title, memory, L.title, true);
    const motif = fictionalText(raw.motif, memory, 300, true);
    const reference = exactReference(raw, memory);
    const missingText = raw.text == null || (typeof raw.text === 'string' && !raw.text.trim());
    try {
        return { title, text: fictionalText(raw.text, memory, L.prose, true), motif, ...reference };
    } catch (error) {
        if (options.allowPending === true && missingText && error?.code === 'RMT_PAST_LIVES_STRUCTURE') {
            return { title, motif, text: '', prosePending: true, ...reference };
        }
        throw error;
    }
}

export function normalizePastLivesPlan(value, memory) {
    const raw = contract.pastLivesData(value, L.episodeChars);
    return { title: fictionalText(raw.title, memory, L.title, true), opening: normalizePastLivesOpening(raw.opening, memory, { allowPending: true }),
        dossiers: list(raw.dossiers, L.dossiers).map((item, index) => ({ id: localId('D', index),
            title: fictionalText(item.title, memory, L.title, true), era: fictionalText(item.era, memory, 240),
            intent: fictionalText(item.intent, memory, 1200, true) })) };
}

export function normalizePastLivesDossier(value, memory, { id = 'D01', title = '' } = {}) {
    const raw = contract.pastLivesData(value, L.episodeChars);
    return { id, title: fictionalText(title || raw.title, memory, L.title, true), era: fictionalText(raw.era, memory, 240),
        synopsis: fictionalText(raw.synopsis, memory, L.prose, true),
        ...cg_visual.generatedCgSceneFields(raw), ...cg_targets.normalizeLocalCgSlots(raw),
        clues: list(raw.clues, L.clues).map((clue, index) => {
            // r84.171：认不出的线索类型按「旁记」收下，不让整步失败。
            const kind = contract.PAST_LIVES_CLUE_KINDS.includes(clue.kind) ? clue.kind : 'note';
            const speaker = ['char', 'user', 'narrator'].includes(clue.speaker) ? clue.speaker : 'narrator';
            return { id: localId(`${id}-C`, index), kind, speaker,
                title: fictionalText(clue.title, memory, L.title, true),
                text: fictionalText(clue.text, memory, L.prose, true, speaker),
                revealedText: fictionalText(clue.revealedText, memory, L.prose, kind === 'missing', speaker) };
        }) };
}

export function normalizePastLivesFinale(value, memory, dossiers, options = {}) {
    const raw = contract.pastLivesData(value, L.episodeChars);
    const clueIds = new Set(dossiers.flatMap(item => item.clues.map(clue => clue.id)));
    // r84.171：和续写时的 pastLivesProgressFinale 一样逐条处理：某一条回响或旁批不合规，只丢掉那一条，不让整步失败。
    // 今生真实记忆仍必须逐字出自所引 Mxxx（对不上就不收这一条，不会改标成别的）；未来回响仍须是假设语气。
    const echoes = [];
    for (const echo of list(raw.echoes, L.echoes)) {
        try {
            if (echo.kind === 'memory') {
                const reference = exactReference(echo, memory);
                const quote = clean(echo.text, L.prose, true);
                if (!sourceText(memory, reference.sourceMemoryIds).includes(quote)) continue;
                const source = memory.memories.find(item => item.id === reference.sourceMemoryIds[0]);
                echoes.push({ id: localId('E', echoes.length), kind: 'memory', title: text.normalizeText(source?.title || reference.sourceMemoryAnchor, L.title),
                    text: quote, reflection: presentText(echo.reflection, memory, 1800, false, options), ...reference });
                continue;
            }
            if (echo.kind !== 'possibility') continue;
            const prose = presentText(echo.text, memory, L.prose, true, options);
            if (!/(?:可能|也许|或许|如果|假如|愿|希望|未必|不一定)/u.test(prose)) continue;
            let title = '';
            try { title = presentText(echo.title, memory, L.title, true, options); } catch { title = '未来的一种可能'; }
            echoes.push({ id: localId('E', echoes.length), kind: 'possibility', title,
                text: prose, reflection: presentText(echo.reflection, memory, 1800, false, options), sourceMemoryIds: [], sourceMemoryAnchor: '' });
        } catch { /* 这一条不收，其余照常。 */ }
    }
    const annotations = [];
    for (const annotation of list(raw.annotations, L.annotations)) {
        try {
            // 引用了不存在的线索时，去掉那几个引用；一个都不剩就当作随时可读的旁批。
            const afterClueIds = [...new Set(list(annotation.afterClueIds, L.dossiers * L.clues))].filter(id => typeof id === 'string' && clueIds.has(id));
            annotations.push({ id: localId('A', annotations.length), afterClueIds, text: annotationText(annotation.text, memory) });
        } catch { /* 这一条不收，其余照常。 */ }
    }
    let closingText;
    try { closingText = presentText(raw.closing?.text, memory, L.prose, true, options); }
    catch { closingText = fictionalText(raw.closing?.text, memory, L.prose, true); }
    let signature = '';
    try { signature = presentText(raw.closing?.signature, memory, 240, false, options); } catch { signature = ''; }
    return { echoes, annotations, closing: { text: closingText, signature: signature || ownerLabel(memory) } };
}

export function normalizePastLivesEpisode(value, memory, { id = 'PL01', presentation = 'neutral', controlledEvidence = '' } = {}) {
    const raw = contract.pastLivesData(value, L.episodeChars);
    const opening = normalizePastLivesOpening(raw.opening, memory);
    const dossiers = list(raw.dossiers, L.dossiers).map((item, index) => normalizePastLivesDossier(item, memory, { id: localId('D', index) }));
    return { id, title: fictionalText(raw.title, memory, L.title, true), presentation: ['classical', 'modern', 'fantasy', 'neutral'].includes(presentation) ? presentation : 'neutral',
        fiction: true, opening, dossiers, ...normalizePastLivesFinale(raw, memory, dossiers, { controlledEvidence }) };
}

export function normalizePastLives(value, memory, options = {}) {
    const raw = contract.pastLivesData(value);
    if (raw.kind !== PAST_LIVES_MODE || raw.version !== PAST_LIVES_VERSION) throw fail('VERSION', '这份前世今生版本暂不可读取，原记录保持不变。');
    if ((raw.chatId && raw.chatId !== memory?.chatId) || (raw.archiveRevision && raw.archiveRevision !== memory?.archiveRevision))
        throw fail('SOURCE', '番外所属聊天或档案版本不一致，原记录保持不变。');
    const result = emptyPastLives(memory, options.context);
    // Re-normalizing an older readable volume must not rewrite its saved reading label.
    if ([ownerLabel(memory), memory?.characterName].includes(raw.characterName)) result.characterName = raw.characterName;
    result.ownerKey = result.ownerKey || clean(raw.ownerKey, 1200);
    result.presentation = ['classical', 'modern', 'fantasy', 'neutral'].includes(raw.presentation) ? raw.presentation : 'neutral';
    result.episodes = list(raw.episodes, L.episodes).map((episode, index) => normalizePastLivesEpisode(episode, memory,
        { id: localId('PL', index), presentation: episode.presentation || result.presentation, controlledEvidence: options.controlledEvidence || '' }));
    Object.assign(result, contract.pastLivesReadingState({ ...result, ...Object.fromEntries(['selectedId', 'selectedEntryId', 'selectedKey', 'view', 'pastLivesReadMask', 'pastLivesDrawn', 'pastLivesClosing'].map(key => [key, raw[key]])) }));
    return result;
}

// Reopening checks safe storage structure and identity, not today's interpretation
// of yesterday's writing. Generation alone revalidates current evidence/relationship.
export function readablePastLivesSession(value, memory) {
    try {
        const raw = contract.pastLivesStoredData(value);
        if (raw.chatId !== memory?.chatId || raw.archiveRevision !== memory?.archiveRevision
            || ![ownerLabel(memory), memory?.characterName].includes(raw.characterName) || raw.userName !== memory?.userName) return null;
        return value;
    } catch { return null; }
}

export function pastLivesHasSource(memory) {
    return (Array.isArray(memory?.memories) ? memory.memories : []).some(item =>
        /^M\d+$/u.test(String(item?.id || '')) && evidence.memoryEvidenceTerms(memory, [item.id]).length > 0);
}

function pastLivesProgressFinale(raw, memory, dossiers, options = {}) {
    const clueIds = new Set(dossiers.flatMap(item => item.clues.map(clue => clue.id)));
    const echoes = [];
    for (const [index, echo] of (raw.echoes || []).entries()) {
        try {
            let item;
            if (echo.kind === 'memory') {
                const reference = exactReference(echo, memory);
                const quote = clean(echo.text, L.prose, true);
                if (!sourceText(memory, reference.sourceMemoryIds).includes(quote)) continue;
                const source = memory.memories.find(entry => entry.id === reference.sourceMemoryIds[0]);
                item = { kind: 'memory', title: text.normalizeText(source?.title || reference.sourceMemoryAnchor, L.title),
                    text: quote, reflection: presentText(echo.reflection, memory, 1800, false, options), ...reference };
            } else if (echo.kind === 'possibility') {
                const prose = presentText(echo.text, memory, L.prose, true, options);
                if (!/(?:可能|也许|或许|如果|假如|愿|希望|未必|不一定)/u.test(prose)) continue;
                item = { kind: 'possibility', title: presentText(echo.title, memory, L.title, true, options), text: prose,
                    reflection: presentText(echo.reflection, memory, 1800, false, options), sourceMemoryIds: [], sourceMemoryAnchor: '' };
            }
            if (item) echoes.push({ id: localId('E', index), ...item });
        } catch {}
    }
    const annotations = [];
    for (const [index, annotation] of (raw.annotations || []).entries()) {
        try {
            const afterClueIds = [...new Set(list(annotation.afterClueIds, L.dossiers * L.clues))];
            if (afterClueIds.some(id => typeof id !== 'string' || !clueIds.has(id))) continue;
            annotations.push({ id: localId('A', index), afterClueIds, text: annotationText(annotation.text, memory) });
        } catch {}
    }
    let closing = null;
    if (raw.closing) {
        try { closing = normalizePastLivesFinale({ echoes: [], annotations: [], closing: raw.closing }, memory, dossiers, options).closing; } catch {}
    }
    return { echoes, annotations, closing };
}

export function projectPastLivesProgress({ segments = [], memoryBank, context = {}, previousSession = null, frozenInputs = {} }) {
    const segment = segments.find(item => /:past-lives-plan$/u.test(item.slot));
    if (!segment?.has('/opening') || !segment.has('/title')) return null;
    let plan;
    try { plan = normalizePastLivesPlan({ ...segment.value, dossiers: segment.items('/dossiers') }, memoryBank); } catch { return null; }
    const presentationContext = frozenInputs['presentation:pastLives'];
    const presentation = contract.pastLivesPresentation(presentationContext?.profile);
    const dossiers = [];
    const pending = [];
    for (const slot of plan.dossiers) {
        const part = segments.find(item => item.slot.endsWith(`:past-lives-dossier:${slot.id}`));
        try {
            if (!part?.has('/synopsis')) throw new Error('pending');
            const dossier = normalizePastLivesDossier({ ...part.value, clues: part.items('/clues') }, memoryBank, slot);
            if (!part.complete) dossier.progressPending = ['卷宗线索'];
            dossiers.push(dossier);
        } catch { pending.push(slot.title); }
    }
    const finale = segments.find(item => /:past-lives-finale$/u.test(item.slot));
    const controlledEvidence = presentationContext?.settingEvidence || '';
    const final = pastLivesProgressFinale({ echoes: finale?.items('/echoes') || [], annotations: finale?.items('/annotations') || [],
        closing: finale?.has('/closing') ? finale.value.closing : null }, memoryBank, dossiers, { controlledEvidence });
    const episode = { id: localId('PL', previousSession?.episodes?.length || 0), title: plan.title, presentation, fiction: true,
        opening: plan.opening, dossiers, ...final,
        progressPending: [...(!segment.complete ? ['卷宗计划'] : []), ...pending.map(title => `卷宗：${title}`), ...(!finale?.complete ? ['今生回响与落款'] : [])] };
    return { ...emptyPastLives(memoryBank, context), presentation, progressSettingEvidence: controlledEvidence, episodes: [episode], selectedId: episode.id,
        selectedEntryId: dossiers[0]?.id || '', view: 'draw', pastLivesDrawn: true };
}

// Partial reading is opt-in and never makes an incomplete draft a full result.
export function readablePastLivesProgressSession(value, memory) {
    try {
        const raw = contract.pastLivesData(value);
        if (raw.readableProgress?.version !== 1 || raw.readableProgress.complete !== false
            || raw.kind !== PAST_LIVES_MODE || raw.version !== PAST_LIVES_VERSION
            || raw.chatId !== memory?.chatId || raw.archiveRevision !== memory?.archiveRevision
            || ![ownerLabel(memory), memory?.characterName].includes(raw.characterName) || raw.userName !== memory?.userName
            || !Array.isArray(raw.episodes) || !raw.episodes.length) return null;
        for (const episode of raw.episodes) {
            if (!/^PL\d+$/u.test(episode.id) || episode.fiction !== true || !Array.isArray(episode.dossiers)
                || !Array.isArray(episode.echoes) || !Array.isArray(episode.annotations)) return null;
            fictionalText(episode.title, memory, L.title, true);
            normalizePastLivesOpening(episode.opening, memory);
            for (const dossier of episode.dossiers) {
                if (!/^D\d+$/u.test(dossier.id)) return null;
                normalizePastLivesDossier(dossier, memory, { id: dossier.id });
            }
            const checked = pastLivesProgressFinale(episode, memory, episode.dossiers, { controlledEvidence: raw.progressSettingEvidence || '' });
            if (checked.echoes.length !== episode.echoes.length || checked.annotations.length !== episode.annotations.length
                || (episode.closing && !checked.closing)) return null;
        }
        return value;
    } catch { return null; }
}

const GENERATION_RULES = `前世是明确标注的虚构番外，可写另一段人生；不能用它证明轮回、真实命理或今生已发生的事。不要求生日，不编四柱。
围绕角色与用户，遵循人物性格；不加前任或第三人恋爱婚姻。前世只是假设，今生关系不升级、不回填主聊天、不生成新的 Mxxx。
签、卷、线索和回响数量由内容决定；数组可为空，不凑最低数量或字数。不要用固定先凶后吉、永世相守代替人物选择。
模型只写 JSON 文本，禁止 HTML/CSS/JS/SVG、URL、事件、坐标、资源路径和执行指令。ID、界面与显字由本地代码控制。
所有前世场景写在 opening/dossiers 中。今生 memory 回响的 text 必须逐字摘录所引 Mxxx 的 title/summary/anchors；reflection 只写当下解读。possibility 明确写可能、愿望或假设。旁批和落款写对虚构卷宗的解读与当下选择，不夹带未证实的今生历史。`;

export function pastLivesPlanPrompt(context, memory, previous = null, presentation = 'neutral') {
    return `${prompts.promptSafetyBoundary(context, '前世今生 · 独立虚构番外', null, memory)}
${GENERATION_RULES}
从档案中一件可追溯的物品、话语或选择取引子，写新的入卷计划。表现风格：${presentation}。不复制已有篇章，不重写它们。
输出 {"title":"篇名","opening":{"title":"引子名","motif":"画面意象","text":"短签文/旧信引子，属于虚构开卷","sourceMemoryIds":["真实Mxxx"],"sourceMemoryAnchor":"逐字完整anchor"},"dossiers":[{"title":"卷名","era":"另一人生的时代背景","intent":"这卷要揭示的选择或疑点"}]}。
dossiers 仅有安全上限 ${L.dossiers}，不是目标数量；引子和每卷都有内容即可，不设最低字数。
UNTRUSTED_EXISTING_EPISODE_TITLES_JSON:
${JSON.stringify((previous?.episodes || []).map(item => ({ title: item.title, motif: item.opening.motif })))}
UNTRUSTED_CURRENT_ARCHIVE_JSON:
${prompts.promptArchiveSlice(memory, 48)}`;
}

function pendingPastLivesEpisode(session) {
    return (session?.episodes || []).find(item => item?.opening?.prosePending === true) || null;
}

async function fillPastLivesOpeningText(context, memory, origin, taskKey, opening, baseOptions, compatibility) {
    const prompt = `${prompts.promptSafetyBoundary(context, '前世今生 · 补引子正文', null, memory)}
${GENERATION_RULES}
只补这条引子缺少的 text。不得改 title、motif、sourceMemoryIds、sourceMemoryAnchor。
只输出 {"text":"虚构开卷正文"}。
FROZEN_OPENING_JSON:
${JSON.stringify({ title: opening.title, motif: opening.motif, sourceMemoryIds: opening.sourceMemoryIds, sourceMemoryAnchor: opening.sourceMemoryAnchor })}`;
    const text = await generation.requestValidatedSegment(prompt, '前世今生 · 正在补引子正文…',
        { ...baseOptions, taskKey: `${taskKey}:past-lives-opening-text`, maxTokens: 2400, recoveryCompatibility: compatibility(prompt) },
        raw => fictionalText(contract.pastLivesData(raw, L.episodeChars).text, memory, L.prose, true));
    const next = { ...opening, text };
    delete next.prosePending;
    return next;
}

async function writePastLivesRemainder(context, memory, origin, taskKey, { title, opening, slots, presentation, presentationContext, baseOptions, compatibility }) {
    const dossiers = [];
    for (const slot of slots) {
        const prompt = `${prompts.promptSafetyBoundary(context, '前世今生 · 虚构卷宗', null, memory)}
${GENERATION_RULES}
只完成 LOCAL_DOSSIER_PLAN 中这一卷，不写今生真实历史、不提前输出其他卷。用物证、证词、缺页或旁记展开角色与用户的选择；可少写，不凑线索数量。
输出 {"title":"卷名","era":"时代","synopsis":"这一卷的叙事正文","clues":[{"kind":"object|testimony|missing|note","title":"线索名","speaker":"char|user|narrator","text":"可见的线索正文","revealedText":"缺页点击后显示的完整字迹；其他类型可为空"}]}。
missing 必须有完整 revealedText，显字纯本地完成。每卷 clues 安全上限 ${L.clues}，不是配额。证词的 speaker 只表示虚构卷内的发言归属。
LOCAL_DOSSIER_PLAN:
${JSON.stringify({ opening, dossier: slot, presentation })}`;
        dossiers.push(await generation.requestValidatedSegment(prompt, `前世今生 · 正在展开「${slot.title}」…`,
            { ...baseOptions, taskKey: `${taskKey}:past-lives-dossier:${slot.id}`, maxTokens: 6800, recoveryCompatibility: compatibility(prompt) },
            raw => normalizePastLivesDossier(raw, memory, { id: slot.id, title: slot.title })));
    }
    const finalePrompt = `${prompts.promptSafetyBoundary(context, '前世今生 · 今生回响与落款', null, memory)}
${GENERATION_RULES}
根据已完成卷宗，写今生回响、逐步出现的旁批和落款。annotations.afterClueIds 只用卷内提供的真实本地线索 id；空数组表示入卷即有的初批，有线索的旁批应补充或修正解读。读者可以略过探索直接看结尾，不设答题或付费解锁。
输出 {"echoes":[{"kind":"memory|possibility","title":"可能的标题；memory标题由本地取真实记忆标题","text":"memory须逐字引用档案，possibility明确是可能","reflection":"当下解读，可为空","sourceMemoryIds":["仅memory需要真实Mxxx"],"sourceMemoryAnchor":"仅memory需要完整anchor"}],"annotations":[{"afterClueIds":["已有线索id"],"text":"对虚构故事的初解、补充或修正"}],"closing":{"text":"结尾与当下选择，不替双方定命","signature":"落款"}}。
echoes、annotations 可为空，安全上限各 ${L.echoes}/${L.annotations}；不用固定结果。落款应完整，但没有字数闯关。
UNTRUSTED_COMPLETED_STORY_JSON:
${JSON.stringify({ title, opening, dossiers })}
UNTRUSTED_CURRENT_ARCHIVE_JSON:
${prompts.promptArchiveSlice(memory, 48)}`;
    const finale = await generation.requestValidatedSegment(finalePrompt, '前世今生 · 正在写今生回响与落款…',
        { ...baseOptions, taskKey: `${taskKey}:past-lives-finale`, maxTokens: 6400, recoveryCompatibility: compatibility(finalePrompt) }, raw => normalizePastLivesFinale(raw, memory, dossiers, { controlledEvidence: presentationContext.settingEvidence || '' }));
    return { dossiers, ...finale };
}

function savePastLivesShell(previous, memory, context, presentation, plan, origin) {
    const episode = {
        id: localId('PL', previous?.episodes?.length || 0),
        title: plan.title,
        presentation,
        fiction: true,
        opening: plan.opening,
        dossiers: [],
        echoes: [],
        annotations: [],
        closing: { text: '', signature: ownerLabel(memory) },
        plannedDossiers: plan.dossiers,
    };
    const next = previous ? structuredClone(previous) : emptyPastLives(memory, context);
    next.presentation = presentation;
    next.episodes.push(episode);
    Object.assign(next, { selectedId: episode.id, selectedEntryId: '', selectedKey: '',
        view: 'draw', pastLivesReadMask: '', pastLivesDrawn: false, pastLivesClosing: false });
    requestCoordinator.noteSecondStepOffer(origin, {
        label: '引子正文', kind: 'past-lives-prose', mode: PAST_LIVES_MODE, pageId: PAST_LIVES_MODE,
    });
    return next;
}

export async function generatePastLivesWithRepair(context, memory, origin, taskKey, options = {}) {
    if (!pastLivesHasSource(memory)) throw fail('SOURCE', '当前档案还没有可追溯的物件、话语或选择；先整理真实记忆，再写这篇番外。');
    const previous = options.previousSession || (options.replaceExisting ? null : cache.loadSession(PAST_LIVES_MODE, { context, chatId: memory.chatId, memoryBank: memory, clone: true }));
    // Never treat an unreadable saved record as permission to overwrite it.
    if (!previous && options.replaceExisting !== true && cache.getCache(context)?.[PAST_LIVES_MODE])
        throw fail('VERSION', '已有番外暂不可安全读取，原记录保持不变；请先备份检查，不能直接覆盖。');
    if (previous && !readablePastLivesSession(previous, memory))
        throw fail('VERSION', '已有番外暂不可安全读取，原记录保持不变；不能直接覆盖。');
    const pendingEpisode = pendingPastLivesEpisode(previous);
    // r84.171：不再按篇数拒绝写新篇（原上限 48）。
    const assertContextRead = () => {
        contextApi.assertRuntimeLifecycleCurrent(origin.lifecycleEpoch);
        if (!context.__rmtArchiveTargetEntryId && !contextApi.isCurrentTaskOrigin(origin))
            throw new DOMException('Archive context changed before past-lives context capture', 'AbortError');
    };
    assertContextRead();
    const presentationContext = options.presentationContext || await generation.buildWorldPresentationContext(context, memory, PAST_LIVES_MODE, options.origin);
    assertContextRead();
    const presentation = contract.pastLivesPresentation(presentationContext.profile);
    const baseOptions = { context, contextEnvelope: presentationContext.contextEnvelope, origin, mode: PAST_LIVES_MODE, background: true };
    // r62 changes only the validator for this mode, not its r61 prompt recipe.
    // The exact legacy prompt authenticates replay; it is not a general hash bypass.
    const planPrompt = pastLivesPlanPrompt(context, memory, previous, presentation);
    const compatibility = prompt => ({ contract: 'past-lives-readable-r62', legacyPrompts: [prompt], legacyTemperatures: [0.75] });
    const shouldFillNow = options.secondStep === true || settings.getPluginSettings().autoSecondPass === true;
    let plan = null;
    let opening = pendingEpisode?.opening || null;
    if (pendingEpisode) {
        opening = await fillPastLivesOpeningText(context, memory, origin, taskKey, opening, baseOptions, compatibility);
    } else {
        plan = await generation.requestValidatedSegment(planPrompt, '前世今生 · 正在写下入卷引子…',
            { ...baseOptions, taskKey: `${taskKey}:past-lives-plan`, maxTokens: 4200, recoveryCompatibility: compatibility(planPrompt) }, raw => normalizePastLivesPlan(raw, memory));
        opening = plan.opening;
        if (opening.prosePending && !shouldFillNow) {
            const shell = savePastLivesShell(previous, memory, context, presentation, plan, origin);
            const covered = incremental.derivedExpansionMemoryIds(previous, memory);
            incremental.stampIncrementalCoverage(shell, previous, memory, 'mode', covered, 1);
            contract.pastLivesData(shell);
            return shell;
        }
        if (opening.prosePending) opening = await fillPastLivesOpeningText(context, memory, origin, taskKey, opening, baseOptions, compatibility);
    }
    const slots = pendingEpisode?.plannedDossiers || plan?.dossiers || [];
    const title = pendingEpisode?.title || plan.title;
    const episodeId = pendingEpisode?.id || localId('PL', previous?.episodes?.length || 0);
    const remainder = await writePastLivesRemainder(context, memory, origin, taskKey, {
        title, opening, slots, presentation, presentationContext, baseOptions, compatibility,
    });
    const episode = normalizePastLivesEpisode({ title, opening, ...remainder }, memory,
        { id: episodeId, presentation, controlledEvidence: presentationContext.settingEvidence || '' });
    requestCoordinator.noteSecondStepOffer(origin, null);
    const next = previous ? structuredClone(previous) : emptyPastLives(memory, context);
    next.presentation = presentation;
    const pendingIndex = next.episodes.findIndex(item => item?.id === episode.id && item?.opening?.prosePending === true);
    if (pendingIndex >= 0) next.episodes.splice(pendingIndex, 1, episode);
    else next.episodes.push(episode);
    // Reset only the new reader position; every previously saved episode remains intact.
    Object.assign(next, { selectedId: episode.id, selectedEntryId: episode.dossiers[0]?.id || '', selectedKey: '',
        view: 'draw', pastLivesReadMask: '', pastLivesDrawn: false, pastLivesClosing: false });
    const covered = incremental.derivedExpansionMemoryIds(previous, memory);
    incremental.stampIncrementalCoverage(next, previous, memory, 'mode', covered, 1);
    contract.pastLivesData(next);
    return next;
}

// 重构清单 C-3（r84.98）：把 core 层要用的函数登记到 core/modesBridge.js（core 不再 import 本文件）。
core_modesBridge.registerModesBridge({ readablePastLivesProgressSession, readablePastLivesSession });
// 重构清单 C-4（r84.104）：把生成层要用的函数登记到 generation/modesBridge.js（生成层不再 import 本文件）。
generation_modesBridge.registerGenerationModesBridge({ projectPastLivesProgress, generatePastLivesWithRepair, normalizePastLives });
