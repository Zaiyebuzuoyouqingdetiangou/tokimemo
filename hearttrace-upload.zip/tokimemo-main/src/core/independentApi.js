import * as manual_credentials from './manualCredentialStore.js';
import * as advanced_generation from './advancedGeneration.js';
import * as output_budget from './outputBudget.js';
// Heartbeat Memories independent API transport boundary.
// Manual providers are reached only through SillyTavern's fixed same-origin custom backend.
import * as core_constants from './constants.js';
import * as core_text from './text.js';

export const PROFILE_ONE_CLICK_UI_VERSION = '1.1.18';

const MANUAL_STATUS_ENDPOINT = '/api/backends/chat-completions/status';
const MANUAL_GENERATE_ENDPOINT = '/api/backends/chat-completions/generate';
const KNOWN_API_ENDPOINT_RE = /\/(?:chat\/completions|completions|responses|messages|embeddings|models)\/?$/i;

function apiError(message, code, status = 0) {
    const error = new Error(message);
    error.code = code;
    error.safeToDisplay = true;
    error.safeUserMessage = message;
    if (status) error.status = status;
    return error;
}

export function connectionManagerHasProfileSecrets(service) {
    if (typeof service?.sendRequest !== 'function') return false;
    try {
        const source = Function.prototype.toString.call(service.sendRequest);
        return /\bsecret_id\s*:/.test(source) && /profile\s*\[\s*['"]secret-id['"]\s*\]/.test(source);
    } catch {
        return false;
    }
}

export function connectionManagerSupportsRequestOverrides(service) {
    if (typeof service?.sendRequest !== 'function') return false;
    try {
        const source = Function.prototype.toString.call(service.sendRequest);
        const profileModelIndex = source.search(/\bmodel\s*:\s*profile(?:\.model|\s*\[\s*['"]model['"]\s*\])/);
        const overrideIndex = source.search(/\.\.\.\s*overridePayload\b/);
        return profileModelIndex >= 0 && overrideIndex > profileModelIndex;
    } catch {
        return false;
    }
}

export function assertConnectionManagerProfileSupport(service) {
    const validService = typeof service?.validateProfile === 'function' && typeof service?.sendRequest === 'function';
    if (validService && connectionManagerHasProfileSecrets(service) && connectionManagerSupportsRequestOverrides(service)) return true;
    throw apiError(
        `一键配置要求 ${PROFILE_ONE_CLICK_UI_VERSION} 的 Connection Manager 能力。当前页面未提供安全的 Profile Secret 与模型覆盖能力；本次没有发送请求。`,
        'RMT_PROFILE_CAPABILITY',
    );
}

function stripKnownEndpoint(url) {
    let pathname = String(url.pathname || '').replace(/\/+$/, '');
    for (let index = 0; index < 3; index += 1) {
        const next = pathname.replace(KNOWN_API_ENDPOINT_RE, '');
        if (next === pathname) break;
        pathname = next.replace(/\/+$/, '');
    }
    url.pathname = pathname || '/';
    url.hash = '';
    return url;
}

export function normalizeManualApiBaseUrl(value, { required = false } = {}) {
    const raw = String(value ?? '').trim();
    if (!raw) {
        if (required) throw apiError('请填写手动 API 地址。', 'RMT_MANUAL_API_URL');
        return '';
    }
    if (raw.length > 2000 || /[\u0000-\u001f\u007f]/.test(raw)) {
        throw apiError('手动 API 地址格式无效。', 'RMT_MANUAL_API_URL');
    }
    const explicitScheme = raw.match(/^([a-z][a-z0-9+.-]*):(.*)$/i);
    const looksLikeHostPort = !!explicitScheme
        && /^\d+(?:[/?#]|$)/.test(explicitScheme[2])
        && /^(?:[a-z0-9](?:[a-z0-9.-]{0,251}[a-z0-9])?)$/i.test(explicitScheme[1]);
    if (explicitScheme && !/^https?:\/\//i.test(raw) && !looksLikeHostPort) {
        throw apiError('手动 API 地址必须是无内嵌账号密码的 HTTP(S) 地址。', 'RMT_MANUAL_API_URL');
    }
    const hostPart = raw.split('/')[0];
    const localHost = /^(?:localhost|127(?:\.\d{1,3}){3}|\[[0-9a-f:]+\])(?::\d+)?$/i.test(hostPart);
    const withScheme = /^https?:\/\//i.test(raw) ? raw : `${localHost ? 'http' : 'https'}://${raw}`;
    let parsed;
    try {
        parsed = new URL(withScheme);
    } catch {
        throw apiError('手动 API 地址格式无效。', 'RMT_MANUAL_API_URL');
    }
    if (!['http:', 'https:'].includes(parsed.protocol) || !parsed.hostname || parsed.username || parsed.password) {
        throw apiError('手动 API 地址必须是无内嵌账号密码的 HTTP(S) 地址。', 'RMT_MANUAL_API_URL');
    }
    const credentialQueryNames = new Set([
        'apikey', 'key', 'token', 'accesstoken', 'refreshtoken', 'idtoken', 'sessiontoken',
        'secret', 'clientsecret', 'apisecret', 'authorization', 'auth', 'xapikey', 'bearertoken',
        'password', 'passwd', 'proxypassword', 'credential', 'credentials', 'signature', 'sig',
        'accesskey', 'accesskeyid', 'secretkey', 'xamzcredential', 'xamzsecuritytoken', 'xamzsignature',
        'apitoken', 'authtoken', 'oauthtoken', 'clientpassword', 'clientid', 'privatekey',
        'subscriptionkey', 'awsaccesskeyid', 'googleaccessid', 'licensekey', 'servicekey',
    ]);
    for (const [name, value] of parsed.searchParams.entries()) {
        const normalizedName = String(name || '').toLowerCase().replace(/[^a-z0-9]/g, '');
        const credentialLike = credentialQueryNames.has(normalizedName)
            || /(?:token|secret|password|passwd|credential|signature|authorization|bearer)/.test(normalizedName)
            || /^(?:api|access|auth|client|private|public|secret|xamz).*(?:key|keyid)$/.test(normalizedName);
        const normalizedValue = String(value || '').trim();
        const credentialValue = /^(?:bearer\s+|(?:sk|rk|pk|key|token|secret)[-_])[a-z0-9._~+\/-]{6,}$/i.test(normalizedValue)
            || /^eyJ[a-z0-9_-]{8,}\.[a-z0-9_-]{8,}(?:\.[a-z0-9_-]{8,})?$/i.test(normalizedValue)
            || /^AKIA[A-Z0-9]{12,}$/i.test(normalizedValue);
        if (credentialLike || credentialValue) {
            throw apiError('手动 API 地址不能在查询参数中携带 Key、Token、Secret 或账号凭据；请使用独立的 API Key 输入框。', 'RMT_MANUAL_API_URL');
        }
    }
    stripKnownEndpoint(parsed);
    const normalized = parsed.toString().replace(/\/(?=\?|$)/, '');
    if (normalized.length > 2000) throw apiError('手动 API 地址过长。', 'RMT_MANUAL_API_URL');
    return normalized;
}

export function manualApiHeadersJson(apiKey) {
    const key = core_text.normalizeText(apiKey, 4000);
    return JSON.stringify(key ? { Authorization: `Bearer ${key}` } : {});
}

export function apiConfigurationFingerprint(settings) {
    const mode = settings?.apiConnectionMode === 'manual' ? 'manual' : 'profile';
    if (mode === 'manual') {
        let base = '';
        try { base = normalizeManualApiBaseUrl(settings?.manualApiBaseUrl); } catch { base = 'invalid'; }
        const key = core_text.normalizeText(settings?.manualApiKey, 4000);
        return JSON.stringify([
            mode,
            base,
            core_text.normalizeText(settings?.manualApiModel, 240),
            key ? `${key.length}:${core_text.hashString(key)}` : '',
            Number(settings?.maxTokens) || 0,
            Number(settings?.temperature) || 0,
            settings?.manualApiStreaming === true,
            ...(!key && settings?.manualApiSecretRef ? [settings.manualApiSecretRef] : []),
            ...(advanced_generation.advancedFingerprint(settings) ? [advanced_generation.advancedFingerprint(settings)] : []),
        ]);
    }
    return JSON.stringify([
        mode,
        core_text.normalizeText(settings?.connectionProfileId, 160),
        core_text.normalizeText(settings?.modelOverride, 240),
        Number(settings?.maxTokens) || 0,
        Number(settings?.temperature) || 0,
        ...(advanced_generation.advancedFingerprint(settings) ? [advanced_generation.advancedFingerprint(settings)] : []),
    ]);
}

export function manualModelCacheKey(settings) {
    let base = '';
    try { base = normalizeManualApiBaseUrl(settings?.manualApiBaseUrl); } catch { base = 'invalid'; }
    const key = core_text.normalizeText(settings?.manualApiKey, 4000);
    return `manual:${core_text.hashString(`${base}|${key.length}:${core_text.hashString(key)}${!key && settings?.manualApiSecretRef ? `|${settings.manualApiSecretRef}` : ''}`)}`;
}

function requestHeaders(context) {
    let headers = {};
    try { headers = typeof context?.getRequestHeaders === 'function' ? context.getRequestHeaders() : {}; } catch {}
    return { ...(headers && typeof headers === 'object' ? headers : {}), 'Content-Type': 'application/json' };
}

async function boundedResponseText(response, maxBytes = core_constants.MAX_MANUAL_API_RESPONSE_BYTES) {
    const contentLength = Number(response?.headers?.get?.('content-length'));
    if (Number.isFinite(contentLength) && contentLength > maxBytes) {
        throw apiError('模型服务返回内容过大，已停止读取。', 'RMT_MANUAL_RESPONSE_TOO_LARGE', Number(response?.status) || 0);
    }
    const reader = response?.body?.getReader?.();
    if (!reader) {
        const text = await response.text();
        const size = typeof TextEncoder === 'function' ? new TextEncoder().encode(text).byteLength : text.length * 3;
        if (size > maxBytes) throw apiError('模型服务返回内容过大，已停止读取。', 'RMT_MANUAL_RESPONSE_TOO_LARGE', Number(response?.status) || 0);
        return text;
    }
    const decoder = new TextDecoder();
    let total = 0;
    let text = '';
    while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        total += value?.byteLength || 0;
        if (total > maxBytes) {
            try { await reader.cancel(); } catch {}
            throw apiError('模型服务返回内容过大，已停止读取。', 'RMT_MANUAL_RESPONSE_TOO_LARGE', Number(response?.status) || 0);
        }
        text += decoder.decode(value, { stream: true });
    }
    return text + decoder.decode();
}

async function boundedJson(response, maxBytes) {
    const contentType = String(response?.headers?.get?.('content-type') || '').toLowerCase();
    if (contentType.includes('text/html')) {
        try { await response?.body?.cancel?.(); } catch {}
        throw apiError('模型服务返回了 HTML 页面，响应正文已隐藏。', 'RMT_RESPONSE_HTML', Number(response?.status) || 0);
    }
    const text = await boundedResponseText(response, maxBytes);
    if (looksLikeHtmlResponse(text)) {
        throw apiError('模型服务返回了 HTML 页面，响应正文已隐藏。', 'RMT_RESPONSE_HTML', Number(response?.status) || 0);
    }
    try {
        return JSON.parse(text);
    } catch {
        throw apiError('模型服务没有返回可解析的 JSON。', 'RMT_MANUAL_INVALID_JSON', Number(response?.status) || 0);
    }
}

export function looksLikeHtmlResponse(value) {
    const body = String(value ?? '').replace(/^\uFEFF/, '').trimStart();
    // A complete JSON document is data, including any quoted markup in its strings.
    // Only a whole-document parse grants this exception; never extract a JSON island
    // from an HTML error page here. No response text is rendered or executed.
    const jsonBody = body.replace(/^```(?:json)?\s*\n?([\s\S]*?)\n?```\s*$/i, '$1').trim();
    if (jsonBody.startsWith('{') || jsonBody.startsWith('[')) {
        try { const parsed = JSON.parse(jsonBody); if (parsed && typeof parsed === 'object') return false; } catch {}
    }
    // Proxies commonly prepend comments/meta tags or wrap a JSON-looking fragment in an error
    // page. Detect markup anywhere near the response head, before JSON extraction can mistake an
    // embedded object for the provider payload. The body is never included in the public error.
    return /<!--[\s\S]*?-->/i.test(body)
        || /<\s*!doctype\b/i.test(body)
        || /<\s*\/?\s*[a-z][a-z0-9:-]*(?:\s+[^<>]*?)?\s*\/?\s*>/i.test(body);
}

export async function readBoundedJsonResponse(response, maxBytes = core_constants.MAX_MANUAL_API_RESPONSE_BYTES) {
    return await boundedJson(response, maxBytes);
}

function httpFailure(response) {
    const code = Number(response?.status) || 0;
    const html = /text\/html/i.test(String(response?.headers?.get?.('content-type') || ''));
    const error = apiError(
        code ? `手动 API 请求失败（HTTP ${code}）。请检查手动配置与服务状态。` : '手动 API 请求失败。请检查手动配置与服务状态。',
        html ? 'RMT_RESPONSE_HTML' : 'RMT_MANUAL_HTTP',
        code,
    );
    const retryAfter = String(response?.headers?.get?.('retry-after') || '').slice(0, 100).trim();
    const delay = /^\d+(?:\.\d+)?$/.test(retryAfter) ? Number(retryAfter) * 1000 : Date.parse(retryAfter) - Date.now();
    if (code === 429 && Number.isFinite(delay) && delay > 0) error.retryAfterMs = Math.min(86400000, Math.ceil(delay));
    return error;
}

function providerEnvelopeFailure(payload, manual = true) {
    // Read only bounded error metadata. Never propagate a provider message/body as a cause.
    const seen = new Set();
    let status = 0, typeStatus = 0, quota = false;
    const visit = (node, depth) => {
        if (!node || typeof node !== 'object' || seen.has(node) || depth > 4 || seen.size >= 24) return;
        seen.add(node);
        for (const key of ['status', 'statusCode', 'code', 'type']) {
            const descriptor = Object.getOwnPropertyDescriptor(node, key);
            const value = descriptor && 'value' in descriptor ? descriptor.value : null;
            if (!['string', 'number'].includes(typeof value)) continue;
            const token = String(value).slice(0, 100).toLowerCase();
            const numeric = Number(token);
            if (!status && Number.isInteger(numeric) && numeric >= 400 && numeric <= 599) status = numeric;
            if (['insufficient_quota', 'billing_hard_limit_reached', 'credit_balance_too_low'].includes(token)) quota = true;
            if (['rate_limit_error', 'rate_limit_exceeded', 'resource_exhausted'].includes(token)) typeStatus = 429;
            else if (!typeStatus && ['invalid_api_key', 'authentication_error', 'unauthorized', 'unauthenticated'].includes(token)) typeStatus = 401;
            else if (!typeStatus && ['permission_denied', 'permission_error', 'forbidden'].includes(token)) typeStatus = 403;
        }
        for (const key of ['error', 'errors', 'data', 'result', 'response', 'body', 'details']) {
            const descriptor = Object.getOwnPropertyDescriptor(node, key);
            if (descriptor && 'value' in descriptor) visit(descriptor.value, depth + 1);
        }
        if (Array.isArray(node)) for (let i = 0; i < Math.min(4, node.length); i++) {
            const descriptor = Object.getOwnPropertyDescriptor(node, String(i));
            if (descriptor && 'value' in descriptor) visit(descriptor.value, depth + 1);
        }
    };
    visit(payload, 0);
    if (quota && (!status || status === 429)) {
        const error = apiError('服务商报告额度不足，请检查该账号额度。', 'RMT_CONNECTION_QUOTA', status);
        error.retryable = false;
        return error;
    }
    if (status || typeStatus) return apiError('模型服务返回错误状态；详情已隐藏。', 'RMT_PROVIDER_STATUS', status || typeStatus);
    const error = apiError('专用连接返回了错误状态，请检查服务配置后重试。', manual ? 'RMT_MANUAL_PROVIDER_ERROR' : 'RMT_CONNECTION_FAILED');
    error.retryable = false;
    return error;
}

export function assertManualApiCredentialTransport(baseUrl, apiKey) {
    const normalized = normalizeManualApiBaseUrl(baseUrl, { required: true });
    const parsed = new URL(normalized);
    const loopback = /^(?:localhost|127(?:\.\d{1,3}){3}|\[?::1\]?)$/i.test(parsed.hostname);
    if (parsed.protocol !== 'https:' && !loopback) {
        throw apiError('手动 API 地址必须使用 HTTPS；仅本机 localhost/127.0.0.1/::1 可使用 HTTP。', 'RMT_MANUAL_API_TRANSPORT');
    }
    return normalized;
}

function modelId(value) {
    if (typeof value === 'string') return core_text.normalizeText(value, 240);
    if (!value || typeof value !== 'object') return '';
    return core_text.normalizeText(value.id ?? value.model ?? value.model_id ?? value.name ?? value.slug, 240);
}

export function extractManualModelIds(payload) {
    const lists = [];
    const visit = (value, depth = 0) => {
        if (depth > 3 || value == null) return;
        if (Array.isArray(value)) {
            lists.push(value);
            return;
        }
        if (typeof value !== 'object') return;
        for (const key of ['data', 'models', 'items', 'result', 'results']) {
            if (Object.prototype.hasOwnProperty.call(value, key)) visit(value[key], depth + 1);
        }
    };
    visit(payload);
    return [...new Set(lists.flatMap(list => list.map(modelId)).filter(Boolean))].slice(0, 2000);
}

function responseField(value, key) {
    if (!value || typeof value !== 'object') return undefined;
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    return descriptor && 'value' in descriptor ? descriptor.value : undefined;
}

function hasResponseField(value, key) {
    const descriptor = value && typeof value === 'object' ? Object.getOwnPropertyDescriptor(value, key) : null;
    return !!descriptor && 'value' in descriptor;
}

function nonFinalContent(value) {
    const type = responseField(value, 'type');
    const role = responseField(value, 'role');
    return (typeof type === 'string' && /(?:reasoning|thought|thinking|analysis|tool|function|refusal|error|_call(?:_output)?$)/i.test(type))
        || responseField(value, 'thought') === true
        || (typeof role === 'string' && !['assistant', 'model'].includes(role))
        || !!responseField(value, 'refusal');
}

// null means an unsupported shape; an empty string means a recognized but empty
// final channel. Do not promote reasoning/tool text when the final channel is empty.
function finalContentText(value, depth = 0) {
    if (depth > 6) return null;
    if (value == null) return '';
    if (typeof value === 'string') return value;
    if (Array.isArray(value)) {
        if (value.length > 4096) return null;
        const parts = [];
        for (let i = 0; i < value.length; i += 1) {
            const text = finalContentText(responseField(value, String(i)), depth + 1);
            // Responses may interleave visible messages with non-text output.
            // Unknown blocks never contribute text and are not serialized.
            if (text !== null) parts.push(text);
        }
        return parts.join('');
    }
    if (typeof value !== 'object') return null;
    if (nonFinalContent(value)) return '';
    const text = responseField(value, 'text');
    if (typeof text === 'string') return text;
    if (typeof responseField(text, 'value') === 'string') return responseField(text, 'value');
    if (typeof responseField(value, 'output_text') === 'string') return responseField(value, 'output_text');
    if (hasResponseField(value, 'content')) return finalContentText(responseField(value, 'content'), depth + 1);
    if (['assistant', 'model'].includes(responseField(value, 'role'))
        || ['reasoning', 'reasoning_content', 'thinking'].some(key => hasResponseField(value, key))) return '';
    return null;
}

function visibleContentText(value, depth = 0) { return finalContentText(value, depth) || ''; }

function finalResponseSelection(payload, depth = 0, seen = new Set()) {
    const unsupported = { shape: 'unsupported', text: null };
    if (depth > 4) return unsupported;
    if (typeof payload === 'string') return { shape: 'text', text: payload };
    if (payload == null) return { shape: 'empty', text: '' };
    if (typeof payload !== 'object' || Array.isArray(payload) || seen.has(payload)) return unsupported;
    seen.add(payload);
    const selected = (shape, value) => {
        const text = finalContentText(value);
        return text === null ? unsupported : { shape, text };
    };
    if (nonFinalContent(payload)) return { shape: 'content', text: '' };
    const choices = responseField(payload, 'choices');
    if (Array.isArray(choices)) {
        const choice = choices.find(item => responseField(item, 'index') === 0)
            || choices.find(item => item && responseField(item, 'index') == null);
        if (!choice || ['tool_calls', 'function_call', 'content_filter'].includes(responseField(choice, 'finish_reason'))) {
            return { shape: 'choices', text: '' };
        }
        for (const key of ['message', 'delta']) {
            if (hasResponseField(choice, key)) return selected('choices', responseField(choice, key));
        }
        return selected('choices', responseField(choice, 'text'));
    }
    for (const key of ['content', 'output_text', 'output', 'message']) {
        if (!hasResponseField(payload, key)) continue;
        const value = responseField(payload, key);
        // A wrapper's generic message string is not an assistant message.
        if (key === 'message' && (!value || typeof value !== 'object')) continue;
        return selected(key, value);
    }
    const candidates = responseField(payload, 'candidates');
    if (Array.isArray(candidates)) {
        const candidate = responseField(candidates, '0');
        const parts = responseField(responseField(candidate, 'content'), 'parts');
        return selected('candidates', parts ?? responseField(candidate, 'output'));
    }
    // Only known response containers are traversed. Never scan arbitrary keys or
    // serialize an API envelope/parsed application object into generated JSON.
    let hadWrapper = false;
    for (const key of ['data', 'result', 'response', 'body']) {
        if (!hasResponseField(payload, key)) continue;
        hadWrapper = true;
        const value = responseField(payload, key);
        if (key === 'response' && typeof value === 'string') return selected('wrapped', value);
        if (!value || typeof value !== 'object') continue;
        const nested = finalResponseSelection(value, depth + 1, seen);
        if (nested.text !== null) return { shape: 'wrapped', text: nested.text };
    }
    if (hadWrapper) return unsupported;
    if (hasResponseField(payload, 'text')) return selected('text_fallback', responseField(payload, 'text'));
    if (['reasoning', 'reasoning_content', 'thinking'].some(key => hasResponseField(payload, key))) {
        return { shape: 'empty', text: '' };
    }
    return unsupported;
}

export function extractIndependentResponseContent(payload) {
    const selected = finalResponseSelection(payload);
    return selected.text === null ? payload : selected.text;
}

const SUMMARY_FINISH_REASONS = new Set(['stop', 'end_turn', 'stop_sequence', 'length', 'max_tokens',
    'content_filter', 'tool_calls', 'function_call', 'completed', 'incomplete', 'done']);

// Pure diagnostics: fixed labels and bounded counts only. Provider text, keys,
// identifiers and error messages are never returned, even for unsupported shapes.
export function responseShapeSummary(payload) {
    const summary = { shape: 'unsupported', finalChars: 0, reasoningChars: 0, finishReason: 'none' };
    try {
        const selected = finalResponseSelection(payload);
        summary.shape = payloadHasProviderError(payload) ? 'error' : selected.shape;
        summary.finalChars = summary.shape === 'error' ? 0 : Math.min(core_constants.MAX_GENERATION_OUTPUT_CHARS, selected.text?.length || 0);
        const seen = new Set();
        const addReasoning = value => {
            if (typeof value === 'string') summary.reasoningChars = Math.min(core_constants.MAX_GENERATION_OUTPUT_CHARS, summary.reasoningChars + value.length);
        };
        const visit = (node, depth = 0, reasoning = false) => {
            if (depth > 8 || seen.size >= 256) return;
            if (typeof node === 'string') { if (reasoning) addReasoning(node); return; }
            if (!node || typeof node !== 'object' || seen.has(node)) return;
            seen.add(node);
            if (Array.isArray(node)) {
                for (let i = 0; i < Math.min(node.length, 256); i += 1) visit(responseField(node, String(i)), depth + 1, reasoning);
                return;
            }
            const type = responseField(node, 'type');
            reasoning = reasoning || responseField(node, 'thought') === true
                || (typeof type === 'string' && /(?:reasoning|thought|thinking|analysis)/i.test(type));
            for (const key of ['reasoning', 'reasoning_content', 'thinking']) visit(responseField(node, key), depth + 1, true);
            for (const key of ['finish_reason', 'finishReason', 'stop_reason', 'status']) {
                const raw = responseField(node, key);
                if (typeof raw !== 'string' || (key === 'status' && !['completed', 'incomplete'].includes(raw))) continue;
                if (summary.finishReason === 'none') summary.finishReason = SUMMARY_FINISH_REASONS.has(raw.toLowerCase()) ? raw.toLowerCase() : 'unknown';
            }
            for (const key of ['choices', 'message', 'delta', 'content', 'output', 'candidates', 'parts', 'data', 'result', 'response', 'body']) {
                visit(responseField(node, key), depth + 1, reasoning);
            }
            if (reasoning) for (const key of ['text', 'value', 'output_text', 'summary']) visit(responseField(node, key), depth + 1, true);
        };
        visit(payload);
        const completion = manualStreamCompletionInfo(payload);
        if (completion) { summary.finishReason = SUMMARY_FINISH_REASONS.has(completion.finishReason) ? completion.finishReason : 'unknown';
            summary.reasoningChars = Math.max(summary.reasoningChars, completion.reasoningChars || 0); }
    } catch { return { shape: 'unsupported', finalChars: 0, reasoningChars: 0, finishReason: 'none' }; }
    return summary;
}

export function payloadHasProviderError(payload) {
    const seen = new Set();
    const presentError = value => value === true
        || (Number.isFinite(Number(value)) && Number(value) >= 400 && Number(value) <= 599)
        || (typeof value === 'string' && !!value.trim())
        || (Array.isArray(value) && value.length > 0)
        || (!!value && typeof value === 'object');
    const visit = (node, depth) => {
        if (!node || typeof node !== 'object' || seen.has(node) || depth > 4) return false;
        seen.add(node);
        if (presentError(node.error) || presentError(node.errors) || node.ok === false || node.success === false) return true;
        for (const value of [node.status, node.statusCode, node.code]) {
            const numeric = Number(value);
            if (Number.isFinite(numeric) && numeric >= 400 && numeric <= 599) return true;
            const label = String(value || '').trim().toLowerCase();
            if (['error', 'failed', 'failure', 'denied', 'unauthorized', 'forbidden'].includes(label)) return true;
        }
        const message = String(node.message || node.detail || '').trim();
        if (message && /(?:unauthori[sz]ed|forbidden|authentication\s+failed|invalid\s+(?:api\s*)?key|access\s+denied|quota\s+exceeded)/i.test(message)) return true;
        return ['data', 'result', 'response', 'body', 'details'].some(key => visit(node[key], depth + 1));
    };
    return visit(payload, 0);
}

export function assertIndependentResponsePayload(payload) {
    if (payloadHasProviderError(payload)) {
        throw providerEnvelopeFailure(payload, false);
    }
    const content = extractIndependentResponseContent(payload);
    if (typeof content !== 'string') {
        const error = apiError('连接返回的正文结构暂不支持，尚未取得可解析的最终正文；旧内容未改变。请导出诊断报告检查返回形态。', 'RMT_RESPONSE_FORMAT');
        error.retryable = false;
        error.retryableJson = false;
        throw error;
    }
    if (typeof content === 'string' && looksLikeHtmlResponse(content)) {
        const error = apiError('专用连接返回了 HTML 页面；响应正文已隐藏。', 'RMT_RESPONSE_HTML');
        error.retryable = false;
        throw error;
    }
    if (!content.trim()) throw emptyFinalFailure(responseShapeSummary(payload));
    return content;
}

// Transport completion is local authority, not model JSON. A provider cannot forge it
// by emitting fields named complete/finishReason. Keep partial text out of Error objects.
const manualStreamCompletions = new WeakMap();
const STREAM_FINISH_REASONS = new Set(['stop', 'end_turn', 'stop_sequence', 'length', 'max_tokens', 'content_filter', 'tool_calls', 'function_call']);
const COMPLETE_STREAM_REASONS = new Set(['stop', 'end_turn', 'stop_sequence', 'done']);

function streamFinishReason(value) {
    if (value == null || value === '') return '';
    return typeof value === 'string' && STREAM_FINISH_REASONS.has(value) ? value : 'unknown';
}

function streamCompletion(content, finishReason, interrupted = false, reasoningChars = 0, publicStream = false) {
    const result = Object.freeze({ content });
    manualStreamCompletions.set(result, Object.freeze({
        complete: !interrupted && COMPLETE_STREAM_REASONS.has(finishReason),
        finishReason, interrupted: interrupted === true, reasoningChars: Math.max(0, Math.min(core_constants.MAX_GENERATION_OUTPUT_CHARS, Number(reasoningChars) || 0)), publicStream,
    }));
    return result;
}

export function manualStreamCompletionInfo(result) {
    return result && typeof result === 'object' ? manualStreamCompletions.get(result) || null : null;
}

// Call inside the JSON-parser/recovery try block, after the normal origin/config guard.
// Its catch can pass the separately held content to recordRecoveryTruncation unchanged.
export function assertManualStreamComplete(result) {
    const completion = manualStreamCompletionInfo(result);
    const rawFinish = completion ? '' : responseShapeSummary(result).finishReason;
    if (['length', 'max_tokens', 'incomplete'].includes(rawFinish)) {
        const error = apiError('渠道明确报告输出未完成；原成功分段保留，不会自动请求。', 'RMT_JSON_TRUNCATED');
        error.retryable = false; error.retryableJson = false; throw error;
    }
    if (completion && !completion.complete && !(completion.publicStream && !completion.interrupted && completion.finishReason === 'unknown')) {
        const error = apiError('流式正文尚未完整结束；已停止本段，不会自动重发请求。可保留草稿后显式继续。', 'RMT_JSON_TRUNCATED');
        error.retryable = false;
        error.retryableJson = false;
        throw error;
    }
    return true;
}

const transportFailures = new WeakMap();
export function transportFailureSummary(error) { return transportFailures.get(error) || null; }
function emptyFinalFailure(summary) {
    const error = apiError(summary.reasoningChars ? '本次响应只有推理字段，没有最终正文；未采用推理内容，也没有自动重试。请按渠道文档调整推理参数或流式设置后再点击。' : '本次响应没有最终正文；未自动重试，请检查渠道状态和参数。',
        summary.reasoningChars ? 'RMT_JSON_EMPTY_FINAL_WITH_REASONING' : 'RMT_JSON_EMPTY_FINAL');
    error.retryable = false; error.retryableJson = false;
    transportFailures.set(error, { shape: summary.shape || 'empty', finalChars: 0,
        reasoningChars: Math.min(core_constants.MAX_GENERATION_OUTPUT_CHARS, summary.reasoningChars || 0), finishReason: summary.finishReason || 'unknown' });
    return error;
}

// Public ConnectionManager streaming contract: cumulative text + separate reasoning.
// Its API does not expose the provider finish reason; do not manufacture a stop code.
export async function readProfileCompletion(result, { signal = null } = {}) {
    if (typeof result !== 'function') return result;
    const iterator = result();
    if (!iterator || typeof iterator.next !== 'function') throw apiError('连接未提供可读取的流式结果。', 'RMT_RESPONSE_FORMAT');
    let content = '', reasoningChars = 0, interrupted = false, rejectAbort;
    const abort = new Promise((_,reject) => { rejectAbort = reject; });
    const onAbort = () => { rejectAbort(streamAbortReason(signal)); };
    signal?.addEventListener?.('abort', onAbort, { once:true });
    try {
        if (signal?.aborted) throw streamAbortReason(signal);
        for (;;) {
            const item = await Promise.race([iterator.next(), abort]);
            if (signal?.aborted) throw streamAbortReason(signal);
            if (item.done) break;
            const next = responseField(item.value, 'text');
            if (typeof next !== 'string' || !next.startsWith(content)) throw apiError('连接的流式正文结构异常。', 'RMT_RESPONSE_FORMAT');
            const reasoning = responseField(responseField(item.value, 'state'), 'reasoning');
            reasoningChars = Math.max(reasoningChars, typeof reasoning === 'string' ? reasoning.length : 0);
            if (next.length > core_constants.MAX_GENERATION_OUTPUT_CHARS
                || new TextEncoder().encode(next).byteLength > core_constants.MAX_MANUAL_API_RESPONSE_BYTES
                || reasoningChars > core_constants.MAX_MANUAL_API_RESPONSE_BYTES) throw apiError('流式响应超过安全范围。', 'RMT_MANUAL_RESPONSE_TOO_LARGE');
            content = next;
        }
    } catch (error) {
        if (signal?.aborted || error?.name === 'AbortError') throw streamAbortReason(signal);
        if (error?.code === 'RMT_MANUAL_RESPONSE_TOO_LARGE' || error?.code === 'RMT_RESPONSE_FORMAT') throw error;
        if (!content.trim()) throw error;
        interrupted = true;
    } finally {
        signal?.removeEventListener?.('abort', onAbort);
        try { void iterator.return?.()?.catch?.(() => {}); } catch {}
    }
    if (!content.trim()) throw emptyFinalFailure({ reasoningChars });
    return streamCompletion(content, 'unknown', interrupted, reasoningChars, true);
}

function streamReadError(code = 'RMT_MANUAL_INVALID_JSON') {
    const error = apiError(code === 'RMT_MANUAL_PROVIDER_ERROR'
        ? '手动 API 在流式响应中返回错误；详情已隐藏，本段不会自动重发。'
        : '流式响应没有完整结束或格式无效；详情已隐藏，本段不会自动重发。', code);
    error.retryable = false;
    error.retryableJson = false;
    return error;
}

function streamAbortReason(signal) {
    return signal?.reason instanceof Error ? signal.reason : new DOMException('Aborted', 'AbortError');
}

async function readManualApiStream(response, options = {}) {
    const maxBytes = core_constants.MAX_MANUAL_API_RESPONSE_BYTES;
    const declaredBytes = Number(response?.headers?.get?.('content-length'));
    if (Number.isFinite(declaredBytes) && declaredBytes > maxBytes) {
        try { void response?.body?.cancel?.()?.catch?.(() => {}); } catch {}
        throw apiError('模型服务返回内容过大，已停止读取。', 'RMT_MANUAL_RESPONSE_TOO_LARGE');
    }
    const reader = response?.body?.getReader?.();
    if (!reader) throw streamReadError();
    const signal = options.signal || null;
    const decoder = new TextDecoder('utf-8');
    let bytes = 0, content = '', line = '', eventType = '', dataLines = [], reasoningChars = 0, protocol = '';
    const blockKinds = new Map();
    let responseOutputIndex = null;
    const chooseProtocol = kind => { if (protocol && protocol !== kind) throw streamReadError(); protocol = kind; };
    const countReasoning = payload => { reasoningChars = Math.min(core_constants.MAX_GENERATION_OUTPUT_CHARS, reasoningChars + responseShapeSummary(payload).reasoningChars); };
    let previousCR = false, firstCharacter = true, terminal = false, finishReason = '', interrupted = false;
    const cancel = () => { try { void reader.cancel().catch(() => {}); } catch {} };
    // reader.cancel settles outstanding read() calls. Avoid adding one reaction per
    // tiny network fragment to a long-lived abort promise.
    const onAbort = () => { cancel(); };
    const append = value => {
        if (content.length + value.length > core_constants.MAX_GENERATION_OUTPUT_CHARS) {
            throw apiError('模型服务返回内容过大，已停止读取。', 'RMT_MANUAL_RESPONSE_TOO_LARGE');
        }
        content += value;
    };
    const dispatch = () => {
        const data = dataLines.join('\n');
        const type = eventType;
        dataLines = [];
        eventType = '';
        if (!data) return;
        if (type === 'error') throw streamReadError('RMT_MANUAL_PROVIDER_ERROR');
        if (data.trim() === '[DONE]') {
            if (!finishReason) finishReason = 'done';
            terminal = true;
            return;
        }
        let payload;
        try { payload = JSON.parse(data); } catch { throw streamReadError(); }
        if (payloadHasProviderError(payload)) throw streamReadError('RMT_MANUAL_PROVIDER_ERROR');
        if (!payload || typeof payload !== 'object') throw streamReadError();
        // Accept only documented final-bearing event shapes, never JSON from
        // reasoning/tool blocks. A stream cannot silently switch protocols.
        const semanticType = payload.type || type;
        if (Array.isArray(payload.candidates)) {
            chooseProtocol('gemini');
            const candidate = payload.candidates.find(value => value?.index === 0) || payload.candidates.find(value => value?.index == null);
            if (!candidate) return;
            countReasoning({ candidates: [candidate] });
            const visible = visibleContentText(candidate.content?.parts); if (visible) append(visible);
            if (candidate.finishReason) {
                const mapped = { STOP:'stop', MAX_TOKENS:'max_tokens', SAFETY:'content_filter', RECITATION:'content_filter', BLOCKLIST:'content_filter', PROHIBITED_CONTENT:'content_filter' };
                finishReason = mapped[candidate.finishReason] || 'unknown'; terminal = true;
            }
            return;
        }
        if (typeof semanticType === 'string' && semanticType.startsWith('response.')) {
            chooseProtocol('responses');
            if (semanticType === 'response.output_text.delta') {
                // Responses output may begin with a reasoning item; the first
                // visible message is not necessarily output_index 0. Never join
                // a second output item into the selected final message.
                const index = payload.output_index ?? 0;
                if (!Number.isSafeInteger(index) || index < 0) throw streamReadError();
                responseOutputIndex ??= index;
                if (index === responseOutputIndex && typeof payload.delta === 'string') append(payload.delta);
            } else if (/^response\.reasoning(?:_summary)?_text\.delta$/.test(semanticType)) {
                if (typeof payload.delta === 'string') reasoningChars = Math.min(core_constants.MAX_GENERATION_OUTPUT_CHARS, reasoningChars + payload.delta.length);
            } else if (['response.completed','response.incomplete','response.failed'].includes(semanticType)) {
                if (semanticType === 'response.failed') throw streamReadError('RMT_MANUAL_PROVIDER_ERROR');
                const full = extractIndependentResponseContent(payload.response);
                if (typeof full === 'string' && full) {
                    if (content && !full.startsWith(content)) throw streamReadError();
                    if (full.length > content.length) append(full.slice(content.length));
                }
                finishReason = semanticType === 'response.completed' ? 'stop' : 'length'; terminal = true;
            }
            return;
        }
        if (['message_start','content_block_start','content_block_delta','content_block_stop','message_delta','message_stop','ping'].includes(semanticType)) {
            if (semanticType === 'ping') return;
            chooseProtocol('anthropic');
            if (semanticType === 'message_start' && payload.message?.role !== 'assistant') throw streamReadError();
            if (semanticType === 'content_block_start') {
                if (!Number.isSafeInteger(payload.index) || payload.index < 0 || blockKinds.size >= 4096) throw streamReadError();
                blockKinds.set(payload.index, payload.content_block?.type || 'unknown');
                if (payload.content_block?.type === 'text') append(visibleContentText(payload.content_block));
                else countReasoning(payload.content_block);
            } else if (semanticType === 'content_block_delta') {
                const kind = blockKinds.get(payload.index);
                if (kind === 'text' && payload.delta?.type === 'text_delta' && typeof payload.delta.text === 'string') append(payload.delta.text);
                else if (kind === 'thinking' && typeof payload.delta?.thinking === 'string') reasoningChars = Math.min(core_constants.MAX_GENERATION_OUTPUT_CHARS, reasoningChars + payload.delta.thinking.length);
            } else if (semanticType === 'message_delta') finishReason = streamFinishReason(payload.delta?.stop_reason) || finishReason;
            else if (semanticType === 'message_stop') { finishReason ||= 'unknown'; terminal = true; }
            return;
        }
        // OpenAI-compatible choice deltas (DeepSeek, Qwen, GLM, Doubao, Gemini
        // compatibility endpoints etc.) share this path regardless of model name.
        const choices = Array.isArray(payload.choices) ? payload.choices : [];
        const choice = choices.find(value => value?.index === 0)
            || choices.find(value => value && value.index == null);
        if (!choice) return;
        chooseProtocol('choices'); countReasoning({ choices: [choice] });
        let visible = visibleContentText(choice.delta?.content);
        if (!visible && typeof choice.text === 'string') visible = choice.text;
        if (!visible && choice.message?.content != null) {
            const full = visibleContentText(choice.message.content);
            if (content && !full.startsWith(content)) throw streamReadError();
            visible = full.slice(content.length);
        }
        if (visible) append(visible);
        if (choice.delta?.refusal || choice.message?.refusal) {
            finishReason = 'content_filter';
            terminal = true;
            return;
        }
        const reason = streamFinishReason(choice.finish_reason);
        if (reason) {
            finishReason = reason;
            terminal = true;
        }
    };
    const consumeLine = () => {
        if (!line) dispatch();
        else if (!line.startsWith(':')) {
            // A transport wrapper is not an SSE field; do not fish valid events
            // out of an HTML page merely because its header/comment looks SSE-like.
            if (line.trimStart().startsWith('<')) throw apiError('模型服务返回了 HTML 页面，响应正文已隐藏。', 'RMT_RESPONSE_HTML');
            const colon = line.indexOf(':');
            const field = colon < 0 ? line : line.slice(0, colon);
            let value = colon < 0 ? '' : line.slice(colon + 1);
            if (value.startsWith(' ')) value = value.slice(1);
            if (field === 'data') dataLines.push(value);
            else if (field === 'event') eventType = value;
            // id/retry are deliberately ignored: this paid request never reconnects.
        }
        line = '';
    };
    const consume = text => {
        // SSE permits CRLF, CR, or LF; a split CRLF is one newline, not two.
        for (const character of text) {
            if (terminal) break;
            if (firstCharacter) { firstCharacter = false; if (character === '\uFEFF') continue; }
            if (previousCR) { previousCR = false; if (character === '\n') continue; }
            if (character === '\r' || character === '\n') {
                consumeLine();
                previousCR = character === '\r';
            } else line += character;
        }
    };
    signal?.addEventListener?.('abort', onAbort, { once: true });
    try {
        if (signal?.aborted) throw streamAbortReason(signal);
        while (!terminal) {
            const { value, done } = await reader.read();
            if (signal?.aborted) throw streamAbortReason(signal);
            if (done) {
                consume(decoder.decode());
                // Per SSE framing, EOF does not dispatch an unfinished event.
                if (!terminal) interrupted = true;
                break;
            }
            bytes += value?.byteLength || 0;
            if (bytes > maxBytes) throw apiError('模型服务返回内容过大，已停止读取。', 'RMT_MANUAL_RESPONSE_TOO_LARGE');
            consume(decoder.decode(value, { stream: true }));
        }
    } catch (error) {
        if (signal?.aborted || error?.name === 'AbortError') throw streamAbortReason(signal);
        if (!content.trim()) {
            if (['RMT_MANUAL_INVALID_JSON', 'RMT_MANUAL_PROVIDER_ERROR', 'RMT_MANUAL_RESPONSE_TOO_LARGE', 'RMT_RESPONSE_HTML'].includes(error?.code)) throw error;
            throw streamReadError();
        }
        // Previously dispatched visible text may be recoverable; never append the
        // malformed/error event, put provider text in an Error, or issue another fetch.
        interrupted = true;
    } finally {
        signal?.removeEventListener?.('abort', onAbort);
        cancel();
        try { reader.releaseLock(); } catch {}
    }
    if (signal?.aborted) throw streamAbortReason(signal);
    if (!content.trim()) throw emptyFinalFailure({ shape: protocol === 'gemini' ? 'candidates' : 'choices', reasoningChars, finishReason });
    return streamCompletion(content, finishReason, interrupted, reasoningChars);
}

// The host may forward SSE without Content-Type, or a provider may answer a
// streaming request with ordinary JSON. Inspect only a bounded prefix of this
// response, then replay every consumed byte into the existing parser. No tee,
// second fetch, persistent setting change or provider-body diagnostics are used.
const MANUAL_RESPONSE_SNIFF_BYTES = 8192;

function manualResponseKind(prefix, ended, contentType) {
    const head = prefix.replace(/^\uFEFF/, '').trimStart();
    if (!head) return ended ? (contentType.includes('text/event-stream') ? 'sse' : 'json') : '';
    // JSON always wins over a misleading event-stream header. HTML goes through
    // the existing whole-document HTML rejection, never a JSON-island search.
    if ('{["<'.includes(head[0]) || /[0-9tfn-]/.test(head[0])) return 'json';
    if (head.startsWith(':')) return 'sse';
    for (const field of ['data', 'event', 'id', 'retry']) {
        if (head.startsWith(`${field}:`) || head.startsWith(`${field}\n`) || head.startsWith(`${field}\r`)) return 'sse';
        if (!ended && field.startsWith(head)) return '';
    }
    // With a real SSE header, unknown SSE fields retain their original handling.
    // Without it, unknown/plain content is not upgraded to a model completion.
    return contentType.includes('text/event-stream') ? 'sse' : 'json';
}

async function readManualCompletionResponse(response, options = {}) {
    const maxBytes = core_constants.MAX_MANUAL_API_RESPONSE_BYTES;
    const contentType = String(response?.headers?.get?.('content-type') || '').toLowerCase();
    const declaredBytes = Number(response?.headers?.get?.('content-length'));
    if (contentType.includes('text/html')) {
        try { void response?.body?.cancel?.()?.catch?.(() => {}); } catch {}
        throw apiError('模型服务返回了 HTML 页面，响应正文已隐藏。', 'RMT_RESPONSE_HTML', Number(response?.status) || 0);
    }
    if (Number.isFinite(declaredBytes) && declaredBytes > maxBytes) {
        try { void response?.body?.cancel?.()?.catch?.(() => {}); } catch {}
        throw apiError('模型服务返回内容过大，已停止读取。', 'RMT_MANUAL_RESPONSE_TOO_LARGE', Number(response?.status) || 0);
    }
    const signal = options.signal || null;
    let reader = response?.body?.getReader?.();
    if (!reader) {
        // Older fetch shims may only expose text(). Preserve their bounded read;
        // turn that single result into a replayable local byte reader, not IO.
        const text = await boundedResponseText(response, maxBytes);
        const bytes = new TextEncoder().encode(text);
        let used = false;
        reader = {
            read: async () => used ? { done: true } : (used = true, { done: false, value: bytes }),
            cancel: async () => { used = true; },
            releaseLock: () => {},
        };
    }
    const buffered = [];
    let cursor = 0, ended = false, cancelled = false;
    const cancel = () => {
        if (cancelled) return;
        cancelled = true;
        try { void reader.cancel()?.catch?.(() => {}); } catch {}
    };
    const onAbort = () => { cancel(); };
    const replay = {
        read: async () => {
            if (signal?.aborted) throw streamAbortReason(signal);
            if (cursor < buffered.length) {
                const value = buffered[cursor];
                buffered[cursor++] = null;
                return { done: false, value };
            }
            return ended ? { done: true } : await reader.read();
        },
        cancel: async () => { cancel(); },
        releaseLock: () => {}, // The owner below releases the original lock once.
    };
    const replayResponse = {
        status: response?.status, headers: response?.headers,
        body: { getReader: () => replay, cancel: async () => { cancel(); } },
    };
    signal?.addEventListener?.('abort', onAbort, { once: true });
    try {
        if (signal?.aborted) throw streamAbortReason(signal);
        const decoder = new TextDecoder('utf-8');
        let prefix = '', prefixBytes = 0, receivedBytes = 0, kind = '';
        while (!kind) {
            const { value, done } = await reader.read();
            if (signal?.aborted) throw streamAbortReason(signal);
            if (done) { ended = true; prefix += decoder.decode(); }
            else {
                receivedBytes += value?.byteLength || 0;
                if (receivedBytes > maxBytes) throw apiError('模型服务返回内容过大，已停止读取。', 'RMT_MANUAL_RESPONSE_TOO_LARGE');
                if (value?.byteLength) {
                    buffered.push(value);
                    const head = value.subarray(0, Math.max(0, MANUAL_RESPONSE_SNIFF_BYTES - prefixBytes));
                    prefixBytes += head.byteLength;
                    prefix += decoder.decode(head, { stream: true });
                }
            }
            kind = manualResponseKind(prefix, ended || prefixBytes >= MANUAL_RESPONSE_SNIFF_BYTES, contentType);
        }
        if (kind === 'sse') return { streaming: true, payload: await readManualApiStream(replayResponse, options) };
        const payload = await boundedJson(replayResponse, maxBytes);
        if (signal?.aborted) throw streamAbortReason(signal);
        return { streaming: false, payload };
    } catch (error) {
        if (signal?.aborted || error?.name === 'AbortError') throw streamAbortReason(signal);
        if (error?.safeToDisplay === true) throw error;
        throw streamReadError();
    } finally {
        signal?.removeEventListener?.('abort', onAbort);
        cancel();
        buffered.length = 0;
        try { reader.releaseLock(); } catch {}
    }
}

async function manualRequestSettings(settings, signal) {
    if (signal?.aborted) throw streamAbortReason(signal);
    const base = normalizeManualApiBaseUrl(settings?.manualApiBaseUrl, { required: true });
    if (settings?.manualApiKey || !settings?.manualApiSecretRef) return settings;
    const key = await manual_credentials.readManualCredential(base, settings.manualApiSecretRef);
    if (signal?.aborted) throw streamAbortReason(signal);
    return { ...settings, manualApiKey: key };
}

export async function fetchManualApiModels(settings, context, options = {}) {
    settings = await manualRequestSettings(settings, options.signal);
    const customUrl = assertManualApiCredentialTransport(settings?.manualApiBaseUrl, settings?.manualApiKey);
    const fetchImpl = options.fetchImpl || globalThis.fetch;
    if (typeof fetchImpl !== 'function') throw apiError('当前环境没有可用的网络请求能力。', 'RMT_MANUAL_FETCH_UNAVAILABLE');
    const controller = new AbortController();
    const externalSignal = options.signal || null;
    let timeoutId = 0;
    let rejectExternalAbort = null;
    const forwardAbort = () => {
        const reason = externalSignal?.reason instanceof Error ? externalSignal.reason : new DOMException('Aborted', 'AbortError');
        try { controller.abort(reason); } catch {}
        rejectExternalAbort?.(reason);
    };
    if (externalSignal?.aborted) {
        const reason = externalSignal.reason instanceof Error ? externalSignal.reason : new DOMException('Aborted', 'AbortError');
        try { controller.abort(reason); } catch {}
        throw reason;
    }
    externalSignal?.addEventListener?.('abort', forwardAbort, { once: true });
    try {
        const fetchPromise = fetchImpl(MANUAL_STATUS_ENDPOINT, {
            method: 'POST',
            credentials: 'same-origin',
            cache: 'no-cache',
            headers: requestHeaders(context),
            signal: controller.signal,
            body: JSON.stringify({
                chat_completion_source: 'custom',
                custom_url: customUrl,
                custom_include_headers: manualApiHeadersJson(settings?.manualApiKey),
                custom_include_body: '',
                custom_exclude_body: '',
            }),
        });
        const timeoutPromise = new Promise((_, reject) => {
            timeoutId = setTimeout(() => {
                const error = apiError('拉取模型超时；仍可直接填写模型 ID。', 'RMT_MANUAL_MODEL_TIMEOUT');
                try { controller.abort(error); } catch {}
                reject(error);
            }, core_constants.MANUAL_API_MODEL_LIST_TIMEOUT_MS);
        });
        const externalAbortPromise = new Promise((_, reject) => { rejectExternalAbort = reject; });
        const response = await Promise.race([fetchPromise, timeoutPromise, externalAbortPromise]);
        if (!response?.ok) {
            try { await response?.body?.cancel?.(); } catch {}
            throw httpFailure(response);
        }
        const payload = await boundedJson(response, 2000000);
        if (payloadHasProviderError(payload)) throw providerEnvelopeFailure(payload);
        const models = extractManualModelIds(payload);
        if (!models.length) throw apiError('接口没有返回可用模型；仍可直接填写模型 ID。', 'RMT_MANUAL_MODELS_EMPTY');
        return models;
    } finally {
        clearTimeout(timeoutId);
        rejectExternalAbort = null;
        try { externalSignal?.removeEventListener?.('abort', forwardAbort); } catch {}
    }
}

export async function requestManualApiCompletion(settings, context, messages, maxTokens, options = {}) {
    settings = await manualRequestSettings(settings, options.signal);
    if (options.signal?.aborted) throw streamAbortReason(options.signal);
    const customUrl = assertManualApiCredentialTransport(settings?.manualApiBaseUrl, settings?.manualApiKey);
    const model = core_text.normalizeText(options.model || settings?.manualApiModel, 240);
    if (!model) throw apiError('请先填写手动 API 的模型 ID。', 'RMT_MANUAL_MODEL');
    if (!Array.isArray(messages) || !messages.length) throw apiError('手动 API 请求缺少消息。', 'RMT_MANUAL_MESSAGES');
    const fetchImpl = options.fetchImpl || globalThis.fetch;
    if (typeof fetchImpl !== 'function') throw apiError('当前环境没有可用的网络请求能力。', 'RMT_MANUAL_FETCH_UNAVAILABLE');
    const advanced = advanced_generation.parseAdvancedGeneration(settings);
    let body = {
        model,
        messages,
        max_tokens: output_budget.normalizeOutputTokens(maxTokens),
        temperature: Number.isFinite(Number(options.temperature)) ? Number(options.temperature) : settings?.temperature,
        stream: settings?.manualApiStreaming === true,
        chat_completion_source: 'custom',
        custom_url: customUrl,
        custom_include_headers: manualApiHeadersJson(settings?.manualApiKey),
        custom_include_body: '',
        custom_exclude_body: '',
    };
    Object.assign(body, advanced_generation.advancedCarrier(advanced, 'custom'));
    body = advanced_generation.applyAdvancedExclusions(body, advanced);
    if (advanced.streamMode !== 'original') body.stream = advanced.streamMode === 'on';
    const response = await fetchImpl(MANUAL_GENERATE_ENDPOINT, {
        method: 'POST',
        credentials: 'same-origin',
        cache: 'no-cache',
        headers: requestHeaders(context),
        signal: options.signal || null,
        body: JSON.stringify(body),
    });
    if (!response?.ok) {
        try { await response?.body?.cancel?.(); } catch {}
        throw httpFailure(response);
    }
    const decoded = await readManualCompletionResponse(response, options);
    if (decoded.streaming) return decoded.payload;
    const payload = decoded.payload;
    if (payloadHasProviderError(payload)) throw providerEnvelopeFailure(payload);
    const content = extractIndependentResponseContent(payload);
    const summary = responseShapeSummary(payload);
    if (typeof content === 'string' && !content.trim()) throw emptyFinalFailure(summary);
    if (typeof content === 'string' && (body.stream || summary.reasoningChars
        || ['length','max_tokens','incomplete','content_filter','tool_calls','function_call'].includes(summary.finishReason))) {
        // JSON answered this same request. Missing completion metadata remains
        // unknown; explicit truncation never becomes a successfully saved result.
        const reason = ['none','unknown'].includes(summary.finishReason) ? 'unknown' : summary.finishReason === 'completed' ? 'stop' : summary.finishReason;
        return streamCompletion(content, reason, false, summary.reasoningChars, reason === 'unknown');
    }
    return content;
}
