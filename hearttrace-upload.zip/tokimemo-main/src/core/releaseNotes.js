// GENERATED FROM README.md by tools/verification/build.py. Do not edit by hand.
export const RELEASE_README = "# 心迹回廊 1.0.35\n\n## 更新日志模块\n\n新增了更新日志板块，感谢@nancyindaeyo的更新。\n\n## 本次变动\n\n- 修复 TT 中情侣头像收到图片后无法写入历史的问题，正确识别 TT 返回的本机图片地址。\n- 绘制进度放在生成按钮附近；生成失败会保留原因，点击“知道了”才收起。切换到历史页仍可查看任务与提示。\n- 诊断报告增加头像任务状态和处理阶段，便于区分等待出图、图片接收及本机保存问题。\n";
