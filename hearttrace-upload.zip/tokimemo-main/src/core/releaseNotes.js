// GENERATED FROM README.md by tools/verification/build.py. Do not edit by hand.
export const RELEASE_README = "# 心迹回廊 1.0.41\n\n## 更新日志模块\n\n新增了更新日志板块，感谢@nancyindaeyo的更新。\n\n## 本次变动\n\n- 调整情侣头像的柏宝绘 NAI 提示：使用公开接口的标签与自然语言字段，外貌放在各自人物栏开头，动作单独传递，减少反复出现的风格长段。\n- 随机互动灵感同时携带左右动作和不同反应，修正人物栏只有笼统动作说明的问题；自定义文字、角色外貌和已有收藏保持原样。\n- 随机灵感的默认背景描述改为铺满画面的纯色背景；工笔与油画的笔触说明改用正向描述。柏宝绘自身的画风配方、负向提示与横屏尺寸仍按用户配置使用。\n";
