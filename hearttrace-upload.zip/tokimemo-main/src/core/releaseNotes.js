// GENERATED FROM README.md by tools/verification/build.py. Do not edit by hand.
export const RELEASE_README = "# 心迹回廊 1.0.28\n\n## 更新日志模块\n\n新增了更新日志板块，感谢@nancyindaeyo的更新。\n\n## 本次变动\n\n- 手书剪辑台采用已确认的新布局：大画面、四镜缩略图与全部分镜入口、简洁工具页签；剪辑时收起外层导航，返回即恢复。\n- 镜头与全片设置按需展开；保留图片编辑、音乐与录屏音源、定段定句、舞台编排、导出和待保存结果处理。\n- 图片编辑的缩放工具移到画布下方，撤销、保存和保存下一镜常驻；更新不改已有图片、提示词与存档。\n";
