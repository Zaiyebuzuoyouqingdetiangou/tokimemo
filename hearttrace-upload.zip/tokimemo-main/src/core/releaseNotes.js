// GENERATED FROM README.md by tools/verification/build.py. Do not edit by hand.
export const RELEASE_README = "# 心迹回廊 1.0.29\n\n## 更新日志模块\n\n新增了更新日志板块，感谢@nancyindaeyo的更新。\n\n## 本次变动\n\n- 图片编辑保留“选单格、自由裁切、抠图修边”原位置，把“导入图片”和“编辑提示词”移出工具滚动区，放到下方独立显示。\n- 共用面板按需展开、相互切换，关闭时保留当前图片、缩放、撤销记录和提示词草稿；撤销与保存仍常驻。\n";
