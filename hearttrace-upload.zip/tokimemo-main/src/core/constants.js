// Heartbeat Memories r35 modular runtime.
// Extracted from r34 without changing archive/cache storage contracts.
export const THEATER_ID = 'heartbeat_memories';

export const OVERLAY_ID = 'heartbeat_memories_overlay';

export const SETTINGS_ID = 'heartbeat_memories_settings';

export const MENU_ID = 'heartbeat_memories_menu_item';

export const STYLE_ID = 'heartbeat_memories_styles';

export const SETTINGS_STYLE_ID = 'heartbeat_memories_settings_styles';

export const CACHE_KEY = 'heartbeatMemoriesTheaterV3';

export const PHONE_DRAFT_CACHE_KEY = 'phoneGenerationDraftV1';

export const MODE_WRITE_FENCES_CACHE_KEY = 'modeWriteFencesV1';

export const SESSION_MODE_WRITE_FENCE_KEY = '_rmtModeWriteFence';

export const MEMORY_KEY = 'heartbeatMemoriesArchiveV3';

export const ARCHIVE_SCHEMA_VERSION = 3;

export const MIN_SUPPORTED_ARCHIVE_SCHEMA_VERSION = 3;

export const MEMORY_VERSION = ARCHIVE_SCHEMA_VERSION;

export const CACHE_STORAGE_FORMAT = 'gzip-base64-v1';

export const CACHE_STORAGE_VERSION = 1;

export const CALENDAR_SESSION_VERSION = 6;

export const PHONE_SESSION_VERSION = 4;

export const ROOM_SESSION_VERSION = 3;

export const TRAVEL_SESSION_VERSION = 4;

// No plugin-defined byte ceiling: actual storage transactions decide success.
export const MAX_CACHE_COMPRESSED_BASE64_CHARS = Infinity;

export const MAX_CACHE_DECOMPRESSED_BYTES = Infinity;

export const MAX_CACHE_SOURCE_BYTES = MAX_CACHE_DECOMPRESSED_BYTES;

export const ARCHIVE_BACKUP_DB_NAME = 'heartbeatMemoriesArchiveBackupsV1';

export const ARCHIVE_BACKUP_STORE_NAME = 'archives';

export const ARCHIVE_BACKUP_STORAGE_VERSION = 1;

// Compatibility alias for test/tooling consumers from r42.2 and earlier. The cache writer no
// longer compares this budget with String.length; UTF-8 bytes are the authoritative unit.
export const MAX_CACHE_SOURCE_CHARS = MAX_CACHE_SOURCE_BYTES;

export const MAX_IMPORT_MESSAGES = 4000;

export const MAX_IMPORT_TOTAL_CHARS = 1200000;

export const IMPORT_CHUNK_CHARS = 30000;

// r84.71: a formal archive checkpoint every ~5 chat requests instead of one
// 1.2M-character batch. A single failed request can no longer hold back the
// whole chat. Per-request size and model budgets are unchanged.
export const ARCHIVE_BATCH_CHAT_CHARS = 150000;

// Archive extraction reads ~30k characters per request and can legitimately
// take longer than ordinary pages on slow proxies. Floor only; never shorter.
export const ARCHIVE_REQUEST_TIMEOUT_MS = 360000;

// Transient transport failures (5xx / network / timeout / rate limit) get a
// bounded number of automatic retries for archive extraction only.
export const ARCHIVE_TRANSIENT_RETRY_DELAYS_MS = Object.freeze([5000, 15000]);

export const MAX_MEMORY_ITEMS = 240;

// Formal storage is not the model's per-request evidence/output budget.
// Keep MAX_MEMORY_ITEMS bounded for existing prompt consumers only.
export const MAX_STORED_MEMORY_ITEMS = Infinity;

export const MAX_COLD_ARCHIVE_ITEMS = 100;

export const MAX_ROLLING_EVICT_PER_BATCH = 20;

export const MAX_MEMORY_PROMPT_ITEMS = 64;

export const DERIVED_INCREMENTAL_SCHEMA_VERSION = 1;

export const MAX_DERIVED_CONTENT_ITEMS = Infinity;

export const MAX_INCREMENTAL_EXISTING_INDEX_ITEMS = 120;

export const MAX_GENERATION_INPUT_TOKENS = 60000;

export const LEGACY_DEFAULT_INPUT_BUDGET_TOKENS = 32000;

// Preserve the user-selected positive safe integer; this is not a model capability.
export const MIN_USER_INPUT_BUDGET_TOKENS = 1;

export const MAX_USER_INPUT_BUDGET_TOKENS = Number.MAX_SAFE_INTEGER;

// Legacy per-feature sizing hint only; never clamp the user's output setting to it.
export const MAX_GENERATION_OUTPUT_TOKENS = 60000;

export const MAX_GENERATION_OUTPUT_CHARS = Infinity;

export const MAX_GENERATION_INPUT_CHARS = 180000;

export const MAX_EXTERNAL_MEMORY_ITEMS = 256;

export const MAX_EXTERNAL_MEMORY_CHARS = 240000;

export const EXTERNAL_MEMORY_CHUNK_CHARS = 26000;

export const EXTERNAL_MEMORY_FETCH_LIMIT = 200;

// r46 universal-memory ingress keeps the durable source ledger independent from the
// much smaller generation budget above.  Importing more source material must not make
// every model request larger.
export const MEMORY_PROVIDER_REGISTRY_VERSION = 1;

export const MEMORY_SOURCE_LEDGER_DB_NAME = 'heartbeatMemoriesSourceLedgerV1';

export const MEMORY_SOURCE_LEDGER_STORE_NAME = 'sourceLedgers';

export const MEMORY_SOURCE_LEDGER_STORAGE_VERSION = 1;

// Durable source storage has no plugin count/character quota. Per-request
// batching and actual storage acknowledgements are separate contracts.
export const MAX_MEMORY_SOURCE_LEDGER_RECORDS = Infinity;

export const MAX_MEMORY_SOURCE_LEDGER_CHARS = Infinity;

export const MAX_MEMORY_SOURCE_FRAGMENT_CHARS = 5200;

export const MAX_MEMORY_FILE_BYTES = Infinity;

export const MAX_MEMORY_FILE_RECORDS = Infinity;

export const MAX_MEMORY_FILE_CHARS = Infinity;

export const ARCHIVE_INDEX_SETTINGS_KEY = 'heartbeatMemoriesArchiveIndexV1';

export const ARCHIVE_INDEX_MAX = 1200;

export const ARCHIVE_GROUPS_SETTINGS_KEY = 'heartbeatMemoriesArchiveGroupsV1';

export const ARCHIVE_GROUPS_MAX = 240;

export const ARCHIVE_DELETED_CHARACTERS_SETTINGS_KEY = 'heartbeatMemoriesDeletedCharactersV1';

export const ARCHIVE_DELETED_CHARACTERS_MAX = 240;

export const ARCHIVE_CHARACTER_PROFILES_SETTINGS_KEY = 'heartbeatMemoriesCharacterProfilesV1';

export const ARCHIVE_CHARACTER_PROFILES_MAX = 240;

export const EXTENSION_SETTINGS_KEY = 'heartbeatMemories';

export const AVATAR_VISIT_SETTINGS_KEY = 'heartbeatMemoriesAvatarVisitsV1';

export const MAX_BANNED_GENERATED_PHRASES = 24;

export const MEMORY_WORLD_INFO_SETTINGS_KEY = 'heartbeatMemoriesMemoryWorldInfoV1';

export const MAX_MEMORY_WORLD_INFO_BOOKS = Infinity;

export const MAX_MEMORY_WORLD_INFO_ENTRIES = 160;

export const MAX_MEMORY_WORLD_INFO_CHARS = 52000;
// Controlled-envelope budget for ROOM / TRAVEL / PHONE. The picker above allows a much
// larger selection than one request can carry, so these two numbers decide what actually
// ships. Hand-picked setting entries outrank the dry-run tail: the user chose them on
// purpose, the dry run only happened to activate.
export const MAX_CONTROLLED_WORLD_TOTAL_CHARS = 16000;
export const MAX_SELECTED_SETTING_CHARS = 12000;

export const THEME_MODES = new Set(['default', 'night', 'host', 'custom', 'gs1', 'gs2', 'gs3', 'gs4']);
export const SEASON_THEME_PALETTES = Object.freeze({
    gs1: Object.freeze({ background: '#edf6e5', surface: '#ffffff', text: '#234831', muted: '#50624d', accent: '#43833d', accentAlt: '#e7b83b', border: '#bad7a7' }),
    gs2: Object.freeze({ background: '#e9f3ff', surface: '#ffffff', text: '#233d61', muted: '#52647d', accent: '#287dc3', accentAlt: '#9b79c8', border: '#b4d2ee' }),
    gs3: Object.freeze({ background: '#fff0f5', surface: '#ffffff', text: '#572c43', muted: '#78536a', accent: '#cc4d87', accentAlt: '#68a97d', border: '#edb6cf' }),
    gs4: Object.freeze({ background: '#fff1d9', surface: '#fffefd', text: '#553b24', muted: '#74604b', accent: '#c77425', accentAlt: '#5096c8', border: '#e9ca94' }),
});

export const NIGHT_THEME_PALETTE = Object.freeze({
    background: '#171d28', surface: '#232c3a', text: '#edf1f8', muted: '#b8c5d6',
    accent: '#d9a8c1', accentAlt: '#90c9c5', border: '#455269',
});

export const DEFAULT_THEME_PALETTE = Object.freeze({
    background: '#f5f4fb',
    surface: '#ffffff',
    text: '#34495d',
    muted: '#586b7c',
    accent: '#ce729c',
    accentAlt: '#58a59e',
    border: '#cfdae5',
});

export const DEFAULT_SETTINGS = Object.freeze({
    apiConnectionMode: 'profile',
    connectionProfileId: '',
    modelOverride: '',
    manualApiBaseUrl: '',
    manualApiModel: '',
    manualApiStreaming: false,
    chatReadRange: Object.freeze({ mode: 'recent', recent: 50, start: 1, end: 100, includeHidden: false }),
    maxTokens: 60000,
    inputBudgetTokens: 60000,
    temperature: 0.9,
    roomLifeAutoDaily: true,
    useCurrentChatExternalMemory: true,
    useActivatedWorldInfo: true,
    // Manual fallback for hosts where Image Generation is active but its SlashCommand object is
    // not exposed through the current context registry. Off by default; when enabled we may use
    // the public executeSlashCommandsWithOptions('/sd quiet=true ...') path with a sanitized prompt.
    imageGenerationManualEnabled: false,
    autoRetryEnabled: false,
    autoRetryCount: 1,
    autoSecondPass: false,
    autoMemoryLatestFloor: false,
    autoMemoryIntervalFloors: 5,
    heartEnvelopeSkin: 'pink',
    creativeSupplementEnabled: false,
    creativeSupplement: '',
    imageGenerationProvider: 'baibai-image',
    imageGenerationFallback: false,
    cgPromptFormat: 'nai5-natural',
    // Optional r32-style mobile safe-area presentation. Off keeps the long-standing edge-to-edge fullscreen UI.
    ttDisplayMode: false,
    floatingAvatar: 'char',
    floatingAvatarPosition: null,
    themeMode: 'default',
    themeAlpha: 0.96,
    themeCustom: DEFAULT_THEME_PALETTE,
    // Applies only to newly model-generated derivative content. Never rewrite chat/archive evidence.
    bannedGeneratedPhrases: ['老子'],
});

export const HEART_ENVELOPE_SKINS = Object.freeze(['pink', 'wax', 'night', 'sakura', 'airmail', 'wash']);

export const MODE = Object.freeze({
    BUTTERFLY: 'butterfly',
    ALBUM: 'album',
    ADV: 'adv',
    ROOM: 'room',
    ITEMS: 'items',
    CABINET: 'cabinet',
    PHONE: 'phone',
    INBOX: 'inbox',
    THEME_SONG: 'themeSong',
    BEDTIME: 'bedtime',
    PAST_LIVES: 'pastLives',
    TIME_ECHO: 'timeEcho',
    TRAVEL: 'travel',
    ENDING: 'ending',
    CALENDAR: 'calendar',
    RELATIONS: 'relations',
    HEART: 'heart',
    ACHIEVEMENTS: 'achievements',
});

export const MODE_LABEL = Object.freeze({
    [MODE.BUTTERFLY]: '蝴蝶效应的时间节点',
    [MODE.ALBUM]: '回忆相簿',
    [MODE.ADV]: 'ADV EVENT',
    [MODE.ROOM]: '他的房间',
    [MODE.ITEMS]: '他的物品',
    [MODE.CABINET]: '两个人的陈列柜',
    [MODE.PHONE]: '他的私人终端',
    [MODE.INBOX]: '你的邮箱',
    [MODE.THEME_SONG]: '角色印象曲',
    [MODE.BEDTIME]: '睡前故事',
    [MODE.PAST_LIVES]: '前世今生',
    [MODE.TIME_ECHO]: '时空回响',
    [MODE.TRAVEL]: '他的出行路线',
    [MODE.ENDING]: '结局与后日谈',
    [MODE.CALENDAR]: '两个人的日历',
    [MODE.RELATIONS]: '人际庭园',
    [MODE.HEART]: '角色互动与 Voice Drama',
    [MODE.ACHIEVEMENTS]: '成就库',
});

export const MODE_TOKEN_CAPS = Object.freeze({
    [MODE.BUTTERFLY]: MAX_GENERATION_OUTPUT_TOKENS,
    [MODE.ALBUM]: MAX_GENERATION_OUTPUT_TOKENS,
    [MODE.ADV]: MAX_GENERATION_OUTPUT_TOKENS,
    [MODE.ROOM]: MAX_GENERATION_OUTPUT_TOKENS,
    [MODE.ITEMS]: MAX_GENERATION_OUTPUT_TOKENS,
    [MODE.CABINET]: 5500,
    [MODE.PHONE]: MAX_GENERATION_OUTPUT_TOKENS,
    [MODE.INBOX]: 4000,
    [MODE.THEME_SONG]: 6500,
    [MODE.BEDTIME]: 6500,
    [MODE.PAST_LIVES]: MAX_GENERATION_OUTPUT_TOKENS,
    [MODE.TIME_ECHO]: 12000,
    [MODE.TRAVEL]: 9000,
    [MODE.ENDING]: MAX_GENERATION_OUTPUT_TOKENS,
    [MODE.CALENDAR]: 6000,
    [MODE.RELATIONS]: 7000,
    [MODE.HEART]: MAX_GENERATION_OUTPUT_TOKENS,
    [MODE.ACHIEVEMENTS]: 6000,
});

export const ARCHIVE_PORTAL_MODES = Object.freeze([MODE.ALBUM, MODE.ADV, MODE.ROOM, MODE.PHONE, MODE.INBOX, MODE.CABINET, MODE.TRAVEL, MODE.ENDING, MODE.CALENDAR, MODE.RELATIONS, MODE.HEART, MODE.ACHIEVEMENTS, MODE.BUTTERFLY, MODE.PAST_LIVES, MODE.THEME_SONG, MODE.BEDTIME]);

export const ROOM_DEEP_MODES = Object.freeze([MODE.ITEMS]);
export const CREATIVE_EXPANSION_MODES = Object.freeze([MODE.ADV, MODE.BUTTERFLY, MODE.HEART, MODE.ENDING, MODE.ALBUM, MODE.TRAVEL, MODE.PAST_LIVES, MODE.TIME_ECHO, MODE.THEME_SONG, MODE.BEDTIME]);

export const ARCHIVE_OVERVIEW_CACHE_MS = 60000;

export const CATEGORY_VALUES = new Set(['日常', '约会', '结局', '待分类']);

export const ROOM_ZONE_VALUES = new Set(['左上', '右上', '左下', '右下', '中央', '近景']);

// 记忆 = shared past with the user (hard archive evidence required).
// 设定 = written down in the card or world book (verbatim quote required).
// 推演 = inferred from persona and world. That is characterisation, not a factual claim
//        about the user's history, so it carries no quote — but it may never mention a
//        shared past, and the UI always labels it as inferred.
export const ROOM_BASIS_VALUES = new Set(['设定', '记忆', '推演']);

export const PHONE_DEVICE_KINDS = new Set(['neutral', 'phone', 'watch', 'terminal', 'communicator', 'folio', 'relic']);

export const PHONE_EXCLUDED_APP_KINDS = new Set(['schedule', 'calendar', 'location', 'map', 'maps', 'navigation', 'travel', 'transit', 'route']);

export const TRAVEL_LOCATION_KINDS = new Set(['near', 'far']);

export const TRAVEL_MAP_THEMES = new Set(['neutral', 'city', 'coast', 'forest', 'mountain', 'campus', 'historic', 'fantasy', 'scifi']);

export const TRAVEL_POSTCARD_TONES = new Set(['rose', 'ocean', 'forest', 'sunset', 'night', 'paper']);

export const TRAVEL_KEEPSAKE_KINDS = new Set(['postcard', 'letter', 'journal', 'scroll', 'fieldnote', 'dossier', 'datalog', 'token']);

export const ROOM_DAYPART_KEYS = ['morning', 'daytime', 'evening', 'night'];

export const ENDING_TYPES = new Set(['route', 'romance', 'reverse', 'bond', 'open', 'personal']);

export const CONFESSION_REPLAY_TYPES = new Set(['true', 'mutual', 'friendship', 'indirect', 'relationship', 'rejected', 'other']);

export const CG_IMAGE_PROVIDER = 'sillytavern-imagine';
export const CG_IMAGE_HISTORY_LIMIT = 5;

export const MAX_CG_IMAGE_PROMPT_CHARS = 1800;

export const HEART_GREETING_KEYS = Object.freeze(['morning', 'noon', 'evening', 'night', 'weekend', 'birthday', 'userBirthday', 'holiday', 'absenceWorry', 'absenceSulky', 'absenceJealous']);

export const HEART_VOICE_KINDS = new Set(['postending', 'spring', 'summer', 'autumn', 'winter']);

export const HEART_SCENARIO_SEASONS = new Set(['spring', 'summer', 'autumn', 'winter']);

export const HEART_DRAMA_VISUAL_TONES = new Set(['soft', 'clear', 'muted', 'deep']);

export const HEART_FIREFLY_COLORS = new Set(['pink', 'blue', 'yellow', 'white', 'desire']);
export const HEART_FIREFLY_MAX_ITEMS = MAX_DERIVED_CONTENT_ITEMS;
export const HEART_FIREFLY_PAGE_SIZE = 6;

export const HEART_STRIP_PANEL_COUNTS = new Set([1, 2, 4]);

export const MAX_CONCURRENT_GENERATION_TASKS = 5;

export const ADV_BULK_BATCH_SIZE = 6;

export const MAX_CONCURRENT_PROVIDER_REQUESTS = 2;

export const CACHE_PERSIST_IDLE_RETRY_MS = 1200;

// Measured on this user's host: a failing request sat for 4-12 minutes before the
// transport gave up, and with two provider slots one stuck request queued everything
// behind it. A request that has produced nothing after three minutes will not recover,
// so fail it fast and release the slot.
export const DEFAULT_GENERATION_REQUEST_TIMEOUT_MS = 180000;

export const MIN_GENERATION_REQUEST_TIMEOUT_MS = 30000;

export const MAX_GENERATION_REQUEST_TIMEOUT_MS = 1200000;

export const MANUAL_API_MODEL_LIST_TIMEOUT_MS = 30000;

export const MAX_MANUAL_API_RESPONSE_BYTES = Infinity;

export const SEGMENT_REQUEST_CONCURRENCY = 2;

export const ARCHIVE_SNAPSHOT_CACHE_MAX = 4;

export const RUNTIME_SESSION_CACHE_MAX = 3;
