import * as content_selection_ui from './contentSelection.js';
import * as cg_format_ui from './cgFormatControl.js';
// Heartbeat Memories r35 modular runtime.
// Extracted from r34 without changing archive/cache storage contracts.
import * as core_constants from '../core/constants.js';
import * as core_context from '../core/context.js';
import { state as runtimeState } from '../core/state.js';
import * as core_text from '../core/text.js';
import * as generation_imageGeneration from '../generation/imageGeneration.js';
import * as ui_overlay from './overlay.js';

export function selectedAdvEvent() {
    if (!runtimeState.activeSession || runtimeState.activeSession.kind !== core_constants.MODE.ADV) return null;
    return runtimeState.activeSession.events.find(x => x.id === runtimeState.activeSession.selectedId) || runtimeState.activeSession.events[0] || null;
}

export function renderAdvMode() {
    const session = runtimeState.activeSession;
    if (!session || session.kind !== core_constants.MODE.ADV) return;
    ui_overlay.setBackVisible(true, runtimeState.activeArchiveSnapshot ? '只读档案' : '当前档案');
    ui_overlay.topTitle(core_constants.MODE_LABEL[core_constants.MODE.ADV]);
    const selected = selectedAdvEvent();
    let scope = runtimeState.activeArchiveSnapshot
        ? `archive-target:${core_context.archiveIndexEntryId(runtimeState.activeArchiveSnapshot)}`
        : '';
    if (!scope) try { scope = core_context.chatScopeKey(core_context.currentCharacterGuard()); } catch {}
    const bulkRunning = scope ? runtimeState.activeAdvBulkScopes.has(scope) : false;
    const completedAdv = session.events.filter(item => item.adv?.paragraphs?.length && !item.progressPending?.length).length;
    const readOnlyArchive = !!runtimeState.activeArchiveSnapshot && runtimeState.activeArchiveReadOnly;
    const canGenerateDerived = !runtimeState.activeArchiveSnapshot || runtimeState.activeArchiveSnapshot.backupOnly !== true;
    const selectedIndex = Math.max(0, session.events.findIndex(item => item.id === selected?.id));
    const list = session.events.map((item, index) => `<button type="button" class="rmt-event ${item.id === session.selectedId ? 'active' : ''}" data-rmt-event-id="${core_text.esc(item.id)}"><span class="rmt-event-index">${String(index + 1).padStart(2, '0')}</span><span class="rmt-event-copy"><b>${core_text.esc(item.title)}</b><small>${core_text.esc(item.date)}</small></span><em class="rmt-event-state">${generation_imageGeneration.normalizeCgImageRecord(item.cgImage) ? '图✓ ' : ''}${item.adv?.paragraphs?.length ? 'ADV✓' : 'CG'}</em></button>`).join('');
    const options = session.events.map((item, index) => `<option value="${core_text.esc(item.id)}" ${item.id === selected?.id ? 'selected' : ''}>${String(index + 1).padStart(2, '0')} · ${core_text.esc(item.title)} · ${core_text.esc(item.date)}${item.adv?.paragraphs?.length ? ' · ADV✓' : ''}</option>`).join('');
    const hasAdv = !!selected?.adv?.paragraphs?.length;
    const reading = session.view !== 'cg' && hasAdv;
    let detail = '';
    if (selected) {
        const image = `<div class="rmt-big-cg rmt-reading-image${generation_imageGeneration.normalizeCgImageRecord(selected.cgImage) ? ' rmt-reading-image-saved' : ''}">${generation_imageGeneration.cgImageLayerHtml(selected, { lazy: false })}</div>`;
        const actions = `<div class="rmt-mode-actions rmt-adv-reading-actions">${reading ? '<button type="button" class="rmt-btn" data-rmt-action="cg-only">只看CG</button>' : ''}<button type="button" class="rmt-btn" data-rmt-action="read-adv" ${reading || (!hasAdv && (bulkRunning || !canGenerateDerived)) ? 'disabled' : ''}>${reading ? '阅读ADV' : hasAdv ? '返回阅读 ADV' : canGenerateDerived ? '生成并阅读 ADV' : 'ADV 尚未生成'}</button>${readOnlyArchive ? '' : '<button type="button" class="rmt-btn rmt-picture-settings" data-rmt-action="edit-cg-prompt">图片设置</button>'}</div>`;
        if (reading) {
            const paras = selected.adv.paragraphs;
            session.paragraphIndex = Math.max(0, Math.min(session.paragraphIndex, paras.length - 1));
            detail = `${actions}<div class="rmt-adv-reading-layout rmt-adv-text-first">${image}<div class="rmt-adv-reading-copy"><details class="rmt-cg-caption"><summary><b>${core_text.esc(selected.title)}</b><span>${core_text.esc(selected.date)}</span></summary><p>${core_text.esc(selected.cgDesc)}</p></details><div class="rmt-adv-reader"><div class="rmt-progress">第 ${session.paragraphIndex + 1} 段 / 共 ${paras.length} 段</div><div class="rmt-adv-para">${core_text.esc(paras[session.paragraphIndex])}</div><div class="rmt-reader-actions"><button type="button" class="rmt-btn" data-rmt-action="adv-prev" ${session.paragraphIndex <= 0 ? 'disabled' : ''}>上一段</button><button type="button" class="rmt-btn" data-rmt-action="adv-next">${session.paragraphIndex >= paras.length - 1 ? '重看' : '下一段'}</button></div></div></div></div>`;
        } else {
            // CG view contains no caption or prose layer. The return action stays
            // outside the image, and rendering cannot trigger a paid request.
            detail = session.view === 'cg' ? `${actions}${image}`
                : `${actions}<section class="rmt-workspace-empty"><h2>${core_text.esc(selected.title)}</h2><p>这篇 ADV 正文尚未生成。</p><button type="button" class="rmt-btn" data-rmt-action="cg-only">只看 CG</button></section>`;
        }
    }
    const recoveryIds = new Set(core_text.cleanArray(session.advBulkRecovery?.failedIds, 64, 100));
    const recoveryCount = session.events.filter(item => !item.adv?.paragraphs?.length && (!recoveryIds.size || recoveryIds.has(item.id))).length;
    const recoveryActions = canGenerateDerived && recoveryCount > 0 && session.advBulkRecovery
        ? `<div class="rmt-adv-recovery"><button type="button" class="rmt-btn" data-rmt-action="repair-failed-adv" ${bulkRunning ? 'disabled' : ''}>逐个补失败项 · ${recoveryCount}</button></div>`
        : '';
    const bulkLabel = session.advBulkRecovery && recoveryCount
        ? `重试失败批 · 最多${core_constants.ADV_BULK_BATCH_SIZE}篇`
        : completedAdv ? `生成下一批 ADV · 最多${core_constants.ADV_BULK_BATCH_SIZE}篇` : `生成第一批 ADV · 最多${core_constants.ADV_BULK_BATCH_SIZE}篇`;
    const bulkBar = `<div class="rmt-adv-bulkbar"><div><b>ADV ${completedAdv}/${session.events.length}</b><span>${!canGenerateDerived ? '永久只读备份' : completedAdv >= session.events.length ? '已完成' : `每批最多 ${core_constants.ADV_BULK_BATCH_SIZE} 篇`}</span></div>${!canGenerateDerived ? '' : `<button type="button" class="rmt-btn" data-rmt-action="generate-all-adv" ${bulkRunning || completedAdv >= session.events.length ? 'disabled' : ''}>${bulkRunning ? '生成中…' : bulkLabel}</button>`}</div>${recoveryActions}`;
    const mobilePicker = `<div class="rmt-adv-mobile-picker"><button type="button" class="rmt-btn" data-rmt-action="adv-event-prev" aria-label="上一个事件" ${selectedIndex <= 0 ? 'disabled' : ''}>‹</button><select data-rmt-adv-select aria-label="选择 ADV EVENT 事件">${options}</select><button type="button" class="rmt-btn" data-rmt-action="adv-event-next" aria-label="下一个事件" ${selectedIndex >= session.events.length - 1 ? 'disabled' : ''}>›</button></div>`;

    const body = ui_overlay.bodyEl();
    const expandButton = readOnlyArchive && canGenerateDerived && completedAdv >= session.events.length && session.events.length < core_constants.MAX_DERIVED_CONTENT_ITEMS
        ? '<button type="button" class="rmt-btn" data-rmt-generate-mode="adv" data-rmt-regenerate="true">同一记忆 · 追加新镜头</button>' : '';
    const libraryTools = `<details class="rmt-adv-library-tools"><summary>生成与补全 · ${completedAdv}/${session.events.length}</summary><div>${bulkBar}${expandButton}${generation_imageGeneration.cgImageProviderBar({ readOnly: readOnlyArchive })}</div></details>`;
    body.innerHTML = `${content_selection_ui.contentSelectionHtml(core_constants.MODE.ADV, { readOnly: readOnlyArchive })}<div class="rmt-adv ${reading ? 'rmt-adv-reading' : 'rmt-cg-only'}"><aside class="rmt-event-list">${mobilePicker}${libraryTools}<div class="rmt-event-items">${list}</div></aside><section class="rmt-event-detail">${session.readableProgress?.complete === false ? '<p role="status">未完成 · 已生成的事件和正文可继续阅读。</p>' : ''}${selected?.progressPending?.length ? '<p role="status">这篇 ADV 正文尚未完成。</p>' : ''}${detail}</section><div class="rmt-inline-status" hidden></div></div>`;
    content_selection_ui.mountContentSelection(body, core_constants.MODE.ADV, session);
    cg_format_ui.mountCgFormatControl(body, 'adv', '', readOnlyArchive);
}

export function resumeAdvReading() {
    const session = runtimeState.activeSession;
    if (runtimeState.activeMode !== core_constants.MODE.ADV || session?.kind !== core_constants.MODE.ADV) return false;
    if (!selectedAdvEvent()?.adv?.paragraphs?.length) return false;
    session.view = 'adv';
    renderAdvMode();
    return true;
}

export function advSelect(id) {
    if (!runtimeState.activeSession || runtimeState.activeSession.kind !== core_constants.MODE.ADV) return;
    const item = runtimeState.activeSession.events.find(x => x.id === id);
    if (!item) return;
    runtimeState.activeSession.selectedId = item.id;
    runtimeState.activeSession.view = 'adv';
    runtimeState.activeSession.paragraphIndex = 0;
    renderAdvMode();
}

export function advEventStep(delta) {
    if (!runtimeState.activeSession || runtimeState.activeSession.kind !== core_constants.MODE.ADV || !runtimeState.activeSession.events.length) return;
    const current = Math.max(0, runtimeState.activeSession.events.findIndex(item => item.id === runtimeState.activeSession.selectedId));
    const next = Math.max(0, Math.min(runtimeState.activeSession.events.length - 1, current + delta));
    const item = runtimeState.activeSession.events[next];
    if (!item || next === current) return;
    runtimeState.activeSession.selectedId = item.id;
    runtimeState.activeSession.view = 'adv';
    runtimeState.activeSession.paragraphIndex = 0;
    renderAdvMode();
}

export function advStep(delta) {
    if (!runtimeState.activeSession || runtimeState.activeSession.kind !== core_constants.MODE.ADV) return;
    const event = selectedAdvEvent();
    const paras = event?.adv?.paragraphs || [];
    if (!paras.length) return;
    if (delta > 0 && runtimeState.activeSession.paragraphIndex >= paras.length - 1) {
        runtimeState.activeSession.paragraphIndex = 0;
    } else {
        runtimeState.activeSession.paragraphIndex = Math.max(0, Math.min(paras.length - 1, runtimeState.activeSession.paragraphIndex + delta));
    }
    renderAdvMode();
}
