import * as advanced_ui from './advancedGenerationUi.js';
import * as output_budget from '../core/outputBudget.js';
import * as cg_format_ui from './cgFormatControl.js';
// Heartbeat Memories r35 modular runtime.
// Extracted from r34 without changing archive/cache storage contracts.
import * as archive_repository from '../archive/repository.js';
import * as source_guard from '../archive/sourceReadGuard.js';
import * as archive_library from '../archive/library.js';
import * as generation_imageGeneration from '../generation/imageGeneration.js';
import * as core_constants from '../core/constants.js';
import * as core_context from '../core/context.js';
import * as core_independentApi from '../core/independentApi.js';
import * as core_requestCoordinator from '../core/requestCoordinator.js';
import * as core_settings from '../core/settings.js';
import * as floating_archive from './floatingArchive.js';
import { state as runtimeState } from '../core/state.js';
import * as core_text from '../core/text.js';
import * as core_theme from '../core/theme.js';
import * as core_autoUpdatePolicy from '../core/autoUpdatePolicy.js';
import * as core_autoUpdates from '../core/autoUpdates.js';
import * as core_selfUpdater from '../core/selfUpdater.js';
import * as core_contextTags from '../core/contextTags.js';
import * as core_chatReadRange from '../core/chatReadRange.js';
import * as ui_archivePortal from './archivePortal.js';
import * as ui_overlay from './overlay.js';
import * as ui_styles from './styles.js';

let imageProviderEventCleanup = null;
let homeSettingsPanel = null;
let homeSettingsEpoch = -1;
let homeSettingsScope = '';
let memoryFilePreviewEpoch = 0;
export const SETTINGS_LAUNCHER_ID = core_constants.SETTINGS_ID + '_launcher';

export function clearHomeSettingsPanel() {
    homeSettingsPanel?.remove(); homeSettingsPanel = null; homeSettingsEpoch = -1;
    pendingMemoryFilePreview = null; memoryIngressRequestEpoch += 1; memoryFilePreviewEpoch += 1;
    homeSettingsScope = '';
    document.getElementById(SETTINGS_LAUNCHER_ID)?.remove();
}

export function refreshImageGenerationSettingsUi() {
    const panel = document.getElementById(core_constants.SETTINGS_ID);
    if (!panel) return;
    const settings = core_settings.getPluginSettings();
    const choice = panel.querySelector('[data-rmt-image-generation-provider]');
    if (choice) choice.value = settings.imageGenerationProvider;
    const statusNode = panel.querySelector('[data-rmt-image-generation-status]');
    const status = generation_imageGeneration.imageGenerationUiState();
    if (statusNode) statusNode.textContent = status.available ? '柏宝绘已连接 · 公开 API v1' : status.reason || '请单独安装、启用并配置柏宝绘公开 API v1。';
}

export function chatReadingSettingsHtml(settings = core_settings.getPluginSettings()) {
    const range = settings.chatReadRange || { mode: 'recent', recent: 50, start: 1, end: 100, includeHidden: false };
    return `<details class="rmt-settings-card" data-rmt-settings-section="reading">
      <summary class="rmt-settings-card-head"><span>READ</span><div><b>聊天读取范围</b><small>按原始楼号选择 · 不改旧档案</small></div></summary>
      <div class="rmt-settings-section-body">
        <label class="rmt-settings-field"><span>读取方式</span><select class="text_pole" data-rmt-read-mode><option value="recent" ${range.mode === 'recent' ? 'selected' : ''}>最近若干楼</option><option value="range" ${range.mode === 'range' ? 'selected' : ''}>指定楼号范围</option><option value="all" ${range.mode === 'all' ? 'selected' : ''}>当前聊天全部楼层</option></select></label>
        <label class="rmt-settings-field" data-rmt-read-recent-row ${range.mode === 'recent' ? '' : 'hidden'}><span>最近多少楼</span><input class="text_pole" type="number" min="1" step="1" data-rmt-read-recent value="${core_text.esc(range.recent)}"></label>
        <div class="rmt-api-grid" data-rmt-read-range-row ${range.mode === 'range' ? '' : 'hidden'}><label class="rmt-settings-field"><span>从第几楼</span><input class="text_pole" type="number" min="1" step="1" data-rmt-read-start value="${core_text.esc(range.start)}"></label><label class="rmt-settings-field"><span>到第几楼</span><input class="text_pole" type="number" min="1" step="1" data-rmt-read-end value="${core_text.esc(range.end)}"></label></div>
        <label class="rmt-settings-check"><input type="checkbox" data-rmt-read-hidden ${range.includeHidden ? 'checked' : ''}><span>包含范围内被隐藏的普通聊天楼层</span></label>
        <p>每条消息为一楼，从 1 开始，隐藏楼层仍保留原楼号。只限制聊天正文；世界书与外部记忆摘要仍按“记忆来源”单独读取。不删除已有记忆。</p>
        <button type="button" class="menu_button rmt-settings-wide" data-rmt-read-preview>预览当前读取量（不生成）</button>
        <div data-rmt-read-preview-status role="status" aria-live="polite">默认只读最近 50 楼；可主动选择全部。</div>
      </div></details>`;
}

function refreshReadingSettingsUi(panel) {
    const range = core_settings.getPluginSettings().chatReadRange || { mode: 'recent', recent: 50, start: 1, end: 100, includeHidden: false };
    for (const field of ['mode', 'recent', 'start', 'end']) {
        const input = panel.querySelector('[data-rmt-read-' + field + ']');
        if (input) input.value = range[field];
    }
    const hidden = panel.querySelector('[data-rmt-read-hidden]');
    if (hidden) hidden.checked = range.includeHidden === true;
    const recentRow = panel.querySelector('[data-rmt-read-recent-row]');
    const rangeRow = panel.querySelector('[data-rmt-read-range-row]');
    if (recentRow) recentRow.hidden = range.mode !== 'recent';
    if (rangeRow) rangeRow.hidden = range.mode !== 'range';
}

export function bindImageProviderEvents() {
    if (imageProviderEventCleanup || typeof globalThis.addEventListener !== 'function') return;
    const changed = () => {
        refreshImageGenerationSettingsUi();
        generation_imageGeneration.refreshCgImageProviderBars();
    };
    globalThis.addEventListener('st-baibai-image:ready', changed);
    globalThis.addEventListener('st-baibai-image:changed', changed);
    imageProviderEventCleanup = () => {
        globalThis.removeEventListener('st-baibai-image:ready', changed);
        globalThis.removeEventListener('st-baibai-image:changed', changed);
        imageProviderEventCleanup = null;
    };
}

export function unbindImageProviderEvents() { imageProviderEventCleanup?.(); }

let pendingMemoryFilePreview = null;
let memoryIngressRequestEpoch = 0;

export async function refreshMemoryIngressUi() {
    const requestEpoch = ++memoryIngressRequestEpoch;
    const panel = document.getElementById(core_constants.SETTINGS_ID);
    if (!panel) return;
    const status = panel.querySelector('[data-rmt-memory-ingress-status]');
    const details = panel.querySelector('[data-rmt-memory-source-list]');
    const historyBooks = panel.querySelector('[data-rmt-memory-history-books]');
    let capturedScopeKey = '';
    const isCurrent = () => {
        if (requestEpoch !== memoryIngressRequestEpoch || !capturedScopeKey) return false;
        try {
            const liveContext = core_context.currentCharacterGuard();
            return archive_repository.memorySourceScopeForContext(liveContext).key === capturedScopeKey;
        } catch { return false; }
    };
    try {
        const context = core_context.currentCharacterGuard();
        capturedScopeKey = archive_repository.memorySourceScopeForContext(context).key;
        const summary = await archive_repository.currentMemorySourceLedgerSummary(context);
        if (!isCurrent()) return;
        const preflight = archive_repository.getMemoryPreflight(context);
        const displayedSources = [...summary.sources];
        for (const source of preflight?.sources || []) {
            const latest = { provider: source.label || source.id, id: source.id, coverage: source.coverage, count: source.count };
            const index = displayedSources.findIndex(item => (item.provider || item.id) === source.id);
            if (index >= 0) displayedSources[index] = latest;
            else displayedSources.push(latest);
        }
        if (status) status.textContent = summary.sources.length
            ? `● 已保存 ${summary.sources.length} 个来源 · ${summary.recordCount} 条记录 · ${summary.totalChars.toLocaleString()} 字符`
            : '○ 当前聊天还没有已保存来源';
        if (details) {
            details.replaceChildren();
            for (const source of displayedSources) {
                const row = document.createElement('div');
                const coverage = source.coverage?.status || 'partial';
                const labels = { complete: '完整', partial: '部分', truncated: '已截断', failed: '失败' };
                row.textContent = `${labels[coverage] || '部分'} · ${source.label || source.provider || source.id}${source.coverage?.returned ? ` · ${source.coverage.returned} 条` : ''}${source.coverage?.reason ? ` · ${source.coverage.reason}` : ''}`;
                details.appendChild(row);
            }
            if (!details.childElementCount) details.textContent = '暂无持久化来源。';
        }
        if (historyBooks) {
            const selection = archive_repository.getMemoryWorldInfoSelection(context);
            historyBooks.innerHTML = selection.books.length
                ? selection.books.map(book => `<label class="checkbox_label rmt-settings-check"><input type="checkbox" data-rmt-memory-history-book="${core_text.esc(book.name)}" ${book.historySource ? 'checked' : ''}> ${core_text.esc(book.name)} · 作为历史摘要</label>`).join('')
                : '<small>请先在档案室选择记忆相关世界书；默认仍只作设定解释。</small>';
        }
    } catch (error) {
        if (capturedScopeKey && !isCurrent()) return;
        if (status) status.textContent = capturedScopeKey
            ? '○ ' + core_text.safeErrorSummary({ code: 'RMT_LEDGER_UNAVAILABLE' })
            : '○ 请先打开一个单角色聊天，再查看该聊天的来源账本。';
        if (details) details.textContent = '无法读取当前聊天来源。';
        if (historyBooks) historyBooks.textContent = '请先打开单角色聊天。';
    }
}

export async function refreshModelOptions({ fetchRemote = false } = {}) {
    const panel = document.getElementById(core_constants.SETTINGS_ID);
    if (!panel) return;
    const select = panel.querySelector('[data-rmt-api-model]');
    const refreshButton = panel.querySelector('[data-rmt-api-model-refresh]');
    if (!select) return;
    const requestEpoch = Number(panel.dataset.rmtProfileModelRequest || 0) + 1;
    panel.dataset.rmtProfileModelRequest = String(requestEpoch);
    const settings = core_settings.getPluginSettings();
    const profileId = core_text.normalizeText(settings.connectionProfileId, 160);
    const configurationEpoch = runtimeState.apiConfigurationEpoch;
    let profileCacheKey = '';
    let profileStateFingerprint = '';
    let profile;
    try { profile = profileId ? core_settings.rawConnectionProfile(profileId) : null; } catch { profile = null; }
    profileStateFingerprint = profile ? core_settings.profileFingerprint(profile) : 'missing';
    try { profileCacheKey = profileId ? await core_settings.resolvedProfileModelCacheKey(profileId) : ''; } catch {}
    const isCurrent = () => Number(panel.dataset.rmtProfileModelRequest || 0) === requestEpoch
        && runtimeState.apiConfigurationEpoch === configurationEpoch
        && core_settings.getPluginSettings().connectionProfileId === profileId
        && (() => {
            try {
                if (!profileId) return true;
                return core_settings.profileFingerprint(core_settings.rawConnectionProfile(profileId)) === profileStateFingerprint;
            }
            catch { return false; }
        })();
    if (refreshButton) {
        refreshButton.disabled = fetchRemote || !profileId;
        refreshButton.textContent = fetchRemote ? '正在拉取…' : '刷新模型';
    }
    if (!profileId) {
        const defaultOption = document.createElement('option');
        defaultOption.value = '';
        defaultOption.textContent = '请先选择专用连接';
        select.replaceChildren(defaultOption);
        select.disabled = true;
        return { models: [], fallbackOnly: false };
    }
    const profileModel = core_text.normalizeText(profile?.model, 240);
    select.disabled = fetchRemote;
    let models = [];
    let fallbackOnly = false;
    try {
        if (fetchRemote) {
            const result = await core_settings.fetchModelsForConnection(profileId, { force: true, returnMeta: true });
            models = result.models;
            fallbackOnly = result.fallbackOnly;
        } else {
            models = runtimeState.connectionModelCache.get(profileCacheKey) || core_settings.savedModelsForProfile(profileId);
        }
    } catch (error) {
        if (!isCurrent() || error?.code === 'RMT_API_MODEL_REQUEST_SUPERSEDED' || error?.name === 'AbortError') return null;
        console.warn('[HeartbeatMemories] refresh model options failed', core_text.safeErrorDiagnostic(error));
        if (!fetchRemote) {
            models = profileModel ? [profileModel] : [];
        } else {
            if (refreshButton) {
                refreshButton.disabled = false;
                refreshButton.textContent = '刷新模型';
            }
            select.disabled = false;
            throw error;
        }
    }
    if (!isCurrent()) return null;
    const currentSettings = core_settings.getPluginSettings();
    const override = core_text.normalizeText(currentSettings.modelOverride, 240);
    if (override && !models.includes(override)) models.unshift(override);
    const defaultOption = document.createElement('option');
    defaultOption.value = '';
    defaultOption.textContent = profileModel ? `使用配置默认模型 · ${profileModel}` : '使用配置默认模型';
    select.replaceChildren(defaultOption);
    for (const model of [...new Set(models)]) {
        if (!model) continue;
        const option = document.createElement('option');
        option.value = model;
        option.textContent = model;
        select.appendChild(option);
    }
    select.value = override;
    select.disabled = false;
    if (refreshButton) {
        refreshButton.disabled = false;
        refreshButton.textContent = '刷新模型';
    }
    return { models, fallbackOnly };
}

function manualSettingsFromPanel(panel) {
    const current = core_settings.getPluginSettings();
    const keyInput = panel?.querySelector?.('[data-rmt-manual-api-key]');
    const baseInput = panel?.querySelector?.('[data-rmt-manual-api-base]');
    const modelInput = panel?.querySelector?.('[data-rmt-manual-api-model]');
    const base = baseInput ? baseInput.value : current.manualApiBaseUrl;
    let sameBase = false;
    try { sameBase = core_independentApi.normalizeManualApiBaseUrl(base) === current.manualApiBaseUrl; } catch {}
    return {
        ...current,
        apiConnectionMode: 'manual',
        manualApiBaseUrl: base,
        manualApiKey: core_text.normalizeText(keyInput?.value, 4000) || (sameBase ? current.manualApiKey : ''),
        manualApiSecretRef: sameBase ? current.manualApiSecretRef : '',
        manualApiModel: modelInput ? modelInput.value : current.manualApiModel,
    };
}

const manualAutosaves = new WeakMap();
async function saveManualPanel(panel, activate = false) {
    clearTimeout(manualAutosaves.get(panel)); manualAutosaves.delete(panel);
    const status = panel.querySelector('[data-rmt-manual-save-status]');
    const candidate = manualSettingsFromPanel(panel);
    const keyInput = panel.querySelector('[data-rmt-manual-api-key]');
    const typedKey = keyInput?.value || '';
    if (status) status.textContent = '正在保存…';
    try {
        const result = await core_settings.saveManualApiConfiguration(candidate, { activate });
        if (keyInput?.value === typedKey) keyInput.value = '';
        if (keyInput) keyInput.placeholder = result.credentialSaved ? '已加密保存到本机；填写可替换' : 'API Key（可留空）';
        if (status) status.textContent = result.credentialSaved ? '连接信息与 Key 已保存到本机；刷新后可用。' : '连接信息已保存；未填写 Key。';
        if (activate) { panel.dataset.rmtApiEditor = 'manual'; panel.dataset.rmtManualDirty = '0'; refreshGenerationSettingsUi(); }
        return result;
    } catch (error) {
        if (status) status.textContent = error?.name === 'AbortError' ? '配置已再次编辑，旧保存已停止。' : core_text.safeErrorSummary(error);
        if (activate) globalThis.toastr?.error?.(core_text.safeErrorSummary(error), '心迹回廊 · 未保存');
        return null;
    }
}
function bindManualAutosave(panel) {
    const schedule = event => {
        if (!event.target.matches?.('[data-rmt-manual-api-base],[data-rmt-manual-api-key],[data-rmt-manual-api-model]')) return;
        clearTimeout(manualAutosaves.get(panel));
        manualAutosaves.set(panel, setTimeout(() => { void saveManualPanel(panel); }, event.type === 'change' ? 0 : 500));
    };
    panel.addEventListener('input', schedule); panel.addEventListener('change', schedule);
}

export async function refreshManualModelOptions({ fetchRemote = false } = {}) {
    const panel = document.getElementById(core_constants.SETTINGS_ID);
    if (!panel) return [];
    const input = panel.querySelector('[data-rmt-manual-api-model]');
    const list = panel.querySelector('[data-rmt-manual-api-models]');
    const button = panel.querySelector('[data-rmt-manual-api-model-refresh]');
    if (!input || !list) return [];
    const candidate = manualSettingsFromPanel(panel);
    const signature = core_independentApi.apiConfigurationFingerprint(candidate);
    const requestEpoch = Number(panel.dataset.rmtManualModelRequest || 0) + 1;
    panel.dataset.rmtManualModelRequest = String(requestEpoch);
    const isCurrent = () => Number(panel.dataset.rmtManualModelRequest || 0) === requestEpoch
        && core_independentApi.apiConfigurationFingerprint(manualSettingsFromPanel(panel)) === signature;
    if (button) {
        button.disabled = fetchRemote;
        button.textContent = fetchRemote ? '正在拉取…' : '拉取模型';
    }
    let models = runtimeState.connectionModelCache.get(core_independentApi.manualModelCacheKey(candidate)) || [];
    panel.dataset.rmtManualModelFallback = '0';
    try {
        if (fetchRemote) models = await core_settings.fetchModelsForManualConnection(candidate, { force: true });
    } catch (error) {
        if (!isCurrent() || error?.code === 'RMT_API_MODEL_REQUEST_SUPERSEDED' || error?.name === 'AbortError') return null;
        const savedModel = core_text.normalizeText(candidate.manualApiModel, 240);
        models = [...new Set([...(models || []), savedModel].filter(Boolean))];
        if (!models.length) {
            if (button) { button.disabled = false; button.textContent = '拉取模型'; }
            throw error;
        }
        panel.dataset.rmtManualModelFallback = '1';
    }
    if (!isCurrent()) return null;
    const uniqueModels = [...new Set(models)].filter(Boolean);
    const placeholder = document.createElement('option');
    placeholder.value = '';
    placeholder.textContent = uniqueModels.length ? `选择已拉取模型（${uniqueModels.length}）` : '没有可用模型';
    list.replaceChildren(placeholder);
    for (const model of uniqueModels) {
        const option = document.createElement('option');
        option.value = model;
        option.textContent = model;
        list.appendChild(option);
    }
    list.hidden = uniqueModels.length === 0;
    list.value = uniqueModels.includes(input.value) ? input.value : '';
    if (!input.value && uniqueModels[0]) {
        input.value = uniqueModels[0];
        list.value = uniqueModels[0];
        panel.dataset.rmtManualDirty = '1';
    }
    if (button) {
        button.disabled = false;
        button.textContent = '拉取模型';
    }
    return models;
}

function refreshThemeUi() {
    const settings = core_settings.getPluginSettings();
    for (const element of document.querySelectorAll('#' + core_constants.SETTINGS_ID + ',#' + core_constants.OVERLAY_ID + ',.rmt-avatar-dialog-pop')) core_theme.applyThemeToElement(element, settings);
    const panel = document.getElementById(core_constants.SETTINGS_ID);
    const custom = panel?.querySelector('[data-rmt-theme-custom-panel]');
    if (custom) custom.hidden = settings.themeMode !== 'custom';
    const opacity = panel?.querySelector('[data-rmt-theme-opacity]');
    if (opacity) opacity.textContent = Math.round(settings.themeAlpha * 100) + '%';
}

export function refreshGenerationSettingsUi() {
    const panel = document.getElementById(core_constants.SETTINGS_ID);
    if (!panel) return;
    const settings = core_settings.getPluginSettings();
    refreshThemeUi();
    const connectionMode = settings.apiConnectionMode === 'manual' ? 'manual' : 'profile';
    const editorMode = panel.dataset.rmtApiEditor === 'manual' || panel.dataset.rmtApiEditor === 'profile'
        ? panel.dataset.rmtApiEditor
        : connectionMode;
    panel.dataset.rmtApiEditor = editorMode;
    const profile = panel.querySelector('[data-rmt-api-profile]');
    const oneClick = panel.querySelector('[data-rmt-api-import-current]');
    const capability = panel.querySelector('[data-rmt-api-host-capability]');
    if (capability) capability.textContent = core_settings.oneClickConnectionCapability().message;
    const manualChoice = panel.querySelector('[data-rmt-api-select-manual]');
    const profilePanel = panel.querySelector('[data-rmt-api-profile-panel]');
    const manualPanel = panel.querySelector('[data-rmt-api-manual-panel]');
    const manualBase = panel.querySelector('[data-rmt-manual-api-base]');
    const manualKey = panel.querySelector('[data-rmt-manual-api-key]');
    const manualModel = panel.querySelector('[data-rmt-manual-api-model]');
    const maxTokens = panel.querySelector('[data-rmt-api-max-tokens]');
    const temperature = panel.querySelector('[data-rmt-api-temperature]');
    const roomDaily = panel.querySelector('[data-rmt-room-life-auto]');
    const manualStreaming = panel.querySelector('[data-rmt-manual-streaming]');
    const ttDisplay = panel.querySelector('[data-rmt-tt-display]');
    const themeMode = panel.querySelector('[data-rmt-theme-mode]');
    const themeAlpha = panel.querySelector('[data-rmt-theme-alpha]');
    const themeCustomPanel = panel.querySelector('[data-rmt-theme-custom-panel]');
    const bannedPhrases = panel.querySelector('[data-rmt-banned-generated-phrases]');
    const status = panel.querySelector('[data-rmt-api-status]');
    if (profile) {
        const profiles = core_settings.supportedConnectionProfiles();
        profile.replaceChildren();
        const empty = document.createElement('option');
        empty.value = '';
        empty.textContent = profiles.length ? '选择 Connection Manager 配置' : '没有可用的连接配置';
        profile.appendChild(empty);
        for (const item of profiles) {
            const option = document.createElement('option');
            option.value = item.id;
            option.textContent = `${item.name}${item.model ? ` · ${item.model}` : ''}`;
            profile.appendChild(option);
        }
        profile.value = profiles.some(item => item.id === settings.connectionProfileId) ? settings.connectionProfileId : '';
    }
    if (oneClick) {
        oneClick.classList.toggle('is-active', editorMode === 'profile');
        oneClick.setAttribute('aria-pressed', editorMode === 'profile' ? 'true' : 'false');
    }
    if (manualChoice) {
        manualChoice.classList.toggle('is-active', editorMode === 'manual');
        manualChoice.setAttribute('aria-pressed', editorMode === 'manual' ? 'true' : 'false');
    }
    if (profilePanel) profilePanel.hidden = editorMode !== 'profile';
    if (manualPanel) manualPanel.hidden = editorMode !== 'manual';
    const manualDirty = panel.dataset.rmtManualDirty === '1';
    if (!manualDirty && manualBase) manualBase.value = settings.manualApiBaseUrl;
    if (!manualDirty && manualModel) manualModel.value = settings.manualApiModel;
    if (!manualDirty && manualKey) {
        manualKey.value = '';
        manualKey.placeholder = settings.manualApiSecretRef ? '已加密保存到本机；填写可替换' : settings.manualApiKey ? '本页已有 Key；尚未确认持久保存' : 'API Key（可留空）';
    }
    if (maxTokens) maxTokens.value = String(settings.maxTokens);
    if (temperature) {
        temperature.value = String(settings.temperature);
        temperature.disabled = false;
        temperature.title = '覆盖心迹回廊专用连接的温度';
    }
    if (roomDaily) roomDaily.checked = settings.roomLifeAutoDaily;
    if (manualStreaming) manualStreaming.checked = settings.manualApiStreaming === true;
    const externalSource = panel.querySelector('[data-rmt-source-external]');
    const worldInfoSource = panel.querySelector('[data-rmt-source-world-info]');
    if (externalSource) externalSource.checked = settings.useCurrentChatExternalMemory !== false;
    if (worldInfoSource) worldInfoSource.checked = settings.useActivatedWorldInfo !== false;
    refreshImageGenerationSettingsUi();
    if (ttDisplay) ttDisplay.checked = settings.ttDisplayMode;
    const floatingAvatar = panel.querySelector('[data-rmt-floating-avatar]');
    if (floatingAvatar) floatingAvatar.value = settings.floatingAvatar;
    if (themeMode) themeMode.value = settings.themeMode;
    const autoRules = core_autoUpdatePolicy.normalizeAutoUpdates(settings.autoUpdates);
    for (const input of panel.querySelectorAll('[data-rmt-auto-enabled]')) input.checked = autoRules[input.dataset.rmtAutoEnabled]?.enabled === true;
    for (const input of panel.querySelectorAll('[data-rmt-auto-every]')) input.value = String(autoRules[input.dataset.rmtAutoEvery]?.every || 20);
    const autoWarning = panel.querySelector('[data-rmt-auto-warning]');
    if (autoWarning) autoWarning.textContent = core_autoUpdates.autoUpdateAvailability();
    core_autoUpdates.refreshAutoUpdateStatus();
    if (themeAlpha) themeAlpha.value = String(settings.themeAlpha);
    if (themeCustomPanel) themeCustomPanel.hidden = settings.themeMode !== 'custom';
    for (const input of panel.querySelectorAll('[data-rmt-theme-color]')) {
        const key = input.dataset.rmtThemeColor;
        if (key && settings.themeCustom?.[key]) input.value = settings.themeCustom[key];
    }
    if (bannedPhrases) bannedPhrases.value = settings.bannedGeneratedPhrases.join('，');
    if (status) {
        let profileCapabilityReady = false;
        let manualConfigurationReady = false;
        if (connectionMode === 'profile' && settings.connectionProfileId) {
            try {
                core_independentApi.assertConnectionManagerProfileSupport(core_context.getContext().ConnectionManagerRequestService);
                profileCapabilityReady = true;
            } catch {}
        }
        if (connectionMode === 'manual' && settings.manualApiModel) {
            try {
                core_independentApi.assertManualApiCredentialTransport(settings.manualApiBaseUrl, settings.manualApiKey);
                manualConfigurationReady = true;
            } catch {}
        }
        const ready = connectionMode === 'manual'
            ? manualConfigurationReady
            : !!settings.connectionProfileId && profileCapabilityReady;
        status.classList.toggle('is-ready', ready);
        status.textContent = `${ready ? '●' : '○'} ${ready
            ? core_settings.generationSourceLabel(settings)
            : connectionMode === 'manual' ? '手动配置未完成'
            : settings.connectionProfileId ? '需凭证绑定能力，可改用手动配置' : '一键连接未配置'}`;
    }
    void refreshModelOptions();
    void refreshManualModelOptions();
}

export function hydrateSettingsPanel({ memory = false } = {}) {
    const panel = document.getElementById(core_constants.SETTINGS_ID);
    if (!panel) return false;
    refreshSettingsMemoryStatus({ lightweight: true });
    if (memory) void refreshMemoryIngressUi();
    if (panel.dataset.rmtHydrated === '1') return true;
    refreshGenerationSettingsUi();
    panel.dataset.rmtHydrated = '1';
    return true;
}

export function refreshSettingsTaskStatus() {
    const panel = document.getElementById(core_constants.SETTINGS_ID);
    if (!panel) return;
    const openButton = panel.querySelector('[data-rmt-settings-open-archive]');
    const taskRows = new Map();
    for (const [key, task] of runtimeState.activeGenerationTasks.entries()) {
        const logicalKey = core_text.normalizeText(task?.parentTaskKey, 240)
            || core_requestCoordinator.activeModeBuildScopeForTask(key)
            || key;
        taskRows.set(logicalKey, task);
    }
    for (const [key, reservation] of runtimeState.activeArchiveTargetReservations.entries()) {
        if (!taskRows.has(key)) taskRows.set(key, { ...reservation, origin: { archiveTargetEntryId: reservation.entryId } });
    }
    const taskCount = taskRows.size;
    const targetTasks = [...taskRows.values()].filter(task => core_text.normalizeText(task?.origin?.archiveTargetEntryId || task?.entryId, 120));
    const targetTaskLabel = core_text.normalizeText(targetTasks[0]?.label, 220);
    if (openButton) {
        openButton.disabled = false;
        openButton.textContent = runtimeState.busy
            ? '打开档案室 · 档案整理中'
            : targetTaskLabel
                ? `${targetTaskLabel}${targetTasks.length > 1 ? ` · 另有${targetTasks.length - 1}项` : ''}`
                : taskCount ? `打开档案室 · ${taskCount}项生成中` : '打开档案室';
        openButton.title = targetTaskLabel ? targetTasks.map(task => core_text.normalizeText(task?.label, 300)).filter(Boolean).join('\n') : '';
    }
}

export function refreshSettingsMemoryStatus({ lightweight = false } = {}) {
    const panel = document.getElementById(core_constants.SETTINGS_ID);
    if (!panel) return;
    refreshSettingsTaskStatus();
    const worldInfoPicker = panel.querySelector('[data-rmt-action="memory-worldinfo-picker"]');
    if (worldInfoPicker) worldInfoPicker.disabled = runtimeState.busy || core_requestCoordinator.hasGenerationTasks();
    const archiveButton = panel.querySelector('[data-rmt-settings-current-archive]');
    if (archiveButton) {
        let ready = false;
        let actionable = false;
        let mismatch = null;
        try {
            const context = core_context.currentCharacterGuard();
            actionable = !!core_context.getChatId(context);
            ready = lightweight
                ? !!archive_repository.getImportedMemory(context)
                : archive_repository.getMemoryState(context).status === 'ready';
            // An archive whose only problem is a different chat id used to dead-end here:
            // unreadable, and blocking a new one. Surface the way out on this very button.
            if (!ready) mismatch = archive_repository.mismatchedArchiveInfo(context);
        } catch {}
        archiveButton.disabled = runtimeState.busy || core_requestCoordinator.hasGenerationTasks() || !actionable;
        archiveButton.dataset.rmtArchiveClaim = mismatch ? '1' : '';
        const archiveLabelNode = archiveButton.querySelector('span') || archiveButton;
        archiveLabelNode.textContent = !actionable
            ? '当前窗口档案不可用'
            : runtimeState.busy ? '当前窗口档案整理中…'
            : mismatch ? `认领这份档案（${mismatch.memoryCount} 条记忆）`
            : ready ? '增量更新当前窗口档案' : '生成当前窗口档案';
        archiveButton.title = mismatch
            ? '这个聊天里存着一份档案，但它记录的聊天标识与当前不同（重命名、分支或复制聊天后会这样）。认领只改变绑定，不改动任何记忆内容。'
            : '';
    }
}

export function mountSettings({ homeTarget = null } = {}) {
    ui_styles.ensureSettingsStyles();
    if (!homeTarget) {
        document.getElementById(SETTINGS_LAUNCHER_ID)?.remove();
        // The full settings and normal diagnostics entry belong to Hearttrace home.
        return true;
    }
    const existing = homeSettingsEpoch === runtimeState.runtimeLifecycleEpoch ? homeSettingsPanel : null;
    let scope = '';
    try { scope = core_context.chatScopeKey(core_context.currentCharacterGuard()); } catch {}
    if (scope !== homeSettingsScope) {
        homeSettingsScope = scope;
        pendingMemoryFilePreview = null; memoryIngressRequestEpoch += 1; memoryFilePreviewEpoch += 1;
        const preview = existing?.querySelector('[data-rmt-memory-file-preview]');
        if (preview) preview.hidden = true;
        const status = existing?.querySelector('[data-rmt-memory-ingress-status]');
        if (status) status.textContent = '聊天已切换；展开记忆来源后查看状态。';
        const sourceList = existing?.querySelector('[data-rmt-memory-source-list]');
        const historyBooks = existing?.querySelector('[data-rmt-memory-history-books]');
        if (sourceList) sourceList.textContent = '';
        if (historyBooks) historyBooks.textContent = '';
    }
    if (existing) {
        homeTarget.appendChild(existing);
        refreshSettingsMemoryStatus({ lightweight: true });
        if (existing.dataset.rmtHydrated === '1') refreshGenerationSettingsUi();
        return true;
    }
    const mount = homeTarget;
    const panel = document.createElement('div');
    panel.id = core_constants.SETTINGS_ID;
    panel.className = 'rmt-home-settings';
    homeSettingsPanel = panel; homeSettingsEpoch = runtimeState.runtimeLifecycleEpoch;
    panel.innerHTML = `
      <div class="inline-drawer-toggle inline-drawer-header rmt-settings-header">
        <div><b>心迹回廊</b><small> API SETTINGS</small></div>
        <div class="inline-drawer-icon fa-solid fa-circle-chevron-down down"></div>
      </div>
      <div class="inline-drawer-content rmt-settings-content">
        <details class="rmt-settings-card rmt-api-box" data-rmt-settings-section="api">
          <summary class="rmt-settings-card-head"><span>API</span><div><b>独立 API</b><small>一键配置 · 手动配置</small></div></summary>
          <div class="rmt-settings-section-body">
          <div class="rmt-api-source-grid" role="group" aria-label="独立 API 配置方式">
            <button type="button" class="menu_button rmt-api-source-card" data-rmt-api-import-current aria-pressed="false"><span class="rmt-api-source-badge">凭证绑定</span><b>一键配置</b><small>读取酒馆当前连接</small></button>
            <button type="button" class="menu_button rmt-api-source-card" data-rmt-api-select-manual aria-pressed="false"><span class="rmt-api-source-badge">OPENAI</span><b>手动配置</b><small>URL · Key · 模型</small></button>
          </div>
          <div data-rmt-api-host-capability role="status"></div>
          <div class="rmt-api-status" data-rmt-api-status role="status">○ 一键连接未配置</div>
          <div class="rmt-api-source-panel" data-rmt-api-profile-panel>
            <label class="rmt-settings-field"><span>连接配置</span><select class="text_pole" data-rmt-api-profile><option value="">选择 Connection Manager 配置</option></select></label>
            <div class="rmt-model-row">
              <label class="rmt-settings-field"><span>模型</span><select class="text_pole" data-rmt-api-model><option value="">请先选择专用连接</option></select></label>
              <button type="button" class="menu_button rmt-model-refresh" data-rmt-api-model-refresh>刷新模型</button>
            </div>
          </div>
          <div class="rmt-api-source-panel" data-rmt-api-manual-panel hidden>
            <label class="rmt-settings-field"><span>API 地址</span><input class="text_pole" data-rmt-manual-api-base type="url" inputmode="url" placeholder="https://api.example.com/v1"></label>
            <label class="rmt-settings-field"><span>API Key</span><div class="rmt-manual-key-row"><input class="text_pole" data-rmt-manual-api-key type="password" autocomplete="new-password" placeholder="API Key（可留空）"><button type="button" class="menu_button" data-rmt-manual-api-key-clear>清除 Key</button></div></label>
            <div class="rmt-model-row">
              <label class="rmt-settings-field"><span>模型 ID</span><input class="text_pole" data-rmt-manual-api-model type="text" placeholder="例如 gpt-4.1"><select class="text_pole rmt-manual-model-picker" data-rmt-manual-api-models hidden><option value="">选择已拉取模型</option></select></label>
              <button type="button" class="menu_button rmt-model-refresh" data-rmt-manual-api-model-refresh>拉取模型</button>
            </div>
            <button type="button" class="menu_button rmt-settings-wide rmt-manual-save" data-rmt-manual-api-save>保存并使用</button>
            <div data-rmt-manual-save-status role="status" aria-live="polite">填写后自动保存到本机，不随档案导出。</div>
            <label class="rmt-settings-check"><input type="checkbox" data-rmt-manual-streaming ${core_settings.getPluginSettings().manualApiStreaming ? 'checked' : ''}><span>使用流式输出（仅此手动 API）</span></label>
            <small>需要服务端支持 SSE；关闭时使用普通完整响应，不影响主聊天。</small>
          </div>
          <div class="rmt-api-grid">
            <label class="rmt-settings-field"><span>最大输出</span><input class="text_pole" data-rmt-api-max-tokens type="number" min="1" step="1" placeholder="默认 60000"></label>
            <label class="rmt-settings-field"><span>温度</span><input class="text_pole" data-rmt-api-temperature type="number" min="0" max="2" step="0.1"></label>
          </div>
          <label class="rmt-settings-field"><span>生成禁用词</span><input class="text_pole" data-rmt-banned-generated-phrases type="text" placeholder="用逗号分隔，例如：老子"></label>
          <p>打开房间只读已有内容；“今日生活”由房间里的手动更新按钮触发，不会在进入时自动请求。</p>
          <label class="rmt-settings-check"><input data-rmt-tt-display type="checkbox"><span>TT 顶部安全区</span></label>
          </div>
        </details>
        ${advanced_ui.advancedGenerationHtml()}
        ${chatReadingSettingsHtml()}
        <details class="rmt-settings-card" data-rmt-settings-section="image">
          <summary class="rmt-settings-card-head"><span>CG</span><div><b>CG 生图</b><small>相簿 · ADV · 日常一格</small></div></summary>
          <div class="rmt-settings-section-body">
            ${cg_format_ui.cgFormatControlHtml()}
            <label class="rmt-settings-field"><span>生图渠道</span><select class="text_pole" data-rmt-image-generation-provider aria-describedby="rmt-image-provider-status"><option value="baibai-image">柏宝绘 · 公开 API v1</option></select></label>
            <p id="rmt-image-provider-status" data-rmt-image-generation-status role="status" aria-live="polite"></p>
            <p>柏宝绘需单独安装并配置出图渠道。只在点击绘制并确认后出图，失败不会自动换渠道。</p>
          </div>
        </details>
        <details class="rmt-settings-card" data-rmt-settings-section="creative">
          <summary class="rmt-settings-card-head"><span>文</span><div><b>创作补充词</b><small>仅用于心迹回廊独立 API</small></div></summary>
          <div class="rmt-settings-section-body">
            <label class="rmt-settings-check"><input type="checkbox" data-rmt-creative-enabled><span>启用创作补充词</span></label>
            <label class="rmt-settings-field"><span>文风、氛围与叙事偏好</span><textarea class="text_pole" data-rmt-creative-text maxlength="20000" rows="8" placeholder="例如：少用总结式旁白，让情绪从对白和细节中自然流露。"></textarea></label>
            <p><output data-rmt-creative-count>0 / 20,000</output> 字符。仅随心迹回廊文本生成发送，不写入主聊天、不发送给生图接口；会占用模型输入额度。</p>
            <div class="rmt-theme-presets"><button type="button" data-rmt-creative-save>保存补充词</button><button type="button" data-rmt-creative-cancel>撤销编辑</button></div>
            <div role="status" data-rmt-creative-status></div>
          </div>
        </details>
        <details class="rmt-settings-card" data-rmt-settings-section="filter">
          <summary class="rmt-settings-card-head"><span>TAG</span><div><b>按用户所选标签保存</b><small>勾选保留</small></div></summary>
          <div class="rmt-settings-section-body">
            <p>勾选的标签块参与后续整理；未选外层块连同内部略过，无标签正文保留。不改聊天和旧档案。</p>
            <textarea class="text_pole" data-rmt-tag-draft aria-label="要保存的标签名" placeholder="正文, content, dialogue"></textarea>
            <div class="rmt-theme-presets"><button type="button" data-rmt-tag-scan>扫描当前聊天</button><button type="button" data-rmt-tag-all>全选</button><button type="button" data-rmt-tag-invert>反选</button><button type="button" data-rmt-tag-clear>清空选择</button><button type="button" data-rmt-tag-cancel>撤销编辑</button><button type="button" data-rmt-tag-save>保存选择</button></div>
            <div data-rmt-tag-status role="status"></div>
            <div data-rmt-tag-results></div>
          </div>
        </details>
        <details class="rmt-settings-card rmt-theme-box" data-rmt-settings-section="theme">
          <summary class="rmt-settings-card-head"><span>UI</span><div><b>界面主题</b><small>配色与透明度</small></div></summary>
          <div class="rmt-settings-section-body">
          <label class="rmt-settings-field"><span>外观</span><select class="text_pole" data-rmt-theme-mode><option value="default">日间 · 珍珠白</option><option value="night">夜间 · 星黛蓝</option><option value="gs1">初叶绿</option><option value="gs2">海盐蓝</option><option value="gs3">花漾粉</option><option value="gs4">杏糖橙</option><option value="host">跟随酒馆美化</option><option value="custom">自定义配色</option></select></label>
          <label class="rmt-settings-field"><span>悬浮头像</span><select class="text_pole" data-rmt-floating-avatar><option value="char">角色 char（默认）</option><option value="user">用户 user</option><option value="off">关闭</option></select></label>
          <label class="rmt-settings-field"><span>卡片不透明度 <output data-rmt-theme-opacity></output></span><input data-rmt-theme-alpha type="range" min="0.72" max="1" step="0.01"></label>
          <div class="rmt-theme-custom-panel" data-rmt-theme-custom-panel>
            <div class="rmt-theme-presets"><button type="button" data-rmt-theme-preset="day">从日间开始</button><button type="button" data-rmt-theme-preset="night">从夜间开始</button></div>
            <label><span>背景</span><input type="color" data-rmt-theme-color="background"></label>
            <label><span>卡片</span><input type="color" data-rmt-theme-color="surface"></label>
            <label><span>主文字</span><input type="color" data-rmt-theme-color="text"></label>
            <label><span>次文字</span><input type="color" data-rmt-theme-color="muted"></label>
            <label><span>选中与装饰色</span><input type="color" data-rmt-theme-color="accent"></label>
            <label><span>第二装饰色</span><input type="color" data-rmt-theme-color="accentAlt"></label>
            <label><span>边框</span><input type="color" data-rmt-theme-color="border"></label>
          </div>
          <button type="button" class="menu_button rmt-settings-wide" data-rmt-theme-reset>恢复默认配色</button>
          </div>
        </details>
        <details class="rmt-settings-card" data-rmt-settings-section="auto">
          <summary class="rmt-settings-card-head"><span>↻</span><div><b>自动更新</b><small>跟随当前聊天 · 每项独立设置</small></div></summary>
          <div class="rmt-settings-section-body">
          <p>只在已有档案的当前窗口运行。每条聊天消息算一楼，编辑不加楼；开启后从当前楼数起计。</p>
          <p>“档案同步”收录新聊天；其他模块使用已归档记忆，不改旧内容。会调用独立 API。</p>
          <div class="rmt-auto-rules">${core_autoUpdatePolicy.AUTO_UPDATE_MODES.map(mode => `<div class="rmt-auto-rule"><label><input type="checkbox" data-rmt-auto-enabled="${mode}"> ${core_text.esc(mode === 'archive' ? '档案同步' : core_constants.MODE_LABEL[mode])}</label><label>每 <input type="number" min="1" max="1000" step="1" data-rmt-auto-every="${mode}" aria-label="${core_text.esc(mode === 'archive' ? '档案同步' : core_constants.MODE_LABEL[mode])}间隔楼层"> 楼</label><small data-rmt-auto-status="${mode}" role="status"></small></div>`).join('')}</div>
          <small data-rmt-auto-warning role="status"></small>
          <small>失败后不连续重试，等待下一个间隔；可随时手动生成。不支持跨页任务锁的浏览器仅保留手动操作。</small>
          </div>
        </details>
        <div class="rmt-settings-card">
          <button type="button" class="menu_button rmt-settings-wide" data-rmt-self-update>检查并更新插件</button>
          <small data-rmt-self-update-status role="status">强制检查已发布更新 · 完成后手动刷新页面</small>
        </div>
        <details class="rmt-settings-card rmt-api-box" data-rmt-settings-section="memory">
          <summary class="rmt-settings-card-head"><span>MEM</span><div><b>记忆来源</b><small>当前角色 · 当前聊天</small></div></summary>
          <div class="rmt-settings-section-body">
          <div class="rmt-api-source-grid" role="group" aria-label="记忆来源操作">
            <button type="button" class="menu_button rmt-api-source-card" data-rmt-memory-auto-read><span class="rmt-api-source-badge">AUTO</span><b>自动读取</b><small>已注册的当前聊天来源</small></button>
            <button type="button" class="menu_button rmt-api-source-card" data-rmt-memory-file-choose><span class="rmt-api-source-badge">FILE</span><b>导入记忆</b><small>JSON · JSONL · TXT · Markdown</small></button>
          </div>
          <label class="rmt-settings-check"><input type="checkbox" data-rmt-source-external ${core_settings.getPluginSettings().useCurrentChatExternalMemory !== false ? 'checked' : ''}><span>读取当前聊天的外部记忆摘要</span></label>
          <label class="rmt-settings-check"><input type="checkbox" data-rmt-source-world-info ${core_settings.getPluginSettings().useActivatedWorldInfo !== false ? 'checked' : ''}><span>读取自动激活的世界书</span></label>
          <p>聊天范围只控制聊天摘录。外部摘要、自动激活世界书分别由上方开关控制；手动选择的世界书仍按下方来源设置读取。已有档案不会被删除，派生模块仍使用已经归档的记忆。</p>
          <button type="button" class="menu_button rmt-settings-wide" data-rmt-action="memory-worldinfo-picker" ${runtimeState.busy || core_requestCoordinator.hasGenerationTasks() ? 'disabled' : ''}>选择记忆相关世界书</button>
          <button type="button" class="menu_button rmt-settings-wide" data-rmt-action="participants-picker">选择加入回廊的人物</button>
          <button type="button" class="menu_button rmt-settings-wide" data-rmt-action="participants-versions">查看重做前的旧版本</button>
          <input type="file" accept=".json,.jsonl,.txt,.md,.markdown,application/json,text/plain,text/markdown" data-rmt-memory-file-input hidden>
          <div class="rmt-api-status" data-rmt-memory-ingress-status role="status">展开记忆来源后查看状态；不会自动导入或生成。</div>
          <div class="rmt-api-source-panel" data-rmt-memory-file-preview hidden>
            <b data-rmt-memory-file-preview-title>待确认的记忆文件</b>
            <small data-rmt-memory-file-preview-meta></small>
            <small data-rmt-memory-file-preview-binding></small>
            <div data-rmt-memory-file-preview-sample></div>
            <label class="checkbox_label rmt-settings-check"><input type="checkbox" data-rmt-memory-file-history-confirm> 我确认这是已经发生的历史/摘要，不是角色设定</label>
            <button type="button" class="menu_button rmt-settings-wide" data-rmt-memory-file-commit disabled>确认作为历史导入当前聊天</button>
          </div>
          <details class="rmt-api-source-panel"><summary>来源详情与世界书类型</summary>
            <div data-rmt-memory-source-list>暂无持久化来源。</div>
            <div data-rmt-memory-history-books></div>
          </details>
          <button type="button" class="menu_button rmt-settings-wide" data-rmt-memory-source-clear>清除当前聊天已导入来源</button>
          <small>只清除心迹回廊自己的来源账本；不会删除聊天、第三方记忆或正式 Mxxx。</small>
          </div>
        </details>
        <div class="rmt-settings-archive-actions">
          <button type="button" class="menu_button rmt-open-archive-room" data-rmt-settings-current-archive><i class="fa-solid fa-file-circle-plus"></i><span>生成当前窗口档案</span></button>
          <button type="button" class="menu_button rmt-open-archive-room" data-rmt-settings-open-archive><i class="fa-solid fa-box-archive"></i><span>打开档案室</span></button>
        </div>
      </div>`;
    mount.appendChild(panel);
    refreshThemeUi();
    const tagDraft = panel.querySelector('[data-rmt-tag-draft]');
    const tagStatus = panel.querySelector('[data-rmt-tag-status]');
    let tagChoices = new Map(), tagScanned = false, tagEdited = false, tagScanEpoch = 0;
    const savedTagDraft = () => {
        const settings = core_settings.getPluginSettings();
        return settings.contextTagMode === 'keep' ? settings.retainedContextTags
            : [...tagChoices.keys()].filter(name => !settings.excludedContextTags.includes(name));
    };
    const renderTagChoices = () => {
        const selected = new Set(core_contextTags.normalizeExcludedTags(tagDraft.value));
        for (const name of selected) if (!tagChoices.has(name)) tagChoices.set(name, 0);
        const result = panel.querySelector('[data-rmt-tag-results]');
        // Empty/legacy initial state does not need to allocate a tag subtree.
        if (!tagChoices.size) { result.textContent = ''; return; }
        const fragment = document.createDocumentFragment();
        for (const [name, count] of tagChoices) {
            const label = document.createElement('label'); label.className = 'rmt-tag-choice';
            const input = document.createElement('input'); input.type = 'checkbox'; input.dataset.rmtTagName = name;
            input.checked = selected.has(name);
            const text = document.createElement('span'); text.textContent = name + (count ? ' · ' + count : '');
            label.append(input, text); fragment.appendChild(label);
        }
        result.replaceChildren(fragment);
    };
    tagDraft.value = savedTagDraft().join(', ');
    tagStatus.textContent = core_settings.getPluginSettings().contextTagMode === 'keep'
        ? '已保存的选择从下一次整理生效。' : '当前沿用旧排除设置；扫描后可选择要保留的标签。';
    renderTagChoices();
    const scanTagChoices = async () => {
        const epoch = ++tagScanEpoch, context = core_context.currentCharacterGuard();
        const scope = core_context.chatScopeKey(context), chat = context.chat, length = chat?.length;
        const lifecycle = runtimeState.runtimeLifecycleEpoch;
        const sourceSignature = source_guard.sourceReadSignature(context);
        const assertCurrent = () => {
            if (epoch !== tagScanEpoch || !panel.isConnected || lifecycle !== runtimeState.runtimeLifecycleEpoch
                || core_context.chatScopeKey(core_context.currentCharacterGuard()) !== scope
                || core_context.getContext().chat !== chat || chat?.length !== length
                || source_guard.sourceReadSignature(core_context.getContext()) !== sourceSignature) throw new DOMException('Changed', 'AbortError');
        };
        tagStatus.textContent = '正在扫描当前聊天的标签…';
        const scanned = await core_contextTags.scanContextTagChoices(chat, { assertCurrent });
        assertCurrent();
        const names = new Map(scanned.tags.map(tag => [tag.name, tag.count]));
        for (const name of core_contextTags.normalizeExcludedTags(tagDraft.value)) if (!names.has(name)) names.set(name, 0);
        tagChoices = names; tagScanned = true;
        if (!tagEdited) tagDraft.value = savedTagDraft().join(', ');
        renderTagChoices();
        tagStatus.textContent = '已扫描 ' + scanned.usedMessages + ' 条消息／' + scanned.tags.length + ' 种标签；选择后保存生效。';
    };
    const refreshCreative = () => {
        const settings = core_settings.getPluginSettings();
        panel.querySelector('[data-rmt-creative-text]').value = settings.creativeSupplement;
        panel.querySelector('[data-rmt-creative-enabled]').checked = settings.creativeSupplementEnabled;
        panel.querySelector('[data-rmt-creative-count]').textContent = settings.creativeSupplement.length.toLocaleString() + ' / 20,000';
    };
    refreshCreative();
    advanced_ui.bindAdvancedGenerationUi(panel);
    bindManualAutosave(panel);
    panel.addEventListener('change', async event => {
        if (cg_format_ui.handleCgFormatChange(event)) return;
        const target = event.target;
        if (target.matches?.('[data-rmt-tag-name]')) {
            ++tagScanEpoch;
            const selected = new Set(core_contextTags.normalizeExcludedTags(tagDraft.value));
            if (target.checked) selected.add(target.dataset.rmtTagName); else selected.delete(target.dataset.rmtTagName);
            tagDraft.value = [...selected].join(', '); tagEdited = true;
            tagStatus.textContent = '选择已更新；尚未保存。';
            return;
        }
        if (target.matches?.('[data-rmt-source-external]')) {
            core_settings.updatePluginSettings({ useCurrentChatExternalMemory: !!target.checked });
            return;
        }
        if (target.matches?.('[data-rmt-source-world-info]')) {
            core_settings.updatePluginSettings({ useActivatedWorldInfo: !!target.checked });
            return;
        }
        if (target.matches?.('[data-rmt-manual-streaming]')) {
            core_settings.updatePluginSettings({ manualApiStreaming: !!target.checked });
            return;
        }
        if (target.matches?.('[data-rmt-read-mode], [data-rmt-read-recent], [data-rmt-read-start], [data-rmt-read-end], [data-rmt-read-hidden]')) {
            const range = {
                mode: panel.querySelector('[data-rmt-read-mode]').value,
                recent: Number(panel.querySelector('[data-rmt-read-recent]').value),
                start: Number(panel.querySelector('[data-rmt-read-start]').value),
                end: Number(panel.querySelector('[data-rmt-read-end]').value),
                includeHidden: panel.querySelector('[data-rmt-read-hidden]').checked,
            };
            core_settings.updatePluginSettings({ chatReadRange: range });
            refreshReadingSettingsUi(panel);
            panel.querySelector('[data-rmt-read-preview-status]').textContent = '已保存，之后读取聊天时生效；已有记忆保持不变。';
            return;
        }
        const autoMode = target.dataset?.rmtAutoEnabled || target.dataset?.rmtAutoEvery;
        if (core_autoUpdatePolicy.AUTO_UPDATE_MODES.includes(autoMode)) {
            const rules = core_autoUpdatePolicy.normalizeAutoUpdates(core_settings.getPluginSettings().autoUpdates);
            rules[autoMode] = { ...rules[autoMode], epoch: Date.now(),
                ...(target.dataset.rmtAutoEnabled ? { enabled: target.checked } : { every: Number(target.value) }) };
            core_settings.updatePluginSettings({ autoUpdates: rules });
            core_autoUpdates.notifyAutoUpdateSettingsChanged();
            refreshGenerationSettingsUi();
            return;
        }
        if (target.matches?.('[data-rmt-memory-file-input]')) {
            const file = target.files?.[0];
            pendingMemoryFilePreview = null;
            const previewEpoch = ++memoryFilePreviewEpoch;
            const previewScope = homeSettingsScope;
            const previewStillCurrent = () => {
                try { return previewEpoch === memoryFilePreviewEpoch && homeSettingsPanel === panel
                    && previewScope === core_context.chatScopeKey(core_context.currentCharacterGuard()); } catch { return false; }
            };
            if (!file) return;
            const previewPanel = panel.querySelector('[data-rmt-memory-file-preview]');
            const title = panel.querySelector('[data-rmt-memory-file-preview-title]');
            const meta = panel.querySelector('[data-rmt-memory-file-preview-meta]');
            const binding = panel.querySelector('[data-rmt-memory-file-preview-binding]');
            const sample = panel.querySelector('[data-rmt-memory-file-preview-sample]');
            const historyConfirm = panel.querySelector('[data-rmt-memory-file-history-confirm]');
            const commitButton = panel.querySelector('[data-rmt-memory-file-commit]');
            archive_repository.previewCurrentChatMemoryFile(file).then(preview => {
                if (!previewStillCurrent()) return;
                pendingMemoryFilePreview = preview;
                if (title) title.textContent = preview.fileName;
                if (meta) {
                    const skipped = Number(preview.skippedSensitiveFields || 0) + Number(preview.skippedConfigFields || 0);
                    meta.textContent = `${preview.records.length} 条 · ${preview.totalChars.toLocaleString()} 字符 · ${(preview.bytes / 1024).toFixed(1)} KB${skipped ? ` · 已排除敏感/配置字段 ${skipped} 个` : ''}`;
                }
                if (binding) binding.textContent = `归属：${preview.scope.characterName || '当前角色'} · ${preview.scope.chatId}`;
                if (sample) {
                    const excerpt = preview.records.slice(0, 3).map((item, index) => {
                        const label = item.title ? `${item.title}：` : '';
                        return `${index + 1}. ${label}${core_text.normalizeText(item.content, 220)}`;
                    }).join('\n');
                    sample.textContent = `内容预览\n${excerpt}`;
                }
                if (historyConfirm) historyConfirm.checked = false;
                if (commitButton) commitButton.disabled = true;
                if (previewPanel) previewPanel.hidden = false;
            }).catch(error => {
                if (!previewStillCurrent()) return;
                if (previewPanel) previewPanel.hidden = true;
                globalThis.toastr?.error?.(core_text.toastText(core_text.safeErrorSummary(error)), '心迹回廊');
            }).finally(() => { target.value = ''; });
            return;
        }
        if (target.matches?.('[data-rmt-memory-file-history-confirm]')) {
            const commitButton = panel.querySelector('[data-rmt-memory-file-commit]');
            if (commitButton) commitButton.disabled = !target.checked || !pendingMemoryFilePreview;
            return;
        }
        if (target.matches?.('[data-rmt-memory-history-book]')) {
            let context = null;
            let previousSelection = null;
            let attemptedSelectionJson = '';
            try {
                context = core_context.currentCharacterGuard();
                previousSelection = archive_repository.getMemoryWorldInfoSelection(context);
                archive_repository.updateMemoryWorldInfoBookSelection(context, target.dataset.rmtMemoryHistoryBook, { historySource: !!target.checked });
                attemptedSelectionJson = JSON.stringify(archive_repository.getMemoryWorldInfoSelection(context).books);
                const worldInfo = await archive_repository.syncSelectedWorldInfoHistoryLedger(context);
                const bookResult = worldInfo.books?.find(book => book.name === target.dataset.rmtMemoryHistoryBook);
                if (target.checked && bookResult?.coverageInfo?.status !== 'complete') {
                    globalThis.toastr?.warning?.(`已标记，但本轮只完成部分同步：${bookResult?.coverageInfo?.reason || '请查看来源状态'}`, '心迹回廊');
                } else {
                    globalThis.toastr?.success?.(target.checked ? '已标记为历史摘要来源。' : '已恢复为设定解释来源。', '心迹回廊');
                }
                void refreshMemoryIngressUi();
            } catch (error) {
                if (!error?.worldHistoryPersisted && context && previousSelection
                    && JSON.stringify(archive_repository.getMemoryWorldInfoSelection(context).books) === attemptedSelectionJson) {
                    archive_repository.setMemoryWorldInfoSelection(context, previousSelection);
                    const previousBook = previousSelection.books.find(book => book.name === target.dataset.rmtMemoryHistoryBook);
                    target.checked = previousBook?.historySource === true;
                }
                if (error?.name !== 'AbortError') globalThis.toastr?.error?.(`历史来源没有同步，已恢复原选择：${core_text.toastText(core_text.safeErrorSummary(error))}`, '心迹回廊');
                void refreshMemoryIngressUi();
            }
            return;
        }
        if (target.matches?.('[data-rmt-api-profile]')) {
            panel.dataset.rmtApiEditor = 'profile';
            const connectionProfileId = core_text.normalizeText(target.value, 160);
            core_settings.updatePluginSettings({ apiConnectionMode: 'profile', connectionProfileId, modelOverride: '' });
            refreshGenerationSettingsUi();
            void refreshModelOptions({ fetchRemote: !!connectionProfileId });
            return;
        }
        if (target.matches?.('[data-rmt-api-model]')) {
            panel.dataset.rmtApiEditor = 'profile';
            core_settings.updatePluginSettings({ apiConnectionMode: 'profile', modelOverride: core_text.normalizeText(target.value, 240) });
            refreshGenerationSettingsUi();
            return;
        }
        if (target.matches?.('[data-rmt-api-max-tokens]')) {
            if (target.validity?.badInput || (target.value.trim() && !output_budget.isValidOutputTokens(target.value))) {
                globalThis.toastr?.warning?.('最大输出请填写正整数；原设置未改动。', '心迹回廊');
                target.value = String(core_settings.getPluginSettings().maxTokens);
                return;
            }
            core_settings.updatePluginSettings({ maxTokens: output_budget.normalizeOutputTokens(target.value) });
            refreshGenerationSettingsUi();
            return;
        }
        if (target.matches?.('[data-rmt-api-temperature]')) {
            core_settings.updatePluginSettings({ temperature: Math.max(0, Math.min(2, Number.isFinite(Number(target.value)) ? Number(target.value) : core_constants.DEFAULT_SETTINGS.temperature)) });
            refreshGenerationSettingsUi();
            return;
        }
        if (target.matches?.('[data-rmt-room-life-auto]')) {
            core_settings.updatePluginSettings({ roomLifeAutoDaily: !!target.checked });
            refreshGenerationSettingsUi();
            return;
        }
        if (target.matches?.('[data-rmt-image-generation-provider]')) {
            core_settings.updatePluginSettings({ imageGenerationProvider: target.value });
            refreshImageGenerationSettingsUi();
            generation_imageGeneration.refreshCgImageProviderBars();
            return;
        }
        if (target.matches?.('[data-rmt-tt-display]')) {
            core_settings.updatePluginSettings({ ttDisplayMode: !!target.checked });
            const overlay = document.getElementById(core_constants.OVERLAY_ID);
            if (overlay) ui_overlay.applyArchiveMobileSafeArea(overlay);
            refreshGenerationSettingsUi();
            return;
        }
        if (target.matches?.('[data-rmt-floating-avatar]')) {
            core_settings.updatePluginSettings({ floatingAvatar: target.value });
            floating_archive.refreshFloatingArchive();
            return;
        }
        if (target.matches?.('[data-rmt-theme-mode]')) {
            core_settings.updatePluginSettings({ themeMode: core_constants.THEME_MODES.has(target.value) ? target.value : 'default' });
            refreshThemeUi();
            refreshGenerationSettingsUi();
            return;
        }
        if (target.matches?.('[data-rmt-theme-alpha]')) {
            core_settings.updatePluginSettings({ themeAlpha: Math.max(0.72, Math.min(1, Number(target.value) || 0.96)) });
            refreshThemeUi();
            return;
        }
        if (target.matches?.('[data-rmt-theme-color]')) {
            const key = target.dataset.rmtThemeColor;
            const settings = core_settings.getPluginSettings();
            if (key && Object.prototype.hasOwnProperty.call(settings.themeCustom || {}, key)) {
                core_settings.updatePluginSettings({ themeMode: 'custom', themeCustom: core_theme.normalizeThemeCustom({ ...settings.themeCustom, [key]: target.value }) });
                refreshThemeUi();
                refreshGenerationSettingsUi();
            }
            return;
        }
        if (target.matches?.('[data-rmt-manual-api-models]')) {
            const manualInput = panel.querySelector('[data-rmt-manual-api-model]');
            if (manualInput && target.value) {
                manualInput.value = target.value;
                panel.dataset.rmtManualDirty = '1';
            }
            return;
        }
        if (target.matches?.('[data-rmt-banned-generated-phrases]')) {
            core_settings.updatePluginSettings({ bannedGeneratedPhrases: core_settings.normalizeBannedGeneratedPhrases(target.value) });
            refreshGenerationSettingsUi();
        }
    });
    panel.addEventListener('input', event => {
        if (event.target === tagDraft) {
            ++tagScanEpoch; tagEdited = true;
            const selected = new Set(core_contextTags.normalizeExcludedTags(tagDraft.value));
            for (const input of panel.querySelectorAll('[data-rmt-tag-name]')) input.checked = selected.has(input.dataset.rmtTagName);
            tagStatus.textContent = '选择已更新；尚未保存。';
            return;
        }
        if (event.target.matches?.('[data-rmt-creative-text]')) panel.querySelector('[data-rmt-creative-count]').textContent = event.target.value.length.toLocaleString() + ' / 20,000';
        if (event.target.matches?.('[data-rmt-manual-api-base],[data-rmt-manual-api-key],[data-rmt-manual-api-model]')) {
            panel.dataset.rmtManualDirty = '1';
            if (event.target.matches?.('[data-rmt-manual-api-model]')) {
                const picker = panel.querySelector('[data-rmt-manual-api-models]');
                if (picker) picker.value = [...picker.options].some(option => option.value === event.target.value) ? event.target.value : '';
            }
        }
        if (event.target.matches?.('[data-rmt-theme-alpha]')) {
            core_settings.updatePluginSettings({ themeAlpha: Math.max(0.72, Math.min(1, Number(event.target.value) || 0.96)) });
            refreshThemeUi();
        }
    });
    panel.addEventListener('click', event => {
        if (event.target.closest?.('[data-rmt-read-preview]')) {
            const status = panel.querySelector('[data-rmt-read-preview-status]');
            try {
                const preview = core_chatReadRange.readRangePreview(core_context.currentCharacterGuard(), core_settings.getPluginSettings());
                status.textContent = `${preview.label} · 共 ${preview.totalFloors} 楼，选中 ${preview.selectedFloors} 楼（普通 ${preview.visibleCount} / 隐藏 ${preview.hiddenCount}），约 ${preview.characters.toLocaleString()} 字符。仅本地预览，未发起生成。`;
            } catch (error) { status.textContent = core_text.safeErrorSummary(error); }
            return;
        }
        if (event.target.closest?.('[data-rmt-creative-save]')) {
            try {
                core_settings.updatePluginSettings({ creativeSupplement: panel.querySelector('[data-rmt-creative-text]').value, creativeSupplementEnabled: panel.querySelector('[data-rmt-creative-enabled]').checked });
                panel.querySelector('[data-rmt-creative-status]').textContent = '已保存；下次心迹回廊文本生成生效。';
            } catch (error) { panel.querySelector('[data-rmt-creative-status]').textContent = core_text.safeErrorSummary(error); }
            return;
        }
        if (event.target.closest?.('[data-rmt-creative-cancel]')) { refreshCreative(); panel.querySelector('[data-rmt-creative-status]').textContent = '已撤销未保存编辑。'; return; }
        const updateButton = event.target.closest?.('[data-rmt-self-update]');
        if (updateButton) {
            void core_selfUpdater.updateFromButton(updateButton, panel.querySelector('[data-rmt-self-update-status]'), {
                isBusy: () => runtimeState.busy || core_requestCoordinator.hasGenerationTasks() || !!runtimeState.roomLifeRefreshPromise,
            });
            return;
        }
        const tagAction = event.target.closest?.('[data-rmt-tag-save],[data-rmt-tag-cancel],[data-rmt-tag-clear],[data-rmt-tag-scan],[data-rmt-tag-all],[data-rmt-tag-invert]');
        if (tagAction) {
            void (async () => {
                try {
                    if (tagAction.hasAttribute('data-rmt-tag-save')) {
                        ++tagScanEpoch;
                        const tags = core_contextTags.normalizeExcludedTags(tagDraft.value);
                        core_settings.updatePluginSettings({ contextTagMode: 'keep', retainedContextTags: tags });
                        tagDraft.value = tags.join(', '); tagEdited = false; renderTagChoices();
                        tagStatus.textContent = '已保存 ' + tags.length + ' 个标签；下次整理生效，聊天和旧档案未改动。';
                    } else if (tagAction.hasAttribute('data-rmt-tag-cancel')) {
                        ++tagScanEpoch; tagEdited = false; tagDraft.value = savedTagDraft().join(', '); renderTagChoices();
                        tagStatus.textContent = '已撤销未保存编辑。';
                    } else if (tagAction.hasAttribute('data-rmt-tag-clear')) {
                        ++tagScanEpoch; tagEdited = true; tagDraft.value = ''; renderTagChoices();
                        tagStatus.textContent = '已清空选择；尚未保存。';
                    } else if (tagAction.hasAttribute('data-rmt-tag-scan')) {
                        tagAction.disabled = true;
                        await scanTagChoices();
                    } else {
                        tagAction.disabled = true;
                        if (!tagScanned) await scanTagChoices();
                        ++tagScanEpoch;
                        const selected = new Set(core_contextTags.normalizeExcludedTags(tagDraft.value));
                        tagDraft.value = [...tagChoices.keys()].filter(name => tagAction.hasAttribute('data-rmt-tag-all') || !selected.has(name)).join(', ');
                        tagEdited = true; renderTagChoices(); tagStatus.textContent = '选择已更新；尚未保存。';
                    }
                } catch (error) {
                    if (error?.name !== 'AbortError') tagStatus.textContent = core_text.safeErrorSummary(error);
                } finally { tagAction.disabled = false; }
            })();
            return;
        }
        const preset = event.target.closest?.('[data-rmt-theme-preset]');
        if (preset) {
            core_settings.updatePluginSettings({ themeMode: 'custom', themeCustom: { ...(preset.dataset.rmtThemePreset === 'night' ? core_constants.NIGHT_THEME_PALETTE : core_constants.DEFAULT_THEME_PALETTE) } });
            refreshGenerationSettingsUi();
            return;
        }
        const settingsSummary = event.target.closest?.('[data-rmt-settings-section] > summary');
        if (settingsSummary) hydrateSettingsPanel({ memory: settingsSummary.parentElement?.dataset.rmtSettingsSection === 'memory' });
        const themeReset = event.target.closest?.('[data-rmt-theme-reset]');
        if (themeReset) {
            core_settings.updatePluginSettings({ themeMode: 'default', themeAlpha: core_constants.DEFAULT_SETTINGS.themeAlpha, themeCustom: { ...core_constants.DEFAULT_THEME_PALETTE } });
            refreshThemeUi();
            refreshGenerationSettingsUi();
            globalThis.toastr?.success?.('已恢复心迹回廊默认配色。', '心迹回廊');
            return;
        }
        const memoryAutoRead = event.target.closest?.('[data-rmt-memory-auto-read]');
        if (memoryAutoRead) {
            memoryAutoRead.disabled = true;
            memoryAutoRead.querySelector('small')?.replaceChildren(document.createTextNode('正在读取…'));
            archive_repository.readCurrentChatMemoryPlugins()
                .then(() => refreshMemoryIngressUi())
                .catch(error => globalThis.toastr?.error?.(core_text.toastText(core_text.safeErrorSummary(error)), '心迹回廊'))
                .finally(() => { memoryAutoRead.disabled = false; const small = memoryAutoRead.querySelector('small'); if (small) small.textContent = '已注册的当前聊天来源'; });
            return;
        }
        const memoryFileChoose = event.target.closest?.('[data-rmt-memory-file-choose]');
        if (memoryFileChoose) {
            panel.querySelector('[data-rmt-memory-file-input]')?.click?.();
            return;
        }
        const memoryFileCommit = event.target.closest?.('[data-rmt-memory-file-commit]');
        if (memoryFileCommit) {
            if (!pendingMemoryFilePreview) {
                globalThis.toastr?.warning?.('请先选择并预览记忆文件。', '心迹回廊');
                return;
            }
            if (!panel.querySelector('[data-rmt-memory-file-history-confirm]')?.checked) {
                globalThis.toastr?.warning?.('请先确认：文件内容是已经发生的历史/摘要，不是角色设定。', '心迹回廊');
                return;
            }
            memoryFileCommit.disabled = true;
            archive_repository.commitCurrentChatMemoryFilePreview(pendingMemoryFilePreview, core_context.currentCharacterGuard(), { confirmedHistory: true })
                .then(async summary => {
                    pendingMemoryFilePreview = null;
                    const previewPanel = panel.querySelector('[data-rmt-memory-file-preview]');
                    if (previewPanel) previewPanel.hidden = true;
                    globalThis.toastr?.success?.(`已导入来源账本：${summary.recordCount} 条。`, '心迹回廊');
                    await refreshMemoryIngressUi();
                })
                .catch(error => globalThis.toastr?.error?.(core_text.toastText(core_text.safeErrorSummary(error)), '心迹回廊'))
                .finally(() => { memoryFileCommit.disabled = false; });
            return;
        }
        const memorySourceClear = event.target.closest?.('[data-rmt-memory-source-clear]');
        if (memorySourceClear) {
            if (!globalThis.confirm?.('只清除当前角色、当前聊天在“心迹回廊”内保存的来源账本。正式 Mxxx、聊天和第三方记忆都不会删除。确定继续吗？')) return;
            memorySourceClear.disabled = true;
            archive_repository.clearCurrentChatImportedSources()
                .then(async () => {
                    pendingMemoryFilePreview = null;
                    const previewPanel = panel.querySelector('[data-rmt-memory-file-preview]');
                    if (previewPanel) previewPanel.hidden = true;
                    await refreshMemoryIngressUi();
                    globalThis.toastr?.success?.('当前聊天的心迹回廊来源账本已清除并验证。', '心迹回廊');
                })
                .catch(error => globalThis.toastr?.error?.(core_text.toastText(core_text.safeErrorSummary(error)), '心迹回廊'))
                .finally(() => { memorySourceClear.disabled = false; });
            return;
        }
        const manualChoiceButton = event.target.closest?.('[data-rmt-api-select-manual]');
        if (manualChoiceButton) {
            core_settings.beginApiConfigurationOperation();
            panel.dataset.rmtApiEditor = 'manual';
            refreshGenerationSettingsUi();
            return;
        }
        const manualClearButton = event.target.closest?.('[data-rmt-manual-api-key-clear]');
        if (manualClearButton) {
            clearTimeout(manualAutosaves.get(panel)); manualAutosaves.delete(panel);
            const keyInput = panel.querySelector('[data-rmt-manual-api-key]'); if (keyInput) keyInput.value = '';
            void core_settings.forgetManualApiCredential().then(() => {
                refreshGenerationSettingsUi();
                const status = panel.querySelector('[data-rmt-manual-save-status]'); if (status) status.textContent = '本插件手动 Key 已清除，主聊天连接未改。';
            }).catch(error => globalThis.toastr?.error?.(core_text.safeErrorSummary(error), '心迹回廊'));
            return;
        }
        if (event.target.closest?.('[data-rmt-manual-api-save]')) { void saveManualPanel(panel, true); return; }
        const manualRefreshButton = event.target.closest?.('[data-rmt-manual-api-model-refresh]');
        if (manualRefreshButton) {
            refreshManualModelOptions({ fetchRemote: true })
                .then(models => {
                    if (!models?.length) return;
                    if (panel.dataset.rmtManualModelFallback === '1') globalThis.toastr?.warning?.('远程模型列表暂不可用，已保留手动 API 自己保存的模型。', '心迹回廊');
                    else globalThis.toastr?.success?.(`已找到 ${models.length} 个模型。`, '心迹回廊');
                })
                .catch(error => globalThis.toastr?.error?.(core_text.toastText(core_text.safeErrorSummary(error)), '心迹回廊'));
            return;
        }
        const modelRefreshButton = event.target.closest?.('[data-rmt-api-model-refresh]');
        if (modelRefreshButton) {
            refreshModelOptions({ fetchRemote: true })
                .then(result => {
                    if (!result) return;
                    if (result.fallbackOnly) globalThis.toastr?.warning?.('远程列表暂不可用，已显示这一连接保存的模型。', '心迹回廊');
                    else globalThis.toastr?.success?.('模型列表已更新。', '心迹回廊');
                })
                .catch(error => globalThis.toastr?.error?.(core_text.toastText(core_text.safeErrorSummary(error)), '心迹回廊'));
            return;
        }
        const apiImportButton = event.target.closest?.('[data-rmt-api-import-current]');
        if (apiImportButton) {
            panel.dataset.rmtApiEditor = 'profile';
            const operationEpoch = core_settings.beginApiConfigurationOperation();
            const uiRequestEpoch = Number(panel.dataset.rmtOneClickRequest || 0) + 1;
            panel.dataset.rmtOneClickRequest = String(uiRequestEpoch);
            const isLatestUiRequest = () => Number(panel.dataset.rmtOneClickRequest || 0) === uiRequestEpoch;
            apiImportButton.disabled = true;
            core_settings.importCurrentSillyTavernConnection({
                isCurrent: () => core_settings.isCurrentApiConfigurationOperation(operationEpoch),
            }).then(result => {
                if (!isLatestUiRequest()) return;
                refreshGenerationSettingsUi();
                const current = core_settings.getPluginSettings();
                if (current.apiConnectionMode !== 'profile' || current.connectionProfileId !== core_text.normalizeText(result?.id, 160)) return;
                globalThis.toastr?.success?.(result?.created ? '一键连接已创建并启用。' : '一键连接已启用。', '心迹回廊');
                void refreshModelOptions({ fetchRemote: true });
            }).catch(error => {
                if (!isLatestUiRequest()) return;
                if (error?.code !== 'RMT_API_CONFIGURATION_SUPERSEDED') {
                    console.warn('[HeartbeatMemories] one-click configuration failed', core_text.safeErrorDiagnostic(error));
                    globalThis.toastr?.error?.(core_text.toastText(core_text.safeErrorSummary(error)), '心迹回廊');
                }
                refreshGenerationSettingsUi();
            }).finally(() => {
                if (isLatestUiRequest()) apiImportButton.disabled = false;
            });
            return;
        }
        const currentArchiveButton = event.target.closest?.('[data-rmt-settings-current-archive]');
        if (currentArchiveButton) {
            // In claim mode this button re-binds the existing archive instead of paying for
            // a rebuild. Nothing is generated and no memory is altered.
            if (currentArchiveButton.dataset.rmtArchiveClaim === '1') {
                let info = null;
                try { info = archive_repository.mismatchedArchiveInfo(core_context.currentCharacterGuard()); } catch {}
                if (!info) { refreshSettingsMemoryStatus(); return; }
                const ok = ui_overlay.confirmExplicitAction('认领这份档案到当前聊天？',
                    `找到「${info.archiveName || '未命名档案'}」，共 ${info.memoryCount} 条记忆，但它记录的聊天标识与当前聊天不同。`
                    + '\n\n聊天被重命名、分支或复制后会出现这种情况。'
                    + '\n\n确定＝把它绑定到当前聊天。不改动任何记忆内容，不消耗生成额度，原标识会被保留备查。'
                    + '\n取消＝保持原样。',
                    { destructive: false });
                if (!ok) return;
                try {
                    const claimed = archive_repository.claimMismatchedArchive(core_context.currentCharacterGuard());
                    globalThis.toastr?.success?.(`已认领 ${claimed.memoryCount} 条记忆到当前聊天。`, '心迹回廊');
                } catch (error) {
                    globalThis.toastr?.error?.(core_text.safeErrorSummary(error), '心迹回廊 · 认领失败');
                }
                refreshSettingsMemoryStatus();
                return;
            }
            ui_overlay.requestCurrentArchiveImport();
            return;
        }
        const openArchiveButton = event.target.closest?.('[data-rmt-settings-open-archive]');
        if (openArchiveButton) {
            void archive_library.showArchiveLibrary();
            return;
        }
    });
    panel.addEventListener('focusin', event => {
        if (panel.dataset.rmtHydrated !== '1' && event.target.matches?.('input,select,button,textarea')) hydrateSettingsPanel();
    });
    refreshSettingsMemoryStatus({ lightweight: true });
    return true;
}
