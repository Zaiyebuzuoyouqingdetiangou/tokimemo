// 情侣头像的画风、互动都是可选提示，不作为出图条件。
export const STYLE_GROUPS = Object.freeze([
    { id: 'chibi', label: 'Q版萌系' }, { id: 'anime', label: '动漫绘本' },
    { id: 'art', label: '手绘艺术' }, { id: 'craft', label: '手作材质' },
    { id: 'graphic', label: '平面设计' }, { id: 'photo', label: '写真氛围' },
    { id: 'animal', label: '动物化身' }, { id: 'fantasy', label: '幻想装饰' },
]);

export const COUPLE_STYLES = Object.freeze([
    ['chibi-dumpling', 'chibi', '二头身团子', '大头小身体，圆润而轻巧。', 'two-head-tall chibi characters, rounded dumpling-like proportions, oversized heads, tiny bodies, soft playful shapes'],
    ['chibi-three-head', 'chibi', '三头身小人', '保留服装细节，也能看清小动作。', 'three-head-tall chibi figures, expressive small gestures, recognizable clothing details, cute balanced proportions'],
    ['chibi-headshot', 'chibi', '萌系大头', '脸和表情是主角，缩小也清楚。', 'cute large-head portrait illustration, expressive readable faces, simple supporting shapes'],
    ['chibi-doodle', 'chibi', '豆豆眼涂鸦', '几笔小表情，松弛又俏皮。', 'playful hand-drawn doodles, dot eyes, loose lively outlines, simple charming expressions'],
    ['chibi-animal', 'animal', '圆滚滚兽化', '主角本身变成动物，不是人戴兽耳。', 'animal-only chibi illustration, two rounded small animals with muzzles, animal limbs and tails, choose fitting species for their personalities'],
    ['chibi-meme', 'chibi', '表情包Q版', '一边闹、一边笑，表情更夸张。', 'expressive chibi reaction-sticker illustration, exaggerated playful expressions and complementary poses, no lettering'],
    ['anime-clean', 'anime', '日系清线', '利落线条，轻盈的平涂色块。', 'Japanese anime illustration, crisp delicate linework, light flat colors'],
    ['anime-cel', 'anime', '赛璐璐', '清晰明暗面，像动画定格。', 'cel-shaded anime keyframe, defined light and shadow shapes, clear facial features'],
    ['anime-shojo', 'anime', '少女漫画', '细线、网点和心动的眼神。', 'romantic shoujo manga illustration, fine linework, delicate screen tones, expressive affectionate eyes'],
    ['anime-retro90', 'anime', '90年代动画', '复古描线与柔和胶片感。', '1990s anime aesthetic, nostalgic ink outlines, soft analog cel texture and restrained film grain'],
    ['anime-korean', 'anime', '韩系清透插画', '通透肤色，轻柔而精致。', 'airy Korean-style portrait illustration, translucent gentle skin shading, refined soft linework'],
    ['anime-storybook', 'anime', '童话绘本', '带一点故事感的温柔笔触。', 'fairytale picture-book illustration, gentle tactile brushwork, narrative charm'],
    ['art-gongbi', 'art', '国风工笔', '细描发丝与衣纹，含蓄耐看。', 'Chinese gongbi painting, meticulous fine hair and fabric lines, refined restrained color washes'],
    ['art-ink', 'art', '水墨淡彩', '墨色留白，少量颜色点睛。', 'Chinese ink-and-light-color painting, expressive ink washes, negative space, sparse color accents'],
    ['art-watercolor', 'art', '透明水彩', '水色晕染，轻轻透出纸感。', 'transparent watercolor portrait illustration, luminous layered washes, subtle paper grain'],
    ['art-pencil', 'art', '彩铅手绘', '颗粒和线条，像手绘小卡。', 'colored-pencil drawing, visible pencil grain and gentle strokes, hand-drawn portrait illustration'],
    ['art-oil', 'art', '油画厚涂', '可见笔触与统一的光影。', 'painterly oil portrait, visible impasto brushwork, coherent soft lighting and rich color relationships'],
    ['art-sketch', 'art', '黑白素描', '不靠配色，也能画出默契。', 'monochrome graphite portrait sketch, sensitive line and tonal shading, expressive individual faces'],
    ['craft-plush', 'craft', '毛绒玩偶', '绒毛和缝线，软乎乎的一对。', 'a matching pair of soft plush dolls, tactile fuzzy fabric, delicate stitching, recognizable character design'],
    ['craft-clay', 'craft', '黏土手办', '圆润体块，保留手作质感。', 'handcrafted clay character figurines, rounded forms, slight handmade surface texture'],
    ['craft-crochet', 'craft', '钩织娃娃', '针织纹路，配对的小衣服。', 'crocheted amigurumi character dolls, visible yarn stitches, coordinated tiny clothing'],
    ['craft-felt', 'craft', '羊毛毡', '细绒毛与微微不规则的轮廓。', 'needle-felted wool character dolls, fine soft fibers, charming slightly irregular handmade contours'],
    ['craft-vinyl', 'craft', '搪胶盲盒', '光滑小手办，玩具收藏感。', 'designer vinyl toy figurines, smooth satin material, charming collectible toy proportions'],
    ['craft-paper', 'craft', '剪纸拼贴', '层叠纸边和轻浅投影。', 'layered cut-paper collage portraits, visible paper edges, subtle cast shadows, tactile colored paper'],
    ['graphic-pixel', 'graphic', '16位像素', '方块细节，复古游戏头像。', '16-bit pixel art character bust portraits, large readable heads and shoulders, deliberate crisp pixel clusters, nuanced retro game palette'],
    ['graphic-line', 'graphic', '极简线描', '用少量线条留住人物特征。', 'minimal line-art portraits, economical expressive contours, keep distinguishing features'],
    ['graphic-silhouette', 'graphic', '双色剪影', '轮廓和配色相互呼应。', 'two-color silhouette portrait design, recognizable hair and accessory contours, complementary color shapes'],
    ['graphic-print', 'graphic', '复古版画', '刻线与套色，干净有力度。', 'vintage relief-print portrait illustration, carved hatching, clean limited-color overprints'],
    ['graphic-sticker', 'graphic', '贴纸描边', '清楚的白边，像成对贴纸。', 'matching die-cut character sticker illustrations, clean white contour outline, expressive poses'],
    ['graphic-geometric', 'graphic', '几何色块', '形状和色块拼出两人的默契。', 'geometric shape-based portrait illustration, balanced flat color blocks, recognizable character features'],
    ['photo-film', 'photo', '胶片写真', '真实镜头与细微胶片颗粒。', 'natural photographic character portraits, analog film rendering, fine film grain, coherent lens perspective'],
    ['photo-daylight', 'photo', '清新日光', '自然光线，像随手拍下的日常。', 'fresh candid daylight portraits, natural soft light, relaxed expressions, clear facial detail'],
    ['photo-studio', 'photo', '复古影楼', '成套背景与复古肖像光。', 'vintage studio portrait photography, coordinated backdrop, nostalgic controlled portrait lighting'],
    ['photo-night', 'photo', '电影夜景', '有色夜光，保持五官清晰。', 'cinematic nighttime portraits, colored ambient night light, legible eyes and facial details'],
    ['photo-backlight', 'photo', '柔焦逆光', '轻柔轮廓光，不抹去面部细节。', 'soft backlit portrait photography, gentle rim light and delicate bloom, retain readable face detail'],
    ['photo-mono', 'photo', '黑白人像', '简单背景，突出神情与距离。', 'black-and-white portrait photography, simple background, subtle tonal contrast, expressive connection'],
    ['chibi-mochi', 'chibi', '糯米团子', '软糯小圆团，保留发色与配饰。', 'mochi-like chibi characters, tiny round bodies and miniature limbs, soft squashy silhouettes, simple dot features'],
    ['chibi-sleepy', 'chibi', '困困小人', '短短手脚，惺忪眼睛和松软线条。', 'sleepy miniature chibi figures, stubby limbs, half-closed eyes, soft rounded loose linework'],
    ['chibi-crayon', 'chibi', '蜡笔小朋友', '稚拙轮廓，像小朋友认真画的画。', 'finished childlike crayon chibi illustration, deliberately naive proportions, lively wax strokes, bold simple shapes'],
    ['anime-flat', 'anime', '清爽平涂', '省去复杂光影，突出轮廓与色块。', 'flat-color anime illustration, clean silhouettes, minimal shadow, no painterly rendering, restrained palette'],
    ['anime-manga', 'anime', '黑白漫画', '黑白墨线、网点和夸张小表情。', 'black-and-white manga portrait, expressive ink contours, screentone shadows, no color painting'],
    ['anime-pastel', 'anime', '粉彩动画', '柔和粉彩、圆润描线与淡淡阴影。', 'pastel animation drawing, rounded colored outlines, delicate flat cel shadows, airy candy-colored palette'],
    ['anime-webtoon', 'anime', '条漫肖像', '简洁五官，利落的条漫式明暗。', 'modern webtoon portrait illustration, clear graphic facial design, smooth selective cel shading, economical linework'],
    ['art-gouache', 'art', '不透明水粉', '哑光厚实色块，可见叠色笔触。', 'opaque gouache painting, matte chalky color planes, visible overlapping brush marks, painted rather than anime outlines'],
    ['art-pastel', 'art', '油画棒', '厚重蜡质笔触，柔软而有颗粒。', 'oil-pastel portrait drawing, thick waxy strokes, visible paper tooth, broken color edges'],
    ['art-charcoal', 'art', '炭笔速写', '擦痕、炭粉与有呼吸感的粗线。', 'finished expressive charcoal portrait drawing, velvety blacks, lifted highlights, confident gestural contours on paper'],
    ['art-risograph', 'art', '孔版套印', '有限套色与轻微错版，像印刷小卡。', 'risograph portrait print, limited spot colors, grainy ink, visible subtle registration offsets'],
    ['craft-porcelain', 'craft', '釉彩瓷偶', '圆润瓷面，带一点通透釉光。', 'two small glazed porcelain character dolls as the actual subjects, rounded ceramic forms, painted features, translucent glaze highlights'],
    ['craft-wood', 'craft', '木雕小偶', '刀痕与木纹，像掌心的小收藏。', 'two hand-carved wooden character dolls, visible wood grain, faceted carving marks, tiny painted faces'],
    ['craft-origami', 'craft', '折纸小人', '折痕和纸面拼出人物与衣服。', 'folded-paper character figures, visible origami creases, geometric folded heads and clothing, paper forms rather than real skin'],
    ['craft-bead', 'craft', '拼豆小像', '一颗颗圆形拼豆组成小小人物。', 'fused-bead character portraits, visible individual cylindrical plastic beads on a square grid, flat craft object photography'],
    ['graphic-8bit', 'graphic', '8位小像素', '更少颜色、更大像素，轮廓清楚。', '8-bit pixel art character bust portraits, large readable heads and shoulders, small limited palette, deliberate square pixel clusters, crisp stepped edges'],
    ['graphic-pop', 'graphic', '波普撞色', '粗轮廓、撞色和醒目的网点。', 'pop-art portrait illustration, bold ink outlines, contrasting flat colors, large halftone dots'],
    ['graphic-comic', 'graphic', '复古美漫', '粗黑墨线、排线与纸面印刷感。', 'vintage comic-book portraits, bold black ink contours, crosshatching, textured halftone printing, no lettering'],
    ['graphic-lino', 'graphic', '双色橡皮章', '雕刻感的粗线，像一对印章。', 'two-color linocut stamp portraits, broad carved negative shapes, tactile ink transfer, graphic flat silhouettes'],
    ['photo-instant', 'photo', '即时成像', '柔和闪光与轻微偏色的日常抓拍。', 'instant-film candid photography, soft direct flash, slight analog color shifts, authentic lens rendering, edge-to-edge background'],
    ['photo-rain', 'photo', '雨窗写真', '雨滴虚化、玻璃反光与柔和侧光。', 'photographic portraits beside a rainy window, defocused raindrops and glass reflections, soft sidelight, realistic skin texture'],
    ['animal-cat', 'animal', '小猫化身', '猫脸、猫爪和尾巴，映射原有发色。', 'two small cats as the main subjects, round feline faces, whiskers, paws and curved tails, cute animal portrait illustration'],
    ['animal-dog', 'animal', '小狗化身', '小狗嘴鼻与软耳，神情各不相同。', 'two small dogs as the main subjects, canine muzzles, soft ears, paws and wagging tails, expressive animal portraits'],
    ['animal-fox', 'animal', '小狐狸化身', '尖耳朵和蓬松大尾巴的一对狐狸。', 'two little foxes, fox muzzles, pointed ears, four animal limbs and large fluffy tails, animal-only storybook illustration'],
    ['animal-rabbit', 'animal', '垂耳兔化身', '软软兔脸和垂耳，不是人形兔耳。', 'two little lop-eared rabbits, rabbit faces, soft floppy ears, small forepaws and round tails, animal-only illustration'],
    ['animal-bear', 'animal', '小熊化身', '圆耳、短嘴鼻和肉乎乎的熊爪。', 'two small bears, round ears, short bear muzzles, stout animal bodies and soft paws, rounded animal-only illustration'],
    ['animal-bird', 'animal', '团子小鸟', '圆滚滚羽毛、鸟喙与小翅膀。', 'two round little birds, visible beaks, feathered bodies, tiny wings and bird feet, soft animal-only illustration'],
    ['animal-seal', 'animal', '海豹团子', '小鳍肢和圆滚滚身形，靠神情呼应。', 'two plump baby seals, seal muzzles, whiskers and flippers, smooth rounded animal bodies, expressive animal-only illustration'],
    ['fantasy-glass', 'fantasy', '彩窗玻璃', '彩色玻璃与细细铅条拼出肖像。', 'stained-glass portrait artwork, luminous colored glass pieces separated by lead outlines, faceted transmitted light'],
    ['fantasy-enamel', 'fantasy', '珐琅徽章', '金属轮廓与亮亮的珐琅色面。', 'matching hard-enamel portrait pins, polished raised metal outlines and glossy flat enamel fills, collectible objects'],
    ['fantasy-embroidery', 'fantasy', '刺绣肖像', '线迹组成五官、发丝和衣服。', 'embroidered character portraits on fabric, every shape made of visible thread stitches, tactile satin-stitch relief'],
    ['fantasy-mosaic', 'fantasy', '马赛克拼画', '细小瓷砖拼成有光泽的肖像。', 'portrait mosaics made entirely of tiny colored ceramic tesserae, visible grout and subtle glazed reflections'],
    ['fantasy-blueprint', 'fantasy', '蓝晒肖像', '靛蓝与纸白，带植物光影的蓝晒。', 'cyanotype portrait print, exclusively Prussian blue and white, photographic contact-print texture, botanical shadow shapes'],
    ['fantasy-shadow', 'fantasy', '皮影小像', '透光皮革、镂刻纹样和关节细节。', 'Chinese shadow-puppet character portraits, translucent colored leather, intricate cutout ornament and visible puppet joints'],
    ['fantasy-luminous', 'fantasy', '夜光剪纸', '纸层间透出小夜灯一样的柔光。', 'illuminated layered-paper portrait diorama, actual cut-paper subjects, gentle light between paper layers, visible edge depth'],
    ['fantasy-fresco', 'fantasy', '壁画矿彩', '矿物色、磨损肌理和壁画式线条。', 'mineral-pigment fresco portraits, matte mineral colors, worn plaster texture, flowing mural contours'],
].map(([id, group, label, description, prompt]) => Object.freeze({ id, group, label, description, prompt })));

// Construction instructions affect the subjects themselves, not just a texture
// or a decorative background. They are prompts only, never output validation.
const MEDIUM_CONSTRUCTION = Object.freeze({
    chibi: 'Build the selected stylized proportions into each head, face and body.',
    anime: 'Use the selected drawing language for both faces, hair and clothes: deliberate contours and matching shadow design.',
    art: 'The selected traditional medium visibly builds the face, hair, clothing and background.',
    craft: 'The actual two subjects are handmade objects. Their face, hair, limbs and clothes are constructed from the chosen material.',
    graphic: 'Construct faces, hair, clothes and background in the same graphic vocabulary.',
    photo: 'Use photographic facial structure, natural skin texture and coherent camera lighting on both subjects.',
    animal: 'Use complete species-appropriate animal anatomy, including animal faces and bodies. Map each identity to its own fur or feather markings, eyes and small accessories.',
    fantasy: 'Build the portrait itself out of the selected medium. Face, hair and clothes share its visible construction.',
});
const STYLE_CONSTRUCTION = Object.freeze({
    'chibi-dumpling': 'Each head occupies about half of the full figure height; show the tiny torso, stubby arms and feet. Broad simple shapes, minimal facial shading.',
    'chibi-three-head': 'The head occupies about one third of the figure height; include the small clothed body and readable little gestures, not a head-only crop.',
    'chibi-headshot': 'Oversized rounded face, small nose and mouth, deliberately enlarged expressive eyes; show hair silhouette and a little shoulder, without adult facial proportions.',
    'chibi-doodle': 'Dot eyes, a few uneven pen strokes for mouth and hair, simplified silhouette and small flat color patches; no detailed painted eyes or face shading.',
    'chibi-animal': 'Round animal skulls with visible species-specific muzzles or beaks, compact bodies and paws or wings. Distinguish the two through their own markings, accessories and reactions.',
    'chibi-meme': 'Squashed miniature bodies, exaggerated mouth and eyebrow shapes, a visibly different reaction on each side; simple outlines and flat fills.',
    'anime-clean': 'Thin clean contours define facial features and separate hair locks; mostly flat colors with small clean shadows, no dense painterly surface.',
    'anime-cel': 'Crisp linework and hard-edged cel shadow shapes on faces and clothing, flat local colors and a small highlight shape; avoid blended painted shadows.',
    'anime-shojo': 'Fine expressive ink contours and visible screentone shading on faces, hair and clothes; delicate eye lashes and generous white areas, not a softly painted anime portrait.',
    'anime-retro90': 'Slightly heavy analog ink contours, flat painted cels and restrained two-step face shadows. A light analog texture surrounds clearly drawn facial features and distinct hair shapes.',
    'anime-korean': 'Refined thin colored outlines, translucent skin tones and soft sparse shadows; clear airy eyes, economical hair detail, no heavy ink masses.',
    'anime-storybook': 'Simple storybook facial shapes, tactile brush marks, slightly irregular hand-drawn contours and quiet broad color areas; reduce polished anime eye detail.',
    'art-gongbi': 'Continuous hair-fine ink lines define facial contours, hair and garment folds, with many thin restrained color washes and slender ink edges.',
    'art-ink': 'Wet and dry ink strokes shape the hair and clothes, with expressive broken brush edges and quiet paper areas. Fine intentional strokes define facial features; sparse washes preserve their clarity.',
    'art-watercolor': 'Translucent overlapping washes, wet-on-wet transitions and pigment blooms build the portrait. Delicate controlled strokes resolve facial features; selective soft and lost edges belong to surrounding hair, clothing and background.',
    'art-pencil': 'Visible directional colored-pencil strokes across skin, hair and fabric, layered crosshatching and paper tooth; highlights are uncolored paper.',
    'art-oil': 'Visible directional brushstrokes build the face, hair and clothing; solid paint planes and impasto edges shape the light, with broad individually painted hair masses.',
    'art-sketch': 'Graphite strokes and crosshatching build face planes, hair and clothing; varied pencil pressure, erased highlights and white paper. All features remain monochrome, not colored eyes or flat manga screentones.',
    'craft-plush': 'Visible fabric seams shape the face and body; short fuzzy pile, embroidered eyes and mouth, stuffed rounded limbs. Hair is fabric tufts rather than painted strands.',
    'craft-clay': 'A visibly sculpted rounded face and chunky clay hair locks, small modeled limbs, matte handmade surfaces and gentle physical cast shadows.',
    'craft-crochet': 'Individual crochet loops build the face and body, yarn strands form hair and tiny clothes; stitched eyes, no smooth illustrated skin.',
    'craft-felt': 'Needle-felt fibers form the cheeks, hair and little limbs, uneven fuzzy edges and soft wool volume throughout each figure.',
    'craft-vinyl': 'Large simple molded toy shapes, a smooth satin vinyl face with printed features, sculpted hair masses and small seams; toy proportions, not realistic people.',
    'craft-paper': 'Separate cut-paper pieces form the face, hair and clothing, sharp or torn paper edges and tiny inter-layer shadows; no painted three-dimensional facial shading.',
    'graphic-pixel': 'A large head-and-shoulders or upper-body portrait fills each half. Use one consistent visible pixel grid, carefully shaped clusters and clear color separation for individual facial features, hair and clothing. Any visible hands connect through arms to shoulders; a quiet supporting background keeps the faces prominent.',
    'graphic-line': 'A few continuous economical contour strokes define the faces and hair, mostly empty interiors; preserve distinctive silhouettes without adding painted shading.',
    'graphic-silhouette': 'Two flat colors only, identity expressed through profile, hair and accessory contours; use negative shapes instead of fully rendered eyes or skin.',
    'graphic-print': 'Carved light and dark hatching shapes define cheeks, hair and fabric, limited ink overprints and small uneven ink edges; no continuous-tone painting.',
    'graphic-sticker': 'Bold simplified character silhouettes with readable expressions, clean flat or cel colors and a die-cut white outline following the subjects.',
    'graphic-geometric': 'Geometric planes construct the cheeks, eyes, hair and clothing; flat color boundaries replace brushwork, with recognizable individual silhouettes.',
    'photo-film': 'Candid photographic faces with natural asymmetry, coherent lens depth, fine film grain and restrained analog color response.',
    'photo-daylight': 'Natural daylight on real facial planes, clear skin texture, relaxed candid posture and soft background defocus; no airbrushed doll faces.',
    'photo-studio': 'A shared old studio backdrop, controlled key light with visible soft shadow shaping the faces, restrained vintage photographic color.',
    'photo-night': 'Real faces illuminated by the same colored night lights, natural shadow falloff, background bokeh and readable eyes, not painted neon contours.',
    'photo-backlight': 'Photographic facial structure with fine rim-lit hair, gentle optical bloom and shallow depth of field while keeping the eyes readable.',
    'photo-mono': 'Black-and-white photographic tonal gradients and skin texture, coherent lens perspective; no pencil strokes or manga ink shading.',
    'chibi-mochi': 'A soft near-spherical head-and-body silhouette, tiny feet and dot features, small signature accessories; no normal-length human torso.',
    'chibi-sleepy': 'Oversized sleepy head with half-closed eyes, a stubby small body and loose soft outlines; let the two have different sleepy responses.',
    'chibi-crayon': 'Lively wax crayon marks build the face, hair and body, with naive rounded proportions and deliberate simple expressions. Layered wax fills hold the shapes together while small paper-grain flecks preserve the handmade texture.',
    'anime-flat': 'Flat local colors, clear economical contours and almost no modeled shadows across faces and clothes; no dense glossy gradients.',
    'anime-manga': 'Black ink outlines, solid black areas, white paper and patterned screentone; draw expressions as ink shapes rather than grayscale painted portraits.',
    'anime-pastel': 'Soft colored outlines, round animated facial shapes and pale flat cel shadows; use pastel colors on the characters, not only behind them.',
    'anime-webtoon': 'Simplify each face into economical contours and one or two shadow shapes; broad clean hair masses and flat skin colors, no detailed painterly rendering.',
    'art-gouache': 'Opaque chalky paint strokes overlap across the face and hair, matte broad planes with visible bristle marks and slightly irregular painted edges.',
    'art-pastel': 'Thick wax strokes and broken color cover the face, hair and fabric; visible paper tooth and smudged layered edges.',
    'art-charcoal': 'Energetic charcoal strokes, controlled rubbed midtones and lifted paper highlights construct resolved facial planes and hair. Selective gestural marks and velvety paper texture retain the expressive drawing character.',
    'art-risograph': 'Limited spot-color layers and fine visible grain build the portraits. Subtle registration shifts at broad color edges retain the print character while facial outlines and distinguishing features remain clearly aligned.',
    'craft-porcelain': 'Small sculpted ceramic faces, painted-on features and hair areas, rounded porcelain bodies and translucent glaze reflections.',
    'craft-wood': 'Faceted carving marks and wood grain run across the face, hair and body, with tiny painted facial features and a real object silhouette.',
    'craft-origami': 'Folded paper planes construct the head, face and clothes; sharp folds, visible paper thickness and small cast shadows, no organic skin rendering.',
    'craft-bead': 'Individual round plastic beads on a regular square grid form every facial and hair feature; visible bead holes and material, not merely pixel illustration.',
    'graphic-8bit': 'A large head-and-shoulders or upper-body portrait fills each half, with visible clothing and distinctive hair shapes. A consistent square grid and a few colors form carefully placed readable facial features. Any visible hands connect through arms to shoulders; a simple broad-color background keeps attention on the subjects. Preserve crisp stepped pixel edges.',
    'graphic-pop': 'Bold graphic facial outlines, large halftone dots and contrasting flat spot colors cover the subjects themselves.',
    'graphic-comic': 'Heavy expressive ink, crosshatched facial shadows and printed halftone colors, with simplified readable hair masses.',
    'graphic-lino': 'Broad carved negative spaces and two ink colors define clear faces, hair and clothing. Controlled ink texture stays inside deliberate printed shapes, with coherent facial marks and cleanly cut silhouettes; flat inks retain the stamp character.',
    'photo-instant': 'Real candid faces with soft direct flash, mild analog color shifts, shallow lens depth and informal snapshots, edge-to-edge scenery.',
    'photo-rain': 'Real facial planes in soft window sidelight, optical reflections and defocused rain behind the subjects, not raindrops painted onto an anime portrait.',
    'animal-cat': 'Feline skulls, triangular ears, short muzzles, whiskers, paws and tails; no human face underneath cat ears.',
    'animal-dog': 'Canine muzzles, noses, dog ears, paws and tails; individual fur markings and different expressions distinguish the two dogs.',
    'animal-fox': 'Long fox muzzles, pointed ears, fluffy cheek fur and bushy tails; both are complete foxes with their own markings.',
    'animal-rabbit': 'Rabbit noses, round cheeks, long floppy ears, small forepaws and rounded hindquarters; no human hair or fingers.',
    'animal-bear': 'Bear muzzles, round ears, compact thick bodies and broad paws; express each personality through posture and accessories.',
    'animal-bird': 'Visible beaks, rounded feathered bodies, folded wings and small bird feet; hair colors become feather markings, not human hair.',
    'animal-seal': 'Seal whiskers, short muzzles, smooth rounded bodies and flippers; accessories and each face reaction carry the identities.',
    'fantasy-glass': 'Colored glass pieces and lead seams build the cheeks, eyes, hair and clothing; translucent light passes through the shapes.',
    'fantasy-enamel': 'Raised metal outlines divide glossy solid enamel fields across the entire little portrait; physical pin edge and thickness.',
    'fantasy-embroidery': 'Directional visible thread stitches build the face and hair, with stitched clothing and slight thread relief over fabric.',
    'fantasy-mosaic': 'Small ceramic tesserae and visible grout construct the facial features and hair, with tiny glazed reflections.',
    'fantasy-blueprint': 'Prussian blue and paper white only, photographic cyanotype silhouettes and uneven contact-print tone; identity colors become tonal differences.',
    'fantasy-shadow': 'Translucent leather, cutout facial ornament, articulated puppet shapes and backlit color; no smooth painted human portrait.',
    'fantasy-luminous': 'Layered cut-paper shapes form each face and body, with light shining between physical paper layers and edges.',
    'fantasy-fresco': 'Matte mineral pigment strokes create clear facial planes, flowing mural hair contours and broad restrained color areas. Fine plaster texture and selective surface wear retain the mural character while preserving facial features and key gestures.',
});

export function coupleStyleConstruction(style) {
    return style ? [MEDIUM_CONSTRUCTION[style.group], STYLE_CONSTRUCTION[style.id]].filter(Boolean).join(' ') : '';
}

const INTERACTION_ROLES = Object.freeze({
    '半颗爱心': ['hold one heart half toward the right inner edge', 'hold the complementary heart half toward the left inner edge'],
    '隔空对望': ['turn slightly right and look toward the other subject', 'turn slightly left and return the gaze with a different expression'],
    '左右眨眼': ['give a confident playful wink', 'answer with a bashful wink and a different head tilt'],
    '一根红线': ['lift one end of the red thread toward the right', 'notice and gently hold the other end toward the left'],
    '隔空击掌': ['raise the inner hand or forepaw toward the right', 'reach the inner hand or forepaw toward the left to meet it'],
    '悄悄牵住衣角': ['gently catch the other subject\'s clothing edge or accessory', 'notice the small tug and glance back shyly'],
    '递出一朵花': ['offer a flower toward the right', 'reach toward the left to receive the flower'],
    '碰一碰鼻尖': ['lean right with a gentle forward tilt', 'lean left with a different gentle tilt, bringing noses close'],
    '替你理围巾': ['reach inward to straighten the other subject\'s scarf', 'hold still and smile softly at the caring gesture'],
    '藏在背后的小花': ['hide a small flower behind the back with an expectant look', 'peek inward curiously, trying to see the hidden flower'],
    '一边闹一边笑': ['playfully tease with an animated gesture', 'laugh in response with a relaxed different posture'],
    '假装生气': ['puff up in mock annoyance', 'try to suppress an amused smile'],
    '偷偷模仿你': ['strike a serious confident pose', 'playfully imitate the pose with a mischievous expression'],
    '一边偷看一边躲': ['peek inward around a small prop', 'bashfully turn slightly away while noticing the glance'],
    '互相做鬼脸': ['make one playful silly face toward the right', 'reply with a visibly different silly face toward the left'],
    '一边困一边闹': ['look drowsy with half-closed eyes and relaxed posture', 'lean inward energetically to seek attention'],
    '偷偷戴上同款': ['show a matching small accessory with a knowing smile', 'wear the matching accessory and pretend not to notice'],
    '被发现的偷笑': ['try to suppress a laugh after being noticed', 'give a knowing sidelong look toward the left'],
    '举杯碰杯': ['raise a cup toward the right inner edge', 'tilt a cup toward the left to answer the toast'],
    '一人一只小动物': ['gently cuddle a small pet while looking inward', 'let another small pet lean close while responding inward'],
    '耳机分你一只': ['offer the shared earphone cable inward with a pleased look', 'listen through one earphone with a softer answering expression'],
    '同款不同色': ['show one version of the coordinated clothing with an open pose', 'show the complementary version with a different relaxed pose'],
    '一起看烟花': ['point toward the fireworks with delighted surprise', 'watch the same fireworks with a quiet smile and reflected light'],
    '并肩吹泡泡': ['blow a bubble toward the right', 'watch an incoming bubble and prepare to blow another'],
    '共用一条围巾': ['hold one end of the shared scarf near the chest', 'nestle into the other end with an answering head tilt'],
    '分享一把伞': ['hold an umbrella tilted inward toward the other subject', 'lean into the offered shelter with a grateful expression'],
    '一起读一本书': ['point at a passage in the shared book', 'follow the indicated passage with a different amused reaction'],
    '举起同款相机': ['raise the small camera to take a picture', 'hold the matching camera lower and smile for the picture'],
    '一人一半饼干': ['offer one cookie half inward', 'hold the other cookie half and answer with a different pleased expression'],
    '递来最后一口': ['offer the last bite of a snack toward the right', 'lean toward the offered bite with pleasantly surprised eyes'],
    '草莓分给你': ['hold out a strawberry toward the right', 'lean toward the strawberry with an eager answering expression'],
    '两杯不同口味': ['hold one drink flavor and offer a curious glance', 'hold the other flavor and respond with a pleased different expression'],
    '偷吃被发现': ['look caught with a few snack crumbs near the mouth', 'notice the crumbs with amused surprise'],
    '一串糖葫芦': ['offer the candied-fruit skewer toward the right', 'lean inward to take a bite'],
    '交换便当': ['offer one small lunch box inward', 'receive it while offering the other lunch box back'],
    '融化的冰淇淋': ['worry over a melting ice cream', 'offer a napkin toward the left with a reassuring smile'],
    '接住一片落叶': ['release a leaf toward the right', 'reach inward to catch the drifting leaf'],
    '一起捧雪花': ['cup a snowflake and look surprised', 'look at another snowflake with a softer delighted response'],
    '围巾里躲风': ['nestle down into a scarf against the wind', 'lean inward to share warmth'],
    '花瓣落在头顶': ['wear an unnoticed flower petal on the head', 'point out the petal with a smile'],
    '夏夜捕萤': ['follow a nearby firefly with an attentive gaze', 'reach gently toward another firefly with a different curious reaction'],
    '雨后踩水花': ['make a small playful splash toward the right', 'react to the splash with amused surprise'],
    '同一阵风': ['face the shared breeze with a lifted gaze', 'brace lightly against the same breeze with a different head angle'],
    '日与月的呼应': ['relate to the sun motif and its warm light', 'relate to the moon motif and its cool light with a different pose'],
    '星星递给你': ['offer a small glowing star toward the right', 'reach inward toward the offered star'],
    '拼成一朵花': ['hold or echo one flower half at the inner edge', 'complete the flower with its complementary half and a different expression'],
    '纸飞机传话': ['release a paper airplane toward the right', 'wait to catch the incoming paper airplane'],
    '两边同一片海': ['show one seashell against the shared sea horizon', 'show a different seashell while responding toward the left'],
});

export const INTERACTION_PRESETS = Object.freeze([
    ['甜甜互动', '半颗爱心', 'each subject holds half a heart at the inner edge; together the halves form one heart'],
    ['甜甜互动', '隔空对望', 'left subject gazes right; right subject gazes left with an affectionate response'],
    ['甜甜互动', '左右眨眼', 'complementary playful winks with distinct individual expressions'],
    ['甜甜互动', '一根红线', 'a fine red thread connects the two subjects across the central boundary'],
    ['甜甜互动', '隔空击掌', 'the two subjects extend matching hands or forepaws toward the inner edges for a high-five'],
    ['甜甜互动', '悄悄牵住衣角', 'one gently catches the other\'s clothing edge or small accessory; the other responds shyly'],
    ['甜甜互动', '递出一朵花', 'one offers a flower inward; the other reaches inward to receive it'],
    ['甜甜互动', '碰一碰鼻尖', 'two faces turned inward, noses gently meeting across the boundary'],
    ['甜甜互动', '替你理围巾', 'one straightens the other\'s scarf while the other smiles softly'],
    ['甜甜互动', '藏在背后的小花', 'one hides a small flower behind their back; the other peeks curiously'],
    ['俏皮表情', '一边闹一边笑', 'one playfully teases; the other laughs in response'],
    ['俏皮表情', '假装生气', 'one puffs up in mock annoyance; the other tries not to laugh'],
    ['俏皮表情', '偷偷模仿你', 'one strikes a serious pose; the other playfully copies it'],
    ['俏皮表情', '一边偷看一边躲', 'one peeks around a prop toward the other; the other bashfully looks away'],
    ['俏皮表情', '互相做鬼脸', 'different silly faces directed toward one another'],
    ['俏皮表情', '一边困一边闹', 'one is drowsy with half-closed eyes; the other playfully seeks attention'],
    ['俏皮表情', '偷偷戴上同款', 'matching little accessories; one knowingly smiles and the other pretends not to notice'],
    ['俏皮表情', '被发现的偷笑', 'one is caught suppressing a laugh; the other gives a knowing sidelong look'],
    ['日常陪伴', '举杯碰杯', 'each raises a cup toward the other for a small shared toast'],
    ['日常陪伴', '一人一只小动物', 'each subject is accompanied by a small pet with complementary affectionate gestures'],
    ['日常陪伴', '耳机分你一只', 'each wears one earphone, a shared cable visually joins their portraits'],
    ['日常陪伴', '同款不同色', 'matching clothing or accessories in two complementary colors'],
    ['日常陪伴', '一起看烟花', 'both gaze at shared fireworks with different delighted expressions and matching reflected light'],
    ['日常陪伴', '并肩吹泡泡', 'both blow bubbles with different expressions; bubbles drift across the two portraits'],
    ['日常陪伴', '共用一条围巾', 'one long scarf wraps loosely around both subjects across the central boundary'],
    ['日常陪伴', '分享一把伞', 'one holds a shared umbrella tilted toward the other; each remains in their own half'],
    ['日常陪伴', '一起读一本书', 'a shared open book spans the lower center; each reacts differently to the same page'],
    ['日常陪伴', '举起同款相机', 'both hold matching small cameras, one takes a photo while the other smiles'],
    ['分享零食', '一人一半饼干', 'each holds half of the same cookie toward the inner edge'],
    ['分享零食', '递来最后一口', 'one offers the last bite of a snack; the other looks pleasantly surprised'],
    ['分享零食', '草莓分给你', 'one offers a strawberry inward; the other eagerly leans toward it'],
    ['分享零食', '两杯不同口味', 'matching drink cups in different colors and two distinct pleased expressions'],
    ['分享零食', '偷吃被发现', 'one has snack crumbs near their mouth; the other notices with amused surprise'],
    ['分享零食', '一串糖葫芦', 'one offers a candied-fruit skewer across the center; the other prepares to take a bite'],
    ['分享零食', '交换便当', 'two small lunch boxes offered toward the center with warm smiles'],
    ['分享零食', '融化的冰淇淋', 'one worries over melting ice cream; the other offers a napkin'],
    ['季节小事', '接住一片落叶', 'one releases a leaf toward the center; the other catches it'],
    ['季节小事', '一起捧雪花', 'matching snowflakes land near their faces; each shows a different delighted expression'],
    ['季节小事', '围巾里躲风', 'one nestles into a scarf against the wind; the other leans closer for warmth'],
    ['季节小事', '花瓣落在头顶', 'a flower petal rests on one subject; the other points it out with a smile'],
    ['季节小事', '夏夜捕萤', 'each follows a firefly; warm firefly trails connect the two halves'],
    ['季节小事', '雨后踩水花', 'one splashes a tiny puddle toward the center; the other reacts playfully'],
    ['季节小事', '同一阵风', 'the same gentle breeze moves both subjects\' hair, fur or accessories in one direction'],
    ['意象呼应', '日与月的呼应', 'complementary sun and moon motifs with warm and cool light'],
    ['意象呼应', '星星递给你', 'one offers a small glowing star; the other reaches toward it'],
    ['意象呼应', '拼成一朵花', 'two complementary flower halves meet across the center'],
    ['意象呼应', '纸飞机传话', 'one sends a paper airplane toward the center; the other waits to catch it'],
    ['意象呼应', '两边同一片海', 'matching horizon and sea breeze, each subject holds a different seashell'],
].map(([group, label, prompt]) => Object.freeze({ group, label, prompt, roles: Object.freeze(INTERACTION_ROLES[label] || []) })));

export const INTERACTIONS = Object.freeze([...INTERACTION_PRESETS.map(row => row.label), '交给灵感', '自定义互动']);

// Keep a generated idea's wording and its two actions together. These are local
// authoring templates, not an extra translation/generation request. Existing
// saved ideas remain plain strings; only an exact known template is expanded.
const IDEA_MOMENTS = Object.freeze([
    ['左边递出一朵小花，右边伸手接住', 'offer a small flower toward the right', 'reach left to receive the flower'],
    ['左边偷藏一颗糖，右边假装没发现', 'secretly hide a piece of candy', 'pretend not to notice the hidden candy'],
    ['左边举起一半爱心，右边拿着另一半回应', 'raise one heart half toward the right', 'hold the other heart half toward the left in response'],
    ['左边轻轻拉住围巾一端，右边靠过来', 'gently tug one end of the scarf', 'lean toward the left in response to the tug'],
    ['左边捧着小星星，右边试着触碰它的光', 'hold a small glowing star toward the right', 'reach toward the left to touch the star light'],
    ['左边吹出一个泡泡，右边追着泡泡看', 'blow a bubble toward the right', 'follow the drifting bubble with the eyes'],
    ['左边把小纸船推过来，右边在另一侧接住', 'push a little paper boat toward the right', 'catch the paper boat coming from the left'],
    ['左边藏在叶子后偷看，右边歪头找它', 'peek from behind a leaf', 'tilt the head and look left to find the hidden subject'],
    ['左边递来热饮，右边把小饼干分过去', 'offer a warm drink toward the right', 'offer a small cookie toward the left in return'],
    ['左边举着小相机，右边故意做个鬼脸', 'raise a small camera toward the right', 'make a playful silly face for the camera'],
    ['左边把花瓣放到头顶，右边学着戴上另一片', 'place a flower petal on top of the head', 'copy the gesture with a different petal'],
    ['左边送出纸飞机，右边伸手迎接', 'send a paper airplane toward the right', 'reach left to catch the paper airplane'],
    ['左边指着远处的烟花，右边偷偷看左边', 'point toward the distant fireworks', 'secretly glance toward the subject on the left'],
    ['左边捧着一团雪，右边围着围巾笑', 'cup a little snowball', 'smile while nestled in a scarf'],
    ['左边戴着歪歪的小帽子，右边伸手扶正', 'wear a small tilted hat', 'reach left to straighten the tilted hat'],
    ['左边递出一枚贝壳，右边回赠一颗小石子', 'offer a seashell toward the right', 'give a small pebble toward the left in return'],
]);
const IDEA_MOODS = Object.freeze([
    ['一个认真、一个忍不住笑', 'a serious expression', 'an amused smile'],
    ['一个害羞、一个温柔回应', 'a shy expression', 'a gentle warm response'],
    ['一个得意、一个假装嫌弃', 'a proud playful expression', 'a playfully unimpressed reaction'],
    ['一个好奇、一个耐心陪伴', 'a curious expression', 'a patient caring expression'],
    ['一个困困的、一个很有精神', 'a sleepy expression', 'an energetic expression'],
    ['一个有点惊讶、一个偷偷开心', 'a slightly surprised expression', 'a quietly delighted expression'],
]);
const IDEA_SCENES = Object.freeze([
    ['纯色背景铺满画面，重点放在动作和表情', 'A quiet solid-color ground fills the image, focusing attention on gestures and expressions.'],
    ['同一束柔光落在两边', 'The same soft light falls on both subjects.'],
    ['两边用相呼应的淡色背景', 'Coordinated pale colors fill the continuous background.'],
    ['共享一个小小的窗边场景', 'Both share a small scene beside a window.'],
    ['点缀几片花瓣，不遮住脸', 'A few petals drift around the subjects, keeping their faces clear.'],
]);

export function coupleInteraction(interaction, detail = '') {
    const preset = INTERACTION_PRESETS.find(item => item.label === interaction);
    if (preset) return { prompt: preset.prompt, roles: [...preset.roles] };
    const raw = interaction === '自定义互动' ? detail : interaction;
    const moment = IDEA_MOMENTS.find(row => raw.startsWith(row[0] + '；'));
    if (moment) {
        const rest = raw.slice(moment[0].length + 1);
        const mood = IDEA_MOODS.find(row => rest.startsWith(row[0] + '。'));
        const sceneText = mood ? rest.slice(mood[0].length + 1).replace(/。$/, '') : '';
        const scene = IDEA_SCENES.find(row => row[0] === sceneText);
        // Recognize the old built-in quiet-background suggestion too; keep
        // that light ground continuous instead of describing a framing gap.
        const oldScene = sceneText === '背景留白，重点放在动作和表情';
        if (mood && (scene || oldScene)) {
            const roles = [1, 2].map(i => `${moment[i]}, with ${mood[i]}`);
            return { prompt: `The left subject ${roles[0]}; the right subject ${roles[1]}. ${scene?.[1] || IDEA_SCENES[0][1]}`, roles };
        }
    }
    // Free text is never discarded or guessed at by splitting punctuation.
    // Each subject receives the actual interaction, not a role placeholder.
    return { prompt: raw, roles: ['LEFT', 'RIGHT'].map(side => raw && raw !== '交给灵感'
        ? `follow the ${side} subject's action in this user interaction: ${raw}`
        : `choose a fresh individual gesture and expression for the ${side} subject, responding to the other subject`) };
}

// Local inspiration only: browsing ideas never sends a paid generation request.
export function randomCoupleIdeas(previous = [], random = Math.random) {
    const moments = IDEA_MOMENTS.map(row => row[0]);
    const moods = IDEA_MOODS.map(row => row[0]);
    const scenes = IDEA_SCENES.map(row => row[0]);
    const pick = values => values[Math.min(values.length - 1, Math.max(0, Math.floor(random() * values.length)))];
    const shuffled = moments.filter(moment => !previous.some(idea => idea.startsWith(moment)));
    for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.min(i, Math.max(0, Math.floor(random() * (i + 1))));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return (shuffled.length ? shuffled : moments).slice(0, 3).map(moment => `${moment}；${pick(moods)}。${pick(scenes)}。`);
}

// NAI5-only authoring guidance. The caller opts in; the historical style
// catalog and construction strings stay unchanged for saved legacy prompts.
export function coupleStyleIdentityRendering(chosen) {
    const style = COUPLE_STYLES.find(row => row.id === chosen?.id);
    if (!style) return '';
    const identity = "Use only this subject's supplied identity; shared traits may remain shared. Never transfer the other subject's features or invent differences.";
    if (style.group === 'animal') return `${identity} Express these through this animal's own markings and small accessories, keeping the selected animal anatomy.`;
    if (style.group === 'craft' || ['fantasy-enamel', 'fantasy-shadow'].includes(style.id)) {
        return `${identity} Keep its distinguishing silhouettes and accessories as material-built shapes in the selected crafted form.`;
    }
    const form = "Preserve its own hair silhouette and accessories in the selected medium.";
    const proportions = style.group === 'chibi' ? 'Keep the selected proportions and framing.' : '';
    const eyes = style.id === 'chibi-doodle'
        ? 'When visible, the two eyes are tiny solid dots; supplied eye color only tints those dots. Use simple mouth/brow marks, without detailed irises; retain supplied eye coverings.'
        : '';
    return [identity, form, proportions, eyes].filter(Boolean).join(' ');
}
