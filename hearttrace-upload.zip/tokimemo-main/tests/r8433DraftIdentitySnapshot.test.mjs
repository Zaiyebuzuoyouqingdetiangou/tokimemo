import test from 'node:test';
import assert from 'node:assert/strict';
import * as recovery from '../src/generation/recovery.js';
import * as client from '../src/generation/client.js';
import * as core_context from '../src/core/context.js';
import * as core_evidence from '../src/core/evidence.js';
import * as constants from '../src/core/constants.js';
import { state as runtimeState } from '../src/core/state.js';

// r84.33: (A) the recovery identity embeds a card-content fingerprint; ordinary
// card edits drift it and were misread as a character switch. When the draft
// lookup key already proves same slot + same avatar + same chat, fingerprint-only
// drift is tolerated while real switches still hard-block. (B) a full archive at
// the legitimate item cap serialized beyond the snapshot budget and blocked every
// derived task pre-request; snapshots that exceed the budget now carry a
// distilled bank (summary trimmed to the existing prompt contract, evidence
// fields byte-identical). No cap is raised and no protection is removed.

const baseOrigin = () => ({ characterKey: 'card:fpA\u001fcharacter:7', characterId: '7', characterAvatar: 'a.png',
    chatId: 'chat-1', archiveRevision: 'r1', archiveTargetEntryId: 'e1' });

async function createJournal(origin = baseOrigin(), settingsIdentity = 's') {
    const handle = await recovery.createGenerationRecovery({ origin, mode: 'album', settingsIdentity,
        contentSnapshot: { version: 1, archiveInputsHash: 'h' }, save: () => true });
    return structuredClone(handle.journal);
}

test('same slot, avatar and chat with drifted card fingerprint can continue the draft', async () => {
    const existing = await createJournal();
    const drifted = { ...baseOrigin(), characterKey: 'card:fpB-edited-character-card\u001fcharacter:7' };
    let saved = 0;
    const handle = await recovery.createGenerationRecovery({ origin: drifted, mode: 'album', settingsIdentity: 's',
        existing, continueRequested: true, save: () => { saved++; return true; } });
    assert.ok(handle.journal, 'continuation must succeed for fingerprint-only drift');
    assert.equal(handle.journal.identity.characterKey, 'card:fpA\u001fcharacter:7',
        'the original identity binding stays on the journal as evidence');
});

test('a real character switch still hard-blocks continuation', async () => {
    const existing = await createJournal();
    for (const [label, origin, category] of [
        ['different slot', { ...baseOrigin(), characterKey: 'card:fpA\u001fcharacter:8', characterId: '8' }, 'character'],
        ['different avatar', { ...baseOrigin(), characterKey: 'card:fpC\u001fcharacter:7', characterAvatar: 'b.png' }, 'character'],
        ['different chat', { ...baseOrigin(), chatId: 'chat-2' }, 'chat'],
    ]) {
        await assert.rejects(
            recovery.createGenerationRecovery({ origin, mode: 'album', settingsIdentity: 's',
                existing: structuredClone(existing), continueRequested: true, save: () => true }),
            error => error.code === 'RMT_RECOVERY_INPUT_CHANGED' && error.archiveInputCategory === category,
            `${label} must still be rejected`);
    }
});

test('empty avatar gives no fingerprint-drift tolerance', async () => {
    const origin = { ...baseOrigin(), characterAvatar: '' };
    const existing = await createJournal(origin);
    const drifted = { ...origin, characterKey: 'card:fpE\u001fcharacter:7' };
    await assert.rejects(
        recovery.createGenerationRecovery({ origin: drifted, mode: 'album', settingsIdentity: 's',
            existing, continueRequested: true, save: () => true }),
        error => error.code === 'RMT_RECOVERY_INPUT_CHANGED' && error.archiveInputCategory === 'character');
});

const fakeContext = (description, avatar = 'a.png', id = '7') => ({ characterId: id, chatId: 'chat-1', name2: '测试角色',
    characters: Object.assign([], { [id]: { name: '测试角色', avatar, data: { avatar, description } } }) });

test('taskOriginCharacterMatches tolerates card edits but blocks real switches', () => {
    const before = fakeContext('第一版角色卡');
    const origin = { characterKey: core_context.currentCharacterRuntimeKey(before), characterId: '7',
        characterAvatar: 'a.png', chatId: 'chat-1' };
    const after = fakeContext('完全重写的角色卡描述');
    assert.notEqual(core_context.currentCharacterRuntimeKey(after), origin.characterKey,
        'fixture sanity: the card edit must actually drift the fingerprint');
    assert.equal(core_context.taskOriginCharacterMatches(origin, after), true, 'same slot + avatar must match');
    assert.equal(core_context.taskOriginCharacterMatches(origin, fakeContext('第一版角色卡', 'other.png')), false,
        'a changed avatar must still fail');
    assert.equal(core_context.taskOriginCharacterMatches(origin, fakeContext('第一版角色卡', 'a.png', '8')), false,
        'a changed card slot must still fail');
});

test('view gates stay strict on card edits while run gates tolerate them', () => {
    const before = fakeContext('第一版角色卡');
    const origin = { characterKey: core_context.currentCharacterRuntimeKey(before), characterId: '7',
        characterAvatar: 'a.png', chatId: 'chat-1', lifecycleEpoch: runtimeState.runtimeLifecycleEpoch };
    assert.equal(core_context.isCurrentTaskOrigin(origin, fakeContext('又一次编辑')), false,
        'late read/repaint paths must not rebind under edited card text');
    assert.equal(core_context.isCurrentTaskRunOrigin(origin, fakeContext('又一次编辑')), true,
        'run gates tolerate same-person card edits');
    assert.equal(core_context.isCurrentTaskRunOrigin({ ...origin, lifecycleEpoch: -1 }, fakeContext('又一次编辑')), false,
        'a stale lifecycle epoch must still fail');
    assert.equal(core_context.isCurrentTaskRunOrigin(origin, { ...fakeContext('又一次编辑'), chatId: 'chat-9' }), false,
        'a changed chat must still fail');
});

const memoryAt = (index, summaryChars) => ({ id: `M${String(index + 1).padStart(3, '0')}`, title: `事件 ${index + 1}`,
    date: '2026-09-21', summary: `摘要${index}-${'叙'.repeat(summaryChars)}`,
    anchors: [`锚点${index}`, '灯塔', ...Array.from({ length: 6 }, (_, k) => `补充锚点${k}-${'锚'.repeat(110)}`)],
    participants: ['测试角色', '用户', ...Array.from({ length: 8 }, (_, k) => `路人${k}-${'名'.repeat(110)}`)],
    messageStart: index * 10, messageEnd: index * 10 + 9, sourceKind: 'chat' });

const snapshotWith = memories => ({ version: 1, fields: { characterId: '7' }, cardFields: {},
    memoryBank: { archiveName: '共同回忆', archiveRevision: 'r1', chatId: 'chat-1', characterName: '测试角色',
        userName: '用户', memories },
    contentSettings: {} });

test('snapshots within the budget stay byte-identical with no distilled marker', () => {
    const snapshot = snapshotWith([memoryAt(0, 100)]);
    const fitted = client.fitGenerationContentSnapshot(snapshot);
    assert.equal(fitted, snapshot, 'small archives must take the unchanged full-snapshot path');
    assert.equal(fitted.memoryBankDistilled, undefined);
});

test('a full-cap archive distills summaries, keeps evidence fields, and fits the unchanged budget', () => {
    const memories = Array.from({ length: 240 }, (_, i) => memoryAt(i, 4000));
    const snapshot = snapshotWith(memories);
    assert.ok(JSON.stringify(snapshot).length > recovery.GENERATION_RECOVERY_LIMITS.requestChars,
        'fixture sanity: the full-cap archive must exceed the snapshot budget');
    const fitted = client.fitGenerationContentSnapshot(snapshot);
    assert.equal(fitted.memoryBankDistilled, true);
    assert.equal(typeof fitted.memoryBankDigest, 'string');
    assert.ok(JSON.stringify(fitted).length <= recovery.GENERATION_RECOVERY_LIMITS.requestChars,
        'distilled snapshot must fit the unchanged requestChars budget');
    assert.equal(fitted.memoryBank.memories.length, 240, 'every memory entry must be kept');
    for (let i = 0; i < 240; i++) {
        const original = memories[i], distilled = fitted.memoryBank.memories[i];
        assert.equal(distilled.id, original.id);
        assert.equal(distilled.title, original.title);
        assert.deepEqual(distilled.anchors, original.anchors, 'evidence anchors stay byte-identical');
        assert.deepEqual(distilled.participants, original.participants);
        assert.equal(distilled.messageStart, original.messageStart);
        assert.equal(distilled.messageEnd, original.messageEnd);
        assert.ok(distilled.summary.length <= fitted.memoryBankSummaryChars);
    }
    assert.equal(fitted.memoryBank.archiveRevision, 'r1');
});

test('evidence validation returns identical results on a distilled bank', () => {
    const memories = Array.from({ length: 240 }, (_, i) => memoryAt(i, 2200));
    const full = snapshotWith(memories).memoryBank;
    const distilled = client.fitGenerationContentSnapshot(snapshotWith(memories)).memoryBank;
    for (const ids of [['M001'], ['M120', 'M240']]) {
        const expected = core_evidence.normalizeMemoryReference(ids, '灯塔', '正文提到灯塔与夜色', full, 1);
        const actual = core_evidence.normalizeMemoryReference(ids, '灯塔', '正文提到灯塔与夜色', distilled, 1);
        assert.deepEqual(actual, expected, 'id/title/anchors evidence checks must not drift');
    }
});

test('an oversized snapshot with no distillable bank still fails before any request', async () => {
    const snapshot = { ...snapshotWith([memoryAt(0, 100)]), cardFields: { huge: '卡'.repeat(2000000) } };
    const fitted = client.fitGenerationContentSnapshot(snapshot);
    assert.ok(JSON.stringify(fitted).length > recovery.GENERATION_RECOVERY_LIMITS.requestChars);
    let saved = 0;
    await assert.rejects(
        recovery.createGenerationRecovery({ origin: baseOrigin(), mode: 'album', settingsIdentity: 'x',
            existing: null, save: () => { saved++; }, contentSnapshot: fitted }),
        error => error.code === 'RMT_RECOVERY_SNAPSHOT_TOO_LARGE' && error.safeToDisplay === true);
    assert.equal(saved, 0);
});

test('recovery limits and the archive item cap are unchanged', () => {
    assert.deepEqual({ ...recovery.GENERATION_RECOVERY_LIMITS },
        { segments: 128, segmentChars: 600000, journalChars: 1800000, requestChars: 1200000, maxAgeMs: 7 * 24 * 60 * 60 * 1000 });
    assert.equal(constants.MAX_MEMORY_ITEMS, 240);
});
