import test from 'node:test';
import assert from 'node:assert/strict';
import { archiveRecoveryHtml } from '../src/ui/recoveryView.js';
import * as styles from '../src/ui/workspaceStyles.js';

for (const summary of [
    { completed: 2, notice: '保留正文', drafts: [{ draftId: 'draft-1' }] },
    { onlyArchivedDrafts: true, notice: '保留旧草稿', drafts: [{ draftId: 'old', paused: true }] },
    { pageOnly: true, completed: 1, notice: '可保存本页' },
]) test(`recovery actions share a layout container: ${summary.notice}`, () => {
    const html = archiveRecoveryHtml(summary);
    assert.match(html, /<div class="rmt-recovery-actions">/);
    const group = html.match(/<div class="rmt-recovery-actions">([\s\S]*?)<\/div>/)?.[1] || '';
    assert.ok(group.includes('<button'));
    assert.equal((group.match(/<button/g) || []).length, (html.match(/<button/g) || []).length);
    assert.ok(html.includes(summary.notice));
});

test('shared capsule rules cover body, dialogs and grouped actions without hiding labels', () => {
    assert.equal(typeof styles.capsuleCss, 'function');
    const css = styles.capsuleCss('#fixture');
    assert.ok(css.includes('#fixture'));
    for (const name of ['rmt-recovery-actions', 'rmt-cg-prompt-actions', 'rmt-filter', 'rmt-participant-dialog']) assert.ok(css.includes(name), name);
    assert.match(css, /gap:8px/);
    assert.match(css, /min-width:0/);
    assert.match(css, /white-space:normal/);
    assert.doesNotMatch(css, /text-overflow:ellipsis|-webkit-line-clamp/);
    assert.match(css, /\.rmt-btn\[hidden\]\{display:none!important\}/);
});
