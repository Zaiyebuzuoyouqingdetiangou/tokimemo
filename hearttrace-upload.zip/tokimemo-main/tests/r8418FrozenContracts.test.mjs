import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import {createHash}from'node:crypto';
import * as schema from '../src/modes/postcardDesign.js';
const root=new URL('../',import.meta.url),read=p=>fs.readFileSync(new URL(p,root),'utf8'),sha=s=>createHash('sha256').update(s).digest('hex');
const hashes=JSON.parse(read('tests/helpers/r8418UntouchedHashes.json'));
for(const group of ['src/modes/','src/core/','src/ui/','src/generation/','src/archive/'])test('r8418 actually untouched file bytes vs r84.17: '+group,()=>{
 const names=Object.keys(hashes).filter(p=>p.startsWith(group));assert.ok(names.length);for(const p of names)assert.equal(sha(read(p)),hashes[p],p);
});
test('new identity is consistent and upstream uploader filenames/layout unchanged',()=>{
 const m=JSON.parse(read('manifest.json'));assert.equal(m.version,'0.8.94');assert.equal(m.js,'index.js?heartbeat=0.8.94-tt-cg-r84.18-sketch-readonly');
 assert.match(read('index.js'),/const BUILD = '0\.8\.94-tt-cg-r84\.18-sketch-readonly'/);
});
test('no boat-water validity gate and all structural limits preserved',()=>{
 assert.equal(schema.MAX_DESIGN_NODES,90);assert.equal(schema.MAX_DESIGN_BYTES,8192);assert.equal(schema.MAX_DESIGN_ELEMENTS,20);assert.equal(schema.DESIGN_KINDS.length,24);
 assert.doesNotMatch(read('src/modes/postcardDesign.js'),/elements\.some\(item => item\.kind === 'boat'/);
});
test('r84.17 legacy visual prompt output remains byte-identical',()=>{
 assert.equal(sha(schema.postcardDesignInstructions(true)),'ae283644e1f84975f3c5ab146f58bb9c9e92f2a2665c7c61199eeae5a43adfbd');
});
test('only travel-map receives new versioned recovery contract',()=>{
 const s=read('src/generation/recovery.js');assert.match(s,/'travel-sketch-design-r8418': Object\.freeze\(\{ mode: 'travel', slot: \/:travel-map\$\//);
 assert.match(s,/previous\.requestHash !== requestHash/);assert.match(s,/!handle\.continueRequested \|\| previous\.contract/);
});
test('backup recovery reuses indexed read action rather than flipping backup flag or binding host',()=>{
 const s=read('src/archive/library.js');assert.match(s,/cached && !cached\.backupOnly/);assert.match(s,/重试读取源聊天/);assert.match(s,/if \(!viewStillCurrent\(\)\) return;/);
 assert.doesNotMatch(s,/\.backupOnly\s*=\s*false|delete\s+\w+\.backupOnly|setInterval\(|\/api\/chats\/delete/);
});
