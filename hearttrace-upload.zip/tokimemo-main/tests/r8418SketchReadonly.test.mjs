import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { fixture } from './helpers/r847Host.mjs';
import { design, el, location, scenes } from './helpers/r8416DesignFixtures.mjs';
import * as schema from '../src/modes/postcardDesign.js';
import * as draw from '../src/ui/postcardDesignView.js';
import * as library from '../src/archive/library.js';
import * as overlay from '../src/ui/overlay.js';
import * as workspace from '../src/ui/workspace.js';
import * as cache from '../src/core/cache.js';
import * as context from '../src/core/context.js';
import * as C from '../src/core/constants.js';
import * as client from '../src/generation/client.js';
import * as travelView from '../src/ui/travelView.js';
import * as inboxView from '../src/ui/inboxView.js';
import { state } from '../src/core/state.js';
const clone=v=>structuredClone(v);
const legacy=JSON.parse(fs.readFileSync(new URL('./helpers/r8418LegacyJournals.json',import.meta.url),'utf8'));
const sketch=(elements)=>{const p=location();p.keepsake.design=design(elements);return {locations:[p]};};
const openB=f=>library.openIndexedArchive(f.bEntry.characterKey,f.bEntry.chatId,f.bEntry.entryId);
function offline(){globalThis.fetch=async()=>{throw new TypeError('synthetic-source-offline');};}
function fence(f){f.records.set(f.bEntry.entryId,{...clone(f.bEntry),deleted:true,deletedAt:Date.now()});}
async function put(f,mode,s){await cache.commitSession(mode,s,f.liveBank.chatId,context.captureTaskOrigin(f.ctx,f.liveBank.archiveRevision));state.runtimeSessionCache.clear();await cache.ensureCacheHydrated(f.ctx);}

for(const layer of ['far','mid','near'])for(const size of ['s','m','l'])test(`boat-only sketch ${layer}/${size} renders deterministically without invented water`,()=>{
 const d=design([el('boat',layer,100,size,6)]),before=JSON.stringify(d);const norm=schema.normalizePostcardDesign(d);assert.ok(norm);
 const svg=draw.renderPostcardDesign(d);assert.ok(svg);assert.equal(svg,draw.renderPostcardDesign(clone(d)));assert.equal(JSON.stringify(d),before);
 assert.doesNotMatch(svg,/NaN|Infinity|data-pd-kind="(?:water|shore|pavilion)"/);assert.equal(schema.postcardDesignNodeCount(d),26);
});
test('simple and overlapping supported designs are accepted, unsupported/code/overbudget designs remain rejected',()=>{
 assert.ok(schema.normalizePostcardDesign(design([el('tree','far',20,'s')])));
 assert.ok(schema.normalizePostcardDesign(design([el('peak','mid',50,'l',3),el('peak','mid',50,'l',3)])));
 for(const bad of [design([el('person')]),design(Array.from({length:21},()=>el('leaf'))),design([el('water','mid',50,'m',6),el('water','mid',50,'m',6)]),{html:'<svg onload=alert(1)>'}])assert.equal(schema.normalizePostcardDesign(bad),null);
 assert.equal(schema.MAX_DESIGN_BYTES,8192);assert.equal(schema.MAX_DESIGN_NODES,90);
});
test('boat with only closer water is accepted as a sketch rather than a support error',()=>{
 const d=design([el('boat','far'),el('water','near')]);assert.ok(schema.normalizePostcardDesign(d));assert.ok(draw.renderPostcardDesign(d));
});
test('local visual instruction changes only the water gate; old recipe remains available verbatim',()=>{
 assert.match(schema.postcardDesignInstructions(),/允许只画boat/);
 assert.doesNotMatch(schema.postcardDesignInstructions(),/必须显式设计水面/);
 assert.match(schema.postcardDesignInstructions(true),/同层或更远处必须显式设计水面/);
});
for(const [label,elements] of [ ['tree',[el('tree','far',30,'s')]],['boat',[el('boat')]],['overlap',[el('peak','mid',50,'l',3)]] ])test(`${label}: real generation, canonical save, hydration, reader, inbox freeze and dedup`,async t=>{
 const f=await fixture(t),old=await f.persisted(),response=sketch(elements);f.setResponse(response);
 assert.ok(await client.generateMode('travel',{background:true}),JSON.stringify(f.notices));assert.equal(f.requests.length,1);
 let saved=await f.persisted();assert.deepEqual(saved.travel.locations[0].keepsake.design,response.locations[0].keepsake.design);
 assert.deepEqual(saved.phone,old.phone);assert.deepEqual(saved.cabinet,old.cabinet);
 state.runtimeSessionCache.clear();await cache.ensureCacheHydrated(f.ctx);await f.open('travel');travelView.selectTravelLocation('F1');
 assert.match(f.body.innerHTML,new RegExp(`data-pd-kind="${elements[0].kind}"`));assert.doesNotMatch(f.body.innerHTML,/data-rmt-design-state="fallback"/);
 await f.open('inbox');await inboxView.handleInboxAction('postcards');saved=await f.persisted();assert.equal(saved.inbox.letters.length,1);
 const frozen=clone(saved.inbox.letters[0]);assert.deepEqual(frozen.travelSnapshot.location.postcard.design,response.locations[0].keepsake.design);
 const changed=clone(saved.travel);changed.locations[0].keepsake.design=scenes.snow;changed.locations[0].postcard.design=scenes.snow;await put(f,'travel',changed);
 await f.open('inbox');await inboxView.handleInboxAction('postcards');saved=await f.persisted();assert.equal(saved.inbox.letters.length,1);assert.deepEqual(saved.inbox.letters[0],frozen);
 await inboxView.handleInboxAction('read',frozen.id);assert.match(f.body.innerHTML,new RegExp(`data-pd-kind="${elements[0].kind}"`));assert.equal(f.requests.length,1);
});
for(const [name,old] of Object.entries(legacy))test(`actual r84.17 ${name} journal retains original request and paid success`,async t=>{
 const f=await fixture(t),saved=clone(old.saved),j=saved.__generationRecoveryV1.travel;j.createdAt=j.updatedAt=Date.now();
 Object.assign(f.liveCache,clone(saved));f.ctx.chatMetadata[C.CACHE_KEY]=clone(saved);f.records.get(f.aEntry.entryId).cache=clone(saved);state.runtimeSessionCache.clear();await f.open('travel');
 f.setResponse(old.response);await client.continueSavedGeneration('travel');assert.ok((await f.persisted()).travel,JSON.stringify(f.notices));
 assert.equal(f.requests.length,name==='failed'?1:0);if(f.requests.length)assert.deepEqual(f.requests[0],old.requests[0]);
});
test('new sketch request retries only explicitly and replays saved response without another request',async t=>{
 const f=await fixture(t);f.setResponse(sketch([el('boat')]));f.failCompletedSave('travel',s=>s?.locations?.length);
 await client.generateMode('travel',{background:true});assert.equal(f.requests.length,1);assert.equal((await f.persisted()).travel,undefined);
 assert.equal(cache.loadGenerationRecovery('travel',f.ctx).segments[0].contract,'travel-sketch-design-r8418');
 f.failCompletedSave('');await client.continueSavedGeneration('travel');assert.equal(f.requests.length,1);assert.ok((await f.persisted()).travel.locations[0].keepsake.design);
});
test('old journal still rejects changed creative settings without extra paid request',async t=>{
 const f=await fixture(t),saved=clone(legacy.failed.saved);saved.__generationRecoveryV1.travel.createdAt=saved.__generationRecoveryV1.travel.updatedAt=Date.now();
 Object.assign(f.liveCache,clone(saved));f.ctx.chatMetadata[C.CACHE_KEY]=clone(saved);f.records.get(f.aEntry.entryId).cache=clone(saved);
 f.ctx.extensionSettings[C.EXTENSION_SETTINGS_KEY].creativeSupplementEnabled=true;f.ctx.extensionSettings[C.EXTENSION_SETTINGS_KEY].creativeSupplement='explicitly changed';
 state.runtimeSessionCache.clear();await f.open('travel');await client.continueSavedGeneration('travel');assert.equal(f.requests.length,0);assert.equal((await f.persisted()).travel,undefined);
});
for(const mode of ['network','http503','missing-archive'])test(`backup after ${mode} can re-read recovered source immediately, never flip old backup to writable`,async t=>{
 const f=await fixture(t),fetchSource=globalThis.fetch,original=JSON.stringify([...f.records]);
 globalThis.fetch=async()=>{if(mode==='network')throw new TypeError('offline');if(mode==='http503')return{ok:false,status:503};return{ok:true,json:async()=>[{chat_metadata:{}}]};};
 const backup=await library.fetchIndexedArchiveSnapshot(f.bEntry,f.ctx);assert.equal(backup.backupOnly,true);library.showIndexedArchiveSnapshot(backup);
 assert.match(f.body.innerHTML,/重试读取源聊天/);assert.doesNotMatch(f.body.innerHTML,/永久只读|已丢失/);
 library.setArchiveReadOnly(false);assert.equal(state.activeArchiveReadOnly,true);assert.equal(library.requireWritableArchiveAction(),false);
 globalThis.fetch=fetchSource;await openB(f);const fresh=state.activeArchiveSnapshot;assert.ok(fresh);assert.notEqual(fresh,backup);
 assert.equal(fresh.backupOnly,false);assert.equal(backup.backupOnly,true);assert.equal(state.activeArchiveReadOnly,true);
 assert.equal(JSON.stringify([...f.records]),original);assert.equal(f.requests.length,0);
});
test('ordinary healthy snapshot cache remains unchanged and does not reread on every page switch',async t=>{
 const f=await fixture(t);const a=await library.fetchIndexedArchiveSnapshot(f.bEntry,f.ctx);const b=await library.fetchIndexedArchiveSnapshot(f.bEntry,f.ctx);
 assert.equal(a,b);assert.equal(f.reads.length,1);library.showIndexedArchiveSnapshot(a);workspace.openWorkspaceTab('content');workspace.openWorkspaceTab('archive');assert.equal(f.reads.length,1);assert.equal(f.requests.length,0);
});
test('recovered source is fetched even when host now matches the old backup target',async t=>{
 const f=await fixture(t),fetchSource=globalThis.fetch;offline();const backup=await library.fetchIndexedArchiveSnapshot(f.bEntry,f.ctx);library.showIndexedArchiveSnapshot(backup);
 Object.assign(f.ctx,{characterId:1,chatId:f.otherBank.chatId,name1:f.otherBank.userName,name2:f.otherBank.characterName,chatMetadata:{[C.MEMORY_KEY]:clone(f.otherBank),[C.CACHE_KEY]:clone(f.otherCache)}});
 globalThis.fetch=fetchSource;await openB(f);assert.equal(state.activeArchiveSnapshot.backupOnly,false);assert.equal(state.activeArchiveReadOnly,true);assert.equal(backup.backupOnly,true);assert.equal(f.reads.length,1);
});
test('continued source failure remains backup-only; no delete, write, polling or model request',async t=>{
 const f=await fixture(t);offline();const old=JSON.stringify([...f.records]);await openB(f);const backup=state.activeArchiveSnapshot;assert.equal(backup.backupOnly,true);
 await openB(f);assert.equal(state.activeArchiveSnapshot.backupOnly,true);assert.equal(library.requireWritableArchiveAction(),false);assert.equal(JSON.stringify([...f.records]),old);assert.equal(f.requests.length,0);
});
test('explicit current-archive entry clears stale historical view without modifying its backup',async t=>{
 const f=await fixture(t);offline();const backup=await library.fetchIndexedArchiveSnapshot(f.bEntry,f.ctx);library.showIndexedArchiveSnapshot(backup);const before=JSON.stringify([...f.records]);
 overlay.showChooser();assert.equal(state.activeArchiveSnapshot,null);assert.equal(library.requireWritableArchiveAction(),true);assert.equal(backup.backupOnly,true);assert.equal(JSON.stringify([...f.records]),before);
});
test('recovered historical archive preserves explicit readonly choice and rejects editing a different live chat',async t=>{
 const f=await fixture(t);await openB(f);const source=state.activeArchiveSnapshot;library.setArchiveReadOnly(true);workspace.openWorkspaceTab('content');workspace.openWorkspaceTab('archive');
 assert.equal(state.activeArchiveReadOnly,true);assert.equal(library.requireWritableArchiveAction(),false);
 library.setArchiveReadOnly(false);assert.equal(library.requireWritableArchiveAction(),false);assert.equal(state.activeArchiveSnapshot,source);assert.equal(f.requests.length,0);
});
test('deleted backup fence wins before any source re-read',async t=>{
 const f=await fixture(t),fetchSource=globalThis.fetch;offline();await library.fetchIndexedArchiveSnapshot(f.bEntry,f.ctx);fence(f);globalThis.fetch=fetchSource;
 await assert.rejects(library.fetchIndexedArchiveSnapshot(f.bEntry,f.ctx),e=>e.code==='RMT_ARCHIVE_DELETED_FENCE');assert.equal(f.reads.length,0);assert.equal(f.records.get(f.bEntry.entryId).deleted,true);
});
test('deletion during source retry defeats the late result',async t=>{
 const f=await fixture(t),hold=f.pauseSourceRead();const p=library.fetchIndexedArchiveSnapshot(f.bEntry,f.ctx);await hold.ready;fence(f);hold.release();
 await assert.rejects(p,e=>e.code==='RMT_ARCHIVE_DELETED_FENCE');assert.equal(f.records.get(f.bEntry.entryId).deleted,true);assert.equal(f.requests.length,0);
});
test('source character conflict does not turn a backup into writable source',async t=>{
 const f=await fixture(t);globalThis.fetch=async()=>({ok:true,json:async()=>[{chat_metadata:{[C.MEMORY_KEY]:{...clone(f.otherBank),characterName:'different-card'}}}]});
 await assert.rejects(library.fetchIndexedArchiveSnapshot(f.bEntry,f.ctx),/不同角色身份/);assert.equal(state.archiveSnapshotCache.size,0);
});
for(const change of ['current-page','other-mode','settings','close','lifecycle','chat','character','persona'])test(`late historical open cannot steal ${change}`,async t=>{
 const f=await fixture(t),hold=f.pauseSourceRead();const p=openB(f);await hold.ready;
 if(change==='current-page')overlay.showChooser();
 if(change==='other-mode')await f.open('phone');
 if(change==='settings')workspace.openWorkspaceTab('settings');
 if(change==='close')f.host.hidden=true;
 if(change==='lifecycle')state.runtimeLifecycleEpoch++;
 if(change==='chat')f.ctx.chatId='another-live-chat';
 if(change==='character')f.ctx.characterId=1;
 if(change==='persona')f.ctx.name1='another-persona';
 const view={body:f.body.innerHTML,snapshot:state.activeArchiveSnapshot,mode:state.activeMode,readonly:state.activeArchiveReadOnly,notices:f.notices.length};hold.release();await p;
 assert.equal(f.body.innerHTML,view.body);assert.equal(state.activeArchiveSnapshot,view.snapshot);assert.equal(state.activeMode,view.mode);assert.equal(state.activeArchiveReadOnly,view.readonly);assert.equal(f.notices.length,view.notices);
});
test('late failure also cannot replace the current page with an error or reset readonly',async t=>{
 const f=await fixture(t);f.records.delete(f.bEntry.entryId);let entered,release;const ready=new Promise(r=>entered=r),wait=new Promise(r=>release=r);
 globalThis.fetch=async()=>{entered();await wait;throw new TypeError('synthetic-offline');};const p=openB(f);await ready;overlay.showChooser();const body=f.body.innerHTML;release();await p;assert.equal(f.body.innerHTML,body);assert.equal(state.activeArchiveSnapshot,null);
});
test('newer explicit open wins over older same-target read, and an explicit readonly action remains respected',async t=>{
 const f=await fixture(t),fetchSource=globalThis.fetch;let entered,release,calls=0;const ready=new Promise(r=>entered=r),wait=new Promise(r=>release=r);
 globalThis.fetch=async(...args)=>{calls++;if(calls===1){entered();await wait;}return fetchSource(...args);};
 const first=openB(f);await ready;await openB(f);const last=state.activeArchiveSnapshot;library.setArchiveReadOnly(true);release();await first;
 assert.equal(state.activeArchiveSnapshot,last);assert.equal(state.activeArchiveReadOnly,true);assert.equal(f.requests.length,0);
});
