import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './helpers/r847Host.mjs';
import { fixedOrigin } from './helpers/r8425LocalHost.mjs';
import * as C from '../src/core/constants.js';
import * as ctx from '../src/core/context.js';
import * as cache from '../src/core/cache.js';
import * as settings from '../src/core/settings.js';
import * as source from '../src/core/recoverySourcePolicy.js';
import * as G from '../src/generation/recovery.js';
import * as client from '../src/generation/client.js';
import * as trace from '../src/core/taskTrace.js';
import * as text from '../src/core/text.js';
import * as recoveryView from '../src/ui/recoveryView.js';
import { state } from '../src/core/state.js';

const operations = [
 ...Object.values(C.MODE).map(mode=>[mode,{kind:'mode',mode}]),
 ['adv',{kind:'adv-single',eventId:'E01'}], ['adv',{kind:'adv-bulk',eventIds:['E01','E02']}],
 ['adv',{kind:'adv-repair',eventIds:['E01']}], ['heart',{kind:'heart-section',part:'dialogues',languageCategory:'morning'}],
 ['heart',{kind:'heart-season',season:'spring',batchId:'spring:1'}], ['heart',{kind:'heart-fireflies',batchId:'fireflies:1'}],
 ['room',{kind:'room-daily-life',dateKey:'2026-09-19'}], ['album',{kind:'content-item',target:{type:'album-comment',id:'A01'}}],
];
const fail = () => {throw Object.assign(new Error('synthetic unavailable'),{code:'RMT_MANUAL_HTTP',status:400});};
const good = { value:'validated synthetic data' };
const validate = raw => {assert.equal(raw.value,good.value);return raw;};
function storedDraft(stored, mode, draftId = '') {
 const rows=Object.entries(stored[cache.GENERATION_DRAFTS_CACHE_KEY]?.records || {});
 const found=rows.find(([id,row])=>(!draftId || id===draftId) && row.journal?.identity?.mode===mode);
 return found?.[1].journal || stored[G.GENERATION_RECOVERY_CACHE_KEY]?.[mode];
}
function legacyOnly(stored, mode) {
 const copy=structuredClone(stored), journal=structuredClone(storedDraft(stored,mode));
 delete copy[cache.GENERATION_DRAFTS_CACHE_KEY];
 copy[G.GENERATION_RECOVERY_CACHE_KEY]={[mode]:journal};
 return copy;
}
for (const [mode,operation] of operations) test(`common real request/cache recovery: ${mode}/${operation.kind}, legacy optional target, replay only missing segment`,async t=>{
 const f=await fixture(t), bank=f.liveBank, origin=ctx.captureTaskOrigin(f.ctx,bank.archiveRevision);
 const before=await f.persisted();
 const handle=await client.beginModeRecovery(mode,f.ctx,bank,origin,{operation});
 const options=slot=>({context:f.ctx,origin,taskKey:`matrix:${ctx.chatScopeKey(f.ctx)}:${slot}`,mode,maxTokens:12000,temperature:.6});
 f.setResponse(good);await client.requestValidatedSegment('SYNTHETIC SEGMENT A','fixture',options('a'),validate);
 f.setResponse(fail);await assert.rejects(client.requestValidatedSegment('SYNTHETIC SEGMENT B','fixture',options('b'),validate));
 const original=cache.loadGenerationRecovery(mode,f.ctx);assert.equal(original.segments.filter(s=>s.state==='complete').length,1);
 // Schema-valid legacy omission; this is explicitly a migration probe, not an
 // assertion that every old version necessarily produced an empty target.
 original.identity.archiveTargetEntryId='';delete original.inputSnapshotVersion;
 assert.equal(await cache.saveGenerationRecovery(f.ctx,bank,mode,original,origin),true);
 G.detachGenerationRecovery(origin);state.runtimeSessionCache.clear();await cache.ensureCacheHydrated(f.ctx);
 const disk=await f.persisted();assert.equal(storedDraft(disk,mode,original.draftId).identity.archiveTargetEntryId,'');
 const loaded=cache.loadGenerationRecovery(mode,f.ctx);assert.equal(loaded.identity.archiveTargetEntryId,f.aEntry.entryId);
 assert.equal(storedDraft(disk,mode,original.draftId).identity.archiveTargetEntryId,'','read is copy-on-write, not a mutation');
 const next=ctx.captureTaskOrigin(f.ctx,bank.archiveRevision);
 await client.beginModeRecovery(mode,f.ctx,bank,next,{operation,existing:loaded});
 const count=f.requests.length;f.setResponse(good);
 for(const slot of ['a','b']) await client.requestValidatedSegment('SYNTHETIC SEGMENT '+slot.toUpperCase(),'fixture',{...options(slot),origin:next},validate);
 assert.equal(f.requests.length,count+1,'only incomplete B is sent');
 const saved=cache.loadGenerationRecovery(mode,f.ctx);assert.equal(saved.segments.filter(s=>s.state==='complete').length,2);
 assert.equal(saved.segments[0].rawJson,original.segments[0].rawJson);assert.equal(saved.segments[0].requestHash,original.segments[0].requestHash);
 assert.deepEqual((await f.persisted()).phone,before.phone);assert.deepEqual(f.ctx.chatMetadata[C.MEMORY_KEY],bank);
 G.detachGenerationRecovery(next);
});

async function simple(t, {stateName='retry',poisoned=false}={}) {
 const origin=fixedOrigin(),mode='inbox';let stored=null,calls=0;
 const options={origin,mode,taskKey:'legacy:slot',maxTokens:4000,contextEnvelope:'old context'};
 let h=await G.createGenerationRecovery({origin,mode,settingsIdentity:'same',save:j=>{stored=structuredClone(j);return true;}});G.attachGenerationRecovery(origin,h);
 const run=async(_p,_o,accepted)=>{calls++;if(stateName==='complete'){await accepted(good);return good;}if(stateName==='truncated') {const e={code:'RMT_JSON_TRUNCATED'};await G.recordRecoveryTruncation(_o,'{"value":"unfinished',e);throw e;}throw {code:'RMT_JSON_INVALID'};};
 if(stateName==='complete')await G.withRecoverySegment('original prompt',options,validate,run);else await assert.rejects(G.withRecoverySegment('original prompt',options,validate,run));
 G.detachGenerationRecovery(origin);delete stored.inputSnapshotVersion;
 if(poisoned){stored.frozenInputs={'context:inbox':JSON.stringify('later wrong context')};stored.failureCode='RMT_RECOVERY_INPUT_CHANGED';}
 t.after(()=>G.detachGenerationRecovery(origin));
 return {origin,mode,options,getStored:()=>structuredClone(stored),save:j=>{stored=structuredClone(j);return true;},call:()=>{calls++;},calls:()=>calls};
}
for(const stateName of ['retry','truncated','complete'])test(`unmatched legacy ${stateName}: new background is not written before proof or on failure`,async t=>{
 const f=await simple(t,{stateName}),old=f.getStored();let confirm=0;
 const h=await G.createGenerationRecovery({origin:f.origin,mode:f.mode,settingsIdentity:'same',existing:old,continueRequested:true,
 sourcePolicy:{character:'a'.repeat(64),persona:'b'.repeat(64),selection:'c'.repeat(64)},confirmLegacyRestart:()=>{confirm++;return false;},save:f.save});
 G.attachGenerationRecovery(f.origin,h);
 const produced=await G.frozenGenerationInput(f.origin,'context:inbox',async()=>({background:'different',order:{z:1,a:2}}));
 assert.deepEqual(produced,{background:'different',order:{z:1,a:2}});assert.deepEqual(f.getStored(),old,'staging must not save');
 let error;try {await G.withRecoverySegment('changed prompt',f.options,validate,async()=>{f.call();return good;});}catch(e){error=e;}
 assert.equal(error.code,'RMT_RECOVERY_INPUT_CHANGED');assert.equal(error.archiveInputCategory,'request');assert.equal(f.calls(),1);
 await G.noteGenerationRecoveryFailure(f.origin,error);
 const saved=f.getStored();assert.equal(saved.frozenInputs,undefined);assert.equal(saved.sourcePolicy,undefined);
 assert.deepEqual(saved.segments,old.segments);assert.equal(confirm,stateName==='retry'?1:0);
});
for(const poisoned of [false,true]) test(`zero-success legacy restart is explicit, retained, and works on a later click; poisoned=${poisoned}`,async t=>{
 const f=await simple(t,{poisoned});const old=f.getStored();let confirms=0;
 for(const approved of [false,true]){
  const h=await G.createGenerationRecovery({origin:f.origin,mode:f.mode,settingsIdentity:'same',existing:f.getStored(),continueRequested:true,save:f.save,
   confirmLegacyRestart:()=>{confirms++;return approved;}});G.attachGenerationRecovery(f.origin,h);
  await G.frozenGenerationInput(f.origin,'context:inbox',async()=>'new background');
  const action=()=>G.withRecoverySegment('new prompt',f.options,validate,async(_p,_o,accepted)=>{f.call();await accepted(good);return good;});
  if(!approved){let error;try{await action();}catch(e){error=e;}assert.equal(error.code,'RMT_RECOVERY_INPUT_CHANGED');await G.noteGenerationRecoveryFailure(f.origin,error);assert.equal(f.calls(),1);}
  else {await action();assert.equal(f.calls(),2);assert.equal(f.getStored().segments[0].state,'complete');assert.deepEqual(f.getStored().previousAttempts[0].segments,old.segments);assert.equal(f.getStored().inputSnapshotVersion,1);}
  G.detachGenerationRecovery(f.origin);
 }
 assert.equal(confirms,2);
});
test('matching legacy recipe commits the original ordered snapshot then replays without a request',async t=>{
 const f=await simple(t,{stateName:'complete'}),old=f.getStored();const h=await G.createGenerationRecovery({origin:f.origin,mode:f.mode,settingsIdentity:'same',existing:old,continueRequested:true,save:f.save});G.attachGenerationRecovery(f.origin,h);
 await G.frozenGenerationInput(f.origin,'context:inbox',async()=>({z:1,a:2}));
 await G.withRecoverySegment('original prompt',f.options,validate,async()=>{throw new Error('must replay');});
 assert.equal(f.calls(),1);assert.equal(f.getStored().frozenInputs['context:inbox'],'{"z":1,"a":2}');assert.deepEqual(f.getStored().segments,old.segments);
});
test('new snapshot storage failure before sending preserves retry data and sends nothing',async t=>{
 const f=await simple(t);const old=f.getStored();const h=await G.createGenerationRecovery({origin:f.origin,mode:f.mode,settingsIdentity:'same',existing:old,continueRequested:true,save:()=>false});G.attachGenerationRecovery(f.origin,h);
 await G.frozenGenerationInput(f.origin,'context:inbox',async()=>'same');
 await assert.rejects(G.withRecoverySegment('original prompt',f.options,validate,async()=>{f.call();}),{code:'RMT_RECOVERY_STORAGE'});
 assert.equal(f.calls(),1);assert.deepEqual(f.getStored(),old);
});
for(const [field,value,category] of [['chatId','elsewhere','chat'],['characterId','2','character'],['characterAvatar','else.png','character'],['archiveRevision','new','archive'],['archiveTargetEntryId','wrong','target'],['mode','phone','operation']])test(`required mismatch is not aliased: ${field}`,async t=>{
 const f=await simple(t);const raw=f.getStored();raw.identity[field]=value;
 await assert.rejects(G.createGenerationRecovery({origin:f.origin,mode:f.mode,settingsIdentity:'same',existing:raw,continueRequested:true}),e=>e.code==='RMT_RECOVERY_INPUT_CHANGED'&&e.archiveInputCategory===category);
});
// r84.33: characterKey embeds a card-content fingerprint. Same slot + same avatar +
// same chat with only fingerprint drift is the same person (authorized contract
// change, mirroring the archive grouping and deferred-commit lanes); the original
// identity binding stays on the journal. A real switch (avatar/slot) still throws.
test('required mismatch is not aliased: characterKey',async t=>{
 const f=await simple(t);const drifted=f.getStored();drifted.identity.characterKey='someone-else';
 const h=await G.createGenerationRecovery({origin:f.origin,mode:f.mode,settingsIdentity:'same',existing:drifted,continueRequested:true,save:f.save});
 assert.equal(h.journal.identity.characterKey,'someone-else','original binding stays as evidence');
 const switched=f.getStored();switched.identity.characterKey='someone-else';switched.identity.characterAvatar='else.png';
 await assert.rejects(G.createGenerationRecovery({origin:f.origin,mode:f.mode,settingsIdentity:'same',existing:switched,continueRequested:true}),e=>e.code==='RMT_RECOVERY_INPUT_CHANGED'&&e.archiveInputCategory==='character');
});
test('malformed records and settings mismatch report distinct classifications without payloads',async t=>{
 const f=await simple(t);let e;
 for(const [raw,id,category] of [[{...f.getStored(),version:999},'same','record'],[f.getStored(),'different','configuration']]){
  try{await G.createGenerationRecovery({origin:f.origin,mode:f.mode,settingsIdentity:id,existing:raw,continueRequested:true});}catch(error){e=error;}
  assert.equal(e.archiveInputCategory,category);assert.doesNotMatch(text.safeErrorSummary(e),/different|original prompt/);
 }
});
for(const category of ['configuration','persona','selection','character'])test(`admission retains frozen content for ${category} changes and protects character ownership`,async t=>{
 const f=await fixture(t),origin=ctx.captureTaskOrigin(f.ctx,f.liveBank.archiveRevision);await client.beginModeRecovery('inbox',f.ctx,f.liveBank,origin,{operation:{kind:'mode',mode:'inbox'}});
 f.setResponse(fail);await assert.rejects(client.requestValidatedSegment('synthetic','fixture',{context:f.ctx,origin,taskKey:'p',mode:'inbox'},validate));G.detachGenerationRecovery(origin);
 const before=await f.persisted();
 if(category==='configuration')settings.updatePluginSettings({creativeSupplementEnabled:true,creativeSupplement:'changed synthetic rule'});
 if(category==='persona')f.ctx.powerUserSettings.persona_description+='different';
 if(category==='selection')settings.updatePluginSettings({contextTagMode:'keep',retainedContextTags:['story']});
 if(category==='character')f.ctx.characters[0].data.personality+='changed';
 if(category==='character') {
  await assert.rejects(cache.claimLiveModeGeneration('inbox',f.ctx,f.liveBank),e=>['RMT_RECOVERY_INPUT_CHANGED','RMT_RECOVERY_SOURCE_CHANGED'].includes(e.code));
  assert.deepEqual(await f.persisted(),before);
 } else {
  await cache.claimLiveModeGeneration('inbox',f.ctx,f.liveBank);
  const journal=cache.loadGenerationRecovery('inbox',f.ctx);
  assert.deepEqual(journal.contentSnapshot,storedDraft(before,'inbox',journal.draftId).contentSnapshot);
  assert.deepEqual(journal.segments,storedDraft(before,'inbox',journal.draftId).segments);
  assert.equal(journal.settingsHash,storedDraft(before,'inbox',journal.draftId).settingsHash);
 }
 assert.equal(f.requests.length,1);
});
test('diagnostic exports contain only fixed recovery category and phase, never hashes or payload',()=>{
 trace.clearTaskTrace();const parent=trace.startTaskTrace('sensitive chat','inbox');const child=trace.startTaskTrace('sensitive prompt','inbox',parent);
 const error=G.generationRecoveryMismatch('request','request');error.message='sensitive message';error.secret='synthetic';trace.endTaskTrace(child,'failed',error);trace.endTaskTrace(parent,'failed',error);
 const result=trace.taskTraceSnapshot();assert.equal(result.at(-1).recovery.category,'request');assert.equal(result.at(-1).recovery.phase,'request');assert.doesNotMatch(JSON.stringify(result),/sensitive|synthetic|secret/);
 const fake=trace.startTaskTrace('','heart');trace.endTaskTrace(fake,'failed',{code:'RMT_RECOVERY_INPUT_CHANGED',archiveInputCategory:'raw leak',recoveryPhase:'raw leak'});
 assert.deepEqual(trace.taskTraceSnapshot().at(-1).recovery,{phase:'initialization',category:'unknown'});trace.clearTaskTrace();
});
test('export is explicit, has successful raw data, omits unknown top-level properties and does not mutate the journal',async t=>{
 const f=await simple(t,{stateName:'complete'}),raw=f.getStored();raw.untrustedSecret='must-not-export';const before=structuredClone(raw),result=G.exportGenerationRecovery(raw);
 assert.equal(result.journal.segments[0].rawJson,raw.segments[0].rawJson);assert.doesNotMatch(JSON.stringify(result),/must-not-export/);assert.deepEqual(raw,before);
});
test('actual common banner includes explicit recovery export, not an automatic restart',async t=>{
 const f=await fixture(t),origin=ctx.captureTaskOrigin(f.ctx,f.liveBank.archiveRevision);await client.beginModeRecovery('inbox',f.ctx,f.liveBank,origin,{operation:{kind:'mode',mode:'inbox'}});f.setResponse(fail);
 await assert.rejects(client.requestValidatedSegment('synthetic','fixture',{context:f.ctx,origin,taskKey:'p',mode:'inbox'},validate));
 const html=recoveryView.recoveryBannerHtml(await f.persisted(),f.liveBank);assert.match(html,/data-rmt-recovery-export="inbox"/);assert.match(html,/data-rmt-recovery-mode="inbox"/);
 const exportValue=await client.exportSavedGeneration('inbox');assert.equal(exportValue.journal.identity.archiveTargetEntryId,f.aEntry.entryId);assert.equal(f.requests.length,1);G.detachGenerationRecovery(origin);
});
for (const [field, value] of [['archiveTargetEntryId','different-entry'],['characterKey','different-character'],['chatId','different-chat'],['archiveRevision','different-revision']]) test(`canonical loader never turns explicit ${field} mismatch into the current identity`,async t=>{
 const f=await fixture(t),origin=ctx.captureTaskOrigin(f.ctx,f.liveBank.archiveRevision);
 await client.beginModeRecovery('inbox',f.ctx,f.liveBank,origin,{operation:{kind:'mode',mode:'inbox'}});f.setResponse(fail);
 await assert.rejects(client.requestValidatedSegment('synthetic','fixture',{context:f.ctx,origin,taskKey:'guard',mode:'inbox'},validate));
 const stored=await f.persisted();const supplied=legacyOnly(stored,'inbox');supplied[G.GENERATION_RECOVERY_CACHE_KEY].inbox.identity[field]=value;
 const before=structuredClone(supplied);assert.equal(cache.loadGenerationRecovery('inbox',f.ctx,supplied),null);assert.deepEqual(supplied,before);assert.deepEqual(await f.persisted(),stored);G.detachGenerationRecovery(origin);
});
test('mismatched mode fence still prevents legacy optional-field revival',async t=>{
 const f=await fixture(t),origin=ctx.captureTaskOrigin(f.ctx,f.liveBank.archiveRevision);
 await client.beginModeRecovery('inbox',f.ctx,f.liveBank,origin,{operation:{kind:'mode',mode:'inbox'}});f.setResponse(fail);
 await assert.rejects(client.requestValidatedSegment('synthetic','fixture',{context:f.ctx,origin,taskKey:'fence',mode:'inbox'},validate));
 const stored=await f.persisted();const stale=legacyOnly(stored,'inbox');stale[G.GENERATION_RECOVERY_CACHE_KEY].inbox.identity.archiveTargetEntryId='';
 stale[G.GENERATION_RECOVERY_CACHE_KEY].inbox[C.SESSION_MODE_WRITE_FENCE_KEY]='stale';
 assert.equal(cache.loadGenerationRecovery('inbox',f.ctx,stale),null);assert.deepEqual(await f.persisted(),stored);G.detachGenerationRecovery(origin);
});
