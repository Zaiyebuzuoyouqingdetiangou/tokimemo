import test from 'node:test';
import assert from 'node:assert/strict';
import { createHostContextAdapter, readArchiveRowMetadata } from '../src/core/hostCompatibility.js';
import { assertConnectionManagerProfileSupport } from '../src/core/independentApi.js';
import { fixture } from './helpers/r847Host.mjs';
import * as library from '../src/archive/library.js';
import * as groups from '../src/archive/groups.js';
import * as constants from '../src/core/constants.js';
import * as repository from '../src/archive/repository.js';

const chat = id => ({ characterId: 0, groupId: null, chatId: id, chatMetadata: { original: id } });
function pending() { let resolve, reject; const promise = new Promise((a,b) => { resolve=a; reject=b; }); return {promise,resolve,reject}; }

test('new host methods and context references remain unchanged without imports', async () => {
    const names = () => ['book'], save = () => 'native';
    const context = { ...chat('A'), getWorldInfoNames: names, saveMetadataDebounced: save };
    const adapt = createHostContextAdapter({ loadWorldInfo: () => assert.fail('unexpected import'), loadExtensions: () => assert.fail('unexpected import') });
    assert.equal(adapt(context), context);
    assert.equal(context.getWorldInfoNames, names);
    assert.equal(context.saveMetadataDebounced, save);
    assert.equal(context.saveMetadataDebounced(), 'native');
});

test('legacy world list reads live exported names and returns independent arrays', async () => {
    let imports = 0;
    const module = {world_names: ['甲', '乙']};
    const adapt = createHostContextAdapter({loadWorldInfo: async () => { imports++; return module; }});
    const context = adapt(chat('A'));
    const first = await context.getWorldInfoNames();
    first.pop();
    assert.deepEqual(module.world_names, ['甲','乙']);
    module.world_names = ['新书'];
    assert.deepEqual(await context.getWorldInfoNames(), ['新书']);
    assert.equal(imports, 1);
});

test('world list failure is visible and a later explicit read can recover without retrying itself', async () => {
    let imports = 0;
    const adapt = createHostContextAdapter({loadWorldInfo: async () => { if (++imports === 1) throw new Error('offline'); return {world_names: []}; }});
    const context = adapt(chat('A'));
    await assert.rejects(context.getWorldInfoNames(), /offline/);
    assert.equal(imports, 1);
    assert.deepEqual(await context.getWorldInfoNames(), []);
    assert.equal(imports, 2);
});

test('explicit legacy worldbook reads do not acquire a new dependency on the adapted listing', async () => {
    let imports=0, reads=0;
    const adapt=createHostContextAdapter({loadWorldInfo:async()=>{imports++;throw new Error('listing unavailable');}});
    const context=adapt({...chat('A'),loadWorldInfo:async name=>{
        assert.equal(name,'已选择的历史');reads++;return {entries:{1:{uid:1,content:'原先可直接读取的历史正文'}}};
    }});
    for(const options of [{},{participantSource:true}]){
        const entries=await repository.loadMemoryWorldInfoBook(context,'已选择的历史',null,options);
        assert.equal(entries[0].content,'原先可直接读取的历史正文');
    }
    assert.equal(reads,2);assert.equal(imports,0);
    await assert.rejects(context.getWorldInfoNames(),/listing unavailable/,'interactive listing must retain its visible failure');
    assert.equal(imports,1);
});

test('native listing validation and failures remain unchanged for explicit worldbook reads', async () => {
    let reads=0;
    const adapt=createHostContextAdapter({loadWorldInfo:()=>assert.fail('must use native listing')});
    const context=adapt({...chat('A'),getWorldInfoNames:()=>['存在的书'],loadWorldInfo:async()=>{
        reads++;return {entries:{1:{uid:1,content:'原生正文'}}};
    }});
    assert.equal((await repository.loadMemoryWorldInfoBook(context,'存在的书'))[0].content,'原生正文');
    await assert.rejects(repository.loadMemoryWorldInfoBook(context,'不存在的书'),/已经不存在/);
    context.getWorldInfoNames=()=>{throw new Error('native list unavailable');};
    await assert.rejects(repository.loadMemoryWorldInfoBook(context,'存在的书'),/native list unavailable/);
    assert.equal(reads,1);
});

test('replacing an adapted listing with a native method restores native name validation', async () => {
    const context=createHostContextAdapter()({...chat('A'),loadWorldInfo:()=>assert.fail('excluded native name must not load')});
    context.getWorldInfoNames=()=>[];
    await assert.rejects(repository.loadMemoryWorldInfoBook(context,'已移除的书'),/已经不存在/);
});

test('legacy metadata uses the native queue synchronously after module load', async () => {
    let live = chat('A'), queued = 0, imports = 0;
    const adapt = createHostContextAdapter({getContext: () => live, loadExtensions: async () => { imports++; return {saveMetadataDebounced() { queued++; }}; }});
    assert.equal(await adapt(live).saveMetadataDebounced(), true);
    assert.equal(queued, 1);
    assert.equal(live.saveMetadataDebounced(), true);
    assert.equal(queued, 2);
    assert.equal(imports, 1);
});

for (const change of ['chat','metadata','character','group','epoch']) test(`pending legacy save cannot requeue after ${change} changes`, async () => {
    let live = chat('A'), epoch = 0, queued = 0;
    const deferred = pending();
    const adapt = createHostContextAdapter({getContext: () => live, getEpoch: () => epoch, loadExtensions: () => deferred.promise});
    const result = adapt(live).saveMetadataDebounced();
    if (change === 'chat') live = { ...live, chatId: 'B' };
    if (change === 'metadata') live = { ...live, chatMetadata: {} };
    if (change === 'character') live = { ...live, characterId: 1 };
    if (change === 'group') live = { ...live, groupId: 'G' };
    if (change === 'epoch') epoch++;
    deferred.resolve({saveMetadataDebounced() {queued++;}});
    assert.equal(await result, false);
    assert.equal(queued, 0);
});

test('failed save import is reported once and never falls back to whole-chat save', async () => {
    let reports = 0, loads = 0;
    const live = {...chat('A'), saveMetadata() { assert.fail('whole chat save'); }};
    const adapt = createHostContextAdapter({getContext: () => live, onSaveError: () => reports++, loadExtensions: async () => {loads++; throw new Error('offline');}});
    assert.equal(await adapt(live).saveMetadataDebounced(), false);
    assert.equal(reports,1); assert.equal(loads,1);
});

test('native archive metadata does not fetch a chat file', async () => {
    const row = {file_name:'A.jsonl',chat_metadata:{archive:'kept'}};
    assert.equal(await readArchiveRowMetadata({},'avatar.png',row,{fetchImpl: () => assert.fail('native unnecessary read')}), row);
});

test('legacy archive reads exactly the selected chat without switching or writing it', async () => {
    const calls = [], row = {file_name:'旧聊天.jsonl'}, metadata = {archive:{text:'保留正文'}};
    const result = await readArchiveRowMetadata({getRequestHeaders:()=>({'X-CSRF-Token':'test'})},'角色.png',row,{
        fetchImpl: async (url, init) => {calls.push({url,init}); return {ok:true,json:async()=>[{chat_metadata:metadata},{mes:'正文'}]};},
    });
    assert.equal(calls.length,1); assert.equal(calls[0].url,'/api/chats/get');
    assert.deepEqual(JSON.parse(calls[0].init.body),{avatar_url:'角色.png',file_name:'旧聊天'});
    assert.deepEqual(result,{...row,chat_metadata:metadata});
    assert.deepEqual(row,{file_name:'旧聊天.jsonl'});
});

test('cancelled legacy scan neither starts another read nor accepts a late response', async () => {
    const controller = new AbortController(); controller.abort();
    await assert.rejects(readArchiveRowMetadata({},'a',{file_name:'A'},{signal:controller.signal,fetchImpl:()=>assert.fail('cancelled fetch')}),{name:'AbortError'});
    let current = true;
    await assert.rejects(readArchiveRowMetadata({getRequestHeaders:()=>({})},'a',{file_name:'A'},{
        isCurrent:()=>current,fetchImpl:async()=>{current=false;return {ok:true,json:async()=>assert.fail('late parse')};},
    }),{name:'AbortError'});
});

test('legacy profile rejection remains explicit and sends no request', () => {
    const service = {validateProfile(){return {selected:'openai'};},sendRequest(){assert.fail('must not generate');}};
    assert.throws(()=>assertConnectionManagerProfileSupport(service),error=>error.code==='RMT_PROFILE_CAPABILITY' && /手动独立 API/.test(error.message));
});

for (const mode of ['native','legacy','partial-failure']) test(`real manual archive scan: ${mode} keeps existing index and reads source without writing chats`, async t => {
    const f = await fixture(t);
    // B exists only in its source chat; the scan must discover it rather than merely keep a fixture index.
    f.ctx.extensionSettings[constants.ARCHIVE_INDEX_SETTINGS_KEY] = [f.aEntry];
    const originalChat = JSON.stringify(f.ctx.chat);
    const reads = [];
    globalThis.fetch = async (url, init) => {
        const body = JSON.parse(init.body);
        reads.push({url,body});
        const bank = body.avatar_url === 'time-a.png' ? f.liveBank : f.otherBank;
        const metadata = {[constants.MEMORY_KEY]:bank};
        if (url === '/api/characters/chats') return {ok:true,json:async()=>[
            ...(mode === 'partial-failure' ? [{file_name:'broken.jsonl'}] : []),
            {file_name:bank.chatId+'.jsonl',...(mode === 'native' ? {chat_metadata:metadata} : {})},
        ]};
        assert.equal(url,'/api/chats/get','scan must not call host write/switch/generate endpoints');
        if (body.file_name === 'broken') return {ok:false,status:503};
        assert.equal(body.file_name,bank.chatId);
        return {ok:true,json:async()=>[{chat_metadata:metadata},{mes:'untouched original source'}]};
    };
    await library.rebuildArchiveIndexFromExisting();
    await new Promise(resolve=>setTimeout(resolve,0));
    const index=groups.getArchiveIndex(f.ctx);
    assert(index.some(item=>item.chatId===f.aEntry.chatId));
    assert(index.some(item=>item.chatId===f.bEntry.chatId),'legacy metadata must actually create the missing B index');
    assert.equal(reads.filter(row=>row.url==='/api/chats/get').length,mode==='native'?0:mode==='legacy'?2:4);
    assert.equal(JSON.stringify(f.ctx.chat),originalChat);
    assert.equal(f.requests.length,0);
    if(mode==='partial-failure') assert(f.notices.some(row=>row.kind==='warning'&&row.message.includes('部分完成')));
});

test('manual scan stop button cancels further reads and preserves existing entries', async t => {
    const f=await fixture(t);
    const before=groups.getArchiveIndex(f.ctx).map(row=>row.chatId).sort();
    let cancel, removed=false, fileReads=0, lists=0;
    f.body.addEventListener=(name,fn)=>{if(name==='click')cancel=fn;};
    f.body.removeEventListener=(name,fn)=>{if(name==='click'&&fn===cancel)removed=true;};
    globalThis.fetch=async(url,init)=>{
        if(url==='/api/characters/chats'){lists++;return {ok:true,json:async()=>[{file_name:'one.jsonl'},{file_name:'two.jsonl'}]};}
        assert.equal(url,'/api/chats/get');fileReads++;
        cancel({target:{closest:selector=>selector==='[data-rmt-cancel-legacy-scan]'?{}:null}});
        assert.equal(init.signal.aborted,true);
        return {ok:true,json:async()=>assert.fail('cancelled response must not be parsed')};
    };
    await library.rebuildArchiveIndexFromExisting();
    await new Promise(resolve=>setTimeout(resolve,0));
    assert.equal(lists,1);assert.equal(fileReads,1);assert.equal(removed,true);
    assert.deepEqual(groups.getArchiveIndex(f.ctx).map(row=>row.chatId).sort(),before);
    assert(f.notices.some(row=>row.message.includes('已停止')));
});
