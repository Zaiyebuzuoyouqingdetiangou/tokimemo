import test from 'node:test';
import assert from 'node:assert/strict';
import * as appearance from '../src/generation/cgAppearance.js';
import * as looks from '../src/core/castLooks.js';
import * as participants from '../src/core/participants.js';
import * as context from '../src/core/context.js';
import { fixture } from './helpers/r847Host.mjs';

const cast = { version: 1, people: [
    { id: 'a', name: '同名', sourceRefs: [{ world: '人物', uid: '8', title: '甲', content: '外貌：棕色短发，小麦色皮肤。' }] },
    { id: 'b', name: '同名', sourceRefs: [{ world: '人物', uid: '9', title: '乙', content: '外貌：银色长发，蓝眼睛。' }] },
    { id: 'c', name: '未知', sourceRefs: [] },
] };
const natural = '棕色短发，小麦色皮肤。';
const response = characters => ({ imagePrompt: '雨棚下的几人。', sceneTags: 'rain, canopy', flatPrompt: '雨棚下的几人。', characters });

test('multiplayer natural-only appearance survives normalization and scene edits without inventing English tags', async t => {
    const f = await fixture(t);
    const evidence = appearance.captureCgAppearanceEvidence(f.ctx, { castSnapshot: cast });
    const prepared = appearance.normalizeCgPreparedPrompt(response([{ participantId: 'a', tag: '', nl: natural }]), evidence);
    assert.deepEqual(prepared.characters, [{ participantId: 'a', name: '同名', tag: '', nl: natural }]);
    assert.deepEqual(prepared.missingParticipantIds, ['b', 'c']);
    assert.deepEqual(appearance.metadataAfterSceneEdit(prepared).characters, prepared.characters);
    assert.match(appearance.cgPreparedVisualPrompt('雨棚', prepared), /棕色短发/);
    assert.equal(f.requests.length, 0);
});

test('missing model appearance is distinguishable from missing source without discarding successful scene', async t => {
    const f = await fixture(t);
    const prepared = appearance.normalizeCgPreparedPrompt(response([]), appearance.captureCgAppearanceEvidence(f.ctx, { castSnapshot: cast }));
    assert.deepEqual(prepared.appearanceStatus.map(row => [row.participantId, row.sourceAvailable, row.hasAppearance]),
        [['a', true, false], ['b', true, false], ['c', false, false]]);
    assert.equal(prepared.imagePrompt, '雨棚下的几人。');
    assert.equal(f.requests.length, 0);
});

test('natural-only multiplayer appearance is durable by ID and keeps legacy tag-only records unchanged', async t => {
    const f = await fixture(t);
    const old = { version: 1, chatId: '', identity: '', updatedAt: 0, characters: [{ participantId: 'old', tag: 'black hair' }] };
    assert.deepEqual(looks.normalizeParticipantLooks(old), old);
    const saved = looks.saveConfirmedParticipantLooks([{ participantId: 'a', tag: '', nl: natural }, { participantId: 'b', tag: 'silver hair' }], {
        origin: context.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision), expectedSignature: looks.participantLooksSignature(null),
    });
    delete f.ctx.chatMetadata[looks.PARTICIPANT_LOOKS_KEY];
    const read = looks.readParticipantLooks(f.ctx);
    assert.equal(read.characters.find(row => row.participantId === 'a').nl, natural);
    assert.equal(read.characters.find(row => row.participantId === 'b').tag, 'silver hair');
    assert.deepEqual(read, saved);
    assert.equal(f.requests.length, 0);
});

test('natural-mode provider parameters retain natural-only people and independent identities', () => {
    const metadata = { promptFormat: 'nai5-natural', castSnapshot: cast, characters: [
        { participantId: 'a', tag: '', nl: natural }, { participantId: 'b', tag: 'silver hair', nl: '银色长发。' },
    ] };
    for (const backend of ['nai', 'comfyui']) {
        const result = appearance.formattedCgProviderPrompts('雨棚下的两人。', metadata, true, backend);
        assert.equal(result.characters.length, 2);
        assert.equal(result.characters[0].nl, natural);
        assert.equal(result.characters[1].tag, 'silver hair');
    }
    const flat = appearance.formattedCgProviderPrompts('雨棚下的两人。', metadata, false, 'comfyui');
    assert.match(flat.prompt, /棕色短发/);
    assert.match(flat.prompt, /silver hair/);
    const authored = appearance.formattedCgProviderPrompts('雨棚', { ...metadata, flatPrompt: 'KEEP_CUSTOM_SCENE' }, false, 'comfyui');
    assert.match(authored.prompt, /KEEP_CUSTOM_SCENE/);
    assert.match(authored.prompt, /棕色短发/);
});


test('user identity survives participant and CG round trips while old participant shapes remain unchanged', () => {
    const old = structuredClone(cast);
    assert.deepEqual(participants.normalizeParticipantSnapshot(old), old);
    const user = {id: 'user-1', name: '用户', identity: 'user', sourceRefs: []};
    const marked = {version: 1, people: [user]};
    assert.deepEqual(participants.normalizeParticipantSnapshot(marked), marked);
    const metadata = {castSnapshot: marked, characters: [{participantId: user.id, tag: 'silver hair', nl: ''}]};
    const normalized = appearance.normalizeCgPromptMetadata(metadata);
    assert.equal(normalized.castSnapshot.people[0].identity, 'user');
    assert.equal(appearance.metadataAfterSceneEdit(normalized).castSnapshot.people[0].identity, 'user');
    assert.equal(Object.hasOwn(participants.normalizeParticipantSnapshot(old).people[0], 'identity'), false);
});
