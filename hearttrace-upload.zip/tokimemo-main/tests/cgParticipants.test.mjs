import test from 'node:test';
import assert from 'node:assert/strict';
import * as appearance from '../src/generation/cgAppearance.js';
import * as images from '../src/generation/imageGeneration.js';
import * as patch from '../src/core/cgImagePatch.js';
import * as looks from '../src/core/castLooks.js';
import * as contextApi from '../src/core/context.js';
import * as cache from '../src/core/cache.js';
import * as constants from '../src/core/constants.js';
import * as editorUi from '../src/ui/cgPromptEditor.js';
import * as generation from '../src/generation/client.js';
import * as recovery from '../src/generation/recovery.js';
import * as repository from '../src/archive/repository.js';
import { state } from '../src/core/state.js';
import { fixture } from './helpers/r847Host.mjs';

const clone = value => structuredClone(value);
const PEOPLE = [
    { id: 'person-left', name: '同名', sourceRefs: [{ world: '合住', uid: '11', title: '左侧人物', content: 'LEFT_SOURCE：黑发，绿眼。' }] },
    { id: 'person-middle', name: '同名', sourceRefs: [{ world: '合住', uid: '12', title: '中间人物', content: 'MIDDLE_SOURCE：黑发，蓝眼。' }] },
    { id: 'person-right', name: '同名', sourceRefs: [{ world: '合住', uid: '13', title: '右侧人物', content: 'RIGHT_SOURCE：黑发，棕眼。' }] },
];
const SNAPSHOT = { version: 1, people: PEOPLE };
const TAGS = ['(black hair:1.25), green eyes', '(black hair:1.25), blue eyes', '(black hair:1.25), brown eyes'];
const SCENE = '三个人在庭院不同位置照料花苗。';
const SCENE_TAGS = '3people, courtyard, left holding seedling, middle watering, right digging';
const FLAT = 'Three people in a courtyard: green-eyed person holds a seedling on the left, blue-eyed person waters in the middle, brown-eyed person digs on the right.';
const PATH = '/user/images/fixture/participants.png';
const ROSTER = { version: 1, cardType: 'multi', revision: 'cast-r1', people: PEOPLE, selectedIds: PEOPLE.map(person => person.id) };

function metadata(promptFormat = 'nai5-natural') {
    return { sceneTags: SCENE_TAGS, flatPrompt: FLAT, promptFormat, castSnapshot: clone(SNAPSHOT),
        characters: PEOPLE.map((person, index) => ({ participantId: person.id, name: person.name, tag: TAGS[index], nl: '' })) };
}

function freeze(value) {
    if (value && typeof value === 'object') { Object.values(value).forEach(freeze); Object.freeze(value); }
    return value;
}

function provider(t, { backend = 'nai', supportsCharacters = true, generate } = {}) {
    const descriptor = Object.getOwnPropertyDescriptor(globalThis, 'STBaiBaiImage');
    const calls = [];
    globalThis.STBaiBaiImage = { apiVersion: 1, capabilities: { generate: true, saveToGallery: true },
        getBackendStatus: () => ({ configured: true, backend, supportsCharacters }),
        generate: async (request, options) => {
            calls.push({ request: clone(request), options });
            return generate ? generate(request, options) : { path: PATH };
        } };
    t.after(() => descriptor ? Object.defineProperty(globalThis, 'STBaiBaiImage', descriptor) : delete globalThis.STBaiBaiImage);
    return calls;
}

async function albumFixture(t, { image = null, multi = true } = {}) {
    const f = await fixture(t);
    if (multi) {
        f.liveBank.participantsV1 = clone(ROSTER);
        f.ctx.chatMetadata[constants.MEMORY_KEY].participantsV1 = clone(ROSTER);
        f.liveCache.participantsV1 = clone(ROSTER);
    }
    const item = { id: 'people-event', title: '庭院合影', desc: SCENE, cgDesc: SCENE,
        imagePrompt: SCENE, unlocked: true, visualSeed: ['花苗'], ...(image ? { cgImage: clone(image) } : {}) };
    const session = { kind: 'album', chatId: f.liveBank.chatId, archiveRevision: f.liveBank.archiveRevision,
        selectedId: item.id, entries: [item], category: '全部', page: 1 };
    f.liveCache.album = clone(session);
    f.ctx.chatMetadata[constants.CACHE_KEY] = clone(f.liveCache);
    f.records.get(f.aEntry.entryId).cache = clone(f.liveCache);
    f.records.get(f.aEntry.entryId).memory = clone(f.liveBank);
    state.runtimeSessionCache.clear(); state.activeMode = 'album'; state.activeSession = session;
    images.abortActiveCgImageTasks();
    t.after(() => images.abortActiveCgImageTasks());
    f.host.hidden = true;
    globalThis.fetch = () => { throw new Error('No network is allowed in the CG participant fixture'); };
    const origin = () => contextApi.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision);
    return { ...f, session, item, origin, async reopen() {
        state.runtimeSessionCache.clear(); await cache.ensureCacheHydrated(f.ctx);
        state.activeSession = cache.loadSession('album', { context: f.ctx });
        return state.activeSession;
    } };
}

// Only the DOM boundary is simulated. All editor state, input listeners,
// confirmations, generation, provider admission and durable cache code are real.
// This fixture makes no browser layout claim.
function editorDom(f, t) {
    class Node {
        constructor() { this.value = ''; this.textContent = ''; this.checked = false; this.attributes = {}; this.listeners = {}; this.nodes = []; this.isConnected = true; }
        set innerHTML(html) {
            this.html = html; this.nodes = [];
            for (const match of html.matchAll(/<([a-z][\w-]*)\b([^>]*)>/gi)) {
                const child = new Node(); child.tagName = match[1];
                for (const attr of match[2].matchAll(/\b(data-rmt-[\w-]+|id)(?:="([^"]*)")?/g)) child.attributes[attr[1]] = attr[2] ?? '';
                this.nodes.push(child);
            }
        }
        descendants() { return this.nodes.flatMap(node => [node, ...node.descendants()]); }
        querySelectorAll(selector) {
            const alternatives = selector.split(',').map(value => value.trim());
            return this.descendants().filter(node => alternatives.some(value => {
                const match = value.match(/^\[([^=\]]+)(?:="([^"]*)")?\]$/);
                return match && Object.hasOwn(node.attributes, match[1]) && (match[2] === undefined || node.attributes[match[1]] === match[2]);
            }));
        }
        querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
        setAttribute(name, value) { this.attributes[name] = value; }
        addEventListener(name, fn) { (this.listeners[name] ||= []).push(fn); }
        removeEventListener(name, fn) { this.listeners[name] = (this.listeners[name] || []).filter(value => value !== fn); }
        emit(name) { for (const fn of this.listeners[name] || []) fn({ target: this, stopPropagation() {}, preventDefault() {} }); }
        focus() { globalThis.document.activeElement = this; }
        remove() { this.isConnected = false; }
    }
    const shell = { current: null, appendChild(node) { this.current = node; node.isConnected = true; } };
    const oldQuery = f.host.querySelector;
    f.host.querySelector = selector => selector === '.rmt-shell' ? shell : oldQuery.call(f.host, selector);
    globalThis.document = { ...globalThis.document, activeElement: null, createElement: () => new Node() };
    t.after(() => {
        editorUi.closeCgPromptEditor({ restoreFocus: false }); f.host.querySelector = oldQuery;
        // r847Host owns restoration of the original global document.
    });
    return { open() {
        editorUi.openCgPromptEditor(); assert.ok(editorUi.hasCgPromptEditor(), JSON.stringify(f.notices)); return shell.current;
    } };
}

test('metadata keeps all selected IDs, duplicate names and unknown looks separately without mutating raw data', () => {
    const raw = metadata(); raw.castSnapshot.people.push({ id: 'unknown', name: '未见外貌', sourceRefs: [] });
    raw.characters.reverse(); raw.characters[0].name = 'provider must not choose a name';
    freeze(raw); const before = JSON.stringify(raw);
    const result = appearance.normalizeCgPromptMetadata(raw);
    assert.deepEqual(result.castSnapshot.people.map(person => person.id), ['person-left', 'person-middle', 'person-right', 'unknown']);
    assert.deepEqual(result.characters.map(row => [row.participantId, row.name, row.tag]), [
        ['person-left', '同名', TAGS[0]], ['person-middle', '同名', TAGS[1]], ['person-right', '同名', TAGS[2]],
    ]);
    assert.equal(JSON.stringify(raw), before);
    assert.deepEqual(appearance.metadataAfterSceneEdit(result).castSnapshot, result.castSnapshot);
    assert.equal(appearance.metadataAfterSceneEdit(result).flatPrompt, undefined);
});

test('multiplayer normalization has no two/eight-person truncation', () => {
    const people = Array.from({ length: 12 }, (_, index) => ({ id: `p-${index}`, name: '同名', sourceRefs: [] }));
    const result = appearance.normalizeCgPromptMetadata({ castSnapshot: { version: 1, people },
        characters: people.map(person => ({ participantId: person.id, tag: 'black hair' })) });
    assert.equal(result.castSnapshot.people.length, 12); assert.equal(result.characters.length, 12);
    assert.equal(result.characters[11].participantId, 'p-11');
});

test('selected evidence is ID-bound and never guesses from card, user or same-name image library', () => {
    const ctx = { name1: '不应自动入镜', name2: '沙盒卡名', chatMetadata: {},
        getCharacterCardFields() { throw new Error('multiplayer evidence must not read the card'); } };
    const evidence = appearance.captureCgAppearanceEvidence(ctx, { castSnapshot: SNAPSHOT,
        api: { apiVersion: 1, capabilities: { characterLibrary: true }, getCharacters() { throw new Error('ambiguous name lookup is forbidden'); } } });
    assert.deepEqual(evidence.characters.map(row => row.participantId), ['person-left', 'person-middle', 'person-right']);
    assert.match(evidence.characters[0].description, /LEFT_SOURCE/);
    assert.doesNotMatch(evidence.characters[0].description, /MIDDLE_SOURCE|RIGHT_SOURCE/);
    const prompt = images.buildCgReconceptPrompt({ desc: SCENE }, ctx, 'album', evidence, 'nai5-natural');
    assert.doesNotMatch(prompt, /沙盒卡名|不应自动入镜/);
    assert.match(prompt, /person-left/); assert.match(prompt, /person-middle/); assert.match(prompt, /person-right/);
});

test('prepared reply keeps the complete snapshot and does not invent unknown appearance', () => {
    const snapshot = clone(SNAPSHOT); snapshot.people.push({ id: 'unknown', name: '路过者', sourceRefs: [] });
    const evidence = appearance.captureCgAppearanceEvidence({ chatMetadata: {} }, { castSnapshot: snapshot, api: null });
    const result = appearance.normalizeCgPreparedPrompt({ imagePrompt: SCENE, sceneTags: SCENE_TAGS, flatPrompt: FLAT,
        characters: [...PEOPLE.map((person, index) => ({ participantId: person.id, tag: TAGS[index] })),
            { participantId: 'unknown', tag: 'made up blond hair' }] }, evidence);
    assert.equal(result.castSnapshot.people.length, 4); assert.equal(result.characters.length, 3);
    assert.deepEqual(result.missingParticipantIds, ['unknown']);
    assert.doesNotMatch(JSON.stringify(result.characters), /blond/);
    assert.throws(() => appearance.normalizeCgPreparedPrompt({ imagePrompt: SCENE, sceneTags: SCENE_TAGS, flatPrompt: FLAT,
        characters: [{ participantId: 'person-left', tag: TAGS[0] }, { participantId: 'person-left', tag: TAGS[1] }] }, evidence),
    error => error.code === 'RMT_CG_PROMPT_INVALID');
});

for (const manualChinese of [false, true]) test(`multiplayer reconception sends the complete selected source beyond 16000 characters (Chinese draft=${manualChinese})`, async t => {
    const f = await albumFixture(t);
    f.ctx.extensionSettings[constants.EXTENSION_SETTINGS_KEY].excludedContextTags = ['thinking', 'secret'];
    const tail = 'TAIL_SOURCE_MARK：银灰色长发，左眼下有星形胎记。';
    const content = 'VISIBLE_SOURCE_HEAD <secret>HIDDEN_SOURCE_HEAD</secret>\n'
        + 'neutral setting detail '.repeat(900)
        + '<thinking>HIDDEN_SOURCE_TAIL</thinking>&lt;secret&gt;HIDDEN_ENCODED_TAIL&lt;/secret&gt;'
        + '<b>VISIBLE_AFTER_LONG_BODY</b> https://example.invalid/PRIVATE_URL {{PRIVATE_MACRO}}\u0000\n' + tail;
    assert.ok(content.indexOf(tail) > 16000, 'the appearance is beyond both former per-source cutoffs');
    const snapshot = freeze({ version: 1, people: [{ ...clone(PEOPLE[0]), sourceRefs: [{ ...clone(PEOPLE[0].sourceRefs[0]), content }] }] });
    const before = JSON.stringify(snapshot), originalRoster = clone(cache.readParticipantRoster(f.ctx));
    const appearanceDraft = manualChinese ? { [PEOPLE[0].id]: '银灰色长发' } : null;
    const evidence = appearance.appearanceEvidenceForFormat(appearance.appearanceEvidenceWithDraft(
        appearance.captureCgAppearanceEvidence(f.ctx, { castSnapshot: snapshot }), appearanceDraft), 'nai45-tags');
    const instructions = appearance.buildCgAppearanceInstructions(evidence, 'nai45-tags');
    assert.ok(instructions.includes(tail), 'the full tail reaches the actual appearance instructions');
    assert.ok(instructions.includes('VISIBLE_SOURCE_HEAD') && instructions.includes('VISIBLE_AFTER_LONG_BODY'));
    assert.doesNotMatch(instructions, /HIDDEN_|PRIVATE_URL|PRIVATE_MACRO|<b>|MIDDLE_SOURCE|RIGHT_SOURCE/);
    if (manualChinese) assert.match(evidence.characters[0].description, /^已保存资料/);
    f.setResponse({ imagePrompt: '1person, courtyard, holding seedling', sceneTags: '1person, courtyard, holding seedling',
        flatPrompt: '1person, silver hair, long hair, star-shaped birthmark, courtyard, holding seedling',
        characters: [{ participantId: PEOPLE[0].id, tag: 'silver hair, long hair, star-shaped birthmark', nl: '' }] });
    const result = await images.reconceiveCgImagePrompt(images.captureCgImageTarget(),
        { promptFormat: 'nai45-tags', appearanceDraft, castSnapshot: snapshot });
    assert.equal(f.requests.length, 1, 'complete source selection still uses one explicit text request');
    const sent = f.requests[0].map(message => message.content).join('\n');
    assert.ok(sent.includes(tail), 'the provider receives the long-source tail, not only a helper preview');
    assert.ok(sent.includes('VISIBLE_SOURCE_HEAD') && sent.includes('VISIBLE_AFTER_LONG_BODY'));
    assert.doesNotMatch(sent, /HIDDEN_|PRIVATE_URL|PRIVATE_MACRO|<b>|MIDDLE_SOURCE|RIGHT_SOURCE|CARD_A_ONLY|PERSONA_A_ONLY/);
    assert.equal(result.characters.length, 1);
    assert.deepEqual(result.castSnapshot, snapshot);
    assert.equal(JSON.stringify(snapshot), before, 'filtering is a read-only projection of complete sourceRefs');
    assert.deepEqual(cache.readParticipantRoster(f.ctx), originalRoster);
});

test('legacy V1 char/user normalization and signatures remain literal and acquire no multiplayer marker', t => {
    const oldLocation = Object.getOwnPropertyDescriptor(globalThis, 'location'); globalThis.location = { href: 'tauri://localhost/' };
    t.after(() => oldLocation ? Object.defineProperty(globalThis, 'location', oldLocation) : delete globalThis.location);
    const old = freeze({ sceneTags: 'garden', characters: [{ role: 'char', name: '甲', tag: 'black hair', nl: '' },
        { role: 'user', name: '乙', tag: 'silver hair', nl: '' }] });
    assert.deepEqual(appearance.normalizeCgPromptMetadata(old), old);
    const image = { url: '/user/images/fixture/old.png', prompt: '旧图', provider: 'baibai-image', generatedAt: 1, promptMetadata: old };
    const item = { id: 'old', title: '旧事件', cgImage: image };
    assert.equal(patch.cgItemSignature(item), JSON.stringify(['old', '旧事件', null, null, null, null, null, null, null, null, image]));
    const record = { chatId: 'old', char: 'black hair', user: 'silver hair', manual: true, updatedAt: 7 };
    assert.equal(looks.castLooksSignature(record), '["black hair","silver hair",true,7,""]');
});

for (const promptFormat of ['nai45-tags', 'nai5-natural']) for (const backend of ['nai', 'comfyui']) for (const supportsCharacters of [true, false]) {
    test(`three same-name people reach public provider once: ${promptFormat}/${backend}/${supportsCharacters}`, async t => {
        const f = await albumFixture(t); const calls = provider(t, { backend, supportsCharacters });
        const raw = freeze(metadata(promptFormat)), before = JSON.stringify(raw);
        const expectedCharacters = PEOPLE.map((person, index) => ({ name: '同名', tag: TAGS[index],
            ...(promptFormat === 'nai45-tags' && backend !== 'nai' ? { nl: TAGS[index] } : {}) }));
        const prompt = promptFormat === 'nai45-tags' && supportsCharacters ? SCENE_TAGS : FLAT;
        const expected = { prompt, nl: backend === 'nai' && supportsCharacters ? '' : prompt,
            ...(supportsCharacters ? { characters: expectedCharacters } : {}) };
        assert.deepEqual(images.cgEditorSendPreview('album', f.item, SCENE, raw, promptFormat), expected);
        await images.invokeImageGeneration(SCENE, f.ctx, { promptMetadata: raw });
        assert.equal(calls.length, 1); assert.equal(f.requests.length, 0);
        assert.deepEqual(calls[0].request, { ...expected, size: 'landscape', save: true, character: '林舟' });
        assert.equal(JSON.stringify(raw), before);
    });
}

test('participant appearance saves by ID, survives mirror loss, rejects stale CAS and leaves V1 bytes unchanged', async t => {
    const f = await albumFixture(t);
    looks.writeCastLooks(f.ctx, { char: 'OLD_CHAR', user: 'OLD_USER', manual: true }, f.ctx.chatId);
    const legacy = JSON.stringify(f.ctx.chatMetadata[looks.CAST_LOOKS_KEY]);
    const ticket = { origin: f.origin(), expectedSignature: looks.participantLooksSignature(null) };
    const saved = looks.saveConfirmedParticipantLooks(PEOPLE.map((person, index) => ({ participantId: person.id, tag: TAGS[index] })), ticket);
    assert.deepEqual(saved.characters.map(row => row.tag), TAGS);
    assert.equal(JSON.stringify(f.ctx.chatMetadata[looks.CAST_LOOKS_KEY]), legacy);
    delete f.ctx.chatMetadata[looks.PARTICIPANT_LOOKS_KEY];
    assert.deepEqual(looks.readParticipantLooks(f.ctx), saved);
    assert.throws(() => looks.saveConfirmedParticipantLooks([{ participantId: 'person-left', tag: 'blond hair' }], ticket), error => error.code === 'RMT_CAST_LOOKS_STALE');
    assert.equal(f.requests.length, 0);
});

test('real editor edits three same-name people, switches format without requests, draws once and reopens its own snapshot', async t => {
    const f = await albumFixture(t); const calls = provider(t); const dom = editorDom(f, t);
    let element = dom.open();
    assert.equal(element.querySelectorAll('[data-rmt-cg-person-selected]').length, 3);
    assert.equal(element.querySelector('[data-rmt-cg-tag-input="char"]'), null);
    for (let index = 0; index < 3; index++) {
        const field = element.querySelector(`[data-rmt-cg-person-tag="${index}"]`); field.value = TAGS[index]; field.emit('input');
    }
    await editorUi.handleCgPromptEditorAction('save-looks');
    assert.match(element.querySelector('[data-rmt-cg-prompt-status]').textContent, /外貌已保存/);
    await editorUi.handleCgPromptEditorAction('add-user');
    assert.equal(element.querySelector('[data-rmt-cg-person-name="3"]').value, '小月');
    assert.equal(element.querySelector('[data-rmt-cg-person-selected="3"]').checked, false, 'the user is optional');
    const choice = element.querySelector('[data-rmt-cg-editor-format]'); choice.value = 'nai45-tags'; choice.emit('change');
    for (let index = 0; index < 3; index++) assert.equal(element.querySelector(`[data-rmt-cg-person-tag="${index}"]`).value, TAGS[index]);
    assert.equal(f.requests.length, 0); assert.equal(calls.length, 0);
    f.setResponse({ imagePrompt: SCENE_TAGS, sceneTags: SCENE_TAGS, flatPrompt: FLAT,
        characters: PEOPLE.map((person, index) => ({ participantId: person.id, tag: TAGS[index], nl: '' })) });
    await editorUi.handleCgPromptEditorAction('reconceive');
    assert.equal(f.requests.length, 1, JSON.stringify(f.notices)); assert.equal(calls.length, 0);
    assert.doesNotMatch(f.requests[0].map(row => row.content).join('\n'), /CARD_A_ONLY|PERSONA_A_ONLY/);
    for (const tag of TAGS) assert.ok(element.querySelector('[data-rmt-cg-send-preview]').value.includes(tag));
    await editorUi.handleCgPromptEditorAction('draw');
    assert.equal(calls.length, 1, JSON.stringify(f.notices)); assert.equal(f.requests.length, 1);
    const saved = (await f.persisted()).album.entries[0];
    assert.equal(saved.cgImage.url, PATH); assert.deepEqual(saved.cgImage.promptMetadata.castSnapshot, SNAPSHOT);
    assert.deepEqual(saved.cgImage.promptMetadata.characters.map(row => row.tag), TAGS);
    assert.equal(saved.desc, SCENE);
    const oldRoster = cache.readParticipantRoster(f.ctx);
    await cache.commitParticipantRoster(f.ctx,
        { ...clone(oldRoster), people: [{ id: 'new', name: '后改名单', sourceRefs: [] }], selectedIds: ['new'] },
        { expectedRevision: oldRoster.revision });
    await f.reopen(); element = dom.open();
    assert.deepEqual(cache.readParticipantRoster(f.ctx).selectedIds, ['new'], 'the current archive really has a different canonical roster');
    assert.equal(element.querySelectorAll('[data-rmt-cg-person-selected]').length, 3);
    assert.equal(element.querySelector('[data-rmt-cg-person-name="0"]').value, '同名');
    assert.equal(element.querySelector('[data-rmt-cg-person-tag="2"]').value, TAGS[2]);
    assert.equal(calls.length, 1); assert.equal(f.requests.length, 1);
});

for (const edit of ['appearance', 'name', 'selection']) test(`real editor preserves authored scene tags after participant ${edit} edits`, async t => {
    const f = await albumFixture(t); const calls = provider(t); const dom = editorDom(f, t);
    const element = dom.open(), originalRoster = clone(cache.readParticipantRoster(f.ctx));
    const format = element.querySelector('[data-rmt-cg-editor-format]');
    format.value = 'nai45-tags'; format.emit('change');
    const scene = element.querySelector('[data-rmt-cg-prompt-input]');
    scene.value = SCENE_TAGS; scene.emit('input');
    for (let index = 0; index < PEOPLE.length; index++) {
        const field = element.querySelector(`[data-rmt-cg-person-tag="${index}"]`);
        field.value = TAGS[index]; field.emit('input');
    }
    const sceneTags = element.querySelector('[data-rmt-cg-scene-tags]');
    const authoredSceneTags = '(from below:1.3), courtyard, holding seedling, watering plants';
    sceneTags.value = authoredSceneTags; sceneTags.emit('input');
    const flat = element.querySelector('[data-rmt-cg-flat-prompt]');
    flat.value = FLAT; flat.emit('input');
    const changedTag = '(silver hair:1.25), green eyes';
    if (edit === 'appearance') {
        const field = element.querySelector('[data-rmt-cg-person-tag="0"]');
        field.value = changedTag; field.emit('input');
    } else if (edit === 'name') {
        const field = element.querySelector('[data-rmt-cg-person-name="0"]');
        field.value = '手选人物姓名'; field.emit('input');
    } else {
        const field = element.querySelector('[data-rmt-cg-person-selected="0"]');
        field.checked = false; field.emit('change');
    }
    const expectedPeople = clone(edit === 'selection' ? PEOPLE.slice(1) : PEOPLE);
    if (edit === 'name') expectedPeople[0].name = '手选人物姓名';
    const expectedTags = edit === 'selection' ? TAGS.slice(1) : edit === 'appearance' ? [changedTag, ...TAGS.slice(1)] : TAGS;
    assert.equal(sceneTags.value, authoredSceneTags, 'participant edits must retain independently authored camera, action and scene tags');
    assert.equal(scene.value, SCENE_TAGS);
    assert.equal(flat.value, '', 'the old full prompt still becomes stale when its participants change');
    const preview = element.querySelector('[data-rmt-cg-send-preview]').value;
    assert.ok(preview.includes(authoredSceneTags));
    for (const tag of expectedTags) assert.ok(preview.includes(tag));
    assert.equal(preview.includes(FLAT), false);
    if (edit !== 'name') assert.equal(preview.includes(TAGS[0]), false);
    assert.deepEqual(cache.readParticipantRoster(f.ctx), originalRoster);
    assert.equal(f.requests.length, 0); assert.equal(calls.length, 0);
    await editorUi.handleCgPromptEditorAction('draw');
    assert.equal(calls.length, 1, JSON.stringify(f.notices)); assert.equal(f.requests.length, 0);
    assert.deepEqual(calls[0].request, { prompt: authoredSceneTags, nl: '',
        characters: expectedPeople.map((person, index) => ({ name: person.name, tag: expectedTags[index] })),
        size: 'landscape', save: true, character: f.ctx.name2 });
    const saved = (await f.persisted()).album.entries[0].cgImage.promptMetadata;
    assert.equal(saved.sceneTags, authoredSceneTags); assert.equal(saved.flatPrompt, undefined);
    assert.deepEqual(saved.characters.map(person => person.tag), expectedTags);
    assert.deepEqual(saved.castSnapshot, { version: 1, people: expectedPeople });
    assert.deepEqual(cache.readParticipantRoster(f.ctx), originalRoster);
});

test('real editor can deselect a resident and add a named unknown person without editing the archive roster', async t => {
    const f = await albumFixture(t); const calls = provider(t); const dom = editorDom(f, t); const element = dom.open();
    const originalRoster = JSON.stringify(cache.readParticipantRoster(f.ctx));
    const left = element.querySelector('[data-rmt-cg-person-selected="0"]'); left.checked = false; left.emit('change');
    await editorUi.handleCgPromptEditorAction('add-person');
    const name = element.querySelector('[data-rmt-cg-person-name="3"]'); name.value = '只在本图出现'; name.emit('input');
    const added = element.querySelector('[data-rmt-cg-person-selected="3"]'); added.checked = true; added.emit('change');
    await editorUi.handleCgPromptEditorAction('draw');
    assert.equal(calls.length, 1, JSON.stringify(f.notices)); assert.equal(f.requests.length, 0);
    const saved = (await f.persisted()).album.entries[0].cgImage.promptMetadata;
    assert.deepEqual(saved.castSnapshot.people.map(person => person.name), ['同名', '同名', '只在本图出现']);
    assert.equal(saved.castSnapshot.people.some(person => person.id === 'person-left'), false);
    assert.equal(saved.characters.length, 0, 'unknown appearance does not remove any selected person');
    assert.equal(JSON.stringify(cache.readParticipantRoster(f.ctx)), originalRoster);
});

test('completed image retains all participant metadata through failed commit and free retry', async t => {
    const f = await albumFixture(t); const calls = provider(t);
    const captured = images.captureCgImageTarget(); const raw = metadata();
    f.failCompletedSave('album', value => !!value?.entries?.[0]?.cgImage);
    await images.drawSelectedCgImage({ promptOverride: SCENE, promptMetadata: raw, expectedTarget: captured });
    assert.equal(calls.length, 1); assert.ok(images.hasPendingCgImage(captured), JSON.stringify(f.notices));
    assert.equal((await f.persisted()).album.entries[0].cgImage, undefined);
    f.failCompletedSave('');
    assert.equal(await images.retryPendingCgImage(captured), true, JSON.stringify(f.notices));
    assert.equal(calls.length, 1); assert.equal(f.requests.length, 0);
    await f.reopen();
    assert.deepEqual(state.activeSession.entries[0].cgImage.promptMetadata.castSnapshot, SNAPSHOT);
    assert.deepEqual(state.activeSession.entries[0].cgImage.promptMetadata.characters.map(row => row.tag), TAGS);
});

test('old image stays on its own legacy metadata even after the archive adopts a multiplayer roster', async t => {
    const prior = { sceneTags: 'old garden', characters: [{ role: 'char', name: '旧角色', tag: 'old hair', nl: '' }] };
    const image = { url: '/user/images/fixture/old.png', prompt: '旧画面', provider: 'baibai-image', generatedAt: 1, promptMetadata: prior };
    const f = await albumFixture(t, { image }); const dom = editorDom(f, t); const before = JSON.stringify(f.item);
    const element = dom.open();
    assert.equal(element.querySelector('[data-rmt-cg-cast]'), null);
    assert.equal(element.querySelector('[data-rmt-cg-tag-input="char"]').value, 'old hair');
    assert.deepEqual(appearance.initialCgAppearanceMetadata(f.item, f.ctx), prior);
    assert.equal(JSON.stringify(f.item), before); assert.equal(f.requests.length, 0);
});

async function partialAlbumFixture(t) {
    const f = await albumFixture(t);
    const origin = f.origin();
    await generation.beginModeRecovery('album', f.ctx, f.liveBank, origin,
        { existing: null, pageId: 'album', contentInputs: { previousSession: f.session } });
    await recovery.withRecoverySegment('already received index', { origin, taskKey: 'album:test-index', mode: 'album', context: f.ctx }, value => value,
        async (_prompt, _options, accept) => { const value = { saved: true }; await accept(value); return value; });
    recovery.detachGenerationRecovery(origin);
    const draftId = origin.generationRecoveryDraftId;
    const session = { ...clone(f.session), entries: [{ ...clone(f.item), id: 'partial-new-cg', title: '已收到的新回忆' }], selectedId: 'partial-new-cg',
        readableProgress: { version: 1, complete: false, draftId, pageId: 'album' } };
    await cache.saveGenerationTaskResult(f.ctx, 'album', session, origin,
        { complete: false, memoryBank: f.liveBank, sourceMemory: f.liveBank });
    state.activeSession = cache.loadSession('album', { context: f.ctx, includePartial: true });
    return { ...f, partial: session, draftId, generationOrigin: origin };
}

test('partial CG draws once, persists in its task, survives reload and text completion without changing the prior formal album', async t => {
    const f = await partialAlbumFixture(t); const calls = provider(t);
    const formalBefore = clone((await f.persisted()).album);
    const captured = images.captureCgImageTarget();
    assert.equal(captured?.draftId, f.draftId);
    await images.drawSelectedCgImage({ promptOverride: SCENE, promptMetadata: metadata(), expectedTarget: captured });
    assert.equal(calls.length, 1, JSON.stringify(f.notices));
    assert.deepEqual((await f.persisted()).album, formalBefore);
    state.runtimeSessionCache.clear(); await cache.ensureCacheHydrated(f.ctx);
    const reloaded = cache.loadSession('album', { context: f.ctx, includePartial: true });
    assert.equal(reloaded.entries[0].cgImage.url, PATH, JSON.stringify(f.notices));
    assert.deepEqual(reloaded.entries[0].cgImage.promptMetadata.castSnapshot, SNAPSHOT);
    const final = clone(f.partial); delete final.readableProgress;
    assert.equal(await cache.commitSession('album', final, f.liveBank.chatId, f.generationOrigin), true);
    assert.equal(cache.loadSession('album', { context: f.ctx }).entries[0].cgImage.url, PATH);
    assert.equal(calls.length, 1); assert.equal(f.requests.length, 0);
});

test('a partial CG already drawing writes to the matching formal item when its text task finishes meanwhile', async t => {
    const f = await partialAlbumFixture(t);
    const calls = provider(t, { generate: async () => {
        const final = clone(f.partial); delete final.readableProgress;
        assert.equal(await cache.commitSession('album', final, f.liveBank.chatId, f.generationOrigin), true);
        return { path: PATH };
    } });
    const captured = images.captureCgImageTarget(); assert.ok(captured?.draftId);
    await images.drawSelectedCgImage({ promptOverride: SCENE, promptMetadata: metadata(), expectedTarget: captured });
    assert.equal(calls.length, 1);
    assert.equal((await f.persisted()).album.entries[0].cgImage?.url, PATH, JSON.stringify(f.notices));
    assert.equal(images.hasPendingCgImage(captured), false);
});

test('partial CG deferred while another chat is open returns to the original draft and leaves both formal pages intact', async t => {
    const f = await partialAlbumFixture(t);
    const before = clone((await f.persisted()).album);
    const captured = images.captureCgImageTarget();
    const prior = { characterId: f.ctx.characterId, chatId: f.ctx.chatId, name1: f.ctx.name1, name2: f.ctx.name2, chatMetadata: f.ctx.chatMetadata };
    Object.assign(f.ctx, { characterId: 1, chatId: f.otherBank.chatId, name1: f.otherBank.userName, name2: f.otherBank.characterName,
        chatMetadata: { [constants.MEMORY_KEY]: clone(f.otherBank), [constants.CACHE_KEY]: clone(f.otherCache) } });
    const image = { url: PATH, prompt: SCENE, provider: 'baibai-image', generatedAt: 1 };
    assert.ok(images.deferCgImageIfOriginChanged(captured, image));
    Object.assign(f.ctx, prior);
    await repository.flushDeferredCommitsForCurrentChat();
    assert.deepEqual((await f.persisted()).album, before);
    assert.equal((await cache.readGenerationTaskResult(f.ctx, f.draftId)).session.entries[0].cgImage?.url, PATH);
    assert.deepEqual(await f.persisted(f.bEntry), f.otherCache);
    assert.equal(f.requests.length, 0);
});

test('legacy image explicitly adopts current cast only in local editor and can restore the original draft', async t => {
    const prior = { sceneTags: 'old garden', flatPrompt: 'Old complete prompt.', characters: [{ role: 'char', name: '旧角色', tag: 'old hair', nl: '' }] };
    const image = { url: '/user/images/fixture/old.png', prompt: '旧画面', provider: 'baibai-image', generatedAt: 1, promptMetadata: prior };
    const f = await albumFixture(t, { image }), calls = provider(t), dom = editorDom(f, t), before = JSON.stringify(f.item);
    const element = dom.open();
    assert.ok(element.querySelector('[data-rmt-cg-prompt-action="use-current-cast"]'), 'legacy image offers explicit participant selection');
    const originalScene = element.querySelector('[data-rmt-cg-prompt-input]').value;
    await editorUi.handleCgPromptEditorAction('use-current-cast');
    assert.equal(element.querySelectorAll('[data-rmt-cg-person-selected]').length, 3);
    assert.equal(element.querySelector('[data-rmt-cg-person-selected="0"]').checked, true);
    assert.equal(element.querySelector('[data-rmt-cg-prompt-input]').value, originalScene);
    assert.equal(element.querySelector('[data-rmt-cg-flat-prompt]').value, '', 'only obsolete dependent flat draft is cleared');
    assert.equal(element.querySelector('[data-rmt-cg-scene-tags]').value, 'old garden');
    assert.equal(JSON.stringify(f.item), before);
    assert.equal(f.requests.length, 0); assert.equal(calls.length, 0);
    await editorUi.handleCgPromptEditorAction('restore-draft');
    assert.equal(element.querySelector('[data-rmt-cg-cast]'), null);
    assert.equal(element.querySelector('[data-rmt-cg-tag-input="char"]').value, 'old hair');
    assert.equal(element.querySelector('[data-rmt-cg-flat-prompt]').value, prior.flatPrompt);
    assert.equal(element.querySelector('[data-rmt-cg-prompt-input]').value, originalScene);
    await editorUi.handleCgPromptEditorAction('use-current-cast');
    const unchecked = element.querySelector('[data-rmt-cg-person-selected="2"]'); unchecked.checked = false; unchecked.emit('change');
    f.setResponse({ imagePrompt: '两人照料花苗', sceneTags: '2people, courtyard', flatPrompt: 'Two people in a courtyard.',
        characters: PEOPLE.slice(0, 2).map((person, index) => ({ participantId: person.id, tag: TAGS[index], nl: '' })) });
    await editorUi.handleCgPromptEditorAction('reconceive');
    assert.equal(f.requests.length, 1, JSON.stringify(f.notices)); assert.equal(calls.length, 0);
    const sent = f.requests[0].map(row => row.content).join('\n');
    assert.match(sent, /LEFT_SOURCE/); assert.match(sent, /MIDDLE_SOURCE/);
    assert.doesNotMatch(sent, /RIGHT_SOURCE|CARD_A_ONLY|PERSONA_A_ONLY/);
    assert.equal(JSON.stringify(f.item), before, 'reconceive never replaces old image or saved prompt');
    assert.deepEqual(cache.readParticipantRoster(f.ctx), ROSTER);
});

test('real reconceive sends saved-empty worldbook source and leaves old image untouched', async t => {
    const prior = metadata();
    const image = { url: '/user/images/fixture/old.png', prompt: '旧画面', provider: 'baibai-image', generatedAt: 1, promptMetadata: prior };
    const f = await albumFixture(t, { image }), calls = provider(t);
    looks.saveConfirmedParticipantLooks(PEOPLE.map(person => ({ participantId: person.id, tag: '' })), {
        origin: f.origin(), expectedSignature: looks.participantLooksSignature(looks.readParticipantLooks(f.ctx)),
    });
    const before = JSON.stringify(f.item);
    f.setResponse({ imagePrompt: SCENE, sceneTags: SCENE_TAGS, flatPrompt: FLAT,
        characters: PEOPLE.map((person, index) => ({ participantId: person.id, tag: TAGS[index], nl: '' })) });
    const result = await images.reconceiveCgImagePrompt(images.captureCgImageTarget(), { promptFormat: 'nai5-natural',
        appearanceDraft: Object.fromEntries(PEOPLE.map(person => [person.id, ''])) });
    assert.equal(f.requests.length, 1); assert.equal(calls.length, 0);
    const sent = f.requests[0].map(row => row.content).join('\n');
    for (const source of ['LEFT_SOURCE', 'MIDDLE_SOURCE', 'RIGHT_SOURCE']) assert.ok(sent.includes(source));
    assert.deepEqual(result.missingParticipantIds, []);
    assert.deepEqual(result.characters.map(person => person.tag), TAGS);
    assert.equal(JSON.stringify(f.item), before);
});
