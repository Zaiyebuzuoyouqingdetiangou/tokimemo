import test from 'node:test';
import assert from 'node:assert/strict';
import * as A from '../src/core/independentApi.js';
import * as C from '../src/core/constants.js';

const answer=JSON.stringify({memories:[{title:'纸船',summary:'两人在湖畔放了纸船。'}]});
const envelope=(text=answer,finish='stop')=>JSON.stringify({choices:[{index:0,message:{role:'assistant',content:text},finish_reason:finish}]});
const event=(text=answer,finish=null,index=0)=>`data: ${JSON.stringify({choices:[{index,delta:{content:text},finish_reason:finish}]})}\n\n`;
const stream=(text=answer,finish='stop')=>event(text)+event('',finish)+'data: [DONE]\n\n';
const textOf=x=>A.extractIndependentResponseContent(x);
function response(bytes, type, {slice=4096,status=200,declared=null,textOnly=false}={}) {
    const raw=typeof bytes==='string'?new TextEncoder().encode(bytes):bytes;
    const headers=new Headers();if(type!=null)headers.set('Content-Type',type);if(declared!=null)headers.set('Content-Length',String(declared));
    const stats={reads:0,cancels:0,position:0};
    if(textOnly)return {value:{status,ok:status>=200&&status<300,headers,text:async()=>new TextDecoder().decode(raw)},stats};
    const body=new ReadableStream({pull(c){stats.reads++;if(stats.position>=raw.length){c.close();return;}const end=Math.min(raw.length,stats.position+slice);c.enqueue(raw.subarray(stats.position,end));stats.position=end;},cancel(){stats.cancels++;}}, {highWaterMark:0});
    return {value:new Response(body,{status,headers}),stats};
}
async function request(r,{requested=true,signal=null}={}) {
    const settings={apiConnectionMode:'manual',manualApiBaseUrl:'https://fixture.invalid/api/coding/v3',manualApiKey:'',manualApiModel:'local-test',manualApiStreaming:requested,temperature:0.5};
    const before=JSON.stringify(settings);let calls=0;
    try {
      return await A.requestManualApiCompletion(settings,{},[{role:'user',content:'合成请求，无真实资料'}],200,{signal,fetchImpl:async(path,opts)=>{
       calls++;assert.equal(path,'/api/backends/chat-completions/generate');const body=JSON.parse(opts.body);
       assert.equal(body.stream,requested);assert.equal(body.custom_url,settings.manualApiBaseUrl);assert.equal(body.chat_completion_source,'custom');assert.equal(body.max_tokens,200);assert.equal(opts.credentials,'same-origin');return r;
      }});
    } finally {assert.equal(calls,signal?.aborted&&calls===0?0:1);assert.equal(JSON.stringify(settings),before);}
}
for (const requested of [false,true])for(const type of [null,'text/event-stream','application/json','text/plain','application/octet-stream'])for(const format of ['sse','json'])test(`same response / requested=${requested} / type=${type} / actual=${format}`,async()=>{
 const r=response(format==='sse'?stream():envelope(),type,{slice:7});const result=await request(r.value,{requested});assert.equal(textOf(result),answer);assert.equal(r.value.body.locked,false);
 if(format==='sse'){assert.equal(A.manualStreamCompletionInfo(result).complete,true);assert.equal(A.assertManualStreamComplete(result),true);}
});
for(const slice of [1,2,3,7,37,8192])for(const ending of ['\n','\r\n','\r'])test(`incremental UTF-8 / BOM / SSE line ending=${JSON.stringify(ending)} / chunk=${slice}`,async()=>{
 const bytes='\uFEFF: heartbeat\n\nevent: message\nid: 7\nretry: 999\n'+stream();const r=response(bytes.replaceAll('\n',ending),null,{slice});
 assert.equal(textOf(await request(r.value)),answer);assert.equal(r.value.body.locked,false);
});
for(const first of ['data:','event: message\n','id: 1\n','retry: 1000\n',': comment\n\n'])test('recognizes bounded SSE prefix '+JSON.stringify(first),async()=>{
 const raw=first==='data:'?stream().replace('data: ','data:'):first+stream();assert.equal(textOf(await request(response(raw,null,{slice:1}).value)),answer);
});
for(const format of ['sse','json'])test('text-only host shim reads once: '+format,async()=>{assert.equal(textOf(await request(response(format==='sse'?stream():envelope(),null,{textOnly:true}).value)),answer)});
for(const type of [null,'application/json','text/event-stream'])for(const html of ['<html>{"choices":[]}</html>',': keepalive\n\n<html>bad</html>\n'+stream()])test('HTML wrapper never becomes a completion '+type+' '+html.slice(0,15),async()=>{
 await assert.rejects(request(response(html,type,{slice:5}).value),e=>e.code==='RMT_RESPONSE_HTML');
});
for(const bytes of [envelope(),stream()])test('explicit HTML MIME cannot be bypassed by valid-looking bytes',async()=>{await assert.rejects(request(response(bytes,'text/html').value),{code:'RMT_RESPONSE_HTML'})});
for(const format of ['sse','json'])test('markup and data labels inside valid JSON string stay inert: '+format,async()=>{
 const text=JSON.stringify({summary:'<span>合成文字</span> data: example event: message'});
 assert.equal(textOf(await request(response(format==='sse'?stream(text):envelope(text),'application/json',{slice:3}).value)),text);
});
for(const type of [null,'application/json','text/event-stream'])test('incomplete SSE cannot be committed even with complete application JSON: '+type,async()=>{
 const result=await request(response(event(answer),type).value);assert.equal(textOf(result),answer);assert.equal(A.manualStreamCompletionInfo(result).complete,false);assert.throws(()=>A.assertManualStreamComplete(result),{code:'RMT_JSON_TRUNCATED'});
});
for(const finish of ['length','max_tokens','tool_calls','content_filter','unrecognized'])test('non-success terminal reason stays incomplete: '+finish,async()=>{
 const result=await request(response(stream(answer,finish),null).value);assert.throws(()=>A.assertManualStreamComplete(result),{code:'RMT_JSON_TRUNCATED'});
});
for(const broken of ['data: {bad\n\n','data: [DONE]','event: error\ndata: {"error":"SENSITIVE_SENTINEL"}\n\n'])test('malformed/empty/error first stream is rejected without leaking body '+broken.slice(0,17),async()=>{
 await assert.rejects(request(response(broken,null).value),e=>{assert.doesNotMatch(JSON.stringify(e)+e.message,/SENSITIVE_SENTINEL|\{bad/);return ['RMT_MANUAL_INVALID_JSON','RMT_MANUAL_PROVIDER_ERROR','RMT_MANUAL_EMPTY'].includes(e.code)});
});
test('malformed later event preserves only previous data as incomplete, never success',async()=>{
 const result=await request(response(event(answer)+'data: {bad\n\n'+stream('FORBIDDEN'),null).value);assert.equal(textOf(result),answer);assert.throws(()=>A.assertManualStreamComplete(result),{code:'RMT_JSON_TRUNCATED'});
});
test('actual HTML line after visible SSE makes result incomplete, not successful',async()=>{
 const result=await request(response(event(answer)+'<html>failure</html>\n'+stream(),null).value);assert.throws(()=>A.assertManualStreamComplete(result),{code:'RMT_JSON_TRUNCATED'});
});
test('reasoning-only stream does not become final output',async()=>{
 const raw=`data: ${JSON.stringify({choices:[{index:0,delta:{reasoning_content:'NOT_FINAL'},finish_reason:null}]})}\n\n`+event('','stop');
 await assert.rejects(request(response(raw,null).value),{code:'RMT_MANUAL_EMPTY'});
});
test('multiple candidates remain isolated to index 0',async()=>{
 const raw=event('WRONG',null,1)+event(answer)+event('','stop');assert.equal(textOf(await request(response(raw,null).value)),answer);
});
test('multi-line SSE data JSON is joined without corrupting UTF-8',async()=>{
 const raw='data: {"choices":[\n'+'data: '+JSON.stringify({index:0,delta:{content:answer},finish_reason:'stop'})+']}\n\n';assert.equal(textOf(await request(response(raw,null,{slice:1}).value)),answer);
});
for(const status of [400,401,403,404,422,429,500,502])test('HTTP failure remains HTTP failure '+status,async()=>{
 await assert.rejects(request(response('{"error":"SENSITIVE_SENTINEL"}',null,{status}).value),e=>e.code==='RMT_MANUAL_HTTP'&&e.status===status&&!e.message.includes('SENSITIVE'));
});
test('JSON provider error retains original safe classification',async()=>{
 await assert.rejects(request(response('{"error":{"status":401,"message":"SENSITIVE_SENTINEL"}}',null).value),e=>e.status===401&&!e.message.includes('SENSITIVE'));
});
test('excessive Content-Length stops before any body reads',async()=>{
 const r=response(stream(),null,{declared:C.MAX_MANUAL_API_RESPONSE_BYTES+1});await assert.rejects(request(r.value),{code:'RMT_MANUAL_RESPONSE_TOO_LARGE'});assert.equal(r.stats.reads,0);assert.equal(r.stats.cancels,1);
});
test('single oversized incoming chunk cannot bypass total byte limit',async()=>{
 const data=new Uint8Array(C.MAX_MANUAL_API_RESPONSE_BYTES+1);data.fill(32);const r=response(data,null,{slice:data.length});await assert.rejects(request(r.value),{code:'RMT_MANUAL_RESPONSE_TOO_LARGE'});assert.equal(r.value.body.locked,false);
});
test('bounded prefix falls back to normal JSON rather than seeking distant SSE',async()=>{
 const r=response(' '.repeat(10000)+stream(),null,{slice:1});await assert.rejects(request(r.value),{code:'RMT_MANUAL_INVALID_JSON'});assert.ok(r.stats.reads<11000);assert.equal(r.value.body.locked,false);
});
test('valid large JSON is not limited to sniff prefix',async()=>{
 const text='合成内容'.repeat(10000);assert.equal(textOf(await request(response(envelope(text),null,{slice:1024}).value)),text);
});
test('output character budget remains enforced',async()=>{
 await assert.rejects(request(response(stream('字'.repeat(C.MAX_GENERATION_OUTPUT_CHARS+1)),null,{slice:1000}).value),{code:'RMT_MANUAL_RESPONSE_TOO_LARGE'});
});
for(const prefix of ['d','{','data: {"choices":[]}',event(answer)])test('abort cancels sniff/JSON/SSE pending read '+prefix.slice(0,12),async()=>{
 const controller=new AbortController();let pulls=0,cancelled=0,entered;const ready=new Promise(r=>entered=r);
 const body=new ReadableStream({pull(c){if(!pulls++){c.enqueue(new TextEncoder().encode(prefix));return;}entered();return new Promise(()=>{});},cancel(){cancelled++;}},{highWaterMark:0});
 const promise=request(new Response(body),{signal:controller.signal});await ready;controller.abort();await assert.rejects(promise,{name:'AbortError'});assert.equal(cancelled,1);assert.equal(body.locked,false);
});
test('already aborted request does not call transport',async()=>{const c=new AbortController();c.abort();await assert.rejects(request(response(stream(),null).value,{signal:c.signal}),{name:'AbortError'})});
test('timeout abort preserves original safe reason',async()=>{
 const c=new AbortController();let begin;const ready=new Promise(r=>begin=r);const body=new ReadableStream({pull(){begin();return new Promise(()=>{})}});const pending=request(new Response(body),{signal:c.signal});await ready;
 const error=new Error('本地超时');error.code='RMT_REQUEST_TIMEOUT';c.abort(error);await assert.rejects(pending,e=>e===error);assert.equal(body.locked,false);
});
test('network error before parsing cannot leak transport text',async()=>{
 const body=new ReadableStream({pull(c){c.error(new Error('SENSITIVE_SENTINEL'))}});await assert.rejects(request(new Response(body)),e=>e.code==='RMT_MANUAL_INVALID_JSON'&&!e.message.includes('SENSITIVE'));assert.equal(body.locked,false);
});

test('large leading whitespace on ordinary JSON retains the existing bounded JSON behavior',async()=>{assert.equal(textOf(await request(response(' '.repeat(10000)+envelope(),null,{slice:1}).value)),answer)});
