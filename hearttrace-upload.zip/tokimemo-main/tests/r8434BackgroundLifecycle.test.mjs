// r8434: background/lock-screen/app-switch lifecycle.
// - hidden/pagehide triggers an emergency persist of already-received results
//   (deferred-commit queue, pending compressed cache, archive draft journals)
//   without starting, cancelling or retrying any task.
// - Request timeout is judged by the real clock and visible elapsed time: a
//   request that crossed a page freeze is not killed by a parked timer firing
//   on resume; genuine visible overtime still raises RMT_REQUEST_TIMEOUT with
//   retryable=false.
// - A paid segment whose journal save failed (non-capacity) is held in bounded
//   page memory and readable through generationRecoveryHeldReplies, with the
//   established export hint; the RMT_RECOVERY_STORAGE classification is kept.
// - shouldRetrySegmentRequest never auto-retries errors whose paid outcome is
//   unknowable locally (network cut / gateway timeout / unknown transport),
//   while a definitive 429 and local validation failures keep prior semantics.
// Synthetic data only; no user journal, prompt or key.
import test from 'node:test';
import assert from 'node:assert/strict';
import * as coordinator from '../src/core/requestCoordinator.js';
import * as recovery from '../src/generation/recovery.js';
import * as cache from '../src/core/cache.js';
import * as local from '../src/core/localRecoveryStore.js';
import * as importRecovery from '../src/archive/importRecovery.js';
import * as portal from '../src/ui/archivePortal.js';
import { createDurableDeferredCommitMap } from '../src/core/deferredCommitStore.js';
import { state } from '../src/core/state.js';
import { fixture as hostFixture } from './helpers/r847Host.mjs';
import { waitUntil } from './helpers/r8425LocalHost.mjs';

const EXPORT_HINT = '本次新收到的成果已保留在当前页面，可通过恢复区“导出未提交草稿”一并导出。';

function stubVisibilityDocument(t, initial = 'visible') {
    const descriptor = Object.getOwnPropertyDescriptor(globalThis, 'document');
    const listeners = new Map();
    let visibility = initial;
    globalThis.document = {
        getElementById: () => null, querySelector: () => null, querySelectorAll: () => [],
        addEventListener(type, fn) { listeners.set(type, [...(listeners.get(type) || []), fn]); },
        removeEventListener(type, fn) { listeners.set(type, (listeners.get(type) || []).filter(row => row !== fn)); },
        get visibilityState() { return visibility; },
    };
    t.after(() => { if (descriptor) Object.defineProperty(globalThis, 'document', descriptor); else delete globalThis.document; });
    return {
        setVisibility(value) { visibility = value; },
        dispatch(type) { for (const fn of listeners.get(type) || []) fn(); },
        listenerCount(type) { return (listeners.get(type) || []).length; },
    };
}

test('r8434 hidden: emergency persist flushes deferred commits, pending compressed cache and archive drafts', async t => {
    const f = await hostFixture(t);
    const doc = stubVisibilityDocument(t);
    // The host document stub is replaced; keep a body/head so later fixture
    // teardown and rendering helpers stay inert.
    let deferredWrites = 0;
    state.deferredChatCommits = createDurableDeferredCommitMap({ storage: {
        getItem: () => null, setItem: () => { deferredWrites += 1; }, removeItem() {},
    } });
    state.deferredChatCommits.set('bg-character|bg-chat', [{ kind: 'sessions', sessions: {},
        origin: { characterKey: 'bg-character', chatId: 'bg-chat' }, queuedAt: 1 }]);
    assert.equal(deferredWrites, 1, 'queueing persists immediately');
    // Archive draft with real local transaction backend (counted).
    const draftWrites = [];
    local.setLocalRecoveryBackendForTests({
        read: async () => null,
        compare: async (id, revision) => { draftWrites.push(id); return revision + 1; },
    });
    t.after(() => { local.setLocalRecoveryBackendForTests(null); importRecovery.resetArchiveRecoveryMemoryForTests(); });
    const origin = { characterKey: 'bg-character', characterId: '0', characterAvatar: 'time-a.png',
        chatId: 'time-flow-a', archiveRevision: 'time-revision-a' };
    const ticket = await importRecovery.beginArchiveRecovery({ origin,
        sourceIdentity: 'stable', sourceFragments: ['stable source'], settingsIdentity: 'same' });
    importRecovery.releaseArchiveRecovery(ticket);
    await waitUntil(() => draftWrites.length >= 2);
    const draftWritesBeforeHidden = draftWrites.length;
    // Pending compressed cache for the current chat, awaiting its deferred write.
    const scope = cache.cacheScopeFromContext(f.ctx);
    state.pendingCompressedCacheWrites.set(scope, { chatId: f.liveBank.chatId,
        archiveRevision: f.liveBank.archiveRevision, commitToken: Date.now() * 1000 + 7, marker: 'BG_PENDING_CACHE' });

    portal.bindChatStateEvents();
    assert.ok(doc.listenerCount('visibilitychange') >= 1, 'visibilitychange listener is bound');
    doc.setVisibility('visible');
    doc.dispatch('visibilitychange');
    await new Promise(resolve => setTimeout(resolve, 20));
    assert.equal(deferredWrites, 1, 'a visible transition does not persist again');

    doc.setVisibility('hidden');
    doc.dispatch('visibilitychange');
    await waitUntil(() => deferredWrites >= 2 && state.pendingCompressedCacheWrites.size === 0
        && draftWrites.length > draftWritesBeforeHidden);
    assert.ok(draftWrites.length > draftWritesBeforeHidden, 'hidden flushed the archive draft journal');
    assert.equal(state.pendingCompressedCacheWrites.size, 0, 'hidden flushed the pending compressed cache');
    // pagehide takes the same emergency path.
    const writesAfterHidden = deferredWrites;
    await portal.persistPendingResultsForBackground('pagehide');
    assert.equal(deferredWrites, writesAfterHidden + 1, 'pagehide persists the deferred queue again');
    try { globalThis.__heartbeatMemoriesEventCleanup?.(); } catch {}
});

test('r8434 timeout: a request crossing a page freeze is judged by visible elapsed time, not the parked timer', async t => {
    const doc = stubVisibilityDocument(t);
    t.mock.timers.enable({ apis: ['setTimeout', 'Date'] });
    const controller = new AbortController();
    let settled = null;
    const request = coordinator.runGenerationRequestWithTimeout(() => new Promise(() => {}), controller, 30000, 'BG段');
    request.then(() => { settled = 'resolved'; }, error => { settled = error; });
    t.mock.timers.tick(15000); // 15s of normal visible transfer
    assert.equal(settled, null);
    doc.setVisibility('hidden');
    doc.dispatch('visibilitychange');
    t.mock.timers.tick(600000); // frozen/backgrounded far beyond the limit
    assert.equal(settled, null, 'no timeout is declared while hidden');
    assert.equal(controller.signal.aborted, false, 'a healthy in-flight request is not aborted by the freeze');
    doc.setVisibility('visible');
    doc.dispatch('visibilitychange');
    t.mock.timers.tick(14000); // visible elapsed: 29s < 30s
    assert.equal(settled, null, 'hidden time does not count against the limit');
    t.mock.timers.tick(2000); // visible elapsed: 31s
    await assert.rejects(request, error => error?.code === 'RMT_REQUEST_TIMEOUT' && error.retryable === false);
    assert.ok(controller.signal.aborted, 'genuine visible overtime still aborts and frees the task slot');
});

test('r8434 timeout: pure visible overtime still times out at the configured limit', async t => {
    stubVisibilityDocument(t);
    t.mock.timers.enable({ apis: ['setTimeout', 'Date'] });
    const controller = new AbortController();
    let settled = null;
    const request = coordinator.runGenerationRequestWithTimeout(() => new Promise(() => {}), controller, 30000, '');
    request.then(() => { settled = 'resolved'; }, error => { settled = error; });
    t.mock.timers.tick(29999);
    assert.equal(settled, null, 'just under the limit the request is still waiting');
    t.mock.timers.tick(2);
    await assert.rejects(request, error => error?.code === 'RMT_REQUEST_TIMEOUT' && error.retryable === false);
});

test('r8434 timeout: a settled request never re-aborts on later visibility changes', async t => {
    const doc = stubVisibilityDocument(t);
    t.mock.timers.enable({ apis: ['setTimeout', 'Date'] });
    const controller = new AbortController();
    const request = coordinator.runGenerationRequestWithTimeout(async () => 'BG_RESULT', controller, 30000, '');
    assert.equal(await request, 'BG_RESULT');
    doc.setVisibility('hidden');
    doc.dispatch('visibilitychange');
    doc.setVisibility('visible');
    doc.dispatch('visibilitychange');
    t.mock.timers.tick(60000);
    assert.equal(controller.signal.aborted, false, 'no late timeout after the value already arrived');
});

// --- Segment-level "paid but save failed" retention -------------------------

let sequence = 0;
const originFor = suffix => ({ characterKey: `r8434-character-${suffix}`, characterId: '0',
    characterAvatar: 'fixture.png', chatId: `r8434-chat-${suffix}`, archiveRevision: 'r8434-revision' });

async function saveFailingHarness(t, save) {
    const origin = originFor(++sequence);
    const calls = [];
    const handle = await recovery.createGenerationRecovery({ origin, mode: 'achievements',
        settingsIdentity: 'same-settings', save });
    recovery.attachGenerationRecovery(origin, handle);
    t.after(() => { recovery.detachGenerationRecovery(origin); recovery.discardGenerationRecoveryHeldReplies(origin, 'achievements'); });
    return { origin, handle, calls,
        complete(taskKey, value) {
            return recovery.withRecoverySegment('same-prompt', { origin, mode: 'achievements', taskKey, contextEnvelope: 'same-context' },
                raw => raw, async (_prompt, _requestOptions, accepted) => { calls.push(taskKey); await accepted(value); return value; });
        } };
}

test('r8434 segment: a paid reply whose journal save failed (non-capacity) is held and exportable', async t => {
    const h = await saveFailingHarness(t, () => false);
    const reply = { value: 'BG_PAID_REPLY' };
    await assert.rejects(h.complete('bg:save-false', reply),
        error => error?.code === 'RMT_RECOVERY_STORAGE' && error.retryable === false
            && error.message.endsWith(EXPORT_HINT) && error.safeUserMessage.endsWith(EXPORT_HINT),
        'storage classification unchanged, export hint attached');
    const held = recovery.generationRecoveryHeldReplies(h.origin, 'achievements');
    assert.equal(held.length, 1);
    assert.equal(held[0].slot, 'bg:save-false');
    assert.equal(held[0].rawJson, JSON.stringify(reply), 'the paid raw JSON survived in the page hold');
    assert.equal(h.calls.filter(key => key === 'bg:save-false').length, 1, 'no automatic second paid request');
});

test('r8434 segment: a throwing (non-capacity) save also holds the paid reply', async t => {
    const h = await saveFailingHarness(t, () => { throw new Error('synthetic storage outage'); });
    const reply = { value: 'BG_PAID_THROW' };
    await assert.rejects(h.complete('bg:save-throw', reply),
        error => error?.code === 'RMT_RECOVERY_STORAGE' && error.message.endsWith(EXPORT_HINT));
    const held = recovery.generationRecoveryHeldReplies(h.origin, 'achievements');
    assert.deepEqual(held.map(entry => entry.slot), ['bg:save-throw']);
    assert.deepEqual(JSON.parse(held[0].rawJson), reply);
});

test('r8434 segment: a durable save still accepts without any hold', async t => {
    const h = await saveFailingHarness(t, () => true);
    const reply = { value: 'BG_PAID_OK' };
    const value = await h.complete('bg:save-ok', reply);
    assert.deepEqual(value, reply);
    assert.equal(recovery.generationRecoveryHeldReplies(h.origin, 'achievements').length, 0, 'no hold on the healthy path');
});

// --- Never auto-retry an unknowable paid outcome ----------------------------

test('r8434 retry guard: unknown-outcome request errors never auto-retry, opt-in or not', () => {
    for (const code of ['RMT_CONNECTION_FAILED', 'RMT_CONNECTION_NETWORK', 'RMT_CONNECTION_SERVER', 'RMT_REQUEST_TIMEOUT']) {
        assert.equal(coordinator.shouldRetrySegmentRequest({ code, retryable: true }, 0), false, `${code} must never auto-retry`);
        assert.equal(coordinator.shouldRetrySegmentRequest({ code, retryable: true, retryableJson: true }, 0), false, `${code} retryableJson does not help either`);
    }
    // Definitive answers keep their prior semantics: a real 429 may auto-retry
    // once inside the existing budget, a local validation failure may too, and
    // aborts never do.
    assert.equal(coordinator.shouldRetrySegmentRequest({ code: 'RMT_CONNECTION_RATE_LIMIT', retryable: true }, 0), true);
    assert.equal(coordinator.shouldRetrySegmentRequest({ code: 'RMT_CONNECTION_RATE_LIMIT', retryable: true, retryAfterMs: 120000 }, 0), false);
    assert.equal(coordinator.shouldRetrySegmentRequest({ code: 'RMT_SEGMENT_VALIDATION', retryable: true }, 0), true);
    assert.equal(coordinator.shouldRetrySegmentRequest({ name: 'AbortError' }, 0), false);
});

// --- Explicit notice when a deferred result is not confirmed durable --------

test('r8434 deferred notice: non-durable queueing tells the user to export the unsubmitted draft', t => {
    const descriptor = Object.getOwnPropertyDescriptor(globalThis, 'toastr');
    const notices = [];
    globalThis.toastr = { warning: message => notices.push(message) };
    t.after(() => { if (descriptor) Object.defineProperty(globalThis, 'toastr', descriptor); else delete globalThis.toastr; });
    assert.equal(coordinator.notifyDeferredCommitNotDurable(true), false);
    assert.equal(notices.length, 0, 'a confirmed durable write stays quiet');
    assert.equal(coordinator.notifyDeferredCommitNotDurable(false), true);
    assert.equal(notices.length, 1);
    assert.match(notices[0], /保存未确认/);
    assert.match(notices[0], /导出未提交草稿/);
});
