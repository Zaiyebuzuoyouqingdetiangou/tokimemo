import test from 'node:test';
import assert from 'node:assert/strict';
import * as fmt from '../src/core/cgPromptFormat.js';
import * as policy from '../src/generation/cgPromptPolicy.js';
import * as images from '../src/generation/imageGeneration.js';
import * as appearance from '../src/generation/cgAppearance.js';
import * as provider from '../src/generation/baibaiImage.js';
import * as cache from '../src/core/cache.js';
import * as constants from '../src/core/constants.js';
import * as context from '../src/core/context.js';
import * as client from '../src/generation/client.js';
import * as recovery from '../src/generation/recovery.js';
import * as heartView from '../src/ui/heartView.js';
import { state } from '../src/core/state.js';
import { fixture } from './helpers/r847Host.mjs';
const prose = '两位成年人坐在窗边看书，午后的阳光照在书页上。';
const tags = '2people, reading, window, book, sunlight';
const mixed = '两位成年人, reading a book, 窗边, soft light';
const meta = format => ({promptFormat:format, sceneTags:'', flatPrompt:'',characters:[
 {role:'char',name:'林舟',tag:'黑色短发，蓝眼睛',nl:''},
 {role:'user',name:'小月',tag:'silver hair，绿色眼睛',nl:''},
]});
function mockProvider(t, supportsCharacters, custom=null) {
 const old=Object.getOwnPropertyDescriptor(globalThis,'STBaiBaiImage');
 t.after(()=>old?Object.defineProperty(globalThis,'STBaiBaiImage',old):delete globalThis.STBaiBaiImage);
 const calls=[];
 globalThis.STBaiBaiImage={apiVersion:1,capabilities:{generate:true,saveToGallery:true},getBackendStatus:()=>({configured:true,supportsCharacters}),
 async generate(request,options){calls.push(structuredClone(request));return custom?custom(request,options):{path:'/user/images/fixture/r8419.png'}}};
 return calls;
}
async function seedTarget(f,mode){
 const item={id:'visual',title:'窗边读书',date:'2008/05/10',desc:prose,cgDesc:prose,subtitle:prose,imagePrompt:prose,unlocked:true,category:'日常',visualSeed:['窗边'],
 adv:{paragraphs:['我在窗前打开书。','我把这一页递给你。']},panelCount:2,panels:[{caption:'读书',action:'翻开书页'},{caption:'一起读',action:'递给对方书'}]};
 const s={kind:mode,chatId:f.liveBank.chatId,archiveRevision:f.liveBank.archiveRevision,selectedId:'visual',page:1,pageSize:6,category:'全部'};
 if(mode==='album')s.entries=[item];else if(mode==='adv'){s.events=[item];s.view='adv';s.paragraphIndex=0;}
 else Object.assign(s,{view:'strips',selectedStripId:'visual',greetings:{},voiceDramas:[],scenarioDramas:[],dailyStrips:[item],fireflies:[],relationshipSourceMemoryAnchor:prose});
 f.liveCache[mode]=structuredClone(s);f.ctx.chatMetadata[constants.CACHE_KEY]=structuredClone(f.liveCache);
 f.records.get(f.aEntry.entryId).cache=structuredClone(f.liveCache);state.runtimeSessionCache.clear();await cache.ensureCacheHydrated(f.ctx);await f.open(mode);
 return item;
}
const first=(s,mode)=>mode==='album'?s.entries[0]:mode==='adv'?s.events[0]:s.dailyStrips[0];
for(const mode of ['album','adv','heart']) for(const format of fmt.CG_PROMPT_FORMATS) for(const multi of [false,true]) {
 test(`real draw/save/reopen/preview: ${mode} ${format} characters=${multi}`,async t=>{
  const f=await fixture(t);const calls=mockProvider(t,multi);await seedTarget(f,mode);
  const before=await f.persisted();const draft=meta(format), scene=format==='nai45-tags'?prose:tags;
  const expected=images.cgEditorSendPreview(mode,first(state.activeSession,mode),scene,draft,format);
  if(mode==='heart')await heartView.drawHeartStripImage('visual',{promptOverride:scene,promptMetadata:draft,promptFormat:format});
  else await images.drawSelectedCgImage({promptOverride:scene,promptMetadata:draft,promptFormat:format});
  assert.equal(calls.length,1,JSON.stringify(f.notices));assert.equal(f.requests.length,0,'draw must not translate using a model');
  assert.equal(calls[0].prompt,expected.prompt);assert.equal(calls[0].nl,expected.nl);assert.deepEqual(calls[0].characters,expected.characters);
  assert.equal(calls[0].model,undefined);assert.equal(calls[0].save,true);assert.equal(calls[0].character,f.ctx.name2);
  const all=JSON.stringify(calls[0]);assert.match(all,/黑色短发/);assert.match(all,/绿色眼睛/);
  if(format==='nai45-tags')assert.match(all,/窗边看书/);
  if(mode==='heart')assert.match(calls[0].prompt,format==='nai45-tags'?/2koma/:/2 vertically arranged panels/);
  const saved=await f.persisted();assert.equal(first(saved[mode],mode).cgImage.url,'/user/images/fixture/r8419.png');
  assert.deepEqual(saved.cabinet,before.cabinet);assert.deepEqual(saved.phone,before.phone);
  state.runtimeSessionCache.clear();await cache.ensureCacheHydrated(f.ctx);await f.open(mode);
  assert.equal(first(state.activeSession,mode).cgImage.url,'/user/images/fixture/r8419.png');assert.equal(calls.length,1);
 });
}
for(const format of fmt.CG_PROMPT_FORMATS)for(const multi of [false,true])for(const scene of [prose,tags,mixed]){
 test(`public send Chinese/tag/mixed without translation: ${format} ${multi} ${scene.slice(0,12)}`,async t=>{
  const f=await fixture(t);const calls=mockProvider(t,multi);const draft=meta(format);
  const preview=images.cgEditorSendPreview('album',{},scene,draft,format);
  await images.invokeImageGeneration(scene,f.ctx,{promptMetadata:draft});
  assert.equal(calls.length,1);assert.equal(f.requests.length,0);assert.equal(calls[0].prompt,preview.prompt);assert.equal(calls[0].nl,preview.nl);
  assert.deepEqual(calls[0].characters,preview.characters);
  assert.ok(calls[0].prompt.includes(scene),'confirmed scene preserved');
  assert.match(JSON.stringify(calls[0]),/黑色短发/);
 });
}
for(const [mode,taskKey,field]of [['album','t:index','entries'],['album','t:album','entries'],['adv','t:index','events'],['adv','t:event','events'],['heart','t:strip','dailyStrips'],['heart','t:strips','dailyStrips']])for(const format of fmt.CG_PROMPT_FORMATS){
 test(`automatic text segment keeps valid content: ${mode} ${taskKey} ${format}`,async t=>{
  const f=await fixture(t),origin=context.captureTaskOrigin(f.ctx,f.liveBank.archiveRevision);policy.bindCgPromptFormat(origin,format);
  const raw={[field]:[{id:'good',imagePrompt:format==='nai45-tags'?prose:tags},{id:'domain-bad',imagePrompt:'discarded by domain'}]};f.setResponse(raw);
  const result=await client.requestValidatedSegment('UNCHANGED_DOMAIN_PROMPT','test',{context:f.ctx,contextEnvelope:'',origin,mode,taskKey,background:true,maxTokens:3000},x=>({...x,[field]:x[field].filter(row=>row.id==='good')}));
  assert.equal(result[field].length,1);assert.deepEqual(result[field][0],raw[field][0]);assert.equal(f.requests.length,1);
  assert.match(JSON.stringify(f.requests[0]),/UNCHANGED_DOMAIN_PROMPT/);assert.match(JSON.stringify(f.requests[0]),new RegExp('CG_PROMPT_FORMAT_V1 · '+format));
 });
}
for(const format of fmt.CG_PROMPT_FORMATS)test(`reconceive accepts safe model style mismatch as draft: ${format}`,async t=>{
 const f=await fixture(t);mockProvider(t,true);await seedTarget(f,'album');const before=JSON.stringify(await f.persisted());
 const p={imagePrompt:format==='nai45-tags'?prose:tags,sceneTags:mixed,flatPrompt:mixed,characters:[{role:'char',tag:'黑色短发，蓝眼睛',nl:'中文外貌'},{role:'user',tag:'silver hair，绿色眼睛',nl:'mixed'}]};
 f.setResponse(p);const result=await images.reconceiveCgImagePrompt(images.captureCgImageTarget(),{promptFormat:format,appearanceDraft:{char:'黑色短发，蓝眼睛',user:'silver hair，绿色眼睛'}});
 assert.equal(result.imagePrompt,p.imagePrompt);assert.equal(result.characters[0].tag,p.characters[0].tag);assert.equal(result.promptFormat,format);assert.equal(f.requests.length,1);
 assert.equal(JSON.stringify(await f.persisted()),before,'reconceive alone cannot save or draw');
});
for(const format of fmt.CG_PROMPT_FORMATS)test(`domain rejection still rejects, including async: ${format}`,async()=>{
 const origin={};policy.bindCgPromptFormat(origin,format);const error=Object.assign(new Error('domain'),{code:'DOMAIN_EVIDENCE'});
 const sync=()=>{throw error},asyncV=async()=>{throw error};
 assert.equal(policy.cgSegmentValidator(sync,{origin,mode:'album',taskKey:'t:index'}),sync);assert.throws(()=>sync({}),e=>e===error);
 await assert.rejects(policy.cgSegmentValidator(asyncV,{origin,mode:'adv',taskKey:'t:event'})({}),e=>e===error);
});
test('empty scene and comic total budget still reject without sending',async t=>{
 const f=await fixture(t);const calls=mockProvider(t,false);
 for(const format of fmt.CG_PROMPT_FORMATS){assert.throws(()=>images.cgEditorSendPreview('album',{},'',meta(format),format),{code:'RMT_CG_PROMPT_INVALID'});
  assert.throws(()=>fmt.formatDailyComicPrompt({panelCount:4},'x'.repeat(1800),format),{code:'RMT_CG_PROMPT_INVALID'});}
 await assert.rejects(images.invokeImageGeneration('',f.ctx,{promptMetadata:meta('nai45-tags')}));assert.equal(calls.length,0);
});
test('malformed reconceived structure and unsupported identity remain rejected',()=>{
 assert.throws(()=>appearance.normalizeCgPreparedPrompt({imagePrompt:prose,sceneTags:[],flatPrompt:prose,characters:[]},{}),{code:'RMT_CG_PROMPT_INVALID'});
 const expected={characters:[{role:'char',name:'林舟',knownTag:'black hair',description:''}]};
 assert.throws(()=>appearance.normalizeCgPreparedPrompt({imagePrompt:prose,sceneTags:tags,flatPrompt:prose,characters:[{role:'char',tag:'silver hair'}]},expected),{code:'RMT_CG_PROMPT_INVALID'});
});
test('cancel before confirm makes zero image/text calls and preserves saved content',async t=>{
 const f=await fixture(t);const calls=mockProvider(t,false);await seedTarget(f,'album');const before=await f.persisted();globalThis.confirm=()=>false;
 await images.drawSelectedCgImage({promptOverride:mixed,promptMetadata:meta('nai45-tags'),promptFormat:'nai45-tags'});
 assert.equal(calls.length,0);assert.equal(f.requests.length,0);assert.deepEqual(await f.persisted(),before);
});
test('late response after a newer item edit never overwrites original saved image',async t=>{
 const f=await fixture(t);let entered,release;const ready=new Promise(r=>entered=r),wait=new Promise(r=>release=r);
 const calls=mockProvider(t,false,async()=>{entered();await wait;return{path:'/user/images/fixture/late.png'}});await seedTarget(f,'adv');
 const target=images.captureCgImageTarget();const drawing=images.drawSelectedCgImage({promptOverride:mixed,promptMetadata:meta('nai45-tags'),promptFormat:'nai45-tags',expectedTarget:target});await ready;
 first(target.session,'adv').cgDesc='更新后的正文';release();await drawing;
 assert.equal(calls.length,1);assert.equal(first((await f.persisted()).adv,'adv').cgImage,undefined);assert.equal(state.activeCgImageTasks.size,0);
});
test('public provider errors are sanitized and never retried',async t=>{
 const f=await fixture(t);const calls=mockProvider(t,false,async()=>{throw Object.assign(new Error('PRIVATE_PROVIDER_ERROR_BODY'),{code:'backend_error'})});
 await assert.rejects(images.invokeImageGeneration(mixed,f.ctx,{promptMetadata:meta('nai45-tags')}),e=>e.code==='BBI_BACKEND_ERROR'&&!e.message.includes('PRIVATE_PROVIDER_ERROR_BODY'));
 assert.equal(calls.length,1);assert.equal(provider.baiBaiImagePendingCount(),0);
});
