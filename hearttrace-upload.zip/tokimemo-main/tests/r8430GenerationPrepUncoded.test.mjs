// r8430: generation preparation failures must surface actionable codes, never the
// RMT_UNCODED fallback, and must never delete or silently overwrite durable records.
// Covers: corrupt canonical cache (with/without mirror, host without
// DecompressionStream), pre-CAS takeover, >12MB derived cache eviction/capacity,
// host metadata mirror sync failure, non-cloneable card fields, and trace codes.
import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './helpers/r847Host.mjs';
import * as C from '../src/core/constants.js';
import * as cache from '../src/core/cache.js';
import * as client from '../src/generation/client.js';
import * as trace from '../src/core/taskTrace.js';
import { state } from '../src/core/state.js';

const CORRUPT_CACHE = () => ({ format: C.CACHE_STORAGE_FORMAT, storageVersion: C.CACHE_STORAGE_VERSION,
    data: 'QUJDREVGRw', sourceBytes: 8 }); // valid base64, invalid gzip payload

const inboxResponse = () => ({ letters: [{ slot: 'daily', title: '今日来信', greeting: '小月',
    body: '今天天气很好，我把窗台收拾干净了。周末想请你来喝茶，不知道你有没有空。',
    closing: '林舟' }] });

function corruptCanonicalRecord(f) {
    const record = f.records.get(f.aEntry.entryId);
    record.cache = CORRUPT_CACHE();
    f.records.set(f.aEntry.entryId, record);
}

function traceRow(mode) {
    return trace.taskTraceSnapshot().find(row => row.mode === mode) || null;
}

function inboxFixtureCache(f, extra = {}) {
    return { chatId: f.liveBank.chatId, archiveRevision: f.liveBank.archiveRevision, ...extra };
}

test('F1: corrupt canonical compressed cache commits from the live mirror; archive data untouched', async t => {
    const f = await fixture(t);
    trace.clearTaskTrace();
    f.setResponse(inboxResponse());
    corruptCanonicalRecord(f);
    const result = await client.generateMode('inbox', { background: true });
    assert.ok(result, 'generation must go through with a usable mirror');
    assert.equal(f.requests.length, 1, 'exactly one provider request');
    const row = traceRow('inbox');
    assert.equal(row?.outcome, 'ok');
    assert.equal(row?.providerRequests, 1);
    assert.equal(row?.code, '');
    assert.ok(f.diagnostics.some(args => String(args[0]).includes('canonical cache record unreadable')),
        'the mirror fallback is warned, never silent');
    const record = f.records.get(f.aEntry.entryId);
    assert.ok(record, 'the damaged record is never deleted');
    assert.deepEqual(record.memory, f.liveBank, 'original archive data is not modified');
    const persisted = await f.persisted();
    assert.equal(persisted.inbox?.kind, 'inbox', 'new session committed through the acknowledged CAS write');
    assert.deepEqual(persisted.phone, f.liveCache.phone, 'mirror sessions survive the commit');
    assert.deepEqual(persisted.cabinet, f.liveCache.cabinet, 'unrelated mode sessions survive the commit');
});

test('F1: corrupt canonical cache without a usable mirror fails coded and leaves the record untouched', async t => {
    const f = await fixture(t);
    trace.clearTaskTrace();
    f.setResponse(inboxResponse());
    corruptCanonicalRecord(f);
    // The metadata mirror is an unreadable compressed record too: getCache yields {},
    // which proves nothing and must not seed a commit.
    f.ctx.chatMetadata[C.CACHE_KEY] = CORRUPT_CACHE();
    state.runtimeSessionCache.clear();
    const before = JSON.stringify(f.records.get(f.aEntry.entryId));
    const result = await client.generateMode('inbox', { background: true });
    assert.equal(result, null);
    assert.equal(f.requests.length, 0, 'no provider request is sent');
    const row = traceRow('inbox');
    assert.equal(row?.outcome, 'failed');
    assert.equal(row?.code, 'RMT_CACHE_BACKUP_CORRUPT');
    assert.equal(row?.providerRequests, 0);
    assert.equal(JSON.stringify(f.records.get(f.aEntry.entryId)), before,
        'the damaged record is neither deleted nor overwritten');
    assert.ok(f.notices.some(n => n.kind === 'error' && String(n.message).includes('本机缓存记录损坏')),
        'the user gets the fixed actionable message');
});

test('F1b: host without DecompressionStream commits from the live mirror', async t => {
    const f = await fixture(t);
    trace.clearTaskTrace();
    f.setResponse(inboxResponse());
    // A readable but compressed canonical record on an old WebView: hydrate fails
    // exactly like corruption, and the same mirror fallback applies.
    const record = f.records.get(f.aEntry.entryId);
    record.cache = await cache.prepareCacheBackupValue(inboxFixtureCache(f, { phone: f.liveCache.phone }));
    f.records.set(f.aEntry.entryId, record);
    const realDS = globalThis.DecompressionStream;
    const realCS = globalThis.CompressionStream;
    // Old WebViews lack the pair together; new commits then stay raw, matching the
    // production fallback in prepareCacheBackupValue.
    globalThis.DecompressionStream = undefined;
    globalThis.CompressionStream = undefined;
    let result = null, thrown = null;
    try { result = await client.generateMode('inbox', { background: true }); }
    catch (error) { thrown = error; }
    finally { globalThis.DecompressionStream = realDS; globalThis.CompressionStream = realCS; }
    assert.equal(thrown, null);
    assert.ok(result, 'generation must go through on the mirror');
    assert.equal(f.requests.length, 1);
    assert.equal(traceRow('inbox')?.outcome, 'ok');
    assert.ok(f.records.get(f.aEntry.entryId), 'record is not deleted');
    assert.deepEqual(f.records.get(f.aEntry.entryId).memory, f.liveBank);
    const persisted = await f.persisted();
    assert.equal(persisted.inbox?.kind, 'inbox');
    assert.deepEqual(persisted.phone, f.liveCache.phone);
});

test('F2: archive taken over before the claim fails coded, with no request and no writes', async t => {
    const f = await fixture(t);
    trace.clearTaskTrace();
    f.setResponse(inboxResponse());
    // The claim hydrates the compressed metadata mirror; a newer task moves the
    // archive revision during that pre-CAS await, before the first CAS read.
    f.ctx.chatMetadata[C.CACHE_KEY] = await cache.prepareCacheBackupValue(inboxFixtureCache(f, { phone: f.liveCache.phone }));
    state.runtimeSessionCache.clear();
    const realDS = globalThis.DecompressionStream;
    let flipped = false;
    globalThis.DecompressionStream = class extends realDS {
        constructor(format) {
            if (!flipped) { flipped = true; f.ctx.chatMetadata[C.MEMORY_KEY].archiveRevision = 'time-revision-a-TAKEN-OVER'; }
            super(format);
        }
    };
    const before = JSON.stringify(f.records.get(f.aEntry.entryId));
    let result = null, thrown = null;
    try { result = await client.generateMode('inbox', { background: true }); }
    catch (error) { thrown = error; }
    finally { globalThis.DecompressionStream = realDS; }
    assert.equal(thrown, null, 'generateMode absorbs the blocked claim');
    assert.equal(result, null);
    assert.equal(flipped, true);
    assert.equal(f.requests.length, 0, 'no provider request is sent');
    const row = traceRow('inbox');
    assert.equal(row?.outcome, 'failed');
    assert.equal(row?.code, 'RMT_CACHE_CAS_CONFLICT');
    assert.notEqual(row?.code, 'RMT_UNCODED');
    assert.equal(row?.providerRequests, 0);
    assert.equal(JSON.stringify(f.records.get(f.aEntry.entryId)), before, 'a blocked claim writes nothing');
});

test('F3: terminal draft journal payloads are evicted to fit the 12MB bound, then the commit succeeds', async t => {
    const f = await fixture(t);
    trace.clearTaskTrace();
    f.setResponse(inboxResponse());
    // Canonical carries a terminal draft record still holding an 8MB journal payload
    // (redundant per the retention stub rules); the mirror adds a 4.6MB session.
    const terminalJournal = { identity: { mode: 'inbox', chatId: f.liveBank.chatId, archiveRevision: f.liveBank.archiveRevision },
        pageId: 'inbox', pad: 'x'.repeat(8000000) };
    const canonicalCache = inboxFixtureCache(f, {
        phone: f.liveCache.phone,
        [cache.GENERATION_DRAFTS_CACHE_KEY]: { version: 1, records: {
            'old-draft': { status: 'complete', mode: 'inbox', pageId: 'inbox', closedAt: 1, journal: terminalJournal } } },
    });
    const record = f.records.get(f.aEntry.entryId);
    record.cache = await cache.prepareCacheBackupValue(canonicalCache);
    f.records.set(f.aEntry.entryId, record);
    f.ctx.chatMetadata[C.CACHE_KEY] = inboxFixtureCache(f, {
        cabinet: { kind: 'cabinet', chatId: f.liveBank.chatId, archiveRevision: f.liveBank.archiveRevision,
            items: [{ id: 'old-item', text: `pad${'y'.repeat(4600000)}` }] },
    });
    state.runtimeSessionCache.clear();
    const result = await client.generateMode('inbox', { background: true });
    assert.ok(result, 'evicting the redundant terminal journal payload lets the commit through');
    assert.equal(f.requests.length, 1);
    assert.equal(traceRow('inbox')?.outcome, 'ok');
    const persisted = await f.persisted();
    assert.equal(persisted.inbox?.kind, 'inbox');
    const stub = persisted[cache.GENERATION_DRAFTS_CACHE_KEY]?.records?.['old-draft'];
    assert.ok(stub, 'the terminal draft record itself is kept');
    assert.equal(stub.status, 'complete');
    assert.equal(stub.journal, undefined, 'only the redundant journal payload is evicted');
    assert.equal(stub.mode, 'inbox');
    assert.ok(persisted.cabinet?.items?.[0]?.text?.startsWith('pad'), 'mirror session content survives');
});

test('F3: still over 12MB after eviction fails with the capacity code and writes nothing', async t => {
    const f = await fixture(t);
    trace.clearTaskTrace();
    f.setResponse(inboxResponse());
    // A non-evictable live session payload in a mode the canonical record does not
    // hold pushes the merged cache past the bound.
    f.ctx.chatMetadata[C.CACHE_KEY] = inboxFixtureCache(f, {
        room: { kind: 'room', chatId: f.liveBank.chatId, archiveRevision: f.liveBank.archiveRevision,
            pad: 'z'.repeat(13000000) },
    });
    state.runtimeSessionCache.clear();
    const before = JSON.stringify(f.records.get(f.aEntry.entryId));
    const result = await client.generateMode('inbox', { background: true });
    assert.equal(result, null);
    assert.equal(f.requests.length, 0, 'no provider request is sent');
    const row = traceRow('inbox');
    assert.equal(row?.outcome, 'failed');
    assert.equal(row?.code, 'RMT_ARCHIVE_RESULT_CAPACITY');
    assert.equal(row?.providerRequests, 0);
    assert.equal(JSON.stringify(f.records.get(f.aEntry.entryId)), before,
        'the previous valid cache is preserved, nothing is truncated to fit');
});

test('F4: a throwing host metadata scheduler does not block or roll back the canonical claim', async t => {
    const f = await fixture(t);
    trace.clearTaskTrace();
    f.setResponse(inboxResponse());
    f.ctx.saveMetadataDebounced = () => { throw new Error('host save exploded'); };
    const result = await client.generateMode('inbox', { background: true });
    // The user-visible failure shape was a sub-second, zero-request claim failure.
    // With the mirror failure absorbed at the claim, generation runs to completion
    // and the paid session lands in the existing deferred-commit lane instead of
    // being lost to a mirror scheduling error.
    assert.ok(result, 'the claim is not blocked by the mirror failure');
    assert.equal(f.requests.length, 1, 'generation proceeds past the claim');
    const row = traceRow('inbox');
    assert.equal(row?.outcome, 'deferred', 'the result save defers through the existing mechanism');
    assert.equal(row?.providerRequests, 1);
    assert.ok(f.diagnostics.some(args => String(args[0]).includes('claim metadata mirror scheduling failed')),
        'the mirror failure is warned, not silently swallowed');
    const record = f.records.get(f.aEntry.entryId);
    assert.ok(record, 'the canonical record is not deleted');
    assert.deepEqual(record.memory, f.liveBank, 'original archive data is not modified');
    const persisted = await f.persisted();
    assert.ok(persisted[C.MODE_WRITE_FENCES_CACHE_KEY]?.inbox,
        'the canonical claim (advanced mode fence) is kept, not rolled back');
});

test('F5: a non-cloneable card field degrades to a JSON-safe copy and generation continues', async t => {
    const f = await fixture(t);
    trace.clearTaskTrace();
    f.setResponse(inboxResponse());
    f.ctx.characters[0].data.description = { text: 'CARD_A_ONLY', fn() { return 1; } };
    const result = await client.generateMode('inbox', { background: true });
    assert.ok(result, 'one degraded field must not block generation');
    assert.equal(f.requests.length, 1);
    assert.equal(traceRow('inbox')?.outcome, 'ok');
    // Read the durable record directly: the host card edit above legitimately
    // refreshes the stored identity fingerprint, so the fixture's strict
    // old-identity reader is not the right probe here.
    const record = f.records.get(f.aEntry.entryId);
    assert.ok(record, 'durable record still exists');
    const persisted = cache.isCompressedCacheRecord(record.cache) ? await cache.gunzipJson(record.cache.data) : record.cache;
    assert.equal(persisted.inbox?.kind, 'inbox');
});

test('F5: a field no copy strategy can capture fails coded before any request', async t => {
    const f = await fixture(t);
    trace.clearTaskTrace();
    f.setResponse(inboxResponse());
    // structuredClone rejects the function; JSON.stringify rejects the cycle.
    const card = f.ctx.characters[0];
    card.data.description = { fn() { return 1; } };
    card.data.description.self = card.data.description;
    const result = await client.generateMode('inbox', { background: true });
    assert.equal(result, null);
    assert.equal(f.requests.length, 0, 'no provider request is sent');
    const row = traceRow('inbox');
    assert.equal(row?.outcome, 'failed');
    assert.equal(row?.code, 'RMT_RECOVERY_SOURCE_SNAPSHOT_MISSING');
    assert.equal(row?.providerRequests, 0);
});

test('F6: real recovery/prep codes are no longer mislabeled RMT_UNCODED', () => {
    for (const code of ['RMT_RECOVERY_SOURCE_SNAPSHOT_MISSING', 'RMT_RECOVERY_PROGRESS_STORAGE',
        'RMT_TOKEN_COUNT_UNAVAILABLE', 'RMT_RECOVERY_FAILED', 'RMT_CACHE_BACKUP_CORRUPT']) {
        trace.clearTaskTrace();
        const entry = trace.startTaskTrace('synthetic', 'inbox');
        trace.endTaskTrace(entry, 'failed', Object.assign(new Error('synthetic'), { code }));
        const row = trace.taskTraceSnapshot()[0];
        assert.equal(row.code, code, `${code} must survive the trace whitelist`);
        assert.notEqual(row.code, 'RMT_UNCODED');
    }
    trace.clearTaskTrace();
});
