import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
const root=new URL('../',import.meta.url), read=p=>fs.readFileSync(new URL(p,root),'utf8');
const hashes=JSON.parse(read('tests/helpers/r8420-baseline-hashes.json'));
const sha=value=>createHash('sha256').update(value).digest('hex');
for(const dir of ['src/archive/','src/core/','src/generation/','src/modes/','src/ui/'])test(`r84.20 source scope: unchanged r84.19 bytes outside approved files ${dir}`,()=>{
 for(const [p,expected]of Object.entries(hashes).filter(([p])=>p.startsWith(dir)))assert.equal(sha(read(p)),expected,p);
});
test('existing editor, restoration, manual appearance and final-send code files stay exact',()=>{
 for(const p of ['src/ui/cgPromptEditor.js','src/core/cgPromptFormat.js','src/generation/baibaiImage.js','src/core/requestCoordinator.js','src/core/cache.js','src/generation/client.js','src/generation/recovery.js'])assert.equal(sha(read(p)),hashes[p],p);
});
test('shared authoring utility is pure and does not initiate IO, writes, timers or requests',()=>{
 assert.doesNotMatch(read('src/core/cgVisualRules.js'),/\b(?:fetch|requestJson|requestValidatedSegment|setTimeout|setInterval|localStorage|indexedDB|saveSession|saveChat|eval|Function)\s*[.(]/u);
});
test('send path and validation retain r84.19 language preference semantics',()=>{
 for(const p of ['src/generation/cgAppearance.js','src/generation/cgPromptPolicy.js','src/generation/imageGeneration.js','src/generation/baibaiImage.js','src/ui/cgPromptEditor.js'])assert.doesNotMatch(read(p),/(?:format|cg_format)\.(?:assertEnglishTagPrompt|assertNaturalScenePrompt)\s*\(/u,p);
 assert.match(read('src/generation/cgPromptPolicy.js'),/return validator;/);
});
test('light bootstrap never imports optional metadata policy directly or scans data',()=>{
 assert.doesNotMatch(read('index.js'),/cgVisualRules|cgPromptDraft|CG_VISUAL_AUTHORING_V2/);
});
test('new draft persistence is optional for each existing image domain',()=>{
 for(const p of ['src/modes/album.js','src/modes/advEvent.js','src/modes/heart.js'])assert.equal((read(p).match(/\.\.\.cg_visual\.generatedCgDraftFields\(item\)/g)||[]).length,2,p);
});
test('r84.20 manifest, bootstrap and cache identity agree',()=>{
 const m=JSON.parse(read('manifest.json'));assert.equal(m.version,'0.8.96');
 const build='0.8.96-tt-cg-r84.20-visual-authoring';assert.ok(m.js.includes(build));assert.ok(read('index.js').includes(`const BUILD = '${build}'`));
});
