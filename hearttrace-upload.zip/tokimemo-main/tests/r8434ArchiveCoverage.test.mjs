import test from 'node:test';
import assert from 'node:assert/strict';
import { archiveFixture, sourceRows, memoryReply, clickImport, clone } from './helpers/r8422ArchiveHost.mjs';
import { fixture } from './helpers/r847Host.mjs';
import * as R from '../src/archive/repository.js';
import * as B from '../src/archive/importBatches.js';
import * as V from '../src/archive/coverageRanges.js';
import * as settings from '../src/core/settings.js';
import * as client from '../src/generation/client.js';
import * as generation_recovery from '../src/generation/recovery.js';
import * as context from '../src/core/context.js';

// Synthetic bookkeeping only. No user text, API credentials or external calls.
const pushFloors = (f, count, length = 300) => {
    const base = f.ctx.chat.length;
    for (let i = 1; i <= count; i += 1) f.ctx.chat.push({
        is_user: (base + i) % 2 === 0, name: (base + i) % 2 === 0 ? f.ctx.name1 : f.ctx.name2,
        mes: `共同记录${String(base + i).padStart(3, '0')}。` + '春'.repeat(length),
    });
};

test('coveredRanges merge: append, overlap and adjacency collapse into one interval', () => {
    const once = V.mergeCoveredRanges([
        { start: 1, end: 100, revision: 'r1', kind: 'full' },
        { start: 150, end: 200, revision: 'r2', kind: 'backfill' }]);
    assert.deepEqual(once, [{ start: 1, end: 100, revision: 'r1', kind: 'full' }, { start: 150, end: 200, revision: 'r2', kind: 'backfill' }]);
    const merged = V.mergeCoveredRanges([...once, { start: 101, end: 149, revision: 'r3', kind: 'backfill' }]);
    assert.deepEqual(merged, [{ start: 1, end: 200, revision: 'r2', kind: 'full' }], 'adjacent intervals merge; wider span keeps its kind, the last end extension wins revision');
    const overlap = V.mergeCoveredRanges([{ start: 1, end: 50, revision: 'a', kind: 'incremental' }, { start: 40, end: 80, revision: 'b', kind: 'incremental' }]);
    assert.deepEqual(overlap, [{ start: 1, end: 80, revision: 'b', kind: 'incremental' }]);
    assert.deepEqual(V.normalizeCoveredRanges([{ start: 0, end: 3 }, { start: 9, end: 4 }, null, { start: 2, end: 2, kind: 'unknown' }]),
        [{ start: 2, end: 2, revision: '', kind: 'full' }], 'invalid rows are dropped, unknown kinds fall back safely');
});

test('legacy archives without the field derive one interval only from a proven full window', () => {
    assert.deepEqual(V.bankCoveredRanges(null), []);
    assert.deepEqual(V.bankCoveredRanges({ sourceMessageCount: 120 }), [], 'count alone never fabricates coverage');
    assert.deepEqual(V.bankCoveredRanges({ sourceMessageCount: 120, coverageMode: 'evenly-sampled-full-window' }), [], 'sampled windows have unknown gaps');
    assert.deepEqual(V.bankCoveredRanges({ sourceMessageCount: 120, coverageMode: 'full-window', truncated: true }), []);
    assert.deepEqual(V.bankCoveredRanges({ sourceMessageCount: 120, coverageMode: 'full-window', archiveRevision: 'rev-old' }),
        [{ start: 1, end: 120, revision: 'rev-old', kind: 'full' }]);
    assert.deepEqual(V.bankCoveredRanges({ sourceMessageCount: 5, coveredRanges: [{ start: 3, end: 4, revision: 'x', kind: 'backfill' }] }),
        [{ start: 3, end: 4, revision: 'x', kind: 'backfill' }], 'a stored ledger wins over any derivation');
});

test('range-mode gaps and the next suggested segment come from selection minus coverage', () => {
    const covered = [{ start: 1, end: 100, revision: 'r', kind: 'full' }];
    assert.deepEqual(V.rangeGaps(covered, 1, 150), [{ start: 101, end: 150 }]);
    assert.deepEqual(V.rangeGaps(covered, 50, 100), []);
    assert.deepEqual(V.rangeGaps(covered, 1, 0), []);
    const summary = V.archiveCoverageSummary({ coveredRanges: covered, sourceMessageCount: 260 }, { start: 1, end: 260 });
    assert.deepEqual(summary.gaps, [{ start: 101, end: 260 }]);
    assert.deepEqual(summary.suggested, { start: 101, end: 260 }, 'suggestion stays inside the selected gap');
    const chunked = V.archiveCoverageSummary({ coveredRanges: [], sourceMessageCount: 500 }, { start: 1, end: 500 });
    assert.deepEqual(chunked.suggested, { start: 1, end: 500 });
    assert.equal(V.suggestNextRange([], 1, 500, 100).end, 100, 'explicit chunk size caps the suggestion');
    const text = V.archiveCoverageText({ coveredRanges: covered, sourceMessageCount: 260 });
    assert.match(text, /第 1–100 楼（全量整理）/);
    assert.match(text, /缺口 第 101–260 楼/);
    assert.equal(V.archiveCoverageText({ sourceMessageCount: 260 }), '', 'nothing recorded, nothing displayed');
});

test('operationKind labels distinguish backfill, incremental and full runs', () => {
    assert.equal(V.archiveOperationKind({ existing: null, fullRebuild: false, rangeChanged: false }), 'full');
    assert.equal(V.archiveOperationKind({ existing: {}, fullRebuild: true, rangeChanged: false }), 'full');
    assert.equal(V.archiveOperationKind({ existing: {}, fullRebuild: false, rangeChanged: true }), 'backfill');
    assert.equal(V.archiveOperationKind({ existing: {}, fullRebuild: false, rangeChanged: false }), 'incremental');
    assert.equal(V.OPERATION_KIND_LABEL.backfill, '补录历史');
    assert.equal(V.OPERATION_KIND_LABEL.incremental, '增量更新');
});

test('a pending batch plan never claims its unread tail; completed batches keep their floors', () => {
    const progress = (nextBatch) => ({ nextBatch, batches: [
        [{ refs: [{ kind: 'chat', index: 1 }, { kind: 'chat', index: 2 }] }],
        [{ refs: [{ kind: 'chat', index: 3 }, { kind: 'external', externalId: 'x' }] }]] });
    const window = { start: 1, end: 3 };
    assert.deepEqual(V.coveredRangesForSave(null, { window, kind: 'backfill', revision: 'r1', progress: progress(0) }), [],
        'an interrupted first batch adds nothing and loses nothing');
    assert.deepEqual(V.coveredRangesForSave(null, { window, kind: 'backfill', revision: 'r1', progress: progress(1) }),
        [{ start: 1, end: 2, revision: 'r1', kind: 'backfill' }], 'only the durably saved batch counts');
    const resumed = V.coveredRangesForSave({ coveredRanges: [{ start: 1, end: 2, revision: 'r1', kind: 'backfill' }] },
        { window, kind: 'backfill', revision: 'r2', progress: progress(2) });
    assert.deepEqual(resumed, [{ start: 1, end: 3, revision: 'r2', kind: 'backfill' }], 'resuming extends the kept interval');
    assert.deepEqual(V.coveredRangesForSave(null, { window, kind: 'full', revision: 'r', progress: null }),
        [{ start: 1, end: 3, revision: 'r', kind: 'full' }], 'a single-shot run covers its whole window');
});

test('backfill runs record real floor intervals and merge across tasks', async t => {
    const f = await archiveFixture(t);
    pushFloors(f, 5); // floors 1..6
    settings.updatePluginSettings({ chatReadRange: { mode: 'range', start: 1, end: 3 } });
    await clickImport(f);
    let bank = R.getImportedMemory(f.ctx);
    assert.deepEqual(bank.coveredRanges, [{ start: 1, end: 3, revision: bank.archiveRevision, kind: 'backfill' }], JSON.stringify(f.notices));
    assert.ok(f.notices.some(row => row.kind === 'success' && row.message.includes('补录历史')), JSON.stringify(f.notices));
    settings.updatePluginSettings({ chatReadRange: { mode: 'range', start: 4, end: 6 } });
    await clickImport(f);
    bank = R.getImportedMemory(f.ctx);
    assert.deepEqual(bank.coveredRanges, [{ start: 1, end: 6, revision: bank.archiveRevision, kind: 'backfill' }], 'adjacent backfill merges with the kept interval');
    const summary = V.archiveCoverageSummary(bank, { start: 1, end: 6 });
    assert.deepEqual(summary.gaps, []);
    assert.equal(summary.suggested, null);
});

test('incremental appends extend coverage without relabeling old intervals or fabricating floor 1', async t => {
    const f = await archiveFixture(t); // legacy bank: no coveredRanges, coverageMode unset
    pushFloors(f, 2); // floors 1..3, archived baseline is floor 1
    await clickImport(f);
    let bank = R.getImportedMemory(f.ctx);
    assert.deepEqual(bank.coveredRanges, [{ start: 2, end: 3, revision: bank.archiveRevision, kind: 'incremental' }],
        'only floors actually read this run are recorded; nothing is backdated');
    assert.ok(f.notices.some(row => row.kind === 'success' && row.message.includes('增量更新')), JSON.stringify(f.notices));
    pushFloors(f, 2); // floors 4..5
    await clickImport(f);
    bank = R.getImportedMemory(f.ctx);
    assert.deepEqual(bank.coveredRanges, [{ start: 2, end: 5, revision: bank.archiveRevision, kind: 'incremental' }]);
    const summary = V.archiveCoverageSummary(bank, { start: 1, end: 5 });
    assert.deepEqual(summary.gaps, [{ start: 1, end: 1 }], 'the pre-existing baseline floor shows up as an honest gap');
    assert.deepEqual(summary.suggested, { start: 1, end: 1 });
});

test('derived content snapshots omit the coverage ledger like other import bookkeeping', async t => {
    const f = await fixture(t);
    f.liveBank.coveredRanges = [{ start: 1, end: 5, revision: 'rev-a', kind: 'full' }];
    const origin = context.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision);
    const handle = await client.beginModeRecovery('album', f.ctx, f.liveBank, origin);
    const snapshot = generation_recovery.readGenerationContentSnapshot(handle.journal);
    assert.equal(snapshot.memoryBank.coveredRanges, undefined, 'the derived snapshot never carries import coverage bookkeeping');
    assert.deepEqual(f.liveBank.coveredRanges, [{ start: 1, end: 5, revision: 'rev-a', kind: 'full' }], 'the canonical bank keeps its ledger');
    generation_recovery.detachGenerationRecovery(origin);
});

test('a failed later batch neither rolls back nor loses already saved coverage', async t => {
    const f = await archiveFixture(t, { rows: sourceRows(620, 220) });
    pushFloors(f, 4); // floors 1..5
    settings.updatePluginSettings({ chatReadRange: { mode: 'range', start: 1, end: 5 } });
    await clickImport(f);
    let bank = R.getImportedMemory(f.ctx);
    assert.equal(bank[B.IMPORT_PROGRESS_KEY].nextBatch, 1, JSON.stringify(f.notices));
    assert.deepEqual(bank.coveredRanges, [{ start: 1, end: 5, revision: bank.archiveRevision, kind: 'backfill' }],
        'chat floors of the saved batch are covered even while external batches wait');
    const kept = clone(bank.coveredRanges);
    f.setResponse(() => { throw Object.assign(new Error('synthetic interruption'), { code: 'RMT_JSON_INVALID' }); });
    await clickImport(f);
    bank = R.getImportedMemory(f.ctx);
    assert.equal(bank[B.IMPORT_PROGRESS_KEY].nextBatch, 1, 'a failed batch never advances the checkpoint');
    assert.deepEqual(bank.coveredRanges, kept, 'interruption keeps the recorded intervals');
    f.setResponse(messages => memoryReply(messages));
    await clickImport(f);
    await clickImport(f);
    bank = R.getImportedMemory(f.ctx);
    assert.equal(B.hasPendingBatches(bank[B.IMPORT_PROGRESS_KEY]), false, JSON.stringify(f.notices));
    assert.deepEqual(bank.coveredRanges, kept, 'resuming unfinished external batches does not rewrite chat coverage');
});
