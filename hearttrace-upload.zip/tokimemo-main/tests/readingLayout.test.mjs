import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './helpers/r847Host.mjs';
import { state } from '../src/core/state.js';
import { renderSharedMemory } from '../src/ui/albumView.js';
import { workspace } from '../src/ui/workspaceState.js';
import { workspaceCatalogueHtml } from '../src/ui/workspace.js';

for (const [count,index,prevDisabled,nextDisabled] of [[0,0,true,true],[1,0,true,true],[3,0,true,false],[3,1,false,false],[3,2,false,true]]) {
    test(`dialogue navigation ${index}/${count} retains exactly previous and next`, async t => {
        const f=await fixture(t);
        state.activeSession={kind:'album',entries:[{id:'cg',title:'雨夜',date:'待定',desc:'屋檐下',unlocked:true,comments:Array.from({length:count},(_,i)=>`第${i}句`)}],selectedId:'cg',sharedMemory:true,dialogueIndex:index};
        state.activeArchiveSnapshot=null;state.activeArchiveReadOnly=false;
        renderSharedMemory();
        const html=f.body.innerHTML;
        const actions=html.match(/<div class="rmt-dialogue-actions">([\s\S]*?)<\/div>/)[1];
        assert.equal((actions.match(/<button/g)||[]).length,2);
        assert.match(actions,/shared-prev[\s\S]*上一句[\s\S]*shared-next[\s\S]*下一句/);
        assert.equal(/shared-prev"\s+disabled/.test(actions),prevDisabled);
        assert.equal(/shared-next"\s+disabled/.test(actions),nextDisabled);
        assert.doesNotMatch(actions,/返回相簿|重看/);
        assert.equal(f.requests.length,0);
    });
}
test('calendar has one normal life module entry and no other group entry',async t=>{
    await fixture(t);
    for(const group of ['memory','life','interaction','stories']){
        workspace.group=group;
        const html=workspaceCatalogueHtml();
        assert.equal((html.match(/data-rmt-workspace-route="calendar"/g)||[]).length,group==='life'?1:0);
    }
});
