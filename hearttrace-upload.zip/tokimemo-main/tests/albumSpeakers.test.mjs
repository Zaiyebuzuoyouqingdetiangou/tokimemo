import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import * as album from '../src/modes/album.js';
import * as client from '../src/generation/client.js';
import * as cache from '../src/core/cache.js';
import * as library from '../src/archive/library.js';
import * as contextApi from '../src/core/context.js';
import * as constants from '../src/core/constants.js';
import * as view from '../src/ui/albumView.js';
import { parsePartialJsonObject } from '../src/generation/jsonParser.js';
import { fixture } from './helpers/r847Host.mjs';
import { state } from '../src/core/state.js';

const snapshot = { version: 1, people: [
    { id: 'person-a', name: '甲', sourceRefs: [] }, { id: 'person-b', name: '乙', sourceRefs: [] },
] };
const bank = { characterName: '沙盒卡标题', userName: '玩家', archiveName: '庭院相遇', archiveSummary: '', memories: [
    { id: 'M001', title: '一起栽花。', summary: '甲与玩家成为恋人。', anchors: ['庭院'], participants: ['甲', '玩家'] },
    { id: 'M002', title: '门口相遇。', summary: '乙与玩家是朋友。', anchors: ['门口'], participants: ['乙', '玩家'] },
] };
const entry = { id: 'CG01', title: '庭院', date: '待定', desc: '两人站在庭院', unlocked: true, sourceMemoryIds: ['M001'], sourceMemoryAnchor: '庭院', visualSeed: ['树','花','手','门'], comments: ['旧话一','旧话二','旧话三','旧话四'] };
const relation = { charState:'有证据', userState:'有证据', relationshipState:'未确认', relationshipSummary:'按档案', relationshipSourceMemoryIds:['M001'], relationshipSourceMemoryAnchor:'庭院' };
const lines = Array.from({ length: 6 }, (_, i) => ({ text: `第${i}句`, speakerId: i % 2 ? 'person-b' : 'person-a' }));
function segment(slot, json) { return { slot, ...parsePartialJsonObject(json) }; }

test('multiplayer dialogue normalizes to strings and stable per-line speaker identities', () => {
    const result = album.normalizeAlbumCommentsBatch({ items: [{ id:'CG01', comments: lines }] }, [entry], snapshot).get('CG01');
    assert.deepEqual(result.comments, lines.map(line => line.text));
    assert.deepEqual(result.commentSpeakers.map(line => line.speakerId), lines.map(line => line.speakerId));
    assert.deepEqual(result.commentSpeakers.map(line => line.speakerName), ['甲','乙','甲','乙','甲','乙']);
});

test('unknown speaker preserves the text without inventing a name or rejecting completed prose', () => {
    const result = album.normalizeAlbumCommentsBatch({ items: [{ id:'CG01', comments: lines.map(line => ({...line, speakerId:'unknown',speakerName:'伪造名字'})) }] }, [entry], snapshot).get('CG01');
    assert.deepEqual(result.comments, lines.map(line => line.text));
    assert.ok(result.commentSpeakers.every(line => !line.speakerId && !line.speakerName));
});

test('old strings stay unchanged and receive no guessed multiplayer identity', () => {
    const result = album.normalizeAlbum({ entries:[{...entry, speakerSnapshot:album.albumSpeakerIdentities(snapshot)}] }, bank);
    assert.deepEqual(result.entries[0].comments, entry.comments);
    assert.deepEqual(result.entries[0].commentSpeakers, entry.comments.map(() => ({speakerId:'',speakerName:''})));
    assert.deepEqual(result.entries[0].speakerSnapshot, album.albumSpeakerIdentities(snapshot));
});

test('closed partial dialogue retains alternating speakers and omits the open tail', () => {
    const index = segment('album:index', JSON.stringify({entries:[entry]}));
    const comments = segment('album:comments:0', '{"items":[{"id":"CG01","comments":[' + lines.slice(0,2).map(line=>JSON.stringify(line)).join(',') + ',{"speakerId":"person-a","text":"未完成');
    const result = album.projectAlbumProgress({ segments:[index,comments], memoryBank:bank, frozenInputs:{'participants:album':snapshot} });
    assert.deepEqual(result.entries[0].comments, lines.slice(0,2).map(line=>line.text));
    assert.deepEqual(result.entries[0].commentSpeakers.map(line=>line.speakerId), ['person-a','person-b']);
    assert.deepEqual(result.participantSnapshot,snapshot);
});

test('multiplayer relationship states are scoped to each named pair', () => {
    const result = album.normalizeAlbumRelationshipSnapshot({ people:snapshot.people.map(person=>({...relation,speakerId:person.id})) },bank,snapshot);
    assert.deepEqual(result.people.map(person=>person.speakerId),['person-a','person-b']);
    assert.deepEqual(result.people.map(person=>person.relationshipTier),[3,1]);
    assert.doesNotMatch(result.people[1].charState,/沙盒卡标题|双向亲密/);
});

test('multiplayer prompt specifies per-line ID and separate relationship while single prompt stays stable', async t => {
    const f=await fixture(t);
    const scan = album.albumRelationshipScanPrompt(f.ctx,bank,snapshot);
    const prompt = album.albumCommentsPrompt(f.ctx,bank,[entry],null,snapshot);
    assert.match(scan,/speakerId/); assert.match(scan,/person-a/); assert.match(scan,/person-b/);
    assert.match(prompt,/speakerId/); assert.match(prompt,/person-a/);
    assert.match(prompt,/轮流/);
    for(const [actual,expected] of [
        [album.albumIndexPrompt(f.ctx,bank),'4e35a8445f9eb5dad9546c8b9b6f1ace4affac6cecf6c380e3f7cd9bb46c24ee'],
        [album.albumRelationshipScanPrompt(f.ctx,bank),'1a7c067462dd0ee7d855eac53e323b47ad51dd659c4756f3e9ef57ea4595b462'],
        [album.albumCommentsPrompt(f.ctx,bank,[entry],relation),'a6a2f32ff59966adc181192e5d05d35ca1230cdf29c85516ecd3b97284661170'],
    ]) assert.equal(createHash('sha256').update(actual).digest('hex'),expected);
});

test('incremental merge retains old image, text and attribution exactly', () => {
    const old = {...entry,cgImage:{url:'/old.png'},commentSpeakers:[{speakerId:'person-b',speakerName:'乙'}],speakerSnapshot:{version:1,people:[{id:'person-b',name:'乙'}]}};
    const result=album.mergeAlbumIncremental({entries:[old]},{entries:[{...old,comments:['overwrite']}]},bank);
    assert.deepEqual(result.entries[0],old);
});

test('shared memory displays actual per-line names and offers no-API manual attribution',async t=>{
    const f=await fixture(t);
    state.activeSession={kind:'album',entries:[{...entry,comments:lines.map(line=>line.text),commentSpeakers:lines.map(line=>({speakerId:line.speakerId,speakerName:line.speakerId==='person-a'?'甲':'乙'})),participantSnapshot:snapshot}],selectedId:'CG01',sharedMemory:true,dialogueIndex:1,participantSnapshot:snapshot};
    state.activeArchiveSnapshot=null; state.activeArchiveReadOnly=false;
    view.renderSharedMemory();
    assert.match(f.body.innerHTML, /rmt-dialogue-speaker[^>]*>乙</);
    assert.match(f.body.innerHTML, /data-rmt-album-speaker/);
    assert.doesNotMatch(f.body.innerHTML, /rmt-dialogue-speaker[^>]*>林舟</);
    state.activeSession.entries[0].commentSpeakers=[];
    view.renderSharedMemory();
    assert.match(f.body.innerHTML,/未标注人物/);
    assert.equal(f.requests.length,0);
});

test('entry speaker identities omit repeated worldbook prose but retain duplicate names by ID', () => {
    const roster={version:1,people:snapshot.people.map(person=>({...person,name:'同名',sourceRefs:[{world:'W',uid:person.id,title:'人物',content:'长世界书资料'.repeat(1000)}]}))};
    const compact=album.albumSpeakerIdentities(roster);
    assert.deepEqual(compact.people,[{id:'person-a',name:'同名'},{id:'person-b',name:'同名'}]);
    assert.doesNotMatch(JSON.stringify(compact),/长世界书资料|sourceRefs/);
    const text=lines.map(line=>({...line,text:'相同对白'}));
    const result=album.normalizeAlbumCommentsBatch({items:[{id:'CG01',comments:text}]},[entry],roster).get('CG01');
    assert.equal(result.comments.length,6);
    assert.deepEqual(result.commentSpeakers.map(line=>line.speakerId),lines.map(line=>line.speakerId));
});

test('historical unknown dialogue never borrows the currently open other chat roster', async t => {
    const f=await fixture(t);
    f.ctx.chatMetadata[constants.MEMORY_KEY].participantsV1={...snapshot,cardType:'multi',selectedIds:['person-a','person-b']};
    state.activeArchiveSnapshot=null;
    assert.deepEqual(view.albumSpeakerSnapshot(entry,{kind:'album'}),snapshot);
    state.activeArchiveSnapshot={characterName:'历史沙盒',memory:{},cache:{}};
    const actual=view.albumSpeakerSnapshot(entry,{kind:'album'});
    assert.equal(actual,null);
});

test('multiplayer album retains the existing three request stages and produces named lines',async t=>{
    const f=await fixture(t);
    const origin=contextApi.captureTaskOrigin(f.ctx,f.liveBank.archiveRevision);
    f.setResponse(messages=>{
        const text=JSON.stringify(messages);
        if(text.includes('EXISTING_ALBUM_INDEX_JSON')) return {entries:[entry]};
        if(text.includes('ALBUM_RELATIONSHIP_FULL_ARCHIVE_JSON')) return {people:snapshot.people.map(person=>({...relation,speakerId:person.id}))};
        return {items:[{id:'CG01',comments:lines}]};
    });
    const result=await album.generateAlbumWithRepair(f.ctx,{...bank,chatId:f.liveBank.chatId,archiveRevision:f.liveBank.archiveRevision},origin,'speaker-flow',{participantSnapshot:snapshot});
    assert.equal(f.requests.length,3);
    assert.deepEqual(result.entries[0].comments,lines.map(line=>line.text));
    assert.deepEqual(result.entries[0].commentSpeakers.map(line=>line.speakerId),lines.map(line=>line.speakerId));
    assert.deepEqual(result.entries[0].speakerSnapshot,album.albumSpeakerIdentities(snapshot));
    assert.deepEqual(result.participantSnapshot,snapshot);
});

test('generic archive relationship summary cannot give every sandbox person the same romance',()=>{
    const mixed={...bank,archiveSummary:'双方已经成为恋人。',memories:[bank.memories[0]]};
    const result=album.normalizeAlbumRelationshipSnapshot({people:snapshot.people.map(person=>({...relation,speakerId:person.id}))},mixed,snapshot);
    assert.deepEqual(result.people.map(person=>person.relationshipTier),[3,0]);
    assert.match(result.people[1].charState,/尚未确认/);
});


test('incremental multiplayer upgrade keeps old lines while freezing the new session roster once',()=>{
    const old=structuredClone(entry);
    const fresh={participantSnapshot:snapshot,entries:[{...entry,id:'CG02',sourceMemoryIds:['M002'],sourceMemoryAnchor:'门口',speakerSnapshot:album.albumSpeakerIdentities(snapshot)}]};
    const result=album.mergeAlbumIncremental({entries:[old]},fresh,bank);
    assert.deepEqual(result.entries[0],old);
    assert.deepEqual(result.participantSnapshot,snapshot);
    assert.equal(result.entries.length,2);
    assert.deepEqual(result.entries[1].speakerSnapshot,album.albumSpeakerIdentities(snapshot));
});


test('real multiplayer draft supports manual speaker attribution, reload and missing-only continuation',async t=>{
    const f=await fixture(t);
    await cache.commitParticipantRoster(f.ctx,{...snapshot,cardType:'multi',selectedIds:snapshot.people.map(person=>person.id)});
    const entries=Array.from({length:4},(_,i)=>({...entry,id:`CG0${i+1}`,title:`庭院 ${i+1}`}));
    let resume=false;
    f.setResponse(messages=>{
        const text=messages.map(row=>row.content).join('\n');
        if(text.includes('EXISTING_ALBUM_INDEX_JSON')) return {entries};
        if(text.includes('ALBUM_RELATIONSHIP_FULL_ARCHIVE_JSON')) return {people:snapshot.people.map(person=>({...relation,speakerId:person.id}))};
        if(text.includes('CG04')) {
            if(!resume) throw new Error('synthetic last comments interrupted');
            return {items:[{id:'CG04',comments:lines}]};
        }
        return {items:entries.slice(0,3).map(item=>({id:item.id,comments:lines}))};
    });
    await client.generateMode('album',{background:true});
    assert.equal(f.requests.length,4,JSON.stringify(f.notices));
    const before=await f.persisted();
    const journal=cache.loadGenerationRecovery('album',f.ctx,before);
    assert.ok(journal,JSON.stringify(f.notices));
    assert.deepEqual(JSON.parse(journal.frozenInputs['participants:album']),snapshot);
    for(const messages of f.requests) {
        const text=messages.map(row=>row.content).join('\n');
        assert.equal(text.split('UNTRUSTED_SELECTED_PARTICIPANTS_JSON:').length-1,1,'each existing request carries the selected roster exactly once');
        assert.match(text,/person-a/);assert.match(text,/person-b/);
    }
    await library.openGenerationTaskResult(journal.draftId,f.ctx);
    assert.equal(state.activeArchiveReadOnly,false);
    const oldText=[...state.activeSession.entries[0].comments];
    assert.equal(oldText.length,6);
    await view.albumSetCommentSpeaker('CG01',0,'person-b');
    assert.equal(f.requests.length,4,'manual attribution is local only');
    state.activeSession=null;state.runtimeSessionCache.clear();
    await cache.ensureCacheHydrated(f.ctx);
    await library.openGenerationTaskResult(journal.draftId,f.ctx);
    assert.equal(state.activeSession.entries[0].commentSpeakers[0].speakerId,'person-b');
    assert.deepEqual(state.activeSession.entries[0].comments,oldText);
    resume=true;
    await client.continueSavedGeneration('album',{draftId:journal.draftId});
    assert.equal(f.requests.length,5,JSON.stringify(f.notices));
    assert.equal(f.requests.filter(messages=>messages.some(row=>row.content.includes('EXISTING_ALBUM_INDEX_JSON'))).length,1);
    assert.equal(f.requests.filter(messages=>messages.some(row=>row.content.includes('ALBUM_RELATIONSHIP_FULL_ARCHIVE_JSON'))).length,1);
    const after=await f.persisted();
    const result=after.album || after[cache.GENERATION_DRAFTS_CACHE_KEY].records[journal.draftId].result.session;
    assert.equal(result.entries[0].commentSpeakers[0].speakerId,'person-b');
    assert.deepEqual(result.entries[0].comments,oldText);
    assert.equal(result.entries[3].commentSpeakers[1].speakerId,'person-b');
});
