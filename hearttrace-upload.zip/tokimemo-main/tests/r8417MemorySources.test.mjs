import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './helpers/r847Host.mjs';
import * as R from '../src/archive/repository.js';
import * as L from '../src/archive/sourceLedger.js';
import * as Q from '../src/archive/qianqianjie.js';
import * as G from '../src/archive/sourceReadGuard.js';
import * as P from '../src/archive/memoryProviders.js';
import * as C from '../src/core/constants.js';
import * as cache from '../src/core/cache.js';
import { state } from '../src/core/state.js';

const clone = v => v == null ? v : structuredClone(v);
async function setup(t) {
 const f=await fixture(t); const data=new Map(); let writes=0, reads=0;
 const originals=new Map([Q.QQJ_BRIDGE,'STBaiBaiBook','user_avatar'].map(k=>[k,Object.getOwnPropertyDescriptor(globalThis,k)]));
 delete globalThis[Q.QQJ_BRIDGE]; delete globalThis.STBaiBaiBook;
 f.ctx.userAvatar='user-a.png'; f.ctx.chatMetadata[C.MEMORY_WORLD_INFO_SETTINGS_KEY]={books:[]};
 const backend={async read(scope){reads++;return clone(data.get(scope.key)||null)},async write(value){writes++;data.set(value.scope.key,clone(value));return true},async delete(){throw new Error('Must not delete')}};
 L.setMemorySourceLedgerBackendForTests(backend);
 t.after(()=>{L.setMemorySourceLedgerBackendForTests(null); for(const [k,d] of originals)d?Object.defineProperty(globalThis,k,d):delete globalThis[k]});
 const settings=f.ctx.extensionSettings[C.EXTENSION_SETTINGS_KEY];
 const identity={hostChatId:f.ctx.chatId,qqjChatId:'qqj-a',characterLocator:f.ctx.characters[0].avatar,personaLocator:f.ctx.userAvatar};
 let snapshot={status:'ready',identity:clone(identity),memory:{status:'ready',syncStatus:'idle',headCheckpointId:'checkpoint-a',floors:[{floorId:'floor-a',messageIndex:0,assistantSeq:1,summary:'千千结完整摘要：两人在庭院一起栽花。'}]}};
 let qqjCalls=0;
 const api={schemaVersion:1,kind:'qqj-public-memory-bridge',getStatus:()=>({status:'ready',identity:clone(snapshot.identity)}),getSnapshot(){qqjCalls++;return clone(snapshot)},readMemory(){throw new Error('Do not use lossy text projection')}};
 const setQQJ=(value=snapshot)=>{snapshot=clone(value);globalThis[Q.QQJ_BRIDGE]=api;settings.useCurrentChatExternalMemory=true;return snapshot};
 const setBook=(content,{history=true,all=true,disabled=false}={})=>{
  R.setMemoryWorldInfoSelection(f.ctx,{books:[{name:'A-book',all,entryUids:all?[]:['1'],historySource:history}]});
  f.ctx.loadWorldInfo=async()=>({entries:{1:{uid:1,comment:'手选记忆',key:[],content,disable:disabled}}});
 };
 return {...f,data,backend,settings,identity,api,setQQJ,getSnapshot:()=>snapshot,setBook,counts:()=>({writes,reads,qqjCalls})};
}
const recordsText = result=>result.records.map(r=>r.content).join('');

test('manual historical worldbook is read without any third-party API or external switch',async t=>{
 const f=await setup(t); f.setBook('昨日两人在庭院种下白色花苗。');
 const result=await R.readCurrentChatMemoryPlugins({automatic:true});
 assert.match(recordsText(result),/白色花苗/); assert.equal(f.counts().qqjCalls,0); assert.ok(f.counts().writes>0);
 const saved=await R.currentMemorySourceLedger(f.ctx); assert.ok(L.ledgerCurrentRecords(saved).length>0);
 assert.match(recordsText(await R.currentMemorySourceLedgerExternal(f.ctx)),/白色花苗/);
});
test('long manual historical entry is preserved beyond old 52000 character threshold',async t=>{
 const f=await setup(t);const body='首部标记\n'+'山间昨日同行。'.repeat(8500)+'\n尾部标记';f.setBook(body);
 const result=await R.readCurrentChatMemoryPlugins({automatic:true});
 const stored=L.ledgerCurrentRecords(await R.currentMemorySourceLedger(f.ctx));
 assert.equal(stored.length,1);assert.equal(stored[0].fragments.join(''),body);assert.match(recordsText(result),/尾部标记/);
 assert.equal(result.worldInfo.historyCoverage.status,'complete');
});
test('worldbook input budget is reported while original source remains complete in ledger',async t=>{
 const f=await setup(t);const body='历史正文'.repeat(70000)+'末尾保留';f.setBook(body);
 const result=await R.readCurrentChatMemoryPlugins({automatic:true});
 assert.equal(L.ledgerCurrentRecords(await R.currentMemorySourceLedger(f.ctx))[0].fragments.join(''),body);
 assert.ok(result.records.reduce((n,r)=>n+r.content.length,0)<=C.MAX_EXTERNAL_MEMORY_CHARS);
 assert.ok(result.sources.some(s=>s.coverage?.status==='truncated'));
});
test('ordinary setting book is background, not automatically promoted to history',async t=>{
 const f=await setup(t);f.setBook('设定：他们将来或许前往海边。',{history:false});
 const result=await R.readCurrentChatMemoryPlugins({automatic:true});
 assert.equal(result.records.length,0);assert.ok(result.worldInfo.entries.length>0);
 assert.match(R.memoryWorldInfoPromptBlock(result.worldInfo),/仅解释记忆含义/);
});
test('manual selected historical worldbook can load without listing method',async t=>{
 const f=await setup(t);f.setBook('历史来源直接读取。');delete f.ctx.getWorldInfoNames;
 assert.match(recordsText(await R.readCurrentChatMemoryPlugins({automatic:true})),/历史来源直接读取/);
});
test('explicit historical entries include disabled entries without relying on keyword activation',async t=>{
 const f=await setup(t);f.setBook('已选择的旧事。',{disabled:true});
 assert.match(recordsText(await R.readCurrentChatMemoryPlugins({automatic:true})),/已选择的旧事/);
});
test('explicit entry selection does not consume other entries from the same book',async t=>{
 const f=await setup(t);f.setBook('选中内容',{all:false});
 f.ctx.loadWorldInfo=async()=>({entries:{1:{uid:1,content:'选中内容'},2:{uid:2,content:'未选择不能读取'}}});
 const result=await R.readCurrentChatMemoryPlugins({automatic:true});assert.match(recordsText(result),/选中内容/);assert.doesNotMatch(recordsText(result),/未选择/);
});
test('removing a history selection excludes it without deleting the saved source ledger',async t=>{
 const f=await setup(t);f.setBook('历史源保留');await R.readCurrentChatMemoryPlugins({automatic:true});const before=clone([...f.data.values()]);
 R.setMemoryWorldInfoSelection(f.ctx,{books:[]});assert.equal((await R.currentMemorySourceLedgerExternal(f.ctx)).records.length,0);
 assert.deepEqual([...f.data.values()],before);
});
test('malformed worldbook response does not erase previously read history',async t=>{
 const f=await setup(t);f.setBook('历史仍在');await R.readCurrentChatMemoryPlugins({automatic:true});
 f.ctx.loadWorldInfo=async()=>({error:'private response must not leak'});
 const result=await R.readCurrentChatMemoryPlugins({automatic:true});assert.match(recordsText(result),/历史仍在/);
 assert.ok(result.worldInfo.books[0].error);assert.doesNotMatch(JSON.stringify(result.sources),/private response/);
});
test('failed worldbook loader keeps old evidence and identifies partial read',async t=>{
 const f=await setup(t);f.setBook('原文不应被删除');await R.readCurrentChatMemoryPlugins({automatic:true});
 f.ctx.loadWorldInfo=async()=>{throw new Error('PRIVATE_DETAIL')};
 const result=await R.readCurrentChatMemoryPlugins({automatic:true});assert.match(recordsText(result),/原文不应被删除/);assert.equal(result.worldInfo.historyCoverage.status,'partial');
 assert.doesNotMatch(JSON.stringify(f.diagnostics),/PRIVATE_DETAIL/);
});
for(const change of ['chat','character','persona','selection','lifecycle'])test(`worldbook result is discarded when ${change} changes during read`,async t=>{
 const f=await setup(t);f.setBook('不可串档');let release,entered;const started=new Promise(r=>entered=r);
 f.ctx.loadWorldInfo=()=>{entered();return new Promise(r=>release=r)};
 const pending=R.readCurrentChatMemoryPlugins({automatic:true});await started;
 if(change==='chat')f.ctx.chatId='another-chat';if(change==='character')f.ctx.characterId=1;
 if(change==='persona')f.ctx.userAvatar='other-user.png';if(change==='selection')R.setMemoryWorldInfoSelection(f.ctx,{books:[]});
 if(change==='lifecycle')state.runtimeLifecycleEpoch++;
 release({entries:{1:{uid:1,content:'不可串档'}}});await assert.rejects(pending,{name:'AbortError'});assert.equal(f.counts().writes,0);
});
test('QQJ keeps raw floor summary over 4000 characters and uses no projection/readMemory',async t=>{
 const f=await setup(t);const s=f.setQQJ();s.memory.floors[0].summary='初始\n'+'正文'.repeat(5000)+'\n尾部';
 const result=await R.readCurrentChatMemoryPlugins({automatic:true});assert.match(recordsText(result),/尾部/);
 const stored=L.ledgerCurrentRecords(await R.currentMemorySourceLedger(f.ctx)).filter(r=>r.provider===Q.QQJ_PROVIDER);
 assert.equal(stored[0].fragments.join(''),s.memory.floors[0].summary);assert.equal(f.counts().qqjCalls,1);
});
test('QQJ saved ledger reopens and reprojects without losing records (prior failed path)',async t=>{
 const f=await setup(t);f.setQQJ();await R.readCurrentChatMemoryPlugins({automatic:true});state.memoryPreflightCache.clear();
 const saved=await R.currentMemorySourceLedgerExternal(f.ctx);assert.equal(saved.records.length,1);assert.match(recordsText(saved),/千千结完整摘要/);
});
test('same host switches QQJ identity and consumes new summaries only (prior failed path)',async t=>{
 const f=await setup(t);const first=f.setQQJ();await R.readCurrentChatMemoryPlugins({automatic:true});
 const next=clone(first);next.identity.qqjChatId='qqj-b';next.memory.headCheckpointId='checkpoint-b';next.memory.floors[0].summary='新身份的新历史';
 f.setQQJ(next);const result=await R.readCurrentChatMemoryPlugins({automatic:true});assert.match(recordsText(result),/新身份/);assert.doesNotMatch(recordsText(result),/千千结完整摘要/);
 assert.equal((await R.currentMemorySourceLedger(f.ctx)).records.length,2,'old records remain, but are not adopted');
});
test('repeat QQJ scans deduplicate persisted records',async t=>{
 const f=await setup(t);f.setQQJ();await R.readCurrentChatMemoryPlugins({automatic:true});await R.readCurrentChatMemoryPlugins({automatic:true});
 assert.equal(L.ledgerCurrentRecords(await R.currentMemorySourceLedger(f.ctx)).length,1);assert.equal((await R.currentMemorySourceLedger(f.ctx)).records.length,1);
});
test('overlapping scans share one in-flight QQJ snapshot request',async t=>{
 const f=await setup(t);f.setQQJ();const snapshot=clone(f.getSnapshot());let release,entered,calls=0;const started=new Promise(r=>entered=r);
 f.api.getSnapshot=()=>{calls++;entered();return new Promise(r=>release=r)};
 const one=R.readCurrentChatMemoryPlugins({automatic:true});await started;const two=R.readCurrentChatMemoryPlugins({automatic:true});release(snapshot);
 const [a,b]=await Promise.all([one,two]);assert.equal(calls,1);assert.deepEqual(a,b);
});
for(const field of ['hostChatId','qqjChatId','characterLocator','personaLocator'])test(`QQJ snapshot mismatching ${field} is excluded`,async t=>{
 const f=await setup(t);f.setQQJ();const snapshot=clone(f.getSnapshot());snapshot.identity[field]='WRONG';f.api.getSnapshot=()=>snapshot;
 const result=await R.readCurrentChatMemoryPlugins({automatic:true});assert.equal(result.records.length,0);assert.equal(f.counts().writes,0);
 assert.ok(result.sources.some(s=>s.coverage?.status==='failed'));
});
for(const status of ['disabled','not-ready','error'])test(`QQJ ${status} is visible and errors are redacted`,async t=>{
 const f=await setup(t);f.setQQJ();f.api.getStatus=()=>({status,message:'SECRET_PRIVATE_BODY'});
 const result=await R.readCurrentChatMemoryPlugins({automatic:true});assert.equal(result.records.length,0);assert.match(JSON.stringify(result.sources),/千千结/);
 assert.doesNotMatch(JSON.stringify(result.sources),/SECRET_PRIVATE_BODY/);
});
test('QQJ missing API is visible, not treated as an empty successful scan',async t=>{
 const f=await setup(t);f.settings.useCurrentChatExternalMemory=true;const result=await R.readCurrentChatMemoryPlugins({automatic:true});
 assert.ok(result.sources.some(s=>s.id===Q.QQJ_PROVIDER&&s.coverage.status==='failed'));
});
test('QQJ empty ready snapshot replaces old active source without deleting old data',async t=>{
 const f=await setup(t);f.setQQJ();await R.readCurrentChatMemoryPlugins({automatic:true});const s=clone(f.getSnapshot());s.memory.floors=[];s.memory.headCheckpointId='empty-new';f.setQQJ(s);
 const result=await R.readCurrentChatMemoryPlugins({automatic:true});assert.equal(result.records.length,0);assert.equal((await R.currentMemorySourceLedger(f.ctx)).records.length,1);
});
test('QQJ syncing background with ready saved memory remains usable',async t=>{
 const f=await setup(t);const s=f.setQQJ();s.memory.syncStatus='syncing';assert.equal((await R.readCurrentChatMemoryPlugins({automatic:true})).records.length,1);
});
test('QQJ skips bad rows but keeps valid rows and reports incomplete scan',async t=>{
 const f=await setup(t);const s=f.setQQJ();s.memory.floors.push({floorId:'bad',messageIndex:-1,summary:'不可接受'});
 const result=await R.readCurrentChatMemoryPlugins({automatic:true});assert.match(recordsText(result),/千千结完整摘要/);assert.doesNotMatch(recordsText(result),/不可接受/);
 assert.ok(result.sources.some(s=>s.id===Q.QQJ_PROVIDER&&s.coverage.status==='partial'));
});
test('QQJ does not inspect CSE, people, private properties or execute getters',async t=>{
 const f=await setup(t);f.setQQJ();const s=clone(f.getSnapshot());Object.defineProperty(s,'people',{get(){throw new Error('PRIVATE_ACCESS')}});Object.defineProperty(s,'cse',{get(){throw new Error('PRIVATE_ACCESS')}});
 f.api.getSnapshot=()=>s;assert.equal((await R.readCurrentChatMemoryPlugins({automatic:true})).records.length,1);
});
test('QQJ API replacement during awaited read rejects old result',async t=>{
 const f=await setup(t);f.setQQJ();const original=clone(f.getSnapshot());let release,entered;const started=new Promise(r=>entered=r);
 f.api.getSnapshot=()=>{entered();return new Promise(r=>release=r)};
 const pending=Q.readQianQianJieCurrentChat(f.ctx);await started;globalThis[Q.QQJ_BRIDGE]={...f.api};release(original);
 const result=await pending;assert.equal(result.readStatus,'stale');assert.equal(f.counts().writes,0);
});

test('bounded public read times out without exposing exception or retrying',async t=>{
 const f=await setup(t);f.setQQJ();let calls=0;f.api.getSnapshot=()=>{calls++;return new Promise(()=>{})};
 const result=await Q.readQianQianJieCurrentChat(f.ctx,{timeoutMs:3});assert.equal(result.readStatus,'timed-out');assert.equal(calls,1);
});
test('abort while reading QQJ discards result and writes nothing',async t=>{
 const f=await setup(t);f.setQQJ();const controller=new AbortController();f.api.getSnapshot=()=>new Promise(()=>{});
 const pending=Q.readQianQianJieCurrentChat(f.ctx,{signal:controller.signal});controller.abort();await assert.rejects(pending,{name:'AbortError'});assert.equal(f.counts().writes,0);
});
test('ledger write failure uses current data without claiming it is saved',async t=>{
 const f=await setup(t);f.setQQJ();f.backend.write=async()=>{throw new Error('PRIVATE_FAILURE')};
 const result=await R.readCurrentChatMemoryPlugins({automatic:true});assert.match(recordsText(result),/千千结完整摘要/);assert.equal(f.data.size,0);assert.equal(result.ledgerAvailable,false);
 assert.doesNotMatch(JSON.stringify(f.diagnostics),/PRIVATE_FAILURE/);
});
test('unknown provider total remains null, not 0',()=>{assert.equal(L.normalizeMemorySourceCoverage({returned:17,total:null}).total,null)});
test('BBS documented DTO reads full history with unknown count and no fictitious 17/0 mismatch',async t=>{
 const f=await setup(t);f.settings.useCurrentChatExternalMemory=true;
 const common={apiVersion:1,pluginVersion:'fixture',revision:1,chat:{id:f.ctx.chatId,characterName:f.ctx.name2,groupId:null,length:1},coverage:{complete:true,missingAiFloors:[]}};
 globalThis.STBaiBaiBook={apiVersion:1,getSnapshot:()=>clone(common),getHistory:()=>({...clone(common),nodes:[{id:'one',text:'柏宝书完整历史',floorStart:0,floorEnd:0}],text:'柏宝书完整历史'})};
 const result=await R.readCurrentChatMemoryPlugins({automatic:true});assert.match(recordsText(result),/柏宝书完整历史/);
 const source=result.sources.find(s=>s.id==='baibai-book-public-api');assert.ok(source);assert.notEqual(source.coverage.total,0);
});
test('depth worldbook is archive-only opt-in; default envelope stays unchanged',async t=>{
 const f=await setup(t);f.settings.useActivatedWorldInfo=true;
 f.ctx.getWorldInfoPrompt=async()=>({worldInfoString:'BASE_BACKGROUND',worldInfoDepth:[{entries:['DEPTH_BACKGROUND']}]});
 const normal=await cache.buildControlledContextEnvelope(f.ctx);const archive=await cache.buildControlledContextEnvelope(f.ctx,{includeWorldInfoDepth:true});
 assert.doesNotMatch(normal,/DEPTH_BACKGROUND/);assert.match(archive,/DEPTH_BACKGROUND/);assert.match(archive,/BASE_BACKGROUND/);
});

test('queued ledger write rechecks scope after the awaited storage read',async t=>{
 const f=await setup(t);const scope=R.memorySourceScopeForContext(f.ctx);const guard=G.createSourceReadGuard(f.ctx);
 let entered,release;const started=new Promise(r=>entered=r);f.backend.read=()=>{entered();return new Promise(r=>release=r)};
 const pending=L.upsertMemorySourceLedger(scope,{provider:'manual-history',records:[{sourceId:'a',content:'old source'}]}, {assertCurrent:guard});await started;
 f.ctx.chatId='other-chat';release(null);await assert.rejects(pending,{name:'AbortError'});assert.equal(f.counts().writes,0);
});
test('QQJ source identity is rechecked immediately before ledger persistence',async t=>{
 const f=await setup(t);const snapshot=f.setQQJ();let called=0;const read=f.backend.read;
 f.backend.read=async scope=>{const result=await read(scope);if(++called===1)snapshot.identity.qqjChatId='new-while-saving';return result};
 await assert.rejects(R.collectCurrentChatExternalMemory(f.ctx,f.ctx.chatId),{name:'AbortError'});assert.equal(f.counts().writes,0);
});
test('empty ready QQJ with no checkpoint is a truthful empty current snapshot',async t=>{
 const f=await setup(t);const s=f.setQQJ();s.memory.headCheckpointId=null;s.memory.floors=[];
 const result=await Q.readQianQianJieCurrentChat(f.ctx);assert.equal(result.readStatus,'empty');assert.equal(result.coverage.status,'complete');
});
test('QQJ fake accessor fields never execute',async t=>{
 const f=await setup(t);f.setQQJ();let ran=0;const s=clone(f.getSnapshot());
 Object.defineProperty(s.memory.floors[0],'summary',{get(){ran++;return 'must not run'},enumerable:true});f.api.getSnapshot=()=>s;
 const result=await Q.readQianQianJieCurrentChat(f.ctx);assert.equal(ran,0);assert.equal(result.records.length,0);assert.equal(result.coverage.status,'partial');
});
test('QQJ oversized list is rejected rather than silently cut to budget',async t=>{
 const f=await setup(t);f.setQQJ();const s=clone(f.getSnapshot());s.memory.floors=new Array(C.MAX_MEMORY_SOURCE_LEDGER_RECORDS+1).fill(s.memory.floors[0]);f.api.getSnapshot=()=>s;
 const result=await Q.readQianQianJieCurrentChat(f.ctx);assert.equal(result.records.length,0);assert.equal(result.coverage.status,'failed');
});
test('turning external API off does not delete its ledger but stops its active projection',async t=>{
 const f=await setup(t);f.setQQJ();await R.readCurrentChatMemoryPlugins({automatic:true});const previous=clone([...f.data.values()]);
 f.ctx.extensionSettings[C.EXTENSION_SETTINGS_KEY].useCurrentChatExternalMemory=false;
 assert.equal((await R.currentMemorySourceLedgerExternal(f.ctx)).records.length,0);assert.deepEqual([...f.data.values()],previous);
});
test('readback storage failure retains current scanned content and explicitly reports no durable confirmation',async t=>{
 const f=await setup(t);f.setQQJ();let saved=false;const writer=f.backend.write;f.backend.write=async v=>{await writer(v);saved=true};
 const reader=f.backend.read;f.backend.read=async scope=>{if(saved)throw new Error('PRIVATE_DISK_ERROR');return reader(scope)};
 const result=await R.collectCurrentChatExternalMemory(f.ctx,f.ctx.chatId);assert.match(recordsText(result),/千千结完整摘要/);assert.equal(result.ledgerAvailable,false);
 assert.ok(result.sources.some(s=>s.id===Q.QQJ_PROVIDER&&s.coverage.status==='failed'));
});
test('cancelling before scheduled public read does not start the host method',async()=>{
 const controller=new AbortController();let calls=0;
 const promise=G.boundedSourceRead(()=>{calls++;return {}},controller.signal);controller.abort();
 await assert.rejects(promise,{name:'AbortError'});await Promise.resolve();assert.equal(calls,0);
});
