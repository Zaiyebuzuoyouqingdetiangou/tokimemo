// r8430: when a paid reply overflows the journal's existing total capacity, the
// capacity error still stops later requests, but the new reply keeps a bounded
// volatile page hold plus the explicit user export path. Synthetic data only;
// no user journal, prompt or key. No capacity constant is raised here.
import test from 'node:test';
import assert from 'node:assert/strict';
import * as recovery from '../src/generation/recovery.js';
import * as adapters from '../src/generation/recoveryAdapters.js';
import { fixture } from './helpers/r847Host.mjs';
import * as client from '../src/generation/client.js';
import * as context from '../src/core/context.js';

const LIMITS = recovery.GENERATION_RECOVERY_LIMITS;
const MODE = 'achievements';
const EXPORT_HINT = '本次新收到的成果已保留在当前页面，可通过恢复区“导出未提交草稿”一并导出。';
let sequence = 0;
const originFor = suffix => ({ characterKey: `r8430-character-${suffix}`, characterId: '0',
    characterAvatar: 'fixture.png', chatId: `r8430-chat-${suffix}`, archiveRevision: 'r8430-revision' });
// Exactly `chars` serialized bytes of inert synthetic content.
const replyFor = (tag, chars) => {
    const seed = { value: `${tag}:` };
    return { value: `${tag}:${'x'.repeat(chars - JSON.stringify(seed).length)}` };
};
const rawFor = (tag, chars) => JSON.stringify(replyFor(tag, chars));

async function harness(t, extra = {}) {
    const origin = originFor(++sequence);
    const calls = [];
    let saved = null;
    const handle = await recovery.createGenerationRecovery({ origin, mode: MODE, settingsIdentity: 'same-settings',
        save: value => { saved = structuredClone(value); return true; }, ...extra });
    recovery.attachGenerationRecovery(origin, handle);
    t.after(() => { recovery.detachGenerationRecovery(origin); recovery.discardGenerationRecoveryHeldReplies(origin, MODE); });
    const session = { origin, mode: MODE, handle, calls,
        get saved() { return saved; },
        opts(taskKey) { return { origin, mode: MODE, taskKey, contextEnvelope: 'same-context' }; },
        async complete(taskKey, value, options = {}) {
            return recovery.withRecoverySegment('same-prompt', { ...this.opts(taskKey), ...options }, raw => raw,
                async (_prompt, _requestOptions, accepted) => { calls.push(taskKey); await accepted(value); return value; });
        },
        failRaw(taskKey, raw) {
            return recovery.withRecoverySegment('same-prompt', this.opts(taskKey), raw => raw,
                async (_prompt, requestOptions) => {
                    calls.push(taskKey);
                    const error = Object.assign(new Error('synthetic truncation'), { code: 'RMT_JSON_TRUNCATED', retryable: true, retryableJson: true });
                    await recovery.recordRecoveryTruncation(requestOptions, raw, error);
                    throw error;
                });
        },
        async fail(taskKey, raw) {
            await assert.rejects(this.failRaw(taskKey, raw));
        },
    };
    return session;
}
const heldSlots = (origin, mode = MODE) => recovery.generationRecoveryHeldReplies(origin, mode);
const segmentOf = (handle, slot) => recovery.generationRecoverySnapshot(handle).segments.find(row => row.slot === slot);

test('r8430 A1: a full accepted reply overflowing the existing total capacity is held, projected and never retried', async t => {
    const views = [];
    const h = await harness(t, { onProgress: view => { views.push(view); } });
    await h.complete('ovf:a1:0', replyFor('A0', LIMITS.segmentChars));
    await h.complete('ovf:a1:1', replyFor('A1', LIMITS.segmentChars));
    const before = recovery.generationRecoverySnapshot(h.handle).segments.map(row => ({ ...row }));
    const savedBefore = structuredClone(h.saved);
    const callsBefore = h.calls.length;
    const valueC = replyFor('NEW', LIMITS.segmentChars), rawC = JSON.stringify(valueC);
    await assert.rejects(h.complete('ovf:a1:2', valueC),
        error => error.code === 'RMT_RECOVERY_LIMIT' && error.message.endsWith(EXPORT_HINT)
            && error.safeUserMessage.endsWith(EXPORT_HINT), 'the held-reply export hint rides on the thrown capacity error');
    // Old segments and old durable record are byte-identical; the paid reply did
    // not enter the journal or storage, and nothing regenerated automatically.
    const after = recovery.generationRecoverySnapshot(h.handle).segments;
    assert.deepEqual(after.slice(0, 2), before);
    assert.equal(h.calls.filter(key => key === 'ovf:a1:2').length, 1, 'no automatic retry of the failed segment');
    assert.equal(h.calls.length, callsBefore + 1, 'no extra requests at all');
    const marked = segmentOf(h.handle, 'ovf:a1:2');
    assert.equal(marked.state, 'retry', 'the old failure-marking path still applies');
    assert.equal(marked.rawJson, undefined, 'the new content never entered the journal');
    assert.ok(!JSON.stringify(h.saved).includes(rawC.slice(0, 200)), 'the new content never entered durable storage');
    assert.deepEqual(h.saved.segments.slice(0, 2), savedBefore.segments.slice(0, 2));
    // Bounded page hold keeps the paid reply; reads are deep copies.
    const held = heldSlots(h.origin);
    assert.equal(held.length, 1);
    assert.equal(held[0].slot, 'ovf:a1:2');
    assert.equal(held[0].rawJson, rawC);
    assert.equal(held[0].rawJson.length, LIMITS.segmentChars, 'a reply exactly at the original segment bound is still held');
    held[0].rawJson = 'tampered'; held[0].slot = 'tampered';
    assert.equal(heldSlots(h.origin)[0].rawJson, rawC, 'held replies are returned as deep copies');
    // The page projection carries the held reply as a truncated-looking segment;
    // it is a view only and was never written back into the journal.
    const projected = views.at(-1);
    const pseudo = projected.segments.find(row => row.slot === 'ovf:a1:2');
    assert.equal(pseudo.state, 'truncated');
    assert.equal(pseudo.partial, rawC, 'the page can read the paid reply C from the projection');
    assert.deepEqual(JSON.parse(pseudo.partial), valueC);
    assert.equal(segmentOf(h.handle, 'ovf:a1:2').state, 'retry', 'projection never wrote back');
    // Same slot and same bytes held again are deduplicated.
    await assert.rejects(h.complete('ovf:a1:2', valueC), error => error.code === 'RMT_RECOVERY_LIMIT');
    assert.equal(heldSlots(h.origin).length, 1, 'same slot + same rawJson is held only once');
    assert.equal(h.calls.filter(key => key === 'ovf:a1:2').length, 2, 'only the explicit second attempt ran');
});

test('r8430 A2: a merge conflict whose retention overflows capacity still raises the original conflict and holds the reply', async t => {
    const bank = { version: 3, chatId: 'r8430-merge-chat', archiveRevision: 'r8430-revision', characterName: '林舟', userName: '小月',
        memories: [{ id: 'M001', title: '栽花', summary: '林舟与小月一同在庭院栽花。', anchors: ['庭院'], participants: ['林舟', '小月'] }] };
    const fields = { name1: bank.userName, name2: bank.characterName, characterId: 0, characters: [{ name: bank.characterName, avatar: 'fixture.png' }] };
    const schema = adapters.recoveryProgressSchema('timeEcho', { memoryBank: bank, context: fields });
    const h = await harness(t);
    const oldPartial = '{"ends":[{"role":"char","time":"今夜"},{"role":"user","time":"明年"}],"medium":{"kind":"phone","label":"电话"},"lines":[{"speaker":"a","text":"旧句';
    await h.fail('ovf:a2:merge', oldPartial);
    assert.equal(segmentOf(h.handle, 'ovf:a2:merge').state, 'truncated');
    await h.complete('ovf:a2:0', replyFor('B0', LIMITS.segmentChars));
    await h.complete('ovf:a2:1', replyFor('B1', LIMITS.segmentChars));
    await h.complete('ovf:a2:2', replyFor('B2', 100000));
    // jsonData stores the canonical key-sorted serialization; keep the literal sorted.
    const conflicting = { ends: [{ role: 'user', time: '今夜' }, { role: 'char', time: '明年' }],
        lines: [{ speaker: 'b', text: `新句${'x'.repeat(590000)}` }], medium: { kind: 'phone', label: '电话' } };
    const rawConflicting = JSON.stringify(conflicting);
    assert.ok(rawConflicting.length <= LIMITS.segmentChars);
    const callsBefore = h.calls.length;
    await assert.rejects(h.complete('ovf:a2:merge', conflicting, { recoveryProgressSchema: schema }),
        error => error.code === 'RMT_RECOVERY_MERGE_CONFLICT' && error.message.endsWith(EXPORT_HINT),
        'the original merge conflict must not be replaced by the capacity error, and carries the export hint');
    assert.equal(h.calls.length, callsBefore + 1);
    const held = heldSlots(h.origin);
    assert.equal(held.length, 1);
    assert.equal(held[0].slot, 'ovf:a2:merge');
    assert.equal(held[0].rawJson, rawConflicting, 'the paid conflicting reply is held in-page');
    const prior = segmentOf(h.handle, 'ovf:a2:merge');
    assert.equal(prior.state, 'truncated');
    assert.equal(prior.partial, oldPartial, 'the old truncated draft is untouched');
    assert.equal(prior.retainedPartials, undefined, 'the overflowed retention row rolled back');
});

test('r8430 A3: a truncated draft overflowing the existing total capacity is held while old drafts stay intact', async t => {
    const h = await harness(t);
    await h.complete('ovf:a3:0', replyFor('C0', LIMITS.segmentChars));
    await h.complete('ovf:a3:1', replyFor('C1', LIMITS.segmentChars));
    await h.complete('ovf:a3:2', replyFor('C2', 100000));
    const before = recovery.generationRecoverySnapshot(h.handle).segments.map(row => ({ ...row }));
    const truncated = `{"entries":[{"id":"T1","text":"截断正文${'x'.repeat(590000)}`;
    assert.ok(truncated.length <= LIMITS.segmentChars);
    const callsBefore = h.calls.length;
    await assert.rejects(h.failRaw('ovf:a3:tail', truncated),
        error => error.code === 'RMT_RECOVERY_LIMIT' && error.message.endsWith(EXPORT_HINT)
            && error.safeUserMessage.endsWith(EXPORT_HINT));
    assert.equal(h.calls.length, callsBefore + 1, 'no hidden second request after the captured truncation');
    const held = heldSlots(h.origin);
    assert.equal(held.length, 1);
    assert.equal(held[0].slot, 'ovf:a3:tail');
    assert.equal(held[0].rawJson, truncated, 'the truncated paid draft is held in-page');
    assert.deepEqual(recovery.generationRecoverySnapshot(h.handle).segments.slice(0, 3), before, 'old segments are unchanged');
    const marked = segmentOf(h.handle, 'ovf:a3:tail');
    assert.equal(marked.state, 'retry');
    assert.equal(marked.partial, undefined, 'the overflowed truncated draft never entered the journal');
});

test('r8430 an over-segment-limit single truncation keeps the original message and is never held', async t => {
    const h = await harness(t);
    const oversized = `{"entries":[{"id":"T9","text":"${'x'.repeat(LIMITS.segmentChars)}`;
    assert.ok(oversized.length > LIMITS.segmentChars);
    await assert.rejects(h.failRaw('ovf:a3:huge', oversized),
        error => error.code === 'RMT_RECOVERY_LIMIT' && !error.message.includes(EXPORT_HINT)
            && error.message.endsWith('请勿关闭当前页面。'),
        'the pre-hold single-segment limit keeps the exact original r84.29 message');
    assert.deepEqual(heldSlots(h.origin), [], 'an oversized single reply is rejected by the hold bound');
});

test('r8430 per-identity holds are bounded at eight entries with the oldest dropped', async t => {
    const h = await harness(t);
    await h.complete('ovf:cap:0', replyFor('D0', LIMITS.segmentChars));
    await h.complete('ovf:cap:1', replyFor('D1', LIMITS.segmentChars));
    for (let i = 0; i < 9; i++) {
        await assert.rejects(h.complete(`ovf:cap:x:${i}`, replyFor(`X${i}`, LIMITS.segmentChars)),
            error => error.code === 'RMT_RECOVERY_LIMIT');
    }
    const held = heldSlots(h.origin);
    assert.equal(held.length, 8, 'holds per identity stay within the defensive bound');
    assert.equal(held[0].rawJson, rawFor('X1', LIMITS.segmentChars), 'the oldest hold is dropped first');
    assert.equal(held.at(-1).rawJson, rawFor('X8', LIMITS.segmentChars));
    assert.ok(held.every((entry, index) => entry.at <= (held[index + 1] ?? entry).at || index === held.length - 1));
});

test('r8430 the hold map itself is bounded at sixteen identities', async t => {
    const sessions = [];
    for (let i = 0; i < 17; i++) {
        const origin = originFor(`map-${i}`);
        const handle = await recovery.createGenerationRecovery({ origin, mode: MODE, settingsIdentity: 'same-settings', save: () => true });
        recovery.attachGenerationRecovery(origin, handle);
        sessions.push({ origin, handle });
        const complete = (taskKey, value) => recovery.withRecoverySegment('same-prompt',
            { origin, mode: MODE, taskKey, contextEnvelope: 'same-context' }, raw => raw,
            async (_prompt, _requestOptions, accepted) => { await accepted(value); return value; });
        await complete('ovf:map:0', replyFor(`M${i}a`, LIMITS.segmentChars));
        await complete('ovf:map:1', replyFor(`M${i}b`, LIMITS.segmentChars));
        await assert.rejects(complete('ovf:map:2', replyFor(`M${i}c`, LIMITS.segmentChars)), error => error.code === 'RMT_RECOVERY_LIMIT');
    }
    t.after(() => sessions.forEach(({ origin }) => {
        recovery.detachGenerationRecovery(origin); recovery.discardGenerationRecoveryHeldReplies(origin, MODE);
    }));
    assert.deepEqual(heldSlots(sessions[0].origin), [], 'the oldest identity hold is evicted beyond sixteen identities');
    assert.equal(heldSlots(sessions[1].origin).length, 1);
    assert.equal(heldSlots(sessions[16].origin).length, 1);
    const total = sessions.filter(({ origin }) => heldSlots(origin).length > 0).length;
    assert.ok(total <= 16, 'no more than sixteen identities are ever held');
});

test('r8430 with sufficient capacity nothing is held and the normal path is byte-identical to before', async t => {
    const views = [];
    const h = await harness(t, { onProgress: view => { views.push(view); } });
    await h.complete('ovf:ok:0', { value: '第一段正文' });
    await h.complete('ovf:ok:1', { value: '第二段正文' });
    assert.deepEqual(heldSlots(h.origin), [], 'no overflow means no holds');
    const segments = recovery.generationRecoverySnapshot(h.handle).segments;
    assert.deepEqual(segments.map(row => row.state), ['complete', 'complete']);
    assert.deepEqual(JSON.parse(segments[0].rawJson), { value: '第一段正文' });
    assert.deepEqual(JSON.parse(segments[1].rawJson), { value: '第二段正文' });
    assert.equal(recovery.generationRecoverySummary(h.saved).completed, 2);
    assert.equal(views.length, 2, 'normal durable publications only');
    assert.deepEqual(views.at(-1).segments, segments, 'normal projection is the journal itself');
    const exported = recovery.exportGenerationRecovery(h.saved);
    assert.equal(exported.unsavedReplies, undefined, 'the recovery export shape is unchanged without holds');
});

test('r8430 explicit export carries held replies as inert data and discarding the draft clears them', async t => {
    const f = await fixture(t);
    const origin = context.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision);
    const handle = await client.beginModeRecovery('heart', f.ctx, f.liveBank, origin, { contentInputs: {} });
    const identity = () => recovery.generationRecoverySnapshot(handle).identity;
    t.after(() => { recovery.detachGenerationRecovery(origin); recovery.discardGenerationRecoveryHeldReplies(identity(), 'heart'); });
    const complete = (taskKey, value) => recovery.withRecoverySegment('same-prompt',
        { origin, mode: 'heart', taskKey, contextEnvelope: 'same-context' }, raw => raw,
        async (_prompt, _requestOptions, accepted) => { await accepted(value); return value; });
    await complete('r8430:export:0', replyFor('E0', LIMITS.segmentChars));
    await complete('r8430:export:1', replyFor('E1', LIMITS.segmentChars));
    const cleanExport = await client.exportSavedGeneration('heart');
    assert.equal(cleanExport.unsavedReplies, undefined, 'no holds means the export shape is unchanged');
    const valueE = replyFor('E2', LIMITS.segmentChars);
    await assert.rejects(complete('r8430:export:2', valueE), error => error.code === 'RMT_RECOVERY_LIMIT');
    assert.equal(f.requests.length, 0, 'the overflow path never reaches the provider');
    const exported = await client.exportSavedGeneration('heart');
    assert.ok(Array.isArray(exported.unsavedReplies), 'explicit user export carries the held reply');
    assert.equal(exported.unsavedReplies.length, 1);
    assert.equal(exported.unsavedReplies[0].slot, 'r8430:export:2');
    assert.equal(exported.unsavedReplies[0].state, 'received-unsaved');
    assert.deepEqual(JSON.parse(exported.unsavedReplies[0].rawJson), valueE);
    assert.equal(exported.journal.segments.filter(row => row.state === 'complete').length, 2, 'journal export itself is unchanged');
    await client.discardSavedGeneration('heart');
    assert.deepEqual(recovery.generationRecoveryHeldReplies(identity(), 'heart'), [], 'discard clears the volatile holds');
    await assert.rejects(client.exportSavedGeneration('heart'),
        error => error.code === 'RMT_RECOVERY_INPUT_CHANGED', 'the discarded draft itself is gone as before');
});
