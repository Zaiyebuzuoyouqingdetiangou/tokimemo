import test from 'node:test';
import assert from 'node:assert/strict';
import { archiveFixture, sourceRows, clickImport, memoryReply } from './helpers/r8422ArchiveHost.mjs';
import { localFixture, fixedOrigin, waitUntil } from './helpers/r8425LocalHost.mjs';
import * as D from '../src/archive/importRecovery.js';
import * as R from '../src/archive/repository.js';
import * as G from '../src/generation/recovery.js';
import * as L from '../src/core/localRecoveryStore.js';
import * as context from '../src/core/context.js';
import * as overlay from '../src/ui/overlay.js';
import * as C from '../src/core/constants.js';
import { state } from '../src/core/state.js';
const originFor = f => context.captureTaskOrigin(f.ctx, R.getImportedMemory(f.ctx)?.archiveRevision || '');
const begin = (origin, extra = {}) => D.beginArchiveRecovery({ origin, sourceIdentity: 'tt-synthetic-source', sourceFragments: ['fixed'], settingsIdentity: 'tt-fixed-settings', ...extra });
const run = (ticket, i, count) => G.withRecoverySegment('synthetic fragment '+i, { origin:ticket.origin, taskKey:'tt-'+i, mode:'archive-import' }, x => x,
    async (_p,_o,accept) => { count.n++; const x={i}; await accept(x); return x; });
function noIDB(t, throwing=false) {
    const old=Object.getOwnPropertyDescriptor(globalThis,'indexedDB');
    Object.defineProperty(globalThis,'indexedDB', throwing ? {configurable:true,get(){throw new DOMException('PRIVATE_SENTINEL','SecurityError');}} : {configurable:true,value:undefined});
    t.after(()=>old?Object.defineProperty(globalThis,'indexedDB',old):delete globalThis.indexedDB);
    L.setLocalRecoveryBackendForTests(null);
}
function regionFor(f) {
    const query=f.body.querySelector; const region={innerHTML:'',busy:'',setAttribute(k,v){if(k==='aria-busy')this.busy=v;}};
    f.body.querySelector=s=>s==='[data-rmt-archive-recoveries]'&&f.body.innerHTML.includes('data-rmt-archive-recoveries')?region:query.call(f.body,s);
    return region;
}
async function seed(origin, n=41) {
    const count={n:0}, ticket=await begin(origin);
    for(let i=0;i<n;i++)await run(ticket,i,count);
    D.releaseArchiveRecovery(ticket);await D.flushArchiveRecovery(origin);return count;
}
for(const blocked of [false,true])test('TT-shaped real archive button: '+(blocked?'denied':'absent')+' IndexedDB cannot silently spend in page-only mode',async t=>{
    const f=await archiveFixture(t,{rows:sourceRows(4,5000)}); const local=localFixture(t);noIDB(t,blocked);
    globalThis.location={protocol:'tauri:',origin:'tauri://localhost'};
    const before=structuredClone(f.ctx.chatMetadata);await clickImport(f);
    assert.equal(f.requests.length,0);assert.equal(state.busy,false);assert.equal(state.activeProviderRequestCount,0);
    assert.deepEqual(f.ctx.chatMetadata,before);assert.equal(local.records.size,0);
    assert.ok(f.notices.some(x=>JSON.stringify(x).includes('读取未完成')),JSON.stringify(f.notices));assert.doesNotMatch(JSON.stringify(f.notices),/PRIVATE_SENTINEL/);
});
for(const denied of [false,true])test('archive view distinguishes '+(denied?'SecurityError':'missing storage')+' from empty records without generating',async t=>{
    const f=await archiveFixture(t);const local=localFixture(t),region=regionFor(f);await seed(originFor(f));const rows=structuredClone(local.records);
    D.resetArchiveRecoveryMemoryForTests();noIDB(t,denied);overlay.showChooser({section:'archive'});await waitUntil(()=>region.busy==='false');
    assert.match(region.innerHTML,/读取未完成/);assert.match(region.innerHTML,/不能认定没有记录/);assert.doesNotMatch(region.innerHTML,/本机未找到/);
    assert.deepEqual(local.records,rows);assert.equal(f.requests.length,0);
    L.setLocalRecoveryBackendForTests(local.backend);await overlay.loadChooserArchiveRecovery(f.ctx,{showEmpty:true});
    assert.match(region.innerHTML,/41 个成功分段/);assert.equal(f.requests.length,0);
});
for(const ack of [false,undefined,null,0,99])test('invalid transaction acknowledgement '+String(ack)+' never permits first model request',async t=>{
    const local=localFixture(t),origin=fixedOrigin();L.setLocalRecoveryBackendForTests({...local.backend,compare:async()=>ack});
    await assert.rejects(begin(origin),{code:'RMT_ARCHIVE_DRAFT_STORAGE'});
    const summary=D.archiveRecoverySummary(origin);assert.equal(summary.completed,0);assert.equal(summary.savedCompleted,0);assert.equal(summary.pageOnly,true);
});
test('initial write denied is not permission to generate; storage-only retry preserves original task',async t=>{
    const f=await archiveFixture(t,{rows:sourceRows(2,2000)}),local=localFixture(t);local.fail();
    await clickImport(f);assert.equal(f.requests.length,0);assert.equal(D.archiveRecoverySummary(originFor(f)).pageOnly,true);
    local.fail(false);const saved=await R.saveCurrentArchiveRecovery(f.ctx);assert.equal(saved.pageOnly,false);assert.equal(saved.completed,0);assert.equal(f.requests.length,0);
});
test('41 durable of63: failed save of42 halts before43, saving page and reopening never regenerates42',async t=>{
    const local=localFixture(t),origin=fixedOrigin();const count=await seed(origin);const ticket=await begin(origin,{continueApproved:true});
    for(let i=0;i<41;i++)await run(ticket,i,count);assert.equal(count.n,41);
    const before=structuredClone(local.records);local.fail();
    await assert.rejects((async()=>{for(let i=41;i<63;i++)await run(ticket,i,count);})(),{code:'RMT_RECOVERY_STORAGE'});
    assert.equal(count.n,42);assert.deepEqual(local.records,before);
    let summary=D.archiveRecoverySummary(origin);assert.equal(summary.completed,42);assert.equal(summary.savedCompleted,41);assert.equal(summary.pageOnly,true);
    assert.match(summary.notice,/已确认保存 41/);assert.match(summary.notice,/页面共有 42/);
    D.releaseArchiveRecovery(ticket);await assert.rejects(D.flushArchiveRecovery(origin));local.fail(false);await D.flushArchiveRecovery(origin);
    D.resetArchiveRecoveryMemoryForTests();await D.hydrateArchiveRecovery(origin);summary=D.archiveRecoverySummary(origin);assert.equal(summary.completed,42);assert.equal(summary.pageOnly,false);
    const next=await begin(origin,{continueApproved:true});for(let i=0;i<63;i++)await run(next,i,count);
    assert.equal(count.n,63);D.releaseArchiveRecovery(next);await D.flushArchiveRecovery(origin);
});
test('page results remain exportable when storage disappears; discard may not erase them without a tombstone',async t=>{
    const f=await archiveFixture(t),local=localFixture(t),origin=originFor(f);await seed(origin,3);const rows=structuredClone(local.records);noIDB(t);
    const data=await R.exportCurrentArchiveRecoveryAfterLoad(f.ctx);assert.equal(data.pageDrafts[0].journal.segments.filter(x=>x.state==='complete').length,3);
    await assert.rejects(D.discardArchiveRecovery(origin),{code:'RMT_ARCHIVE_DRAFT_READ'});assert.equal(D.archiveRecoverySummary(origin).completed,3);assert.deepEqual(local.records,rows);assert.equal(f.requests.length,0);
});
test('cached empty scope can be explicitly reread after an existing record becomes accessible',async t=>{
    const local=localFixture(t),origin=fixedOrigin();await seed(origin);const row=structuredClone([...local.records.values()][0]);D.resetArchiveRecoveryMemoryForTests();local.records.clear();
    await D.hydrateArchiveRecovery(origin);assert.equal(D.archiveRecoverySummary(origin),null);local.records.set(row.key,row);
    await D.hydrateArchiveRecovery(origin,'import',{force:true});assert.equal(D.archiveRecoverySummary(origin).completed,41);
});
for(const shape of [undefined,false,{payload:null},{key:'other',revision:1,payload:null}])test('invalid read envelope is not interpreted as empty: '+JSON.stringify(shape),async t=>{
    const local=localFixture(t),origin=fixedOrigin();L.setLocalRecoveryBackendForTests({...local.backend,read:async()=>shape});
    await assert.rejects(D.hydrateArchiveRecovery(origin),{code:'RMT_ARCHIVE_DRAFT_READ'});assert.equal(local.records.size,0);
});
for(const value of ['tombstone','other writer'])test('explicit reread detects '+value+' without adopting new revision to overwrite it',async t=>{
    const local=localFixture(t),origin=fixedOrigin();await seed(origin,3);const row=[...local.records.values()][0];row.revision++;
    if(value==='tombstone')row.payload=null;const before=structuredClone(local.records);
    await assert.rejects(D.hydrateArchiveRecovery(origin,'import',{force:true}),{code:'RMT_ARCHIVE_DRAFT_CONFLICT'});
    await assert.rejects(D.flushArchiveRecovery(origin));assert.deepEqual(local.records,before);assert.equal(D.archiveRecoverySummary(origin).completed,3);
});
test('loaded scope still checks storage on resumed tasks, rather than silently becoming page-only',async t=>{
    const local=localFixture(t),origin=fixedOrigin();const count=await seed(origin,3);noIDB(t);await assert.rejects(begin(origin,{continueApproved:true}));assert.equal(count.n,3);
    L.setLocalRecoveryBackendForTests(local.backend);const ticket=await begin(origin,{continueApproved:true});for(let i=0;i<4;i++)await run(ticket,i,count);assert.equal(count.n,4);D.releaseArchiveRecovery(ticket);await D.flushArchiveRecovery(origin);
});
test('failed save does not remove old formal memory or alter source and model settings',async t=>{
    const f=await archiveFixture(t,{rows:sourceRows(2,2000)}),local=localFixture(t);const before=structuredClone({bank:f.ctx.chatMetadata[C.MEMORY_KEY],settings:f.ctx.extensionSettings});
    let admitted=0;f.setResponse(messages=>{admitted++;local.fail();return memoryReply(messages);});await clickImport(f);
    assert.equal(admitted,1);assert.equal(f.requests.length,1);assert.deepEqual(f.ctx.chatMetadata[C.MEMORY_KEY],before.bank);assert.deepEqual(f.ctx.extensionSettings,before.settings);
});

test('explicit reread does not classify our concurrent successful write as a foreign revision',async t=>{
    const local=localFixture(t),origin=fixedOrigin();const count=await seed(origin,3);
    let entered,release;const ready=new Promise(r=>entered=r),gate=new Promise(r=>release=r);
    L.setLocalRecoveryBackendForTests({...local.backend,read:async key=>{const row=await local.backend.read(key);entered();await gate;return row;}});
    const reading=D.hydrateArchiveRecovery(origin,'import',{force:true});await ready;
    const ticket=await begin(origin,{continueApproved:true});await run(ticket,3,count);D.releaseArchiveRecovery(ticket);await D.flushArchiveRecovery(origin);
    release();await reading;
    assert.equal(D.archiveRecoverySummary(origin).completed,4);assert.equal(D.archiveRecoverySummary(origin).savedCompleted,4);assert.equal(count.n,4);
});
test('malformed stored payload is reported as read failure, not missing or an alleged write',async t=>{
    const local=localFixture(t),origin=fixedOrigin();await seed(origin,3);const row=[...local.records.values()][0];row.payload.version=999;const before=structuredClone(local.records);
    D.resetArchiveRecoveryMemoryForTests();await assert.rejects(D.hydrateArchiveRecovery(origin),{code:'RMT_ARCHIVE_DRAFT_READ'});assert.deepEqual(local.records,before);
});
