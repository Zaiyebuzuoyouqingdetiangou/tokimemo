import test from 'node:test';
import assert from 'node:assert/strict';
import * as recovery from '../src/generation/recovery.js';
import * as cache from '../src/core/cache.js';
import * as constants from '../src/core/constants.js';
import * as view from '../src/ui/recoveryView.js';
import * as modesView from '../src/modes/recoveryView.js';

// r84.32: an oversized journal (packed total above GENERATION_RECOVERY_LIMITS.journalChars)
// must stay readable, exportable and discardable, but never continuable; a fresh
// start whose own source snapshot exceeds the request bound must be classified
// separately from a draft that filled its capacity mid-stream.

const identityFor = () => ({ characterKey: 'oversize-character', characterId: '0', characterAvatar: 'test.png',
    chatId: 'oversize-chat', archiveRevision: 'r1', archiveTargetEntryId: 'e1', mode: 'album' });

function oversizedJournal() {
    // Each segment respects the per-segment bound; only the packed total
    // exceeds GENERATION_RECOVERY_LIMITS.journalChars (1.8M).
    return { kind: 'generation-recovery', version: 1, identity: identityFor(),
        settingsHash: 'a'.repeat(64), createdAt: Date.now() - 2000, updatedAt: Date.now() - 1000,
        segments: [0, 1, 2, 3].map(i => ({ slot: `s${i}`, requestHash: `${i}${'b'.repeat(63)}`, state: 'complete',
            rawJson: JSON.stringify({ number: i, text: 'x'.repeat(500000) }) })) };
}

test('oversized journal summary is readable, flagged oversized, never continuable', () => {
    const summary = recovery.generationRecoverySummary(oversizedJournal());
    assert.ok(summary, 'oversized journal must produce a summary so its card can render');
    assert.equal(summary.oversized, true);
    assert.equal(summary.completed, 4);
    assert.equal(summary.canContinue, false);
    assert.equal(summary.canRetry, false);
});

test('oversized journal exports byte-intact content with an oversized marker', () => {
    const journal = oversizedJournal();
    const exported = recovery.exportGenerationRecovery(journal);
    assert.equal(exported.kind, 'hearttrace-module-recovery-export');
    assert.equal(exported.oversized, true);
    assert.equal(exported.journal.segments[0].rawJson, journal.segments[0].rawJson);
    assert.equal(exported.journal.segments.length, 4);
});

test('continuing an oversized journal fails honestly before any request', async () => {
    let saved = 0;
    await assert.rejects(
        recovery.createGenerationRecovery({ origin: identityFor(), mode: 'album', settingsIdentity: 'same',
            existing: oversizedJournal(), continueRequested: true, save: () => { saved++; } }),
        error => error.code === 'RMT_RECOVERY_OVERSIZED' && error.safeToDisplay === true);
    assert.equal(saved, 0, 'no write may happen for an oversized continuation');
});

test('corrupt journals still fail continuation as a record mismatch, not oversized', async () => {
    const corrupt = { ...oversizedJournal(), settingsHash: 'not-a-digest' };
    await assert.rejects(
        recovery.createGenerationRecovery({ origin: identityFor(), mode: 'album', settingsIdentity: 'same',
            existing: corrupt, continueRequested: true, save: () => true }),
        error => error.code === 'RMT_RECOVERY_INPUT_CHANGED');
    assert.equal(recovery.generationRecoverySummary(corrupt), null);
});

test('oversized source snapshot is classified distinctly from draft capacity', async () => {
    const snapshot = { version: 1, fields: {}, cardFields: {},
        memoryBank: { characterName: 'c', chatId: 'oversize-chat', archiveRevision: 'r1',
            memories: Array.from({ length: 240 }, (_, i) => ({ id: `M${i}`, title: 't'.repeat(100),
                summary: 's'.repeat(5000), anchors: ['a'.repeat(500)] })) },
        contentSettings: {} };
    assert.ok(JSON.stringify(snapshot).length > recovery.GENERATION_RECOVERY_LIMITS.requestChars);
    let saved = 0;
    await assert.rejects(
        recovery.createGenerationRecovery({ origin: identityFor(), mode: 'album', settingsIdentity: 'x',
            existing: null, save: () => { saved++; }, contentSnapshot: snapshot }),
        error => error.code === 'RMT_RECOVERY_SNAPSHOT_TOO_LARGE' && error.safeToDisplay === true);
    assert.equal(saved, 0, 'no draft may be created when the snapshot itself is too large');
});

test('normal journals keep the unchanged summary contract with no oversized flag', async () => {
    let saved;
    const origin = identityFor();
    const handle = await recovery.createGenerationRecovery({ origin, mode: 'album', settingsIdentity: 'original',
        contentSnapshot: { original: true }, save: async value => { saved = structuredClone(value); return true; } });
    recovery.attachGenerationRecovery(origin, handle);
    await recovery.withRecoverySegment('第1段 材料', { origin, taskKey: 'oversize:normal', contextEnvelope: 'bg' }, raw => raw,
        async (_prompt, _options, accept) => { const value = { number: 1 }; await accept(value); return value; });
    const summary = recovery.generationRecoverySummary(saved);
    assert.equal(summary.oversized, undefined);
    assert.equal(summary.completed, 1);
    assert.equal(summary.canContinue, false);
    const exported = recovery.exportGenerationRecovery(saved);
    assert.equal(exported.oversized, undefined);
    recovery.detachGenerationRecovery(origin);
});

test('pool-branch banner shows export and discard but no continue for an oversized draft', () => {
    const journal = oversizedJournal();
    journal.draftId = 'draft-oversize';
    journal.pageId = 'album';
    const stored = { [cache.GENERATION_DRAFTS_CACHE_KEY]: { version: 1,
        records: { 'draft-oversize': { journal, status: 'open' } } } };
    const bank = { chatId: 'oversize-chat', archiveRevision: 'r1' };
    const html = view.recoveryBannerHtml(stored, bank);
    assert.match(html, /超出本地保存上限/);
    assert.match(html, /data-rmt-recovery-export="album"/);
    assert.match(html, /data-rmt-recovery-discard="album"/);
    assert.doesNotMatch(html, /data-rmt-recovery-mode=/, 'oversized drafts must not offer continuation');
});

test('legacy-branch banners show export and discard but no continue for an oversized draft', () => {
    const journal = oversizedJournal();
    journal[constants.SESSION_MODE_WRITE_FENCE_KEY] = '';
    const stored = { [recovery.GENERATION_RECOVERY_CACHE_KEY]: { album: journal } };
    const bank = { chatId: 'oversize-chat', archiveRevision: 'r1' };
    for (const banner of [view.recoveryBannerHtml(stored, bank), modesView.recoveryBannerHtml(stored, bank)]) {
        assert.match(banner, /超出本地保存上限/);
        assert.match(banner, /data-rmt-recovery-export="album"/);
        assert.match(banner, /data-rmt-recovery-discard="album"/);
        assert.doesNotMatch(banner, /data-rmt-recovery-mode=/, 'oversized drafts must not offer continuation');
    }
});

test('normal legacy journals keep continue, export and discard buttons unchanged', () => {
    const journal = { kind: 'generation-recovery', version: 1, identity: identityFor(),
        settingsHash: 'a'.repeat(64), createdAt: Date.now() - 2000, updatedAt: Date.now() - 1000,
        failureCode: 'RMT_JSON_TRUNCATED',
        segments: [{ slot: 's1', requestHash: 'b'.repeat(64), state: 'truncated', partial: ' halfway ', failureCode: 'RMT_JSON_TRUNCATED' }] };
    journal[constants.SESSION_MODE_WRITE_FENCE_KEY] = '';
    const stored = { [recovery.GENERATION_RECOVERY_CACHE_KEY]: { album: journal } };
    const bank = { chatId: 'oversize-chat', archiveRevision: 'r1' };
    const html = view.recoveryBannerHtml(stored, bank);
    assert.match(html, /data-rmt-recovery-mode="album"/);
    assert.match(html, /data-rmt-recovery-export="album"/);
    assert.match(html, /data-rmt-recovery-discard="album"/);
    assert.doesNotMatch(html, /超出本地保存上限/);
});
