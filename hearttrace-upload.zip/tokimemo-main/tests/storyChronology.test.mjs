import test from 'node:test';
import assert from 'node:assert/strict';
import { memoryPayload } from '../src/core/evidence.js';
import * as album from '../src/modes/album.js';
import * as view from '../src/ui/albumView.js';
import { state } from '../src/core/state.js';
import { parsePartialJsonObject } from '../src/generation/jsonParser.js';
import { sortByStoryDate } from '../src/core/storyChronology.js';
import { phase4ChronologyDeltas, phase4ChronologyApprovedSource } from './helpers/phase4ChronologyApprovedDelta.mjs';
import { phase7ApprovedSource } from './helpers/phase7ApprovedDelta.mjs';
import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';

const bank = dates => ({ memories: dates.map((date, index) => ({
  id: `M${index + 1}`, date, title: `记忆${index + 1}`, summary: `正文${index + 1}`,
  anchors: [`锚点${index + 1}`], participants: ['林舟', '小月'], messageStart: index + 1, messageEnd: index + 1,
})) });
const ids = rows => rows.map(row => row.id);
const payloadIds = dates => ids(memoryPayload(bank(dates)));
const entry = (id, date, memoryId, extra = {}) => ({ id, date, title: `相片${id}`,
  desc: '庭院里共同看花。', category: '日常', unlocked: true,
  sourceMemoryIds: [memoryId], sourceMemoryAnchor: `锚点${memoryId.slice(1)}`,
  visualSeed: ['人物', '庭院', '花', '光线'], imagePrompt: 'two people, garden',
  comments: ['一同看花。', '风从庭院吹来。', '花瓣落在衣袖上。', '他们在树下交谈。'], ...extra });
const session = entries => ({ kind: 'album', entries, selectedId: entries[0]?.id || '',
  category: '全部', page: 1, pageSize: 6, title: '回忆相簿' });
function inView(value, action) {
  const prior = state.activeSession;
  state.activeSession = value;
  try { return action(); } finally { state.activeSession = prior; }
}

test('generation evidence puts an explicitly earlier story date before a later date', () => {
  assert.deepEqual(payloadIds(['2025/09/20', '2025/09/01']), ['M2', 'M1']);
});
test('Gregorian numeric and Chinese date spellings share the same chronology', () => {
  assert.deepEqual(payloadIds(['2025年9月20日', '2025-09-01', '2024.12.31']), ['M3', 'M2', 'M1']);
});
test('unknown dates stay at their original positions while comparable dates reorder', () => {
  assert.deepEqual(payloadIds(['2025/09/20', '很久以前', '2025/09/01', '未标注']), ['M3', 'M2', 'M1', 'M4']);
});
test('same-day records retain original relative order, without using wall-clock time', () => {
  assert.deepEqual(payloadIds(['2025/09/20', '2025-09-20', '2025年9月20日']), ['M1', 'M2', 'M3']);
});
test('missing year, relative dates, ranges and unknown dates do not imply a year', () => {
  const dates = ['12/31', '01/01', '昨日', '明日', '2025/09/01—2025/09/03', '', undefined];
  assert.deepEqual(payloadIds(dates), ['M1', 'M2', 'M3', 'M4', 'M5', 'M6', 'M7']);
});
test('impossible Gregorian dates keep their positions and never block other entries', () => {
  assert.deepEqual(payloadIds(['2025/09/20', '2025/02/29', '2025/09/01', '2025/13/01']), ['M3', 'M2', 'M1', 'M4']);
});
test('explicit dates within the same named era can order without a Gregorian conversion', () => {
  assert.deepEqual(payloadIds(['永宁三年九月初二', '永宁二年十二月三十日', '永宁三年九月初一']), ['M2', 'M3', 'M1']);
});
test('different eras retain their own positions and are never equated to Gregorian years', () => {
  assert.deepEqual(payloadIds(['永宁三年九月二日', '星历12年13月2日', '2025/09/20',
    '永宁二年九月二日', '星历11年13月2日', '2025/09/01']), ['M4', 'M5', 'M6', 'M1', 'M2', 'M3']);
});
test('leap-year dates are comparable and preserve the original strings', () => {
  const output = memoryPayload(bank(['2024/03/01', '2024/02/29']));
  assert.deepEqual(output.map(row => row.date), ['2024/02/29', '2024/03/01']);
});
test('original evidence sampling membership is unchanged, only selected rows reorder', () => {
  const value = bank(['2025/09/20', '2020/01/01', '2021/01/01', '2022/01/01', '2025/09/10',
    '2023/01/01', '2024/01/01', '2025/01/01', '2025/09/01']);
  assert.deepEqual(ids(memoryPayload(value, null, 3)), ['M9', 'M5', 'M1']);
  assert.deepEqual(ids(memoryPayload(value, ['M1', 'M5', 'M9'], 2)), ['M5', 'M1']);
});
test('evidence sorting does not mutate the bank or change any selected record field', () => {
  const value = bank(['2025/09/20', '2025/09/01']);
  const before = JSON.stringify(value);
  const separately = value.memories.map(row => memoryPayload({ memories: [row] })[0]);
  const result = memoryPayload(value);
  assert.deepEqual(result, [separately[1], separately[0]]);
  assert.equal(JSON.stringify(value), before);
});
test('all-unknown evidence retains byte-identical existing field serialization', () => {
  const value = bank(['未标注', '待定']);
  const expected = value.memories.map(row => ({ id: row.id, date: row.date, title: row.title, summary: row.summary,
    anchors: row.anchors, participants: row.participants, messageRange: [row.messageStart, row.messageEnd],
    sourceKind: 'chat', externalSource: [] }));
  assert.equal(JSON.stringify(memoryPayload(value)), JSON.stringify(expected));
});
test('existing album prompt index uses story chronology without mutating or adding fields', () => {
  const value = session([entry('CG01', '2025/09/20', 'M1'), entry('CG02', '2025/09/01', 'M2')]);
  const before = JSON.stringify(value);
  assert.deepEqual(album.compactAlbumExisting(value), [value.entries[1], value.entries[0]].map(row => ({
    id: row.id, title: row.title, unlocked: true, sourceMemoryIds: row.sourceMemoryIds, sourceMemoryAnchor: row.sourceMemoryAnchor,
  })));
  assert.equal(JSON.stringify(value), before);
});
test('opening an existing unsorted album orders the list while preserving unknown slots', () => {
  const value = session([entry('late', '2025/09/20', 'M1'), entry('unknown', '待定', 'M2'), entry('early', '2025/09/01', 'M3')]);
  const before = JSON.stringify(value);
  inView(value, () => {
    assert.deepEqual(ids(view.filteredAlbumEntries()), ['early', 'unknown', 'late']);
    assert.equal(view.selectedAlbumEntry(), value.entries[0]);
  });
  assert.equal(JSON.stringify(value), before);
});
test('actual incremental album output reads chronologically and preserves old images, prose and selection', () => {
  const old = entry('CG01', '2025/09/20', 'M1', { cgImage: { url: '/old.webp', prompt: 'OLD_IMAGE', generatedAt: 1 },
    customNote: 'OLD_NOTE', favorite: true });
  const previous = session([old]);
  const fresh = session([entry('CG01', '2025/09/01', 'M2')]);
  const before = structuredClone([previous, fresh]);
  const merged = album.mergeAlbumIncremental(previous, fresh, bank(['2025/09/20', '2025/09/01']));
  inView(merged, () => {
    assert.deepEqual(ids(view.filteredAlbumEntries()), ['CG02', 'CG01']);
    assert.deepEqual(view.selectedAlbumEntry(), old);
  });
  assert.deepEqual(merged.entries.find(row => row.id === 'CG01'), old);
  assert.deepEqual([previous, fresh], before);
});
test('album date categories are filtered from the same chronological view without changing categories', () => {
  const value = session([entry('late', '2025/09/20', 'M1'), entry('other', '2025/09/10', 'M2', { category: '约会' }),
    entry('early', '2025/09/01', 'M3')]);
  value.category = '日常';
  inView(value, () => assert.deepEqual(ids(view.filteredAlbumEntries()), ['early', 'late']));
  assert.equal(value.entries[1].category, '约会');
});
test('partial album keeps completed comments bound to the correct ID after display sorting', () => {
  const value = bank(['2025/09/20', '2025/09/01']);
  const rows = [entry('CG01', '2025/09/20', 'M1'), entry('CG02', '2025/09/01', 'M2')];
  const segment = (slot, raw) => ({ slot, state: typeof raw === 'string' ? 'truncated' : 'complete',
    ...parsePartialJsonObject(typeof raw === 'string' ? raw : JSON.stringify(raw)) });
  const segments = [segment('album:index', { entries: rows }),
    segment('album:comments:0', '{"items":[{"id":"CG01","comments":["已经收到的第一句","已经收到的第二句","尚未完整')];
  const before = JSON.stringify(segments.map(row => row.value));
  const result = album.projectAlbumProgress({ segments, memoryBank: value });
  inView(result, () => {
    assert.deepEqual(ids(view.filteredAlbumEntries()), ['CG02', 'CG01']);
    assert.deepEqual(view.filteredAlbumEntries().find(row => row.id === 'CG01').comments, ['已经收到的第一句', '已经收到的第二句']);
  });
  assert.equal(JSON.stringify(segments.map(row => row.value)), before);
});

test('album relationship request keeps selected detail membership and orders its two indexes', () => {
  const value = bank(Array.from({ length: 15 }, (_, i) => `2025/09/${String(20 - i).padStart(2, '0')}`));
  const before = JSON.stringify(value);
  const result = JSON.parse(album.albumRelationshipArchiveSlice(value));
  assert.deepEqual(result.memories.map(row => row[0]), value.memories.map(row => row.id).reverse());
  assert.deepEqual(result.relationshipDetails.map(row => row.id), value.memories.slice(-12).map(row => row.id).reverse());
  assert.equal(JSON.stringify(value), before);
});

test('album prompt sampling still chooses the original records before chronological display order', () => {
  const value = session(Array.from({ length: 125 }, (_, i) => entry(`CG${i}`, i === 124 ? '2020/01/01' : '2025/01/01', 'M1')));
  const selected = Array.from({ length: 120 }, (_, i) => `CG${Math.round(i * 124 / 119)}`);
  assert.deepEqual(ids(album.compactAlbumExisting(value)), ['CG124', ...selected.slice(0, -1)]);
});

test('chronological view retains the original objects including image and user metadata', () => {
  const rows = [entry('late', '2025/09/20', 'M1', { cgImage: { url: '/old.png' }, note: '手写备注' }),
    entry('early', '2025/09/01', 'M2')];
  const before=JSON.stringify(rows), result=sortByStoryDate(rows);
  assert.equal(result[1], rows[0]);
  assert.equal(result[0], rows[1]);
  assert.equal(JSON.stringify(rows), before);
});

test('approved freeze delta restores the exact old source and rejects any additional change', async () => {
  for (const [file, spec] of Object.entries(phase4ChronologyDeltas)) {
    const current=phase7ApprovedSource(file,await readFile(new URL('../'+file, import.meta.url),'utf8'));
    const previous=phase4ChronologyApprovedSource(file,current);
    assert.equal(createHash('sha256').update(previous).digest('hex'),spec.beforeSha256);
    assert.equal(phase4ChronologyApprovedSource(file,previous),previous);
    assert.throws(()=>phase4ChronologyApprovedSource(file,current+'\n// unapproved extra\n'),/unreviewed/);
  }
});
