// r8430: archive draft storage conditions.
// - Draft rows store the full source snapshot once (inputs.taskInputV1), not a
//   second time inside inputs.progress; old double-copy rows still load.
// - Over-limit sources fail with RMT_ARCHIVE_DRAFT_CAPACITY before any storage
//   transaction and before any model request; original records stay untouched.
// - Quota / CAS / acknowledgement-mismatch save failures keep code
//   RMT_ARCHIVE_DRAFT_STORAGE but name their exact manual remedy. No automatic
//   retry is added anywhere; the healthy path still saves before requesting.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import * as L from '../src/core/localRecoveryStore.js';
import * as D from '../src/archive/importRecovery.js';
import * as R from '../src/archive/repository.js';
import * as context from '../src/core/context.js';
import { localFixture, fixedOrigin } from './helpers/r8425LocalHost.mjs';
import { archiveFixture, memoryReply, requestRows } from './helpers/r8422ArchiveHost.mjs';

const clone = value => structuredClone(value);
const sha = value => createHash('sha256').update(JSON.stringify(value)).digest('hex');
const begin = (origin, extra = {}) => D.beginArchiveRecovery({ origin,
    sourceIdentity: 'stable', sourceFragments: ['stable source'], settingsIdentity: 'same', ...extra });
const reject = promise => promise.then(() => null, error => error);
const profileReply = () => ({ archiveName: '一同栽花', verdictStyle: 'quiet-life',
    relationshipReading: { char: '共同栽花', user: '共同参与', relation: '相伴', tension: '未记载', direction: '相伴' },
    archiveVerdict: '两个人一起在庭院栽花，这份记录呈现的是他们共同参与一件小事的经历。花苗慢慢立在土中，他们的关系仍应由已经发生的事实来理解，不需要提前给尚未表达的感情加上名字。对话没有说明更远的约定，档案也只留下这次相伴本身，以及两人愿意共同花费的时间。',
    verdictSources: [{ memoryId: 'M001', anchor: '庭院' }], keywords: ['庭院', '栽花'] });
const validReply = messages => requestRows(messages).kind === 'profile' ? profileReply() : memoryReply(messages);
// Interrupt the first provider request so the task fails with a retained draft.
function failFirstRequest(f) {
    let calls = 0;
    f.setResponse(messages => { calls += 1; if (calls === 1) throw Object.assign(new Error('synthetic interrupted request'), { code: 'RMT_JSON_INVALID' }); return validReply(messages); });
}
// Default read range keeps the last 50 floors; 50 x 100k chars is ~15MB UTF-8.
function pushBigChat(f, count = 50, length = 100000) {
    const line = '长'.repeat(length);
    for (let i = 0; i < count; i += 1) {
        f.ctx.chat.push({ is_user: i % 2 === 0, name: i % 2 === 0 ? f.ctx.name1 : f.ctx.name2, mes: `${line}【${i}】` });
    }
}
function countCalls(backend) {
    const counters = { reads: 0, compares: 0 };
    const realRead = backend.read, realCompare = backend.compare;
    backend.read = async (...args) => { counters.reads += 1; return realRead(...args); };
    backend.compare = async (...args) => { counters.compares += 1; return realCompare(...args); };
    return counters;
}

test('over-limit inputs: RMT_ARCHIVE_DRAFT_CAPACITY before any write transaction, no request, records untouched', async t => {
    const local = localFixture(t);
    const origin = fixedOrigin();
    const calls = countCalls(local.backend);
    const big = '据'.repeat(4.2 * 1000 * 1000); // ~12.6MB UTF-8 as a single copy
    const inputs = { taskInputV1: { version: 1, digest: 'x', data: { snapshot: { messages: big } } } };
    const error = await reject(begin(origin, { inputs }));
    assert.equal(error?.code, 'RMT_ARCHIVE_DRAFT_CAPACITY');
    assert.match(error.message, /超过本机草稿保存上限（12MB）/);
    assert.match(error.message, /未请求模型/);
    assert.match(error.message, /缩小读取范围或分批建档/);
    assert.equal(calls.compares, 0, 'the byte check throws before any write transaction');
    assert.equal(local.writes(), 0);
    assert.equal(local.records.size, 0, 'original records untouched');
    const summary = D.archiveRecoverySummary(origin);
    assert.deepEqual({ completed: summary?.completed, pageOnly: summary?.pageOnly }, { completed: 0, pageOnly: true },
        'the draft stays page-only with nothing generated and no request dispatched');
    // A manual save retry with the same oversized inputs fails the same way,
    // still without reaching storage.
    const retry = await reject(D.flushArchiveRecovery(origin));
    assert.equal(retry?.code, 'RMT_ARCHIVE_DRAFT_CAPACITY');
    assert.equal(calls.compares, 0);
});

test('single-copy inputs just under the limit save cleanly', async t => {
    const local = localFixture(t);
    const origin = fixedOrigin();
    const payload = '界'.repeat(3.9 * 1000 * 1000); // ~11.7MB UTF-8, stored once
    const inputs = { taskInputV1: { version: 1, digest: 'x', data: { snapshot: { messages: payload } } } };
    const ticket = await begin(origin, { inputs });
    assert.ok(ticket, 'a source that fits as one copy is not rejected');
    assert.equal(local.writes(), 1);
    D.releaseArchiveRecovery(ticket);
});

test('plan preflight uses the same serialization and byte limit as the save itself', async t => {
    localFixture(t);
    const origin = fixedOrigin();
    assert.equal(D.archiveRecoveryDraftPlanExceedsCapacity(origin, 'import', { note: 'small' }), false);
    assert.equal(D.archiveRecoveryDraftPlanExceedsCapacity({}, 'import', { note: 'small' }), false, 'no scope key, no opinion');
    const big = { taskInputV1: { data: { snapshot: '据'.repeat(4.2 * 1000 * 1000) } } };
    assert.equal(D.archiveRecoveryDraftPlanExceedsCapacity(origin, 'import', big), true);
});

test('repository: over-limit source fails before storage, request or draft creation; archive unchanged', async t => {
    const f = await archiveFixture(t, { rows: [] });
    const local = localFixture(t);
    const calls = countCalls(local.backend);
    pushBigChat(f);
    const before = clone(R.getImportedMemory(f.ctx));
    f.setResponse(validReply);
    const result = await R.importCurrentChatMemory();
    assert.equal(result.status, 'failed', JSON.stringify(f.notices));
    assert.ok(f.notices.some(row => row.kind === 'error' && String(row.message).includes('超过本机草稿保存上限（12MB）')),
        `capacity guidance shown: ${JSON.stringify(f.notices)}`);
    assert.equal(f.requests.length, 0, 'no provider request');
    assert.equal(calls.reads, 1, 'only the pre-existing preparation hydrate reads the draft scope');
    assert.equal(calls.compares, 0, 'preflight fires before any write transaction');
    assert.equal(local.records.size, 0, 'nothing was written');
    assert.deepEqual(R.getImportedMemory(f.ctx), before, 'original archive record untouched');
    const origin = context.captureTaskOrigin(f.ctx, before.archiveRevision);
    assert.equal(D.archiveRecoverySummary(origin), null, 'no draft was created');
});

test('repository: a source that fits as one snapshot copy is not rejected', async t => {
    const f = await archiveFixture(t, { rows: [] });
    localFixture(t);
    // The draft row holds the captured input (~4x chat bytes: working,
    // incremental and fingerprint snapshots) plus the per-segment request
    // journal (~1x). ~1.8MB of chat peaks around 9-10MB: over the old
    // double-write limit (~14MB), under the single-copy limit.
    pushBigChat(f, 20, 30000);
    f.setResponse(validReply);
    const result = await R.importCurrentChatMemory();
    assert.equal(result.status, 'committed', JSON.stringify(f.notices));
    assert.ok(f.requests.length >= 1, 'the fitting task really requested the model');
});

test('quota write failure: STORAGE with manual remedy, one save attempt, user retry succeeds', async t => {
    const local = localFixture(t);
    const origin = fixedOrigin();
    const calls = countCalls(local.backend);
    local.fail(true); // backend compare throws DOMException QuotaExceededError
    const error = await reject(begin(origin));
    assert.equal(error?.code, 'RMT_ARCHIVE_DRAFT_STORAGE');
    assert.match(error.message, /本机存储空间不足/);
    assert.match(error.message, /清理浏览器站点数据后可点保存重试/);
    assert.match(error.message, /原记录未修改/);
    assert.equal(calls.compares, 1, 'exactly one save attempt; no automatic retry');
    assert.equal(local.writes(), 0);
    assert.equal(local.records.size, 0, 'nothing was written over');
    // The page draft is retained; a user-initiated retry succeeds once storage recovers.
    local.fail(false);
    assert.equal(await D.flushArchiveRecovery(origin), true);
    assert.equal(local.writes(), 1);
    assert.equal(calls.compares, 2, 'a retry happens only because the user asked');
});

test('acknowledgement mismatch: STORAGE with reopen-and-save guidance', async t => {
    const local = localFixture(t);
    const origin = fixedOrigin();
    const realCompare = local.backend.compare;
    local.backend.compare = async (key, revision, payload) => { await realCompare(key, revision, payload); return revision + 2; };
    const error = await reject(begin(origin));
    assert.equal(error?.code, 'RMT_ARCHIVE_DRAFT_STORAGE');
    assert.match(error.message, /回执与预期不一致/);
    assert.match(error.message, /重新打开本页后重试保存/);
    assert.equal(local.writes(), 1, 'the write itself landed; only the receipt mismatched');
});

test('concurrent-writer CAS: STORAGE with reopen-and-save guidance, nothing overwritten', async t => {
    const local = localFixture(t);
    const origin = fixedOrigin();
    local.backend.compare = async () => { throw Object.assign(new Error('synthetic CAS'), { code: 'RMT_LOCAL_CAS' }); };
    const error = await reject(begin(origin));
    assert.equal(error?.code, 'RMT_ARCHIVE_DRAFT_STORAGE');
    assert.match(error.message, /没有覆盖任何记录/);
    assert.match(error.message, /重新打开本页后重试保存/);
    assert.equal(local.writes(), 0);
});

test('local store flags quota transaction failures with a content-free marker', async t => {
    const old = Object.getOwnPropertyDescriptor(globalThis, 'indexedDB');
    L.setLocalRecoveryBackendForTests(null);
    const tx = {
        abort() { tx.error = new DOMException('synthetic quota', 'QuotaExceededError'); queueMicrotask(() => tx.onabort?.()); },
        objectStore() {
            return {
                get() { const req = {}; setImmediate(() => req.onsuccess?.()); return req; },
                put() { queueMicrotask(() => tx.abort()); return {}; },
            };
        },
    };
    const db = { objectStoreNames: { contains: () => true }, transaction: () => tx, close() {} };
    Object.defineProperty(globalThis, 'indexedDB', { configurable: true,
        value: { open() { const request = { result: db }; setImmediate(() => request.onsuccess?.()); return request; } } });
    t.after(() => { L.setLocalRecoveryBackendForTests(null);
        if (old) Object.defineProperty(globalThis, 'indexedDB', old); else delete globalThis.indexedDB; });
    const error = await reject(L.compareLocalRecoveryRecord(`draft:${'a'.repeat(64)}`, 0, { version: 1, rows: [] }));
    assert.equal(error?.code, 'RMT_LOCAL_STORAGE');
    assert.equal(error?.quota, true, 'quota condition is marked for the caller');
    assert.equal(error.message, '浏览器未能保存本机记录；原记录保留，请勿刷新未保存的页面。', 'marker carries no raw browser text');
});

test('draft rows store the source snapshot once; serialized bytes drop the duplicate', async t => {
    const f = await archiveFixture(t, { rows: [] });
    const local = localFixture(t);
    const marker = `R8430-SNAPSHOT-MARKER-${'椿'.repeat(120)}`;
    f.ctx.chat.push({ is_user: true, name: f.ctx.name1, mes: marker },
        { is_user: false, name: f.ctx.name2, mes: '补充：傍晚两人一起收了花盆。' });
    failFirstRequest(f);
    assert.equal((await R.importCurrentChatMemory()).status, 'failed', JSON.stringify(f.notices));
    const origin = context.captureTaskOrigin(f.ctx, R.getImportedMemory(f.ctx).archiveRevision);
    await D.flushArchiveRecovery(origin);
    const draft = D.exportArchiveRecovery(origin)[0];
    assert.ok(draft?.inputs?.taskInputV1, 'the original source snapshot is still saved');
    assert.ok(draft.inputs.progress, 'batch progress is still saved with the draft');
    assert.equal(Object.hasOwn(draft.inputs.progress, 'taskInputV1'), false, 'no second snapshot copy inside progress');
    const inInputs = JSON.stringify(draft.inputs).split(marker).length - 1;
    const inSnapshot = JSON.stringify(draft.inputs.taskInputV1).split(marker).length - 1;
    assert.ok(inSnapshot > 0, 'the marker really lives in the saved snapshot');
    assert.equal(inInputs, inSnapshot, 'every snapshot byte in the draft row comes from the single top-level copy');
    const stored = JSON.stringify([...local.records.values()].map(record => record.payload));
    assert.equal(stored.split('"taskInputV1"').length - 1, 1, 'serialized rows contain exactly one taskInputV1 key');
});

test('old double-copy draft rows load unchanged and resume to commit', async t => {
    const f = await archiveFixture(t, { rows: [] });
    const local = localFixture(t);
    f.ctx.chat.push({ is_user: true, name: f.ctx.name1, mes: '旧格式草稿来源：两人傍晚一起收拾庭院。' });
    failFirstRequest(f);
    assert.equal((await R.importCurrentChatMemory()).status, 'failed', JSON.stringify(f.notices));
    const origin = context.captureTaskOrigin(f.ctx, R.getImportedMemory(f.ctx).archiveRevision);
    await D.flushArchiveRecovery(origin);
    // Rewrite the stored row into the pre-r8430 shape: a second full snapshot
    // copy inside inputs.progress, with the journal inputs hash updated to match.
    const record = [...local.records.values()][0];
    const row = record.payload.rows[0][1];
    assert.ok(row?.inputs?.taskInputV1 && row.inputs.progress && row.journal?.contentSnapshot?.archiveInputsHash);
    row.inputs.progress.taskInputV1 = row.inputs.taskInputV1;
    row.journal.contentSnapshot.archiveInputsHash = sha(row.inputs);
    local.records.set(record.key, record);
    D.resetArchiveRecoveryMemoryForTests();
    await D.hydrateArchiveRecovery(origin);
    const loaded = D.archiveRecoveryInputs(origin);
    assert.ok(loaded?.taskInputV1 && loaded?.progress?.taskInputV1, 'old rows keep both copies when read');
    assert.equal(loaded.progress.taskInputV1.digest, loaded.taskInputV1.digest);
    f.setResponse(validReply);
    const result = await R.continueCurrentArchiveImport({ draftId: D.listArchiveRecoveryDrafts(origin)[0].draftId });
    assert.equal(result.status, 'committed', JSON.stringify(f.notices));
    assert.ok(R.getImportedMemory(f.ctx).memories.length > 1, 'the resumed task committed its received chunks');
});

test('new single-copy draft rows resume to commit identically', async t => {
    const f = await archiveFixture(t, { rows: [] });
    localFixture(t);
    f.ctx.chat.push({ is_user: true, name: f.ctx.name1, mes: '新格式草稿来源：两人清晨一起给花浇水。' });
    failFirstRequest(f);
    assert.equal((await R.importCurrentChatMemory()).status, 'failed', JSON.stringify(f.notices));
    const origin = context.captureTaskOrigin(f.ctx, R.getImportedMemory(f.ctx).archiveRevision);
    await D.flushArchiveRecovery(origin);
    D.resetArchiveRecoveryMemoryForTests();
    await D.hydrateArchiveRecovery(origin);
    const loaded = D.archiveRecoveryInputs(origin);
    assert.ok(loaded?.taskInputV1 && loaded?.progress, 'the saved inputs reload after a page refresh');
    assert.equal(Object.hasOwn(loaded.progress, 'taskInputV1'), false, 'new rows stay single-copy when read');
    f.setResponse(validReply);
    const result = await R.continueCurrentArchiveImport({ draftId: D.listArchiveRecoveryDrafts(origin)[0].draftId });
    assert.equal(result.status, 'committed', JSON.stringify(f.notices));
});

test('healthy path still confirms the draft save before the first model request', async t => {
    const f = await archiveFixture(t, { rows: [] });
    const local = localFixture(t);
    f.ctx.chat.push({ is_user: true, name: f.ctx.name1, mes: '健康路径：两人一起给花浇水。' });
    // The host double pauses inside the transport boundary of the first request.
    const gate = f.pauseProvider();
    f.setResponse(validReply);
    const run = R.importCurrentChatMemory();
    await gate.ready;
    assert.ok(local.writes() >= 1, 'the initial draft save was confirmed before the first request');
    gate.release();
    const result = await run;
    assert.equal(result.status, 'committed', JSON.stringify(f.notices));
    assert.ok(f.requests.length >= 1, 'the task actually requested the model');
});
