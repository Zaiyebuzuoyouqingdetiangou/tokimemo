import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './helpers/r847Host.mjs';
import * as settings from '../src/core/settings.js';
import * as tags from '../src/core/contextTags.js';
import { buildChatSnapshot } from '../src/core/context.js';

for(const [name,raw,selected,expected] of [
 ['nested image prompt','<content>正文<image_prompt>不读绘图词</image_prompt>后文</content>',['image_prompt'],'<content>正文后文</content>'],
 ['exclude outer','外部<content>正文<image_prompt>不读</image_prompt></content>尾',['content'],'外部尾'],
 ['empty selection','<content>正文</content>',[],'<content>正文</content>'],
 ['encoded block','前&lt;thinking&gt;不读&lt;/thinking&gt;后',['thinking'],'前后'],
 ['unclosed block','前<thinking>不读',['thinking'],'前'],
])test(`checked labels are excluded: ${name}`,async t=>{
 const f=await fixture(t);
 settings.updatePluginSettings({contextTagMode:'exclude',excludedContextTags:selected});
 assert.equal(tags.filterContextTags(raw,tags.tagPolicyForContext(f.ctx)),expected);
 assert.deepEqual(settings.getPluginSettings(f.ctx).excludedContextTags,selected);
});
test('chat snapshot excludes checked nested text and keeps live chat unchanged',async t=>{
 const f=await fixture(t);f.ctx.chat=[{name:'林舟',is_user:false,mes:'<content>庭院正文<image_prompt>DRAW_SECRET</image_prompt>末尾</content>'}];
 const original=JSON.stringify(f.ctx.chat);
 settings.updatePluginSettings({contextTagMode:'exclude',excludedContextTags:['image_prompt']});
 const result=await buildChatSnapshot(f.ctx,{completeSource:true});
 assert.match(JSON.stringify(result.messages),/庭院正文/);
 assert.doesNotMatch(JSON.stringify(result.messages),/DRAW_SECRET/);
 assert.equal(JSON.stringify(f.ctx.chat),original);assert.equal(f.requests.length,0);
});
