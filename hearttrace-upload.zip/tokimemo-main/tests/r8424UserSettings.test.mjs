import test from 'node:test';
import assert from 'node:assert/strict';
import { archiveFixture, sourceRows, memoryReply, requestRows, clickImport, clone } from './helpers/r8422ArchiveHost.mjs';
import * as output from '../src/core/outputBudget.js';
import * as tags from '../src/core/contextTags.js';
import * as settings from '../src/core/settings.js';
import * as context from '../src/core/context.js';
import * as client from '../src/generation/client.js';
import * as parser from '../src/generation/jsonParser.js';
import * as budget from '../src/archive/requestBudget.js';
import * as R from '../src/archive/repository.js';
import * as B from '../src/archive/importBatches.js';
import * as C from '../src/core/constants.js';
import * as ledger from '../src/archive/sourceLedger.js';
import * as recovery from '../src/archive/importRecovery.js';
import * as guard from '../src/archive/sourceReadGuard.js';
import { state } from '../src/core/state.js';
const keep = names => ({ mode: 'keep', tags: names });

for (const count of [1, 1024, 16384, 60000, 60001, 120000, 1000000]) test(`max output ${count}: settings -> archive measurement -> actual profile request, no ceiling/floor override`, async t => {
    const f = await archiveFixture(t); settings.updatePluginSettings({maxTokens: count});
    assert.equal(settings.getPluginSettings(f.ctx).maxTokens, count);
    const measured = await budget.measureArchiveRequest(f.ctx, '合成输入'); assert.equal(measured.outputTokens, count);
    let sent; const original=f.ctx.ConnectionManagerRequestService.sendRequest;
    const profile=settings.rawConnectionProfile(settings.getPluginSettings(f.ctx).connectionProfileId,f.ctx);
    f.ctx.ConnectionManagerRequestService.sendRequest = (id,messages,n,opts,overridePayload) => {
        const payload={secret_id:profile['secret-id'],model:profile.model,...overridePayload};
        assert.equal(payload.model,'fixture-model');sent=n;return original(id,messages,n,opts,overridePayload);
    };
    f.setResponse({ok:true});
    assert.deepEqual(await client.generateConfiguredJson('合成任务', { context: f.ctx, contextEnvelope: '', maxTokens: 2048 }), {ok:true});
    assert.equal(sent,count,'old per-feature hint is not a hidden reduction'); assert.equal(f.requests.length,1);
});

test('60000 is only the absent/empty default; existing legitimate stored values remain unchanged', async t => {
    const f=await archiveFixture(t); delete f.ctx.extensionSettings.heartbeatMemories.maxTokens;
    assert.equal(settings.getPluginSettings(f.ctx).maxTokens,60000);
    for(const value of [undefined,null,'', '   ',0,-1,1.5,NaN,Infinity,{},'invalid']) assert.equal(output.normalizeOutputTokens(value),60000);
    for(const value of [12000,'240000','1']) assert.equal(output.normalizeOutputTokens(value),Number(value));
    for(const value of [NaN,Infinity,-1,0,{},true,'1.5']) assert.equal(output.isValidOutputTokens(value),false);
    f.ctx.extensionSettings.heartbeatMemories.maxTokens=16384;assert.equal(settings.getPluginSettings(f.ctx).maxTokens,16384);
});

for (const format of ['json','sse']) test(`manual ${format} response: 120000 output reaches exact existing endpoint/model; no extra call`, async t => {
    const f=await archiveFixture(t);settings.updatePluginSettings({apiConnectionMode:'manual',manualApiBaseUrl:'https://fixture.invalid/api/v1',manualApiModel:'same-fixture',manualApiKey:'',manualApiStreaming:format==='sse',maxTokens:120000});
    const calls=[];globalThis.fetch=async(url,options)=>{
        const body=JSON.parse(options.body);calls.push({url,body});
        const content=JSON.stringify({ok:true});
        return new Response(format==='json'?JSON.stringify({choices:[{message:{content},finish_reason:'stop'}]}):`data: ${JSON.stringify({choices:[{delta:{content},finish_reason:'stop'}]})}\n\ndata: [DONE]\n\n`,{headers:format==='json'?{'content-type':'application/json'}:{}});
    };
    assert.deepEqual(await client.requestJson('合成任务','',{background:true}),{ok:true});
    assert.equal(calls.length,1);assert.equal(calls[0].url,'/api/backends/chat-completions/generate');
    assert.equal(calls[0].body.custom_url,'https://fixture.invalid/api/v1');assert.equal(calls[0].body.model,'same-fixture');assert.equal(calls[0].body.max_tokens,120000);
    assert.equal(calls[0].body.stream,format==='sse');
});

test('budget errors report actual configured/request allowance, never a fictitious 60000 maximum',()=>{
    const label=parser.jsonOutputBudgetSummary({requestMaxTokens:120000,configuredMaxTokens:120000});
    assert.ok(label.includes('120,000'));assert.ok(!label.includes('允许最高'));assert.ok(!label.includes('60,000'));
    assert.throws(()=>parser.extractJson('',{requestMaxTokens:120000,configuredMaxTokens:120000}), e=> e.code==='RMT_JSON_EMPTY_FINAL' && e.message.includes('120,000') && !e.message.includes('允许最高'));
});

test('known synthetic model capacity is still checked; unknown does not become a plugin maximum',async t=>{
    const f=await archiveFixture(t);settings.updatePluginSettings({maxTokens:120000});f.ctx.getTokenCountAsync=async()=>47030;
    const value=await budget.measureArchiveRequest(f.ctx,'合成输入');assert.equal(value.combinedTokens,167030);assert.equal(value.exceeded,null);
    const known=await budget.measureArchiveRequest(f.ctx,'合成输入',{confirmedLimits:{contextTokens:128000,maximumOutputTokens:100000}});
    assert.notEqual(known.exceeded,null);
});

test('legacy exclusion mode is unchanged until an explicit keep save; not an automatic settings migration',async t=>{
    const f=await archiveFixture(t);delete f.ctx.extensionSettings.heartbeatMemories.contextTagMode;
    const raw='前<thinking>弃</thinking><正文>保留</正文>后';
    assert.equal(tags.filterContextTags(raw,tags.tagPolicyForContext(f.ctx)),'前<正文>保留</正文>后');
    assert.deepEqual(tags.savedTagSelection(settings.getPluginSettings(f.ctx)),{});
    assert.equal(f.ctx.extensionSettings.heartbeatMemories.contextTagMode,undefined);
});

for(const [name,raw,selected,expected] of [
 ['raw siblings','前<keep>留</keep><drop>弃</drop>后',['keep'],'前<keep>留</keep>后'],
 ['nested unselected outer','前<drop><keep>弃</keep></drop>后',['keep'],'前后'],
 ['nested unselected child','<keep>甲<drop>弃</drop>乙</keep>',['keep'],'<keep>甲乙</keep>'],
 ['all selected','<keep>甲<drop>乙</drop></keep>',['keep','drop'],'<keep>甲<drop>乙</drop></keep>'],
 ['no selections','前<keep>弃</keep>后',[],'前后'],
 ['plain only','不含标签的正文',[],'不含标签的正文'],
 ['entity encoded','前&lt;drop&gt;弃&lt;/drop&gt;&lt;keep&gt;留&lt;/keep&gt;后',['keep'],'前&lt;keep&gt;留&lt;/keep&gt;后'],
 ['twice escaped','前&amp;lt;drop&amp;gt;弃&amp;lt;/drop&amp;gt;后',[],'前后'],
 ['quoted angle','甲<drop title="a>b">弃</drop>乙',[],'甲乙'],
 ['unclosed discard','甲<drop>弃',['keep'],'甲'],
 ['unclosed retained','甲<keep>留',['keep'],'甲<keep>留'],
 ['self closing discard','甲<drop />乙',[],'甲乙'],
 ['Unicode and case','<正文>甲</正文><KEEP>乙</KEEP><其余>弃</其余>',['正文','keep'],'<正文>甲</正文><KEEP>乙</KEEP>'],
 ['unseen tag excluded','<newtag>弃</newtag><keep>留</keep>',['keep'],'<keep>留</keep>'],
]) test('retained labels reuse isolation semantics: '+name,()=>assert.equal(tags.filterContextTags(raw,keep(selected)),expected));

test('more than32/100 retained tags survive normalization and a real settings round trip',async t=>{
    const f=await archiveFixture(t);const names=Array.from({length:360},(_,i)=>'tag'+i);
    settings.updatePluginSettings({contextTagMode:'keep',retainedContextTags:names});
    assert.deepEqual(settings.getPluginSettings(f.ctx).retainedContextTags,names);
    const raw=names.map(name=>`<${name}>记${name}</${name}>`).join('');
    assert.equal(tags.filterContextTags(raw,tags.tagPolicyForContext(f.ctx)),raw);
    assert.equal(tags.normalizeExcludedTags([...names,...names]).length,360);
    assert.ok(!tags.normalizeExcludedTags(['__proto__','<script onload=evil>']).length);
});

test('scanner includes the first of >500 messages, long text tail, and >100 labels without truncation',async()=>{
    const messages=[{mes:'<first>早期</first>'},...Array.from({length:520},(_,i)=>({mes:`<tag${i}>正常</tag${i}>`})),{mes:'常'.repeat(300000)+'<last>末尾</last>'}];
    const result=await tags.scanContextTagChoices(messages);
    assert.equal(result.usedMessages,522);assert.equal(result.tags.length,522);assert.equal(result.tags[0].name,'first');assert.equal(result.tags.at(-1).name,'last');assert.equal(result.bounded,false);
});

test('complete tag scan yields to lifecycle cancellation rather than retaining stale page results',async t=>{
    const now=Date.now;let clock=100;Date.now=()=>clock+=20;t.after(()=>{Date.now=now});
    let stale=false,checks=0;const timer=setTimeout(()=>{stale=true},0);
    await assert.rejects(tags.scanContextTagChoices([{mes:'中'.repeat(800000)+'<tail>末尾</tail>'}],{assertCurrent:()=>{checks++;if(stale)throw new DOMException('Changed','AbortError')}}),{name:'AbortError'});
    clearTimeout(timer);assert.ok(checks>1);
});

test('tag selection read guard binds chat, Persona, lifecycle and selected labels without opening storage',async t=>{
    const f=await archiveFixture(t);const check=guard.createSourceReadGuard(f.ctx);
    settings.updatePluginSettings({contextTagMode:'keep',retainedContextTags:['keep']});assert.throws(check,{name:'AbortError'});
    const next=guard.createSourceReadGuard(f.ctx);f.ctx.name1+='变';assert.throws(next,{name:'AbortError'});
});

test('JSON source values filtered; JSON keys and non-data instructions stay byte-identical',()=>{
    const raw='DO NOT CHANGE TASK\nDATA:'+JSON.stringify({'<drop>schemaKey</drop>':'甲<drop>弃</drop><keep>留</keep>','n':1,'array':['<drop>弃</drop>']})+'\nEND TASK';
    const result=tags.filterJsonPromptStrings(raw,keep(['keep']));assert.ok(result.startsWith('DO NOT CHANGE TASK\nDATA:'));assert.ok(result.endsWith('\nEND TASK'));
    assert.deepEqual(JSON.parse(result.slice(24,-9)),{'<drop>schemaKey</drop>':'甲<keep>留</keep>',n:1,array:['']});
});

test('whole-record tag isolation preserves original fragment positions and tail evidence IDs',()=>{
    const size=C.MAX_MEMORY_SOURCE_FRAGMENT_CHARS,raw='<drop>'+ '私'.repeat(size*4)+'</drop><keep>末尾共同庭院</keep>尾';
    const segments=tags.filterContextTagSegments(raw,keep(['keep']),size);
    assert.equal(segments.length,Math.ceil(raw.length/size));assert.equal(segments.slice(0,-1).join(''),'');assert.equal(segments.join(''),'<keep>末尾共同庭院</keep>尾');
    const rows=[{provider:'synthetic-file',sourceId:'whole',content:raw}];
    const original=R.normalizeExternalMemoryRecords(rows,{complete:true}), selected=R.normalizeExternalMemoryRecords(rows,{complete:true,tagPolicy:keep(['keep'])});
    assert.equal(selected.length,1);assert.equal(selected[0].externalId,original.at(-1).externalId);assert.equal(selected[0].content,'<keep>末尾共同庭院</keep>尾');assert.equal(rows[0].content,raw);
});

test('selected whole record and original ledger retained; scanned omission is not mislabelled a size limit',async t=>{
    const row={provider:'synthetic-file',sourceId:'whole',content:'前<drop>'+ '私'.repeat(12000)+'</drop><keep>共同庭院尾</keep>'};
    const f=await archiveFixture(t,{rows:[row]});settings.updatePluginSettings({contextTagMode:'keep',retainedContextTags:['keep']});
    const external=await R.currentMemorySourceLedgerExternal(f.ctx);assert.ok(!external.records.map(r=>r.content).join('').includes('私'));
    const stored=await ledger.readMemorySourceLedger(R.memorySourceScopeForContext(f.ctx));assert.equal(stored.records[0].fragments.join(''),row.content);
    assert.equal(external.sources[0].coverage.status,'complete');assert.ok(external.sources[0].coverage.reason.includes('标签选择'));
});

test('actual archive button -> selected source request -> canonical saved results -> restore -> manual next batch, no tag leak/re-numbered old Mxxx',async t=>{
    const rows=sourceRows(270,80).map(row=>({...row,content:row.content+'<drop>DROP_SENTINEL</drop><keep>共同庭院留存</keep>'}));
    const f=await archiveFixture(t,{rows});const old=clone(R.getImportedMemory(f.ctx).memories[0]);
    settings.updatePluginSettings({contextTagMode:'keep',retainedContextTags:['keep'],maxTokens:120000});
    for(let batch=1;batch<=2;batch++){
        await clickImport(f);const bank=R.getImportedMemory(f.ctx);assert.equal(bank[B.IMPORT_PROGRESS_KEY]?.nextBatch,batch,JSON.stringify(f.notices));
        assert.deepEqual(bank.memories[0],old);assert.ok(bank.memories.length>1);
        recovery.clearArchiveRecovery(context.captureTaskOrigin(f.ctx,bank.archiveRevision));state.memoryPreflightCache.clear();state.runtimeSessionCache.clear();
        f.ctx.chatMetadata[C.MEMORY_KEY]=clone(f.records.get(f.aEntry.entryId).memory);
    }
    const sent=f.requests.flatMap(m=>requestRows(m).rows);assert.equal(sent.length,270);assert.equal(new Set(sent.map(r=>r.externalId)).size,270);
    assert.ok(!JSON.stringify(f.requests).includes('DROP_SENTINEL'));assert.ok(JSON.stringify(f.requests).includes('共同庭院留存'));
});

test('changing saved tag choice prevents old batch continuation without deleting old results',async t=>{
    const f=await archiveFixture(t,{rows:sourceRows(270,80)});settings.updatePluginSettings({contextTagMode:'keep',retainedContextTags:['keep']});
    await clickImport(f);const old=clone(R.getImportedMemory(f.ctx)),calls=f.requests.length;
    settings.updatePluginSettings({retainedContextTags:['other']});await clickImport(f);
    assert.equal(f.requests.length,calls);assert.deepEqual(R.getImportedMemory(f.ctx),old);assert.ok(f.notices.some(n=>/来源|配置|选择/.test(n.message)));
});

test('changed output blocks old recovery ticket rather than silently sending old amount',async t=>{
    const f=await archiveFixture(t,{rows:sourceRows(270,80)});await clickImport(f);const old=clone(R.getImportedMemory(f.ctx)),calls=f.requests.length;
    settings.updatePluginSettings({maxTokens:240000});await clickImport(f);
    assert.equal(f.requests.length,calls);assert.deepEqual(R.getImportedMemory(f.ctx),old);
});

test('selection applies before chat chunking and does not edit live chat bytes',async t=>{
    const f=await archiveFixture(t);f.ctx.chat=[{name:'林舟',is_user:false,mes:'<drop>'+ '弃'.repeat(80000)+'</drop><keep>共同庭院正文</keep>尾'}];
    settings.updatePluginSettings({contextTagMode:'keep',retainedContextTags:['keep']});const before=clone(f.ctx.chat);
    const snap=await context.buildChatSnapshot(f.ctx,{completeSource:true});
    assert.ok(!JSON.stringify(snap.messages).includes('弃'));assert.ok(JSON.stringify(snap.messages).includes('共同庭院正文'));assert.deepEqual(f.ctx.chat,before);
});

test('changing retained labels during a real provider wait cannot commit stale archive results',async t=>{
    const f=await archiveFixture(t,{rows:sourceRows(2,200)});settings.updatePluginSettings({contextTagMode:'keep',retainedContextTags:['keep']});
    const old=clone(R.getImportedMemory(f.ctx)),pause=f.pauseProvider();const pending=clickImport(f);await pause.ready;
    settings.updatePluginSettings({retainedContextTags:['different']});pause.release();await pending;
    assert.deepEqual(R.getImportedMemory(f.ctx),old);assert.equal(f.requests.length,1);assert.equal(state.busy,false);
});

test('an entire long discarded tag cannot leak through actual archive source request and saved memory',async t=>{
    const content='<thinking>'+ 'OMIT_LONG_SENTINEL'.repeat(1800)+'</thinking><keep>两人共同在庭院栽花，并保留末尾证据。</keep>';
    const f=await archiveFixture(t,{rows:[{provider:'synthetic-file',sourceId:'whole-record',content}]});
    settings.updatePluginSettings({contextTagMode:'keep',retainedContextTags:['keep']});const old=clone(R.getImportedMemory(f.ctx).memories[0]);
    await clickImport(f);const bank=R.getImportedMemory(f.ctx);assert.equal(bank[B.IMPORT_PROGRESS_KEY]?.nextBatch,1,JSON.stringify(f.notices));
    assert.ok(!JSON.stringify(f.requests).includes('OMIT_LONG_SENTINEL'));assert.ok(!JSON.stringify(bank.memories).includes('OMIT_LONG_SENTINEL'));assert.deepEqual(bank.memories[0],old);
    const sent=f.requests.flatMap(messages=>requestRows(messages).rows);assert.equal(sent.length,1);assert.equal(sent[0].externalId,R.normalizeExternalMemoryRecords([{provider:'synthetic-file',sourceId:'whole-record',content}],{complete:true}).at(-1).externalId);
});

test('retaining no tags is a valid explicit selection, not a minimum-tag or rebuild gate',async t=>{
    const f=await archiveFixture(t,{rows:[{provider:'synthetic-file',sourceId:'empty-selection',content:'两人共同在庭院栽花。<thinking>OMIT_SENTINEL</thinking>末尾凭据。'}]});
    settings.updatePluginSettings({contextTagMode:'keep',retainedContextTags:[]});await clickImport(f);
    assert.equal(R.getImportedMemory(f.ctx)[B.IMPORT_PROGRESS_KEY]?.nextBatch,1,JSON.stringify(f.notices));assert.ok(!JSON.stringify(f.requests).includes('OMIT_SENTINEL'));
});

test('all original source fragment IDs stay unchanged when all encountered labels are selected',()=>{
    const rows=sourceRows(6,19000).map(r=>({...r,content:'<keep>'+r.content+'</keep>'}));
    const original=R.normalizeExternalMemoryRecords(rows,{complete:true});
    assert.deepEqual(R.normalizeExternalMemoryRecords(rows,{complete:true,tagPolicy:keep(['keep'])}),original);
});
