import test from 'node:test';
import assert from 'node:assert/strict';
import * as L from '../src/core/localRecoveryStore.js';
// Event-driven IndexedDB substitute: exercises the production open/transaction
// callbacks, not setLocalRecoveryBackendForTests. Not a native browser database.
function idb(t,{unsupported=false,abortWrite=false,failTransaction=false,hold=false,blocked=false}={}) {
    const old=Object.getOwnPropertyDescriptor(globalThis,'indexedDB');const rows=new Map(),transactions=[],waiting=[];let closes=0;
    L.setLocalRecoveryBackendForTests(null);
    function transaction(_store,mode,options) {
        transactions.push({mode,options});if(options&&unsupported)throw new TypeError('options unsupported');
        if(failTransaction)throw new DOMException('PRIVATE_SENTINEL','SecurityError');
        let aborted=false,pending,finished=false;
        const tx={abort(){if(finished)return;aborted=true;queueMicrotask(()=>tx.onabort?.());},objectStore(){return{
            get(key){const req={};setImmediate(()=>{if(aborted)return;req.result=structuredClone(rows.get(key));req.onsuccess?.();
                const finish=()=>{if(aborted||finished)return;if(mode==='readwrite'&&abortWrite){tx.abort();return;}finished=true;if(pending)rows.set(pending.key,structuredClone(pending));tx.oncomplete?.();};
                if(hold&&mode==='readwrite')waiting.push(finish);else setImmediate(finish);
            });return req;},put(record){pending=structuredClone(record);return{};}};}};
        return tx;
    }
    const db={objectStoreNames:{contains:()=>true},transaction,close(){closes++;}};
    Object.defineProperty(globalThis,'indexedDB',{configurable:true,value:{open(){const request={result:db};setImmediate(()=>blocked?request.onblocked?.():request.onsuccess?.());return request;}}});
    t.after(()=>{L.setLocalRecoveryBackendForTests(null);old?Object.defineProperty(globalThis,'indexedDB',old):delete globalThis.indexedDB;});
    return {rows,transactions,waiting,closes:()=>closes};
}
const draft='draft:'+'a'.repeat(64), credential='credential:00000000-0000-0000-0000-000000000000';
test('draft requests standard strict durability and resolves only after transaction complete',async t=>{
    const f=idb(t,{hold:true});let settled=false;const p=L.compareLocalRecoveryRecord(draft,0,{kept:41}).then(n=>{settled=true;return n;});
    for(let i=0;i<10&&!f.waiting.length;i++)await new Promise(r=>setImmediate(r));
    assert.equal(f.waiting.length,1);assert.equal(settled,false);assert.equal(f.rows.size,0);assert.equal(f.transactions[0].options.durability,'strict');
    f.waiting.shift()();assert.equal(await p,1);assert.equal(f.rows.get(draft).payload.kept,41);assert.equal(f.closes(),1);
});
test('older engine rejecting optional durability uses original atomic readwrite transaction',async t=>{
    const f=idb(t,{unsupported:true});assert.equal(await L.compareLocalRecoveryRecord(draft,0,{kept:41}),1);
    assert.equal(f.transactions.length,2);assert.equal(f.transactions[1].mode,'readwrite');assert.equal(f.transactions[1].options,undefined);
    assert.equal((await L.readLocalRecoveryRecord(draft)).payload.kept,41);
});
test('permission failure is not treated as unsupported option and not retried',async t=>{
    const f=idb(t,{failTransaction:true});await assert.rejects(L.compareLocalRecoveryRecord(draft,0,{kept:1}));assert.equal(f.transactions.length,1);assert.equal(f.rows.size,0);
});
test('aborted transaction never acknowledges or replaces the previous durable41',async t=>{
    const f=idb(t,{abortWrite:true});f.rows.set(draft,{key:draft,revision:41,payload:{kept:41}});
    await assert.rejects(L.compareLocalRecoveryRecord(draft,41,{kept:42}),{code:'RMT_LOCAL_STORAGE'});assert.equal(f.rows.get(draft).revision,41);assert.equal(f.rows.get(draft).payload.kept,41);
});
test('CAS mismatch and a persisted tombstone prevent stale writer resurrection',async t=>{
    const f=idb(t);await L.compareLocalRecoveryRecord(draft,0,{kept:41});assert.equal(await L.compareLocalRecoveryRecord(draft,1,null),2);
    await assert.rejects(L.compareLocalRecoveryRecord(draft,1,{kept:41}),{code:'RMT_LOCAL_CAS'});assert.equal((await L.readLocalRecoveryRecord(draft)).payload,null);
});
test('credential transaction behavior is unchanged by archive durability hint',async t=>{
    const f=idb(t);assert.equal(await L.compareLocalRecoveryRecord(credential,0,{synthetic:true}),1);assert.equal(f.transactions.length,1);assert.equal(f.transactions[0].options,undefined);
});
test('blocked database open is a safe failure, never an empty record',async t=>{
    const f=idb(t,{blocked:true});await assert.rejects(L.readLocalRecoveryRecord(draft),{code:'RMT_LOCAL_STORAGE'});assert.equal(f.transactions.length,0);assert.equal(f.rows.size,0);
});
test('wrong keys cannot become arbitrary storage targets',async t=>{
    const f=idb(t);await assert.rejects(L.compareLocalRecoveryRecord('other:arbitrary',0,{kept:1}));assert.equal(f.transactions.length,0);assert.equal(f.rows.size,0);
});
