import test from 'node:test';
import assert from 'node:assert/strict';
import * as recovery from '../src/generation/recovery.js';

const originFor = () => ({ characterKey: 'capacity-character', characterId: '0', characterAvatar: 'test.png', chatId: 'capacity-chat', archiveRevision: 'r1' });
const background = '原资料🙂\\n\r\n'.repeat(11000);
const promptFor = i => `第${i}段 {{char}}：${'材料'.repeat(9000)}`;
const actualFor = i => background + '\n' + promptFor(i).replace('{{char}}', '原角色') + '\n已启用补充';
const resultFor = i => ({ number: i, text: `保留第${i}段原文🙂`, ids: ['M001', 'CG001'], image: 'https://example.invalid/existing.png' });
async function open(existing = null, save = async () => true) {
    const origin = originFor();
    const handle = await recovery.createGenerationRecovery({ origin, mode: 'archive', settingsIdentity: existing ? 'changed-api' : 'original-api',
        contentSnapshot: { original: true }, existing, continueRequested: !!existing, save });
    recovery.attachGenerationRecovery(origin, handle);
    return { origin, handle };
}
async function segment(session, i, calls, fail = false) {
    return recovery.withRecoverySegment(promptFor(i), { origin: session.origin, taskKey: `capacity:${i}`, contextEnvelope: background }, raw => raw,
        async (prompt, options, accepted) => {
            const frozen = await recovery.freezeRecoveryRequestPayload(options, { actualPrompt: actualFor(i), contentSettings: { original: true } });
            assert.equal(prompt, promptFor(i));
            assert.equal(options.contextEnvelope, background);
            assert.equal(frozen.actualPrompt, actualFor(i), 'request must be byte-identical');
            calls.push(i);
            if (fail) throw Object.assign(new Error('synthetic provider failure'), { code: 'RMT_MANUAL_HTTP' });
            const value = resultFor(i); await accepted(value); return value;
        });
}

test('large repeated request material survives nine segments and reload without repeating completed requests', async () => {
    let saved;
    const session = await open(null, async value => { saved = structuredClone(value); return true; });
    const calls = [];
    for (let i = 0; i < 8; i++) assert.deepEqual(await segment(session, i, calls), resultFor(i));
    await assert.rejects(segment(session, 8, calls, true), /synthetic provider failure/);
    const expanded = recovery.generationRecoverySnapshot(session.handle);
    assert.ok(JSON.stringify(expanded).length > recovery.GENERATION_RECOVERY_LIMITS.journalChars);
    assert.ok(JSON.stringify(saved).length < recovery.GENERATION_RECOVERY_LIMITS.journalChars);
    const firstEight = structuredClone(expanded.segments.slice(0, 8));
    const exported = recovery.exportGenerationRecovery(saved);
    const reopened = await open(JSON.parse(JSON.stringify(exported.journal)), async value => { saved = structuredClone(value); return true; });
    calls.length = 0;
    for (let i = 0; i < 9; i++) assert.deepEqual(await segment(reopened, i, calls), resultFor(i));
    assert.deepEqual(calls, [8], 'only the missing request may run');
    assert.deepEqual(recovery.generationRecoverySnapshot(reopened.handle).segments.slice(0, 8), firstEight);
    assert.equal(recovery.generationRecoverySummary(saved).completed, 9);
    assert.equal(recovery.readGenerationContentSnapshot(saved).original, true);
    assert.ok(saved.segments.every(row => typeof row.requestRecipe.identity.prompt === 'string'), 'archive partial reader needs literal prompt');
});

test('old plain journals migrate losslessly and frozen actual text wins over changed current inputs', async () => {
    const session = await open();
    const calls = [];
    await segment(session, 0, calls);
    await assert.rejects(segment(session, 1, calls, true));
    const legacy = recovery.generationRecoverySnapshot(session.handle);
    let saved;
    const restored = await open(legacy, async value => { saved = structuredClone(value); return true; });
    let providerCalls = 0;
    await recovery.withRecoverySegment('changed current prompt', { origin: restored.origin, taskKey: 'capacity:1', contextEnvelope: 'changed current context' }, raw => raw,
        async (prompt, options, accepted) => {
            const value = await recovery.freezeRecoveryRequestPayload(options, { actualPrompt: 'changed current output', contentSettings: { changed: true } });
            assert.equal(prompt, promptFor(1));
            assert.equal(options.contextEnvelope, background);
            assert.deepEqual(value, { actualPrompt: actualFor(1), contentSettings: { original: true } });
            providerCalls++; await accepted(resultFor(1)); return resultFor(1);
        });
    assert.equal(providerCalls, 1);
    assert.deepEqual(recovery.generationRecoverySnapshot(restored.handle).segments[0], legacy.segments[0]);
    assert.equal(recovery.generationRecoverySummary(saved).completed, 2);
    const diskRead = await open(JSON.parse(JSON.stringify(saved)));
    assert.deepEqual(recovery.generationRecoverySnapshot(diskRead.handle).segments,
        recovery.generationRecoverySnapshot(restored.handle).segments, 'all saved results must survive serialization and reload');
    const replayCalls = [];
    for (let i = 0; i < 2; i++) assert.deepEqual(await segment(diskRead, i, replayCalls), resultFor(i));
    assert.deepEqual(replayCalls, [], 'reopening successful results never regenerates them');
});

test('payload codec restores exact strings, unrelated fields, and previous attempts', async () => {
    const codec = await import('../src/generation/recoveryPayload.js');
    const base = { kind: 'generation-recovery', version: 1, segments: [], other: { retained: 'original' } };
    for (const [context, prompt, actual] of [
        [background, 'A🙂', background + '\nA🙂'],
        [background, 'B{{char}}尾巴', background + '\nB名字尾巴'],
        ['different'.repeat(1000), 'C', 'completely different'],
        ['', 'D', 'D'], [background, 'E', ''], [background, 'F', background + '\nF\nextra'],
        [background, 'G', background.slice(0, -2) + '\nG'],
    ]) base.segments.push({ requestRecipe: { version: 1, identity: { contextEnvelope: context, prompt }, actualPrompt: actual }, rawJson: '{"saved":true}' });
    base.previousAttempts = [structuredClone(base)];
    const original = structuredClone(base), packed = codec.packRecoveryPayload(base);
    assert.ok(JSON.stringify(packed).length < JSON.stringify(base).length);
    assert.deepEqual(codec.unpackRecoveryPayload(packed, recovery.GENERATION_RECOVERY_LIMITS.requestChars), base);
    assert.deepEqual(base, original, 'encoding must not mutate the caller');
    assert.equal(JSON.stringify(packed).split(JSON.stringify(background).slice(1, -1)).length - 1, 2, 'one background per journal, including each preserved attempt');
    const ordinary = { kind: 'generation-recovery', version: 1, segments: [{ state: 'retry' }] };
    assert.deepEqual(codec.packRecoveryPayload(ordinary), ordinary);
    assert.deepEqual(codec.unpackRecoveryPayload(ordinary, 1200000), ordinary);
});

test('broken compact references cannot produce requests or replace successful data', async () => {
    let saved;
    const session = await open(null, async value => { saved = structuredClone(value); return true; });
    await segment(session, 0, []);
    const before = structuredClone(saved);
    for (const damage of [
        value => { value.requestEncoding = 99; },
        value => { value.requestContextTable = []; },
        value => { value.segments[0].requestRecipe.identity.contextEnvelope.textRef = -1; },
        value => { value.segments[0].requestRecipe.actualPrompt.prefixChars = Number.MAX_SAFE_INTEGER; },
    ]) {
        const bad = structuredClone(saved); damage(bad);
        assert.equal(recovery.generationRecoverySummary(bad), null);
        await assert.rejects(open(bad), error => error.code === 'RMT_RECOVERY_INPUT_CHANGED');
    }
    assert.deepEqual(saved, before);
});

test('a failed durable write retains received output in-page', async () => {
    let acceptWrites = true;
    const session = await open(null, async () => acceptWrites);
    await recovery.withRecoverySegment(promptFor(0), { origin: session.origin, taskKey: 'capacity:0', contextEnvelope: background }, raw => raw,
        async (_prompt, options, accepted) => {
            await recovery.freezeRecoveryRequestPayload(options, { actualPrompt: actualFor(0) });
            acceptWrites = false;
            await assert.rejects(accepted(resultFor(0)), error => error.code === 'RMT_RECOVERY_STORAGE');
            return resultFor(0);
        });
    const retained = recovery.generationRecoverySnapshot(session.handle).segments[0];
    assert.equal(retained.state, 'complete');
    assert.deepEqual(JSON.parse(retained.rawJson), resultFor(0));
});
