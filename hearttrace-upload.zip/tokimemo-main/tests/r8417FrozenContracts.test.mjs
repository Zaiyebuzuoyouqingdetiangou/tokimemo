import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createHash } from 'node:crypto';
import * as C from '../src/core/constants.js';
const root=new URL('../',import.meta.url),read=p=>fs.readFileSync(new URL(p,root),'utf8'),sha=s=>createHash('sha256').update(s).digest('hex');
const hashes=JSON.parse(read('tests/helpers/r8417UntouchedHashes.json'));
for(const group of ['src/modes/','src/core/','src/ui/','src/generation/','src/archive/'])test('r8417 actual untouched bytes against r84.16: '+group,()=>{
 let n=0;for(const [p,h]of Object.entries(hashes))if(p.startsWith(group)){assert.equal(sha(read(p)),h,p);n++;}assert.ok(n>0);
});
test('only the documented QQJ current chat snapshot API is read',()=>{
 const s=read('src/archive/qianqianjie.js');assert.match(s,/qqj_v3_public_bridge_v1/);assert.match(s,/getSnapshot/);
 assert.doesNotMatch(s,/\.readMemory\(|\.getPromptSnapshot\(|fetch\(|indexedDB|localStorage|chatMetadata|\.cse\b|\.people\b|import\(/);
});
test('bootstrap identity names agree with manifest and import ZIP workflow',()=>{
 const m=JSON.parse(read('manifest.json'));assert.equal(m.version,'0.8.93');assert.equal(m.js,'index.js?heartbeat=0.8.93-tt-cg-r84.17-memory-sources');
 assert.match(read('index.js'),/const BUILD = '0\.8\.93-tt-cg-r84\.17-memory-sources'/);assert.equal(m.homePage,'https://github.com/Zaiyebuzuoyouqingdetiangou/tokimemo');
});
test('explicit historical consent remains necessary; only new checkbox is made available',()=>{
 const s=read('src/archive/repository.js');assert.match(s,/data-rmt-memory-wi-history/);assert.match(s,/作为历史摘要/);
 assert.match(s,/historySource:.*=== true/);assert.match(read('src/ui/overlay.js'),/rmt-memory-wi-history/);
});
test('original budget constants and store protections are still present',()=>{
 assert.ok(C.MAX_MEMORY_SOURCE_LEDGER_RECORDS>0);assert.equal(C.MAX_EXTERNAL_MEMORY_CHARS,240000);
 assert.match(read('src/archive/sourceLedger.js'),/assertCurrent\(\);\s*await backend\(\)\.write/);
 assert.match(read('src/archive/importRecovery.js'),/existing\.sourceHash !== sourceHash/);
 assert.match(read('src/archive/importRecovery.js'),/continueRequested: !!existing/);
});
