import test, { afterEach } from 'node:test';
import assert from 'node:assert/strict';
import * as viewer from '../src/ui/cgImageViewer.js';
import { OVERLAY_ID } from '../src/core/constants.js';

// Same DOM/event fixture style as cgImageViewer.test.mjs: it exercises the real
// view and listener lifecycle, including the capture-phase touch fallback that
// must dismiss the viewer when iOS/TT WebViews swallow the close button's click.
const observers = new Set();
function changed(target) {
    for (const observer of observers) if (observer.targets.has(target) && !observer.queued) {
        observer.queued = true;
        queueMicrotask(() => {
            observer.queued = false;
            if (observers.has(observer)) observer.callback();
        });
    }
}
class FixtureObserver {
    constructor(callback) { this.callback = callback; this.targets = new Set(); }
    observe(target) { this.targets.add(target); observers.add(this); }
    disconnect() { this.targets.clear(); observers.delete(this); }
}
class FixtureNode {
    constructor(tag, document) {
        this.tagName = tag.toUpperCase(); this.ownerDocument = document;
        this.children = []; this.listeners = new Map(); this.attributes = new Map();
        this.className = ''; this.hidden = false; this.disabled = false; this.textContent = '';
    }
    get firstChild() { return this.children[0] || null; }
    get isConnected() { return this === this.ownerDocument || !!this.parentNode?.isConnected; }
    get classList() {
        return { contains: name => this.className.split(/\s+/).includes(name), toggle: (name, force) => {
            const values = new Set(this.className.split(/\s+/).filter(Boolean));
            const enabled = force ?? !values.has(name);
            if (enabled) values.add(name); else values.delete(name);
            this.className = [...values].join(' '); return enabled;
        } };
    }
    setAttribute(name, value) { this.attributes.set(name, String(value)); }
    getAttribute(name) { return this.attributes.get(name) ?? null; }
    appendChild(node) { node.remove(); this.children.push(node); node.parentNode = this; changed(this); return node; }
    remove() {
        const parent = this.parentNode;
        if (!parent) return;
        parent.children.splice(parent.children.indexOf(this), 1); this.parentNode = null; changed(parent);
    }
    replaceChildren(...nodes) { [...this.children].forEach(node => node.remove()); nodes.forEach(node => this.appendChild(node)); }
    contains(node) { return node === this || this.children.some(child => child.contains(node)); }
    querySelector(selector) {
        const matches = node => selector.startsWith('.') ? node.classList.contains(selector.slice(1))
            : selector.startsWith('#') ? node.id === selector.slice(1) : node.tagName.toLowerCase() === selector;
        for (const child of this.children) { if (matches(child)) return child; const nested = child.querySelector(selector); if (nested) return nested; }
        return null;
    }
    focus() { this.ownerDocument.activeElement = this; }
    addEventListener(type, callback, capture = false) {
        const entries = this.listeners.get(type) || [];
        entries.push({ callback, capture: capture === true || capture?.capture === true }); this.listeners.set(type, entries);
    }
    removeEventListener(type, callback, capture = false) {
        const isCapture = capture === true || capture?.capture === true;
        this.listeners.set(type, (this.listeners.get(type) || []).filter(entry => entry.callback !== callback || entry.capture !== isCapture));
    }
    listenerCount(type) { return (this.listeners.get(type) || []).length; }
    dispatch(type, values = {}) {
        const event = { type, target: this, defaultPrevented: false, stopped: false, immediate: false,
            preventDefault() { this.defaultPrevented = true; }, stopPropagation() { this.stopped = true; },
            stopImmediatePropagation() { this.immediate = this.stopped = true; }, ...values };
        const path = []; for (let node = this; node; node = node.parentNode) path.push(node);
        const deliver = (node, capture) => {
            for (const entry of [...(node.listeners.get(type) || [])]) {
                if (entry.capture === capture) entry.callback(event);
                if (event.immediate) break;
            }
        };
        for (const node of [...path].reverse()) { deliver(node, true); if (event.stopped) return event; }
        for (const node of path) { deliver(node, false); if (event.stopped) break; }
        return event;
    }
}
function fixture() {
    const document = new FixtureNode('#document'); document.ownerDocument = document;
    document.createElement = tag => new FixtureNode(tag, document);
    document.getElementById = id => document.querySelector('#' + id);
    document.body = document.createElement('body'); document.appendChild(document.body);
    const host = document.createElement('dialog'); host.id = OVERLAY_ID; host.open = true;
    const shell = document.createElement('div'); shell.className = 'rmt-shell';
    const body = document.createElement('div'); body.className = 'rmt-body';
    const opener = document.createElement('button'); body.appendChild(opener);
    shell.appendChild(body); host.appendChild(shell); document.body.appendChild(host); opener.focus();
    globalThis.document = document; globalThis.MutationObserver = FixtureObserver;
    globalThis.location = { href: 'https://cloud.example/', origin: 'https://cloud.example' };
    globalThis.toastr = { warning: () => {} };
    let focusCount = 0;
    const focus = opener.focus.bind(opener);
    opener.focus = () => { focusCount++; focus(); };
    return { document, host, shell, body, opener, focusCount: () => focusCount };
}
const record = Object.freeze({ url: '/user/images/fixture/event.png', provider: 'baibai-image', prompt: '已保存提示' });
afterEach(() => {
    viewer.closeCgImageViewer({ restoreFocus: false });
    for (const key of ['document', 'MutationObserver', 'location', 'toastr']) delete globalThis[key];
    assert.equal(observers.size, 0, 'view observers must be released');
});

test('touchstart fallback on the close button dismisses the viewer without any click', () => {
    const f = fixture();
    assert.equal(viewer.openCgImageViewer(record, '旧图', { opener: f.opener }), true);
    const element = f.shell.querySelector('.rmt-cg-viewer');
    element.querySelector('img').dispatch('load');
    const close = element.querySelector('.rmt-cg-viewer-close');
    const event = close.dispatch('touchstart');
    assert.equal(event.defaultPrevented, true, 'fallback prevents the swallowed-gesture default');
    assert.equal(viewer.hasCgImageViewer(), false, 'viewer closed via touch fallback alone');
    assert.equal(element.isConnected, false);
    assert.equal(f.document.activeElement, f.opener);
    assert.equal(f.host.open, true, 'archive overlay stays open');
});

test('pointerdown fallback and the trailing synthetic click never dismiss twice', () => {
    const f = fixture();
    viewer.openCgImageViewer(record, '旧图', { opener: f.opener });
    const element = f.shell.querySelector('.rmt-cg-viewer');
    element.querySelector('img').dispatch('load');
    const close = element.querySelector('.rmt-cg-viewer-close');
    close.dispatch('pointerdown');
    assert.equal(viewer.hasCgImageViewer(), false);
    assert.equal(f.focusCount(), 1, 'exactly one dismiss ran');
    // The synthetic click a WebView fires after pointerdown must not close anything else.
    close.dispatch('click');
    assert.equal(f.focusCount(), 1, 'trailing click within 500ms is deduped, no double dismiss');
    assert.equal(f.host.isConnected, true);
    assert.equal(f.host.open, true, 'archive overlay is not closed by the duplicate gesture');
    assert.equal(viewer.hasCgImageViewer(), false);
});

test('fallback ignores gestures outside the close button and non-primary pointerdown', () => {
    const f = fixture();
    viewer.openCgImageViewer(record, '旧图', { opener: f.opener });
    const element = f.shell.querySelector('.rmt-cg-viewer');
    const stage = element.querySelector('.rmt-cg-viewer-stage');
    const close = element.querySelector('.rmt-cg-viewer-close');
    stage.dispatch('touchstart');
    stage.dispatch('pointerdown');
    close.dispatch('pointerdown', { button: 2 });
    close.dispatch('pointerdown', { isPrimary: false });
    assert.equal(viewer.hasCgImageViewer(), true, 'stage gestures and secondary pointers never close');
    assert.equal(f.focusCount(), 0);
});

test('viewer is exitable while still loading, after zoom toggling and after dragging', () => {
    const f = fixture();
    // Loading state: no load event, toggle disabled, status still showing.
    viewer.openCgImageViewer(record, '旧图', { opener: f.opener });
    let element = f.shell.querySelector('.rmt-cg-viewer');
    assert.equal(element.querySelector('.rmt-cg-viewer-toggle').disabled, true);
    assert.match(element.querySelector('.rmt-cg-viewer-status').textContent, /正在加载/);
    element.querySelector('.rmt-cg-viewer-close').dispatch('touchstart');
    assert.equal(viewer.hasCgImageViewer(), false, 'touch fallback closes during load');
    // Zoomed/native mode plus a drag (scroll offsets) must still exit.
    viewer.openCgImageViewer(record, '旧图', { opener: f.opener });
    element = f.shell.querySelector('.rmt-cg-viewer');
    element.querySelector('img').dispatch('load');
    const stage = element.querySelector('.rmt-cg-viewer-stage');
    element.querySelector('.rmt-cg-viewer-toggle').dispatch('click');
    assert.equal(element.classList.contains('rmt-cg-viewer-native'), true);
    stage.scrollTop = 480; stage.scrollLeft = 320;
    element.querySelector('.rmt-cg-viewer-close').dispatch('pointerdown');
    assert.equal(viewer.hasCgImageViewer(), false, 'pointer fallback closes after zoom and drag');
});

test('touch fallback close leaves zero listeners behind on every node', () => {
    const f = fixture();
    viewer.openCgImageViewer(record, '旧图', { opener: f.opener });
    const element = f.shell.querySelector('.rmt-cg-viewer');
    const image = element.querySelector('img');
    const close = element.querySelector('.rmt-cg-viewer-close');
    for (const type of ['click', 'pointerdown', 'touchstart']) assert.ok(element.listenerCount(type) > 0, `${type} bound while open`);
    close.dispatch('touchstart');
    assert.equal(viewer.hasCgImageViewer(), false);
    for (const type of ['click', 'pointerdown', 'touchstart']) assert.equal(element.listenerCount(type), 0, `${type} removed from viewer root`);
    assert.equal(image.listenerCount('load'), 0);
    assert.equal(image.listenerCount('error'), 0);
    assert.equal(f.document.listenerCount('keydown'), 0, 'document keydown capture removed');
    assert.equal(f.host.listenerCount('cancel'), 0, 'host cancel capture removed');
    assert.equal(observers.size, 0, 'mutation observers disconnected');
});
