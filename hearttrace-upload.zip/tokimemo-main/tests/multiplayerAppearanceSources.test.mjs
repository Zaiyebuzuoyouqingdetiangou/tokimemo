import test from 'node:test';
import assert from 'node:assert/strict';
import * as appearance from '../src/generation/cgAppearance.js';
import * as looks from '../src/core/castLooks.js';
import * as context from '../src/core/context.js';
import { fixture } from './helpers/r847Host.mjs';

const cast = { version: 1, people: [
    { id: 'p-a', name: '同名', sourceRefs: [{ world: '人物书', uid: '8', title: '甲', content: '外貌描写：棕色短发，小麦色皮肤。' }] },
    { id: 'p-b', name: '同名', sourceRefs: [{ world: '人物书', uid: '9', title: '乙', content: '外貌描写：银色长发，蓝眼睛。' }] },
    { id: 'p-c', name: '未知', sourceRefs: [] },
] };

for (const emptyTag of ['', '   \n  ']) test(`saved empty appearance does not suppress worldbook source (${JSON.stringify(emptyTag)})`, async t => {
    const f = await fixture(t), before = JSON.stringify(cast);
    looks.saveConfirmedParticipantLooks([{ participantId: 'p-a', tag: emptyTag }, { participantId: 'p-b', tag: 'silver hair, blue eyes' }], {
        origin: context.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision),
        expectedSignature: looks.participantLooksSignature(looks.readParticipantLooks(f.ctx)),
    });
    const saved = JSON.stringify(looks.readParticipantLooks(f.ctx));
    const evidence = appearance.captureCgAppearanceEvidence(f.ctx, { castSnapshot: cast });
    assert.equal(evidence.characters[0].description, cast.people[0].sourceRefs[0].content);
    assert.equal(evidence.characters[0].knownTag, '');
    assert.equal(evidence.characters[1].description, '', 'valid saved tags keep their established prompt inputs');
    assert.equal(evidence.characters[1].knownTag, 'silver hair, blue eyes');
    assert.deepEqual(evidence.missingParticipantIds, ['p-c']);
    assert.equal(JSON.stringify(cast), before);
    assert.equal(JSON.stringify(looks.readParticipantLooks(f.ctx)), saved);
    assert.equal(f.requests.length, 0);
    const result = appearance.normalizeCgPreparedPrompt({ imagePrompt: '庭院中的两人', sceneTags: 'courtyard', flatPrompt: 'Two people in a courtyard.',
        characters: [{ participantId: 'p-a', tag: 'brown hair, short hair, tan skin' }, { participantId: 'p-b', tag: 'silver hair, blue eyes' }] }, evidence);
    assert.equal(result.characters[0].participantId, 'p-a');
    assert.equal(result.characters[0].tag, 'brown hair, short hair, tan skin');
    assert.deepEqual(result.missingParticipantIds, ['p-c']);
});

test('nonempty saved manual appearance remains authoritative', async t => {
    const f = await fixture(t);
    looks.saveConfirmedParticipantLooks([{ participantId: 'p-a', tag: '(black hair:1.3), green eyes' }], {
        origin: context.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision),
        expectedSignature: looks.participantLooksSignature(looks.readParticipantLooks(f.ctx)),
    });
    const evidence = appearance.captureCgAppearanceEvidence(f.ctx, { castSnapshot: cast });
    assert.equal(evidence.characters[0].description, '');
    assert.equal(evidence.characters[0].knownTag, '(black hair:1.3), green eyes');
    assert.throws(() => appearance.normalizeCgPreparedPrompt({ imagePrompt: '庭院', sceneTags: 'garden', flatPrompt: 'Garden.',
        characters: [{ participantId: 'p-a', tag: 'brown hair' }] }, evidence), error => error.code === 'RMT_CG_PROMPT_INVALID');
    assert.equal(f.requests.length, 0);
});

test('clearing a saved tag in the editor restores its own filtered worldbook source without saving', async t => {
    const f = await fixture(t);
    f.ctx.extensionSettings.heartbeatMemories.excludedContextTags = ['private'];
    const source = structuredClone(cast);
    source.people[0].sourceRefs[0].content += '<private>HIDDEN_LOOK</private>VISIBLE_TAIL';
    looks.saveConfirmedParticipantLooks([{ participantId: 'p-a', tag: 'old hair' }], {
        origin: context.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision),
        expectedSignature: looks.participantLooksSignature(looks.readParticipantLooks(f.ctx)),
    });
    const before = JSON.stringify(looks.readParticipantLooks(f.ctx));
    const evidence = appearance.captureCgAppearanceEvidence(f.ctx, { castSnapshot: source });
    assert.equal(evidence.characters[0].description, '');
    const draft = appearance.appearanceEvidenceWithDraft(evidence, { 'p-a': '' }, f.ctx);
    assert.match(draft.characters[0].description, /棕色短发/);
    assert.match(draft.characters[0].description, /VISIBLE_TAIL/);
    assert.doesNotMatch(draft.characters[0].description, /HIDDEN_LOOK|银色长发/);
    assert.equal(draft.characters[0].knownTag, '');
    assert.equal(evidence.characters[0].knownTag, 'old hair');
    assert.equal(JSON.stringify(looks.readParticipantLooks(f.ctx)), before);
    assert.equal(f.requests.length, 0);
});
