import test from 'node:test';
import assert from 'node:assert/strict';
import * as appearance from '../src/generation/cgAppearance.js';
import * as looks from '../src/core/castLooks.js';
import * as participants from '../src/core/participants.js';
import * as context from '../src/core/context.js';
import { fixture } from './helpers/r847Host.mjs';

const cast = { version: 1, people: [
    { id: 'p-a', name: '同名', sourceRefs: [{ world: '人物书', uid: '8', title: '甲', content: '外貌描写：棕色短发，小麦色皮肤。' }] },
    { id: 'p-b', name: '同名', sourceRefs: [{ world: '人物书', uid: '9', title: '乙', content: '外貌描写：银色长发，蓝眼睛。' }] },
    { id: 'p-c', name: '未知', sourceRefs: [] },
] };

for (const emptyTag of ['', '   \n  ']) test(`saved empty appearance does not suppress worldbook source (${JSON.stringify(emptyTag)})`, async t => {
    const f = await fixture(t), before = JSON.stringify(cast);
    looks.saveConfirmedParticipantLooks([{ participantId: 'p-a', tag: emptyTag }, { participantId: 'p-b', tag: 'silver hair, blue eyes' }], {
        origin: context.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision),
        expectedSignature: looks.participantLooksSignature(looks.readParticipantLooks(f.ctx)),
    });
    const saved = JSON.stringify(looks.readParticipantLooks(f.ctx));
    const evidence = appearance.captureCgAppearanceEvidence(f.ctx, { castSnapshot: cast });
    assert.equal(evidence.characters[0].description, cast.people[0].sourceRefs[0].content);
    assert.equal(evidence.characters[0].knownTag, '');
    assert.equal(evidence.characters[1].description, '', 'valid saved tags keep their established prompt inputs');
    assert.equal(evidence.characters[1].knownTag, 'silver hair, blue eyes');
    assert.deepEqual(evidence.missingParticipantIds, ['p-c']);
    assert.equal(JSON.stringify(cast), before);
    assert.equal(JSON.stringify(looks.readParticipantLooks(f.ctx)), saved);
    assert.equal(f.requests.length, 0);
    const result = appearance.normalizeCgPreparedPrompt({ imagePrompt: '庭院中的两人', sceneTags: 'courtyard', flatPrompt: 'Two people in a courtyard.',
        characters: [{ participantId: 'p-a', tag: 'brown hair, short hair, tan skin' }, { participantId: 'p-b', tag: 'silver hair, blue eyes' }] }, evidence);
    assert.equal(result.characters[0].participantId, 'p-a');
    assert.equal(result.characters[0].tag, 'brown hair, short hair, tan skin');
    assert.deepEqual(result.missingParticipantIds, ['p-c']);
});

test('nonempty saved manual appearance remains authoritative', async t => {
    const f = await fixture(t);
    looks.saveConfirmedParticipantLooks([{ participantId: 'p-a', tag: '(black hair:1.3), green eyes' }], {
        origin: context.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision),
        expectedSignature: looks.participantLooksSignature(looks.readParticipantLooks(f.ctx)),
    });
    const evidence = appearance.captureCgAppearanceEvidence(f.ctx, { castSnapshot: cast });
    assert.equal(evidence.characters[0].description, '');
    assert.equal(evidence.characters[0].knownTag, '(black hair:1.3), green eyes');
    assert.throws(() => appearance.normalizeCgPreparedPrompt({ imagePrompt: '庭院', sceneTags: 'garden', flatPrompt: 'Garden.',
        characters: [{ participantId: 'p-a', tag: 'brown hair' }] }, evidence), error => error.code === 'RMT_CG_PROMPT_INVALID');
    assert.equal(f.requests.length, 0);
});

// Retain the historical case name for before/after comparison. Filtering now
// removes markup only; explicit worldbook content is independent of chat tags.
test('clearing a saved tag in the editor restores its own filtered worldbook source without saving', async t => {
    const f = await fixture(t);
    f.ctx.extensionSettings.heartbeatMemories.excludedContextTags = ['private'];
    const source = structuredClone(cast);
    source.people[0].sourceRefs[0].content += '<private>HIDDEN_LOOK</private>VISIBLE_TAIL';
    looks.saveConfirmedParticipantLooks([{ participantId: 'p-a', tag: 'old hair' }], {
        origin: context.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision),
        expectedSignature: looks.participantLooksSignature(looks.readParticipantLooks(f.ctx)),
    });
    const before = JSON.stringify(looks.readParticipantLooks(f.ctx));
    const evidence = appearance.captureCgAppearanceEvidence(f.ctx, { castSnapshot: source });
    assert.equal(evidence.characters[0].description, '');
    const draft = appearance.appearanceEvidenceWithDraft(evidence, { 'p-a': '' }, f.ctx);
    assert.match(draft.characters[0].description, /棕色短发/);
    assert.match(draft.characters[0].description, /VISIBLE_TAIL/);
    assert.match(draft.characters[0].description, /HIDDEN_LOOK/, 'chat exclusions do not remove explicitly selected worldbook content');
    assert.doesNotMatch(draft.characters[0].description, /银色长发/);
    assert.equal(draft.characters[0].knownTag, '');
    assert.equal(evidence.characters[0].knownTag, 'old hair');
    assert.equal(JSON.stringify(looks.readParticipantLooks(f.ctx)), before);
    assert.equal(f.requests.length, 0);
});


test('explicit character-information worldbook survives chat keep selection with complete long source', async t => {
    const f = await fixture(t), source = structuredClone(cast);
    f.ctx.extensionSettings.heartbeatMemories.contextTagMode = 'keep';
    f.ctx.extensionSettings.heartbeatMemories.retainedContextTags = ['content'];
    const long = '资料'.repeat(12000);
    source.people[0].sourceRefs[0].content = `<character_information character="人物甲">外貌：棕色短发。${long}TAIL_VISIBLE</character_information>`;
    const before = JSON.stringify(source);
    const evidence = appearance.captureCgAppearanceEvidence(f.ctx, { castSnapshot: source });
    assert.match(evidence.characters[0].description, /棕色短发/);
    assert.ok(evidence.characters[0].description.endsWith('TAIL_VISIBLE'));
    assert.ok(evidence.characters[0].description.includes(long));
    assert.doesNotMatch(evidence.characters[0].description, /character_information|银色长发/);
    assert.deepEqual(evidence.missingParticipantIds, ['p-c']);
    assert.equal(JSON.stringify(source), before); assert.equal(f.requests.length, 0);
});

test('explicit user identity receives persona; a same-name NPC never receives it', async t => {
    const f = await fixture(t);
    f.ctx.getCharacterCardFields = () => ({ persona: '<user_profile>银色长发，紫色眼睛。</user_profile>' });
    f.ctx.extensionSettings.heartbeatMemories.contextTagMode = 'keep';
    f.ctx.extensionSettings.heartbeatMemories.retainedContextTags = ['content'];
    const user = { id: 'user-1', name: f.ctx.name1, identity: 'user', sourceRefs: [] };
    const sameName = { id: 'npc-1', name: f.ctx.name1, sourceRefs: [] };
    const snapshot = participants.normalizeParticipantSnapshot({version: 1, people: [user, sameName]});
    assert.equal(snapshot.people[0].identity, 'user');
    const evidence = appearance.captureCgAppearanceEvidence(f.ctx, {castSnapshot: snapshot});
    assert.match(evidence.characters[0].description, /银色长发/);
    assert.equal(evidence.characters[1].description, '');
    assert.deepEqual(evidence.missingParticipantIds, ['npc-1']);
    assert.equal(f.requests.length, 0);
});

test('automatic user candidate freezes persona, stays ID-distinct, and preserves previous image sources', async t => {
    const f = await fixture(t);
    f.ctx.getCharacterCardFields = () => ({ persona: '原人设：银色长发。' });
    const npc = { id: 'rmt-current-user', name: f.ctx.name1, sourceRefs: [] };
    const user = appearance.createCgUserParticipant(f.ctx, [npc]);
    assert.notEqual(user.id, npc.id); assert.equal(user.identity, 'user');
    assert.equal(user.name, f.ctx.name1);
    const snapshot = {version: 1, people: [user]};
    const metadata = appearance.normalizeCgPromptMetadata({castSnapshot: snapshot, characters: []});
    f.ctx.getCharacterCardFields = () => ({ persona: '后来人设：黑色短发。' });
    const retained = appearance.initialCgAppearanceMetadata({cgImage: {promptMetadata: metadata}}, f.ctx);
    assert.ok(retained?.castSnapshot, 'the saved image retains its original participant snapshot');
    const evidence = appearance.captureCgAppearanceEvidence(f.ctx, {castSnapshot: retained.castSnapshot});
    assert.match(evidence.characters[0].description, /银色长发/);
    assert.doesNotMatch(evidence.characters[0].description, /黑色短发/);
    assert.deepEqual(retained, metadata); assert.equal(f.requests.length, 0);
});
