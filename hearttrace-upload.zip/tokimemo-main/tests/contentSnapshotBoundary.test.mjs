import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './helpers/r847Host.mjs';
import * as client from '../src/generation/client.js';
import * as recovery from '../src/generation/recovery.js';
import * as context from '../src/core/context.js';
import * as constants from '../src/core/constants.js';

// Synthetic bookkeeping only. No user text, API credentials or external calls.
function checkpoint() {
    return { version: 1, taskId: 'completed-import', nextBatch: 1, batches: [[]],
        taskInputV1: { source: '保存的原建档资料🙂'.repeat(150000) } };
}
const expectedBank = bank => {
    const copy = structuredClone(bank);
    delete copy.archiveImportProgress;
    delete copy.archiveImportPaused;
    return copy;
};

for (const mode of [...new Set(Object.values(constants.MODE))]) {
    test(`large archive bookkeeping cannot block the shared ${mode} content entry`, async t => {
        const f = await fixture(t);
        f.liveBank.archiveImportProgress = checkpoint();
        f.liveBank.archiveImportPaused = { reason: 'unfinished next batch', retained: 'do not delete' };
        f.liveBank.extraFutureField = { original: ['keep', null, '🙂'], image: '/user/images/existing.png' };
        f.ctx.characters[0].data.description += '完整角色资料'.repeat(22000);
        const before = JSON.stringify(f.liveBank);
        assert.ok(before.length > recovery.GENERATION_RECOVERY_LIMITS.requestChars);
        const origin = context.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision);
        const handle = await client.beginModeRecovery(mode, f.ctx, f.liveBank, origin);
        const snapshot = recovery.readGenerationContentSnapshot(handle.journal);
        assert.deepEqual(snapshot.memoryBank, expectedBank(f.liveBank), 'omit only archive bookkeeping');
        assert.equal(JSON.stringify(f.liveBank), before, 'source archive must not be mutated');
        assert.deepEqual(snapshot.cardFields, f.ctx.getCharacterCardFields(), 'card must not be truncated');
        assert.deepEqual(snapshot.fields.characters[0], f.ctx.characters[0]);
        assert.deepEqual(snapshot.fields.powerUserSettings, f.ctx.powerUserSettings);
        assert.equal(f.requests.length, 0, 'snapshot capture is free of provider calls');
        recovery.detachGenerationRecovery(origin);
    });
}

test('an ordinary archive retains every source field and the capture is an independent copy', async t => {
    const f = await fixture(t), origin = context.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision);
    const before = structuredClone(f.liveBank);
    const handle = await client.beginModeRecovery('album', f.ctx, f.liveBank, origin);
    const snapshot = recovery.readGenerationContentSnapshot(handle.journal);
    assert.deepEqual(snapshot.memoryBank, before);
    handle.contentBank.memories[0].summary = 'temporary generation view';
    assert.deepEqual(f.liveBank, before);
    assert.deepEqual(recovery.readGenerationContentSnapshot(handle.journal).memoryBank, before);
    recovery.detachGenerationRecovery(origin);
});

test('existing frozen content source and completed segment survive API change, new chat text and reopen', async t => {
    const f = await fixture(t), origin = context.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision);
    const first = await client.beginModeRecovery('album', f.ctx, f.liveBank, origin);
    // A previously saved small content snapshot is legal and must remain exact.
    const legacySnapshot = recovery.readGenerationContentSnapshot(first.journal);
    legacySnapshot.memoryBank.archiveImportProgress = { version: 1, oldSnapshot: true };
    const legacy = await recovery.createGenerationRecovery({ origin: { ...origin, archiveTargetEntryId: first.journal.identity.archiveTargetEntryId }, mode: 'album',
        contentSnapshot: legacySnapshot, save: async () => true });
    recovery.attachGenerationRecovery(origin, legacy);
    await recovery.withRecoverySegment('frozen original prompt', { origin, taskKey: 'done' }, x => x,
        async (_prompt, _options, accepted) => { const value = { keep: 'paid text', image: '/old.png' }; await accepted(value); return value; });
    const saved = recovery.generationRecoverySnapshot(legacy);
    saved.operation = structuredClone(first.journal.operation);
    recovery.detachGenerationRecovery(origin);
    f.ctx.chat.push({ is_user: true, mes: 'new current text' });
    f.ctx.extensionSettings.connectionManager.profiles[0].model = 'changed-model';
    f.liveBank.archiveImportProgress = checkpoint();
    const resumed = await client.beginModeRecovery('album', f.ctx, f.liveBank, origin, { existing: saved });
    assert.deepEqual(recovery.readGenerationContentSnapshot(resumed.journal), legacySnapshot);
    assert.deepEqual(resumed.journal.segments, saved.segments);
    let requests = 0;
    const value = await recovery.withRecoverySegment('changed current prompt', { origin, taskKey: 'done' }, x => x,
        async () => { requests++; throw new Error('completed segment must not request again'); });
    assert.equal(requests, 0);
    assert.deepEqual(value, { keep: 'paid text', image: '/old.png' });
    assert.deepEqual(f.liveBank.archiveImportProgress, checkpoint());
    recovery.detachGenerationRecovery(origin);
});
