import test from 'node:test';
import assert from 'node:assert/strict';
import { archiveFixture } from './helpers/r8422ArchiveHost.mjs';
import { localFixture, waitUntil } from './helpers/r8425LocalHost.mjs';
import * as D from '../src/archive/importRecovery.js';
import * as R from '../src/archive/repository.js';
import * as G from '../src/generation/recovery.js';
import * as L from '../src/core/localRecoveryStore.js';
import * as context from '../src/core/context.js';
import * as overlay from '../src/ui/overlay.js';
import * as view from '../src/ui/recoveryView.js';
import * as C from '../src/core/constants.js';
import { workspace } from '../src/ui/workspaceState.js';
import { state } from '../src/core/state.js';

// This suite uses production handlers with an explicit DOM/storage/provider
// double. tools/r8426-browser-recovery.py separately exercises real Chromium DOM.
function regionFor(f) {
    const original = f.body.querySelector;
    const region = { innerHTML: '', busy: '', setAttribute(k, v) { if (k === 'aria-busy') this.busy = v; } };
    f.body.querySelector = selector => selector === '[data-rmt-archive-recoveries]' && f.body.innerHTML.includes('data-rmt-archive-recoveries') ? region : original.call(f.body, selector);
    return region;
}
const originFor = f => context.captureTaskOrigin(f.ctx, R.getImportedMemory(f.ctx)?.archiveRevision || '');
const begin = (origin, extra = {}) => D.beginArchiveRecovery({ origin, sourceIdentity: 'synthetic source 63',
    sourceFragments: ['synthetic source'], settingsIdentity: 'fixed-settings', ...extra });
const segment = (ticket, n, counter) => G.withRecoverySegment('synthetic fragment ' + n,
    { origin: ticket.origin, taskKey: 'part-' + n, mode: 'archive-import' }, raw => raw,
    async (_prompt, _options, accept) => { counter.n++; const value = { value: n }; await accept(value); return value; });
async function seed(f, count = 41, operation = 'import') {
    const origin = originFor(f), counter = { n: 0 }, ticket = await begin(origin, { operation });
    for (let n = 0; n < count; n++) await segment(ticket, n, counter);
    D.releaseArchiveRecovery(ticket); await D.flushArchiveRecovery(origin, operation);
    return { origin, counter };
}
// Build a genuine unpersisted imported legacy draft. New paid tasks must no
// longer be used to seed page-only results while storage is absent.
async function seedPageOnly(f, local, count) {
    const { origin } = await seed(f, count);
    const data = { format: 'hearttrace-unarchived-results-v2', pageDrafts: D.exportArchiveRecovery(origin) };
    await D.clearArchiveRecoveryDurably(origin);
    local.fail();
    await assert.rejects(D.importArchiveRecoveryData(origin, data), { code: 'RMT_ARCHIVE_DRAFT_STORAGE' });
    local.fail(false);
    return { origin };
}
const control = (name, dataset = {}) => ({ target: { closest: s => s === `[${name}]` ? { dataset, disabled: false } : null }, preventDefault() {} });

test('opening current archive restores 41 saved fragments automatically; no provider or canonical write', async t => {
    const f = await archiveFixture(t), local = localFixture(t), region = regionFor(f);
    const { origin } = await seed(f);
    const before = structuredClone(f.ctx.chatMetadata), rows = structuredClone(local.records), calls = f.requests.length;
    D.resetArchiveRecoveryMemoryForTests();
    assert.equal(R.getCurrentArchiveImportRecoverySummary(f.ctx), null);
    overlay.showChooser({ section: 'archive' });
    await waitUntil(() => region.busy === 'false');
    assert.match(region.innerHTML, /41 个成功分段/);
    assert.match(region.innerHTML, /已保存到本机/);
    assert.match(region.innerHTML, /data-rmt-archive-recovery="import"/);
    assert.equal(D.archiveRecoverySummary(origin).pageOnly, false);
    assert.deepEqual(f.ctx.chatMetadata, before);
    assert.deepEqual(local.records, rows, 'loading does not rewrite persisted journals');
    assert.equal(f.requests.length, calls);
});

test('explicit read button recovers without blind generation or empty export', async t => {
    const f = await archiveFixture(t), local = localFixture(t), region = regionFor(f);
    await seed(f);
    D.resetArchiveRecoveryMemoryForTests();
    f.body.innerHTML = '<div data-rmt-archive-recoveries></div>'; workspace.tab = 'archive';
    overlay.handleOverlayClick(control('data-rmt-archive-read-drafts'));
    await waitUntil(() => region.busy === 'false');
    assert.match(region.innerHTML, /41 个成功分段/);
    D.resetArchiveRecoveryMemoryForTests();
    const value = await R.exportCurrentArchiveRecoveryAfterLoad(f.ctx);
    assert.equal(value.pageDrafts[0].journal.segments.filter(s => s.state === 'complete').length, 41);
    assert.equal(f.requests.length, 0);
    assert.equal(local.records.size, 1);
});

test('63-part plan reuses the restored 41, requests only remaining 22', async t => {
    const f = await archiveFixture(t); localFixture(t); const region = regionFor(f);
    const { origin, counter } = await seed(f);
    D.resetArchiveRecoveryMemoryForTests(); overlay.showChooser({ section: 'archive' });
    await waitUntil(() => region.busy === 'false');
    const ticket = await begin(origin, { continueApproved: true });
    for (let n = 0; n < 63; n++) assert.deepEqual(await segment(ticket, n, counter), { value: n });
    assert.equal(counter.n, 63, '41 reused plus 22 new, not 104');
    D.releaseArchiveRecovery(ticket); await D.flushArchiveRecovery(origin);
    assert.equal(D.archiveRecoverySummary(origin).completed, 63);
});

test('failed local read stays visibly retryable and cannot erase old records', async t => {
    const f = await archiveFixture(t), local = localFixture(t), region = regionFor(f);
    await seed(f); const before = structuredClone(local.records); D.resetArchiveRecoveryMemoryForTests();
    let failed = true;
    L.setLocalRecoveryBackendForTests({ ...local.backend, read: async key => {
        if (failed) throw new Error('synthetic secret must not be displayed'); return local.backend.read(key);
    } });
    overlay.showChooser({ section: 'archive' }); await waitUntil(() => region.busy === 'false');
    assert.match(region.innerHTML, /草稿读取未完成/); assert.doesNotMatch(region.innerHTML, /synthetic secret/);
    assert.deepEqual(local.records, before); assert.equal(f.requests.length, 0);
    failed = false; overlay.handleOverlayClick(control('data-rmt-archive-read-drafts'));
    await waitUntil(() => region.busy === 'false'); assert.match(region.innerHTML, /41 个成功分段/);
    assert.deepEqual(local.records, before);
});

for (const change of ['close', 'settings', 'reader', 'chat', 'card', 'revision', 'lifecycle']) {
    test('late read cannot repaint or rebind after ' + change, async t => {
        const f = await archiveFixture(t), local = localFixture(t), region = regionFor(f);
        await seed(f); const records = structuredClone(local.records); D.resetArchiveRecoveryMemoryForTests();
        let release, entered = false; const gate = new Promise(r => { release = r; });
        L.setLocalRecoveryBackendForTests({ ...local.backend, read: async key => { entered = true; await gate; return local.backend.read(key); } });
        overlay.showChooser({ section: 'archive' }); await waitUntil(() => entered);
        if (change === 'close') f.host.hidden = true;
        if (change === 'settings') { workspace.tab = 'settings'; workspace.epoch++; }
        if (change === 'reader') { state.activeMode = 'heart'; state.archiveViewLevel = 'theater'; }
        if (change === 'chat') f.ctx.chatId = 'other-chat';
        if (change === 'card') f.ctx.characters[0].data.description += ' different';
        if (change === 'revision') f.ctx.chatMetadata[C.MEMORY_KEY].archiveRevision = 'newer';
        if (change === 'lifecycle') state.runtimeLifecycleEpoch++;
        region.innerHTML = 'NEW VIEW SENTINEL'; release(); await new Promise(r => setTimeout(r, 30));
        assert.equal(region.innerHTML, 'NEW VIEW SENTINEL'); assert.equal(f.requests.length, 0);
        assert.deepEqual(local.records, records);
    });
}

test('parallel opening/read/continue preparation uses a single storage read per scope', async t => {
    const f = await archiveFixture(t), local = localFixture(t); await seed(f); D.resetArchiveRecoveryMemoryForTests();
    let reads = 0;
    L.setLocalRecoveryBackendForTests({ ...local.backend, read: async key => { reads++; await new Promise(r => setTimeout(r, 10)); return local.backend.read(key); } });
    await Promise.all(Array.from({ length: 6 }, () => R.hydrateCurrentArchiveRecovery(f.ctx)));
    assert.equal(reads, 2, 'one import read and one profile read'); assert.equal(f.requests.length, 0);
});

test('page-only successful draft can be explicitly saved without regenerating', async t => {
    const f = await archiveFixture(t), local = localFixture(t);
    const { origin } = await seedPageOnly(f, local, 3); assert.equal(D.archiveRecoverySummary(origin).pageOnly, true);
    assert.match(view.archiveRecoveryHtml(D.archiveRecoverySummary(origin)), /保存本页草稿（不生成）/);
    L.setLocalRecoveryBackendForTests(local.backend);
    const summary = await R.saveCurrentArchiveRecovery(f.ctx);
    assert.equal(summary.completed, 3); assert.equal(summary.pageOnly, false); assert.equal(f.requests.length, 0);
    D.resetArchiveRecoveryMemoryForTests(); await R.hydrateCurrentArchiveRecovery(f.ctx);
    assert.equal(D.archiveRecoverySummary(origin).completed, 3);
});

test('save acknowledgement never describes uncommitted new success as durable', async t => {
    const f = await archiveFixture(t), local = localFixture(t), origin = originFor(f), counter = { n: 0 };
    const ticket = await begin(origin); await segment(ticket, 0, counter);
    let release, entered = false; const gate = new Promise(r => { release = r; });
    L.setLocalRecoveryBackendForTests({ ...local.backend, compare: async (...args) => { entered = true; await gate; return local.backend.compare(...args); } });
    const writing = segment(ticket, 1, counter); await waitUntil(() => entered);
    assert.equal(D.archiveRecoverySummary(origin).completed, 2); assert.equal(D.archiveRecoverySummary(origin).pageOnly, true);
    release(); await writing; D.releaseArchiveRecovery(ticket); await D.flushArchiveRecovery(origin);
    assert.equal(D.archiveRecoverySummary(origin).pageOnly, false);
});

test('failed save preserves page successes, original persisted row and zero new requests', async t => {
    const f = await archiveFixture(t), local = localFixture(t); const { origin } = await seed(f, 3);
    const before = structuredClone(local.records); local.fail();
    await assert.rejects(R.saveCurrentArchiveRecovery(f.ctx), { code: 'RMT_ARCHIVE_DRAFT_STORAGE' });
    assert.equal(D.archiveRecoverySummary(origin).completed, 3); assert.equal(D.archiveRecoverySummary(origin).pageOnly, true);
    assert.deepEqual(local.records, before); assert.equal(f.requests.length, 0); local.fail(false);
});

test('empty export refuses a misleading zero-draft file and does not generate', async t => {
    const f = await archiveFixture(t); localFixture(t);
    await assert.rejects(R.exportCurrentArchiveRecoveryAfterLoad(f.ctx), { code: 'RMT_ARCHIVE_DRAFT_NOT_FOUND' });
    assert.equal(f.requests.length, 0);
});

test('import and profile checkpoints both appear after reopening', async t => {
    const f = await archiveFixture(t); localFixture(t); const region = regionFor(f);
    await seed(f, 3); await seed(f, 1, 'profile'); D.resetArchiveRecoveryMemoryForTests();
    overlay.showChooser({ section: 'archive' }); await waitUntil(() => region.busy === 'false');
    assert.match(region.innerHTML, /3 个成功分段/); assert.match(region.innerHTML, /仅重试档案简介/);
    assert.equal(f.requests.length, 0);
});

for (const invalid of ['foreign', 'malformed']) test('invalid stored ' + invalid + ' draft is preserved, not promoted or overwritten', async t => {
    const f = await archiveFixture(t), local = localFixture(t), region = regionFor(f); await seed(f, 1);
    const row = [...local.records.values()][0];
    if (invalid === 'foreign') row.payload.rows[0][1].journal.identity.chatId = 'foreign-chat';
    else row.payload.rows = { invalid: true };
    const before = structuredClone(local.records); D.resetArchiveRecoveryMemoryForTests();
    overlay.showChooser({ section: 'archive' }); await waitUntil(() => region.busy === 'false');
    assert.match(region.innerHTML, /草稿读取未完成/); assert.deepEqual(local.records, before); assert.equal(f.requests.length, 0);
});

test('explicitly discarded durable checkpoint is not revived on open', async t => {
    const f = await archiveFixture(t), local = localFixture(t), region = regionFor(f); const { origin } = await seed(f, 2);
    await D.clearArchiveRecoveryDurably(origin); const before = structuredClone(local.records); D.resetArchiveRecoveryMemoryForTests();
    overlay.showChooser({ section: 'archive' }); await waitUntil(() => region.busy === 'false');
    assert.doesNotMatch(region.innerHTML, /成功分段/); assert.deepEqual(local.records, before); assert.equal(f.requests.length, 0);
});

test('settings/content-only rendering does not open the archive draft database', async t => {
    const f = await archiveFixture(t), local = localFixture(t); regionFor(f); let reads = 0;
    L.setLocalRecoveryBackendForTests({ ...local.backend, read: async key => { reads++; return local.backend.read(key); } });
    overlay.showChooser({ section: 'content' }); await new Promise(r => setTimeout(r, 20)); assert.equal(reads, 0);
    assert.equal(f.requests.length, 0);
});


test('archive read after the live chat has closed does not reject outside its handler', async t => {
    const f = await archiveFixture(t); localFixture(t); regionFor(f);
    overlay.showChooser({ section: 'archive' });
    await assert.doesNotReject(() => overlay.loadChooserArchiveRecovery(null, { showEmpty: true }));
});

test('page-only success can still be exported when durable storage read fails', async t => {
    const f = await archiveFixture(t), local = localFixture(t);
    await seedPageOnly(f, local, 3);
    L.setLocalRecoveryBackendForTests({ ...local.backend, read: async () => { throw new Error('Synthetic failed read'); } });
    const before = structuredClone(f.ctx.chatMetadata);
    const value = await R.exportCurrentArchiveRecoveryAfterLoad(f.ctx);
    assert.equal(value.pageDrafts[0].journal.segments.filter(s => s.state === 'complete').length, 3);
    assert.deepEqual(f.ctx.chatMetadata, before); assert.equal(f.requests.length, 0);
});

test('unrelated corrupt profile draft cannot block exporting or saving valid import draft', async t => {
    const f = await archiveFixture(t), local = localFixture(t); await seed(f, 3); await seed(f, 1, 'profile');
    const profileRow = [...local.records.values()].find(r => r.payload.rows[0][1].operation === 'profile');
    profileRow.payload.version = -1; const before = structuredClone(profileRow);
    D.resetArchiveRecoveryMemoryForTests();
    const exported = await R.exportCurrentArchiveRecoveryAfterLoad(f.ctx);
    assert.equal(exported.pageDrafts[0].journal.segments.filter(s => s.state === 'complete').length, 3);
    assert.equal((await R.saveCurrentArchiveRecovery(f.ctx)).completed, 3);
    assert.deepEqual(local.records.get(profileRow.key), before); assert.equal(f.requests.length, 0);
});
