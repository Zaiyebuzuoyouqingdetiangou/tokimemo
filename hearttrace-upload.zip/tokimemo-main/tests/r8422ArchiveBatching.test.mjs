import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { execFileSync } from 'node:child_process';
import { archiveFixture, sourceRows, memoryReply, requestRows, clickImport, clickArchiveControl, clone } from './helpers/r8422ArchiveHost.mjs';
import * as R from '../src/archive/repository.js';
import * as B from '../src/archive/importBatches.js';
import * as budget from '../src/archive/requestBudget.js';
import * as context from '../src/core/context.js';
import * as settings from '../src/core/settings.js';
import * as C from '../src/core/constants.js';
import * as cache from '../src/core/cache.js';
import * as backup from '../src/archive/backupStore.js';
import * as recovery from '../src/archive/importRecovery.js';
import * as trace from '../src/core/taskTrace.js';
import * as text from '../src/core/text.js';
import { state } from '../src/core/state.js';

for (const [name, value] of [
    ['Chinese-80k', '中'.repeat(79990) + '最后尾段保留'],
    ['mixed-80k', 'A日🙂 punctuation '.repeat(5000) + 'FINAL_TAIL_8422'],
    ['single-300k', '单'.repeat(300000) + '单条最后尾巴'],
]) test(`complete source + exact-request planning preserves every code unit: ${name}`, async t => {
    const f = await archiveFixture(t);
    const records = R.normalizeExternalMemoryRecords([{ provider: 'synthetic', sourceId: 'long', content: value }], { complete: true });
    assert.equal(records.map(row => row.content).join(''), value);
    const measure = async (_kind, rows) => budget.measureArchiveRequest(f.ctx,
        budget.composeArchiveRequest(f.ctx, R.externalMemoryImportPrompt(f.ctx, rows), '实际人设背景'));
    const batches = await B.planSourceBatches(B.makeSourceUnits([], records), measure);
    const restored = batches.flatMap(parts => parts.flatMap(part => part.units.map(unit => unit.data.content))).join('');
    assert.equal(restored, value);
    for (const parts of batches) {
        const units = parts.flatMap(part => part.units);
        assert.ok(units.length <= C.MAX_EXTERNAL_MEMORY_ITEMS);
        assert.ok(units.reduce((n, unit) => n + unit.ref.length, 0) <= C.MAX_EXTERNAL_MEMORY_CHARS);
        for (const part of parts) { assert.equal(part.budget.exceeded, null); assert.equal(part.budget.outputTokens, 12000); }
    }
    if (value.length > 240000) assert.ok(batches.length >= 2);
});

test('80k characters in >256 fragments creates later batches without sampling', async t => {
    const f = await archiveFixture(t, { rows: sourceRows(400, 200) });
    const external = await R.currentMemorySourceLedgerExternal(f.ctx);
    assert.equal(external.records.length, 400);
    assert.equal(external.records.reduce((n, row) => n + row.content.length, 0), 80000);
    await clickImport(f);
    let bank = R.getImportedMemory(f.ctx);
    assert.equal(bank[B.IMPORT_PROGRESS_KEY].nextBatch, 1, JSON.stringify(f.notices));
    assert.equal(bank[B.IMPORT_PROGRESS_KEY].batches.length, 2);
    const calls = f.requests.length;
    await new Promise(resolve => setTimeout(resolve, 10));
    assert.equal(f.requests.length, calls, 'no automatic next batch or billed retry');
    assert.ok(R.requireArchive(f.ctx).memories.length, 'first saved batch is readable now');
    await clickImport(f);
    bank = R.getImportedMemory(f.ctx);
    assert.equal(bank[B.IMPORT_PROGRESS_KEY].nextBatch, 2, JSON.stringify(f.notices));
    const sent = f.requests.flatMap(messages => requestRows(messages).rows);
    assert.equal(sent.length, 400);
    assert.equal(new Set(sent.map(row => row.externalId)).size, 400);
    assert.ok(sent.at(-1).content.endsWith('尾000399'));
});

test('real production UI handler processes three explicit batches and reopens without sending saved sources', async t => {
    const f = await archiveFixture(t, { rows: sourceRows(620, 220) });
    const original = clone(R.getImportedMemory(f.ctx).memories[0]);
    const oldChat = JSON.stringify(f.ctx.chat);
    for (let batch = 1; batch <= 3; batch++) {
        await clickImport(f);
        const bank = R.getImportedMemory(f.ctx);
        assert.equal(bank[B.IMPORT_PROGRESS_KEY]?.nextBatch, batch, JSON.stringify(f.notices));
        assert.deepEqual(bank.memories[0], original);
        assert.deepEqual([...f.records.values()].find(row => row.archiveRevision === bank.archiveRevision).memory[B.IMPORT_PROGRESS_KEY], bank[B.IMPORT_PROGRESS_KEY]);
        recovery.clearArchiveRecovery(context.captureTaskOrigin(f.ctx, bank.archiveRevision));
        state.runtimeSessionCache.clear(); state.memoryPreflightCache.clear();
        f.ctx.chatMetadata[C.MEMORY_KEY] = clone([...f.records.values()].find(row => row.archiveRevision === bank.archiveRevision).memory);
    }
    const sent = f.requests.flatMap(messages => requestRows(messages).rows);
    assert.equal(sent.length, 620);
    assert.equal(new Set(sent.map(row => row.externalId)).size, 620);
    assert.equal(JSON.stringify(f.ctx.chat), oldChat);
    const stored = await f.persisted();
    assert.equal(stored.phone.apps[0].entries[0].detail, 'OLD_PHONE_PROSE_SENTINEL');
    assert.equal(stored.cabinet.items[0].text, 'OLD_OTHER_MODE_SENTINEL');
});

test('same-source failure resumes through the ordinary UI button, not the successful segment', async t => {
    const f = await archiveFixture(t, { rows: sourceRows(18, 5200) });
    let calls = 0, fail = true;
    f.setResponse(messages => { calls++; if (calls === 2 && fail) throw Object.assign(new Error('synthetic failure'), { code: 'RMT_JSON_INVALID' }); return memoryReply(messages); });
    const old = JSON.stringify(R.getImportedMemory(f.ctx));
    await clickImport(f);
    assert.equal(calls, 2); assert.equal(JSON.stringify(R.getImportedMemory(f.ctx)), old);
    assert.equal(R.getCurrentArchiveImportRecoverySummary(f.ctx).completed, 1);
    const first = JSON.stringify(f.requests[0]); fail = false;
    state.memoryPreflightCache.clear();
    await clickImport(f);
    assert.ok(R.getImportedMemory(f.ctx)[B.IMPORT_PROGRESS_KEY]?.nextBatch === 1, JSON.stringify(f.notices));
    assert.equal(f.requests.filter(value => JSON.stringify(value) === first).length, 1);
});

test('zero-success failure can explicitly restart with new configuration without deleting the prior draft', async t => {
    const f = await archiveFixture(t, { rows: sourceRows(2, 200) });
    f.setResponse(() => { throw Object.assign(new Error('fixture invalid'), { code: 'RMT_JSON_INVALID' }); });
    await clickImport(f);
    assert.equal(R.getCurrentArchiveImportRecoverySummary(f.ctx)?.completed, 0);
    const old = clone(R.getImportedMemory(f.ctx).memories);
    settings.updatePluginSettings({ maxTokens: 15000 });
    f.setResponse(messages => memoryReply(messages));
    await clickImport(f);
    assert.equal(f.requests.length, 1, 'ordinary button must not bypass changed settings');
    assert.ok(f.notices.some(row => row.message.includes('生成配置')));
    await clickArchiveControl(f, 'data-rmt-archive-restart');
    assert.ok(R.getImportedMemory(f.ctx)[B.IMPORT_PROGRESS_KEY]?.nextBatch === 1, JSON.stringify(f.notices));
    assert.deepEqual(R.getImportedMemory(f.ctx).memories.slice(0, old.length), old);
    assert.equal(R.exportCurrentArchiveImportProgress(f.ctx).pageDrafts.length, 1, 'old failed task preserved, not cleared');
});

for (const category of ['chat', 'character', 'persona', 'range', 'selection', 'configuration', 'archive']) test(`durable batch mismatch reports category and sends nothing: ${category}`, async t => {
    const f = await archiveFixture(t, { rows: sourceRows(300, 100) });
    await clickImport(f);
    const old = clone(R.getImportedMemory(f.ctx));
    if (category === 'chat') f.ctx.chat[0].mes += '正文变更';
    if (category === 'character') f.ctx.characters[0].data.personality += '角色变更';
    if (category === 'persona') f.ctx.powerUserSettings.persona_description += '变更';
    if (category === 'range') settings.updatePluginSettings({ chatReadRange: { mode: 'recent', recent: 30, includeHidden: true } });
    if (category === 'selection') R.setMemoryWorldInfoSelection(f.ctx, { books: [{ name: 'A-book', all: true, historySource: false }] });
    if (category === 'configuration') settings.updatePluginSettings({ maxTokens: 14000 });
    if (category === 'archive') f.ctx.chatMetadata[C.MEMORY_KEY].archiveRevision += '-changed';
    const count = f.requests.length;
    await clickImport(f);
    assert.equal(f.requests.length, count);
    assert.deepEqual(R.getImportedMemory(f.ctx).memories, old.memories);
    const expected = { chat: '聊天', character: '角色', persona: 'Persona', range: '范围', selection: '来源选择', configuration: '生成配置', archive: '档案版本' }[category];
    assert.ok(f.notices.some(row => row.message.includes(expected)), JSON.stringify(f.notices));
});

test('background ledger revision does not replace already captured remaining sources', async t => {
    const original = sourceRows(300, 160);
    const f = await archiveFixture(t, { rows: original });
    await clickImport(f);
    await f.putSources(original.map(row => ({ ...row, content: '后台修改版本，不应替换已捕获任务' })), 'newer');
    await clickImport(f);
    assert.equal(R.getImportedMemory(f.ctx)[B.IMPORT_PROGRESS_KEY].nextBatch, 2, JSON.stringify(f.notices));
    assert.equal(f.requests.flatMap(messages => requestRows(messages).rows).length, 300);
    assert.ok(f.requests.at(-1)[0].content.includes('尾000299'));
    assert.ok(!f.requests.at(-1)[0].content.includes('后台修改版本'));
});

test('save failure never advances canonical checkpoint; retry is save-only', async t => {
    const f = await archiveFixture(t, { rows: sourceRows(310, 120) });
    const old = clone(R.getImportedMemory(f.ctx));
    let reject = true;
    backup.setArchiveBackupBackendForTests({ read: async entry => clone(f.records.get(entry.entryId || context.archiveIndexEntryId(entry)) || null),
        put: async record => { if (reject) throw new DOMException('synthetic quota', 'QuotaExceededError'); f.records.set(record.entryId, clone(record)); return true; },
        delete: async () => { throw new Error('No deletes'); } });
    await clickImport(f);
    assert.deepEqual(R.getImportedMemory(f.ctx), old);
    assert.equal(R.getCurrentArchiveImportRecoverySummary(f.ctx).awaitingCommit, true);
    const calls = f.requests.length;
    reject = false;
    await clickImport(f);
    assert.equal(f.requests.length, calls);
    assert.equal(R.getImportedMemory(f.ctx)[B.IMPORT_PROGRESS_KEY].nextBatch, 1, JSON.stringify(f.notices));
});

test('240 cap retains all valid overflow without assigning evidence IDs or marking a batch done', async t => {
    const f = await archiveFixture(t, { rows: sourceRows(60, 800), memoryCount: 230 });
    const old = clone(R.getImportedMemory(f.ctx).memories);
    f.setResponse(messages => memoryReply(messages, { allRows: true }));
    await clickImport(f);
    const bank = R.getImportedMemory(f.ctx), progress = bank[B.IMPORT_PROGRESS_KEY];
    assert.equal(bank.memories.length, 240, JSON.stringify(f.notices));
    assert.deepEqual(bank.memories.slice(0, 230), old);
    assert.equal(progress.nextBatch, 0);
    assert.equal(progress.capacityPending.length, 50);
    assert.ok(progress.capacityPending.every(item => !item.id));
    assert.equal(B.progressTotals(progress).processed, 60);
    assert.equal(B.progressTotals(progress).saved, 0);
    const calls = f.requests.length;
    await clickImport(f); assert.equal(f.requests.length, calls);
    assert.equal(R.exportCurrentArchiveImportProgress(f.ctx).progress.capacityPending.length, 50);
    assert.ok(R.requireArchive(f.ctx).memories.length === 240);
});

test('cross-batch reaching exactly 240 blocks another billed request but keeps remaining plan', async t => {
    const f = await archiveFixture(t, { rows: sourceRows(270, 100), memoryCount: 236 });
    await clickImport(f);
    const bank = R.getImportedMemory(f.ctx), p = bank[B.IMPORT_PROGRESS_KEY];
    // 26k per request also includes per-fragment overhead: 256 small rows need five requests.
    assert.equal(bank.memories.length, 240, JSON.stringify(f.notices));
    assert.ok(p.nextBatch === 1 || p.capacityPending.length > 0);
    assert.ok(B.hasPendingBatches(p));
    const calls = f.requests.length;
    await clickImport(f); assert.equal(f.requests.length, calls);
    assert.ok(R.getCurrentArchiveImportRecoverySummary(f.ctx).capacityBlocked);
});

test('every valid model row is validated, including >48 rows: no hidden slice before capacity handling', async t => {
    const f = await archiveFixture(t, { rows: sourceRows(50, 40) });
    f.setResponse(messages => memoryReply(messages, { allRows: true }));
    await clickImport(f);
    assert.equal(R.getImportedMemory(f.ctx).memories.length, 51, JSON.stringify(f.notices));
});

test('empty legitimate batch saves a checkpoint and does not invent minimum memories', async t => {
    const f = await archiveFixture(t, { rows: sourceRows(300, 100) });
    f.setResponse({ memories: [] });
    await clickImport(f);
    const bank = R.getImportedMemory(f.ctx);
    assert.equal(bank.memories.length, 1);
    assert.equal(bank[B.IMPORT_PROGRESS_KEY].nextBatch, 1, JSON.stringify(f.notices));
    await clickImport(f);
    assert.equal(R.getImportedMemory(f.ctx)[B.IMPORT_PROGRESS_KEY].nextBatch, 2);
});

test('actual request measurements distinguish characters, bytes, tokens and requested output', async t => {
    const f = await archiveFixture(t);
    delete f.ctx.getTokenCountAsync;
    settings.updatePluginSettings({ maxTokens: 48000 });
    const actual = budget.composeArchiveRequest(f.ctx, '中'.repeat(80000), '背景🙂');
    const value = await budget.measureArchiveRequest(f.ctx, actual);
    assert.equal(value.utf16Chars, actual.length);
    assert.equal(value.utf8Bytes, new TextEncoder().encode(actual).byteLength);
    assert.equal(value.inputTokens, null); assert.equal(value.combinedTokens, null);
    assert.equal(value.outputTokens, 48000); assert.equal(value.contextTokens, null);
    assert.ok(value.utf8Bytes > value.utf16Chars * 2);
    const known = await budget.measureArchiveRequest(f.ctx, actual, { confirmedLimits: { maximumOutputTokens: 8192, contextTokens: 32768 } });
    assert.equal(known.exceeded, 'output');
    assert.equal(settings.getPluginSettings(f.ctx).maxTokens, 48000);
});

test('character and token budgets apply to full composed prompts; local splitting does not call provider', async t => {
    const f = await archiveFixture(t);
    f.ctx.getTokenCountAsync = async value => Array.from(value).length; // synthetic tokenizer fixture, not a provider claim
    const records = R.normalizeExternalMemoryRecords(sourceRows(20, 5200), { complete: true });
    const parts = await B.planSourceBatches(B.makeSourceUnits([], records), async (_kind, rows) => budget.measureArchiveRequest(f.ctx,
        budget.composeArchiveRequest(f.ctx, R.externalMemoryImportPrompt(f.ctx, rows), '背景'.repeat(10000))));
    for (const batch of parts) for (const part of batch) assert.ok(part.budget.inputTokens <= C.MAX_GENERATION_INPUT_TOKENS);
    assert.equal(parts.flatMap(batch => batch.flatMap(part => part.units)).reduce((n, unit) => n + unit.ref.length, 0), 104000);
    assert.equal(f.requests.length, 0);
});

test('an oversized background fails locally with numeric layer diagnostics and no user-output reduction', async t => {
    const f = await archiveFixture(t);
    delete f.ctx.getTokenCountAsync;
    const records = R.normalizeExternalMemoryRecords(sourceRows(1, 200), { complete: true });
    await assert.rejects(B.planSourceBatches(B.makeSourceUnits([], records), async (_kind, rows) => budget.measureArchiveRequest(f.ctx,
        budget.composeArchiveRequest(f.ctx, R.externalMemoryImportPrompt(f.ctx, rows), '背景'.repeat(60000)))), error => {
            assert.equal(error.code, 'RMT_ARCHIVE_CONTEXT_BUDGET');
            assert.ok(error.archiveBudget.utf8Bytes > 300000);
            assert.ok(text.safeErrorSummary(error).includes('UTF-8'));
            return true;
        });
    assert.equal(f.requests.length, 0); assert.equal(settings.getPluginSettings(f.ctx).maxTokens, 12000);
});

test('long single chat source preserves >8000 characters and detects edits in the former clipped tail', async t => {
    const f = await archiveFixture(t);
    f.ctx.chat.push({ is_user: true, name: '小月', mes: '共同经历。'.repeat(17000) + 'CHAT_TAIL_PRESERVED' });
    const snap = await context.buildChatSnapshot(f.ctx, { completeSource: true });
    assert.ok(snap.messages.at(-1).text.endsWith('CHAT_TAIL_PRESERVED'));
    await clickImport(f);
    const sent = f.requests.flatMap(messages => requestRows(messages).rows).map(row => row.text || '').join('');
    assert.ok(sent.endsWith('CHAT_TAIL_PRESERVED'), JSON.stringify(f.notices));
    const old = R.getImportedMemory(f.ctx).fullSourceFingerprint;
    f.ctx.chat.at(-1).mes += 'TAIL_EDIT';
    const changed = await context.buildChatSnapshot(f.ctx, { completeSource: true });
    assert.notEqual(changed.fullFingerprint, old);
    const calls = f.requests.length; await clickImport(f); assert.equal(f.requests.length, calls);
});

test('checkpoint and its memories are present together on disk, observable by an independent Node process', async t => {
    const f = await archiveFixture(t, { rows: sourceRows(300, 110) });
    const dir = mkdtempSync(join(tmpdir(), 'hearttrace-r8422-')); t.after(() => rmSync(dir, { recursive: true, force: true }));
    const path = join(dir, 'canonical.json');
    writeFileSync(path, JSON.stringify([...f.records.values()]));
    backup.setArchiveBackupBackendForTests({
        read: async entry => JSON.parse(readFileSync(path)).find(row => row.entryId === (entry.entryId || context.archiveIndexEntryId(entry))) || null,
        put: async (record, expected) => {
            const rows = JSON.parse(readFileSync(path));
            const index = rows.findIndex(row => row.entryId === record.entryId);
            if (expected.present && index >= 0) assert.equal(rows[index].archiveRevision, expected.revision);
            if (index < 0) rows.push(record); else rows[index] = record;
            writeFileSync(path, JSON.stringify(rows)); return true;
        }, delete: async () => { throw new Error('No deletes'); },
    });
    await clickImport(f);
    const values = JSON.parse(execFileSync(process.execPath, ['-e', `const fs=require('fs'); const row=JSON.parse(fs.readFileSync(process.argv[1])).find(r=>r.memory.archiveImportProgress); console.log(JSON.stringify({cursor:row.memory.archiveImportProgress.nextBatch,count:row.memory.memories.length,rev:row.archiveRevision,checkpointRev:row.memory.archiveImportProgress.archiveRevision}));`, path], { encoding: 'utf8' }));
    assert.equal(values.cursor, 1, JSON.stringify(f.notices));
    assert.ok(values.count > 1); assert.equal(values.rev, values.checkpointRev);
});

test('restart subtracts already saved adaptive source intervals rather than repeating them', async t => {
    const f = await archiveFixture(t, { rows: sourceRows(300, 1000) });
    await clickImport(f);
    const original = clone(R.getImportedMemory(f.ctx));
    const oldIds = new Set(f.requests.flatMap(messages => requestRows(messages).rows.map(row => row.externalId)));
    const calls = f.requests.length;
    settings.updatePluginSettings({ temperature: 0.2 });
    await clickArchiveControl(f, 'data-rmt-archive-restart');
    assert.ok(R.getImportedMemory(f.ctx).archiveRevision !== original.archiveRevision, JSON.stringify(f.notices));
    const newRows = f.requests.slice(calls).flatMap(messages => requestRows(messages).rows);
    assert.ok(newRows.length > 0);
    assert.ok(newRows.every(row => row.externalId && !oldIds.has(row.externalId)), 'No old chat floor or saved external row is resent');
    const [unit] = B.makeSourceUnits([], [{ provider: 'synthetic', externalId: 'long', content: '甲'.repeat(3000) + '乙'.repeat(2200) }]);
    const prior = { nextBatch: 1, batches: [[{ refs: [{ ...unit.ref, length: 3000, hash: B.sourceHash('甲'.repeat(3000)) }] }]] };
    const rest = B.excludeSavedUnits([unit], prior);
    assert.equal(rest.length, 1); assert.equal(rest[0].ref.offset, 3000); assert.equal(rest[0].data.content, '乙'.repeat(2200));
});

test('multiple selected worldbooks preserve all historical tails and append each setting background exactly once', async t => {
    const f = await archiveFixture(t);
    const books = ['历史一', '历史二', '设定一', '设定二'];
    f.ctx.getWorldInfoNames = () => books;
    f.ctx.loadWorldInfo = async name => ({ entries: { 1: { uid: 1, comment: name, content: name.startsWith('历史')
        ? name + '共同行走。'.repeat(31000) + `末尾${name}` : `SETTING_${name}_ONCE。现代庭院背景。` } } });
    R.setMemoryWorldInfoSelection(f.ctx, { books: books.map(name => ({ name, all: true, historySource: name.startsWith('历史') })) });
    // Explicit source scan is the same preflight required by the existing UI.
    await R.readCurrentChatMemoryPlugins();
    await clickImport(f, 'import-memory');
    let progress = R.getImportedMemory(f.ctx)[B.IMPORT_PROGRESS_KEY];
    assert.ok(progress?.batches.length >= 2, JSON.stringify(f.notices));
    while (B.hasPendingBatches(progress)) {
        await clickImport(f, 'import-memory');
        const next = R.getImportedMemory(f.ctx)[B.IMPORT_PROGRESS_KEY];
        assert.ok(next.nextBatch > progress.nextBatch, JSON.stringify(f.notices)); progress = next;
    }
    const prompts = f.requests.map(messages => requestRows(messages));
    for (const { prompt, kind } of prompts.filter(row => row.kind === 'external')) {
        for (const name of ['设定一', '设定二']) assert.equal(prompt.split(`SETTING_${name}_ONCE`).length - 1, 1, name);
        assert.ok(!prompt.includes('完整历史来源正文'), 'Historical books are not repeated as background');
    }
    const adopted = prompts.flatMap(row => row.rows.map(item => item.content || '')).join('');
    assert.ok(adopted.includes('末尾历史一') && adopted.includes('末尾历史二'));
    assert.equal(adopted.length, 310000 + '历史一末尾历史一历史二末尾历史二'.length);
});

test('legacy r84.21-shaped page journal resumes from the real button and queues the uncaptured tail', async t => {
    const f = await archiveFixture(t, { rows: sourceRows(300, 1000) });
    const existing = R.getImportedMemory(f.ctx), cfg = settings.getPluginSettings(f.ctx);
    const all = await R.currentMemorySourceLedgerExternal(f.ctx);
    const external = { ...all, records: R.normalizeExternalMemoryRecords(all.records) };
    const snapshot = await context.buildChatSnapshot(f.ctx, { prefixCount: existing.sourceMessageCount, readRange: cfg.chatReadRange });
    const chunks = R.splitSnapshotIntoChunks({ messages: snapshot.incrementalMessages });
    const externalChunks = R.splitExternalMemoryIntoChunks(external.records);
    const envelope = await cache.buildControlledContextEnvelope(f.ctx, { includeWorldInfoDepth: true }) + R.memoryWorldInfoPromptBlock(external.worldInfo);
    const origin = context.captureTaskOrigin(f.ctx, existing.archiveRevision);
    const generationSettings = Object.fromEntries(['apiConnectionMode','connectionProfileId','modelOverride','manualApiBaseUrl','manualApiModel','manualApiKey','manualApiStreaming','chatReadRange','useActivatedWorldInfo','maxTokens','temperature','useCurrentChatExternalMemory','excludedContextTags','bannedGeneratedPhrases','creativeSupplementEnabled','creativeSupplement'].map(key => [key, cfg[key]]));
    const inputOwner = JSON.stringify({ character: f.ctx.characters[0].data, persona: [f.ctx.name1, '', f.ctx.powerUserSettings.persona_description] });
    const ticket = await recovery.beginArchiveRecovery({ origin, sourceIdentity: JSON.stringify({ fullRebuild: false,
        archivePresent: true, baseRevision: existing.archiveRevision, snapshotFingerprint: snapshot.fingerprint,
        prefixFingerprint: snapshot.prefixFingerprint, sourceMessageCount: snapshot.totalMessages,
        externalFingerprint: external.fingerprint, contextEnvelope: envelope }),
        sourceFragments: [...chunks.map(JSON.stringify), ...externalChunks.map(JSON.stringify)],
        settingsIdentity: JSON.stringify({ settings: generationSettings, worldInfoSelection: R.getMemoryWorldInfoSelection(f.ctx).books,
            profile: settings.rawConnectionProfile(cfg.connectionProfileId, f.ctx) }),
        inputs: { external, contextEnvelope: envelope, inputOwner } });
    const options = { external: true, total: externalChunks.length, worldInfo: external.worldInfo,
        requestOptions: { maxTokens: C.MAX_GENERATION_OUTPUT_TOKENS, temperature: Math.min(cfg.temperature, 0.35),
            contextEnvelope: envelope, skipTokenCount: true } };
    await R.generateArchiveImportSegment(ticket, f.ctx, externalChunks[0], { ...options, index: 0 });
    f.setResponse(() => { throw Object.assign(new Error('old-page failure'), { code: 'RMT_JSON_INVALID' }); });
    await assert.rejects(R.generateArchiveImportSegment(ticket, f.ctx, externalChunks[1], { ...options, index: 1 }));
    recovery.releaseArchiveRecovery(ticket);
    const first = JSON.stringify(f.requests[0]);
    f.setResponse(messages => memoryReply(messages));
    await clickImport(f, 'import-memory');
    let progress = R.getImportedMemory(f.ctx)[B.IMPORT_PROGRESS_KEY];
    assert.equal(progress?.nextBatch, 1, JSON.stringify(f.notices)); assert.ok(progress.batches.length > 1);
    assert.equal(f.requests.filter(row => JSON.stringify(row) === first).length, 1);
    await clickImport(f, 'import-memory');
    progress = R.getImportedMemory(f.ctx)[B.IMPORT_PROGRESS_KEY]; assert.equal(progress.nextBatch, progress.batches.length, JSON.stringify(f.notices));
    const failedIds = requestRows(f.requests[1]).rows.map(row => row.externalId);
    const sent = f.requests.flatMap(request => requestRows(request).rows.map(row => row.externalId));
    assert.equal(new Set(sent).size, 300); assert.equal(sent.length, 300 + failedIds.length, 'Only the old failed segment was sent twice');
});

test('late in-flight edit beyond 8000 characters preserves canonical bank and the successful page segment', async t => {
    const f = await archiveFixture(t, { rows: sourceRows(2, 1000) });
    f.ctx.chat.push({ is_user: false, name: '林舟', mes: '首'.repeat(9000) + 'ORIGINAL_TAIL' });
    const old = clone(R.getImportedMemory(f.ctx));
    const pause = f.pauseProvider();
    const pending = clickImport(f); await pause.ready;
    f.ctx.chat[1].mes = f.ctx.chat[1].mes.replace('ORIGINAL_TAIL', 'CHANGED_TAIL'); pause.release(); await pending;
    assert.deepEqual(R.getImportedMemory(f.ctx), old);
    assert.ok(f.notices.some(row => row.message.includes('聊天正文')));
    assert.ok(R.getCurrentArchiveImportRecoverySummary(f.ctx)?.completed >= 1);
});

test('explicit cancellation retains original canonical results and does not auto-retry', async t => {
    const f = await archiveFixture(t, { rows: sourceRows(30, 3000) });
    const old = clone(R.getImportedMemory(f.ctx)), pause = f.pauseProvider();
    const pending = clickImport(f); await pause.ready; state.activeTaskAbortController.abort(); pause.release(); await pending;
    assert.deepEqual(R.getImportedMemory(f.ctx), old);
    assert.equal(f.requests.length, 1); assert.equal(state.busy, false);
});

test('optional checkpoint obeys the existing 12MB UTF8 bound rather than counting Chinese as bytes', () => {
    const progress = { version: 1, taskId: 'fixture', identity: {}, nextBatch: 0, batches: [], contextEnvelope: '中'.repeat(4000001) };
    assert.ok(JSON.stringify(progress).length < C.MAX_CACHE_SOURCE_BYTES);
    assert.throws(() => B.checkedProgress(progress), { code: 'RMT_ARCHIVE_CHECKPOINT' });
});

test('archive cover-only rewrite leaves all facts and batch checkpoints byte-identical', async t => {
    const f = await archiveFixture(t, { rows: sourceRows(300, 100) }); await clickImport(f);
    const old = clone(R.getImportedMemory(f.ctx));
    f.setResponse(() => ({ archiveName: '庭院里的共同记忆', verdictStyle: 'quiet-life', relationshipReading: { char: '愿意相伴', user: '同样参与', relation: '共同生活中的相伴', tension: '没有更多表达', direction: '已有相处仍在延续' }, archiveSummary: '一起栽花的记忆。',
        archiveVerdict: '两个人一起在庭院栽花，这份记录呈现的是他们共同参与一件小事的经历。花苗在庭院里慢慢生长，他们的关系仍应由已经发生的事实来理解，不需要提前给尚未表达的感情加上名字。对话没有说明更远的约定，档案也只留下这次相伴本身，以及两人愿意共同花费的时间。',
        verdictSources: [{ memoryId: 'M001', anchor: '庭院' }], keywords: ['庭院', '栽花'] }));
    const result = await R.rewriteCurrentArchiveVerdict();
    assert.equal(result.status, 'committed', JSON.stringify(f.notices));
    const current = R.getImportedMemory(f.ctx);
    assert.deepEqual(current.memories, old.memories); assert.deepEqual(current[B.IMPORT_PROGRESS_KEY], old[B.IMPORT_PROGRESS_KEY]);
    assert.equal(current.archiveRevision, old.archiveRevision);
});

for (const change of ['chat', 'character', 'persona']) test(`in-flight ${change} switch never writes into the other live archive`, async t => {
    const f = await archiveFixture(t, { rows: sourceRows(3, 1200) });
    const original = clone(f.ctx.chatMetadata), other = clone(f.otherBank), oldId = f.ctx.chatId, oldCharacter = f.ctx.characterId;
    const oldPersona = f.ctx.powerUserSettings.persona_description;
    const pause = f.pauseProvider(), pending = clickImport(f); await pause.ready;
    if (change === 'chat') { f.ctx.chatId = f.otherBank.chatId; f.ctx.chatMetadata = { [C.MEMORY_KEY]: other }; }
    if (change === 'character') f.ctx.characterId = 1;
    if (change === 'persona') f.ctx.powerUserSettings.persona_description += '在请求期间更换Persona';
    pause.release(); await pending;
    assert.equal(f.requests.length, 1);
    if (change === 'chat') assert.deepEqual(R.getImportedMemory(f.ctx), other);
    else assert.deepEqual(f.ctx.chatMetadata, original);
    assert.deepEqual(f.records.get(f.aEntry.entryId).memory, original[C.MEMORY_KEY]);
    f.ctx.chatId = oldId; f.ctx.characterId = oldCharacter; f.ctx.chatMetadata = original; f.ctx.powerUserSettings.persona_description = oldPersona;
});

test('cancel, explicit production delete, then late provider resolution cannot resurrect the archive', async t => {
    const f = await archiveFixture(t, { rows: sourceRows(3, 1200) });
    const groups = await import('../src/archive/groups.js');
    backup.setArchiveBackupBackendForTests({ read: async entry => clone(f.records.get(entry.entryId || context.archiveIndexEntryId(entry)) || null),
        put: async record => { f.records.set(record.entryId, clone(record)); return true; },
        delete: async entries => { for (const entry of Array.isArray(entries) ? entries : [entries]) {
            const id = context.archiveIndexEntryId(entry), old = f.records.get(id);
            f.records.set(id, { ...old, deleted: true, deletedAt: Date.now(), memory: null, cache: null, archiveRevision: '' });
        } return true; } });
    const oldChat = JSON.stringify(f.ctx.chat), pause = f.pauseProvider(), pending = clickImport(f);
    try {
        await pause.ready; state.activeTaskAbortController.abort();
        await Promise.race([pending, new Promise((_, reject) => setTimeout(() => reject(new Error('Cancellation did not settle')), 1500))]);
        const deleted = await groups.deleteCurrentHeartbeatArchive(''); assert.equal(deleted, true);
        pause.release(); await new Promise(resolve => setTimeout(resolve, 10));
        assert.equal(R.getImportedMemory(f.ctx), null); assert.equal(JSON.stringify(f.ctx.chat), oldChat);
        assert.equal(f.records.get(f.aEntry.entryId).deleted, true);
        assert.equal(f.requests.length, 1);
    } finally { pause.release(); }
});

test('Persona change during local preparation is named and stops before any paid provider request', async t => {
    const f = await archiveFixture(t, { rows: sourceRows(2, 300) });
    const original = clone(R.getImportedMemory(f.ctx)); f.ctx.user_avatar = 'original-persona.png';
    f.ctx.getTokenCountAsync = async () => { f.ctx.user_avatar = 'different-persona.png'; return 100; };
    await clickImport(f); assert.equal(f.requests.length, 0);
    assert.deepEqual(R.getImportedMemory(f.ctx), original);
    assert.ok(f.notices.some(row => row.message.includes('Persona')), JSON.stringify(f.notices));
});

test('durable pending save remains exportable after all page journals are gone', async t => {
    const f = await archiveFixture(t, { rows: sourceRows(300, 100) });
    backup.setArchiveBackupBackendForTests({ read: async entry => clone(f.records.get(entry.entryId || context.archiveIndexEntryId(entry)) || null),
        put: async () => { throw new DOMException('synthetic write failure', 'QuotaExceededError'); }, delete: async () => { throw new Error('No deletion'); } });
    await clickImport(f); assert.equal(R.getCurrentArchiveImportRecoverySummary(f.ctx).awaitingCommit, true);
    recovery.clearArchiveRecovery(context.captureTaskOrigin(f.ctx, R.getImportedMemory(f.ctx).archiveRevision));
    const value = R.exportCurrentArchiveImportProgress(f.ctx);
    assert.equal(value.pageDrafts.length, 0);
    assert.equal(value.pendingSave.formallyCommitted, false);
    assert.ok(value.pendingSave.memoryBank.memories.length > R.getImportedMemory(f.ctx).memories.length);
    assert.equal(value.pendingSave.memoryBank[B.IMPORT_PROGRESS_KEY].nextBatch, 1);
    assert.equal(R.getImportedMemory(f.ctx)[B.IMPORT_PROGRESS_KEY], undefined, 'exported staged checkpoint is NOT a canonical saved cursor');
});
