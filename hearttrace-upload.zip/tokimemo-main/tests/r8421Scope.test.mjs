import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
const root=new URL('../',import.meta.url),read=p=>fs.readFileSync(new URL(p,root),'utf8');
const base=JSON.parse(read('tests/helpers/r8421-baseline-hashes.json'));
const sha=x=>createHash('sha256').update(x).digest('hex');
for(const dir of ['src/archive/','src/core/','src/generation/','src/modes/','src/ui/'])test('r84.21 exact production scope vs r84.20 '+dir,()=>{
 for(const [p,h] of Object.entries(base.sourceHashes))if(p.startsWith(dir)&&p!=='src/core/independentApi.js')assert.equal(sha(read(p)),h,p);
});
test('all non-version bootstrap code is identical',()=>{assert.equal(sha(read('index.js').split('\n').slice(2).join('\n')),base.indexBodySha)});
test('manual model listing and its fixed protocol remain byte-identical',()=>{const s=read('src/core/independentApi.js');assert.equal(sha(s.slice(s.indexOf('export async function fetchManualApiModels'),s.indexOf('export async function requestManualApiCompletion'))),base.apiModelListSha)});
test('request URL/body/headers/streaming preference remain byte-identical',()=>{const s=read('src/core/independentApi.js').split('export async function requestManualApiCompletion')[1];assert.equal(sha('export async function requestManualApiCompletion'+s.slice(0,s.indexOf('    const decoded'))),base.requestPrefixSha)});
test('final envelope and JSON fallback semantics remain byte-identical',()=>{const s=read('src/core/independentApi.js').split('export async function requestManualApiCompletion')[1];assert.equal(sha(s.slice(s.indexOf('    if (payloadHasProviderError(payload))'))),base.requestSuffixSha)});
test('no new exported transport or private-bridge entry point',()=>{assert.deepEqual(read('src/core/independentApi.js').split('\n').filter(x=>x.startsWith('export ')).map(x=>x.split('(')[0]),base.apiExports)});
test('bounded detector introduces no requests, user storage, timers, diagnostics or model fallback',()=>{
 const s=read('src/core/independentApi.js');const helper=s.slice(s.indexOf('const MANUAL_RESPONSE_SNIFF_BYTES'),s.indexOf('export async function fetchManualApiModels'));
 assert.doesNotMatch(helper,/\b(?:fetch|requestJson|setTimeout|setInterval|eval|Function|localStorage|indexedDB|console|toastr)\s*[.(]/);
 assert.match(helper,/MANUAL_RESPONSE_SNIFF_BYTES = 8192/);assert.match(helper,/buffered\.length = 0/);
});
test('r84.21 manifest/build/cache agree and do not alter other manifest capabilities',()=>{
 const m=JSON.parse(read('manifest.json'));assert.equal(m.version,'0.8.97');assert.equal(m.js,'index.js?heartbeat=0.8.97-tt-cg-r84.21-response-routing');assert.ok(read('index.js').includes("const BUILD = '0.8.97-tt-cg-r84.21-response-routing'"));
 const old={...base.manifest},actual={...m};for(const k of ['version','js','description']){delete old[k];delete actual[k];}assert.deepEqual(actual,old);
});
