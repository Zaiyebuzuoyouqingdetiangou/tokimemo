import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import * as visual from '../src/core/cgVisualRules.js';
import * as policy from '../src/generation/cgPromptPolicy.js';
import * as fmt from '../src/core/cgPromptFormat.js';
import * as looks from '../src/core/castLooks.js';
import * as appearance from '../src/generation/cgAppearance.js';
import * as images from '../src/generation/imageGeneration.js';
import * as client from '../src/generation/client.js';
import * as recovery from '../src/generation/recovery.js';
import * as context from '../src/core/context.js';
import * as cache from '../src/core/cache.js';
import * as constants from '../src/core/constants.js';
import * as patch from '../src/core/cgImagePatch.js';
import * as settings from '../src/core/settings.js';
import * as album from '../src/modes/album.js';
import * as adv from '../src/modes/advEvent.js';
import * as heart from '../src/modes/heart.js';
import * as overlay from '../src/ui/overlay.js';
import {state} from '../src/core/state.js';
import {fixture} from './helpers/r847Host.mjs';

const scene='两人在庭院栽花，当前画面中一人扶花苗，另一人拿水壶。';
const draft=()=>({schemaVersion:1,sceneTags:'2people, courtyard, gardening, seedling, watering can',flatPrompt:'In a courtyard, the person with a black high ponytail steadies a seedling while the person with long silver hair holds a watering can.',characters:[{role:'char',tag:'black hair, high ponytail',nl:'黑发高马尾'},{role:'user',tag:'silver hair, long hair',nl:'银色长发'}]});
const item=()=>({id:'visual-one',title:'庭院栽花',date:'日期未记录',desc:scene,cgDesc:scene,subtitle:'庭院的一刻',unlocked:true,category:'日常',sourceMemoryIds:['M001'],sourceMemoryAnchor:'庭院',imagePrompt:scene,visualSeed:['庭院','花苗','水壶','人物'],panelCount:4,panels:Array.from({length:4},(_,i)=>({action:['扶花苗','拿水壶','翻土','放下工具'][i],caption:'第'+(i+1)+'格',charLine:'原台词'+i,userLine:'原回应'+i})),cgPromptDraft:draft()});
const first=(s,mode)=>mode==='album'?s.entries[0]:mode==='adv'?s.events[0]:s.dailyStrips[0];

for(const format of fmt.CG_PROMPT_FORMATS)for(const [mode,key]of [['album','a:index'],['album','a:album'],['adv','a:index'],['adv','a:event'],['heart','a:strip'],['heart','a:strips']])test(`shared first-generation authoring ${mode}/${key}/${format}`,()=>{
 const origin={};policy.bindCgPromptFormat(origin,format);
 const p=policy.cgPromptForSegment('BASE',{origin,mode,taskKey:key});
 assert.ok(p.startsWith('BASE'));assert.ok(p.includes(visual.CG_VISUAL_AUTHORING_RULES));assert.match(p,/cgPromptDraft/);assert.match(p,/当前画面没有笑就不补笑/);
 assert.equal(p.includes('【CG_COMIC_LAYOUT_V2】'),mode==='heart');
 assert.match(p,format==='nai45-tags'?/完整英文Tag画面/:/完整自然语言画面/);
});
for(const format of fmt.CG_PROMPT_FORMATS)for(const mode of ['album','adv','heart'])test(`same authoring rules on explicit reconceive ${mode}/${format}`,()=>{
 const p=images.buildCgReconceptPrompt(item(),{name1:'小月',name2:'林舟'},mode,{characters:[]},format);
 assert.ok(p.includes(visual.CG_VISUAL_AUTHORING_RULES));assert.equal(p.includes('【CG_COMIC_LAYOUT_V2】'),mode==='heart');
 if(mode==='heart'){assert.match(p,/恰好4格/);assert.match(p,/上下四格/);assert.match(p,/放下工具/);assert.doesNotMatch(p,/原台词[0-9]/);}
});
for(const count of [1,2,4])for(const format of fmt.CG_PROMPT_FORMATS)test(`comic count and vertical wrapper remain aligned ${count}/${format}`,()=>{
 const it={panelCount:count,panels:Array.from({length:count},()=>({action:'翻书'}))};
 assert.match(visual.cgComicLayoutInstructions(it),new RegExp('恰好'+count+'格'));
 assert.match(fmt.formatDailyComicPrompt(it,'第1格，人物翻书',format),count===1?/single.panel/:new RegExp(count+(format==='nai45-tags'?'koma':' vertically arranged panels')));
});
test('non-image segments are not given any new rule',()=>{
 const origin={};policy.bindCgPromptFormat(origin,'nai5-natural');
 for(const [mode,key]of [['album','a:relationship'],['album','a:comments'],['adv','a:prose'],['heart','a:voice:spring'],['heart','a:scenario:spring'],['heart','a:languages'],['heart','a:fireflies'],['archive','a:index'],['travel','a:travel-map'],['themeSong','a:song'],['ending','a:event']])assert.equal(policy.cgPromptForSegment('UNCHANGED',{origin,mode,taskKey:key}),'UNCHANGED');
});
test('automatic appearance excludes habits, conditional emotion, clothes and fragments without touching scene',()=>{
 const raw='身高:183，笑起来眼睛弯成月牙，嘴角总是带着笑，发型:，- 黑发高马尾，衣服一定要舒适，有人同情时一脸莫名其妙，被调侃会红耳朵，耳朵悄悄红，- **肤色：** 冷白皮，- **眼睛：** 杏眼，天生红发';
 const a=looks.lookFromDescription(raw);
 for(const value of ['183','黑发高马尾','冷白皮','杏眼','红发'])assert.ok(a.includes(value),a);
 assert.doesNotMatch(a,/笑|调侃|同情|衣服|发型:|\*\*|悄悄红/);
 assert.equal(visual.automaticAppearanceClause('usually smiling with blue eyes'),'');
 assert.equal(visual.automaticAppearanceClause('black high ponytail'),'black high ponytail');
});
test('opening auto legacy looks removes habits without rewriting stored record; manual and saved images exact',()=>{
 const auto={char:'黑发高马尾，平时总带着笑，耳朵悄悄红',user:'长直发，冷白皮',manual:false};
 const ctx={chatId:'c',characterId:0,name1:'乙',name2:'甲',chatMetadata:{[looks.CAST_LOOKS_KEY]:{...auto,chatId:'c'}}};
 const before=JSON.stringify(ctx.chatMetadata);const clean=appearance.initialCgAppearanceMetadata({},ctx);
 assert.doesNotMatch(JSON.stringify(clean),/总带着笑|悄悄红/);assert.equal(JSON.stringify(ctx.chatMetadata),before);
 ctx.chatMetadata[looks.CAST_LOOKS_KEY].manual=true;
 assert.match(appearance.initialCgAppearanceMetadata({},ctx).characters[0].tag,/总带着笑/,'manual remains editable user choice');
 const saved={cgImage:{promptMetadata:{sceneTags:'original',flatPrompt:'USER_EDITED_SCENE',characters:[{role:'char',name:'甲',tag:'用户手填微笑'}] }},cgPromptDraft:draft()};
 assert.deepEqual(appearance.initialCgAppearanceMetadata(saved,ctx),appearance.normalizeCgPromptMetadata(saved.cgImage.promptMetadata));
});
test('initial generated appearances bind names locally and never restore raw automatic excerpts',()=>{
 const ctx={name1:'小月',name2:'林舟',chatId:'c',characterId:0,chatMetadata:{[looks.CAST_LOOKS_KEY]:{chatId:'c',char:'黑发，耳朵悄悄红',manual:false}}};
 const d=draft();d.characters[0].name='OTHER_CHAT_NAME';d.writeTarget='another-chat';
 const md=appearance.initialCgAppearanceMetadata({cgPromptDraft:d},ctx);
 assert.equal(md.characters[0].name,'林舟');assert.equal(md.characters[0].tag,'black hair, high ponytail');assert.equal(md.flatPrompt,d.flatPrompt);assert.doesNotMatch(JSON.stringify(md),/悄悄红|OTHER_CHAT|writeTarget/);
 const edited=appearance.metadataAfterSceneEdit(md);assert.ok(!edited.flatPrompt&&!edited.sceneTags);assert.deepEqual(edited.characters,md.characters);
});
test('public library habits are not immutable appearance but user draft remains untouched',()=>{
 const ctx={name1:'乙',name2:'甲',getCharacterCardFields:()=>({description:'黑发，蓝眼'})};
 const api={apiVersion:1,capabilities:{characterLibrary:true},getCharacters:()=>({apiVersion:1,characters:[{name:'甲',tag:'black hair, always smiling, blue eyes',nl:'笑着的人'}]})};
 const evidence=appearance.captureCgAppearanceEvidence(ctx,{api});assert.equal(evidence.characters[0].knownTag,'black hair, blue eyes');assert.equal(evidence.characters[0].knownNl,'');
 const user=appearance.appearanceEvidenceWithDraft(evidence,{char:'black hair, smiling'});assert.equal(user.characters[0].knownTag,'black hair, smiling');
});
for(const [label,mutate]of [
 ['schema',x=>x.schemaVersion=9],['duplicate-role',x=>x.characters[1].role='char'],['unknown-role',x=>x.characters[0].role='stranger'],['too-many',x=>x.characters.push({role:'other'})],['long-scene',x=>x.sceneTags='x'.repeat(601)],['long-flat',x=>x.flatPrompt='x'.repeat(1801)],['long-tag',x=>x.characters[0].tag='x'.repeat(401)],['bad-array',x=>x.characters='invalid'],['empty-flat',x=>x.flatPrompt=''],['getter',x=>Object.defineProperty(x,'flatPrompt',{get(){throw new Error('getter must not run')}})],['row-getter',x=>Object.defineProperty(x.characters,'0',{get(){throw new Error('getter must not run')}})]
])test(`optional bad generated metadata never rejects valid content: ${label}`,()=>{
 const d=draft();mutate(d);assert.equal(visual.normalizeGeneratedCgDraft(d),null);assert.deepEqual(visual.generatedCgDraftFields({cgPromptDraft:d}),{});
 const strip=heart.normalizeHeartStripsPart({dailyStrips:[{...item(),cgPromptDraft:d} ]})[0];assert.equal(strip.imagePrompt,scene);assert.equal(strip.cgPromptDraft,undefined);
});
test('generated text sanitization is inert, bounded, idempotent and ignores target keys',()=>{
 const d=draft();d.characters[0].tag='<img src=x>黑发';d.characters[0].nl='{{user}} https://example.invalid/token';d.target='another-chat';d.__proto__=null;
 const n=visual.normalizeGeneratedCgDraft(d);assert.ok(n);assert.equal(n.characters[0].tag,'黑发');assert.equal(n.characters[0].nl,'');assert.deepEqual(visual.normalizeGeneratedCgDraft(n),n);assert.equal(n.target,undefined);
});
for(const mode of ['album','adv','heart'])for(const format of fmt.CG_PROMPT_FORMATS)for(const multi of [true,false])test(`first generation -> editor metadata -> draw -> save -> reload ${mode}/${format}/multi=${multi}`,async t=>{
 const f=await fixture(t);settings.updatePluginSettings({cgPromptFormat:format});
 f.ctx.chatMetadata[looks.CAST_LOOKS_KEY]={chatId:f.ctx.chatId,char:'黑发，平时总带着笑',user:'银发，被调侃会红耳朵',manual:false};
 const raw=item();if(format==='nai45-tags'){raw.imagePrompt='2people, gardening, courtyard';raw.cgPromptDraft.flatPrompt='2people, black hair, high ponytail, steadying seedling, silver hair, long hair, holding watering can, courtyard';}
 const calls=[];const previous=Object.getOwnPropertyDescriptor(globalThis,'STBaiBaiImage');t.after(()=>previous?Object.defineProperty(globalThis,'STBaiBaiImage',previous):delete globalThis.STBaiBaiImage);
 globalThis.STBaiBaiImage={apiVersion:1,capabilities:{generate:true,saveToGallery:true},getBackendStatus:()=>({configured:true,supportsCharacters:multi}),async generate(value){calls.push(structuredClone(value));return{path:'/user/images/audit/r8420.png'}}};
 f.setResponse(messages=>{const p=messages.map(m=>m.content).join('\n');
  if(p.includes('ALBUM_RELATIONSHIP_FULL_ARCHIVE_JSON'))return{charState:'友好',userState:'未确认',relationshipSummary:'一同栽花。',relationshipSourceMemoryIds:['M001'],relationshipSourceMemoryAnchor:'庭院'};
  if(p.includes('CG_VISUAL_AUTHORING_V2'))return mode==='album'?{entries:[raw]}:mode==='adv'?{events:[raw]}:{dailyStrips:[raw]};
  return{items:[{id:raw.id,comments:Array.from({length:6},(_,i)=>'现在我想和你聊聊庭院的花。'+i)}]};});
 const before=await f.persisted();const bodyBefore=JSON.stringify(f.ctx.chat);
 if(mode==='heart'){await overlay.openCachedOrGenerate('heart',{workspaceRoute:'strips'});await heart.generateHeartSection('strips');}
 else assert.ok(await client.generateMode(mode,{background:true}),JSON.stringify(f.notices));
 const count=mode==='album'?3:1;assert.equal(f.requests.length,count,JSON.stringify(f.notices));
 const saved=await f.persisted();assert.deepEqual(first(saved[mode],mode).cgPromptDraft,raw.cgPromptDraft);
 const p=f.requests[0].map(m=>m.content).join('\n');assert.ok(p.includes(visual.CG_VISUAL_AUTHORING_RULES));if(mode==='heart')assert.match(p,/上下四格/);
 for(const req of f.requests.slice(1))assert.doesNotMatch(JSON.stringify(req),/CG_VISUAL_AUTHORING_V2/);
 state.runtimeSessionCache.clear();await cache.ensureCacheHydrated(f.ctx);await f.open(mode);if(mode==='heart'){state.activeSession.view='strips';state.activeSession.selectedStripId=raw.id;}
 const current=first(state.activeSession,mode);const md=appearance.initialCgAppearanceMetadata(current,f.ctx);
 assert.doesNotMatch(JSON.stringify(md),/总带着笑|调侃/);assert.equal(md.characters[0].tag,'black hair, high ponytail');
 const preview=images.cgEditorSendPreview(mode,current,current.imagePrompt,md,format);
 await images.drawSelectedCgImage({promptOverride:current.imagePrompt,promptMetadata:md,promptFormat:format});
 assert.equal(calls.length,1,JSON.stringify(f.notices));assert.equal(calls[0].prompt,preview.prompt);assert.equal(calls[0].nl,preview.nl);assert.deepEqual(calls[0].characters,preview.characters);assert.equal(f.requests.length,count);
 const after=await f.persisted();assert.equal(first(after[mode],mode).cgImage.url,'/user/images/audit/r8420.png');assert.deepEqual(after.cabinet,before.cabinet);assert.deepEqual(after.phone,before.phone);assert.equal(JSON.stringify(f.ctx.chat),bodyBefore);
 state.runtimeSessionCache.clear();await cache.ensureCacheHydrated(f.ctx);await f.open(mode);assert.equal(first(state.activeSession,mode).cgImage.url,'/user/images/audit/r8420.png');
 assert.deepEqual(appearance.initialCgAppearanceMetadata(first(state.activeSession,mode),f.ctx),first(after[mode],mode).cgImage.promptMetadata);
});
const captured=JSON.parse(fs.readFileSync(new URL('./helpers/r8420-legacy-cg-journals.json',import.meta.url),'utf8'));
for(const c of captured)test(`actual r84.19 journal replays success and resumes exact pending request ${c.mode}/${c.format}`,async t=>{
 const f=await fixture(t);const existing=structuredClone(c.journal);existing.updatedAt=Date.now();existing.createdAt=Date.now();
 const origin=context.captureTaskOrigin(f.ctx,f.liveBank.archiveRevision);await client.beginModeRecovery(c.mode,f.ctx,f.liveBank,origin,{operation:c.operation,existing,cgPromptFormat:'nai5-natural'});
 const opts=key=>({context:f.ctx,contextEnvelope:'',origin,mode:c.mode,taskKey:key,maxTokens:3000,background:true});
 f.setResponse({imagePrompt:'done-now'});const replay=await client.requestValidatedSegment('UNCHANGED_BASE_A','audit',opts(c.keys[0]),x=>x);assert.equal(replay.marker,'paid-success');assert.equal(f.requests.length,0);
 await client.requestValidatedSegment('UNCHANGED_BASE_B','audit',opts(c.keys[1]),x=>x);assert.equal(f.requests.length,1);assert.deepEqual(f.requests[0],c.requests[1]);assert.doesNotMatch(JSON.stringify(f.requests),/CG_VISUAL_AUTHORING_V2/);recovery.detachGenerationRecovery(origin);
});

for(const mode of ['album','adv','heart'])test(`replacement visual draft cannot receive stale image patch: ${mode}`,()=>{
 const it=item(),rows=mode==='album'?'entries':mode==='adv'?'events':'dailyStrips';
 const session={kind:mode,[rows]:[it]};
 const image={url:'/user/images/audit/stale.png',prompt:'old drawing',provider:'baibai-image',generatedAt:1};
 const pending={version:1,mode,itemId:it.id,expectedSignature:patch.cgItemSignature(it),image};
 assert.equal(patch.applyCgImagePatch(session,pending).status,'applied');
 const changed=structuredClone(session);changed[rows][0].cgPromptDraft.flatPrompt='Replacement scene draft';
 const before=JSON.stringify(changed);assert.equal(patch.applyCgImagePatch(changed,pending).status,'conflict');
 assert.equal(JSON.stringify(changed),before);assert.equal(changed[rows][0].cgImage,undefined);
});
test('new signature guard leaves every legacy field and invalid-optional-draft signature unchanged',()=>{
 const it=item();delete it.cgPromptDraft;
 const old=JSON.stringify([it.id,it.title,it.date,it.desc,it.cgDesc,it.subtitle,it.imagePrompt,it.visualSeed,it.panelCount,it.panels,patch.normalizeCgImageRecord(it.cgImage)]);
 assert.equal(patch.cgItemSignature(it),old);
 assert.equal(patch.cgItemSignature({...it,cgPromptDraft:{unexpected:'not a draft'}}),old);
});
test('live image target rejects replacement visual draft before a drawing result commits',async t=>{
 const f=await fixture(t);const it=item();
 const session={kind:'album',chatId:f.liveBank.chatId,archiveRevision:f.liveBank.archiveRevision,entries:[it],selectedId:it.id};
 assert.equal(cache.saveSession('album',session,f.liveBank.chatId),true);
 await f.open('album');
 const target=images.captureCgImageTarget();assert.ok(target);assert.equal(images.isCgImageTargetCurrent(target),true);
 state.activeSession.entries[0].cgPromptDraft.flatPrompt='Replacement visual draft';
 assert.equal(images.isCgImageTargetCurrent(target),false);
 assert.throws(()=>images.assertCgImageTargetCurrent(target),e=>e.code==='RMT_CG_TARGET_CHANGED');
});
