import test from 'node:test';
import assert from 'node:assert/strict';
import { assertPromptBudget } from '../src/generation/client.js';
import * as constants from '../src/core/constants.js';
import * as outputBudget from '../src/core/outputBudget.js';
import * as settings from '../src/core/settings.js';

function settingsContext(persisted) {
    return {
        name1: '用户', name2: '角色',
        extensionSettings: { [constants.EXTENSION_SETTINGS_KEY]: persisted },
        saveSettingsDebounced() {},
    };
}

test('input budget validation accepts only safe integers inside 8000-128000', () => {
    assert.equal(outputBudget.isValidInputBudgetTokens(7999), false);
    assert.equal(outputBudget.isValidInputBudgetTokens(8000), true);
    assert.equal(outputBudget.isValidInputBudgetTokens(128000), true);
    assert.equal(outputBudget.isValidInputBudgetTokens(128001), false);
    assert.equal(outputBudget.isValidInputBudgetTokens(32000.5), false);
    assert.equal(outputBudget.isValidInputBudgetTokens('abc'), false);
    assert.equal(outputBudget.isValidInputBudgetTokens(''), false);
    assert.equal(outputBudget.isValidInputBudgetTokens(undefined), false);
    assert.equal(outputBudget.isValidInputBudgetTokens('48000'), true);
});

test('input budget normalization falls back to the default 32000', () => {
    assert.equal(outputBudget.normalizeInputBudgetTokens(48000), 48000);
    assert.equal(outputBudget.normalizeInputBudgetTokens('48000'), 48000);
    assert.equal(outputBudget.normalizeInputBudgetTokens(7999), 32000);
    assert.equal(outputBudget.normalizeInputBudgetTokens(128001), 32000);
    assert.equal(outputBudget.normalizeInputBudgetTokens('abc'), 32000);
    assert.equal(outputBudget.normalizeInputBudgetTokens(''), 32000);
    assert.equal(outputBudget.normalizeInputBudgetTokens(undefined), 32000);
});

test('getPluginSettings applies a valid persisted input budget', () => {
    const context = settingsContext({ inputBudgetTokens: 48000 });
    assert.equal(settings.getPluginSettings(context).inputBudgetTokens, 48000);
});

test('getPluginSettings normalizes an invalid persisted input budget to 32000', () => {
    const context = settingsContext({ inputBudgetTokens: 128001 });
    assert.equal(settings.getPluginSettings(context).inputBudgetTokens, 32000);
});

test('assertPromptBudget allows input within the configured budget', async () => {
    const context = settingsContext({ inputBudgetTokens: 48000 });
    context.getTokenCountAsync = async () => 40000;
    await assert.doesNotReject(assertPromptBudget(context, 'fixture prompt'));
});

test('assertPromptBudget rejects input above the configured budget with guidance', async () => {
    const context = settingsContext({ inputBudgetTokens: 48000 });
    context.getTokenCountAsync = async () => 49000;
    await assert.rejects(assertPromptBudget(context, 'fixture prompt'), error => {
        assert.equal(error.code, 'RMT_INPUT_BUDGET');
        assert.ok(error.message.includes('48,000'), `message names the active budget: ${error.message}`);
        return true;
    });
});

test('fixtures without a settings host keep the default 32000 budget', async () => {
    const context = { getTokenCountAsync: async () => 33000 };
    await assert.rejects(assertPromptBudget(context, 'fixture prompt'), error => {
        assert.equal(error.code, 'RMT_INPUT_BUDGET');
        assert.ok(error.message.includes('32,000'), `message names the default budget: ${error.message}`);
        return true;
    });
});

test('the character hard limit is unchanged by the configurable token budget', async () => {
    const context = settingsContext({ inputBudgetTokens: 128000 });
    const prompt = 'x'.repeat(constants.MAX_GENERATION_INPUT_CHARS + 1);
    await assert.rejects(assertPromptBudget(context, prompt, { skipTokenCount: true }),
        error => error.code === 'RMT_INPUT_BUDGET');
});
