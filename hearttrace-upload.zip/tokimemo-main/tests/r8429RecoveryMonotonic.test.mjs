// New regression tests use synthetic data only; no user journal, prompt or key.
import test from 'node:test';
import assert from 'node:assert/strict';
import * as recovery from '../src/generation/recovery.js';
import * as progress from '../src/generation/partialProgress.js';
import * as merge from '../src/generation/recoveryMerge.js';
import * as adapters from '../src/generation/recoveryAdapters.js';
import * as album from '../src/modes/album.js';
import * as achievements from '../src/modes/achievements.js';

const bank = { version: 3, chatId: 'recovery-test-chat', archiveRevision: 'recovery-test-revision', characterName: '林舟', userName: '小月',
    memories: [{ id: 'M001', title: '栽花', summary: '林舟与小月一同在庭院栽花。', anchors: ['庭院'], participants: ['林舟', '小月'] }] };
const fields = { name1: bank.userName, name2: bank.characterName, characterId: 0, characters: [{ name: bank.characterName, avatar: 'fixture.png' }] };
const snapshot = { version: 1, fields, memoryBank: bank, contentInputs: {} };
const origin = () => ({ characterKey: 'recovery-test-character', characterId: '0', characterAvatar: 'fixture.png', chatId: bank.chatId, archiveRevision: bank.archiveRevision, archiveTargetEntryId: 'fixture-entry' });
const ref = { sourceMemoryIds: ['M001'], sourceMemoryAnchor: '庭院' };
const cg = id => ({ id, title: `庭院镜头${id}`, date: '待定', desc: '林舟和小月站在庭院花架旁。', category: '日常', unlocked: true, ...ref,
    visualSeed: ['花架', '庭院', '午后', '花盆'], imagePrompt: '午后光线照在庭院中的两个人与花架上。', hintLines: [] });
const rich = () => '{"entries":[' + [cg('CG01'), cg('CG02')].map(JSON.stringify).join(',') + ',{"id":"CG03","title":"unfinished';
const shorter = () => '{"entries":[' + JSON.stringify(cg('CG01')) + ',{"id":"CG02","title":"unfinished';
async function harness(t, mode = 'album', extra = {}) {
    const o = origin(); let saved = null, calls = 0, failSave = false;
    const save = value => { if (failSave) return false; saved = structuredClone(value); return true; };
    let handle = await recovery.createGenerationRecovery({ origin: o, mode, settingsIdentity: 'same-settings', contentSnapshot: snapshot, save, draftId: 'fixture-draft', pageId: mode, ...extra });
    recovery.attachGenerationRecovery(o, handle); t.after(() => recovery.detachGenerationRecovery(o));
    const opts = { origin: o, mode, taskKey: `mode:${mode}:index`, contextEnvelope: 'same-context' };
    const validate = mode === 'album' ? raw => album.normalizeAlbumIndex(raw, bank) : raw => raw;
    return { o, opts, validate, get handle() { return handle; }, get saved() { return saved; }, get calls() { return calls; },
        failSave(value) { failSave = value; },
        async resume() {
            recovery.detachGenerationRecovery(o);
            handle = await recovery.createGenerationRecovery({ origin: o, mode, settingsIdentity: 'same-settings', existing: saved, continueRequested: true, save, ...(extra.assertCurrent ? { assertCurrent: extra.assertCurrent } : {}) });
            recovery.attachGenerationRecovery(o, handle);
        },
        async fail(raw) {
            let e;
            await assert.rejects(recovery.withRecoverySegment('same-prompt', opts, validate, async (_p, options) => {
                calls++; e = Object.assign(new Error('synthetic truncation'), { code: 'RMT_JSON_TRUNCATED', retryable: true, retryableJson: true });
                await recovery.recordRecoveryTruncation(options, raw, e); throw e;
            }), { code: 'RMT_JSON_TRUNCATED' });
            assert.equal(e.retryable, false); assert.equal(e.retryableJson, false);
        },
        async complete(raw, validator = validate) {
            return recovery.withRecoverySegment('same-prompt', opts, validator, async (_p, _options, accepted) => {
                calls++; const value = await validator(raw); await accepted(raw); return value;
            });
        },
    };
}
const ids = session => session?.entries?.map(row => row.id);

test('r8429 real album validator: two accepted CGs survive a shorter failed reply and reload', async t => {
    const h = await harness(t); await h.fail(rich()); await h.resume(); await h.fail(shorter());
    assert.deepEqual(h.saved.segments[0].retainedPartials, [rich()]);
    assert.equal(h.saved.segments[0].partial, shorter());
    assert.deepEqual(ids(await progress.projectGenerationProgress(h.saved)), ['CG01', 'CG02']);
    await h.resume(); assert.deepEqual(ids(await progress.projectGenerationProgress(recovery.generationRecoverySnapshot(h.handle))), ['CG01', 'CG02']);
    assert.equal(h.calls, 2);
});

test('r8429 final valid omission is merged before returning to the caller, then replay costs zero requests', async t => {
    const h = await harness(t); await h.fail(rich()); await h.resume();
    const value = await h.complete({ entries: [cg('CG03')] });
    assert.deepEqual(ids(value), ['CG01', 'CG02', 'CG03']);
    assert.deepEqual(JSON.parse(h.saved.segments[0].rawJson).entries.map(row => row.id), ['CG01', 'CG02', 'CG03']);
    const count = h.calls; await h.resume();
    assert.deepEqual(ids(await h.complete({ entries: [cg('CG04')] })), ['CG01', 'CG02', 'CG03']); assert.equal(h.calls, count);
});

test('r8429 shorter complete JSON with the same accepted units may finish; no new-item minimum', async t => {
    const h = await harness(t); await h.fail(rich()); await h.resume();
    const value = await h.complete({ entries: [cg('CG01'), cg('CG02')] });
    assert.deepEqual(ids(value), ['CG01', 'CG02']); assert.equal(h.saved.segments[0].state, 'complete');
});

test('r8429 rewriting a known validated item does not overwrite its received text', async t => {
    const h = await harness(t); await h.fail(rich()); await h.resume();
    const value = await h.complete({ entries: [{ ...cg('CG01'), title: '重写标题' }, cg('CG03')] });
    assert.equal(value.entries[0].title, cg('CG01').title); assert.deepEqual(ids(value), ['CG01', 'CG02', 'CG03']);
});

test('r8429 strings are not ranked by length, and repeated dialogue lines are not collapsed', () => {
    const schema = merge.recoveryRecord({ lines: merge.recoveryList(null) });
    const before = '{"lines":["同一句","同一句","旧句"],"tail":"unfinished';
    const next = '{"lines":["同一句","新增句"],"tail":"unfinished';
    const view = merge.mergeRecoveryPartials([before, next], schema);
    assert.deepEqual(view.items('/lines'), ['同一句', '同一句', '旧句', '新增句']); assert.equal(view.complete, false);
});

test('r8429 time endpoint changes never transplant lines into other people/times', () => {
    const schema = adapters.recoveryProgressSchema('timeEcho', { memoryBank: bank, context: fields });
    const a = { ends: [{ role: 'char', time: '今夜' }, { role: 'user', time: '明年' }], medium: { kind: 'phone', label: '电话' }, lines: [{ speaker: 'a', text: '旧句' }] };
    const b = { ...a, ends: [{ role: 'user', time: '今夜' }, { role: 'char', time: '明年' }], lines: [{ speaker: 'a', text: '新句' }] };
    const result = merge.mergeRecoveryPartials([JSON.stringify(a), JSON.stringify(b)], schema, { final: true });
    assert.ok(result.conflicts.length); assert.deepEqual(result.partialValue.ends, a.ends); assert.deepEqual(result.items('/lines'), a.lines);
});

test('r8429 unbound partial lines are not granted a later endpoint identity', () => {
    const schema = adapters.recoveryProgressSchema('timeEcho', { memoryBank: bank, context: fields });
    const a = '{"lines":[{"speaker":"a","text":"无归属旧句"}],"ends":[';
    const b = JSON.stringify({ ends: [{ role: 'char', time: '今夜' }, { role: 'user', time: '明年' }], lines: [{ speaker: 'b', text: '新句' }] });
    const result = merge.mergeRecoveryPartials([a, b], schema, { final: true });
    assert.deepEqual(result.items('/lines'), [{ speaker: 'b', text: '新句' }]);
});

test('r8429 nested content stays with its parent even when parent arrays reorder', () => {
    const nested = merge.recoveryRecord({ nodes: merge.recoveryList(merge.recoveryItemKey('id')) }, ['id', 'label']);
    const schema = merge.recoveryRecord({ containers: merge.recoveryList(merge.recoveryItemKey('id'), nested) });
    const first = { containers: [{ id: 'A', label: '抽屉', nodes: [{ id: 'A1', text: '旧A' }] }, { id: 'B', label: '书包', nodes: [{ id: 'B1', text: '旧B' }] }] };
    const next = { containers: [{ id: 'B', label: '书包', nodes: [{ id: 'B2', text: '新B' }] }, { id: 'A', label: '抽屉', nodes: [{ id: 'A2', text: '新A' }] }] };
    const result = merge.mergeRecoveryPartials([JSON.stringify(first), JSON.stringify(next)], schema, { final: true });
    assert.deepEqual(result.value.containers.map(row => [row.id, row.nodes.map(node => node.id)]), [['A', ['A1', 'A2']], ['B', ['B1', 'B2']]]);
});

test('r8429 invalid old evidence does not replace a valid newer record with the same ID', () => {
    const schema = adapters.recoveryProgressSchema('album', { slot: 'x:index', memoryBank: bank });
    const old = { entries: [{ ...cg('CG01'), sourceMemoryIds: ['M999'], sourceMemoryAnchor: '不存在' }] };
    const result = merge.mergeRecoveryPartials([JSON.stringify(old), JSON.stringify({ entries: [cg('CG01')] })], schema, { final: true });
    assert.deepEqual(album.normalizeAlbumIndex(result.value, bank).entries[0].sourceMemoryIds, ['M001']);
});

test('r8429 accepted composite is revalidated; rejecting validator cannot be bypassed', async t => {
    const h = await harness(t); await h.fail(rich()); await h.resume();
    const validator = raw => { if (raw.entries.length > 1) throw Object.assign(new Error('original validator refused union'), { code: 'RMT_TEST_ORIGINAL_VALIDATOR' }); return raw; };
    await assert.rejects(h.complete({ entries: [cg('CG03')] }, validator), { code: 'RMT_TEST_ORIGINAL_VALIDATOR' });
    const row = recovery.generationRecoverySnapshot(h.handle).segments[0];
    assert.equal(row.state, 'truncated'); assert.equal(row.partial, rich());
    assert.ok(row.retainedPartials.some(raw => JSON.parse(raw).entries[0].id === 'CG03'));
});

test('r8429 failed durability acknowledgment keeps merged paid result in page and emits no success publication', async t => {
    let published = 0; const h = await harness(t, 'album', { onProgress: () => { published++; } });
    await h.fail(rich()); await h.resume(); const before = published; h.failSave(true);
    await assert.rejects(h.complete({ entries: [cg('CG03')] }), { code: 'RMT_RECOVERY_STORAGE' });
    assert.deepEqual(JSON.parse(recovery.generationRecoverySnapshot(h.handle).segments[0].rawJson).entries.map(row => row.id), ['CG01', 'CG02', 'CG03']);
    assert.equal(published, before); assert.equal(h.saved.segments[0].state, 'truncated');
});

test('r8429 retains original capacity and rejects malicious/oversized history before accepting a journal', async t => {
    const h = await harness(t); await h.fail(rich());
    for (const retainedPartials of [[{}], ['x'.repeat(recovery.GENERATION_RECOVERY_LIMITS.segmentChars + 1)], ['']]) {
        const value = structuredClone(h.saved); value.segments[0].retainedPartials = retainedPartials;
        assert.equal(recovery.generationRecoverySummary(value), null);
    }
    assert.equal(recovery.GENERATION_RECOVERY_LIMITS.segmentChars, 600000);
    assert.equal(recovery.GENERATION_RECOVERY_LIMITS.journalChars, 1800000);
});

test('r8429 no JSON completion, prototype execution, arbitrary schema or target supplied by model', () => {
    const schema = merge.recoveryRecord({ entries: merge.recoveryList(merge.recoveryItemKey('id')) });
    const a = '{"entries":[{"id":"A","text":"done"},{"id":"B","text":"unfinished';
    const result = merge.mergeRecoveryPartials([a, '{"__proto__":{"polluted":true},"entries":['], schema);
    assert.deepEqual(result.items('/entries'), [{ id: 'A', text: 'done' }]); assert.equal({}.polluted, undefined);
    assert.equal(result.complete, false); assert.equal(result.has('/entries/1'), false);
});


test('r8429 butterfly partial reader keeps validated MAIN prose through a less-informative response', async () => {
    const partial = '{"node":{"label":"主时间线","sourceMemoryIds":["M001"],"sourceMemoryAnchor":"庭院","monologue":"我记得庭院里的花。","intervention":"unfinished';
    const base = { identity: { mode: 'butterfly' }, createdAt: 1, contentSnapshotVersion: 1,
        contentSnapshot: snapshot, segments: [{ slot: 'mode:@origin:butterfly:slot:0', state: 'truncated', partial }] };
    const first = await progress.projectGenerationProgress(base);
    assert.ok(first?.nodes?.some(row => row.id === 'MAIN'));
    const after = await progress.projectGenerationProgress({ ...base, segments: [{ ...base.segments[0], partial: '{', retainedPartials: [partial] }] });
    assert.equal(after.nodes[0].monologue, first.nodes[0].monologue);
});


test('r8429 history does not introduce a smaller total cap than the original journal bound', async t => {
    const h = await harness(t); await h.fail(rich());
    const imported = structuredClone(h.saved);
    imported.segments[0].retainedPartials = ['x'.repeat(400000), 'y'.repeat(400000)];
    assert.ok(recovery.generationRecoverySummary(imported), 'two legal replies below the original journal capacity are allowed');
    imported.segments[0].retainedPartials = ['x'.repeat(600000), 'y'.repeat(600000), 'z'.repeat(600000)];
    assert.equal(recovery.generationRecoverySummary(imported), null, 'the existing total journal bound remains authoritative');
});


test('r8429 union exceeding the original complete-segment bound keeps both paid replies', async t => {
    const h = await harness(t, 'achievements');
    h.opts.recoveryProgressSchema = merge.recoveryRecord({ entries: merge.recoveryList(merge.recoveryItemKey('id')) });
    const old = '{"entries":[' + JSON.stringify({id:'A',text:'x'.repeat(310000)}) + '],"tail":"unfinished';
    const next = {entries:[{id:'B',text:'y'.repeat(310000)}]};
    await h.fail(old); await h.resume();
    await assert.rejects(h.complete(next));
    const row = recovery.generationRecoverySnapshot(h.handle).segments[0];
    assert.equal(row.partial, old); assert.equal(row.state, 'truncated');
    assert.ok(row.retainedPartials.some(raw => JSON.parse(raw).entries[0].id === 'B'));
});

test('r8429 lost origin or archive revision cannot write a recovered result into another worldline', async t => {
    let current = true;
    const h = await harness(t, 'album', { assertCurrent: () => current });
    await h.fail(rich()); await h.resume();
    const saved = structuredClone(h.saved), calls = h.calls;
    current = false;
    await assert.rejects(h.complete({entries:[cg('CG03')]}), {name:'AbortError'});
    assert.deepEqual(h.saved, saved); assert.equal(h.calls, calls);
});
