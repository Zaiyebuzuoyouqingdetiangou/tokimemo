import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './helpers/r847Host.mjs';
import * as context from '../src/core/context.js';
import * as client from '../src/generation/client.js';
import * as cache from '../src/core/cache.js';
import * as library from '../src/archive/library.js';
import * as overlay from '../src/ui/overlay.js';
import * as repository from '../src/archive/repository.js';
import * as contentManager from '../src/ui/contentManager.js';
import * as recovery from '../src/generation/recovery.js';
import * as images from '../src/generation/imageGeneration.js';
import { state } from '../src/core/state.js';

async function partial(f, source = f.liveBank) {
    const origin = context.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision);
    const handle = await client.beginModeRecovery('album', f.ctx, f.liveBank, origin, { existing: null });
    const draftId = handle.journal.draftId;
    const session = { kind: 'album', chatId: source.chatId, archiveRevision: source.archiveRevision,
        title: '部分相簿', selectedId: 'CG01', page: 1, pageSize: 6, category: '全部',
        entries: ['CG01','CG02'].map(id => ({ id, title: id, desc: '原画面', unlocked: true, comments: ['原对白'] })),
        readableProgress: { version: 1, draftId, pageId: 'album', complete: false } };
    await cache.saveGenerationTaskResult(f.ctx, 'album', session, origin, { draftId, sourceMemory: source, memoryBank: f.liveBank, complete: false });
    return { origin, draftId, session, source };
}

test('open unfinished saved result as its editable page without requesting a model', async t => {
    const f = await fixture(t), task = await partial(f);
    await library.openGenerationTaskResult(task.draftId, f.ctx);
    assert.equal(state.activeArchiveSnapshot, null);
    assert.equal(state.activeArchiveReadOnly, false);
    assert.equal(state.activeSession.readableProgress.explicitDraft, true);
    assert.equal(state.activeSession.readableProgress.draftId, task.draftId);
    assert.equal(library.requireWritableArchiveAction(), true);
    assert.equal(f.requests.length, 0);
});

test('local text, line speaker, image and deletion survive next projection and reopening; formal content unchanged', async t => {
    const f = await fixture(t), task = await partial(f), before = structuredClone(await f.persisted());
    await library.openGenerationTaskResult(task.draftId, f.ctx);
    await overlay.saveActiveSessionEdit(session => {
        session.entries[0].comments[0] = '用户改的对白';
        session.entries[0].commentSpeakers = [{ speakerId: 'A', speakerName: '封剑寒' }];
        session.entries[0].cgImage = { url: '/user-image.png' };
        session.entries = session.entries.filter(item => item.id !== 'CG02');
        return session;
    }, { select: session => session.entries[0] });
    const incoming = structuredClone(task.session);
    incoming.entries[0].comments.push('后来生成的第二句');
    incoming.entries.push({ id: 'CG03', title: '后来完成', comments: [] });
    await cache.saveGenerationTaskResult(f.ctx, 'album', incoming, task.origin, {
        draftId: task.draftId, sourceMemory: task.source, memoryBank: f.liveBank, complete: false });
    await library.openGenerationTaskResult(task.draftId, f.ctx);
    assert.deepEqual(state.activeSession.entries.map(item => item.id), ['CG01','CG03']);
    assert.deepEqual(state.activeSession.entries[0].comments, ['用户改的对白','后来生成的第二句']);
    assert.equal(state.activeSession.entries[0].commentSpeakers[0].speakerName, '封剑寒');
    assert.equal(state.activeSession.entries[0].cgImage.url, '/user-image.png');
    assert.deepEqual((await f.persisted()).album, before.album);
    assert.deepEqual((await f.persisted()).phone, before.phone);
    delete incoming.readableProgress;
    assert.equal(await cache.commitSession('album', incoming, f.liveBank.chatId, task.origin), true);
    state.runtimeSessionCache.clear(); await cache.ensureCacheHydrated(f.ctx);
    const final = (await f.persisted()).album;
    assert.deepEqual(final.entries.map(item => item.id), ['CG01','CG03']);
    assert.equal(final.entries[0].comments[0], '用户改的对白');
    assert.equal(final.entries[0].commentSpeakers[0].speakerName, '封剑寒');
    assert.equal(final.entries[0].cgImage.url, '/user-image.png');
    assert.equal(f.requests.length, 0);
});

test('unfinished result with older original source remains editable without rewriting current memory', async t => {
    const f = await fixture(t), source = { ...structuredClone(f.liveBank), archiveRevision: 'original-older-source' };
    const task = await partial(f, source);
    await library.openGenerationTaskResult(task.draftId, f.ctx);
    await overlay.saveActiveSessionEdit(session => { session.entries[0].title = '编辑旧任务'; return session; }, { select: session => session.entries[0] });
    const result = await cache.readGenerationTaskResult(f.ctx, task.draftId);
    assert.equal(result.session.entries[0].title, '编辑旧任务');
    assert.equal(result.sourceMemory.archiveRevision, 'original-older-source');
    assert.deepEqual(repository.requireArchive(f.ctx), f.liveBank);
    assert.equal(f.requests.length, 0);
});

test('explicitly opened older draft edits its own same-ID item rather than a newer sibling', async t => {
    const f = await fixture(t), first = await partial(f);
    recovery.detachGenerationRecovery(first.origin);
    const second = await partial(f);
    assert.notEqual(first.draftId, second.draftId);
    await library.openGenerationTaskResult(first.draftId, f.ctx);
    const field = contentManager.partialContentFields(state.activeSession).find(row => row.path.at(-1) === 'desc');
    await contentManager.savePartialContentField(field, '只改旧任务');
    await contentManager.deletePartialContentItem(['entries', { id: 'CG02' }]);
    const a = await cache.readGenerationTaskResult(f.ctx, first.draftId), b = await cache.readGenerationTaskResult(f.ctx, second.draftId);
    assert.equal(a.session.entries[0].desc, '只改旧任务');
    assert.equal(a.session.entries.length, 1);
    assert.equal(b.session.entries[0].desc, '原画面');
    assert.equal(b.session.entries.length, 2);
});

test('actual historical saved result remains read-only and cannot edit the live archive', async t => {
    const f = await fixture(t), task = await partial(f);
    await cache.saveGenerationTaskResult(f.ctx, 'album', task.session, task.origin, {
        draftId: task.draftId, sourceMemory: task.source, memoryBank: f.liveBank, complete: true });
    const result = await library.openGenerationTaskResult(task.draftId, f.ctx);
    assert.equal(result.historyVersionId, `task:${task.draftId}`);
    assert.equal(library.requireWritableArchiveAction(), false);
    assert.equal(f.requests.length, 0);
});

test('old-source partial CG is drawn once, saved, displayed, cleared and not resurrected by continuation', async t => {
    const f = await fixture(t), task = await partial(f, { ...structuredClone(f.liveBank), archiveRevision: 'old-draw-source' });
    const previousProvider = Object.getOwnPropertyDescriptor(globalThis, 'STBaiBaiImage');
    let draws = 0;
    globalThis.STBaiBaiImage = { apiVersion: 1, capabilities: { generate: true, saveToGallery: true },
        getBackendStatus: () => ({ configured: true, backend: 'nai', supportsCharacters: true }),
        generate: async () => { draws++; return { path: '/user/images/draft.png' }; } };
    t.after(() => { images.abortActiveCgImageTasks();
        if (previousProvider) Object.defineProperty(globalThis, 'STBaiBaiImage', previousProvider); else delete globalThis.STBaiBaiImage; });
    await library.openGenerationTaskResult(task.draftId, f.ctx);
    const captured = images.captureCgImageTarget(); assert.equal(captured?.draftId, task.draftId);
    await images.drawSelectedCgImage({ promptOverride: '庭院里的花架', expectedTarget: captured });
    assert.equal(draws, 1, JSON.stringify(f.notices));
    assert.equal(state.activeSession.entries[0].cgImage?.url, '/user/images/draft.png', JSON.stringify(f.notices));
    await library.openGenerationTaskResult(task.draftId, f.ctx);
    assert.equal(state.activeSession.entries[0].cgImage?.url, '/user/images/draft.png');
    await images.clearSelectedCgImage();
    await cache.saveGenerationTaskResult(f.ctx, 'album', task.session, task.origin, {
        draftId: task.draftId, sourceMemory: task.source, memoryBank: f.liveBank, complete: false });
    await library.openGenerationTaskResult(task.draftId, f.ctx);
    assert.equal(state.activeSession.entries[0].cgImage || null, null);
    assert.equal(draws, 1); assert.equal(f.requests.length, 0);
});
