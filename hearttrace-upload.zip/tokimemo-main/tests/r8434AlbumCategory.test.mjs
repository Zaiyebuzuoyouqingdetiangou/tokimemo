import test from 'node:test';
import assert from 'node:assert/strict';
import * as album from '../src/modes/album.js';
import * as categoryView from '../src/ui/albumCategory.js';
import * as view from '../src/ui/albumView.js';
import * as contentRegeneration from '../src/generation/contentRegeneration.js';
import * as cache from '../src/core/cache.js';
import * as library from '../src/archive/library.js';
import * as contextApi from '../src/core/context.js';
import * as constants from '../src/core/constants.js';
import { fixture } from './helpers/r847Host.mjs';
import { state } from '../src/core/state.js';

const bank = { characterName: '沙盒卡标题', userName: '玩家', archiveName: '庭院相遇', archiveSummary: '', memories: [
    { id: 'M001', title: '一起栽花。', summary: '两人一同在庭院栽花。', anchors: ['庭院'], participants: [] },
    { id: 'M002', title: '门口相遇。', summary: '两人在门口相遇。', anchors: ['门口'], participants: [] },
] };
const base = { id: 'CG01', title: '庭院', date: '待定', desc: '两人站在庭院', unlocked: true,
    sourceMemoryIds: ['M001'], sourceMemoryAnchor: '庭院', visualSeed: ['树', '花', '手', '门'], imagePrompt: '庭院' };

test('normalizeAlbumCategory folds aliases, english, case and whitespace; unknown values become 待分类', () => {
    assert.equal(album.normalizeAlbumCategory('日常'), '日常');
    assert.equal(album.normalizeAlbumCategory('约会'), '约会');
    assert.equal(album.normalizeAlbumCategory('结局'), '结局');
    assert.equal(album.normalizeAlbumCategory('待分类'), '待分类');
    assert.equal(album.normalizeAlbumCategory(' Daily '), '日常');
    assert.equal(album.normalizeAlbumCategory('EVERYDAY'), '日常');
    assert.equal(album.normalizeAlbumCategory('日常生活'), '日常');
    assert.equal(album.normalizeAlbumCategory('date'), '约会');
    assert.equal(album.normalizeAlbumCategory(' Dating\n'), '约会');
    assert.equal(album.normalizeAlbumCategory('约会日'), '约会');
    assert.equal(album.normalizeAlbumCategory('Ending'), '结局');
    assert.equal(album.normalizeAlbumCategory('FINALE'), '结局');
    assert.equal(album.normalizeAlbumCategory('终章'), '结局');
    for (const value of ['', '   ', null, undefined, 42, '随便什么', '约会？', '私密']) {
        assert.equal(album.normalizeAlbumCategory(value), '待分类', JSON.stringify(value));
    }
    assert.ok(constants.CATEGORY_VALUES.has('待分类'), 'merge/validation chains must accept 待分类');
});

test('normalizeAlbumIndex and normalizeAlbum no longer launder unknown categories into 日常', () => {
    const index = album.normalizeAlbumIndex({ entries: [
        { ...base, category: 'daily' }, { ...base, id: 'CG02', category: 'Ending' },
        { ...base, id: 'CG03', category: '约会' }, { ...base, id: 'CG04', category: '' },
        { ...base, id: 'CG05' }, { ...base, id: 'CG06', category: '编造分类' },
    ] }, bank);
    assert.deepEqual(index.entries.map(item => item.category), ['日常', '结局', '约会', '待分类', '待分类', '待分类']);
    const fourComments = ['一', '二', '三', '四'];
    const full = album.normalizeAlbum({ entries: [{ ...base, category: ' DATE ', comments: fourComments }] }, bank);
    assert.equal(full.entries[0].category, '约会');
    const unknown = album.normalizeAlbum({ entries: [{ ...base, category: '随笔', comments: fourComments }] }, bank);
    assert.equal(unknown.entries[0].category, '待分类');
    assert.equal(categoryView.albumDisplayCategory({ category: '随笔' }), '待分类');
    assert.equal(categoryView.albumDisplayCategory({ category: undefined }), '待分类');
    assert.ok(categoryView.ALBUM_DISPLAY_CATEGORIES.includes('待分类'));
});

test('normalizeAlbum keeps a manual category flag across restore re-normalization', () => {
    const comments = ['一', '二', '三', '四'];
    const manual = album.normalizeAlbum({ entries: [{ ...base, category: '约会', categoryManual: true, comments }] }, bank);
    assert.equal(manual.entries[0].category, '约会');
    assert.equal(manual.entries[0].categoryManual, true);
    const auto = album.normalizeAlbum({ entries: [{ ...base, category: '约会', comments }] }, bank);
    assert.equal(auto.entries[0].categoryManual, undefined);
});

test('incremental merge never overwrites a manual category, including locked-to-unlocked merges', () => {
    const oldUnlocked = { ...base, category: '约会', categoryManual: true, comments: ['旧对白'], cgImage: { url: '/old.png' } };
    const kept = album.mergeAlbumIncremental({ kind: 'album', title: '相簿', entries: [oldUnlocked] }, { entries: [] }, bank);
    assert.deepEqual(kept.entries[0], oldUnlocked);

    const locked = { ...base, id: 'CG02', title: '门口', unlocked: false, category: '结局', categoryManual: true,
        sourceMemoryIds: ['M002'], sourceMemoryAnchor: '门口', hintLines: ['提示'], cgImage: { url: '/locked.png' } };
    const incoming = { ...base, id: 'CG02', title: '门口', unlocked: true, category: '日常',
        sourceMemoryIds: ['M002'], sourceMemoryAnchor: '门口', desc: '解锁后的画面', comments: [] };
    const merged = album.mergeAlbumIncremental({ kind: 'album', title: '相簿', entries: [locked] }, { entries: [incoming] }, bank);
    assert.equal(merged.entries[0].unlocked, true);
    assert.equal(merged.entries[0].category, '结局', 'manual category must survive the unlock merge');
    assert.equal(merged.entries[0].categoryManual, true);
    assert.equal(merged.entries[0].cgImage.url, '/locked.png');

    const automatic = album.mergeAlbumIncremental(
        { kind: 'album', title: '相簿', entries: [{ ...locked, category: '待分类', categoryManual: undefined }] },
        { entries: [{ ...incoming, category: '约会' }] }, bank);
    assert.equal(automatic.entries[0].category, '约会', 'without a manual flag the model category applies');
    assert.equal(automatic.entries[0].categoryManual, undefined);

    const appended = album.mergeAlbumIncremental({ kind: 'album', title: '相簿', entries: [oldUnlocked] },
        { entries: [{ ...incoming, id: 'CG09', title: '新卡', category: '待分类' }] }, bank);
    assert.equal(appended.entries.length, 2);
    assert.equal(appended.entries[1].category, '待分类');
});

test('category re-judgement only changes category and never sends prose, comments or image back', async t => {
    const f = await fixture(t);
    const origin = contextApi.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision);
    const session = { kind: 'album', title: '相簿', entries: [{ ...base, category: '日常', desc: '正文SENTINEL',
        comments: ['绝密对白SENTINEL'], cgImage: { url: '/user/images/cg01.png' } }] };
    f.setResponse(() => ({ category: ' Dating ' }));
    const updated = await contentRegeneration.regenerateManagedTarget(session, 'album-category', 'CG01', '',
        { context: f.ctx, memoryBank: f.liveBank, origin, taskKey: 'recat-test' });
    const item = updated.entries[0];
    assert.equal(item.category, '约会', 'model output passes through normalizeAlbumCategory');
    assert.equal(item.desc, '正文SENTINEL');
    assert.deepEqual(item.comments, ['绝密对白SENTINEL']);
    assert.equal(item.cgImage.url, '/user/images/cg01.png');
    assert.equal(f.requests.length, 1);
    const sent = JSON.stringify(f.requests[0]);
    assert.ok(sent.includes('庭院'), 'title/anchor are the judgement input');
    assert.ok(!sent.includes('绝密对白SENTINEL'), 'comments are never sent for re-judgement');
    assert.ok(!sent.includes('/user/images/cg01.png'), 'image records are never sent for re-judgement');
    await assert.rejects(
        contentRegeneration.regenerateManagedTarget(session, 'album-category', 'CG99', '',
            { context: f.ctx, memoryBank: f.liveBank, origin, taskKey: 'recat-test' }),
        /找不到这张相簿卡/);
});

test('album entry regeneration preserves a manual category and the drawn CG image', async t => {
    const f = await fixture(t);
    const origin = contextApi.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision);
    const comments = ['第一句', '第二句', '第三句', '第四句', '第五句', '第六句'];
    const session = { kind: 'album', title: '相簿', entries: [{ ...base, category: '约会', categoryManual: true,
        desc: '旧画面', comments: ['旧对白'], cgImage: { url: '/user/images/cg01.png' } }] };
    f.setResponse(messages => {
        const text = JSON.stringify(messages);
        if (text.includes('单项重新生成')) return { entries: [{ ...base, category: '结局', desc: '新画面' }] };
        if (text.includes('ALBUM_RELATIONSHIP_FULL_ARCHIVE_JSON')) return { charState: '有证据', userState: '有证据',
            relationshipState: '未确认', relationshipSummary: '按档案',
            relationshipSourceMemoryIds: ['M001'], relationshipSourceMemoryAnchor: '庭院' };
        return { items: [{ id: 'CG01', comments }] };
    });
    const updated = await contentRegeneration.regenerateManagedTarget(session, 'album-entry', 'CG01', '',
        { context: f.ctx, memoryBank: f.liveBank, origin, taskKey: 'entry-test' });
    const item = updated.entries[0];
    assert.equal(item.desc, '新画面', 'the entry text is regenerated');
    assert.deepEqual(item.comments, comments);
    assert.equal(item.category, '约会', 'manual category is never overwritten by regeneration');
    assert.equal(item.categoryManual, true);
    assert.equal(item.cgImage.url, '/user/images/cg01.png', 'a drawn CG image must not be dropped');

    const autoSession = { kind: 'album', title: '相簿', entries: [{ ...base, category: '日常', desc: '旧画面', comments: ['旧对白'] }] };
    const autoUpdated = await contentRegeneration.regenerateManagedTarget(autoSession, 'album-entry', 'CG01', '',
        { context: f.ctx, memoryBank: f.liveBank, origin, taskKey: 'entry-test' });
    assert.equal(autoUpdated.entries[0].category, '结局', 'without a manual flag the regenerated category applies');
    assert.equal(autoUpdated.entries[0].categoryManual, undefined);
    assert.equal(autoUpdated.entries[0].cgImage, null, 'no prior image means no image to keep');
});

test('manual category edit persists with a categoryManual flag and rejects unknown values', async t => {
    const f = await fixture(t);
    const origin = contextApi.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision);
    const handle = await import('../src/generation/client.js').then(client => client.beginModeRecovery('album', f.ctx, f.liveBank, origin, { existing: null }));
    const draftId = handle.journal.draftId;
    const session = { kind: 'album', chatId: f.liveBank.chatId, archiveRevision: f.liveBank.archiveRevision,
        title: '部分相簿', selectedId: 'CG01', page: 1, pageSize: 6, category: '全部',
        entries: [{ ...base, category: '待分类', comments: ['原对白'] }],
        readableProgress: { version: 1, draftId, pageId: 'album', complete: false } };
    await cache.saveGenerationTaskResult(f.ctx, 'album', session, origin, { draftId, sourceMemory: f.liveBank, memoryBank: f.liveBank, complete: false });
    await library.openGenerationTaskResult(draftId, f.ctx);
    assert.equal(state.activeSession.entries[0].category, '待分类');

    await view.albumSetCategory('CG01', '私密');
    let saved = await cache.readGenerationTaskResult(f.ctx, draftId);
    assert.equal(saved.session.entries[0].category, '待分类', 'view-only 私密 is not a storable category');
    assert.equal(saved.session.entries[0].categoryManual, undefined);

    await view.albumSetCategory('CG01', '约会');
    saved = await cache.readGenerationTaskResult(f.ctx, draftId);
    assert.equal(saved.session.entries[0].category, '约会');
    assert.equal(saved.session.entries[0].categoryManual, true, JSON.stringify(f.notices));
    assert.deepEqual(saved.session.entries[0].comments, ['原对白']);
    assert.equal(f.requests.length, 0, 'manual classification never calls the model');
});
