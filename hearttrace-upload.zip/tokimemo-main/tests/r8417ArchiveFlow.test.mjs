import { localFixture } from './helpers/r8425LocalHost.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import {fixture} from './helpers/r847Host.mjs';
import * as R from '../src/archive/repository.js';
import * as L from '../src/archive/sourceLedger.js';
import * as Q from '../src/archive/qianqianjie.js';
import * as recovery from '../src/archive/importRecovery.js';
import * as context from '../src/core/context.js';
import * as C from '../src/core/constants.js';
import * as independent from '../src/core/independentApi.js';
import * as recoveryView from '../src/ui/recoveryView.js';
import {state} from '../src/core/state.js';
const clone=x=>x==null?x:structuredClone(x);
async function setup(t,{kind='worldbook'}={}){
 const f=await fixture(t);const store=new Map();const original=Object.getOwnPropertyDescriptor(globalThis,Q.QQJ_BRIDGE);delete globalThis[Q.QQJ_BRIDGE];
 f.ctx.userAvatar='fixture-persona.png';const settings=f.ctx.extensionSettings[C.EXTENSION_SETTINGS_KEY];
 settings.useCurrentChatExternalMemory=kind==='qqj';settings.useActivatedWorldInfo=true;
 const details={book:'昨日两人在湖畔一同放纸船。',background:'原世界背景',reads:0};
 f.ctx.getWorldInfoPrompt=async()=>({worldInfoString:details.background,worldInfoDepth:[{entries:['深度背景，不能独立证明旧事。']}]});
 R.setMemoryWorldInfoSelection(f.ctx,{books:kind==='worldbook'?[{name:'A-book',all:true,entryUids:[],historySource:true}]:[]});
 f.ctx.loadWorldInfo=async()=>{details.reads++;return {entries:{1:{uid:1,comment:'往事',content:details.book}}}};
 if(kind==='qqj'){
  const identity={hostChatId:f.ctx.chatId,qqjChatId:'qqj-flow',characterLocator:f.ctx.characters[0].avatar,personaLocator:f.ctx.userAvatar};
  globalThis[Q.QQJ_BRIDGE]={schemaVersion:1,kind:'qqj-public-memory-bridge',getStatus:()=>({status:'ready',identity:clone(identity)}),getSnapshot:()=>({status:'ready',identity:clone(identity),memory:{status:'ready',headCheckpointId:'head',floors:[{floorId:'floor',messageIndex:0,summary:details.book}]}})};
 }
 L.setMemorySourceLedgerBackendForTests({read:async scope=>clone(store.get(scope.key)||null),write:async value=>{store.set(value.scope.key,clone(value));return true},delete:async()=>{throw new Error('No source deletion')}});
 const origin=context.captureTaskOrigin(f.ctx,f.liveBank.archiveRevision);recovery.clearArchiveRecovery(origin);
 t.after(()=>{recovery.clearArchiveRecovery(origin);recovery.clearArchiveRecovery(context.captureTaskOrigin(f.ctx,R.getImportedMemory(f.ctx)?.archiveRevision||''));L.setMemorySourceLedgerBackendForTests(null);original?Object.defineProperty(globalThis,Q.QQJ_BRIDGE,original):delete globalThis[Q.QQJ_BRIDGE]});
 let fail=false,failures=0;
 f.setResponse(messages=>{
  const prompt=messages.map(m=>m.content||'').join('\n');
  if(prompt.includes('EXTERNAL_MEMORY_JSON:\n')){
   if(fail){fail=false;failures++;throw new Error('fixture rejected request')}
   const records=R.getMemoryPreflight(f.ctx)?.records||[];const record=records.find(r=>prompt.includes(r.externalId));assert.ok(record,'real externalId is in prompt');
   return {memories:[{title:'湖畔纸船',summary:'两人在湖畔放了纸船。',anchors:['湖畔','纸船'],participants:['林舟','小月'],sourceExternalIds:[record.externalId],sourceExternalAnchor:'湖畔'}]};
  }
  if(prompt.includes('UNTRUSTED_CHAT_JSON:'))return {memories:[]};
  return {archiveName:'一起放船',relationshipReading:{char:'共同放船',user:'共同参与',relation:'相伴',tension:'未记载',direction:'相伴'},verdictStyle:'quiet-life',
   archiveVerdict:'两个人一起在湖畔放了纸船，这份记录呈现的是他们共同参与一件小事的经历。纸船顺着湖水离开，他们的关系仍应由已经发生的事实来理解，不需要提前给尚未表达的感情加上名字。对话没有说明更远的约定，档案也只留下这次相伴本身，以及两人愿意共同花费的时间。',verdictSources:[{memoryId:'M001',anchor:'湖畔'}],keywords:['湖畔','纸船']};
 });
 return {...f,details,settings,store,origin,failNextExternal:()=>{fail=true},failures:()=>failures};
}
for(const kind of ['worldbook','qqj'])test(`${kind} real archive extraction -> source anchor -> canonical save -> reopen`,async t=>{
 const f=await setup(t,{kind});const oldPhone=clone((await f.persisted()).phone);
 const result=await R.importCurrentChatMemory({fullRebuild:true,automatic:true});
 assert.equal(result.status,'committed',JSON.stringify(f.notices));
 const bank=R.getImportedMemory(f.ctx);assert.equal(bank.memories.length,1);assert.equal(bank.memories[0].externalSourceAnchor,'湖畔');
 assert.ok(bank.memories[0].externalSourceIds.length);assert.equal(bank.memories[0].sourceKind,'external-current-chat');
 const record=[...f.records.values()].find(r=>r.memory?.archiveRevision===bank.archiveRevision);assert.ok(record);assert.deepEqual(record.memory.memories,bank.memories);
 assert.equal(f.requests.length,3,'chat + external + profile, no hidden request');
 assert.match(f.requests[1].map(m=>m.content).join(''),/昨日两人在湖畔/);assert.match(f.requests[0].map(m=>m.content).join(''),/深度背景/);
});
test('worldbook background and source update cannot change an already-paid archive retry input',async t=>{
 const f=await setup(t);f.failNextExternal();let result=await R.importCurrentChatMemory({fullRebuild:true,automatic:true});
 assert.equal(result.status,'failed');assert.equal(f.requests.length,2);assert.equal(R.getCurrentArchiveImportRecoverySummary(f.ctx).completed,1);
 f.details.book='后来新的历史不应进入原任务';f.details.background='后来更新的世界背景';const reads=f.details.reads;
 result=await R.continueCurrentArchiveImport();
 assert.equal(result.status,'committed',JSON.stringify(f.notices));assert.equal(f.requests.length,4);assert.equal(f.details.reads,reads);
 assert.deepEqual(f.requests[1],f.requests[2],'retried request input byte-equivalent');assert.match(f.requests[2].map(m=>m.content).join(''),/原世界背景/);
 assert.doesNotMatch(f.requests[2].map(m=>m.content).join(''),/后来/);
});
for(const change of ['model','selection','chat-body','persona','character-data'])test(`paid draft retry still refuses changed ${change} and preserves completed chunks`,async t=>{
 const f=await setup(t);f.failNextExternal();await R.importCurrentChatMemory({fullRebuild:true,automatic:true});const old=clone(f.ctx.chatMetadata[C.MEMORY_KEY]);
 if(change==='model')f.ctx.extensionSettings[C.EXTENSION_SETTINGS_KEY].modelOverride='changed';if(change==='selection')R.setMemoryWorldInfoSelection(f.ctx,{books:[]});
 if(change==='chat-body')f.ctx.chat[0].mes+='修改正文';if(change==='persona')f.ctx.userAvatar='other-persona.png';if(change==='character-data')f.ctx.characters[0].data.personality='changed';
 const result=await R.continueCurrentArchiveImport().catch(e=>{assert.equal(e.code,'RMT_RECOVERY_INPUT_CHANGED');return {status:'failed'}});
 assert.notEqual(result.status,'committed');assert.equal(f.requests.length,2);assert.deepEqual(f.ctx.chatMetadata[C.MEMORY_KEY],old);
 assert.equal(recovery.archiveRecoverySummary(f.origin).completed,1);
});
test('old archive draft without pinned inputs still has original exact hash checks',async t=>{
 localFixture(t);
 const origin={characterKey:'legacy-character',characterId:'1',characterAvatar:'fixture.png',chatId:'legacy-chat',archiveRevision:'rev'};
 const ticket=await recovery.beginArchiveRecovery({origin,sourceIdentity:'old',sourceFragments:['source'],settingsIdentity:'settings',assertCurrent:()=>true});
 recovery.releaseArchiveRecovery(ticket);
 await assert.rejects(()=>recovery.beginArchiveRecovery({origin,sourceIdentity:'new',sourceFragments:['source'],settingsIdentity:'settings',continueApproved:true}),e=>e.code==='RMT_RECOVERY_INPUT_CHANGED');
 recovery.clearArchiveRecovery(origin);
});
for(const markup of ['<span>晚安</span>','<tableEdit>摘要</tableEdit>','<!--正文标签-->','<img src=x onerror=bad()>'])test(`valid JSON containing ${markup.slice(0,14)} is data, not an HTML page`,()=>{
 assert.equal(independent.looksLikeHtmlResponse(JSON.stringify({memories:[{summary:markup}]}),'application/json'),false);
});
for(const body of ['<!DOCTYPE html><html><body>Proxy error</body></html>','<html>{"ok":true}</html>','<!--proxy-->\n<div>bad</div>'])test('real HTML wrapper stays blocked: '+body.slice(0,25),()=>{
 assert.equal(independent.looksLikeHtmlResponse(body,'text/html'),true);assert.equal(independent.looksLikeHtmlResponse(body,'application/json'),true);
});
test('explicit HTML response type stays blocked even if body is JSON',async()=>{await assert.rejects(()=>independent.readBoundedJsonResponse(new Response('{"ok":true}',{headers:{'content-type':'text/html'}})),e=>e.code==='RMT_RESPONSE_HTML')});
test('archive recovery banner uses a safe permanent failure reason',()=>{
 const html=recoveryView.archiveRecoveryHtml({canRetry:true,completed:1,failureCode:'RMT_REQUEST_TIMEOUT'});
 assert.match(html,/超时/);assert.doesNotMatch(html,/undefined/);
});
test('invalid external IDs or fabricated anchors do not become archive evidence',()=>{
 const input=[{externalId:'REAL',content:'两人在湖畔'}];
 assert.deepEqual(R.normalizeExternalImportedMemories({memories:[{title:'不实',summary:'不实',sourceExternalIds:['FAKE'],sourceExternalAnchor:'湖畔'}]},input),[]);
 assert.deepEqual(R.normalizeExternalImportedMemories({memories:[{title:'不实',summary:'不实',sourceExternalIds:['REAL'],sourceExternalAnchor:'海底城'}]},input),[]);
});
test('disabled unrelated QQJ does not block historical worldbook automatic sync',async t=>{
 const f=await setup(t);f.ctx.extensionSettings[C.EXTENSION_SETTINGS_KEY].useCurrentChatExternalMemory=true;
 globalThis[Q.QQJ_BRIDGE]={schemaVersion:1,kind:'qqj-public-memory-bridge',getStatus:()=>({status:'disabled'}),getSnapshot:()=>{throw new Error('must not read disabled API')}};
 const result=await R.importCurrentChatMemory({fullRebuild:true,automatic:true});assert.equal(result.status,'committed',JSON.stringify(f.notices));
 assert.equal(R.getImportedMemory(f.ctx).memories[0].externalSourceAnchor,'湖畔');
});
