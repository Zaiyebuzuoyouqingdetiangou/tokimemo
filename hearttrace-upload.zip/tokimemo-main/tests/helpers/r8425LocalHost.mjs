import assert from 'node:assert/strict';
import * as local from '../../src/core/localRecoveryStore.js';
import * as drafts from '../../src/archive/importRecovery.js';
export function localFixture(t) {
 const records=new Map(); let writes=0,failed=false;
 const backend={read:async id=>structuredClone(records.get(id)||null), compare:async(id,revision,payload)=>{
  if(failed)throw new DOMException('synthetic storage failure','QuotaExceededError');
  const old=records.get(id);if((old?.revision||0)!==revision)throw Object.assign(new Error('synthetic CAS'),{code:'RMT_LOCAL_CAS'});
  writes++;records.set(id,structuredClone({key:id,revision:revision+1,payload}));return revision+1;
 }};
 drafts.resetArchiveRecoveryMemoryForTests();local.setLocalRecoveryBackendForTests(backend);
 t.after(async()=>{await new Promise(r=>setTimeout(r,5));local.setLocalRecoveryBackendForTests(null);drafts.resetArchiveRecoveryMemoryForTests();});
 return {records,backend,fail(value=true){failed=value;},writes:()=>writes};
}
export const fixedOrigin=()=>({characterKey:'fixed-character',characterId:'0',characterAvatar:'fixed.png',chatId:'fixed-chat',archiveRevision:'fixed-bank'});
export async function waitUntil(predicate, timeout=15000) {const start=Date.now();while(!predicate()){assert.ok(Date.now()-start<timeout,'operation did not settle');await new Promise(r=>setTimeout(r,2));}await new Promise(r=>setTimeout(r,4));}
