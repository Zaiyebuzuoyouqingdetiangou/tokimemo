// Exact approved phase5 delta. Preserve all prior phase3/historical checks.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
export const phase5RecoveryDeltas = {
  "src/generation/recovery.js": {
    "beforeSha256": "583a203c70dc9b9be2446ed67678ff16fbbd33c969090a6b3e28a1e022d186e6",
    "afterSha256": "8bac72f2b7bc6ca61c5b0f6e785cf35603527469bcd22757968be3345c84e505",
    "changes": [
      {
        "start": 5,
        "remove": 1,
        "old": "",
        "new": "import * as recovery_payload from './recoveryPayload.js';\n"
      },
      {
        "start": 125,
        "remove": 9,
        "old": "",
        "new": "// Validate JSON ownership first; apply the existing storage limit to the lossless\n// stored representation, not to duplicate in-memory copies of shared requests.\nfunction recoveryJournalData(raw) {\n    const safe = JSON.parse(jsonData(raw, Number.MAX_SAFE_INTEGER, true));\n    const expanded = recovery_payload.unpackRecoveryPayload(safe, GENERATION_RECOVERY_LIMITS.requestChars);\n    const stored = jsonData(recovery_payload.packRecoveryPayload(expanded), GENERATION_RECOVERY_LIMITS.journalChars, true);\n    return { expanded, stored };\n}\n\n"
      },
      {
        "start": 136,
        "remove": 2,
        "old": "        // Bound the persisted object before inspecting it. JSON data cannot acquire authority.\n        const journal = JSON.parse(jsonData(raw, GENERATION_RECOVERY_LIMITS.journalChars, true));\n",
        "new": "        // Decode only structurally checked JSON; request/result validation remains unchanged.\n        const journal = recoveryJournalData(raw).expanded;\n"
      },
      {
        "start": 212,
        "remove": 1,
        "old": "    const pick = item => Object.fromEntries(keys.filter(key => Object.hasOwn(item, key)).map(key => [key, item[key]]));\n",
        "new": "    const pick = item => recovery_payload.packRecoveryPayload(Object.fromEntries(keys.filter(key => Object.hasOwn(item, key)).map(key => [key, item[key]])));\n"
      },
      {
        "start": 278,
        "remove": 1,
        "old": "    return internalHandles.has(handle) ? JSON.parse(jsonData(handle.journal, GENERATION_RECOVERY_LIMITS.journalChars, true)) : null;\n",
        "new": "    return internalHandles.has(handle) ? recoveryJournalData(handle.journal).expanded : null;\n"
      },
      {
        "start": 443,
        "remove": 1,
        "old": "        const serialized = jsonData(next, GENERATION_RECOVERY_LIMITS.journalChars, true);\n",
        "new": "        const { expanded, stored } = recoveryJournalData(next);\n"
      },
      {
        "start": 449,
        "remove": 2,
        "old": "        handle.journal = JSON.parse(serialized);\n        try { handle.durable = typeof handle.save === 'function' && await handle.save(JSON.parse(serialized)) !== false; }\n",
        "new": "        handle.journal = expanded;\n        try { handle.durable = typeof handle.save === 'function' && await handle.save(JSON.parse(stored)) !== false; }\n"
      }
    ]
  }
};
const sha = value => createHash('sha256').update(value).digest('hex');
export function phase5RecoveryApprovedSource(path, value) {
    const spec = phase5RecoveryDeltas[path];
    if (!spec) return value;
    const raw = String(value), digest = sha(raw);
    if (digest === spec.beforeSha256) return raw;
    assert.equal(digest, spec.afterSha256, path + ' contains an unreviewed phase3 change (not an approved phase5 delta)');
    const lines = raw.match(/[^\n]*\n|[^\n]+$/g) || [];
    for (const part of [...spec.changes].reverse()) {
        assert.equal(lines.slice(part.start, part.start + part.remove).join(''), part.new, 'phase5 approved hunk differs');
        lines.splice(part.start, part.remove, ...(part.old.match(/[^\n]*\n|[^\n]+$/g) || []));
    }
    const restored = lines.join('');
    assert.equal(sha(restored), spec.beforeSha256, 'phase5 inverse differs from delivered baseline');
    return restored;
}
