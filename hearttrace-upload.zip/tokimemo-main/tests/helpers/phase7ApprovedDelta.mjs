import { phase8ApprovedSource } from './phase8ApprovedDelta.mjs';
// Exact approved phase7 delta. Preserve all prior phase3/historical checks.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
export const phase7Deltas = {
  "src/archive/library.js": {
    "beforeSha256": "8f3deaf62b0166c476daf96ef366b2d3814abc49f1cdc14435703d1cf55b8550",
    "afterSha256": "7fbc4de6cf8df964d13ea7bcfe8de4a92a9db68ca1857bac5890d658673a941e",
    "changes": [
      {
        "start": 250,
        "remove": 9,
        "old": "",
        "new": "    if (record.status === 'open' && record.session.readableProgress?.complete === false\n        && (!sourceSnapshot || (!sourceSnapshot.historyVersionId && !sourceSnapshot.backupOnly\n            && generation_imageGeneration.indexedArchiveMatchesCurrentChat(sourceSnapshot, context)))) {\n        const current = sourceSnapshot ? await core_cache.readGenerationTaskResult(context, draftId) : record;\n        core_context.assertRuntimeLifecycleCurrent(lifecycle);\n        if (core_context.chatScopeKey(core_context.currentCharacterGuard()) !== scope) throw new DOMException('Chat changed', 'AbortError');\n        ui_overlay.openPartialTaskSession(current);\n        return current;\n    }\n"
      }
    ]
  },
  "src/core/cache.js": {
    "beforeSha256": "50b11627395d1c35a31c9aa7d6799037641c4b96c1d7d10a546b4240ebdb922e",
    "afterSha256": "1b5c32d28759d2573c173a66d528aba3e8b1d6c9dcd840899d29ce120f51d215",
    "changes": [
      {
        "start": 131,
        "remove": 1,
        "old": "    if (!bank || shownSession.chatId !== bank.chatId || shownSession.archiveRevision !== bank.archiveRevision) return null;\n",
        "new": "    if (!bank || shownSession.chatId !== bank.chatId) return null;\n"
      },
      {
        "start": 136,
        "remove": 10,
        "old": "",
        "new": "    if (shownSession.readableProgress?.explicitDraft === true) {\n        const draftId = shownSession.readableProgress.draftId, row = generationDraftRecords(stored)[draftId];\n        if (row?.status !== 'open' || row.result?.mode !== mode || row.result.sourceMemory?.chatId !== bank.chatId\n            || !equal(select(generationTaskResultSession({ draftId, ...row.result })))) return null;\n        return { draftId, pageId: row.result.pageId, status: 'open', session: cloneCacheValue(row.result.session),\n            sourceMemory: cloneCacheValue(row.result.sourceMemory), sourceContext: cloneCacheValue(row.result.sourceContext || {}),\n            contentSnapshot: generation_recovery.readGenerationContentSnapshot(row.journal),\n            frozenInputs: cloneCacheValue(row.journal?.frozenInputs || {}), journal: cloneCacheValue(row.journal) };\n    }\n    if (shownSession.archiveRevision !== bank.archiveRevision) return null;\n"
      },
      {
        "start": 187,
        "remove": 1,
        "old": "        value = typeof part === 'string' ? (value && Object.hasOwn(value, part) ? value[part] : undefined)\n",
        "new": "        value = typeof part === 'string' || typeof part === 'number' ? (value && Object.hasOwn(value, part) ? value[part] : undefined)\n"
      },
      {
        "start": 213,
        "remove": 19,
        "old": "",
        "new": "// Record only changed local fields; never copy task inputs into every edit.\nfunction collectProgressEdits(before, after, path = [], edits = []) {\n    if (sameProgressItemValue(before, after)) return edits;\n    if (Array.isArray(before) && Array.isArray(after)) {\n        after.forEach((value, index) => {\n            const id = typeof value?.id === 'string' ? value.id : null;\n            const previous = id ? before.find(item => item?.id === id) : before[index];\n            collectProgressEdits(previous, value, [...path, id ? { id } : index], edits);\n        });\n    } else if (before && after && typeof before === 'object' && typeof after === 'object'\n        && !Array.isArray(before) && !Array.isArray(after)) {\n        for (const key of new Set([...Object.keys(before), ...Object.keys(after)])) {\n            if (['generationSources', 'readableProgress', 'progressPending', ...PROGRESS_READING_FIELDS].includes(key)) continue;\n            collectProgressEdits(before[key], after[key], [...path, key], edits);\n        }\n    } else if (path.length) edits.push({ path, ...(after === undefined ? { remove: true } : { value: structuredClone(after) }) });\n    return edits;\n}\n\n"
      },
      {
        "start": 233,
        "remove": 7,
        "old": "",
        "new": "    for (const edit of metadata?.manualFieldsV1 || []) {\n        const parent = progressPathValue(session, edit.path.slice(0, -1)), key = edit.path.at(-1);\n        if (!parent || typeof parent !== 'object' || !['string', 'number'].includes(typeof key)) continue;\n        if (edit.remove) delete parent[key];\n        else Object.defineProperty(parent, key, { value: structuredClone(edit.value), enumerable: true, configurable: true, writable: true });\n    }\n\n"
      },
      {
        "start": 256,
        "remove": 3,
        "old": "",
        "new": "    const localEdits = new Map((metadata.manualFieldsV1 || []).map(edit => [JSON.stringify(edit.path), edit]));\n    for (const edit of collectProgressEdits(before, next)) localEdits.set(JSON.stringify(edit.path), edit);\n    if (localEdits.size) metadata.manualFieldsV1 = [...localEdits.values()];\n"
      },
      {
        "start": 340,
        "remove": 1,
        "old": "    if (next.readableProgress) for (const key of ['textOverridesV1', 'clearedFieldsV1']) {\n",
        "new": "    if (next.readableProgress) for (const key of ['textOverridesV1', 'clearedFieldsV1', 'manualFieldsV1']) {\n"
      },
      {
        "start": 365,
        "remove": 1,
        "old": "        if (record?.status !== 'open' || !record.result?.session || record.result.sourceMemory?.archiveRevision !== bank.archiveRevision) return false;\n",
        "new": "        if (record?.status !== 'open' || !record.result?.session || core_context.comparableChatId(record.result.sourceMemory?.chatId) !== core_context.comparableChatId(bank.chatId)) return false;\n"
      },
      {
        "start": 457,
        "remove": 8,
        "old": "",
        "new": "}\n\nexport function generationTaskResultSession(record) {\n    const session = cloneCacheValue(record.session);\n    session.readableProgress = { ...session.readableProgress, explicitDraft: true, draftId: record.draftId };\n    session.generationSources = { ...(session.generationSources || {}), [record.pageId || record.mode]: {\n        sourceMemory: cloneCacheValue(record.sourceMemory), sourceIdentity: cloneCacheValue(record.sourceIdentity) } };\n    return session;\n"
      }
    ]
  },
  "src/generation/cgAppearance.js": {
    "beforeSha256": "3b771fe4c9b3205f739076b79f25d9674c83b29d20226c1488aba7aa0c5fe6da",
    "afterSha256": "b66aeabd0786d0e596c37b58b5c197da73c70f3e702b2bc92961ef125afd665c",
    "changes": [
      {
        "start": 57,
        "remove": 1,
        "old": "                description: known ? '' : person.sourceRefs.map(ref => participantSourceText(ref.content, context)).filter(Boolean).join('\\n'),\n",
        "new": "                description: plain(known?.tag, CG_APPEARANCE_TAG_LIMIT) ? '' : person.sourceRefs.map(ref => participantSourceText(ref.content, context)).filter(Boolean).join('\\n'),\n"
      },
      {
        "start": 259,
        "remove": 1,
        "old": "export function appearanceEvidenceWithDraft(evidence, draft) {\n",
        "new": "export function appearanceEvidenceWithDraft(evidence, draft, context = null) {\n"
      },
      {
        "start": 264,
        "remove": 8,
        "old": "            return { ...row, knownTag: plain(draft[row.participantId], CG_APPEARANCE_TAG_LIMIT), knownNl: '' };\n",
        "new": "            const knownTag = plain(draft[row.participantId], CG_APPEARANCE_TAG_LIMIT);\n            // Clearing a saved tag means re-extract from this person's sources,\n            // not that the corresponding worldbook description disappeared.\n            const description = !knownTag && row.knownTag && !row.description\n                ? (evidence.castSnapshot.people.find(person => person.id === row.participantId)?.sourceRefs || [])\n                    .map(ref => participantSourceText(ref.content, context)).filter(Boolean).join('\\n')\n                : row.description;\n            return { ...row, description, knownTag, knownNl: '' };\n"
      }
    ]
  },
  "src/generation/client.js": {
    "beforeSha256": "49fc14cbffd7d3c46583f950c2de32d406913ceb35549062ae99c8f9642dcb93",
    "afterSha256": "0f2fae935c89187c1c03ad372c19980af9a119d8c888a8be8d78fc4887439367",
    "changes": [
      {
        "start": 248,
        "remove": 11,
        "old": "",
        "new": "}\nexport async function captureAlbumParticipantSnapshot(context, origin, { existing = null, participantSnapshot } = {}) {\n    // Keep legacy recipes and single-card journals byte-for-byte free of the\n    // multiplayer input key. Only explicit multiplayer work freezes a roster.\n    if (existing && !Object.hasOwn(existing.frozenInputs || {}, 'participants:album')) return null;\n    const snapshot = existing\n        ? core_participants.normalizeParticipantSnapshot(JSON.parse(existing.frozenInputs['participants:album']))\n        : participantSnapshot !== undefined ? core_participants.normalizeParticipantSnapshot(participantSnapshot)\n            : core_participants.selectedParticipantSnapshot(core_cache.readParticipantRoster(context));\n    if (!snapshot) return null;\n    return generation_recovery.frozenGenerationInput(origin, 'participants:album', () => snapshot);\n"
      },
      {
        "start": 1386,
        "remove": 2,
        "old": "",
        "new": "                participantSnapshot: options.participantRegeneration?.participantSnapshot })\n            : mode === core_constants.MODE.ALBUM ? await captureAlbumParticipantSnapshot(context, origin, { existing: recoveryExisting,\n"
      },
      {
        "start": 1389,
        "remove": 3,
        "old": "",
        "new": "        if (mode === core_constants.MODE.ALBUM && participantSnapshot) {\n            core_requestCoordinator.bindLogicalGenerationTask(options.logicalTask, origin, { participantSnapshot });\n        }\n"
      },
      {
        "start": 1426,
        "remove": 1,
        "old": "            session = await modes_album.generateAlbumWithRepair(context, memoryBank, origin, taskKey, { replaceExisting });\n",
        "new": "            session = await modes_album.generateAlbumWithRepair(context, memoryBank, origin, taskKey, { replaceExisting, participantSnapshot });\n"
      }
    ]
  },
  "src/generation/imageGeneration.js": {
    "beforeSha256": "802507631055883e1ef07b41f2321fb937d12a1576991131d48ae4b4d5480b5e",
    "afterSha256": "fe9f8413de0c20646bc2df35650cb45aaaa543a8100fa1c6f03de0662d890de0",
    "changes": [
      {
        "start": 214,
        "remove": 1,
        "old": "        || session.archiveRevision !== memory.archiveRevision) return null;\n",
        "new": "        || (!session.readableProgress?.explicitDraft && session.archiveRevision !== memory.archiveRevision)) return null;\n"
      },
      {
        "start": 218,
        "remove": 4,
        "old": "        const candidates = Object.entries(records).filter(([, row]) => row.status === 'open'\n            && row.result?.mode === mode && row.result.sourceMemory?.archiveRevision === memory.archiveRevision\n",
        "new": "        const candidates = Object.entries(records).filter(([id, row]) => row.status === 'open'\n            && row.result?.mode === mode && (session.readableProgress?.explicitDraft\n                ? id === session.readableProgress.draftId && row.result.sourceMemory?.chatId === memory.chatId\n                : row.result.sourceMemory?.archiveRevision === memory.archiveRevision)\n"
      },
      {
        "start": 226,
        "remove": 1,
        "old": "",
        "new": "        if (!draftId && session.readableProgress?.explicitDraft) return null;\n"
      },
      {
        "start": 294,
        "remove": 1,
        "old": "        cg_appearance.appearanceEvidenceWithDraft(cg_appearance.captureCgAppearanceEvidence(context, { castSnapshot: selectedCast }), appearanceDraft), promptFormat);\n",
        "new": "        cg_appearance.appearanceEvidenceWithDraft(cg_appearance.captureCgAppearanceEvidence(context, { castSnapshot: selectedCast }), appearanceDraft, context), promptFormat);\n"
      },
      {
        "start": 490,
        "remove": 3,
        "old": "            if (memory.archiveRevision !== captured.revision) return null;\n",
        "new": "            const expectedRevision = captured.draftId && cgDraftRecord(context, captured.draftId)?.status === 'open'\n                ? captured.session.archiveRevision : captured.revision;\n            if (memory.archiveRevision !== expectedRevision) return null;\n"
      },
      {
        "start": 515,
        "remove": 2,
        "old": "            if (session?.kind !== captured.mode || session.archiveRevision !== captured.revision\n",
        "new": "            if (session?.kind !== captured.mode || (session.archiveRevision !== captured.revision\n                && !(captured.draftId && session.readableProgress?.draftId === captured.draftId))\n"
      },
      {
        "start": 660,
        "remove": 1,
        "old": "            if (session.archiveRevision !== captured.revision || cgItemSignature(item) !== captured.signature) {\n",
        "new": "            if (session.archiveRevision !== captured.session.archiveRevision || cgItemSignature(item) !== captured.signature) {\n"
      }
    ]
  },
  "src/modes/album.js": {
    "beforeSha256": "7160ed26eb32a77fc6a50608e6c968410923c682e0c6d63b75b92f1d6ce70fe0",
    "afterSha256": "86c8e5d5ec4d97e01eaefda8f5c0e948a82447505260faad76678cfc41c487e1",
    "changes": [
      {
        "start": 0,
        "remove": 1,
        "old": "",
        "new": "import * as core_participants from '../core/participants.js';\n"
      },
      {
        "start": 17,
        "remove": 40,
        "old": "",
        "new": "\n// Per-entry identities omit worldbook prose; full generation sources are frozen\n// once by the task/session rather than copied again for every CG.\nexport function albumSpeakerIdentities(snapshot) {\n    return snapshot ? { version: 1, people: snapshot.people.map(({ id, name }) => ({ id, name })) } : null;\n}\n\nexport function normalizeAlbumSpeakerSnapshot(snapshot) {\n    return snapshot ? core_participants.normalizeParticipantSnapshot({ ...snapshot,\n        people: snapshot.people.map(person => ({ ...person, sourceRefs: [] })) }) : null;\n}\n\n// Keep legacy string arrays intact. Multiplayer attribution lives beside the text,\n// so old exports/editors and already generated prose retain their existing shape.\nexport function normalizeAlbumDialogue(raw, participantSnapshot = null, savedSpeakers = []) {\n    const snapshot = core_participants.normalizeParticipantSnapshot(participantSnapshot);\n    if (!snapshot) return { comments: core_text.cleanArray(raw, 8, 1200) };\n    const comments = [], commentSpeakers = [];\n    for (const [index, line] of (Array.isArray(raw) ? raw : []).slice(0, 8).entries()) {\n        const text = core_text.normalizeText(typeof line === 'string' ? line : line?.text, 1200);\n        if (!text) continue;\n        const id = typeof line === 'object' ? line?.speakerId : savedSpeakers[index]?.speakerId;\n        const person = snapshot.people.find(person => person.id === id);\n        comments.push(text);\n        commentSpeakers.push({ speakerId: person?.id || '', speakerName: person?.name || '' });\n    }\n    return { comments, commentSpeakers };\n}\n\nfunction participantRelationshipBank(memoryBank, person) {\n    // Generic \"both\" clauses in another person's memory cannot establish this pair.\n    // Keep explicitly named evidence and records whose participants bind this person.\n    const named = value => !!person.name && typeof value === 'string' && value.includes(person.name);\n    return { ...memoryBank, characterName: person.name,\n        archiveSummary: String(memoryBank?.archiveSummary || '').split(/[。！？\\n]/u).filter(named).join('。'),\n        memories: (memoryBank?.memories || []).filter(memory =>\n            memory.participants?.includes(person.name) || named(memory.title) || named(memory.summary)),\n    };\n}\n\n"
      },
      {
        "start": 69,
        "remove": 2,
        "old": "export function projectAlbumProgress({ segments = [], memoryBank }) {\n",
        "new": "export function projectAlbumProgress({ segments = [], memoryBank, frozenInputs = {} }) {\n    const participantSnapshot = core_participants.normalizeParticipantSnapshot(frozenInputs['participants:album'] || null);\n"
      },
      {
        "start": 90,
        "remove": 1,
        "old": "        try { relationshipSnapshot = normalizeAlbumRelationshipSnapshot(relationship.value, memoryBank); } catch {}\n",
        "new": "        try { relationshipSnapshot = normalizeAlbumRelationshipSnapshot(relationship.value, memoryBank, participantSnapshot); } catch {}\n"
      },
      {
        "start": 96,
        "remove": 1,
        "old": "",
        "new": "        if (participantSnapshot) entry.speakerSnapshot = albumSpeakerIdentities(participantSnapshot);\n"
      },
      {
        "start": 103,
        "remove": 1,
        "old": "                entry.comments = core_text.cleanArray(segment.items(`/items/${i}/comments`), 8, 1200);\n",
        "new": "                Object.assign(entry, normalizeAlbumDialogue(segment.items(`/items/${i}/comments`), participantSnapshot));\n"
      },
      {
        "start": 105,
        "remove": 1,
        "old": "                    const complete = normalizeAlbumCommentsBatch({ items: [row] }, [entry]);\n",
        "new": "                    const complete = normalizeAlbumCommentsBatch({ items: [row] }, [entry], participantSnapshot);\n"
      },
      {
        "start": 107,
        "remove": 2,
        "old": "                        entry.comments = complete.get(entry.id);\n",
        "new": "                        if (participantSnapshot) Object.assign(entry, complete.get(entry.id));\n                        else entry.comments = complete.get(entry.id);\n"
      },
      {
        "start": 115,
        "remove": 1,
        "old": "    return { kind: core_constants.MODE.ALBUM, title: core_text.normalizeText(index.value?.title, 120) || '回忆相簿', entries,\n",
        "new": "    return { ...(participantSnapshot ? { participantSnapshot } : {}), kind: core_constants.MODE.ALBUM, title: core_text.normalizeText(index.value?.title, 120) || '回忆相簿', entries,\n"
      },
      {
        "start": 154,
        "remove": 10,
        "old": "export function albumRelationshipScanPrompt(context, memoryBank) {\n",
        "new": "export function albumRelationshipScanPrompt(context, memoryBank, participantSnapshot = null) {\n    const snapshot = core_participants.normalizeParticipantSnapshot(participantSnapshot);\n    if (snapshot) return `${generation_prompts.promptSafetyBoundary(context, '回忆相簿 / 分段 2：当下关系扫描')}\n本请求扫描完整档案，分别判定每位选定人物与 {{user}} 的当下关系；不写 CG 或对白，不预演未来。角色卡名称是场景标题，不能充当人物姓名。\n${core_participants.participantPromptBlock(snapshot)}\nALBUM_RELATIONSHIP_FULL_ARCHIVE_JSON:\n${albumRelationshipArchiveSlice(memoryBank)}\n严格输出 {\"people\":[{\"speakerId\":\"名单中的原始 id\",\"charState\":\"该人物已证实的态度\",\"userState\":\"用户对该人物已明确表达的态度，未知写未确认\",\"relationshipState\":\"该人物与用户的关系阶段\",\"relationshipSummary\":\"该人物与用户的证据总结\",\"relationshipSourceMemoryIds\":[\"M001\"],\"relationshipSourceMemoryAnchor\":\"该记忆的原样锚点\"}]}。\n每位选定人物各返回一条，用 speakerId 对应。每人的证据和关系分别核对，不能把甲的恋爱关系、行为或内心套给乙；不替用户创造回应。引用必须来自上方档案，只输出 JSON。`;\n\n"
      },
      {
        "start": 186,
        "remove": 17,
        "old": "export function normalizeAlbumRelationshipSnapshot(data, memoryBank) {\n",
        "new": "export function normalizeAlbumRelationshipSnapshot(data, memoryBank, participantSnapshot = null, relationshipBank = memoryBank) {\n    const snapshot = core_participants.normalizeParticipantSnapshot(participantSnapshot);\n    if (snapshot) return { people: snapshot.people.map(person => {\n        const row = Array.isArray(data?.people) ? data.people.find(row => row?.speakerId === person.id) : null;\n        const scopedBank = participantRelationshipBank(memoryBank, person);\n        if (!row) return { speakerId: person.id, speakerName: person.name, relationshipTier: 0,\n            charState: '未确认', userState: '未确认', relationshipState: '关系未确认',\n            relationshipSummary: '尚无该人物的已保存关系扫描；不预设双方恋爱。',\n            relationshipSourceMemoryIds: [], relationshipSourceMemoryAnchor: '' };\n        if (!row.relationshipSourceMemoryIds?.length) return { ...row, speakerId: person.id, speakerName: person.name,\n            relationshipTier: 0, charState: '未确认', userState: '未确认', relationshipState: '关系未确认' };\n        // Verify citations against the original archive, but derive the relationship\n        // only from evidence belonging to this person rather than the sandbox title.\n        const result = normalizeAlbumRelationshipSnapshot(row, { ...memoryBank, characterName: person.name }, null, scopedBank);\n        return { ...result, speakerId: person.id, speakerName: person.name };\n    }) };\n\n"
      },
      {
        "start": 223,
        "remove": 1,
        "old": "    const tier = core_presentExpression.relationshipExpressionTier(memoryBank);\n",
        "new": "    const tier = core_presentExpression.relationshipExpressionTier(relationshipBank);\n"
      },
      {
        "start": 328,
        "remove": 13,
        "old": "export function albumCommentsPrompt(context, memoryBank, entries, relationshipSnapshot = null) {\n",
        "new": "export function albumCommentsPrompt(context, memoryBank, entries, relationshipSnapshot = null, participantSnapshot = null) {\n    const snapshot = core_participants.normalizeParticipantSnapshot(participantSnapshot);\n    if (snapshot) return `${generation_prompts.promptSafetyBoundary(context, '回忆相簿 / 分段 3：当下共同回忆')}\n本请求给 ${entries.length} 张已解锁的过去 CG 写一起翻相簿的当下对白。不同人物可以轮流说话，每句话由实际说话人的 speakerId 对应姓名。角色卡名不是人物。\n${core_participants.participantPromptBlock(snapshot)}\nCURRENT_RELATIONSHIP_SCAN_JSON:\n${JSON.stringify(normalizeAlbumRelationshipSnapshot(relationshipSnapshot, memoryBank, snapshot), null, 2)}\nUNTRUSTED_ALBUM_COMMENT_CONTEXT_JSON:\n${JSON.stringify({ entries: entries.map(item => ({ id: item.id, title: item.title, date: item.date, desc: item.desc, sourceMemoryIds: item.sourceMemoryIds, sourceMemoryAnchor: item.sourceMemoryAnchor, visualSeed: item.visualSeed })), memories: core_evidence.memoryPayload(memoryBank, [...new Set(entries.flatMap(item => item.sourceMemoryIds || []))].slice(0, 20), 20) }, null, 2)}\n严格输出 {\"items\":[{\"id\":\"CG01\",\"comments\":[{\"speakerId\":\"名单中的原始 id\",\"text\":\"该人物的当下对白\"}]}]}。\n每个输入 id 原样返回一次；每张 CG 写 6～8 段，每段约 35～120 个汉字。只让与该记忆有据可查的人物评论各自所知内容，不要求所有人物都出场。speakerId 必须来自上方名单，不以名字猜 ID，不替 {{user}} 生成现在的回应。\n每句话的称呼和亲密程度服从该 speakerId 自己的关系扫描，不挪用其他人的关系。至少覆盖画面细节、当时没说出口的想法和现在的理解；不新增过去事实，不写 ADV 过去独白，不修改记忆证据。只输出 JSON。`;\n\n"
      },
      {
        "start": 374,
        "remove": 1,
        "old": "export function normalizeAlbumCommentsBatch(data, expectedEntries) {\n",
        "new": "export function normalizeAlbumCommentsBatch(data, expectedEntries, participantSnapshot = null) {\n"
      },
      {
        "start": 381,
        "remove": 2,
        "old": "        const comments = core_text.cleanArray(item?.comments, 8, 1200);\n        if (comments.length >= 6) out.set(id, comments);\n",
        "new": "        const dialogue = normalizeAlbumDialogue(item?.comments, participantSnapshot, item?.commentSpeakers);\n        if (dialogue.comments.length >= 6) out.set(id, participantSnapshot ? dialogue : dialogue.comments);\n"
      },
      {
        "start": 439,
        "remove": 1,
        "old": "",
        "new": "        ...(fresh.participantSnapshot ? { participantSnapshot: structuredClone(fresh.participantSnapshot) } : {}),\n"
      },
      {
        "start": 447,
        "remove": 1,
        "old": "",
        "new": "    const participantSnapshot = core_participants.normalizeParticipantSnapshot(options.participantSnapshot || null);\n"
      },
      {
        "start": 466,
        "remove": 1,
        "old": "        albumRelationshipScanPrompt(context, memoryBank),\n",
        "new": "        albumRelationshipScanPrompt(context, memoryBank, participantSnapshot),\n"
      },
      {
        "start": 469,
        "remove": 1,
        "old": "        raw => normalizeAlbumRelationshipSnapshot(raw, memoryBank),\n",
        "new": "        raw => normalizeAlbumRelationshipSnapshot(raw, memoryBank, participantSnapshot),\n"
      },
      {
        "start": 474,
        "remove": 1,
        "old": "            albumCommentsPrompt(context, memoryBank, batch, relationshipSnapshot),\n",
        "new": "            albumCommentsPrompt(context, memoryBank, batch, relationshipSnapshot, participantSnapshot),\n"
      },
      {
        "start": 477,
        "remove": 1,
        "old": "            data => normalizeAlbumCommentsBatch(data, batch),\n",
        "new": "            data => normalizeAlbumCommentsBatch(data, batch, participantSnapshot),\n"
      },
      {
        "start": 483,
        "remove": 1,
        "old": "",
        "new": "        ...(participantSnapshot ? { participantSnapshot } : {}),\n"
      },
      {
        "start": 486,
        "remove": 3,
        "old": "            comments: item.unlocked ? (allComments.get(item.id) || []) : [],\n",
        "new": "            ...(participantSnapshot ? { speakerSnapshot: albumSpeakerIdentities(participantSnapshot),\n                ...(item.unlocked ? (allComments.get(item.id) || { comments: [], commentSpeakers: [] }) : { comments: [] }) }\n                : { comments: item.unlocked ? (allComments.get(item.id) || []) : [] }),\n"
      },
      {
        "start": 506,
        "remove": 4,
        "old": "        const comments = unlocked ? core_text.cleanArray(item?.comments, 8, 1200) : [];\n",
        "new": "        const participantSnapshot = item?.speakerSnapshot ? normalizeAlbumSpeakerSnapshot(item.speakerSnapshot)\n            : core_participants.normalizeParticipantSnapshot(data?.participantSnapshot || null);\n        const dialogue = normalizeAlbumDialogue(unlocked ? item?.comments : [], participantSnapshot, item?.commentSpeakers);\n        const comments = dialogue.comments;\n"
      },
      {
        "start": 512,
        "remove": 1,
        "old": "            ? normalizeAlbumRelationshipSnapshot(item.relationshipSnapshot, memoryBank)\n",
        "new": "            ? normalizeAlbumRelationshipSnapshot(item.relationshipSnapshot, memoryBank, participantSnapshot)\n"
      },
      {
        "start": 532,
        "remove": 1,
        "old": "",
        "new": "            ...(participantSnapshot ? { speakerSnapshot: albumSpeakerIdentities(participantSnapshot), commentSpeakers: dialogue.commentSpeakers } : {}),\n"
      },
      {
        "start": 552,
        "remove": 1,
        "old": "",
        "new": "        ...(data?.participantSnapshot ? { participantSnapshot: core_participants.normalizeParticipantSnapshot(data.participantSnapshot) } : {}),\n"
      }
    ]
  },
  "src/ui/albumView.js": {
    "beforeSha256": "899dc4afee2bfe8d6c93a4ee27b2ea5f4cd8a3a192ef02f614d3597bb8b6f204",
    "afterSha256": "bcb949ef2d05898c4970a2a73f39e891f4091baf450cb65ea635cacc9c291ac2",
    "changes": [
      {
        "start": 0,
        "remove": 3,
        "old": "",
        "new": "import * as modes_album from '../modes/album.js';\nimport * as core_participants from '../core/participants.js';\nimport * as core_cache from '../core/cache.js';\n"
      },
      {
        "start": 186,
        "remove": 27,
        "old": "",
        "new": "export function albumSpeakerSnapshot(item, session = runtimeState.activeSession) {\n    // A saved item's identities win over a later roster edit. Legacy rows may be\n    // attributed manually using the active archive's explicitly selected people.\n    return modes_album.normalizeAlbumSpeakerSnapshot(item?.speakerSnapshot)\n        || core_participants.normalizeParticipantSnapshot(session?.participantSnapshot || null)\n        || core_participants.selectedParticipantSnapshot(runtimeState.activeArchiveSnapshot\n            ? runtimeState.activeArchiveSnapshot.cache?.participantsV1 || runtimeState.activeArchiveSnapshot.memory?.participantsV1\n            : core_cache.readParticipantRoster(core_context.getContext()));\n}\n\nexport async function albumSetCommentSpeaker(entryId, index, speakerId) {\n    if (!archive_library.requireWritableArchiveAction()) return;\n    const item = runtimeState.activeSession?.entries?.find(entry => entry.id === entryId);\n    const snapshot = albumSpeakerSnapshot(item);\n    const person = snapshot?.people.find(person => person.id === speakerId);\n    if (!item || !Number.isInteger(index) || index < 0 || index >= item.comments.length || (speakerId && !person)) return;\n    await ui_overlay.saveActiveSessionEdit(session => {\n        const latest = session.entries.find(entry => entry.id === entryId);\n        latest.speakerSnapshot = modes_album.albumSpeakerIdentities(snapshot);\n        latest.commentSpeakers = latest.comments.map((_, lineIndex) => lineIndex === index\n            ? { speakerId: person?.id || '', speakerName: person?.name || '' }\n            : latest.commentSpeakers?.[lineIndex] || { speakerId: '', speakerName: '' });\n        return session;\n    }, { select: session => session.entries?.find(entry => entry.id === entryId) });\n    renderSharedMemory();\n}\n\n"
      },
      {
        "start": 220,
        "remove": 4,
        "old": "    const charName = core_text.normalizeText(runtimeState.activeArchiveSnapshot?.characterName || core_context.getContext()?.name2, 80) || '他';\n",
        "new": "    const snapshot = albumSpeakerSnapshot(item, session);\n    const speaker = snapshot?.people.find(person => person.id === item.commentSpeakers?.[session.dialogueIndex]?.speakerId);\n    const charName = snapshot ? (speaker?.name || '未标注人物')\n        : core_text.normalizeText(runtimeState.activeArchiveSnapshot?.characterName || core_context.getContext()?.name2, 80) || '他';\n"
      },
      {
        "start": 236,
        "remove": 1,
        "old": "",
        "new": "        ${snapshot && comments.length && !readOnly ? `<label>本句说话人 <select data-rmt-album-speaker=\"${core_text.esc(item.id)}\" data-rmt-dialogue-index=\"${session.dialogueIndex}\"><option value=\"\">未标注人物</option>${snapshot.people.map(person => `<option value=\"${core_text.esc(person.id)}\"${person.id === speaker?.id ? ' selected' : ''}>${core_text.esc(person.name)}</option>`).join('')}</select></label>` : ''}\n"
      },
      {
        "start": 246,
        "remove": 5,
        "old": "",
        "new": "    body.querySelector?.('[data-rmt-album-speaker]')?.addEventListener('change', event => {\n        const select = event.currentTarget;\n        void albumSetCommentSpeaker(select.dataset.rmtAlbumSpeaker, Number(select.dataset.rmtDialogueIndex), select.value)\n            .catch(error => globalThis.toastr?.error?.(core_text.toastText(core_text.safeErrorSummary(error)), '心迹回廊'));\n    });\n"
      }
    ]
  },
  "src/ui/cgPromptEditor.js": {
    "beforeSha256": "be84b61e9281c5add33ab81e9ab8e58cb1c345f4e6b9a0cdaccd259132994c8d",
    "afterSha256": "888abe1741f501c23ba082f60f6a2e89ad81a8f948353f3906a3971bafd5269a",
    "changes": [
      {
        "start": 55,
        "remove": 1,
        "old": "    for (const button of editor.element.querySelectorAll('[data-rmt-cg-prompt-action=\"reconceive\"], [data-rmt-cg-prompt-action=\"draw\"], [data-rmt-cg-prompt-action=\"clear\"], [data-rmt-cg-prompt-action=\"retry\"], [data-rmt-cg-prompt-action=\"save-looks\"], [data-rmt-cg-prompt-action=\"restore-draft\"], [data-rmt-cg-prompt-action=\"add-person\"], [data-rmt-cg-prompt-action=\"add-user\"]')) button.disabled = active;\n",
        "new": "    for (const button of editor.element.querySelectorAll('[data-rmt-cg-prompt-action=\"reconceive\"], [data-rmt-cg-prompt-action=\"draw\"], [data-rmt-cg-prompt-action=\"clear\"], [data-rmt-cg-prompt-action=\"retry\"], [data-rmt-cg-prompt-action=\"save-looks\"], [data-rmt-cg-prompt-action=\"restore-draft\"], [data-rmt-cg-prompt-action=\"add-person\"], [data-rmt-cg-prompt-action=\"add-user\"], [data-rmt-cg-prompt-action=\"use-current-cast\"]')) button.disabled = active;\n"
      },
      {
        "start": 96,
        "remove": 17,
        "old": "",
        "new": "}\n\nfunction appearanceFieldsHtml(multi) {\n    return multi ? '<fieldset data-rmt-cg-cast><legend>本图出镜人物</legend><p>勾选只影响这张图。姓名可改，也可补充档案名单外的人物；同名人物独立保存。</p><div data-rmt-cg-cast-list></div><button type=\"button\" class=\"rmt-btn\" data-rmt-cg-prompt-action=\"add-person\">补充人物</button><button type=\"button\" class=\"rmt-btn\" data-rmt-cg-prompt-action=\"add-user\">添加用户为候选</button></fieldset>' : `<p><label for=\"rmt-cg-char-tags\" data-rmt-cg-tag-name=\"char\">角色 · 外貌 tag</label><textarea id=\"rmt-cg-char-tags\" data-rmt-cg-tag-input=\"char\" rows=\"2\" maxlength=\"${appearance.CG_APPEARANCE_TAG_LIMIT}\" placeholder=\"重新构思时提取，或手动填写\"></textarea></p>\n            <p><label for=\"rmt-cg-user-tags\" data-rmt-cg-tag-name=\"user\">用户 · 外貌 tag</label><textarea id=\"rmt-cg-user-tags\" data-rmt-cg-tag-input=\"user\" rows=\"2\" maxlength=\"${appearance.CG_APPEARANCE_TAG_LIMIT}\" placeholder=\"重新构思时提取，或手动填写\"></textarea></p>`;\n}\n\nfunction changeEditorCastMode(current, multi) {\n    if (current.multi === multi) return;\n    current.multi = multi;\n    current.element.querySelector('[data-rmt-cg-appearance-fields]').innerHTML = appearanceFieldsHtml(multi);\n    if (!multi) for (const field of current.element.querySelectorAll('[data-rmt-cg-tag-input]')) {\n        field.addEventListener('input', () => { invalidateFlatPrompt(current); updatePreparedPreview(current); });\n    }\n    const context = core_context.currentCharacterGuard();\n    current.looksSignature = multi ? cast_looks.participantLooksSignature(cast_looks.readParticipantLooks(context))\n        : cast_looks.castLooksSignature(cast_looks.readCastLooks(context));\n"
      },
      {
        "start": 220,
        "remove": 2,
        "old": "        const roster = multi && !selected.cgImage ? cache.readParticipantRoster(context) : null;\n",
        "new": "        const currentRoster = cache.readParticipantRoster(context);\n        const roster = multi && !selected.cgImage ? currentRoster : null;\n"
      },
      {
        "start": 236,
        "remove": 2,
        "old": "            ${multi ? '<fieldset data-rmt-cg-cast><legend>本图出镜人物</legend><p>勾选只影响这张图。姓名可改，也可补充档案名单外的人物；同名人物独立保存。</p><div data-rmt-cg-cast-list></div><button type=\"button\" class=\"rmt-btn\" data-rmt-cg-prompt-action=\"add-person\">补充人物</button><button type=\"button\" class=\"rmt-btn\" data-rmt-cg-prompt-action=\"add-user\">添加用户为候选</button></fieldset>' : `<p><label for=\"rmt-cg-char-tags\" data-rmt-cg-tag-name=\"char\">角色 · 外貌 tag</label><textarea id=\"rmt-cg-char-tags\" data-rmt-cg-tag-input=\"char\" rows=\"2\" maxlength=\"${appearance.CG_APPEARANCE_TAG_LIMIT}\" placeholder=\"重新构思时提取，或手动填写\"></textarea></p>\n            <p><label for=\"rmt-cg-user-tags\" data-rmt-cg-tag-name=\"user\">用户 · 外貌 tag</label><textarea id=\"rmt-cg-user-tags\" data-rmt-cg-tag-input=\"user\" rows=\"2\" maxlength=\"${appearance.CG_APPEARANCE_TAG_LIMIT}\" placeholder=\"重新构思时提取，或手动填写\"></textarea></p>`}\n",
        "new": "            <div data-rmt-cg-appearance-fields>${appearanceFieldsHtml(multi)}</div>\n            ${selected.cgImage && participants.selectedParticipantSnapshot(currentRoster) ? '<button type=\"button\" class=\"rmt-btn\" data-rmt-cg-prompt-action=\"use-current-cast\">从当前档案选择本图人物</button>' : ''}\n"
      },
      {
        "start": 322,
        "remove": 17,
        "old": "",
        "new": "        if (action === 'use-current-cast') {\n            const context = core_context.currentCharacterGuard();\n            const roster = cache.readParticipantRoster(context);\n            const snapshot = participants.selectedParticipantSnapshot(roster);\n            if (!snapshot) return;\n            const previous = snapshotEditorDraft(current);\n            const saved = cast_looks.readParticipantLooks(context);\n            rememberEditorDraft(current, previous);\n            changeEditorCastMode(current, true);\n            current.people = roster.people.map(person => ({ ...person, selected: false,\n                tag: saved?.characters.find(row => row.participantId === person.id)?.tag || '' }));\n            fillEditorMetadata(current, { promptFormat: current.promptFormat, sceneTags: previous.metadata?.sceneTags || '',\n                castSnapshot: snapshot, characters: saved?.characters || [] });\n            current.element.querySelector('[data-rmt-cg-appearance]').open = true;\n            current.element.querySelector('[data-rmt-cg-prompt-status]').textContent = '已载入当前档案人物，请勾选本图出镜者。原图和原提示未改动；重新构思后再确认绘图。';\n            return;\n        }\n"
      },
      {
        "start": 345,
        "remove": 1,
        "old": "",
        "new": "            changeEditorCastMode(current, !!draft.metadata?.castSnapshot);\n"
      }
    ]
  },
  "src/ui/contentManager.js": {
    "beforeSha256": "aa6adaaab41ad49fff40863fc3d1ae7ee6b516d9d42aa7dfe5af44da01cb4a25",
    "afterSha256": "ea5ac668b278b17a0d22fb9e72253a796551c217828abd7b873e689788732967",
    "changes": [
      {
        "start": 26,
        "remove": 94,
        "old": "",
        "new": "\nconst EDITABLE_CONTENT_LABELS = Object.freeze({\n    title: '标题', subtitle: '副标题', label: '名称', name: '名称', date: '日期', setting: '场景', scene: '场景',\n    description: '说明', desc: '画面说明', summary: '摘要', text: '正文', line: '台词', lines: '台词',\n    body: '正文', greeting: '称呼', closing: '结尾', monologue: '独白', intervention: '回应', systemNote: '观测批语',\n    preview: '摘要', detail: '正文', caption: '图片说明', imageCaption: '图片说明', cgDesc: '画面说明',\n    unlockCondition: '达成条件', hint: '提示', hintLines: '提示', comments: '共同回忆', lyrics: '歌词',\n    vocalDescription: '演唱描述', styleDescription: '音乐描述', value: '内容', content: '正文', message: '留言',\n    dialogueLines: '台词', script: '对话', action: '动作', narration: '叙述', synopsis: '梗概', reflection: '感想',\n    endingScene: '终章', confession: '告白', confessionText: '告白', confessionLines: '告白台词',\n    creditsLine: '落幕语', timeSkip: '时间跨度', finalLine: '结语', unlockHint: '解锁提示',\n    responseSummary: '回应', afterEffect: '后续影响', statusLine: '状态', logs: '记录', poem: '短句',\n    opening: '开场', location: '地点', ending: '结尾', revealedText: '揭示内容',\n    morning: '早安', afternoon: '午后', evening: '晚间', night: '晚安', bedtime: '睡前',\n    atmosphere: '氛围', activity: '活动', npcPerspective: '人物视角', relation: '关系',\n});\nconst EDITOR_INTERNAL_FIELDS = new Set(['generationSources', 'readableProgress', 'participantSnapshot', 'speakerSnapshot',\n    'cgImage', 'cgPromptDraft', 'cgPromptMetadata', 'sourceMemory', 'sourceContext', 'sourceIdentity', 'progressPending']);\n\nexport function partialContentFields(session) {\n    const fields = [];\n    const visit = (value, path = [], field = '', label = '') => {\n        if (typeof value === 'string' && EDITABLE_CONTENT_LABELS[field]) {\n            fields.push({ path, label: `${label ? `${label} · ` : ''}${EDITABLE_CONTENT_LABELS[field]}`, value });\n        } else if (Array.isArray(value)) value.forEach((item, index) => visit(item,\n            [...path, typeof item?.id === 'string' ? { id: item.id } : index], field, item?.title || item?.name || `${label} ${index + 1}`.trim()));\n        else if (value && typeof value === 'object') for (const [key, item] of Object.entries(value)) {\n            if (!EDITOR_INTERNAL_FIELDS.has(key)) visit(item, [...path, key], key, label);\n        }\n    };\n    visit(session);\n    return fields;\n}\n\nfunction editorPathValue(session, path) {\n    return path.reduce((value, part) => typeof part === 'object'\n        ? value?.find?.(item => item?.id === part.id) : value?.[part], session);\n}\n\nexport async function savePartialContentField(field, value) {\n    return ui_overlay.saveActiveSessionEdit(session => {\n        const parent = editorPathValue(session, field.path.slice(0, -1));\n        parent[field.path.at(-1)] = value;\n        return session;\n    }, { select: session => editorPathValue(session, field.path) });\n}\n\nexport async function deletePartialContentItem(path) {\n    return ui_overlay.saveActiveSessionEdit(session => {\n        const parent = editorPathValue(session, path.slice(0, -1)), target = path.at(-1);\n        const index = parent.findIndex(item => item?.id === target.id);\n        if (index >= 0) parent.splice(index, 1);\n        return session;\n    }, { select: session => editorPathValue(session, path) });\n}\n\nexport function renderPartialContentEditor() {\n    if (!archive_library.requireWritableArchiveAction()) return;\n    const body = ui_overlay.bodyEl(), fields = partialContentFields(runtimeState.activeSession);\n    const items = new Map();\n    for (const field of fields) {\n        const index = field.path.findLastIndex(part => part && typeof part === 'object' && part.id);\n        if (index < 0) continue;\n        const path = field.path.slice(0, index + 1), item = editorPathValue(runtimeState.activeSession, path);\n        items.set(JSON.stringify(path), { path, label: item.title || item.name || item.label || item.id });\n    }\n    const deletable = [...items.values()];\n    if (!body) return;\n    runtimeState.contentManagerOpen = true;\n    ui_overlay.topTitle('编辑已生成内容');\n    ui_overlay.setBackVisible(true, '返回内容');\n    body.innerHTML = `<section class=\"rmt-manage-shell\"><p>直接修改已生成的文字，不调用 API。继续生成会保留你的修改。生图仍在原来的图片设置中。</p>\n      <button type=\"button\" class=\"rmt-btn\" data-rmt-partial-editor-back>返回内容</button>\n      ${fields.map((field, index) => `<article class=\"rmt-manage-row\" style=\"display:block\"><label>${core_text.esc(field.label)}\n      <textarea data-rmt-partial-field=\"${index}\" style=\"display:block;width:100%;min-height:6em\">${core_text.esc(field.value)}</textarea></label>\n      <button type=\"button\" class=\"rmt-btn\" data-rmt-partial-save=\"${index}\">保存此项</button></article>`).join('')}\n      ${deletable.map((item, index) => `<button type=\"button\" class=\"rmt-btn\" data-rmt-partial-delete=\"${index}\">删除条目：${core_text.esc(item.label)}</button>`).join('')}</section>`;\n    body.querySelector?.('[data-rmt-partial-editor-back]')?.addEventListener('click', () => ui_overlay.renderActive());\n    body.querySelectorAll?.('[data-rmt-partial-save]').forEach(button => button.addEventListener('click', async () => {\n        const index = Number(button.dataset.rmtPartialSave), field = fields[index];\n        const value = body.querySelector(`[data-rmt-partial-field=\"${index}\"]`).value;\n        try {\n            await savePartialContentField(field, value);\n            field.value = value;\n            globalThis.toastr?.success?.('修改已保存，继续生成会保留。', '心迹回廊');\n        } catch (error) { globalThis.toastr?.error?.(core_text.safeErrorSummary(error), '心迹回廊'); }\n    }));\n    body.querySelectorAll?.('[data-rmt-partial-delete]').forEach(button => button.addEventListener('click', async () => {\n        const item = deletable[Number(button.dataset.rmtPartialDelete)];\n        if (!ui_overlay.confirmExplicitActionTwice(`删除「${item.label}」？`, '只删除这份任务中的这一条，继续生成也不会把它恢复。', { destructive: true })) return;\n        try { await deletePartialContentItem(item.path); renderPartialContentEditor(); }\n        catch (error) { globalThis.toastr?.error?.(core_text.safeErrorSummary(error), '心迹回廊'); }\n    }));\n}\n"
      }
    ]
  },
  "src/ui/overlay.js": {
    "beforeSha256": "02847ae109a2088d97de04b9e14ccfba29f5ebc65b687bb39d8e39b246f6e921",
    "afterSha256": "7c7b063a65d6fb304d4693be97425cc42aee7c5e8f475d33b5b1cac628feeb4d",
    "changes": [
      {
        "start": 1067,
        "remove": 1,
        "old": "",
        "new": "    if (prior?.readableProgress?.explicitDraft && !ownsDraft) return false;\n"
      },
      {
        "start": 1087,
        "remove": 3,
        "old": "    const session = core_cache.loadSession(mode, { context, chatId: memory?.chatId, memoryBank: memory, cache: stored, clone: true, includePartial: true });\n",
        "new": "    const exactResult = prior?.readableProgress?.explicitDraft ? stored?.[core_cache.GENERATION_DRAFTS_CACHE_KEY]?.records?.[prior.readableProgress.draftId]?.result : null;\n    const session = exactResult ? core_cache.generationTaskResultSession({ draftId: prior.readableProgress.draftId, ...exactResult })\n        : core_cache.loadSession(mode, { context, chatId: memory?.chatId, memoryBank: memory, cache: stored, clone: true, includePartial: true });\n"
      },
      {
        "start": 1091,
        "remove": 1,
        "old": "    if (!snapshot && stored?.[core_cache.GENERATION_DRAFTS_CACHE_KEY]?.records?.[draftId]?.result?.sourceMemory?.archiveRevision !== memory?.archiveRevision) return false;\n",
        "new": "    if (!snapshot && !exactResult && stored?.[core_cache.GENERATION_DRAFTS_CACHE_KEY]?.records?.[draftId]?.result?.sourceMemory?.archiveRevision !== memory?.archiveRevision) return false;\n"
      },
      {
        "start": 1110,
        "remove": 39,
        "old": "",
        "new": "}\n\nexport function openPartialTaskSession(record) {\n    runtimeState.activeArchiveSnapshot = null;\n    runtimeState.activeArchiveReadOnly = false;\n    runtimeState.activeMode = record.mode;\n    runtimeState.activeSession = core_cache.generationTaskResultSession(record);\n    runtimeState.archiveViewLevel = 'content';\n    ui_workspaceState.prepareWorkspaceSession(record.mode, runtimeState.activeSession, record.pageId);\n    renderActive();\n}\n\n// Persist a local change to the precise draft/formal item that the user saw.\nexport async function saveActiveSessionEdit(mutator, { select = value => value } = {}) {\n    if (!archive_library.requireWritableArchiveAction()) return null;\n    const shown = runtimeState.activeSession, mode = runtimeState.activeMode;\n    const context = core_context.currentCharacterGuard(), bank = archive_repository.requireArchive(context);\n    const origin = core_context.captureTaskOrigin(context, bank.archiveRevision);\n    const resolved = await core_cache.resolveGenerationProgressTarget(context, shown, select);\n    if (!resolved) throw new Error('这项内容已经变化，请重新打开后编辑；没有修改其他版本。');\n    const expected = JSON.stringify(select(resolved.session));\n    const mutate = latest => {\n        if (JSON.stringify(select(latest)) !== expected) throw new Error('这项内容刚被更新，已保留最新内容，请重新打开后编辑。');\n        return mutator(latest);\n    };\n    const committed = resolved.draftId\n        ? await core_cache.commitGenerationTaskResultMutation(context, resolved.draftId, mutate, { expectedTaskOrigin: origin })\n        : await core_cache.commitSessionMutation(mode, core_context.getChatId(context), origin, mutate, resolved.session);\n    if (!committed) throw new Error('本次修改尚未保存，请重新打开这项内容后再试。');\n    if (runtimeState.activeSession === shown && core_context.isCurrentTaskOrigin(origin)) {\n        const next = structuredClone(committed);\n        if (shown.readableProgress?.explicitDraft && next.readableProgress) next.readableProgress.explicitDraft = true;\n        if (shown.generationSources) next.generationSources = structuredClone(shown.generationSources);\n        for (const key of ['selectedId','selectedEntryId','selectedStripId','view','page','dialogueIndex','sharedMemory']) {\n            if (Object.hasOwn(shown, key)) next[key] = structuredClone(shown[key]);\n        }\n        runtimeState.activeSession = next;\n    }\n    return committed;\n"
      },
      {
        "start": 1185,
        "remove": 1,
        "old": "        note.innerHTML = `<b>已生成部分内容 · 本次任务尚未完成</b><p>这里显示已收到的内容。后续失败或关闭页面，不会清除已保存部分；继续生成只补未完成部分。</p>`;\n",
        "new": "        note.innerHTML = `<b>已生成部分内容 · 本次任务尚未完成</b><p>这里显示已收到的内容。后续失败或关闭页面，不会清除已保存部分；继续生成只补未完成部分。</p>${!runtimeState.activeArchiveSnapshot ? '<button type=\"button\" class=\"rmt-btn\" data-rmt-edit-partial>编辑已生成内容</button>' : ''}`;\n"
      },
      {
        "start": 1352,
        "remove": 3,
        "old": "                runtimeState.activeSession = core_cache.loadSession(mode, { context, memoryBank: bank,\n",
        "new": "                runtimeState.activeSession = shownSession.readableProgress?.explicitDraft\n                    ? { ...committed, readableProgress: { ...committed.readableProgress, explicitDraft: true }, generationSources: shownSession.generationSources }\n                    : core_cache.loadSession(mode, { context, memoryBank: bank,\n"
      },
      {
        "start": 1451,
        "remove": 1,
        "old": "",
        "new": "    if (event.target.closest?.('[data-rmt-edit-partial]')) return ui_contentManager.renderPartialContentEditor();\n"
      }
    ]
  },
  "src/ui/recoveryView.js": {
    "beforeSha256": "1865bab12709235532ffeb641e0107bbfff460a4c8def532fd2663c24719c151",
    "afterSha256": "f14c73ce9cf2ef8a5f4873db0b5c3cb85d327cd1645a251c259e058455f747ce",
    "changes": [
      {
        "start": 30,
        "remove": 1,
        "old": "            return `<section class=\"rmt-recovery-status\" role=\"status\"><b>${text.esc(label)} · ${pending ? '成果已保存，等待选择去向' : row.status === 'open' ? '已保存部分成果，原草稿可继续' : '独立生成成果'}</b><p>按原资料生成，原资料出处随成果保留。</p><button type=\"button\" class=\"rmt-btn\" data-rmt-task-result-open=\"${text.esc(row.draftId)}\">查看已保存成果</button>${!readOnly && (pending || row.status === 'independent') ? ` <button type=\"button\" class=\"rmt-btn\" data-rmt-task-result-choose=\"${text.esc(row.draftId)}\">选择保存去向</button>` : ''}</section>`;\n",
        "new": "            return `<section class=\"rmt-recovery-status\" role=\"status\"><b>${text.esc(label)} · ${pending ? '成果已保存，等待选择去向' : row.status === 'open' ? '已保存部分成果，原草稿可继续' : '独立生成成果'}</b><p>按原资料生成，原资料出处随成果保留。</p><button type=\"button\" class=\"rmt-btn\" data-rmt-task-result-open=\"${text.esc(row.draftId)}\">${row.status === 'open' ? '打开已生成内容' : '查看已保存成果'}</button>${!readOnly && (pending || row.status === 'independent') ? ` <button type=\"button\" class=\"rmt-btn\" data-rmt-task-result-choose=\"${text.esc(row.draftId)}\">选择保存去向</button>` : ''}</section>`;\n"
      }
    ]
  }
};
const sha = value => createHash('sha256').update(value).digest('hex');
export function phase7ApprovedSource(path, value) {
    value = phase8ApprovedSource(path, value);
    const spec = phase7Deltas[path];
    if (!spec) return value;
    const raw = String(value), digest = sha(raw);
    if (digest === spec.beforeSha256) return raw;
    assert.equal(digest, spec.afterSha256, path + ' contains an unreviewed phase3 change (not an approved phase7 delta)');
    const lines = raw.match(/[^\n]*\n|[^\n]+$/g) || [];
    for (const part of [...spec.changes].reverse()) {
        assert.equal(lines.slice(part.start, part.start + part.remove).join(''), part.new, 'phase7 approved hunk differs');
        lines.splice(part.start, part.remove, ...(part.old.match(/[^\n]*\n|[^\n]+$/g) || []));
    }
    const restored = lines.join('');
    assert.equal(sha(restored), spec.beforeSha256, 'phase7 inverse differs from delivered baseline');
    return restored;
}
