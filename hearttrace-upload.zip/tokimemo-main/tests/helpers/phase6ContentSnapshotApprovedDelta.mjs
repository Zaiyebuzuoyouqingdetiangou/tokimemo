// Exact approved phase6 delta. Preserve all prior phase3/historical checks.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
export const phase6ContentSnapshotDeltas = {
  "src/generation/client.js": {
    "beforeSha256": "ee172f5bffd4275abce46913f71d4ed78789c706172c26b6ce4c2ef17f2a9f16",
    "afterSha256": "49fc14cbffd7d3c46583f950c2de32d406913ceb35549062ae99c8f9642dcb93",
    "changes": [
      {
        "start": 122,
        "remove": 6,
        "old": "    return { version: 1, fields, cardFields, memoryBank: structuredClone(bank),\n",
        "new": "    // Archive import checkpoints retain their own source material in the original\n    // bank. Derived content needs the archive facts, not another copy of that log.\n    const memoryBank = structuredClone(bank);\n    delete memoryBank.archiveImportProgress;\n    delete memoryBank.archiveImportPaused;\n    return { version: 1, fields, cardFields, memoryBank,\n"
      }
    ]
  }
};
const sha = value => createHash('sha256').update(value).digest('hex');
export function phase6ContentSnapshotApprovedSource(path, value) {
    const spec = phase6ContentSnapshotDeltas[path];
    if (!spec) return value;
    const raw = String(value), digest = sha(raw);
    if (digest === spec.beforeSha256) return raw;
    assert.equal(digest, spec.afterSha256, path + ' contains an unreviewed phase3 change (not an approved phase6 delta)');
    const lines = raw.match(/[^\n]*\n|[^\n]+$/g) || [];
    for (const part of [...spec.changes].reverse()) {
        assert.equal(lines.slice(part.start, part.start + part.remove).join(''), part.new, 'phase6 approved hunk differs');
        lines.splice(part.start, part.remove, ...(part.old.match(/[^\n]*\n|[^\n]+$/g) || []));
    }
    const restored = lines.join('');
    assert.equal(sha(restored), spec.beforeSha256, 'phase6 inverse differs from delivered baseline');
    return restored;
}
