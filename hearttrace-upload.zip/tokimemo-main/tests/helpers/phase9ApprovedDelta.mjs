import { phase10ApprovedSource } from './phase10ApprovedDelta.mjs';
// Exact approved phase9 delta; prior approved bytes and contracts remain pinned.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
export const phase9Deltas = {
  "src/archive/library.js": {
    "beforeSha256": "7fbc4de6cf8df964d13ea7bcfe8de4a92a9db68ca1857bac5890d658673a941e",
    "afterSha256": "6e6a7306f388d9a4f9ce4531d9db0ab425b37b35302d1fdaf1220b53d31ce078",
    "changes": [
      {
        "start": 23,
        "remove": 1,
        "old": "",
        "new": "import * as host_compatibility from '../core/hostCompatibility.js';\n"
      },
      {
        "start": 1057,
        "remove": 8,
        "old": "",
        "new": "    const controller = new AbortController();\n    const lifecycleEpoch = runtimeState.runtimeLifecycleEpoch;\n    let cancelled = false, failedReads = 0;\n    const cancelScan = event => {\n        if (event.target.closest?.('[data-rmt-cancel-legacy-scan]')) controller.abort();\n    };\n    const scanStillCurrent = () => lifecycleEpoch === runtimeState.runtimeLifecycleEpoch;\n    body?.addEventListener('click', cancelScan);\n"
      },
      {
        "start": 1066,
        "remove": 1,
        "old": "",
        "new": "    try {\n"
      },
      {
        "start": 1069,
        "remove": 1,
        "old": "        if (body) body.innerHTML = `<div class=\"rmt-loading\"><div class=\"rmt-loading-card\"><b>正在扫描旧档案 ${i + 1} / ${avatarEntries.length}</b><div class=\"rmt-loading-note\">同头像只读取一次聊天列表；能唯一匹配角色卡时记录本地指纹，无法唯一判断时保持待手动分类。不会切换宿主聊天。</div></div></div>`;\n",
        "new": "        if (body) body.innerHTML = `<div class=\"rmt-loading\"><div class=\"rmt-loading-card\"><b>正在扫描旧档案 ${i + 1} / ${avatarEntries.length}</b><div class=\"rmt-loading-note\">同头像只读取一次聊天列表；旧酒馆按需只读聊天文件。能唯一匹配角色卡时记录本地指纹，无法唯一判断时保持待手动分类。不会切换宿主聊天。</div><div data-rmt-legacy-scan-progress role=\"status\"></div><button type=\"button\" class=\"rmt-btn\" data-rmt-cancel-legacy-scan>停止扫描</button></div></div>`;\n"
      },
      {
        "start": 1071,
        "remove": 3,
        "old": "            const response = await fetch('/api/characters/chats', { method:'POST', headers:context.getRequestHeaders(), cache:'no-cache', body:JSON.stringify({ avatar_url:avatar, metadata:true }) });\n            if (!response.ok) continue;\n",
        "new": "            if (controller.signal.aborted || !scanStillCurrent()) throw new DOMException('Archive scan cancelled', 'AbortError');\n            const response = await fetch('/api/characters/chats', { method:'POST', headers:context.getRequestHeaders(), cache:'no-cache', signal:controller.signal, body:JSON.stringify({ avatar_url:avatar, metadata:true }) });\n            if (!response.ok) { failedReads++; continue; }\n"
      },
      {
        "start": 1075,
        "remove": 16,
        "old": "            for (const row of Array.isArray(rows) ? rows : []) {\n",
        "new": "            const listedRows = Array.isArray(rows) ? rows : [];\n            if (!Array.isArray(rows)) failedReads++;\n            for (let rowIndex = 0; rowIndex < listedRows.length; rowIndex++) {\n                const progress = body?.querySelector('[data-rmt-legacy-scan-progress]');\n                if (progress) progress.textContent = `聊天 ${rowIndex + 1} / ${listedRows.length}`;\n                let row;\n                try {\n                    row = await host_compatibility.readArchiveRowMetadata(context, avatar, listedRows[rowIndex], {\n                        signal: controller.signal, isCurrent: scanStillCurrent,\n                    });\n                } catch (error) {\n                    if (error?.name === 'AbortError') throw error;\n                    failedReads++;\n                    console.warn('[HeartbeatMemories] legacy archive chat read failed', core_text.safeErrorDiagnostic(error));\n                    continue;\n                }\n"
      },
      {
        "start": 1122,
        "remove": 2,
        "old": "",
        "new": "            if (error?.name === 'AbortError') { cancelled = true; break; }\n            failedReads++;\n"
      },
      {
        "start": 1128,
        "remove": 4,
        "old": "",
        "new": "    } finally {\n        body?.removeEventListener('click', cancelScan);\n    }\n    if (!scanStillCurrent()) return;\n"
      },
      {
        "start": 1142,
        "remove": 3,
        "old": "    globalThis.toastr?.success?.(`旧档案扫描完成：索引 ${found.length} 个聊天档案。无法唯一判断的同头像/同名旧档案已单独列为“待手动分类”。`, '心迹回廊');\n",
        "new": "    const scanMessage = `旧档案扫描${cancelled ? '已停止' : failedReads ? '部分完成' : '完成'}：索引 ${found.length} 个聊天档案。${failedReads ? `有 ${failedReads} 处读取失败，可再次手动扫描；` : ''}${cancelled ? '已保留读到的索引和原有索引；' : ''}无法唯一判断的同头像/同名旧档案已单独列为“待手动分类”。`;\n    if (cancelled || failedReads) globalThis.toastr?.warning?.(scanMessage, '心迹回廊');\n    else globalThis.toastr?.success?.(scanMessage, '心迹回廊');\n"
      }
    ]
  },
  "src/archive/repository.js": {
    "beforeSha256": "728a01789d6445738fccfea17a46bf541b4ed87bf1fa45bf19a36be14d8b01ad",
    "afterSha256": "861a28426f891a4661b16c5b632b1ff8c8697a1b188b1eab48cae0fd6e8efe66",
    "changes": [
      {
        "start": 12,
        "remove": 1,
        "old": "",
        "new": "import * as host_compatibility from '../core/hostCompatibility.js';\n"
      },
      {
        "start": 361,
        "remove": 5,
        "old": "    const rawNames = typeof context.getWorldInfoNames === 'function' ? await sourceGuard.boundedSourceRead(() => context.getWorldInfoNames(), signal) : [];\n",
        "new": "    // Old hosts could already read an explicitly selected book by name. Adding the\n    // interactive list adapter must not make that existing path depend on listing.\n    const validateListedName = typeof context.getWorldInfoNames === 'function'\n        && !host_compatibility.isAdaptedWorldInfoNameReader(context.getWorldInfoNames);\n    const rawNames = validateListedName ? await sourceGuard.boundedSourceRead(() => context.getWorldInfoNames(), signal) : [];\n"
      },
      {
        "start": 369,
        "remove": 1,
        "old": "    if (!name || (typeof context.getWorldInfoNames === 'function' && !names.includes(name))) throw new Error('所选世界书已经不存在，或当前 SillyTavern 无法读取。');\n",
        "new": "    if (!name || (validateListedName && !names.includes(name))) throw new Error('所选世界书已经不存在，或当前 SillyTavern 无法读取。');\n"
      }
    ]
  },
  "src/core/context.js": {
    "beforeSha256": "65b62fba3903eb4bb7046bb75b2d03bc81508ceb3a164c921a8d92a256ad0cd3",
    "afterSha256": "52885dfd81bb58bad5243641540735ff62172db5b15798e065efe01bbbb7efdf",
    "changes": [
      {
        "start": 10,
        "remove": 3,
        "old": "",
        "new": "import * as host_compatibility from './hostCompatibility.js';\n\nconst adaptHostContext = host_compatibility.createHostContextAdapter({ getEpoch: () => runtimeState.runtimeLifecycleEpoch });\n"
      },
      {
        "start": 17,
        "remove": 1,
        "old": "    return context;\n",
        "new": "    return adaptHostContext(context);\n"
      }
    ]
  },
  "src/core/independentApi.js": {
    "beforeSha256": "1b6f8651ead5de2b4dca808cc0126abd16a6951fb57b5fe32aa1c6bfea83ea7d",
    "afterSha256": "9678123e3a2aad695cd0325e84a6112ead4d7878d695f2a3878e9fb60ac6b199",
    "changes": [
      {
        "start": 8,
        "remove": 1,
        "old": "export const PROFILE_ONE_CLICK_UI_VERSION = '1.1.18';\n",
        "new": "export const PROFILE_ONE_CLICK_UI_VERSION = '凭证绑定';\n"
      },
      {
        "start": 49,
        "remove": 1,
        "old": "        `一键配置要求 ${PROFILE_ONE_CLICK_UI_VERSION} 的 Connection Manager 能力。当前页面未提供安全的 Profile Secret 与模型覆盖能力；本次没有发送请求。`,\n",
        "new": "        '当前酒馆没有一键配置所需的配置与密钥绑定能力（Profile Secret）或模型覆盖能力。请使用手动独立 API，填写地址、密钥和模型；不会改动主聊天连接。本次没有发送请求。',\n"
      }
    ]
  },
  "src/core/participants.js": {
    "beforeSha256": "eb3dfdd3c7c5d4dbf896274d1b7728ab830a51d2cbba0bb21f0efee435352431",
    "afterSha256": "945617d2fa2f4ab37769957f3a184a2b5c68d5a2de00d93d2b8afac0810847c9",
    "changes": [
      {
        "start": 49,
        "remove": 1,
        "old": "",
        "new": "            ...(person.identity === 'user' ? { identity: 'user' } : {}),\n"
      }
    ]
  },
  "src/core/settings.js": {
    "beforeSha256": "3cc8068f8e6233e2077ac6462323fac39eed797d31a040957af7c3739506e4b9",
    "afterSha256": "046c917b5cdcc801a699ab394031340242fdab03cd7c39150a05bcdfa45c9011",
    "changes": [
      {
        "start": 458,
        "remove": 9,
        "old": "",
        "new": "export function oneClickConnectionCapability(context = core_context.getContext()) {\n    try {\n        core_independentApi.assertConnectionManagerProfileSupport(context.ConnectionManagerRequestService);\n        return { available: true, message: '当前酒馆支持配置与密钥绑定，可使用一键连接或手动独立 API。' };\n    } catch (error) {\n        return { available: false, message: error.safeUserMessage || '当前酒馆不支持凭证绑定，请使用手动独立 API。' };\n    }\n}\n\n"
      }
    ]
  },
  "src/generation/cgAppearance.js": {
    "beforeSha256": "26ccf8f03397a709562b96c821e75114509b8e03dda9970139d6a00330784947",
    "afterSha256": "a3e6e439d9be64bbdebc6d7240da3a0e5e1fd00cee5c13c607ec00ef94fc73a7",
    "changes": [
      {
        "start": 34,
        "remove": 28,
        "old": "    const filtered = context_tags.filterContextTags(value, context_tags.tagPolicyForContext(context));\n    return plain(filtered, filtered.length);\n",
        "new": "    // These entries were explicitly selected as person settings. Chat-body tag\n    // selection must not erase their XML-wrapped descriptions.\n    const unwrapped = value.replace(/&(?:amp;)*(lt;|gt;|#0*60;|#0*62;|#x0*3c;|#x0*3e;)/gi,\n        (_, entity) => /^(lt;|#0*60;|#x0*3c;)$/i.test(entity) ? '<' : '>').replace(/<[^>]*>/g, ' ');\n    return plain(unwrapped, unwrapped.length);\n}\n\nfunction userPersona(context) {\n    let card = {};\n    try { card = context?.getCharacterCardFields?.() || {}; } catch {}\n    return typeof card.persona === 'string' && card.persona.trim() ? card.persona\n        : typeof context?.powerUserSettings?.persona_description === 'string' ? context.powerUserSettings.persona_description : '';\n}\n\nexport function createCgUserParticipant(context, existingPeople = []) {\n    const ids = new Set(existingPeople.map(person => person.id));\n    let id = 'rmt-current-user', suffix = 0;\n    while (ids.has(id)) id = `rmt-current-user-${++suffix}`;\n    const content = userPersona(context);\n    return { id, name: String(context?.name1 || ''), identity: 'user',\n        sourceRefs: content ? [{ world: '用户人设', uid: 'persona', title: String(context?.name1 || '用户'), content }] : [] };\n}\n\nfunction participantAppearanceSource(person, context) {\n    const sources = person.sourceRefs.map(ref => participantSourceText(ref.content, context)).filter(Boolean);\n    // An explicit user identity is required; equal names never imply user identity.\n    if (!person.sourceRefs.length && person.identity === 'user') sources.push(participantSourceText(userPersona(context), context));\n    return sources.join('\\n');\n"
      },
      {
        "start": 83,
        "remove": 1,
        "old": "                description: plain(known?.tag, CG_APPEARANCE_TAG_LIMIT) ? '' : person.sourceRefs.map(ref => participantSourceText(ref.content, context)).filter(Boolean).join('\\n'),\n",
        "new": "                description: plain(known?.tag, CG_APPEARANCE_TAG_LIMIT) ? '' : participantAppearanceSource(person, context),\n"
      },
      {
        "start": 304,
        "remove": 1,
        "old": "                ? (evidence.castSnapshot.people.find(person => person.id === row.participantId)?.sourceRefs || [])\n                    .map(ref => participantSourceText(ref.content, context)).filter(Boolean).join('\\n')\n",
        "new": "                ? participantAppearanceSource(evidence.castSnapshot.people.find(person => person.id === row.participantId), context)\n"
      }
    ]
  },
  "src/ui/cgPromptEditor.js": {
    "beforeSha256": "8e4fb1c41f1f4450bacec8613b094f6ad9a43f752844bb2531d6c45fb35a6126",
    "afterSha256": "ccea67353d411633fb38b588c37c77f4e366d77aedd70f7531efdf2ed6fa4016",
    "changes": [
      {
        "start": 11,
        "remove": 1,
        "old": "",
        "new": "import * as participant_picker from './participantPicker.js';\n"
      },
      {
        "start": 23,
        "remove": 3,
        "old": "    return { promptFormat: current.promptFormat, scene: current.element.querySelector('[data-rmt-cg-prompt-input]').value, metadata: editorMetadata(current) };\n",
        "new": "    const metadata = editorMetadata(current);\n    return { promptFormat: current.promptFormat, scene: current.element.querySelector('[data-rmt-cg-prompt-input]').value, metadata,\n        ...(current.multi ? { people: structuredClone(current.people) } : {}) };\n"
      },
      {
        "start": 39,
        "remove": 1,
        "old": "",
        "new": "    if (previous.sourcePickerOpen) participant_picker.closeParticipantPicker();\n"
      },
      {
        "start": 59,
        "remove": 1,
        "old": "    for (const button of editor.element.querySelectorAll('[data-rmt-cg-prompt-action=\"reconceive\"], [data-rmt-cg-prompt-action=\"draw\"], [data-rmt-cg-prompt-action=\"clear\"], [data-rmt-cg-prompt-action=\"retry\"], [data-rmt-cg-prompt-action=\"save-looks\"], [data-rmt-cg-prompt-action=\"restore-draft\"], [data-rmt-cg-prompt-action=\"add-person\"], [data-rmt-cg-prompt-action=\"add-user\"], [data-rmt-cg-prompt-action=\"use-current-cast\"]')) button.disabled = active;\n",
        "new": "    for (const button of editor.element.querySelectorAll('[data-rmt-cg-prompt-action=\"reconceive\"], [data-rmt-cg-prompt-action=\"draw\"], [data-rmt-cg-prompt-action=\"clear\"], [data-rmt-cg-prompt-action=\"retry\"], [data-rmt-cg-prompt-action=\"save-looks\"], [data-rmt-cg-prompt-action=\"restore-draft\"], [data-rmt-cg-prompt-action=\"add-person\"], [data-rmt-cg-prompt-action=\"add-user\"], [data-rmt-cg-prompt-action=\"use-current-cast\"], [data-rmt-cg-prompt-action=\"select-sources\"]')) button.disabled = active;\n"
      },
      {
        "start": 73,
        "remove": 11,
        "old": "",
        "new": "function ensureUserCandidate(current) {\n    let user = current.people.find(person => person.identity === 'user');\n    if (user) return user;\n    const context = core_context.currentCharacterGuard();\n    user = appearance.createCgUserParticipant(context, current.people);\n    const saved = cast_looks.readParticipantLooks(context)?.characters.find(row => row.participantId === user.id);\n    user = { ...user, selected: false, tag: saved?.tag || cast_looks.readCastLooks(context)?.user || '', nl: saved?.nl || '' };\n    current.people.push(user);\n    return user;\n}\n\n"
      },
      {
        "start": 90,
        "remove": 1,
        "old": "      <small>${core_text.esc(person.sourceRefs.length ? person.sourceRefs.map(ref => `${ref.world} · ${ref.title || ref.uid}`).join('；') : '手动补充的人物')}</small>\n",
        "new": "      <small>${core_text.esc(person.identity === 'user' && !person.sourceRefs.length ? '当前用户人设' : person.sourceRefs.length ? person.sourceRefs.map(ref => `${ref.world} · ${ref.title || ref.uid}`).join('；') : '手动补充的人物')}</small>\n"
      },
      {
        "start": 120,
        "remove": 1,
        "old": "    return multi ? '<fieldset data-rmt-cg-cast><legend>本图出镜人物</legend><p>勾选只影响这张图。姓名可改，也可补充档案名单外的人物；同名人物独立保存。</p><div data-rmt-cg-cast-list></div><button type=\"button\" class=\"rmt-btn\" data-rmt-cg-prompt-action=\"add-person\">补充人物</button><button type=\"button\" class=\"rmt-btn\" data-rmt-cg-prompt-action=\"add-user\">添加用户为候选</button></fieldset>' : `<p><label for=\"rmt-cg-char-tags\" data-rmt-cg-tag-name=\"char\">角色 · 外貌 tag</label><textarea id=\"rmt-cg-char-tags\" data-rmt-cg-tag-input=\"char\" rows=\"2\" maxlength=\"${appearance.CG_APPEARANCE_TAG_LIMIT}\" placeholder=\"重新构思时提取，或手动填写\"></textarea></p>\n",
        "new": "    return multi ? '<fieldset data-rmt-cg-cast><legend>本图出镜人物</legend><p>勾选只影响这张图。姓名可改，也可补充档案名单外的人物；同名人物独立保存。</p><div data-rmt-cg-cast-list></div><button type=\"button\" class=\"rmt-btn\" data-rmt-cg-prompt-action=\"add-person\">补充人物</button><button type=\"button\" class=\"rmt-btn\" data-rmt-cg-prompt-action=\"add-user\">定位用户候选</button><button type=\"button\" class=\"rmt-btn\" data-rmt-cg-prompt-action=\"select-sources\">重新选择外貌来源</button></fieldset>' : `<p><label for=\"rmt-cg-char-tags\" data-rmt-cg-tag-name=\"char\">角色 · 外貌 tag</label><textarea id=\"rmt-cg-char-tags\" data-rmt-cg-tag-input=\"char\" rows=\"2\" maxlength=\"${appearance.CG_APPEARANCE_TAG_LIMIT}\" placeholder=\"重新构思时提取，或手动填写\"></textarea></p>\n"
      },
      {
        "start": 143,
        "remove": 1,
        "old": "            castSnapshot: { version: 1, people: selected.map(({ id, name, sourceRefs }) => ({ id, name, sourceRefs })) },\n",
        "new": "            castSnapshot: { version: 1, people: selected.map(({ id, name, sourceRefs, identity }) => ({ id, name, sourceRefs, ...(identity === 'user' ? { identity } : {}) })) },\n"
      },
      {
        "start": 204,
        "remove": 1,
        "old": "",
        "new": "        ensureUserCandidate(current);\n"
      },
      {
        "start": 338,
        "remove": 3,
        "old": "            current.people.push({ id: participants.createParticipantId(), name: action === 'add-user' ? String(context.name1 || '') : '',\n                sourceRefs: [], selected: false,\n                tag: action === 'add-user' ? cast_looks.readCastLooks(context)?.user || '' : '' });\n",
        "new": "            const person = action === 'add-user' ? ensureUserCandidate(current)\n                : { id: participants.createParticipantId(), name: '', sourceRefs: [], selected: false, tag: '', nl: '' };\n            if (action !== 'add-user') current.people.push(person);\n"
      },
      {
        "start": 342,
        "remove": 29,
        "old": "            current.element.querySelector(`[data-rmt-cg-person-name=\"${current.people.length - 1}\"]`).focus();\n",
        "new": "            current.element.querySelector(`[data-rmt-cg-person-name=\"${current.people.indexOf(person)}\"]`).focus();\n            return;\n        }\n        if (current.multi && action === 'select-sources') {\n            readParticipantFields(current);\n            const previous = snapshotEditorDraft(current);\n            const beforePeople = structuredClone(current.people);\n            const context = core_context.currentCharacterGuard();\n            current.sourcePickerOpen = true;\n            await participant_picker.showParticipantPicker({ context,\n                title: '重新选择本图人物外貌来源', confirmLabel: '应用到本图草稿',\n                roster: { version: 1, cardType: 'multi', revision: '',\n                    people: current.people, selectedIds: current.people.filter(person => person.selected).map(person => person.id) },\n                onConfirm: snapshot => {\n                    if (editor !== current || !current.element.isConnected) return false;\n                    images.assertCgImageTargetCurrent(current.target);\n                    const old = new Map(beforePeople.map(person => [person.id, person]));\n                    const selected = new Set(snapshot.selectedIds);\n                    rememberEditorDraft(current, previous);\n                    current.people = snapshot.people.map(person => ({ ...person, selected: selected.has(person.id),\n                        tag: old.get(person.id)?.tag || '', nl: old.get(person.id)?.nl || '' }));\n                    ensureUserCandidate(current);\n                    renderParticipantFields(current);\n                    invalidateFlatPrompt(current);\n                    updatePreparedPreview(current);\n                    current.sourcePickerOpen = false;\n                    current.element.querySelector('[data-rmt-cg-prompt-status]').textContent = '本图来源已更新；原图、档案名单和已保存外貌未改动。点击重新构思后才提取外貌。';\n                    return true;\n                } });\n"
      },
      {
        "start": 397,
        "remove": 1,
        "old": "",
        "new": "            if (draft.people) current.people = structuredClone(draft.people);\n"
      }
    ]
  },
  "src/ui/recoveryView.js": {
    "beforeSha256": "f14c73ce9cf2ef8a5f4873db0b5c3cb85d327cd1645a251c259e058455f747ce",
    "afterSha256": "96422b6e3198ea0241e6a8613f0f6b6b209f60dcdc2ca4269c6cdca8da912934",
    "changes": [
      {
        "start": 25,
        "remove": 1,
        "old": "            return `<section class=\"rmt-recovery-status\" role=\"status\"><b>${text.esc(pageLabel)} · 已保留 ${summary.completed} 个成功分段</b><p>${text.esc(new Date(row.createdAt).toLocaleString())} · ${text.esc(reason.replace(/[。\\s]+$/, ''))}。继续只补这份草稿未完成的内容，会使用生成额度。</p><button type=\"button\" class=\"rmt-btn\" data-rmt-recovery-mode=\"${text.esc(row.mode)}\" ${attrs}>${label}</button>${childReader} <button type=\"button\" class=\"rmt-btn\" data-rmt-recovery-export=\"${text.esc(row.mode)}\" ${attrs}>导出未提交草稿</button> <button type=\"button\" class=\"rmt-btn\" data-rmt-recovery-discard=\"${text.esc(row.mode)}\" ${attrs}>放弃这份草稿</button></section>`;\n",
        "new": "            return `<section class=\"rmt-recovery-status\" role=\"status\"><b>${text.esc(pageLabel)} · 已保留 ${summary.completed} 个成功分段</b><p>${text.esc(new Date(row.createdAt).toLocaleString())} · ${text.esc(reason.replace(/[。\\s]+$/, ''))}。继续只补这份草稿未完成的内容，会使用生成额度。</p><div class=\"rmt-recovery-actions\"><button type=\"button\" class=\"rmt-btn\" data-rmt-recovery-mode=\"${text.esc(row.mode)}\" ${attrs}>${label}</button>${childReader} <button type=\"button\" class=\"rmt-btn\" data-rmt-recovery-export=\"${text.esc(row.mode)}\" ${attrs}>导出未提交草稿</button> <button type=\"button\" class=\"rmt-btn\" data-rmt-recovery-discard=\"${text.esc(row.mode)}\" ${attrs}>放弃这份草稿</button></div></section>`;\n"
      },
      {
        "start": 30,
        "remove": 1,
        "old": "            return `<section class=\"rmt-recovery-status\" role=\"status\"><b>${text.esc(label)} · ${pending ? '成果已保存，等待选择去向' : row.status === 'open' ? '已保存部分成果，原草稿可继续' : '独立生成成果'}</b><p>按原资料生成，原资料出处随成果保留。</p><button type=\"button\" class=\"rmt-btn\" data-rmt-task-result-open=\"${text.esc(row.draftId)}\">${row.status === 'open' ? '打开已生成内容' : '查看已保存成果'}</button>${!readOnly && (pending || row.status === 'independent') ? ` <button type=\"button\" class=\"rmt-btn\" data-rmt-task-result-choose=\"${text.esc(row.draftId)}\">选择保存去向</button>` : ''}</section>`;\n",
        "new": "            return `<section class=\"rmt-recovery-status\" role=\"status\"><b>${text.esc(label)} · ${pending ? '成果已保存，等待选择去向' : row.status === 'open' ? '已保存部分成果，原草稿可继续' : '独立生成成果'}</b><p>按原资料生成，原资料出处随成果保留。</p><div class=\"rmt-recovery-actions\"><button type=\"button\" class=\"rmt-btn\" data-rmt-task-result-open=\"${text.esc(row.draftId)}\">${row.status === 'open' ? '打开已生成内容' : '查看已保存成果'}</button>${!readOnly && (pending || row.status === 'independent') ? ` <button type=\"button\" class=\"rmt-btn\" data-rmt-task-result-choose=\"${text.esc(row.draftId)}\">选择保存去向</button>` : ''}</div></section>`;\n"
      },
      {
        "start": 43,
        "remove": 1,
        "old": "        return `<section class=\"rmt-recovery-status\" role=\"status\"><b>${text.esc(constants.MODE_LABEL[mode] || mode)} · 已保留 ${summary.completed} 个成功分段</b><p>上次记录：${text.esc(reason.replace(/[。\\s]+$/, ''))}。继续会使用生成额度。</p><button type=\"button\" class=\"rmt-btn\" data-rmt-recovery-mode=\"${text.esc(mode)}\">${label}</button> <button type=\"button\" class=\"rmt-btn\" data-rmt-recovery-export=\"${text.esc(mode)}\">导出未提交草稿</button> <button type=\"button\" class=\"rmt-btn\" data-rmt-recovery-discard=\"${text.esc(mode)}\">放弃未提交草稿</button></section>`;\n",
        "new": "        return `<section class=\"rmt-recovery-status\" role=\"status\"><b>${text.esc(constants.MODE_LABEL[mode] || mode)} · 已保留 ${summary.completed} 个成功分段</b><p>上次记录：${text.esc(reason.replace(/[。\\s]+$/, ''))}。继续会使用生成额度。</p><div class=\"rmt-recovery-actions\"><button type=\"button\" class=\"rmt-btn\" data-rmt-recovery-mode=\"${text.esc(mode)}\">${label}</button> <button type=\"button\" class=\"rmt-btn\" data-rmt-recovery-export=\"${text.esc(mode)}\">导出未提交草稿</button> <button type=\"button\" class=\"rmt-btn\" data-rmt-recovery-discard=\"${text.esc(mode)}\">放弃未提交草稿</button></div></section>`;\n"
      },
      {
        "start": 50,
        "remove": 1,
        "old": "    if (summary.onlyArchivedDrafts) return `<section class=\"rmt-recovery-status\"><p>${text.esc(summary.notice)}</p>${draftLinks}</section>`;\n",
        "new": "    if (summary.onlyArchivedDrafts) return `<section class=\"rmt-recovery-status\"><p>${text.esc(summary.notice)}</p><div class=\"rmt-recovery-actions\">${draftLinks}</div></section>`;\n"
      },
      {
        "start": 57,
        "remove": 1,
        "old": "    return `<section class=\"rmt-recovery-status\" role=\"status\"><b>${text.esc(heading)}</b><p>${text.esc(summary.notice)}</p>${summary.failureCode ? `<p>${text.esc(text.safeErrorSummary({ code: summary.failureCode }))}</p>` : ''}${draftLinks}\n",
        "new": "    return `<section class=\"rmt-recovery-status\" role=\"status\"><b>${text.esc(heading)}</b><p>${text.esc(summary.notice)}</p>${summary.failureCode ? `<p>${text.esc(text.safeErrorSummary({ code: summary.failureCode }))}</p>` : ''}<div class=\"rmt-recovery-actions\">${draftLinks}\n"
      },
      {
        "start": 62,
        "remove": 1,
        "old": "${!batch ? '<button type=\"button\" class=\"rmt-btn\" data-rmt-archive-discard>放弃整理草稿</button>' : ''}</section>`;\n",
        "new": "${!batch ? '<button type=\"button\" class=\"rmt-btn\" data-rmt-archive-discard>放弃整理草稿</button>' : ''}</div></section>`;\n"
      }
    ]
  },
  "src/ui/settingsPanel.js": {
    "beforeSha256": "8050f0336d42571818cdd14c0941d608da188aec083326c9f06c72bd18f9ab8e",
    "afterSha256": "432d440fd840c2814c9f17d2b1a5e0dfff3d137844b8ca9c87dc70b487510fe8",
    "changes": [
      {
        "start": 375,
        "remove": 2,
        "old": "",
        "new": "    const capability = panel.querySelector('[data-rmt-api-host-capability]');\n    if (capability) capability.textContent = core_settings.oneClickConnectionCapability().message;\n"
      },
      {
        "start": 477,
        "remove": 1,
        "old": "            : settings.connectionProfileId ? '需要 1.1.18 能力' : '一键连接未配置'}`;\n",
        "new": "            : settings.connectionProfileId ? '需凭证绑定能力，可改用手动配置' : '一键连接未配置'}`;\n"
      },
      {
        "start": 597,
        "remove": 1,
        "old": "          <summary class=\"rmt-settings-card-head\"><span>API</span><div><b>独立 API</b><small>1.1.18 一键配置 · 手动配置</small></div></summary>\n",
        "new": "          <summary class=\"rmt-settings-card-head\"><span>API</span><div><b>独立 API</b><small>一键配置 · 手动配置</small></div></summary>\n"
      },
      {
        "start": 600,
        "remove": 1,
        "old": "            <button type=\"button\" class=\"menu_button rmt-api-source-card\" data-rmt-api-import-current aria-pressed=\"false\"><span class=\"rmt-api-source-badge\">要求</span><b>1.1.18 一键配置</b><small>读取酒馆当前连接</small></button>\n",
        "new": "            <button type=\"button\" class=\"menu_button rmt-api-source-card\" data-rmt-api-import-current aria-pressed=\"false\"><span class=\"rmt-api-source-badge\">凭证绑定</span><b>一键配置</b><small>读取酒馆当前连接</small></button>\n"
      },
      {
        "start": 603,
        "remove": 1,
        "old": "",
        "new": "          <div data-rmt-api-host-capability role=\"status\"></div>\n"
      }
    ]
  },
  "src/ui/styles.js": {
    "beforeSha256": "e76d8d5298670ab83e14ddecf27d0883fd44739153de95567ad43d681676526f",
    "afterSha256": "d7cd14cb0d1f0fd053249a89d04d65ec0707621a76a10e242cd9001c909dece1",
    "changes": [
      {
        "start": 185,
        "remove": 1,
        "old": "",
        "new": "    style.textContent += ui_workspaceStyles.capsuleCss('#' + core_constants.OVERLAY_ID);\n"
      },
      {
        "start": 1144,
        "remove": 1,
        "old": "",
        "new": "    style.textContent += ui_workspaceStyles.capsuleCss('#' + core_constants.OVERLAY_ID);\n"
      }
    ]
  },
  "src/ui/workspaceStyles.js": {
    "beforeSha256": "7f2ebc67b6d4dad5782a70f309d67bb8d0bbcea5c99beb34cf6eaf53234f93b3",
    "afterSha256": "4e6cd850640bb6e52f7ed3eb3df85b9b24b8d1449d6080e934c4ef3e26f301ac",
    "changes": [
      {
        "start": 218,
        "remove": 30,
        "old": "",
        "new": "\n\n// Layout only. Keep full labels and existing actions, including modal controls\n// outside .rmt-body. This runs after theme/component styles to avoid conflicts.\nexport function capsuleCss(root = '#heartbeat_memories_overlay') {\n    const r = root + '.rmt-workspace[data-rmt-theme-mode]';\n    const groups = ':is(.rmt-recovery-actions,.rmt-actions,.rmt-mode-actions,.rmt-filter,.rmt-cg-card-actions,.rmt-cg-prompt-actions,.rmt-cg-prompt-secondary,.rmt-manage-actions,.rmt-manage-category-actions,.rmt-mail-actions,.rmt-mail-filters,.rmt-heart-top-actions,.rmt-heart-summary-actions,.rmt-room-heading-actions,.rmt-room-location-actions,.rmt-dialogue-actions,.rmt-loading-actions,.rmt-travel-dialogue-actions,.rmt-ending-confession-actions,.rmt-ending-easter-controls,.rmt-current-archive-actions)';\n    return `\n${r} .rmt-btn,${r} .rmt-body button.rmt-btn{display:inline-flex;align-items:center!important;justify-content:center!important;gap:6px;box-sizing:border-box!important;min-width:0;max-width:100%;min-height:44px!important;height:auto!important;padding:10px 14px!important;margin:0!important;border-radius:24px!important;font-family:inherit!important;font-size:15px!important;line-height:1.4!important;letter-spacing:normal!important;white-space:normal!important;word-break:normal;overflow-wrap:anywhere;text-align:center;vertical-align:middle;touch-action:manipulation}\n${r} .rmt-btn>i,${r} .rmt-btn>svg{flex-shrink:0}\n${r} .rmt-btn[hidden]{display:none!important}\n${r} ${groups}{display:flex;align-items:stretch;justify-content:flex-start;flex-wrap:wrap;gap:8px;min-width:0;max-width:100%}\n${r} ${groups}>.rmt-btn{flex:0 1 auto;width:auto;min-width:0;max-width:100%}\n${r} :is(.rmt-recovery-actions,.rmt-cg-prompt-actions)>.rmt-btn{flex:1 1 auto;width:auto!important}\n${r} .rmt-recovery-actions{margin-top:12px}\n${r} .rmt-cg-prompt-secondary>small{flex-basis:100%}\n${r} :is(.rmt-participant-dialog,.rmt-cg-prompt-dialog) .rmt-btn{color:var(--rmt-theme-text);background:var(--rmt-theme-surface-solid);border:1px solid var(--rmt-theme-border)}\n${r} .rmt-participant-dialog footer{justify-content:flex-end;gap:8px}\n${r} :is(.rmt-workspace-tabs,.rmt-workspace-groups,.rmt-layout-switch) button{box-sizing:border-box;max-width:100%;min-width:0;line-height:1.4;white-space:normal;word-break:normal;overflow-wrap:anywhere;text-align:center}\n${r} :is(.rmt-filter,.rmt-workspace-groups) button{flex:0 1 auto}\n${r} .rmt-layout-switch{flex-wrap:wrap;max-width:100%}\n${r} .rmt-btn:focus-visible{outline:2px solid var(--rmt-theme-accent-ink);outline-offset:3px}\n@media(max-width:600px){\n ${r} .rmt-body .rmt-current-archive-actions{display:flex!important;gap:8px}\n ${r} .rmt-body .rmt-current-archive-actions>.rmt-btn{flex:1 1 144px;width:auto!important}\n ${r} .rmt-body :is(.rmt-travel-dialogue-actions,.rmt-ending-confession-actions,.rmt-ending-easter-controls){display:flex;flex-wrap:wrap;gap:8px}\n ${r} .rmt-body :is(.rmt-travel-dialogue-actions,.rmt-ending-confession-actions,.rmt-ending-easter-controls)>.rmt-btn{flex:1 1 112px}\n}\n`;\n}\n"
      }
    ]
  }
};
const sha = value => createHash('sha256').update(value).digest('hex');
export function phase9ApprovedSource(path, value) {
    value = phase10ApprovedSource(path, value);
    const spec = phase9Deltas[path];
    if (!spec) return value;
    const raw = String(value), digest = sha(raw);
    if (digest === spec.beforeSha256) return raw;
    assert.equal(digest, spec.afterSha256, path + ' contains an unreviewed phase3 change (not an approved phase9 delta)');
    const lines = raw.match(/[^\n]*\n|[^\n]+$/g) || [];
    for (const part of [...spec.changes].reverse()) {
        assert.equal(lines.slice(part.start, part.start + part.remove).join(''), part.new, 'phase9 approved hunk differs');
        lines.splice(part.start, part.remove, ...(part.old.match(/[^\n]*\n|[^\n]+$/g) || []));
    }
    const restored = lines.join('');
    assert.equal(sha(restored), spec.beforeSha256, 'phase9 inverse differs from delivered baseline');
    return restored;
}
