// Reuses original domain fixtures and all their assertions, adding an actual
// second failed response with less information before the original assertions.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { projectGenerationProgress } from '../../src/generation/partialProgress.js';
import { mergeRecoveryPartials } from '../../src/generation/recoveryMerge.js';
import { recoveryProgressSchema } from '../../src/generation/recoveryAdapters.js';
function stable(value) {
    if (Array.isArray(value)) return value.map(stable);
    if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value)
        .filter(([key]) => !['generatedAt', 'updatedAt', 'createdAt'].includes(key)).map(([key, item]) => [key, stable(item)]));
    return value;
}
function record(mode) {
    if (process.env.RMT_MONOTONIC_RECORD) fs.appendFileSync(process.env.RMT_MONOTONIC_RECORD, JSON.stringify({ mode, passed: true }) + '\n');
}
export async function monotonicGenerationProject(journal, options) {
    const before = await projectGenerationProgress(journal, options);
    const next = structuredClone(journal); let changed = false;
    for (const row of next.segments || []) if (row.state === 'truncated') {
        row.retainedPartials = [...(row.retainedPartials || []), row.partial]; row.partial = '{'; changed = true;
    }
    const after = await projectGenerationProgress(next, options);
    if (changed) { assert.deepEqual(stable(after), stable(before), 'less-informative response must not remove validated domain progress: ' + journal.identity.mode); record(journal.identity.mode); }
    return after;
}
export function monotonicProject(mode, project, props) {
    const before = project(props); let changed = false;
    const segments = props.segments.map(row => {
        if (row.state !== 'truncated' || !row.received) return row;
        changed = true;
        const schema = recoveryProgressSchema(mode, { ...props, slot: row.slot });
        return { ...row, ...mergeRecoveryPartials([row.received, '{'], schema) };
    });
    const after = project({ ...props, segments });
    if (changed) { assert.deepEqual(stable(after), stable(before), 'domain reader must retain validated units: ' + mode); record(mode); }
    return after;
}
