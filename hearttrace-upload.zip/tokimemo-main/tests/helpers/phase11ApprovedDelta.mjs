// Exact approved phase11 delta; prior approved bytes and contracts remain pinned.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
export const phase11Deltas = {
  "src/ui/settingsPanel.js": {
    "beforeSha256": "432d440fd840c2814c9f17d2b1a5e0dfff3d137844b8ca9c87dc70b487510fe8",
    "afterSha256": "f8f1e5f86140f6447fb9f8bb6121d6bcef74125ddaddb09b3be6707556aa3794",
    "changes": [
      {
        "start": 655,
        "remove": 1,
        "old": "          <summary class=\"rmt-settings-card-head\"><span>TAG</span><div><b>按用户所选标签保存</b><small>勾选保留</small></div></summary>\n",
        "new": "          <summary class=\"rmt-settings-card-head\"><span>TAG</span><div><b>过滤标签</b><small>勾选即不读取</small></div></summary>\n"
      },
      {
        "start": 657,
        "remove": 2,
        "old": "            <p>勾选的标签块参与后续整理；未选外层块连同内部略过，无标签正文保留。不改聊天和旧档案。</p>\n            <textarea class=\"text_pole\" data-rmt-tag-draft aria-label=\"要保存的标签名\" placeholder=\"正文, content, dialogue\"></textarea>\n",
        "new": "            <p>勾选的标签及其中全部内容不参与后续读取；未勾选的内容和无标签正文保留。可排除正文内嵌的标签块，不改聊天和旧档案。</p>\n            <textarea class=\"text_pole\" data-rmt-tag-draft aria-label=\"不读取的标签名\" placeholder=\"thinking, 绘图提示词标签\"></textarea>\n"
      },
      {
        "start": 740,
        "remove": 1,
        "old": "        return settings.contextTagMode === 'keep' ? settings.retainedContextTags\n            : [...tagChoices.keys()].filter(name => !settings.excludedContextTags.includes(name));\n",
        "new": "        return settings.excludedContextTags;\n"
      },
      {
        "start": 760,
        "remove": 2,
        "old": "        ? '已保存的选择从下一次整理生效。' : '当前沿用旧排除设置；扫描后可选择要保留的标签。';\n",
        "new": "        ? '旧版保留规则尚未更改。当前显示原有排除名单；请自行勾选并保存，之后勾选的标签内容不读取。'\n        : '勾选的标签内容不读取；保存后用于后续整理。';\n"
      },
      {
        "start": 1054,
        "remove": 1,
        "old": "                        core_settings.updatePluginSettings({ contextTagMode: 'keep', retainedContextTags: tags });\n",
        "new": "                        core_settings.updatePluginSettings({ contextTagMode: 'exclude', excludedContextTags: tags });\n"
      },
      {
        "start": 1056,
        "remove": 1,
        "old": "                        tagStatus.textContent = '已保存 ' + tags.length + ' 个标签；下次整理生效，聊天和旧档案未改动。';\n",
        "new": "                        tagStatus.textContent = '已保存 ' + tags.length + ' 个过滤标签，标签内的内容不读取；下次整理生效，聊天和旧档案未改动。';\n"
      }
    ]
  }
};
const sha = value => createHash('sha256').update(value).digest('hex');
export function phase11ApprovedSource(path, value) {
    const spec = phase11Deltas[path];
    if (!spec) return value;
    const raw = String(value), digest = sha(raw);
    if (digest === spec.beforeSha256) return raw;
    assert.equal(digest, spec.afterSha256, path + ' contains an unreviewed phase3 change (not an approved phase11 delta)');
    const lines = raw.match(/[^\n]*\n|[^\n]+$/g) || [];
    for (const part of [...spec.changes].reverse()) {
        assert.equal(lines.slice(part.start, part.start + part.remove).join(''), part.new, 'phase11 approved hunk differs');
        lines.splice(part.start, part.remove, ...(part.old.match(/[^\n]*\n|[^\n]+$/g) || []));
    }
    const restored = lines.join('');
    assert.equal(sha(restored), spec.beforeSha256, 'phase11 inverse differs from delivered baseline');
    return restored;
}
