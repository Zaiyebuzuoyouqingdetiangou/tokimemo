// Exact approved phase4 delta. Preserve all prior phase3/historical checks.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
export const phase4ChronologyDeltas = {
  "src/core/evidence.js": {
    "beforeSha256": "c68df199006c048c1023580aa203671f07598e0be44e92adaaf6a8e9051fe08e",
    "afterSha256": "e4f9fcee4392aa97c0109a75b73288754768b1c59aec3038e6cacdf4f63abd23",
    "changes": [
      {
        "start": 4,
        "remove": 1,
        "old": "",
        "new": "import * as story_chronology from './storyChronology.js';\n"
      },
      {
        "start": 79,
        "remove": 1,
        "old": "    return selected.map(item => ({\n",
        "new": "    return story_chronology.sortByStoryDate(selected).map(item => ({\n"
      }
    ]
  },
  "src/modes/album.js": {
    "beforeSha256": "cef191bfe56fef013ca9a8efb07cba61040ccfbe8c8512800f58054f01bfbb64",
    "afterSha256": "7160ed26eb32a77fc6a50608e6c968410923c682e0c6d63b75b92f1d6ce70fe0",
    "changes": [
      {
        "start": 1,
        "remove": 1,
        "old": "",
        "new": "import * as story_chronology from '../core/storyChronology.js';\n"
      },
      {
        "start": 17,
        "remove": 1,
        "old": "    return core_evidence.evenlySample(Array.isArray(session?.entries) ? session.entries : [], core_constants.MAX_INCREMENTAL_EXISTING_INDEX_ITEMS).map(item => ({\n",
        "new": "    return story_chronology.sortByStoryDate(core_evidence.evenlySample(Array.isArray(session?.entries) ? session.entries : [], core_constants.MAX_INCREMENTAL_EXISTING_INDEX_ITEMS)).map(item => ({\n"
      },
      {
        "start": 93,
        "remove": 1,
        "old": "",
        "new": "    const ordered = story_chronology.sortByStoryDate(indexed.map(record => ({ ...record, date: record.item?.date })));\n"
      },
      {
        "start": 99,
        "remove": 2,
        "old": "        memories: indexed.map(record => [core_text.normalizeText(record.item?.id, 40), record.evidenceAnchor]),\n        relationshipDetails: indexed.filter(record => detailedIndexes.has(record.index)).map(record => ({\n",
        "new": "        memories: ordered.map(record => [core_text.normalizeText(record.item?.id, 40), record.evidenceAnchor]),\n        relationshipDetails: ordered.filter(record => detailedIndexes.has(record.index)).map(record => ({\n"
      }
    ]
  },
  "src/ui/albumView.js": {
    "beforeSha256": "e2eadc76749aabee01f1bff9c483593ec480221a7cbaece1f75f01f7e25d49d1",
    "afterSha256": "899dc4afee2bfe8d6c93a4ee27b2ea5f4cd8a3a192ef02f614d3597bb8b6f204",
    "changes": [
      {
        "start": 1,
        "remove": 1,
        "old": "",
        "new": "import * as story_chronology from '../core/storyChronology.js';\n"
      },
      {
        "start": 17,
        "remove": 2,
        "old": "    return category === '全部' ? runtimeState.activeSession.entries : runtimeState.activeSession.entries.filter(x => ui_albumCategory.albumDisplayCategory(x) === category);\n",
        "new": "    const entries = story_chronology.sortByStoryDate(runtimeState.activeSession.entries);\n    return category === '全部' ? entries : entries.filter(x => ui_albumCategory.albumDisplayCategory(x) === category);\n"
      }
    ]
  }
};
const sha = value => createHash('sha256').update(value).digest('hex');
export function phase4ChronologyApprovedSource(path, value) {
    const spec = phase4ChronologyDeltas[path];
    if (!spec) return value;
    const raw = String(value), digest = sha(raw);
    if (digest === spec.beforeSha256) return raw;
    assert.equal(digest, spec.afterSha256, path + ' contains an unreviewed phase3 change (not an approved phase4 delta)');
    const lines = raw.match(/[^\n]*\n|[^\n]+$/g) || [];
    for (const part of [...spec.changes].reverse()) {
        assert.equal(lines.slice(part.start, part.start + part.remove).join(''), part.new, 'phase4 approved hunk differs');
        lines.splice(part.start, part.remove, ...(part.old.match(/[^\n]*\n|[^\n]+$/g) || []));
    }
    const restored = lines.join('');
    assert.equal(sha(restored), spec.beforeSha256, 'phase4 inverse differs from delivered baseline');
    return restored;
}
