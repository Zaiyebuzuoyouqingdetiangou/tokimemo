// Exact inverse of the reviewed r84.33 draft-identity/snapshot change for historical
// freeze tests. Expected historical hashes are unchanged. Unknown extra edits fail closed.
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import { r8432ApprovedSource } from './r8432ApprovedDelta.mjs';
const deltas = JSON.parse(readFileSync(new URL('./r8433ApprovedDelta.json', import.meta.url), 'utf8'));
const sha = value => createHash('sha256').update(value).digest('hex');
export function r8433ApprovedSource(path, value) {
    const spec = deltas[path];
    if (spec) {
        const raw = String(value), digest = sha(raw);
        if (digest !== spec.beforeSha256) {
            assert.equal(digest, spec.afterSha256, path + ': unreviewed phase3 change outside the exact r8433 approved delta');
            const lines = raw.match(/[^\n]*\n|[^\n]+$/g) || [];
            for (const part of [...spec.changes].reverse()) {
                assert.equal(lines.slice(part.start, part.start + part.remove).join(''), part.new, 'r8433 exact hunk differs');
                lines.splice(part.start, part.remove, ...(part.old.match(/[^\n]*\n|[^\n]+$/g) || []));
            }
            const restored = lines.join('');
            assert.equal(sha(restored), spec.beforeSha256, 'r8433 inverse is not the r8432-approved baseline');
            value = restored;
        }
    }
    return r8432ApprovedSource(path, value);
}
