// Exact inverse of the reviewed r84.34 album-category change for historical
// freeze tests. Expected historical hashes are unchanged. Unknown extra edits fail closed.
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import { r8433ApprovedSource } from './r8433ApprovedDelta.mjs';
const deltas = JSON.parse(readFileSync(new URL('./r8434ApprovedDelta.json', import.meta.url), 'utf8'));
const sha = value => createHash('sha256').update(value).digest('hex');
export function r8434ApprovedSource(path, value) {
    const spec = deltas[path];
    if (spec) {
        const raw = String(value), digest = sha(raw);
        if (digest !== spec.beforeSha256) {
            assert.equal(digest, spec.afterSha256, path + ': unreviewed phase3 change outside the exact r8434 approved delta');
            const lines = raw.match(/[^\n]*\n|[^\n]+$/g) || [];
            for (const part of [...spec.changes].reverse()) {
                assert.equal(lines.slice(part.start, part.start + part.remove).join(''), part.new, 'r8434 exact hunk differs');
                lines.splice(part.start, part.remove, ...(part.old.match(/[^\n]*\n|[^\n]+$/g) || []));
            }
            const restored = lines.join('');
            assert.equal(sha(restored), spec.beforeSha256, 'r8434 inverse is not the r8433-approved baseline');
            value = restored;
        }
    }
    return r8433ApprovedSource(path, value);
}
