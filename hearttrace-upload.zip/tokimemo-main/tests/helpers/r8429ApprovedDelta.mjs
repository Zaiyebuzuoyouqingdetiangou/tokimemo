// Exact inverse of this reviewed recovery-only change for historical freeze tests.
// Expected historical hashes are unchanged. Unknown extra edits fail closed.
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const deltas = JSON.parse(readFileSync(new URL('./r8429ApprovedDelta.json', import.meta.url), 'utf8'));
const sha = value => createHash('sha256').update(value).digest('hex');
export function r8429ApprovedSource(path, value) {
    const spec = deltas[path]; if (!spec) return value;
    const raw = String(value), digest = sha(raw);
    if (digest === spec.beforeSha256) return raw;
    assert.equal(digest, spec.afterSha256, path + ': unreviewed phase3 change outside the exact r8429 recovery delta');
    const lines = raw.match(/[^\n]*\n|[^\n]+$/g) || [];
    for (const part of [...spec.changes].reverse()) {
        assert.equal(lines.slice(part.start, part.start + part.remove).join(''), part.new, 'r8429 exact hunk differs');
        lines.splice(part.start, part.remove, ...(part.old.match(/[^\n]*\n|[^\n]+$/g) || []));
    }
    const restored = lines.join('');
    assert.equal(sha(restored), spec.beforeSha256, 'r8429 inverse is not the uploaded baseline');
    return restored;
}
