import { phase11ApprovedSource } from './phase11ApprovedDelta.mjs';
// Exact approved phase10 delta; prior approved bytes and contracts remain pinned.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
export const phase10Deltas = {
  "src/ui/albumView.js": {
    "beforeSha256": "bcb949ef2d05898c4970a2a73f39e891f4091baf450cb65ea635cacc9c291ac2",
    "afterSha256": "336f43f0f340d3cbaa4011da2f07c867a5fb869e28775db207a8d389c5b98a15",
    "changes": [
      {
        "start": 239,
        "remove": 2,
        "old": "          <button type=\"button\" class=\"rmt-btn\" data-rmt-action=\"shared-back\">返回相簿</button>\n          <button type=\"button\" class=\"rmt-btn\" data-rmt-action=\"${last ? 'shared-replay' : 'shared-next'}\" ${!comments.length ? 'disabled' : ''}>${last ? '重看' : '下一句'}</button>\n",
        "new": "          <button type=\"button\" class=\"rmt-btn\" data-rmt-action=\"shared-prev\" ${!comments.length || session.dialogueIndex <= 0 ? 'disabled' : ''}>上一句</button>\n          <button type=\"button\" class=\"rmt-btn\" data-rmt-action=\"shared-next\" ${!comments.length || last ? 'disabled' : ''}>下一句</button>\n"
      }
    ]
  },
  "src/ui/cgPromptEditor.js": {
    "beforeSha256": "ccea67353d411633fb38b588c37c77f4e366d77aedd70f7531efdf2ed6fa4016",
    "afterSha256": "7d0ea08d5ed3b9101109001f3e5f18a39fe3b1931a98fc9b59fe339b0acc7fa4",
    "changes": [
      {
        "start": 120,
        "remove": 1,
        "old": "    return multi ? '<fieldset data-rmt-cg-cast><legend>本图出镜人物</legend><p>勾选只影响这张图。姓名可改，也可补充档案名单外的人物；同名人物独立保存。</p><div data-rmt-cg-cast-list></div><button type=\"button\" class=\"rmt-btn\" data-rmt-cg-prompt-action=\"add-person\">补充人物</button><button type=\"button\" class=\"rmt-btn\" data-rmt-cg-prompt-action=\"add-user\">定位用户候选</button><button type=\"button\" class=\"rmt-btn\" data-rmt-cg-prompt-action=\"select-sources\">重新选择外貌来源</button></fieldset>' : `<p><label for=\"rmt-cg-char-tags\" data-rmt-cg-tag-name=\"char\">角色 · 外貌 tag</label><textarea id=\"rmt-cg-char-tags\" data-rmt-cg-tag-input=\"char\" rows=\"2\" maxlength=\"${appearance.CG_APPEARANCE_TAG_LIMIT}\" placeholder=\"重新构思时提取，或手动填写\"></textarea></p>\n",
        "new": "    return multi ? '<fieldset data-rmt-cg-cast><legend>本图出镜人物</legend><p>勾选只影响这张图。姓名可改，也可补充档案名单外的人物；同名人物独立保存。</p><div data-rmt-cg-cast-list></div><div class=\"rmt-cg-cast-actions\"><button type=\"button\" class=\"rmt-btn\" data-rmt-cg-prompt-action=\"add-person\">补充人物</button><button type=\"button\" class=\"rmt-btn\" data-rmt-cg-prompt-action=\"add-user\">定位用户候选</button><button type=\"button\" class=\"rmt-btn\" data-rmt-cg-prompt-action=\"select-sources\">重新选择外貌来源</button></div></fieldset>' : `<p><label for=\"rmt-cg-char-tags\" data-rmt-cg-tag-name=\"char\">角色 · 外貌 tag</label><textarea id=\"rmt-cg-char-tags\" data-rmt-cg-tag-input=\"char\" rows=\"2\" maxlength=\"${appearance.CG_APPEARANCE_TAG_LIMIT}\" placeholder=\"重新构思时提取，或手动填写\"></textarea></p>\n"
      },
      {
        "start": 260,
        "remove": 2,
        "old": "            ${selected.cgImage && participants.selectedParticipantSnapshot(currentRoster) ? '<button type=\"button\" class=\"rmt-btn\" data-rmt-cg-prompt-action=\"use-current-cast\">从当前档案选择本图人物</button>' : ''}\n            <button type=\"button\" class=\"rmt-btn\" data-rmt-cg-prompt-action=\"save-looks\">保存外貌</button>\n",
        "new": "            <div class=\"rmt-cg-cast-actions\">${selected.cgImage && participants.selectedParticipantSnapshot(currentRoster) ? '<button type=\"button\" class=\"rmt-btn\" data-rmt-cg-prompt-action=\"use-current-cast\">从当前档案选择本图人物</button>' : ''}\n            <button type=\"button\" class=\"rmt-btn\" data-rmt-cg-prompt-action=\"save-looks\">保存外貌</button></div>\n"
      }
    ]
  },
  "src/ui/overlay.js": {
    "beforeSha256": "7c7b063a65d6fb304d4693be97425cc42aee7c5e8f475d33b5b1cac628feeb4d",
    "afterSha256": "60f9f45d67754420683e95ab083e25381f0863ff30f16fea7cd08266fa2cdee5",
    "changes": [
      {
        "start": 1889,
        "remove": 7,
        "old": "",
        "new": "    if (action === 'shared-prev') {\n        if (runtimeState.activeSession?.kind === core_constants.MODE.ALBUM) {\n            runtimeState.activeSession.dialogueIndex = Math.max(0, runtimeState.activeSession.dialogueIndex - 1);\n            ui_albumView.renderSharedMemory();\n        }\n        return;\n    }\n"
      }
    ]
  },
  "src/ui/workspace.js": {
    "beforeSha256": "a5ce1ae29cb412362d150edc677d3450e95218cbe99d6a3f618cc408a2c99211",
    "afterSha256": "bcca482ad359b82cf8da4af42a07fbde648ed84323f197da4ec59b667fdc5e7d",
    "changes": [
      {
        "start": 113,
        "remove": 1,
        "old": "",
        "new": "    calendar?.remove();\n"
      },
      {
        "start": 161,
        "remove": 0,
        "old": "        if (calendar) main.appendChild(calendar);\n",
        "new": ""
      }
    ]
  },
  "src/ui/workspaceState.js": {
    "beforeSha256": "94604fb3dcacb98ac6366181b4c9c8dd26090ed98652669854e4d65324b1a5f3",
    "afterSha256": "fa992e68b758dd05ab025e9e7bee1b1add5cc86a12c3768253ade73d104d7879",
    "changes": [
      {
        "start": 51,
        "remove": 1,
        "old": "    calendar: { mode: 'calendar', title: '两个人的日历', group: 'life', deep: true },\n",
        "new": "    calendar: { mode: 'calendar', title: '两个人的日历', group: 'life' },\n"
      }
    ]
  },
  "src/ui/workspaceStyles.js": {
    "beforeSha256": "4e6cd850640bb6e52f7ed3eb3df85b9b24b8d1449d6080e934c4ef3e26f301ac",
    "afterSha256": "0cfa3ec2396878aafb4c20e4bcea155945c64f4ba74a842c3879a6d4b83c9a58",
    "changes": [
      {
        "start": 239,
        "remove": 6,
        "old": "",
        "new": "${r} .rmt-body .rmt-dialogue-actions{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:12px!important;width:min(100%,320px)!important;margin:20px auto 0!important;justify-content:center!important}\n${r} .rmt-body .rmt-dialogue-actions>.rmt-btn{width:100%!important;min-width:0!important;white-space:nowrap!important}\n${r} .rmt-body .rmt-cg-card-actions{justify-content:center!important;align-items:center!important;gap:12px!important}\n${r} .rmt-cg-prompt-dialog [data-rmt-cg-cast]{padding:0!important;border:0!important;margin:0!important;min-width:0!important}\n${r} .rmt-cg-cast-actions{display:grid!important;grid-template-columns:minmax(0,1fr)!important;gap:10px!important;width:100%!important;margin:10px 0!important}\n${r} .rmt-cg-cast-actions>.rmt-btn{box-sizing:border-box!important;width:100%!important;min-height:44px!important;margin:0!important;font-size:14px!important;padding:10px 12px!important;border-radius:22px!important}\n"
      }
    ]
  }
};
const sha = value => createHash('sha256').update(value).digest('hex');
export function phase10ApprovedSource(path, value) {
    value = phase11ApprovedSource(path, value);
    const spec = phase10Deltas[path];
    if (!spec) return value;
    const raw = String(value), digest = sha(raw);
    if (digest === spec.beforeSha256) return raw;
    assert.equal(digest, spec.afterSha256, path + ' contains an unreviewed phase3 change (not an approved phase10 delta)');
    const lines = raw.match(/[^\n]*\n|[^\n]+$/g) || [];
    for (const part of [...spec.changes].reverse()) {
        assert.equal(lines.slice(part.start, part.start + part.remove).join(''), part.new, 'phase10 approved hunk differs');
        lines.splice(part.start, part.remove, ...(part.old.match(/[^\n]*\n|[^\n]+$/g) || []));
    }
    const restored = lines.join('');
    assert.equal(sha(restored), spec.beforeSha256, 'phase10 inverse differs from delivered baseline');
    return restored;
}
