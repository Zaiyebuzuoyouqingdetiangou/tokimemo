import assert from 'node:assert/strict';
import { fixture } from './r847Host.mjs';
import * as C from '../../src/core/constants.js';
import * as settings from '../../src/core/settings.js';
import * as context from '../../src/core/context.js';
import * as R from '../../src/archive/repository.js';
import * as ledger from '../../src/archive/sourceLedger.js';
import * as recovery from '../../src/archive/importRecovery.js';
import * as overlay from '../../src/ui/overlay.js';
import { state } from '../../src/core/state.js';

export const clone = value => structuredClone(value);
export const sourceRows = (count, length = 200, provider = 'synthetic-file') => Array.from({ length: count }, (_, i) => ({
    provider, sourceId: `row-${i}`, content: (`记录${String(i).padStart(5, '0')}：锚点与庭院。` + '春'.repeat(length)).slice(0, length - 7) + `尾${String(i).padStart(6, '0')}`,
}));
export function requestRows(messages) {
    const prompt = messages.map(message => message.content).join('\n');
    for (const [marker, kind] of [['EXTERNAL_MEMORY_JSON:\n', 'external'], ['UNTRUSTED_CHAT_JSON:\n', 'chat']]) {
        const index = prompt.lastIndexOf(marker);
        if (index >= 0) return { kind, rows: JSON.parse(prompt.slice(index + marker.length)), prompt };
    }
    return { kind: 'profile', rows: [], prompt };
}
export function memoryReply(messages, { allRows = false } = {}) {
    const { kind, rows } = requestRows(messages);
    if (kind === 'profile') throw Object.assign(new Error('synthetic cover failure'), { code: 'RMT_ARCHIVE_VERDICT' });
    return { memories: (allRows ? rows : rows.slice(0, 1)).map(row => {
        const value = row.content || row.text;
        const suffix = `${value.slice(0, 15)}-${value.slice(-12)}`;
        return kind === 'external'
            ? { title: suffix, summary: `共同记录：${value.slice(0, 60)}`, anchors: [value.slice(0, 6), value.slice(-6)],
                sourceExternalIds: [row.externalId], sourceExternalAnchor: value.slice(0, 6), participants: ['林舟', '小月'] }
            : { title: suffix, summary: `共同记录：${value.slice(0, 60)}`, anchors: [value.slice(0, 6), value.slice(-6)],
                messageStart: row.index, messageEnd: row.index, participants: ['林舟', '小月'] };
    }) };
}
export async function archiveFixture(t, { rows = [], memoryCount = 1 } = {}) {
    const f = await fixture(t);
    R.setMemoryWorldInfoSelection(f.ctx, { books: [] });
    const snapshot = await context.buildChatSnapshot(f.ctx, { completeSource: true, readRange: settings.getPluginSettings(f.ctx).chatReadRange });
    const bank = f.ctx.chatMetadata[C.MEMORY_KEY];
    bank.sourceFingerprint = `${snapshot.fingerprint}:none`;
    bank.sourceMessageCount = snapshot.totalMessages;
    bank.chatReadRange = snapshot.readRange;
    bank.externalMemoryFingerprint = 'none';
    bank.fullSourceFingerprint = snapshot.fullFingerprint;
    bank.memories = Array.from({ length: memoryCount }, (_, i) => i ? { id: `M${String(i + 1).padStart(3, '0')}`, title: `旧记忆${i}`, summary: `保留旧结果${i}`, anchors: [`旧锚点${i}`] } : bank.memories[0]);
    f.records.get(f.aEntry.entryId).memory = clone(bank);
    const stores = new Map();
    ledger.setMemorySourceLedgerBackendForTests({ read: async scope => clone(stores.get(scope.key) || null),
        write: async value => { stores.set(value.scope.key, clone(value)); return true; },
        delete: async () => { throw new Error('No source deletion is allowed in these tests'); } });
    const putSources = async (value, revision = 'first') => ledger.upsertMemorySourceLedger(R.memorySourceScopeForContext(f.ctx), {
        provider: value[0]?.provider || 'synthetic-file', revision, label: '合成历史文件', sourceKind: 'file-user-confirmed-history-summary',
        coverage: { status: 'complete', returned: value.length, total: value.length }, records: value,
    });
    if (rows.length) await putSources(rows);
    f.setResponse(messages => memoryReply(messages));
    t.after(() => {
        recovery.clearArchiveRecovery(context.captureTaskOrigin(f.ctx, R.getImportedMemory(f.ctx)?.archiveRevision || ''));
        ledger.setMemorySourceLedgerBackendForTests(null);
    });
    return { ...f, stores, putSources };
}

export async function clickImport(f, action = 'current-archive-import') {
    const node = { dataset: { rmtAction: action }, disabled: false };
    const event = { target: { closest: selector => selector === '[data-rmt-action]' ? node : null }, preventDefault() {} };
    overlay.handleOverlayClick(event);
    await waitForIdle(f);
}
export async function clickArchiveControl(f, attribute) {
    const node = { dataset: {}, disabled: false };
    overlay.handleOverlayClick({ target: { closest: selector => selector === `[${attribute}]` ? node : null }, preventDefault() {} });
    await waitForIdle(f);
}
export async function waitForIdle(f) {
    const start = Date.now();
    await new Promise(resolve => setTimeout(resolve, 0));
    while (state.busy || state.activeProviderRequestCount) {
        assert.ok(Date.now() - start < 20000, `UI handler did not settle: ${JSON.stringify(f.notices)}`);
        await new Promise(resolve => setTimeout(resolve, 2));
    }
    await new Promise(resolve => setTimeout(resolve, 2));
}
