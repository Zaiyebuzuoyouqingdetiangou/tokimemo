import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const hashes=JSON.parse(read('tests/helpers/r8419-baseline-hashes.json'));
const sha=s=>createHash('sha256').update(s).digest('hex');
for(const dir of ['src/archive/','src/modes/','src/core/','src/generation/','src/ui/'])test(`r84.19 actual unchanged r84.18 source bytes outside approved edit list: ${dir}`,()=>{
 for(const [p,expected]of Object.entries(hashes).filter(([p])=>p.startsWith(dir)))assert.equal(sha(fs.readFileSync(path.join(root,p))),expected,p);
});
test('no format assertions remain on production send/preparation paths',()=>{
 for(const p of ['src/generation/cgAppearance.js','src/generation/cgPromptPolicy.js','src/generation/imageGeneration.js','src/generation/baibaiImage.js','src/ui/cgPromptEditor.js']){
  assert.doesNotMatch(read(p),/(?:format|cg_format)\.(?:assertEnglishTagPrompt|assertNaturalScenePrompt)\s*\(/u,p);
 }
 const text=read('src/core/cgPromptFormat.js'),comic=text.slice(text.indexOf('export function formatDailyComicPrompt'));
 assert.doesNotMatch(comic,/assertEnglishTagPrompt\s*\(/u);
});
test('all three image modes still delegate into shared target-bound draw implementation',()=>{
 assert.match(read('src/ui/cgPromptEditor.js'),/heart\.drawHeartStripImage/);
 assert.match(read('src/ui/cgPromptEditor.js'),/images\.drawSelectedCgImage/);
 assert.match(read('src/ui/heartView.js'),/generation_imageGeneration\.drawSelectedCgImage/);
 assert.match(read('src/generation/baibaiImage.js'),/appearance\.formattedCgProviderPrompts/);
 assert.match(read('src/generation/imageGeneration.js'),/export function cgEditorSendPreview/);
});
test('version and bootstrap runtime cache identity agree',()=>{
 const m=JSON.parse(read('manifest.json'));assert.equal(m.version,'0.8.95');
 const build='0.8.95-tt-cg-r84.19-cg-format-preference';assert.match(m.js,new RegExp(build.replaceAll('.','\\.')));assert.ok(read('index.js').includes(`const BUILD = '${build}'`));
});
test('provider reservation/target/signature/limits were not part of this patch',()=>{
 for(const p of ['src/core/cgImagePatch.js','src/core/requestCoordinator.js','src/generation/baibaiImage.js','src/generation/imageGeneration.js','src/archive/library.js','src/archive/repository.js','src/core/cache.js'])assert.equal(sha(read(p)),hashes[p],p);
});
