import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './helpers/r847Host.mjs';
import * as client from '../src/generation/client.js';
import * as recovery from '../src/generation/recovery.js';
import * as context from '../src/core/context.js';
import * as cache from '../src/core/cache.js';
import * as settings from '../src/core/settings.js';
import * as constants from '../src/core/constants.js';
import * as groups from '../src/archive/groups.js';
import * as coordinator from '../src/core/requestCoordinator.js';
import * as heart from '../src/modes/heart.js';
import * as overlay from '../src/ui/overlay.js';
import { state } from '../src/core/state.js';

const good = { value: '原任务成功内容' };
const validate = raw => { assert.deepEqual(raw, good); return raw; };
const fail = () => { throw Object.assign(new Error('synthetic failure'), { code: 'RMT_MANUAL_HTTP', status: 400 }); };

test('optional absent session fields remain absent in durable source snapshots without blocking generation', async t => {
    const f = await fixture(t), origin = context.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision);
    const baseSession = { kind: 'heart', generationMeta: undefined,
        nested: { missing: undefined, retained: '原内容' }, slots: [undefined, , { text: '已完成', optional: undefined }] };
    const before = structuredClone(baseSession);
    let handle;
    await assert.doesNotReject(async () => { handle = await client.beginModeRecovery('heart', f.ctx, f.liveBank, origin, { contentInputs: { baseSession } }); });
    t.after(() => recovery.detachGenerationRecovery(origin));
    assert.deepEqual(baseSession, before, 'capturing a source must not mutate the visible session');
    const expected = { kind: 'heart', nested: { retained: '原内容' }, slots: [null, null, { text: '已完成' }] };
    assert.deepEqual(handle.contentInputs.baseSession, expected);
    assert.deepEqual(cache.loadGenerationRecovery('heart', f.ctx).contentSnapshot.contentInputs.baseSession, expected);
    f.setResponse(good);
    await client.requestValidatedSegment('原请求保持不变', 'fixture', { context: f.ctx, origin, mode: 'heart', taskKey: 'optional:one' }, validate);
    assert.equal(f.requests.length, 1);
    assert.match(f.requests[0][0].content, /原请求保持不变/);
});

test('unrelated card payload does not consume the current task snapshot while duplicate-card identity is preserved', async t => {
    const f = await fixture(t), selected = f.ctx.characters[f.ctx.characterId];
    const unnamedLabel = `角色 ${f.ctx.characters.length + 5}`;
    const unrelated = { name: '其他人物', avatar: 'unrelated.png', data: { name: '其他人物', description: '无关资料'.repeat(400000),
        extensions: { unrelatedLargePayload: '非当前来源'.repeat(400000) } } };
    f.ctx.characters.push(unrelated, structuredClone(selected), { ...structuredClone(selected), avatar: 'same-name.png' },
        { name: 'n'.repeat(119) + '  tail', avatar: 'a'.repeat(299) + '  tail',
            data: Object.fromEntries(['description', 'personality', 'scenario', 'first_mes', 'mes_example']
                .map(key => [key, 'x'.repeat(4999) + '   tail'])) }, { avatar: 'unnamed.png' }, { name: unnamedLabel, avatar: 'named.png' },
        { name: '换\u0000行\r\n卡', avatar: 'crlf.png', data: { description: 'x' + '\r\n'.repeat(2600) + 'z',
            personality: 'y' + '\u0000'.repeat(6000) + 'z' } });
    const before = structuredClone(f.ctx.characters), origin = context.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision);
    const expectedDescriptors = f.ctx.characters.map((_, i) => groups.characterDescriptor(f.ctx, i));
    const entry = { characterName: f.ctx.name2, characterIndexHint: f.ctx.characterId,
        avatar: selected.avatar, characterFingerprint: expectedDescriptors[f.ctx.characterId].fingerprint };
    let handle;
    await assert.doesNotReject(async () => { handle = await client.beginModeRecovery('inbox', f.ctx, f.liveBank, origin); });
    t.after(() => recovery.detachGenerationRecovery(origin));
    const frozen = handle.contentContext;
    assert.deepEqual(frozen.characters.map((_, i) => groups.characterDescriptor(frozen, i)), expectedDescriptors);
    assert.deepEqual(frozen.characters[f.ctx.characterId], selected, 'the actual source card remains complete');
    assert.equal(context.contextCharacterAvatar(frozen, f.ctx.name2), context.contextCharacterAvatar(f.ctx, f.ctx.name2));
    assert.equal(context.contextCharacterAvatar(frozen, unnamedLabel), context.contextCharacterAvatar(f.ctx, unnamedLabel));
    assert.equal(context.archiveEntryMatchesContextCharacter(entry, frozen), context.archiveEntryMatchesContextCharacter(entry, f.ctx));
    assert.equal(context.archiveEntryMatchesContextCharacter(entry, frozen), false, 'duplicates must remain ambiguous');
    assert.deepEqual(f.ctx.characters, before, 'the host library is not edited');
    assert.doesNotMatch(JSON.stringify(handle.journal.contentSnapshot), /unrelatedLargePayload/);
    f.setResponse(good);
    await client.requestValidatedSegment('当前角色原请求', 'fixture', { context: f.ctx, origin, mode: 'inbox', taskKey: 'cards:one' }, validate);
    assert.equal(f.requests.length, 1);
});
const echo = { title: '雨声从明天传来', opening: '林舟拿起听筒，听见尚未落下的雨。', closing: '他收起原定的车票，约好一起走另一条路。',
    palette: 'blue', motif: '雨声', medium: { kind: 'phone', label: '旧电话' },
    ends: [{ role: 'char', time: '今夜' }, { role: 'user', time: '三年后的今夜' }],
    lines: [{ speaker: 'a', text: '你那边还在下雨吗？' }, { speaker: 'b', text: '明天别坐那班车。' }], message: '换一班车，带上那封信。' };

for (const change of ['unchanged', 'appended-chat', 'reopen', 'profile-model', 'content-settings']) {
    test(`real mode continuation preserves paid input after ${change}`, async t => {
        const f = await fixture(t);
        f.setResponse(fail);
        await client.generateMode('timeEcho', { background: true });
        assert.equal(f.requests.length, 1);
        const original = structuredClone(f.requests[0]);
        const journal = cache.loadGenerationRecovery('timeEcho', f.ctx);
        assert.ok(journal.contentSnapshot);
        assert.ok(journal.segments[0].requestRecipe.actualPrompt);
        if (change === 'appended-chat') f.ctx.chat.push({ name: '小月', is_user: true, mes: 'NEW_CHAT_NOT_IN_OLD_TASK' });
        if (change === 'profile-model') settings.updatePluginSettings({ modelOverride: 'new-current-model' });
        if (change === 'content-settings') settings.updatePluginSettings({ creativeSupplementEnabled: true, creativeSupplement: 'NEW_POLICY_NOT_IN_OLD_TASK' });
        if (change === 'reopen') {
            state.runtimeSessionCache.clear(); state.activeSession = null; state.activeMode = null;
            await cache.ensureCacheHydrated(f.ctx);
        }
        f.setResponse(echo);
        await client.continueSavedGeneration('timeEcho', { draftId: journal.draftId });
        assert.equal(f.requests.length, 2);
        assert.deepEqual(f.requests[1], original);
        assert.equal((await f.persisted()).timeEcho.episodes.length, 1);
        assert.doesNotMatch(JSON.stringify(recovery.exportGenerationRecovery(journal)), /fixture-only|secret-id|manualApiKey|connectionProfileId/);
    });
}

test('complete segment replays locally and only the missing segment uses the current profile model', async t => {
    const f = await fixture(t), bank = f.liveBank;
    const routes = [], service = f.ctx.ConnectionManagerRequestService, originalSend = service.sendRequest;
    service.sendRequest = async function(profileId, messages, length, options, overridePayload) {
        const profile = f.ctx.extensionSettings.connectionManager.profiles.find(row => row.id === profileId);
        const payload = { secret_id: profile['secret-id'], model: profile.model, ...overridePayload };
        routes.push({ profileId, model: payload.model || '', messages: structuredClone(messages) });
        return originalSend.call(this, profileId, messages, length, options, payload);
    };
    const origin = context.captureTaskOrigin(f.ctx, bank.archiveRevision);
    await client.beginModeRecovery('inbox', f.ctx, bank, origin);
    const options = (owner, slot) => ({ context: f.ctx, origin: owner, mode: 'inbox', taskKey: `snapshot:${slot}` });
    f.setResponse(good); await client.requestValidatedSegment('原始A {{char}}', 'A', options(origin, 'a'), validate);
    f.setResponse(fail); await assert.rejects(client.requestValidatedSegment('原始B {{char}}', 'B', options(origin, 'b'), validate));
    const old = cache.loadGenerationRecovery('inbox', f.ctx), first = structuredClone(old.segments[0]);
    recovery.detachGenerationRecovery(origin);
    settings.updatePluginSettings({ modelOverride: 'remaining-model', creativeSupplementEnabled: true, creativeSupplement: 'NEW_SUPPLEMENT' });
    f.ctx.powerUserSettings.persona_description = 'NEW_PERSONA';
    const next = context.captureTaskOrigin(f.ctx, bank.archiveRevision);
    await client.beginModeRecovery('inbox', f.ctx, bank, next, { existing: old });
    t.after(() => recovery.detachGenerationRecovery(next));
    f.setResponse(good);
    await client.requestValidatedSegment('当前重建A不得替换原A', 'A', options(next, 'a'), validate);
    await client.requestValidatedSegment('当前重建B不得替换原B', 'B', options(next, 'b'), validate);
    assert.equal(routes.length, 3);
    assert.equal(routes[2].model, 'remaining-model');
    assert.deepEqual(routes[2].messages, routes[1].messages);
    const saved = cache.loadGenerationRecovery('inbox', f.ctx);
    assert.deepEqual(saved.segments[0], first);
    assert.equal(saved.settingsHash, old.settingsHash);
    assert.deepEqual(saved.contentSnapshot, old.contentSnapshot);
});

for (const legacyRawSlots of [false, true]) test(`cross-revision real album continuation reuses its complete index and original pending request (${legacyRawSlots ? 'legacy raw fallback slots' : 'current slots'})`, async t => {
    const f = await fixture(t), originalIndex = structuredClone(f.ctx.extensionSettings[constants.ARCHIVE_INDEX_SETTINGS_KEY]);
    if (legacyRawSlots) f.ctx.extensionSettings[constants.ARCHIVE_INDEX_SETTINGS_KEY] = [];
    const oldTaskKey = coordinator.generationTaskKeyForMode('album', f.ctx);
    const index = { title: '原 A 相簿', entries: [{ id: 'CG01', title: '庭院旧画面', desc: '林舟站在庭院的花架旁。',
        date: '2008/05/18', category: '日常', unlocked: true, sourceMemoryIds: ['M001'], sourceMemoryAnchor: '庭院' }] };
    const relationship = { charState: '同伴', userState: '共同参与', relationshipState: '同伴', relationshipSummary: '两人在庭院一起栽花。',
        relationshipSourceMemoryIds: ['M001'], relationshipSourceMemoryAnchor: '庭院' };
    let resuming = false;
    f.setResponse(messages => {
        const text = messages.map(row => row.content).join('\n');
        if (text.includes('EXISTING_ALBUM_INDEX_JSON')) return index;
        if (!resuming) return fail();
        return text.includes('ALBUM_RELATIONSHIP_FULL_ARCHIVE_JSON') ? relationship : { items: [{ id: 'CG01',
            comments: Array.from({ length: 6 }, (_, i) => `这是已经完成的第${i + 1}句共同回忆，此刻正看着照片里的花架与光线。`) }] };
    });
    await client.generateMode('album', { background: true });
    assert.equal(f.requests.length, 2, JSON.stringify(f.notices));
    const stored = await f.persisted(), old = cache.loadGenerationRecovery('album', f.ctx, stored);
    assert.deepEqual(old.segments.map(row => row.state), ['complete', 'retry']);
    if (legacyRawSlots) {
        // Earlier released slots retained the code-owned raw scheduler prefix.
        // Restore only that serialization; prompt/hash/source remain untouched.
        for (const row of old.segments) row.slot = row.slot.replace('mode:@origin:album', oldTaskKey);
        stored[cache.GENERATION_DRAFTS_CACHE_KEY].records[old.draftId].journal = structuredClone(old);
    }
    const completed = structuredClone(old.segments[0]), originalPending = structuredClone(f.requests[1]);
    const bank = { ...structuredClone(f.liveBank), archiveRevision: 'new-current-revision', memories: [
        { id: 'M900', title: 'CURRENT_B_ONLY', summary: '林舟在海边读书。', anchors: ['海边'] } ] };
    const currentAlbum = { ...structuredClone(stored[cache.GENERATION_DRAFTS_CACHE_KEY].records[old.draftId].result.session),
        archiveRevision: bank.archiveRevision, title: '当前 B 相簿', entries: [{ id: 'B_CG', title: '当前 B 原内容' }],
        [constants.SESSION_MODE_WRITE_FENCE_KEY]: cache.modeWriteFenceForCache(stored, 'album') };
    delete currentAlbum.readableProgress;
    stored.archiveRevision = bank.archiveRevision; stored.album = currentAlbum;
    const record = structuredClone(f.records.get(f.aEntry.entryId));
    record.archiveRevision = bank.archiveRevision; record.memory = bank; record.cache = stored;
    f.records.set(f.aEntry.entryId, record);
    f.ctx.chatMetadata[constants.MEMORY_KEY] = structuredClone(bank); f.ctx.chatMetadata[constants.CACHE_KEY] = structuredClone(stored);
    f.ctx.extensionSettings[constants.ARCHIVE_INDEX_SETTINGS_KEY] = originalIndex;
    f.ctx.chat.push({ is_user: true, name: f.ctx.name1, mes: 'NEW_BODY_AFTER_ORIGINAL_TASK' });
    settings.updatePluginSettings({ modelOverride: 'remaining-new-model' });
    state.runtimeSessionCache.clear(); await cache.ensureCacheHydrated(f.ctx);
    resuming = true;
    await client.continueSavedGeneration('album', { draftId: old.draftId });
    assert.equal(f.requests.length, 4, 'only the failed relationship and previously unrequested comments may send');
    assert.equal(f.requests.filter(messages => messages.some(row => row.content.includes('EXISTING_ALBUM_INDEX_JSON'))).length, 1,
        'the completed original index must never be paid for again');
    assert.deepEqual(f.requests[2], originalPending, 'the pending request still uses its exact original input');
    assert.doesNotMatch(JSON.stringify(f.requests.slice(2)), /CURRENT_B_ONLY|NEW_BODY_AFTER_ORIGINAL_TASK/);
    const after = await f.persisted(), task = after[cache.GENERATION_DRAFTS_CACHE_KEY].records[old.draftId];
    assert.equal(task.status, 'awaiting-choice');
    assert.deepEqual(task.journal.segments[0], completed, 'replaying must not rewrite the old slot or request hash');
    assert.equal(task.journal.segments.length, 3);
    assert.equal(task.result.session.entries[0].comments.length, 6);
    assert.deepEqual(task.result.sourceMemory, old.contentSnapshot.memoryBank);
    const content = session => { const value = structuredClone(session); delete value[constants.SESSION_MODE_WRITE_FENCE_KEY]; return value; };
    assert.deepEqual(content(after.album), content(currentAlbum), 'a saved source-A result cannot replace current B before the user chooses');
});

test('API settings changed during a paid request do not discard its successful returned segment', async t => {
    const f = await fixture(t), origin = context.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision);
    await client.beginModeRecovery('inbox', f.ctx, f.liveBank, origin);
    t.after(() => recovery.detachGenerationRecovery(origin));
    f.setResponse(good); const pause = f.pauseProvider();
    const pending = client.requestValidatedSegment('PAID_ORIGINAL', 'fixture', { context: f.ctx, origin, mode: 'inbox', taskKey: 'paid:one' }, validate);
    await pause.ready;
    settings.updatePluginSettings({ modelOverride: 'next-request-model' });
    pause.release(); await assert.doesNotReject(pending);
    assert.equal(f.requests.length, 1);
    assert.equal(cache.loadGenerationRecovery('inbox', f.ctx).segments[0].state, 'complete');
});

test('new tasks read the latest content settings after the prior task is detached', async t => {
    const f = await fixture(t), first = context.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision);
    await client.beginModeRecovery('inbox', f.ctx, f.liveBank, first);
    f.setResponse(good);
    await client.requestValidatedSegment('BEFORE', 'fixture', { context: f.ctx, origin: first, mode: 'inbox', taskKey: 'fresh:one' }, validate);
    recovery.detachGenerationRecovery(first);
    settings.updatePluginSettings({ creativeSupplementEnabled: true, creativeSupplement: 'LATEST_POLICY_FOR_NEW_TASK' });
    f.ctx.powerUserSettings.persona_description = 'LATEST_PERSONA_FOR_NEW_TASK';
    const next = context.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision);
    await client.beginModeRecovery('inbox', f.ctx, f.liveBank, next, { existing: null });
    t.after(() => recovery.detachGenerationRecovery(next));
    await client.requestValidatedSegment('AFTER', 'fixture', { context: f.ctx, origin: next, mode: 'inbox', taskKey: 'fresh:one' }, validate);
    assert.match(JSON.stringify(f.requests[1]), /LATEST_POLICY_FOR_NEW_TASK/);
    assert.match(JSON.stringify(f.requests[1]), /LATEST_PERSONA_FOR_NEW_TASK/);
    assert.doesNotMatch(JSON.stringify(f.requests[0]), /LATEST_/);
});

test('automatic mode admission keeps an unfinished draft and sends no fresh request', async t => {
    const f = await fixture(t); f.setResponse(fail);
    await client.generateMode('timeEcho', { background: true });
    const retained = cache.loadGenerationRecovery('timeEcho', f.ctx);
    f.ctx.chat.push({ name: '小月', is_user: true, mes: 'LATEST_AUTOMATIC_MESSAGE' });
    const result = await client.generateMode('timeEcho', { automatic: true, background: true });
    assert.equal(result.status, 'noop'); assert.equal(f.requests.length, 1);
    assert.deepEqual(cache.loadGenerationRecovery('timeEcho', f.ctx), retained);
});

test('truncated actual request resumes its saved input with exactly one continuation block', async t => {
    const f = await fixture(t), service = f.ctx.ConnectionManagerRequestService;
    let truncated = true;
    service.sendRequest = async function(profileId, messages, length, options, overridePayload) {
        const profile = f.ctx.extensionSettings.connectionManager.profiles.find(row => row.id === profileId);
        const payload = { secret_id: profile['secret-id'], model: profile.model, ...overridePayload };
        assert.ok(payload.secret_id);
        f.requests.push(structuredClone(messages));
        return truncated ? { content: '{"value":"unfinished', finish_reason: 'length' } : { content: JSON.stringify(good) };
    };
    const first = context.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision);
    await client.beginModeRecovery('inbox', f.ctx, f.liveBank, first);
    const options = origin => ({ context: f.ctx, origin, mode: 'inbox', taskKey: 'truncated:one' });
    await assert.rejects(client.requestValidatedSegment('ORIGINAL_BASE {{char}}', 'fixture', options(first), validate), { code: 'RMT_JSON_TRUNCATED' });
    const old = cache.loadGenerationRecovery('inbox', f.ctx), original = f.requests[0][0].content;
    assert.equal(old.segments[0].state, 'truncated');
    recovery.detachGenerationRecovery(first);
    const next = context.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision);
    await client.beginModeRecovery('inbox', f.ctx, f.liveBank, next, { existing: old });
    t.after(() => recovery.detachGenerationRecovery(next));
    truncated = false;
    await client.requestValidatedSegment('LATEST_REBUILT_PROMPT', 'fixture', options(next), validate);
    assert.equal(f.requests.length, 2);
    const sent = f.requests[1][0].content;
    assert.ok(sent.startsWith(original));
    assert.equal((sent.match(/INCOMPLETE_SEGMENT_DATA_JSON:/g) || []).length, 1);
    assert.match(sent, /unfinished/);
    assert.doesNotMatch(sent, /LATEST_REBUILT_PROMPT/);
});

for (const [field, changed] of [['characterKey', 'another-character'], ['characterId', '22'],
    ['characterAvatar', 'another-avatar.png'], ['chatId', 'another-chat'], ['archiveTargetEntryId', 'another-entry']]) {
    test(`a pooled content snapshot cannot bypass ${field} ownership`, async t => {
        const f = await fixture(t), origin = context.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision);
        const handle = await client.beginModeRecovery('inbox', f.ctx, f.liveBank, origin);
        t.after(() => recovery.detachGenerationRecovery(origin));
        const saved = await f.persisted(), supplied = structuredClone(saved), id = handle.journal.draftId;
        supplied[cache.GENERATION_DRAFTS_CACHE_KEY].records[id].journal.identity[field] = changed;
        const untouched = structuredClone(supplied);
        assert.equal(cache.loadGenerationRecovery('inbox', f.ctx, supplied, { draftId: id }), null);
        assert.deepEqual(supplied, untouched);
        assert.deepEqual(await f.persisted(), saved);
        assert.equal(f.requests.length, 0);
    });
}

test('ordinary mode generation resumes an existing spring draft without an extra request or a lifecycle lock', async t => {
    const f = await fixture(t);
    await overlay.openCachedOrGenerate('heart', { workspaceRoute: 'heart' });
    const text = '我把手里的书放回原处，接着走向窗边。此刻想与你说说院子里新开的花，也想听你慢慢说今天的小事。'.repeat(3);
    const script = () => Array.from({ length: 8 }, () => ({ speaker: 'char', text }));
    const voice = () => ({ voiceDramas: [{ id: 'VO', kind: 'spring', title: '窗边的花', setting: '日常模拟', script: script() }] });
    const scene = () => ({ scenarioDramas: [{ id: 'SC', season: 'spring', title: '小院子', setting: '日常模拟', script: script() }] });
    const isVoice = messages => JSON.stringify(messages).includes('Voice Drama 新增一篇');
    f.setResponse(messages => isVoice(messages) ? { voiceDramas: [] } : scene());
    await heart.generateHeartSeasonSection('spring');
    assert.equal(f.requests.length, 2);
    const retained = cache.loadGenerationRecovery('heart', f.ctx, null, { pageId: 'spring' });
    assert.ok(retained);
    assert.equal(retained.segments.filter(row => row.state === 'complete').length, 1);
    const before = await f.persisted(), paidVoice = structuredClone(f.requests.find(isVoice));
    assert.deepEqual(coordinator.queryParticipantGenerationTasks(f.ctx), []);
    assert.equal(state.activeModeBuildScopes.size, 0);

    const noticeCount = f.notices.length;
    f.setResponse(messages => isVoice(messages) ? voice() : scene());
    // This is the ordinary module generation entry. It must discover and route
    // the retained subtask itself; do not bypass that route with continueSavedGeneration.
    await client.generateMode('heart', { background: true });

    assert.equal(f.requests.length, 3, 'only the one missing spring voice segment may use a provider request');
    assert.deepEqual(f.requests[2], paidVoice, 'the original spring recipe is continued, not the language module');
    const after = await f.persisted();
    assert.equal(after.heart.voiceDramas.length, 1);
    assert.deepEqual(after.heart.scenarioDramas, before.heart.scenarioDramas);
    assert.deepEqual(after.phone, before.phone);
    assert.deepEqual(after.cabinet, before.cabinet);
    assert.equal(cache.loadGenerationRecovery('heart', f.ctx, null, { draftId: retained.draftId }), null);
    assert.deepEqual(coordinator.queryParticipantGenerationTasks(f.ctx), []);
    assert.equal(state.activeModeBuildScopes.size, 0);
    assert.equal(state.activeGenerationTasks.size, 0);
    assert.ok(!f.notices.slice(noticeCount).some(row => /仍在处理|已经在生成|正在生成\/补齐/.test(row.message || '')));
});

test('real truncated mode exposes received text after reload without making it a completed session or changing continuation input', async t => {
    const f = await fixture(t), service = f.ctx.ConnectionManagerRequestService;
    const before = await f.persisted();
    const received = { title: echo.title, opening: echo.opening, medium: echo.medium, ends: echo.ends, lines: echo.lines };
    const partial = JSON.stringify(received).slice(0, -1) + ',"closing":"尚未返回的结尾';
    let truncated = true;
    service.sendRequest = async function(profileId, messages, length, options, overridePayload) {
        const profile = f.ctx.extensionSettings.connectionManager.profiles.find(row => row.id === profileId);
        const payload = { secret_id: profile['secret-id'], model: profile.model, ...overridePayload };
        assert.ok(payload.secret_id);
        f.requests.push(structuredClone(messages));
        return truncated ? { content: partial, finish_reason: 'length' } : { content: JSON.stringify(echo) };
    };
    await client.generateMode('timeEcho', { background: true });
    assert.equal(f.requests.length, 1);
    const draft = cache.loadGenerationRecovery('timeEcho', f.ctx);
    assert.equal(draft.segments[0].partial, partial);
    const saved = await f.persisted();
    assert.deepEqual(saved.timeEcho, before.timeEcho, 'the readable draft is not a completed canonical session');
    const result = await cache.readGenerationTaskResult(f.ctx, draft.draftId);
    assert.equal(result.session.readableProgress.complete, false);
    assert.equal(result.session.episodes[0].title, echo.title);
    assert.equal(result.session.episodes[0].opening, echo.opening);
    assert.deepEqual(result.session.episodes[0].lines, echo.lines);
    assert.equal(result.session.episodes[0].closing, '', 'an unfinished scalar never appears as received prose');
    assert.equal(cache.loadSession('timeEcho', { context: f.ctx, memoryBank: f.liveBank }), null,
        'generation reads the formal session only');

    state.runtimeSessionCache.clear(); state.activeSession = null; state.activeMode = null;
    await cache.ensureCacheHydrated(f.ctx);
    const readable = cache.loadSession('timeEcho', { context: f.ctx, memoryBank: f.liveBank, includePartial: true });
    assert.equal(readable.episodes[0].title, echo.title);
    assert.deepEqual(readable.episodes[0].lines, echo.lines);
    assert.equal(f.requests.length, 1, 'reload is local and makes no provider request');
    f.ctx.chat.push({ name: f.ctx.name1, is_user: true, mes: 'NEW_MESSAGE_FOR_ANOTHER_APPEND' });
    truncated = false;
    await client.continueSavedGeneration('timeEcho', { draftId: draft.draftId });
    assert.equal(f.requests.length, 2);
    const sent = f.requests[1][0].content;
    assert.ok(sent.startsWith(f.requests[0][0].content));
    assert.equal((sent.match(/INCOMPLETE_SEGMENT_DATA_JSON:/g) || []).length, 1);
    assert.doesNotMatch(sent, /NEW_MESSAGE_FOR_ANOTHER_APPEND/);
    assert.equal((await f.persisted()).timeEcho.episodes.length, 1);
    assert.equal(cache.loadGenerationRecovery('timeEcho', f.ctx, null, { draftId: draft.draftId }), null);
});

test('actual frozen historical character index preserves request bytes while snapshotting array holes as null', async t => {
    const f = await fixture(t);
    const target = await f.historical('inbox');
    const frozen = target.context, bank = target.archiveTarget.memory;
    assert.equal(frozen.characterId, 1);
    assert.equal(Object.hasOwn(frozen.characters, 0), false, 'fixture must use the real sparse freezeArchiveTarget context');
    const origin = context.captureTaskOrigin(frozen, bank.archiveRevision);
    const options = { context: frozen, origin, mode: 'inbox', taskKey: 'sparse-original:one' };
    f.setResponse(good);
    await client.requestValidatedSegment('相同请求 {{char}} 与 {{user}}', 'fixture', options, validate);
    const original = structuredClone(f.requests[0]);
    const handle = await client.beginModeRecovery('inbox', frozen, bank, origin, { ...target, existing: null });
    t.after(() => recovery.detachGenerationRecovery(origin));
    assert.equal(handle.journal.contentSnapshot.fields.characters[0], null);
    assert.equal(Object.hasOwn(frozen.characters, 0), false, 'the host frozen target retains its original sparse shape');
    await client.requestValidatedSegment('相同请求 {{char}} 与 {{user}}', 'fixture', { ...options, taskKey: 'sparse-saved:one' }, validate);
    assert.equal(f.requests.length, 2);
    assert.deepEqual(f.requests[1], original, 'snapshot serialization does not alter actual prompt bytes');
    assert.equal((await f.persisted(target.archiveTarget)).inbox, undefined);
});

// These cases use the production management and continuation entries. Only the
// host/provider/backend are synthetic; projection, identity, CAS and recovery run.
function partialManagedAchievement(title = '草稿中的栽花成就') {
    return { id: 'ACH01', title, description: '两人一同在庭院栽花。', category: '日常', tier: 'bronze',
        unlocked: true, unlockedAt: '已解锁', unlockCondition: '一起在庭院完成栽花', sourceMemoryIds: ['M001'], sourceMemoryAnchor: '庭院', hint: '' };
}

function partialManagedProvider(f) {
    let response = null;
    f.ctx.ConnectionManagerRequestService.sendRequest = async function(profileId, messages, length, options, overridePayload) {
        const profile = f.ctx.extensionSettings.connectionManager.profiles.find(row => row.id === profileId);
        const payload = { secret_id: profile['secret-id'], model: profile.model, ...overridePayload };
        assert.ok(payload.secret_id);
        f.requests.push(structuredClone(messages));
        const value = typeof response === 'function' ? await response(messages) : response;
        return { content: typeof value === 'string' ? value : JSON.stringify(value) };
    };
    return value => { response = value; };
}

async function makeManagedPartial(f, reply, options = {}, initialTitle) {
    const item = partialManagedAchievement(initialTitle);
    reply('{"entries":[' + JSON.stringify(item) + ',{"id":"NOT_CLOSED","title":"不得显示的尾部');
    await client.generateMode('achievements', { ...options, background: true });
    const ctx = options.context || f.ctx, bank = options.archiveTarget?.memory || f.liveBank;
    const stored = await f.persisted(options.archiveTarget || f.aEntry);
    const draft = cache.loadGenerationRecovery('achievements', ctx, stored);
    assert.ok(draft?.draftId, JSON.stringify(f.notices));
    assert.equal(draft.segments[0].state, 'truncated');
    const partial = cache.loadSession('achievements', { context: ctx, memoryBank: bank, cache: stored, includePartial: true });
    assert.equal(partial.entries[0].title, item.title);
    state.activeMode = 'achievements'; state.activeSession = partial;
    if (state.activeArchiveSnapshot) state.activeArchiveSnapshot.cache = structuredClone(stored);
    return { draft, partial, bank, ctx };
}

test('partial single-item regeneration changes its own draft, keeps same-ID formal content, and survives parent continuation', async t => {
    const manager = await import('../src/ui/contentManager.js');
    const f = await fixture(t), reply = partialManagedProvider(f);
    const { draft, partial } = await makeManagedPartial(f, reply);
    const parentJournal = structuredClone(draft);
    const formal = { kind: 'achievements', chatId: f.liveBank.chatId, archiveRevision: f.liveBank.archiveRevision,
        title: '原正式页面', entries: [partialManagedAchievement('FORMAL_SAME_ID_KEEP')] };
    await cache.commitSession('achievements', formal, f.liveBank.chatId, context.captureTaskOrigin(f.ctx, f.liveBank.archiveRevision));
    const before = await f.persisted();
    state.activeMode = 'achievements'; state.activeSession = partial;
    f.ctx.powerUserSettings.persona_description = 'NEW_PERSONA_MUST_NOT_ENTER_PARENT_SOURCE';
    settings.updatePluginSettings({ creativeSupplementEnabled: true, creativeSupplement: 'NEW_SUPPLEMENT_NOT_IN_PARENT' });
    const regenerated = partialManagedAchievement('单项重新生成后的栽花成就');
    reply({ entries: [regenerated] });
    const changed = await manager.runContentRegeneration('achievement', 'ACH01', '', { confirmed: true });
    assert.ok(changed, JSON.stringify(f.notices));
    assert.equal(f.requests.length, 2, 'one parent request and one existing single-item request');
    const after = await f.persisted();
    const formalContent = session => { const copy = structuredClone(session); delete copy[constants.SESSION_MODE_WRITE_FENCE_KEY]; return copy; };
    assert.deepEqual(formalContent(after.achievements), formalContent(before.achievements), 'the same-ID formal entry is not the target');
    assert.equal(after.achievements[constants.SESSION_MODE_WRITE_FENCE_KEY], cache.modeWriteFenceForCache(after, 'achievements'),
        'the existing mode admission advances its concurrency fence without editing formal content');
    assert.deepEqual(after[cache.GENERATION_DRAFTS_CACHE_KEY].records[draft.draftId].journal, parentJournal,
        'a child journal must not overwrite its paid parent journal');
    const result = await cache.readGenerationTaskResult(f.ctx, draft.draftId);
    assert.equal(result.session.entries[0].title, regenerated.title);
    assert.equal(result.session.readableProgress.complete, false);
    assert.doesNotMatch(JSON.stringify(f.requests[1]), /FORMAL_SAME_ID_KEEP|NEW_PERSONA_MUST_NOT|NEW_SUPPLEMENT_NOT/);
    assert.match(JSON.stringify(f.requests[1]), /草稿中的栽花成就/);

    state.runtimeSessionCache.clear(); state.activeSession = null; state.activeMode = null;
    await cache.ensureCacheHydrated(f.ctx);
    assert.equal(cache.loadSession('achievements', { context: f.ctx, memoryBank: f.liveBank, includePartial: true }).entries[0].title, regenerated.title);
    reply({ entries: [partialManagedAchievement()] });
    await client.continueSavedGeneration('achievements', { draftId: draft.draftId });
    assert.equal(f.requests.length, 3, 'continuing the unfinished parent uses only its original missing request');
    const complete = await f.persisted();
    assert.equal(complete.achievements.entries[0].title, regenerated.title, 'later parent projection and full commit keep the explicit override');
    assert.equal(complete.achievements.readableProgress, undefined, 'only the completed parent can make a formal page');
    assert.ok(f.requests[2][0].content.startsWith(f.requests[0][0].content));
    assert.equal((f.requests[2][0].content.match(/INCOMPLETE_SEGMENT_DATA_JSON:/g) || []).length, 1);
});

test('partial-only content child resumes its original source after reopen and API change without a formal page', async t => {
    const manager = await import('../src/ui/contentManager.js');
    const f = await fixture(t), reply = partialManagedProvider(f);
    const { draft } = await makeManagedPartial(f, reply);
    reply(fail);
    assert.equal(await manager.runContentRegeneration('achievement', 'ACH01', '', { confirmed: true }), null);
    assert.equal(f.requests.length, 2);
    const child = cache.listGenerationDrafts(f.ctx, null, 'achievements').find(row => row.journal.operation?.sourceDraftId === draft.draftId);
    assert.ok(child?.journal, JSON.stringify(f.notices));
    assert.equal((await f.persisted()).achievements, undefined);
    const sourceSnapshot = structuredClone(child.journal.contentSnapshot);
    const sent = structuredClone(f.requests[1]);
    state.runtimeSessionCache.clear(); state.activeSession = null; state.activeMode = null;
    await cache.ensureCacheHydrated(f.ctx);
    f.ctx.powerUserSettings.persona_description = 'NEW_PERSONA_AFTER_CHILD_FAILURE';
    settings.updatePluginSettings({ modelOverride: 'new-remaining-provider-model', creativeSupplementEnabled: true,
        creativeSupplement: 'NEW_CHILD_SETTINGS_MUST_NOT_REPLACE_SOURCE' });
    reply({ entries: [partialManagedAchievement('子任务继续后完成')] });
    await client.continueSavedGeneration('achievements', { draftId: child.draftId });
    assert.equal(f.requests.length, 3);
    assert.deepEqual(f.requests[2], sent, 'transport changes do not rebuild the child prompt from current materials');
    const parent = await cache.readGenerationTaskResult(f.ctx, draft.draftId);
    assert.equal(parent.session.entries[0].title, '子任务继续后完成');
    assert.equal((await f.persisted()).achievements, undefined);
    assert.deepEqual(parent.sourceMemory, sourceSnapshot.memoryBank);
    assert.ok(cache.loadGenerationRecovery('achievements', f.ctx, null, { draftId: draft.draftId }), 'parent remains resumable');
    assert.equal(cache.loadGenerationRecovery('achievements', f.ctx, null, { draftId: child.draftId }), null, 'only the committed child is closed');
});

test('historical writable partial single-item regeneration uses target B source and never edits live A', async t => {
    const manager = await import('../src/ui/contentManager.js');
    const f = await fixture(t), reply = partialManagedProvider(f);
    const liveBefore = await f.persisted();
    const target = await f.historical('achievements');
    const { draft } = await makeManagedPartial(f, reply, target);
    reply({ entries: [partialManagedAchievement('历史B单项完成')] });
    const changed = await manager.runContentRegeneration('achievement', 'ACH01', '', { confirmed: true });
    assert.ok(changed, JSON.stringify(f.notices));
    assert.equal(f.requests.length, 2);
    assert.match(JSON.stringify(f.requests[1]), /沈砚|CARD_B_ONLY/);
    assert.doesNotMatch(JSON.stringify(f.requests[1]), /CARD_A_ONLY|WORLD_A_ONLY/);
    assert.deepEqual(await f.persisted(), liveBefore);
    const storedB = await f.persisted(f.bEntry), parent = storedB[cache.GENERATION_DRAFTS_CACHE_KEY].records[draft.draftId];
    assert.equal(parent.result.session.entries[0].title, '历史B单项完成');
    assert.equal(parent.result.sourceMemory.characterName, '沈砚');
    assert.equal(storedB.achievements, undefined);
});

for (const historical of [false, true]) test(`single-item received prose is independently readable after reload ${historical ? 'in historical B without switching to A' : 'in the live archive'}`, async t => {
    const manager = await import('../src/ui/contentManager.js');
    const library = await import('../src/archive/library.js');
    const recoveryView = await import('../src/ui/recoveryView.js');
    const f = await fixture(t), reply = partialManagedProvider(f);
    const liveBefore = await f.persisted();
    const target = historical ? await f.historical('achievements') : {};
    const snapshot = state.activeArchiveSnapshot;
    const { draft, bank, ctx } = await makeManagedPartial(f, reply, target);
    const entry = historical ? f.bEntry : f.aEntry;
    const parentBefore = (await f.persisted(entry))[cache.GENERATION_DRAFTS_CACHE_KEY].records[draft.draftId];
    const prose = '  已收到的第一段。\n\n第二段保留空行与 <花架> & 原文。  ';
    const raw = '{"entries":[{"id":"ACH01","title":"正在重写的成就","description":' + JSON.stringify(prose) + ',"hint":"不可展示的半截尾句';
    reply(raw);
    assert.equal(await manager.runContentRegeneration('achievement', 'ACH01', '', { confirmed: true }), null);
    assert.equal(f.requests.length, 2, 'only the requested parent and single-item generations call the provider');
    const saved = await f.persisted(entry);
    const child = cache.listGenerationDrafts(ctx, saved, 'achievements').find(row => row.journal.operation?.sourceDraftId === draft.draftId);
    assert.ok(child?.journal, JSON.stringify(f.notices));
    assert.equal(child.journal.segments[0].state, 'truncated');
    assert.equal(child.journal.segments[0].partial, raw, 'the original partial reply is retained verbatim');
    assert.deepEqual(saved[cache.GENERATION_DRAFTS_CACHE_KEY].records[draft.draftId], parentBefore,
        'received child prose does not replace or rewrite any part of its paid parent');
    assert.equal(saved.achievements, undefined, 'a readable child cannot become a completed formal page');
    const banner = recoveryView.recoveryBannerHtml(saved, bank);
    assert.ok(banner.includes(`data-rmt-content-draft-open="${child.draftId}"`));

    state.runtimeSessionCache.clear(); state.activeSession = null; state.activeMode = null;
    await cache.ensureCacheHydrated(f.ctx);
    const providerCount = f.requests.length, sourceReads = f.reads.length;
    const opened = await library.openContentRegenerationDraft(child.draftId, f.ctx, { snapshot });
    assert.equal(opened.draftId, child.draftId);
    assert.equal(f.requests.length, providerCount, 'reading saved prose sends no generation request');
    assert.equal(f.reads.length, sourceReads, 'reading uses the saved local checkpoint, not a refreshed host source');
    assert.ok(f.body.innerHTML.includes(`data-rmt-content-draft-reader="${child.draftId}"`));
    assert.ok(f.body.innerHTML.includes('data-rmt-content-draft-field="/entries/0/description"'));
    assert.ok(f.body.innerHTML.includes('  已收到的第一段。\n\n第二段保留空行与 &lt;花架&gt; &amp; 原文。  '));
    assert.match(f.body.innerHTML, /white-space:pre-wrap/);
    assert.doesNotMatch(f.body.innerHTML, /不可展示的半截尾句|不得显示的尾部|<花架>|sourceMemoryIds|requestRecipe/);
    assert.equal(state.activeArchiveSnapshot, snapshot, 'reading keeps the exact historical target instead of substituting live A');
    assert.equal(state.activeMode, null);
    assert.equal(state.activeSession, null);
    assert.deepEqual(await f.persisted(entry), saved, 'the reader does not edit stored parent or child content');
    if (historical) {
        assert.equal(state.activeArchiveSnapshot.memory.characterName, '沈砚');
        assert.deepEqual(await f.persisted(), liveBefore, 'historical B reading leaves live A untouched');
    }
});

for (const historical of [false, true]) test(`whole-page generation resumes its parent rather than a newer failed one-item child ${historical ? 'in historical B' : 'in the live archive'}`, async t => {
    const manager = await import('../src/ui/contentManager.js');
    const f = await fixture(t), reply = partialManagedProvider(f);
    const liveBefore = await f.persisted();
    const target = historical ? await f.historical('achievements') : {};
    // This routing test must not depend on overwriting already validated prose.
    // The separate r8429 regression asserts that such rewrites are retained, not replaced.
    const { draft, ctx } = await makeManagedPartial(f, reply, target, '父任务完整成果');
    const entry = historical ? f.bEntry : f.aEntry;
    reply(fail);
    assert.equal(await manager.runContentRegeneration('achievement', 'ACH01', '', { confirmed: true }), null);
    const before = await f.persisted(entry);
    const child = cache.listGenerationDrafts(ctx, before, 'achievements').find(row => row.journal.operation?.sourceDraftId === draft.draftId);
    assert.ok(child?.journal, JSON.stringify(f.notices));
    assert.equal(cache.loadGenerationRecovery('achievements', ctx, before).draftId, child.draftId,
        'fixture must reproduce the newer child chosen by the previous default loader');
    assert.equal(child.pageId, draft.pageId);
    reply({ entries: [partialManagedAchievement('父任务完整成果')] });
    // This is the actual full-page/toolbar generation entry, with no draft ID.
    await client.generateMode('achievements', { ...target, background: false });
    assert.equal(f.requests.length, 3, 'only the original parent missing segment is requested');
    assert.ok(f.requests[2][0].content.startsWith(f.requests[0][0].content));
    assert.equal((f.requests[2][0].content.match(/INCOMPLETE_SEGMENT_DATA_JSON:/g) || []).length, 1);
    assert.doesNotMatch(f.requests[2][0].content, /CURRENT_ACHIEVEMENT_JSON:/);
    const after = await f.persisted(entry);
    assert.equal(after.achievements.entries[0].title, '父任务完整成果');
    assert.equal(after.achievements.readableProgress, undefined);
    assert.equal(cache.loadGenerationRecovery('achievements', ctx, after, { draftId: draft.draftId }), null);
    assert.deepEqual(after[cache.GENERATION_DRAFTS_CACHE_KEY].records[child.draftId], before[cache.GENERATION_DRAFTS_CACHE_KEY].records[child.draftId],
        'the paid one-item child is not overwritten or silently discarded');
    if (historical) assert.deepEqual(await f.persisted(), liveBefore);
});
