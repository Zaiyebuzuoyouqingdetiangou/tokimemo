// Test-only IndexedDB boundary: queued transactions, request callbacks and atomic
// commit/abort. Unlike a plain Map backend, a failed Nth put rolls back prior puts.
export function relayIndexedDB() {
    const rows = new Map(), queue = [];
    let running = false;
    const control = { failWrite: 0, beforeCommit: null };
    const copy = value => value === undefined ? undefined : structuredClone(value);
    function drain() {
        if (running || !queue.length) return;
        running = true;
        queue.shift()();
    }
    const db = { objectStoreNames: { contains: () => true }, close() {}, transaction(_name, mode) {
        let active = true, done = false, started = false, shadow, writes = 0;
        const requests = [];
        const tx = { error: null, abort() {
            if (done) return;
            done = true;
            tx.error ||= new DOMException('Aborted', 'AbortError');
            setTimeout(() => { tx.onabort?.(); running = false; drain(); }, 0);
        } };
        function request(run) {
            if (!active || done) throw new DOMException('Inactive', 'TransactionInactiveError');
            const r = {};
            requests.push({ r, run });
            return r;
        }
        const store = {
            get: key => request(() => copy(shadow.get(key))),
            getAll: () => request(() => [...shadow.values()].map(copy)),
            index: name => ({ getAll: key => request(() => [...shadow.values()].filter(row => row[name] === key).map(copy)) }),
            put: row => { const frozen = copy(row); return request(() => {
                if (mode !== 'readwrite') throw new DOMException('Read only', 'ReadOnlyError');
                writes++;
                if (control.failWrite && writes === control.failWrite) {
                    control.failWrite = 0;
                    throw new DOMException('Full', 'QuotaExceededError');
                }
                shadow.set(frozen.entryId, frozen); return frozen.entryId;
            }); },
            delete: key => request(() => { shadow.delete(key); }),
        };
        tx.objectStore = () => store;
        function tick() {
            if (done) return;
            const next = requests.shift();
            if (!next) {
                control.beforeCommit?.(tx);
                if (done) return;
                if (mode === 'readwrite') { rows.clear(); for (const [key, value] of shadow) rows.set(key, value); }
                done = true;
                tx.oncomplete?.(); running = false; drain(); return;
            }
            active = true;
            try { next.r.result = next.run(); next.r.onsuccess?.(); }
            catch (error) { next.r.error = error; tx.error = error; next.r.onerror?.(); tx.abort(); }
            active = false;
            if (!done) setTimeout(tick, 0);
        }
        queue.push(() => { started = true; shadow = new Map([...rows].map(([k, v]) => [k, copy(v)])); setTimeout(tick, 0); });
        setTimeout(() => { active = false; if (!started) drain(); }, 0);
        return tx;
    } };
    return { rows, control, open() {
        const r = {}; setTimeout(() => { r.result = db; r.onsuccess?.(); }, 0); return r;
    } };
}
