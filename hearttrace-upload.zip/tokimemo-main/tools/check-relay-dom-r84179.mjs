// Optional DOM integration check. Uses the shipped bundle, Happy DOM, and the
// transaction fixture; not a claim of native IndexedDB or iPhone/TT validation.
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import { relayIndexedDB } from './relay-idb-fixture.mjs';
const { Window } = await import(pathToFileURL(process.env.HAPPY_DOM_PATH).href);
const window = new Window({ url: 'https://localhost/' }), document = window.document;
const body = document.createElement('main'); document.body.append(body);
const errors = [], downloads = [];
const host = { characterId: 0, name1: 'User', name2: 'Char', chatId: 'A',
    characters: [{ name: 'Char', avatar: 'char.png', data: { name: 'Char', description: 'fixture' } }],
    chat: [{ is_user: false, mes: '一起看书' }], chatMetadata: {}, extensionSettings: {},
    getCurrentChatId() { return this.chatId; }, saveMetadata: async () => {}, saveMetadataDebounced: async () => {}, saveSettingsDebounced() {} };
const sandbox = vm.createContext({ console, document, window, navigator: window.navigator,
    location: window.location, SillyTavern: { getContext: () => host }, indexedDB: relayIndexedDB(),
    TextEncoder, TextDecoder, URL, URLSearchParams, Blob, Response, CompressionStream, DecompressionStream,
    AbortController, DOMException, crypto: globalThis.crypto, performance, queueMicrotask,
    setTimeout: (fn, ms) => { const timer = setTimeout(fn, ms); timer.unref?.(); return timer; }, clearTimeout,
    setInterval, clearInterval, btoa, atob,
    toastr: { error: value => errors.push(value), info() {}, success() {}, warning() {} } });
vm.runInContext('structuredClone = v => v === undefined ? undefined : JSON.parse(JSON.stringify(v))', sandbox);
const source = await readFile(new URL('../dist/heartbeatMemories.bundle.js', import.meta.url), 'utf8');
const paths = [...source.matchAll(/^\/\/ MODULE: (.+)$/gm)].map(m => m[1]);
const expose = '\nexport const modules = {' + paths.map(p => JSON.stringify(p) + ':__m_' + p.replace(/[^a-zA-Z0-9]/g, '_')).join(',') + '};';
const module = new vm.SourceTextModule(source + expose, { context: sandbox });
await module.link(() => { throw new Error('Unexpected external import'); }); await module.evaluate();
const m = module.namespace.modules, backup = m['archive/backupStore.js'], cache = m['core/cache.js'];
const groups = m['archive/groups.js'], constants = m['core/constants.js'], ui = m['ui/archiveRelayView.js'];
m['ui/overlay.js'].bodyEl = () => body;
let returnedToLibrary = 0; m['archive/library.js'].showArchiveLibrary = async () => { returnedToLibrary++; };
window.HTMLAnchorElement.prototype.click = function () { downloads.push(this.download); };
const memory = { version: 3, chatId: 'A', archiveRevision: 'A1', archiveName: '<A & B>',
    characterName: 'Char', userName: 'User', memories: [{ id: 'M100', title: '书页', summary: '读书', anchors: ['书'] }] };
host.chatMetadata[constants.MEMORY_KEY] = memory; groups.upsertArchiveIndex(host, memory);
const entry = groups.getArchiveIndex(host)[0];
await backup.seedArchiveBackup(entry, memory, { chatId: 'A', archiveRevision: 'A1' });
m['archive/library.js'].fetchIndexedArchiveSnapshot = async row => {
    const saved = await backup.readArchiveBackupState(row);
    return { ...row, memory: saved.record.memory, cache: saved.record.cache, backupOnly: false };
};
host.chatId = 'B'; host.chatMetadata = { [constants.MEMORY_KEY]: { ...memory, chatId: 'B', archiveRevision: 'B0', archiveName: 'B自己的' } };
body.innerHTML = ui.archiveRelayEntryHtml(host);
const click = async action => {
    const button = body.querySelector('[data-rmt-action="' + action + '"]');
    assert.ok(button, 'button ' + action); await ui.handleArchiveRelayAction(button, action);
};
await click('archive-relay-open');
assert.equal(body.querySelectorAll('[data-rmt-relay-entry]').length, 1);
await click('archive-relay-preview');
assert.ok(body.textContent.includes('<A & B>'), 'archive label escaped, not HTML');
assert.ok(body.querySelector('[data-rmt-relay-replace-confirm]'));
await click('archive-relay-confirm');
assert.equal(errors.length, 1); assert.equal(host.chatMetadata[constants.MEMORY_KEY].archiveRevision, 'B0');
await click('archive-relay-export-target');
assert.deepEqual(downloads, ['hearttrace-before-relay.json']);
body.querySelector('[data-rmt-relay-replace-confirm]').checked = true;
await click('archive-relay-confirm');
assert.equal(errors.length, 1); assert.equal(returnedToLibrary, 1);
assert.equal(host.chatMetadata[constants.MEMORY_KEY].memories[0].id, 'M100');
assert.equal(host.chatMetadata[constants.MEMORY_KEY].chatId, 'B');
host.chatId = 'A'; host.chatMetadata = { [constants.MEMORY_KEY]: memory };
await cache.ensureCurrentArchiveBackup(host);
body.innerHTML = ui.archiveRelayEntryHtml(host);
assert.ok(body.textContent.includes('已交给 B 继续'));
assert.ok(body.querySelector('[data-rmt-action="archive-relay-preview"]'));
assert.equal(m['archive/librarySnapshots.js'].requireWritableArchiveAction(), false);
await click('archive-relay-preview'); await click('archive-relay-confirm');
assert.equal(errors.length, 1); assert.equal(host.chatMetadata[constants.MEMORY_KEY].chatId, 'A');
console.log(JSON.stringify({ ok: true, checks: ['candidate picker', 'escaped labels', 'occupied target protected', 'backup download', 'explicit handoff', 'readonly A', 'handback'], nativeBrowser: false }));
await window.happyDOM.close();
