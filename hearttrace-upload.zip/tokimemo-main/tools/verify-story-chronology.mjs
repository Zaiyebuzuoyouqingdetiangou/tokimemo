// Real shipped index -> bundle, real browser/IndexedDB; synthetic host/provider.
// No source imports or live API calls. Optional STORY_BASELINE_ROOT exercises an
// old-bundle draft followed by an actual page reload into this candidate bundle.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import http from 'node:http';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const { chromium } = createRequire(import.meta.url)('playwright');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const output = path.resolve(process.env.STORY_OUTPUT_DIR || path.join(root, 'artifacts/story-chronology'));
const baseline = process.env.STORY_BASELINE_ROOT && path.resolve(process.env.STORY_BASELINE_ROOT);
const prefix = '/scripts/extensions/third-party/hearttrace/';
const build = JSON.parse(await readFile(path.join(root, 'manifest.json'), 'utf8')).js;
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const bundleSha256 = sha(await readFile(path.join(root, 'dist/heartbeatMemories.bundle.js')));
const baselineBundleSha256 = baseline && sha(await readFile(path.join(baseline, 'dist/heartbeatMemories.bundle.js')));
const comments = Array.from({ length: 6 }, (_, i) => `第${i + 1}句：我记得那天在庭院看花，风吹过枝头，花瓣停在衣袖上。`);
const dates = ['2025/09/20', '待定', '2025/09/10', '2025/09/10', '2025/09/30', '2025/09/05', '2025/09/15', '2025/09/01'];
function makeSeed(kind, width) {
    const chatId = `chronology-${kind}-${width}`, revision = `${chatId}-revision`;
    const memories = dates.map((date, i) => ({ id: `M00${i + 1}`, title: `庭院回忆${i + 1}`, date,
        summary: `林舟和小月在庭院${i + 1}看花。`, anchors: [`庭院${i + 1}`], participants: ['林舟', '小月'] }));
    const entries = dates.map((date, i) => ({ id: `CG0${i + 1}`, title: `庭院相片${i + 1}`, date,
        desc: `第${i + 1}张旧画面。`, category: '日常', unlocked: true, sourceMemoryIds: [`M00${i + 1}`], sourceMemoryAnchor: `庭院${i + 1}`,
        visualSeed: ['庭院', '花瓣', '人物', '光线'], imagePrompt: `garden scene ${i + 1}`, comments: comments.map(line => `${i + 1}：${line}`),
        cgImage: { url: `/user/images/fixture/old-${i + 1}.png`, prompt: `OLD_IMAGE_${i + 1}`, provider: 'baibai-image', generatedAt: 1 } }));
    const bank = { version: 3, chatId, archiveRevision: revision, characterName: '林舟', userName: '小月',
        archiveName: '庭院旧相簿', archiveSummary: '旧的庭院记忆。', createdAt: 1, updatedAt: 1, memories };
    const album = { kind: 'album', chatId, archiveRevision: revision, title: '回忆相簿', entries: entries.slice(0, 7),
        selectedId: 'CG01', category: '全部', page: 1, pageSize: 6,
        generationMeta: { parts: { mode: { coveredMemoryIds: memories.slice(0, 7).map(row => row.id), archiveRevision: revision, updatedAt: 1 } } } };
    return { chatId, bank, album, kind, phase: 'start',
        index: { title: '回忆相簿', entries: [{ ...entries[7], cgImage: undefined, comments: undefined }] },
        relationship: { charState: '一起看花', userState: '一起看花', relationshipState: '同伴', relationshipSummary: '共同看花的同伴。',
            relationshipSourceMemoryIds: ['M008'], relationshipSourceMemoryAnchor: '庭院8' },
        comments: { items: [{ id: 'CG08', comments }] } };
}
function host(seed) {
    return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body><div id="extensions_settings2"></div><div id="extensionsMenu"></div><script>
const seed=${JSON.stringify(seed).replace(/</g, '\\u003c')},copy=v=>v==null?v:JSON.parse(JSON.stringify(v));
const key='story-host',callKey='story-calls',calls=JSON.parse(localStorage.getItem(callKey)||'[]'),notices=[];
const profile={id:'story-fixture',name:'Synthetic',mode:'cc',api:'openai',model:'fixture-model','secret-id':'synthetic-only'};
const context={characterId:0,groupId:null,chatId:seed.chatId,name1:'小月',name2:'林舟',
 characters:[{name:'林舟',avatar:'fixture.png',data:{name:'林舟',description:'庭院里的角色。',personality:'认真'}}],
 chat:[{is_user:true,name:'小月',mes:'林舟和小月在庭院看花。'}],powerUserSettings:{persona_description:'一起看花的同伴。'},
 chatMetadata:JSON.parse(localStorage.getItem(key)||JSON.stringify({heartbeatMemoriesArchiveV3:seed.bank,
  heartbeatMemoriesTheaterV3:{chatId:seed.chatId,archiveRevision:seed.bank.archiveRevision,album:seed.album}})),
 extensionSettings:{heartbeatMemories:{apiConnectionMode:'profile',connectionProfileId:profile.id,useCurrentChatExternalMemory:false,
  useActivatedWorldInfo:false,maxTokens:12000},connectionManager:{profiles:[profile]}},
 getCurrentChatId(){return this.chatId},getCharacterCardFields(){return copy(this.characters[0].data)},
 getRequestHeaders:()=>({'Content-Type':'application/json'}),getTokenCountAsync:async()=>100,
 saveMetadataDebounced(){localStorage.setItem(key,JSON.stringify(context.chatMetadata))},saveSettingsDebounced(){},
 eventTypes:{},eventSource:{on(){},off(){}},ConnectionManagerRequestService:{validateProfile:()=>({selected:'openai',source:'openai'}),
 async sendRequest(profileId,messages,outputTokens,options,overridePayload){
  const payload={model:profile.model,secret_id:profile['secret-id'],...overridePayload};
  const prompt=messages.map(row=>String(row.content||'')).join('\\n');
  const stage=prompt.includes('UNTRUSTED_ALBUM_COMMENT_CONTEXT_JSON')?'comments':prompt.includes('ALBUM_RELATIONSHIP_FULL_ARCHIVE_JSON')?'relationship':prompt.includes('UNTRUSTED_INCREMENTAL_CG_ARCHIVE_JSON')?'index':'unexpected';
  calls.push({stage,messages:copy(messages),outputTokens,payload:copy(payload)});localStorage.setItem(callKey,JSON.stringify(calls));
  if(stage==='unexpected')throw new Error('Unexpected provider request');
  if(seed.kind==='upgrade'&&seed.phase==='start'&&stage==='relationship')throw Object.assign(new Error('Synthetic failure after saved index'),{status:400,code:'RMT_MANUAL_HTTP'});
  return {content:JSON.stringify(seed[stage])};
 }}};
globalThis.SillyTavern={getContext:()=>context};globalThis.confirm=()=>true;
globalThis.toastr=Object.fromEntries(['error','warning','info','success'].map(level=>[level,(...values)=>notices.push({level,text:values.map(String).join(' ')})]));
async function decode(v){return v?.format==='gzip-base64-v1'?JSON.parse(await new Response(new Blob([Uint8Array.from(atob(v.data),x=>x.charCodeAt(0))]).stream().pipeThrough(new DecompressionStream('gzip'))).text()):copy(v)}
async function snapshot(){return {bank:copy(context.chatMetadata.heartbeatMemoriesArchiveV3),cache:await decode(context.chatMetadata.heartbeatMemoriesTheaterV3)}}
async function canonical(){const db=await new Promise((resolve,reject)=>{const r=indexedDB.open('heartbeatMemoriesArchiveBackupsV1');r.onerror=()=>reject(r.error);r.onupgradeneeded=()=>{r.transaction.abort();reject(new Error('Database missing'))};r.onsuccess=()=>resolve(r.result)});
 try{const rows=await new Promise((resolve,reject)=>{const r=db.transaction('archives').objectStore('archives').getAll();r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)});
 const row=rows.find(row=>row.chatId===seed.chatId&&!row.deleted);if(!row)throw new Error('Archive missing');return {bank:copy(row.memory),cache:await decode(row.cache)}}finally{db.close()}}
globalThis.__fixture={calls,notices,snapshot,canonical};
</script><script type="module" src="${prefix}${build}"></script></body></html>`;
}
let activeSeed, runtimeRoot = root;
const requests = [];
const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aH9sAAAAASUVORK5CYII=', 'base64');
const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://127.0.0.1'); res.setHeader('Cache-Control', 'no-store');
    if (url.pathname.startsWith(prefix)) {
        const relative = decodeURIComponent(url.pathname.slice(prefix.length));
        const file = path.resolve(runtimeRoot, relative);
        if (!file.startsWith(runtimeRoot + path.sep) || relative.startsWith('src/')) { res.writeHead(403); res.end(); return; }
        try { const bytes = await readFile(file); requests.push({ path: relative, sha256: sha(bytes) }); res.setHeader('Content-Type', 'text/javascript'); res.end(bytes); }
        catch { res.writeHead(404); res.end(); } return;
    }
    if (url.pathname.startsWith('/user/images/fixture/') || url.pathname==='/thumbnail' || url.pathname==='/characters/fixture.png') { res.setHeader('Content-Type','image/png'); res.end(png); return; }
    if (url.pathname === '/favicon.ico') { res.writeHead(204); res.end(); return; }
    if (url.pathname === '/') { res.setHeader('Content-Type','text/html; charset=utf-8'); res.end(host(activeSeed)); return; }
    requests.push({ unexpected: url.pathname }); res.writeHead(500); res.end('No real host API');
});
const results = [];
let browser;
async function openAlbum(page) {
    await page.locator('#heartbeat_memories_menu_item').click();
    await page.locator('.rmt-workspace-tabs [data-rmt-workspace-tab="content"]').click();
    await page.locator('[data-rmt-workspace-group="memory"]').click();
    await page.locator('[data-rmt-workspace-route="album"]').click();
    await page.locator('.rmt-album').waitFor();
}
const cardIds = page => page.locator('[data-rmt-album-id]').evaluateAll(nodes=>nodes.map(node=>node.dataset.rmtAlbumId));
const expectedOld = ['CG06', 'CG02', 'CG03', 'CG04', 'CG07', 'CG01'];
async function waitForSavedAlbum(page) {
    const deadline=Date.now()+15000;
    while(Date.now()<deadline) {
        const saved=await page.evaluate(async()=>{try{return (await __fixture.canonical()).cache.album.entries.length===8}catch{return false}});
        if(saved)return;
        await new Promise(resolve=>setTimeout(resolve,100));
    }
    assert.fail('Timed out waiting for the eight saved album entries');
}
try {
    await mkdir(output, { recursive:true });
    await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
    const origin = `http://127.0.0.1:${server.address().port}`;
    browser = await chromium.launch({headless:true,executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || chromium.executablePath()});
    const cases=(process.env.STORY_CASES || (baseline?'existing,incremental,upgrade':'existing,incremental')).split(',');
    for (const width of [390,1280]) for (const kind of cases) {
        assert.ok(['existing','incremental','upgrade'].includes(kind));
        if(kind==='upgrade')assert.ok(baseline,'STORY_BASELINE_ROOT required');
        activeSeed=makeSeed(kind,width); runtimeRoot=kind==='upgrade'?baseline:root;
        requests.length=0;
        const result={kind,width,passed:false,pageErrors:[],external:[]};results.push(result);
        const context=await browser.newContext({viewport:{width,height:900}}),page=await context.newPage();page.setDefaultTimeout(15000);
        page.on('pageerror',e=>result.pageErrors.push(e.message));
        await context.route('**/*',route=>{if(new URL(route.request().url()).origin===origin)return route.continue();result.external.push(route.request().url());return route.abort()});
        try {
            await page.goto(origin);await page.locator('#heartbeat_memories_menu_item').waitFor();await openAlbum(page);
            if(kind==='existing') {
                assert.deepEqual(await cardIds(page),expectedOld);
                await page.locator('[data-rmt-action="album-next"]').click();
                await page.waitForFunction(()=>document.querySelector('[data-rmt-album-id]')?.dataset.rmtAlbumId==='CG05');
                assert.deepEqual(await cardIds(page),['CG05']);
                await page.locator('[data-rmt-action="album-prev"]').click();
                await page.waitForFunction(()=>document.querySelector('[data-rmt-album-id]')?.dataset.rmtAlbumId==='CG06');
                await page.locator('[data-rmt-album-memory="CG01"]').click();
                assert.ok((await page.locator('body').innerText()).includes(activeSeed.album.entries[0].comments[0]));
                assert.ok(await page.locator('img[src*="old-1.png"]').count());
                await page.locator('[data-rmt-action="shared-back"]').click();
                assert.deepEqual((await page.evaluate(()=>__fixture.snapshot())).bank,activeSeed.bank);
                assert.equal((await page.evaluate(()=>__fixture.calls)).length,0);
            } else {
                await page.locator('#heartbeat_memories_overlay [data-rmt-action="regenerate"]').click();
                if(kind==='upgrade') {
                    await page.waitForFunction(()=>__fixture.calls.length===2&&__fixture.notices.some(row=>row.level==='error'));
                    result.failedCalls=await page.evaluate(()=>__fixture.calls);
                    result.partial=await page.evaluate(()=>__fixture.canonical());
                    assert.equal(result.partial.cache.album.entries.length,7,'partial work must not overwrite formal old album');
                    activeSeed.phase='resume';runtimeRoot=root;
                    await page.reload();await page.locator('#heartbeat_memories_menu_item').waitFor();
                    // Reading-position restoration may already open the album after the menu click.
                    await openAlbum(page);
                    await page.locator('.rmt-workspace-tabs [data-rmt-workspace-tab="archive"]').click();
                    await page.locator('[data-rmt-recovery-mode="album"]').first().click();
                }
                await waitForSavedAlbum(page);
                const stored=await page.evaluate(()=>__fixture.canonical());
                assert.deepEqual(stored.bank,activeSeed.bank);
                assert.deepEqual(stored.cache.album.entries.slice(0,7),activeSeed.album.entries,'every original item stays byte-equivalent');
                result.calls=await page.evaluate(()=>__fixture.calls);
                assert.deepEqual(result.calls.map(row=>row.stage),kind==='upgrade'?['index','relationship','relationship','comments']:['index','relationship','comments']);
                if(kind==='upgrade')assert.deepEqual(result.calls[1].messages,result.calls[2].messages,'resume preserves the exact old request recipe');
                await page.reload();await page.locator('#heartbeat_memories_menu_item').waitFor();await openAlbum(page);
                assert.deepEqual(await cardIds(page),['CG08','CG02','CG06','CG03','CG04','CG07']);
                assert.equal(new Set(stored.cache.album.generationMeta.parts.mode.coveredMemoryIds).size,8);
                result.canonical=stored;
            }
            result.screenshot=path.join(output,`${kind}-${width}.png`);await page.screenshot({path:result.screenshot,fullPage:true});
            assert.deepEqual(result.external,[]);assert.deepEqual(result.pageErrors,[]);
            assert.ok(requests.some(row=>row.path==='dist/heartbeatMemories.bundle.js'&&row.sha256===bundleSha256));
            if(kind==='upgrade')assert.ok(requests.some(row=>row.path==='dist/heartbeatMemories.bundle.js'&&row.sha256===baselineBundleSha256));
            result.passed=true;
        } catch(error) {
            result.error=error.stack;try{result.snapshot=await page.evaluate(()=>__fixture.snapshot());result.notices=await page.evaluate(()=>__fixture.notices);result.calls=await page.evaluate(()=>__fixture.calls)}catch{}
            await page.screenshot({path:path.join(output,`${kind}-${width}-failure.png`),fullPage:true}).catch(()=>{});
        } finally {result.runtimeRequests=structuredClone(requests);await context.close()}
    }
} finally {
    await browser?.close();await new Promise(resolve=>server.close(resolve));
    const report={bundleSha256,baselineBundleSha256,environment:'real Edge browser and IndexedDB; synthetic host/provider; local-only',
        total:results.length,passed:results.filter(row=>row.passed).length,results};
    await mkdir(output,{recursive:true});await writeFile(path.join(output,'report.json'),JSON.stringify(report,null,2));
    console.log(JSON.stringify({total:report.total,passed:report.passed,report:path.join(output,'report.json')}));
    if(!results.length||results.some(row=>!row.passed))process.exitCode=1;
}
