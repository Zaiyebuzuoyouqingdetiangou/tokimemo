import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { preparationFixture } from './preparation-harness-r8481.mjs';
import { relayIndexedDB } from './relay-idb-fixture.mjs';

const entry = chatId => ({ entryId: `entry-${chatId}`, chatId, avatar: 'preparation-check.png', characterKey: 'card', characterName: '岚', characterIndexHint: 0 });
const memory = chatId => ({ version: 3, chatId, archiveRevision: `rev-${chatId}`, characterName: '岚', userName: '阿宁', memories: [{ id: 'M100', title: '雨夜', summary: '一起躲雨', anchors: ['雨'] }] });
async function fixture(idb = relayIndexedDB()) {
    const f = await preparationFixture(); f.sandbox.Blob = Blob; f.sandbox.indexedDB = idb;
    vm.runInContext('structuredClone = value => value === undefined ? undefined : JSON.parse(JSON.stringify(value))', f.sandbox);
    const backup = await f.api('archive/backupStore.js'), relay = await f.api('archive/relayStore.js');
    const policy = await f.api('core/archiveRelayPolicy.js');
    backup.setArchiveBackupBackendForTests(null);
    return { f, backup, relay, policy, idb };
}
async function request(x, from = 'A', to = 'B') {
    const sourceEntry = entry(from), targetEntry = entry(to);
    const source = await x.backup.readArchiveBackupState(sourceEntry);
    const target = await x.backup.readArchiveBackupState(targetEntry);
    const next = structuredClone(source.record.memory);
    next.chatId = to; next.archiveRevision = `relay-${from}-${to}`;
    const cache = { chatId: to, archiveRevision: next.archiveRevision, commitToken: 20, album: { kind: 'album', marker: 'kept' } };
    return { sourceEntry, targetEntry, sourceExpected: source.record, targetExpected: target.record,
        sourceFence: await x.relay.readArchiveRelayState(sourceEntry), targetFence: await x.relay.readArchiveRelayState(targetEntry),
        memory: next, cache, transferId: `transfer-${from}-${to}`, replaceTarget: false, stillCurrent: () => true };
}
async function seeded() {
    const x = await fixture();
    await x.backup.replaceArchiveBackup(entry('A'), memory('A'), { chatId: 'A', archiveRevision: 'rev-A', commitToken: 10 }, { present: false });
    return x;
}

test('relay transaction moves authority, retains checkpoints and allows holder writes only', async () => {
    const x = await seeded(), input = await request(x);
    const result = await x.relay.handoffArchiveBackup(input);
    assert.equal(result.status, 'committed');
    assert.equal((await x.relay.readArchiveRelayState(entry('A'))).holderKey, x.policy.relayMemberKey(entry('B')));
    assert.equal((await x.backup.readArchiveBackupState(entry('A'))).record.memory.memories[0].id, 'M100');
    const b = (await x.backup.readArchiveBackupState(entry('B'))).record;
    assert.equal(b.memory.memories[0].id, 'M100');
    assert.equal(b.cache.album.marker, 'kept');
    assert.equal((await x.relay.readRelayCheckpoint('transfer-A-B')).before.memory.chatId, 'A');
    await assert.rejects(x.backup.updateArchiveBackupCache(entry('A'), memory('A'), { commitToken: 30 }), /已交给/);
    await assert.rejects(x.backup.deleteArchiveBackup(entry('A')), /已交给/);
    await x.backup.updateArchiveBackupCache(entry('B'), b.memory, { ...b.cache, commitToken: 30, saved: true });
    assert.equal((await x.backup.readArchiveBackup(entry('B'))).cache.saved, true);
    assert.equal(x.f.providerCalls, 0);
});

test('two tabs using the same stale source: exactly one handoff commits', async () => {
    const x = await seeded();
    const y = await fixture(x.idb);
    const [b, c] = await Promise.all([request(x, 'A', 'B'), request(y, 'A', 'C')]);
    const results = await Promise.allSettled([x.relay.handoffArchiveBackup(b), y.relay.handoffArchiveBackup(c)]);
    assert.equal(results.filter(r => r.status === 'fulfilled').length, 1);
    assert.equal([...x.idb.rows.values()].filter(r => r.kind === 'archive-relay-checkpoint').length, 1);
});

test('Nth storage write failure rolls back target, source fences and checkpoint together', async () => {
    for (const failWrite of [1, 2, 3, 4, 5]) {
        const x = await seeded(), input = await request(x);
        const before = JSON.stringify([...x.idb.rows]); x.idb.control.failWrite = failWrite;
        await assert.rejects(x.relay.handoffArchiveBackup(input));
        assert.equal(JSON.stringify([...x.idb.rows]), before, `write ${failWrite}`);
        await x.backup.updateArchiveBackupCache(entry('A'), memory('A'), { chatId: 'A', archiveRevision: 'rev-A', commitToken: 40 });
    }
});

test('occupied target requires explicit choice and keeps its independent full backup', async () => {
    const x = await seeded();
    await x.backup.replaceArchiveBackup(entry('B'), memory('B'), { chatId: 'B', archiveRevision: 'rev-B', commitToken: 1 }, { present: false });
    const input = await request(x);
    await assert.rejects(x.relay.handoffArchiveBackup(input), /已有/);
    await x.relay.handoffArchiveBackup({ ...input, replaceTarget: true });
    assert.equal((await x.relay.readRelayCheckpoint(input.transferId)).targetBefore.memory.archiveRevision, 'rev-B');
});

test('source cache change, target switch and source deletion stop before any handoff', async () => {
    const x = await seeded(), input = await request(x);
    await x.backup.updateArchiveBackupCache(entry('A'), memory('A'), { chatId: 'A', archiveRevision: 'rev-A', commitToken: 41 });
    await assert.rejects(x.relay.handoffArchiveBackup(input), /变化|更新/);
    const fresh = await request(x);
    await assert.rejects(x.relay.handoffArchiveBackup({ ...fresh, stillCurrent: () => false }));
    await x.backup.deleteArchiveBackup(entry('A'));
    await assert.rejects(x.relay.handoffArchiveBackup(fresh));
    assert.equal(await x.relay.readArchiveRelayState(entry('A')), null);
});

test('restart and handback use persisted authority; old B writes remain rejected', async () => {
    const x = await seeded(); await x.relay.handoffArchiveBackup(await request(x));
    const reopened = await fixture(x.idb);
    const req = await request(reopened, 'B', 'A');
    await reopened.relay.handoffArchiveBackup(req);
    assert.equal((await reopened.relay.readArchiveRelayState(entry('B'))).holderKey, x.policy.relayMemberKey(entry('A')));
    await assert.rejects(x.backup.updateArchiveBackupCache(entry('B'), req.sourceExpected.memory, { ...req.sourceExpected.cache, commitToken: 50 }), /已交给/);
    assert.equal((await reopened.backup.readArchiveBackup(entry('A'))).memory.memories[0].id, 'M100');
});
