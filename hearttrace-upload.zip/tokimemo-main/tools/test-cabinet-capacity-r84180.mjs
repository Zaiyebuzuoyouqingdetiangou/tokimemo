import test from 'node:test';
import assert from 'node:assert/strict';
import { resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = process.env.HEARTTRACE_TEST_ROOT || fileURLToPath(new URL('..', import.meta.url));
const cabinet = await import(pathToFileURL(resolve(root, 'src/modes/cabinet.js')).href);

function priorItems(count) {
    return Array.from({ length: count }, (_, index) => ({ id: `KEEP_${index + 1}`, name: `纪念物${index + 1}`,
        objectEvidence: `岚与阿宁留下纪念物${index + 1}。`, sourceMemoryIds: ['M001'], sourceMemoryAnchor: '一起留存纪念物' }));
}

function newReply() {
    const evidence = '岚与阿宁把蓝色票根夹在书里。';
    const bank = { version: 3, chatId: 'cabinet-capacity', archiveRevision: 'r1', characterName: '岚', userName: '阿宁',
        memories: [{ id: 'M241', title: '蓝色票根', summary: evidence, anchors: [evidence], participants: ['岚', '阿宁'] }] };
    const raw = { items: [{ name: '蓝色票根', objectEvidence: evidence, sourceMemoryIds: ['M241'], sourceMemoryAnchor: evidence }] };
    return { bank, raw };
}

test('cabinet retains validated new items beyond the former 240-item boundary without changing old content', () => {
    const { bank, raw } = newReply();
    const fresh = cabinet.normalizeCabinet(raw, bank);
    assert.equal(fresh.items.length, 1, 'fixture passes the actual evidence validator');
    for (const count of [239, 240, 500]) {
        const previous = { kind: 'cabinet', items: priorItems(count) };
        const before = structuredClone(previous);
        const merged = cabinet.mergeCabinet(previous, fresh);
        assert.equal(merged.items.length, count + 1);
        assert.deepEqual(merged.items.slice(0, count), before.items);
        assert.equal(merged.items.at(-1).name, '蓝色票根');
        assert.equal(merged.items.at(-1).id, `KEEP_${count + 1}`);
        assert.deepEqual(previous, before);
    }
});

test('cabinet deduplication still preserves existing identities and content above 240 items', () => {
    const previous = { kind: 'cabinet', items: priorItems(250) };
    const fresh = { kind: 'cabinet', items: [{ ...previous.items[0], objectEvidence: 'must not overwrite' },
        { id: 'KEEP_1', name: '新书签', objectEvidence: '共同留下的书签' },
        { id: 'KEEP_2', name: '新书签', objectEvidence: 'duplicate in the same response' }] };
    const merged = cabinet.mergeCabinet(previous, fresh);
    assert.equal(merged.items.length, 251);
    assert.deepEqual(merged.items.slice(0, 250), previous.items);
    assert.equal(merged.items.at(-1).id, 'KEEP_251');
    assert.equal(merged.items.at(-1).objectEvidence, '共同留下的书签');
});

test('cabinet progress projection and reader retain entries after item 240 with text escaped', () => {
    const { bank, raw } = newReply();
    const previous = { kind: 'cabinet', items: priorItems(240) };
    const projected = cabinet.projectCabinetProgress({ memoryBank: bank, previousSession: previous,
        segments: [{ items: path => path === '/items' ? raw.items : [] }] });
    assert.equal(projected.items.length, 241);
    projected.items.push({ id: 'KEEP_242', name: '<img src=x onerror=bad()>', objectEvidence: '<script>bad()</script>',
        sourceMemoryIds: ['M241'], sourceMemoryAnchor: '<b>anchor</b>' });
    const html = cabinet.cabinetHtml(projected);
    assert.equal((html.match(/class="rmt-cabinet-piece"/g) || []).length, 242);
    assert.match(html, /蓝色票根/);
    assert.match(html, /&lt;img/);
    assert.match(html, /&lt;script&gt;/);
    assert.doesNotMatch(html, /<img|<script>/);
    assert.equal(previous.items.length, 240);
});
