// Real shipped bundle; deterministic provider / host / DOM doubles. No paid calls or real-device claims.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fixture, realClient } from './fixture.mjs';
const plain = value => JSON.parse(JSON.stringify(value));
const ids = (start, end) => Array.from({ length: end - start + 1 }, (_, i) => `M${String(start + i).padStart(3, '0')}`);
const row = (n, mode = 'album') => ({ id: mode === 'album' ? `CG${n}` : `EV${n}`, title: `镜头${n}`, date: '10/01',
    unlocked: true, desc: `事件${n}的画面`, cgDesc: `事件${n}的画面`, category: '日常', visualSeed: ['窗', '灯', '书', '雨'],
    sourceMemoryIds: ids(n,n), sourceMemoryAnchor: `事件${n}`, imagePrompt: 'a room' });
async function setup(mode = 'album', previous = null, count = 500) {
    const f = await fixture(), g = f.get, calls = [];
    f.bank.memories = Array.from({ length: count }, (_, i) => ({ id: ids(i + 1, i + 1)[0], title: `事件${i + 1}`, summary: `记忆${i + 1}`, anchors: [`事件${i + 1}`] }));
    g('core/cache').loadSession = () => previous;
    g('archive/repository').getImportedMemory = (context = f.host) => context.chatMetadata[f.constants.MEMORY_KEY];
    g('core/settings').getPluginSettings = () => ({ autoSecondPass: false });
    g('core/requestCoordinator').noteSecondStepOffer = () => {};
    g('generation/prompts').promptSafetyBoundary = () => '';
    let response = { [mode === 'album' ? 'entries' : 'events']: Array.from({ length: 6 }, (_, i) => row(i + 1, mode)) };
    g('generation/client').requestValidatedSegment = async (prompt, label, options, validate) => {
        calls.push({ prompt, options });
        if (response instanceof Error) throw response;
        return validate(structuredClone(response));
    };
    const selection = g('core/contentSelection');
    const run = options => mode === 'album' ? g('modes/album').generateAlbumWithRepair(f.host, f.bank, {}, 'TEST', options)
        : g('modes/advEventData').generateAdvIndexWithRepair(f.host, f.bank, {}, 'A', 'TEST', options);
    const payload = () => JSON.parse(calls[0].prompt.split(/UNTRUSTED_INCREMENTAL_(?:CG|ADV)_ARCHIVE_JSON:\n/)[1].split(/\nEXISTING_(?:ALBUM|ADV)_INDEX_JSON:/)[0]);
    return { ...f, calls, run, payload, selection, respond: value => { response = value; } };
}
for (const mode of ['album', 'adv']) {
    test(`${mode}: first 500-memory request sends 48 and records 48, not all 500`, async () => {
        const f = await setup(mode), result = await f.run();
        assert.equal(f.calls.length, 1); assert.equal(f.payload().memories.length, 48);
        assert.equal((result.entries || result.events).length, 6);
        assert.equal(result.generationMeta.parts.mode.coveredMemoryIds.length, 48);
        assert.equal(f.selection.contentSelectionStatus(result, f.bank).pendingMemoryIds.length, 452);
        assert.deepEqual(plain(f.selection.createContentSelectionPlan(f.bank, result).memoryIds), ids(49,112));
    });
    test(`${mode}: manual 300-memory range reaches prompt and validates last item`, async () => {
        const f = await setup(mode), selected = ids(150,449);
        const request = f.selection.setContentSelectionRequest(f.host, f.bank, mode, selected);
        f.respond({ [mode === 'album' ? 'entries' : 'events']: [row(449, mode)] });
        const result = await f.run({ contentSelectionRequest: request });
        assert.deepEqual(f.payload().memories.map(item => item.id), selected);
        assert.deepEqual(plain(result.generationMeta.contentSelection.scannedMemoryIds), selected);
        assert.equal((result.entries || result.events)[0].sourceMemoryIds[0], 'M449');
    });
    test(`${mode}: old blanket coverage does not hide unused memories; old work is immutable`, async () => {
        const work = { ...row(1, mode), comments: ['旧对白'], cgImage: { key: 'paid-image' }, adv: { paragraphs: ['旧正文'] }, categoryManual: true };
        const previous = { kind: mode, [mode === 'album' ? 'entries' : 'events']: [work], generationMeta: { parts: { mode: { coveredMemoryIds: ids(1,500) } } } };
        const before = JSON.stringify(previous), f = await setup(mode, previous);
        f.respond({ [mode === 'album' ? 'entries' : 'events']: [row(2, mode)] });
        const result = await f.run();
        assert.equal(f.payload().memories[0].id, 'M002'); assert.equal(f.payload().memories.length, 64);
        assert.equal(JSON.stringify(previous), before);
        assert.deepEqual(plain((result.entries || result.events)[0]), work);
        assert.equal(result.generationMeta.contentSelection.scannedMemoryIds.length, 65);
        assert.equal(result.generationMeta.contentSelection.legacyUnknown, true);
    });
    test(`${mode}: valid empty first result advances material only, without follow-up calls`, async () => {
        const f = await setup(mode); f.respond({ [mode === 'album' ? 'entries' : 'events']: [] });
        const result = await f.run();
        assert.equal((result.entries || result.events).length, 0); assert.equal(f.calls.length, 1);
        assert.equal(result.generationMeta.contentSelection.scannedMemoryIds.length, 48);
        assert.equal(result.generationMeta.contentSelection.last.added, 0);
    });
    test(`${mode}: malformed/failed result never changes old coverage or work`, async () => {
        const old = { kind: mode, [mode === 'album' ? 'entries' : 'events']: [row(1,mode)] }, f = await setup(mode, old), before = JSON.stringify(old);
        f.respond({}); await assert.rejects(f.run()); assert.equal(JSON.stringify(old), before);
        f.respond(new Error('provider failed')); await assert.rejects(f.run(), /provider failed/); assert.equal(JSON.stringify(old), before);
    });
    test(`${mode}: selected evidence cannot accept a different archive row`, async () => {
        const f = await setup(mode), request = f.selection.setContentSelectionRequest(f.host, f.bank, mode, ids(100,101));
        f.respond({ [mode === 'album' ? 'entries' : 'events']: [row(499, mode)] });
        await assert.rejects(f.run({ contentSelectionRequest: request }));
    });
    test(`${mode}: duplicate paid output is discarded while historical image/text stays exact`, async () => {
        const old = { kind: mode, [mode === 'album' ? 'entries' : 'events']: [{ ...row(1,mode), comments: ['keep'], cgImage: { key: 'paid' }, adv: { paragraphs: ['keep'] } }] };
        const f = await setup(mode, old), request = f.selection.setContentSelectionRequest(f.host, f.bank, mode, ids(1,2));
        f.respond({ [mode === 'album' ? 'entries' : 'events']: [row(1,mode)] });
        const result = await f.run({ contentSelectionRequest: request });
        assert.deepEqual(plain(result.entries || result.events), old.entries || old.events);
        assert.equal(result.generationMeta.contentSelection.last.added, 0);
    });
    test(`${mode}: recovery schema and partial reader use frozen selected bank`, async () => {
        const f = await setup(mode), plan = f.selection.createContentSelectionPlan(f.bank, null, { archiveRevision: 'r1', memoryIds: ids(100,101) });
        const operation = { contentSelectionPlan: plan }, key = mode === 'album' ? 'entries' : 'events';
        const schema = f.get('generation/recoveryAdapters').recoveryProgressSchema(mode, { slot: 'TEST:index', memoryBank: f.bank, operation });
        assert.equal(schema.children[key].acceptItem(row(100, mode)), true);
        assert.equal(schema.children[key].acceptItem(row(499, mode)), false);
        const parsed = f.get('generation/jsonParser').parsePartialJsonObject(JSON.stringify({ [key]: [row(100,mode), row(499,mode)] }));
        const input = { segments: [{ ...parsed, slot: 'TEST:index' }], memoryBank: f.bank, operation };
        const result = mode === 'album' ? f.get('modes/album').projectAlbumProgress(input) : f.get('modes/advEventData').projectAdvProgress(input);
        assert.deepEqual(plain((result.entries || result.events).map(item => item.sourceMemoryIds[0])), ['M100']);
    });
}
test('cold-tier selection participates without changing the original bank', async () => {
    const f = await setup(), before = JSON.stringify(f.bank);
    f.bank.coldArchive = [{ id:'COLD',title:'旧日',summary:'旧日',anchors:['旧日'] }];
    const original = JSON.stringify(f.bank), plan = f.selection.createContentSelectionPlan(f.bank, null, { archiveRevision:'r1',memoryIds:['COLD'] });
    assert.equal(JSON.parse(f.selection.selectionPromptArchive(f.bank, plan)).memories[0].id,'COLD');
    assert.equal(f.selection.selectionEvidenceBank(f.bank, plan).memories[0].id,'COLD');
    assert.equal(JSON.stringify(f.bank),original); assert.notEqual(original,before);
});
test('expired manual selection stops before a provider request', async () => {
    const f=await setup(), request=f.selection.setContentSelectionRequest(f.host,f.bank,'album',ids(10,20));
    f.bank.archiveRevision='r2'; await assert.rejects(f.run({contentSelectionRequest:request}),/档案已更新/); assert.equal(f.calls.length,0);
});
test('manual selection is isolated by mode, chat, avatar, archive target and revision', async () => {
    const f=await setup(), s=f.selection;
    s.setContentSelectionRequest(f.host,f.bank,'album',ids(10,20));
    assert.equal(s.readContentSelectionRequest(f.host,f.bank,'album').memoryIds.length,11);
    assert.equal(s.readContentSelectionRequest(f.host,f.bank,'adv'),null);
    assert.equal(s.readContentSelectionRequest({...f.host,chatId:'B'},f.bank,'album'),null);
    assert.equal(s.readContentSelectionRequest({...f.host,characters:[{name:'Char',avatar:'other.png'}]},f.bank,'album'),null);
    assert.equal(s.readContentSelectionRequest({...f.host,__rmtArchiveTargetEntryId:'other'},f.bank,'album'),null);
    assert.equal(s.readContentSelectionRequest(f.host,{...f.bank,archiveRevision:'r2'},'album'),null);
});
test('completion clears only its exact applied request; failed or newer choices survive', async () => {
    const f=await setup(), s=f.selection, first=s.setContentSelectionRequest(f.host,f.bank,'album',ids(1,6));
    const result=await f.run({contentSelectionRequest:first});
    assert.ok(s.readContentSelectionRequest(f.host,f.bank,'album'));
    const next=s.setContentSelectionRequest(f.host,f.bank,'album',ids(7,12));
    assert.equal(s.readContentSelectionRequest(f.host,f.bank,'album',result).requestKey,next.requestKey);
    s.setContentSelectionRequest(f.host,f.bank,'album',null);
    assert.equal(s.readContentSelectionRequest(f.host,f.bank,'album'),null);
});
test('frozen plan survives serialization and does not adopt a later form selection', async () => {
    const f=await setup(), s=f.selection, first=s.setContentSelectionRequest(f.host,f.bank,'album',ids(1,6));
    const plan=plain(s.createContentSelectionPlan(f.bank,null,first));
    s.setContentSelectionRequest(f.host,f.bank,'album',ids(70,80));
    const result=await f.run({contentSelectionPlan:plan});
    assert.deepEqual(f.payload().memories.map(row=>row.id),ids(1,6));
    const fresh=await fixture();
    assert.equal(fresh.get('core/contentSelection').contentSelectionStatus(plain(result),f.bank).pendingMemoryIds.length,494);
    const corrupted={...plan,archiveRevision:'wrong'};await assert.rejects(f.run({contentSelectionPlan:corrupted}));
});
test('empty and nonexistent selections are rejected without replacing an applied request', async () => {
    const f=await setup(),s=f.selection,good=s.setContentSelectionRequest(f.host,f.bank,'album',ids(10,20));
    for(const ids of [[],['M999']]) assert.throws(()=>s.setContentSelectionRequest(f.host,f.bank,'album',ids));
    assert.equal(s.readContentSelectionRequest(f.host,f.bank,'album').requestKey,good.requestKey);
});
test('legacy paid journal keeps its original prompt sampling, but stamps only 48 actual inputs', async () => {
    const f=await setup(); const result=await f.run({legacyContentSelection:true});
    assert.equal(f.payload().memories.length,48); assert.equal(f.payload().memories.at(-1).id,'M500');
    assert.equal(result.generationMeta.contentSelection.scannedMemoryIds.length,48);
});
test('creative prompt templates are byte-for-byte unchanged from the delivered 1.0.20 source',()=>{
    const previous=process.env.BASELINE_ROOT;
    if(!previous) throw Error('Set BASELINE_ROOT to the exact 1.0.20 source for this contract check');
    for(const [file,name] of [['src/modes/album.js','albumIndexPrompt'],['src/modes/advEventData.js','advImportantIndexPrompt']]){
        const template=s=>s.slice(s.indexOf(`export function ${name}`)).match(/return (`[\s\S]+?`);/)[1];
        assert.equal(template(fs.readFileSync(path.join(process.env.TEST_ROOT||'.',file),'utf8')),template(fs.readFileSync(path.join(previous,file),'utf8')));
    }
});

// This small DOM double checks event behavior only, not layout or Safari/TT rendering.
class SelectionRoot {
    constructor() { this.html='';this.nodes=new Map();this.listeners={}; }
    set innerHTML(value) { this.html=value;this.nodes.clear(); }
    get innerHTML() { return this.html; }
    querySelector(selector) {
        if(this.nodes.has(selector))return this.nodes.get(selector);
        const match=selector.match(/^\[([^=\]]+)(?:="([^"]*)")?\]$/);if(!match)return null;
        const [,attribute,value]=match,tag=[...this.html.matchAll(/<[^>]+>/g)].map(m=>m[0]).find(tag=>value===undefined?tag.includes(attribute):tag.includes(`${attribute}="${value}"`));
        if(!tag)return null;
        const dataset={};for(const [,key,val] of tag.matchAll(/data-([\w-]+)(?:="([^"]*)")?/g))dataset[key.replace(/-([a-z])/g,(_,c)=>c.toUpperCase())]=val||'';
        const node={dataset,disabled:/\sdisabled\b/.test(tag),checked:/\schecked\b/.test(tag),value:tag.match(/\svalue="([^"]*)"/)?.[1]||'',textContent:'',innerHTML:'',open:false,
            matches:query=>query.split(',').some(part=>part===selector),hasAttribute:key=>tag.includes(key),closest:query=>query==='button'&&tag.startsWith('<button')||query===selector?node:null};
        this.nodes.set(selector,node);return node;
    }
    addEventListener(type,handler){this.listeners[type]=handler;}
    click(selector){const target=this.querySelector(selector);assert.ok(target,selector);const event={target,stopped:false,preventDefault(){},stopPropagation(){this.stopped=true;}};this.listeners.click(event);return event;}
    input(selector,value){const target=this.querySelector(selector);target.value=String(value);this.listeners.input({target});}
}
async function mount(mode='album',session=null){
    const f=await setup(mode,session),root=new SelectionRoot(),ui=f.get('ui/contentSelection');
    const container={querySelector:()=>root};ui.mountContentSelection(container,mode,session);
    return {...f,root,ui,container};
}
test('UI: opening first-generation selection is local, collapsed and uses existing generate action',async()=>{
    const f=await mount();assert.equal(f.calls.length,0);
    assert.match(f.root.innerHTML,/开始生成/);assert.match(f.root.innerHTML,/data-rmt-reader-generation="true"/);
    assert.match(f.root.innerHTML,/<details data-cs-panel>/);assert.match(f.root.innerHTML,/min-height:44px/);
    assert.equal(f.root.querySelector('[data-cs-rows]').innerHTML.match(/data-cs-row=/g).length,6);
    assert.equal(f.root.click('[data-rmt-generate-mode="album"]').stopped,false);
});
test('UI: apply a range before generation, paginate and keep exact mode-specific request',async()=>{
    const f=await mount();f.root.input('[data-cs-start]',101);f.root.input('[data-cs-end]',300);
    assert.equal(f.root.click('[data-rmt-generate-mode="album"]').stopped,true);
    f.root.click('[data-cs-action="apply"]');assert.equal(f.selection.readContentSelectionRequest(f.host,f.bank,'album'),null);
    f.root.click('[data-cs-action="range"]');f.root.click('[data-cs-action="apply"]');
    assert.deepEqual(plain(f.selection.readContentSelectionRequest(f.host,f.bank,'album').memoryIds),ids(101,300));
    assert.equal(f.root.click('[data-rmt-generate-mode="album"]').stopped,false);
    f.root.click('[data-cs-action="next"]');assert.equal(f.root.querySelector('[data-cs-page]').textContent,'18 / 84');
    assert.equal(f.calls.length,0);
    assert.equal(f.selection.readContentSelectionRequest(f.host,f.bank,'adv'),null);
});
test('UI: invalid and empty ranges cannot replace chosen material; automatic restore works',async()=>{
    const f=await mount();f.root.input('[data-cs-start]',20);f.root.input('[data-cs-end]',10);
    f.root.click('[data-cs-action="range"]');assert.match(f.root.querySelector('[data-cs-notice]').textContent,/有效范围/);
    f.root.click('[data-cs-action="none"]');f.root.click('[data-cs-action="apply"]');
    assert.equal(f.selection.readContentSelectionRequest(f.host,f.bank,'album'),null);
    f.root.click('[data-cs-action="all"]');f.root.click('[data-cs-action="apply"]');
    assert.equal(f.selection.readContentSelectionRequest(f.host,f.bank,'album').memoryIds.length,500);
    f.root.click('[data-cs-action="auto"]');assert.equal(f.selection.readContentSelectionRequest(f.host,f.bank,'album'),null);
    assert.equal(f.root.click('[data-rmt-generate-mode="album"]').stopped,false);
});
test('UI: individual checkboxes change the applied set',async()=>{
    const f=await mount();
    const checkbox={dataset:{csRow:'3'},checked:false,matches:selector=>selector==='[data-cs-row]'};
    f.root.listeners.change({target:checkbox});f.root.click('[data-cs-action="apply"]');
    const selected=f.selection.readContentSelectionRequest(f.host,f.bank,'album').memoryIds;
    assert.equal(selected.length,47);assert.ok(!selected.includes('M004'));
});
test('UI: stale archive blocks both selection and paid generation',async()=>{
    const f=await mount();f.bank.archiveRevision='r2';f.root.click('[data-cs-action="all"]');
    assert.equal(f.root.click('[data-rmt-generate-mode="album"]').stopped,true);
    assert.match(f.root.querySelector('[data-cs-notice]').textContent,/档案已切换或更新/);assert.equal(f.calls.length,0);
});
test('UI: completed selection resets to automatic only for its matching request',async()=>{
    const f=await mount(),request=f.selection.setContentSelectionRequest(f.host,f.bank,'album',ids(1,6)),result=await f.run({contentSelectionRequest:request});
    f.ui.mountContentSelection(f.container,'album',result);
    assert.equal(f.selection.readContentSelectionRequest(f.host,f.bank,'album'),null);
    assert.match(f.root.innerHTML,/继续补充/);assert.match(f.root.innerHTML,/上次选材 6 条/);assert.match(f.root.innerHTML,/还剩 494 条/);
});
test('UI: unsupported modes and read-only or backup pages do not expose selection controls',async()=>{
    const f=await mount();assert.equal(f.ui.contentSelectionHtml('phone'),'');assert.equal(f.ui.contentSelectionHtml('album',{readOnly:true}),'');
    f.get('core/state').state.activeArchiveSnapshot={backupOnly:true};assert.equal(f.ui.contentSelectionHtml('adv'),'');
});
for(const mode of ['album','adv']) test(`${mode}: public generateMode freezes applied selection into recovery and commits matching coverage`,async()=>{
    const f=await setup(mode),g=f.get,journals=[],commits=[];
    // The browser clone stays in its realm; Node's injected structuredClone does not.
    f.sb.structuredClone=value=>value===undefined?undefined:f.json(structuredClone(value));
    f.selection.setContentSelectionRequest(f.host,f.bank,mode,ids(150,170));
    f.respond({[mode==='album'?'entries':'events']:[row(170,mode)]});
    g('core/settings').getPluginSettings=()=>({...f.constants.DEFAULT_SETTINGS,autoSecondPass:false});
    g('core/cache').claimLiveModeGeneration=async()=>{};
    g('core/cache').saveGenerationRecovery=async(context,bank,mode,journal)=>{if(journal)journals.push(plain(journal));return true;};
    g('core/cache').commitSession=async(mode,session)=>{commits.push(plain(session));return true;};
    g('core/requestCoordinator').refreshConcurrentTaskUi=()=>{};
    g('ui/settingsPanel').refreshSettingsMemoryStatus=()=>{};
    const result=await g('generation/generationModes').generateMode(mode,{background:true,participantSnapshot:null,newTask:true});
    assert.ok(result,'generation result');assert.equal(f.calls.length,1);assert.equal(commits.length,1);
    assert.deepEqual(f.payload().memories.map(row=>row.id),ids(150,170));
    assert.deepEqual(journals[0].operation.contentSelectionPlan.memoryIds,ids(150,170));
    assert.equal(commits[0].generationMeta.contentSelection.scannedMemoryIds.length,21);
});
test('album: second-step dialogue keeps selected coverage instead of marking a new batch',async()=>{
    const f=await setup();const first=await f.run();f.get('core/cache').loadSession=()=>first;
    const meta=plain(first.generationMeta);let calls=0;
    f.get('generation/client').requestValidatedSegment=async(prompt,label,options,validate)=>{
        calls++;
        if(options.taskKey.endsWith('relationship-scan'))return validate({charState:'未确认',userState:'未确认',relationshipState:'普通相处',relationshipSummary:'普通相处',relationshipSourceMemoryIds:['M001'],relationshipSourceMemoryAnchor:'事件1'});
        const requested=first.entries.filter(item=>prompt.includes(`"id": "${item.id}"`));
        return validate({items:requested.map(item=>({id:item.id,comments:Array.from({length:6},(_,i)=>`记忆对白${i+1}`)}))});
    };
    const result=await f.run({secondStep:true});assert.equal(calls,3);
    assert.deepEqual(plain(result.generationMeta),meta);assert.equal(result.entries[0].comments.length,6);
});
test('paid album index survives a fresh runtime and resumes original range with zero new provider calls',async()=>{
    async function runtime(existing=null,commit=true){
        const f=await setup('album'),g=f.get,journals=[],commits=[];let calls=0;
        f.sb.structuredClone=value=>value===undefined?undefined:f.json(structuredClone(value));
        realClient(f,()=>{calls++;return {entries:[row(170)]};});
        g('generation/client').requestValidatedSegment=g('generation/generationRequest').requestValidatedSegment;
        g('core/cache').claimLiveModeGeneration=async()=>{};
        g('core/cache').saveGenerationRecovery=async(context,bank,mode,journal)=>{if(journal)journals.push(plain(journal));return true;};
        g('core/cache').commitSession=async(mode,session)=>{commits.push(plain(session));return commit;};
        g('core/cache').saveGenerationTaskResult=async()=>({durable:true});
        g('core/requestCoordinator').queueDeferredCommit=()=>true;
        g('core/requestCoordinator').notifyDeferredCommitNotDurable=()=>{};
        g('ui/settingsPanel').refreshSettingsMemoryStatus=()=>{};
        const request=f.selection.setContentSelectionRequest(f.host,f.bank,'album',existing?ids(20,30):ids(150,170));
        const result=await g('generation/generationModes').generateMode('album',{background:true,participantSnapshot:null,...(existing?{existing:f.json(existing),continueRecovery:true}:{newTask:true})});
        return {f,result,journals,commits,calls,request};
    }
    const first=await runtime(null,false);assert.ok(first.result);assert.equal(first.calls,1);
    const journal=first.journals.at(-1);assert.equal(journal.segments[0].state,'complete');
    assert.deepEqual(journal.operation.contentSelectionPlan.memoryIds,ids(150,170));
    const next=await runtime(journal,true);assert.ok(next.result);assert.equal(next.calls,0);
    assert.deepEqual(next.commits[0].generationMeta.contentSelection.scannedMemoryIds,ids(150,170));
    assert.equal(next.f.selection.readContentSelectionRequest(next.f.host,next.f.bank,'album').requestKey,next.request.requestKey);
});
for(const mode of ['album','adv'])test(`${mode}: existing reader mounts selection alongside original reading controls`,async()=>{
    const f=await setup(mode),session=await f.run(),root=new SelectionRoot();let html='';
    const body={set innerHTML(value){html=value;},get innerHTML(){return html;},querySelector:selector=>selector==='[data-rmt-content-selection]'&&html.includes('data-rmt-content-selection')?root:null};
    const overlay=f.get('ui/overlay');overlay.bodyEl=()=>body;overlay.setBackVisible=()=>{};overlay.topTitle=()=>{};
    f.get('ui/cgFormatControl').mountCgFormatControl=()=>{};
    f.get('generation/imageGeneration').cgImageProviderBar=()=>'';f.get('generation/imageGeneration').cgImageLayerHtml=()=>'';
    f.get('core/state').state.activeSession=session;f.get('core/state').state.activeMode=mode;
    if(mode==='album')f.get('ui/albumView').renderAlbum();else f.get('ui/advEventView').renderAdvMode();
    assert.match(root.innerHTML,/继续补充/);assert.match(root.innerHTML,/选择范围/);
    assert.match(html,mode==='album'?/data-rmt-album-memory/:/data-rmt-action="read-adv"/);
});
test('UI: imported metadata and archive titles cannot insert HTML through the selection panel',async()=>{
    const session={kind:'album',entries:[],generationMeta:{contentSelection:{schemaVersion:1,last:{memoryIds:[],added:'<img onerror=alert(1)>'}}}};
    const f=await mount('album',session);assert.doesNotMatch(f.root.innerHTML,/<img onerror/);
    f.bank.memories[0].title='<img onerror=alert(1)>';
    f.ui.mountContentSelection(f.container,'album',session);
    assert.doesNotMatch(f.root.querySelector('[data-cs-rows]').innerHTML,/<img onerror/);
});
