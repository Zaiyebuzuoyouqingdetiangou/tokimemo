// Compare generated inputs for every other direction with the exact delivered baseline.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url));
if (process.argv[2] === '--snapshot') {
    const { fixture } = await import('./fixture.mjs'), { stageRaw, song } = await import('./mv-stage-fixture.mjs');
    const out = {};
    for (const id of ['auto','narrative','lyrical','interaction','impact','loop','expression','reveal']) {
        const f = await fixture(), mv = f.get('extras/mv'); let prompt = '';
        f.get('core/cache').loadSession = () => ({ songs: [song] });
        f.get('generation/client').requestJson = async p => { prompt = p; return f.json(stageRaw()); };
        await mv.generateStoryboard(song.id, { storyType: id, range: 'full' });
        const record = mv.readMv(f.host,song.id), assets = {};
        for (const layer of ['full','cutout']) {
            for (const g of record.groups) g.layer = layer;
            for (const key of mv.assetKeys(record,song)) assets[`${layer}:${key}`] = mv.defaultAssetPrompt(record,key,f.host);
        }
        out[id] = { prompt, defaults: f.get('extras/mvDirection').directionDefaults(id), assets };
    }
    console.log(JSON.stringify(out));
} else {
    const baseline = process.env.BASELINE_ROOT, candidate = process.env.TEST_ROOT;
    assert.ok(baseline && candidate, 'Set BASELINE_ROOT and TEST_ROOT');
    const snapshot = root => {
        const p = spawnSync(process.execPath,['--experimental-vm-modules',fileURLToPath(import.meta.url),'--snapshot'],{env:{...process.env,TEST_ROOT:root},encoding:'utf8',maxBuffer:8*1024*1024});
        assert.equal(p.status,0,p.stderr); return JSON.parse(p.stdout);
    };
    const old = snapshot(baseline), next = snapshot(candidate); assert.deepEqual(next,old);
    const allowed = new Set(['core/releaseNotes.js','core/selfUpdater.js','extras/mv.js','extras/mvDirection.js','extras/mvIllustration.js','ui/mvView.js','ui/mvIllustrationCanvas.js']);
    let exact = 0;
    for (const name of fs.readdirSync(path.join(baseline,'src'),{recursive:true})) {
        const before = path.join(baseline,'src',name), after=path.join(candidate,'src',name);
        if (!fs.statSync(before).isFile() || allowed.has(name)) continue;
        assert.deepEqual(fs.readFileSync(after),fs.readFileSync(before),name); exact++;
    }
    const changed=[];
    for(const name of fs.readdirSync(path.join(baseline,'tools/verification'))) {
        const a=path.join(baseline,'tools/verification',name),b=path.join(candidate,'tools/verification',name);
        if(fs.statSync(a).isFile()) { assert.deepEqual(fs.readFileSync(b),fs.readFileSync(a),`existing verification tool changed: ${name}`); }
    }
    console.log(JSON.stringify({otherDirections:8,exactSourceFiles:exact,existingToolsUnchanged:true,otherPromptsAndDefaultsEqual:true}));
}
