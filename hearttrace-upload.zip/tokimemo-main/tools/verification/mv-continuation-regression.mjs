import test from 'node:test';
import assert from 'node:assert/strict';
import {fixture, realClient} from './fixture.mjs';
const plain = value => JSON.parse(JSON.stringify(value));
const song={id:'SONG_a',title:'continuation',bpm:120,lyrics:Array.from({length:8},(_,i)=>`[Verse ${i+1}]\nline ${i+1}`).join('\n')+'\n[End]'};
function raw(indexes){return {wardrobe:{era:'new era',char:'new clothes'},groups:indexes.map(i=>({id:`G${i}`,composition:`scene ${i}`,characterPrompt:'one scene',diffs:[{id:'D1',label:'moment',change:'looks up'}],bgs:[{id:'B1',prompt:'garden'}]})),frames:indexes.map(i=>({sectionIndex:i,lyric:`line ${i+1}`,group:`G${i}`,diff:'D1',bg:'B1'}))};}
async function setup(){const f=await fixture();f.get('core/cache').loadSession=()=>({songs:[song]});const mv=f.get('extras/mv');const built=mv.buildShots(raw([0,1,2,3]),f.bank,8,{output:'tegaki'});for(const g of built.groups)g.diffs[0].image={url:`/user/images/${g.id}.png`};const record={id:song.id,createdAt:1,updatedAt:1,settings:{output:'tegaki',range:'custom',rangeFrom:0,rangeTo:3},tegaki:{range:'full'},duration:80,timing:{taps:{0:0,4:40},lineTaps:{'1:0':10},shift:0},wardrobe:{era:'original era',char:'original clothes'},...built};f.host.chatMetadata[mv.MV_KEY]={version:1,songs:{[song.id]:record}};return {...f,mv,record};}
test('1–4 completed then full range appends 5–8 and preserves paid assets, settings and timing',async()=>{const f=await setup();let calls=0;realClient(f,()=>{calls++;return raw([4,5,6,7])});assert.equal(typeof f.mv.continueStoryboard,'function');const old=plain(f.record);const result=await f.mv.continueStoryboard(song.id);assert.equal(result.pending,false);const saved=f.mv.readMv(f.host,song.id);assert.deepEqual(plain(saved.shots.slice(0,4)),old.shots);assert.deepEqual(plain(saved.groups.slice(0,4)),old.groups);assert.deepEqual(plain(saved.timing),old.timing);assert.deepEqual(plain(saved.wardrobe),old.wardrobe);assert.equal(saved.shots.length,8);assert.equal(new Set(saved.groups.map(g=>g.id)).size,8);assert.equal(new Set(saved.shots.map(s=>s.id)).size,8);assert.equal(calls,1);});
test('export defaults to completed 1–4 and remains independent when making full song',async()=>{const f=await setup();assert.equal(typeof f.mv.exportRange,'function');const range=f.mv.exportRange(f.record,song);assert.equal(range.start,0);assert.equal(range.end,40);assert.equal(f.mv.playRange(f.record,song).end,80);});
import {ui, recorderHost} from './mv-ui-fixture.mjs';
const flush=()=>new Promise(resolve=>setImmediate(resolve));
const deferred=()=>{let resolve;const promise=new Promise(r=>resolve=r);return {promise,resolve};};
test('continuation only supplies missing global section indexes and existing wardrobe to the request',async()=>{
 const f=await setup();let prompt='';f.get('generation/client').requestJson=async p=>{prompt=p;return raw([4,5,6,7]);};
 await f.mv.continueStoryboard(song.id);
 const sections=JSON.parse(prompt.split('段落（sectionIndex 从 0 开始）：\n')[1].split('\n')[0]);
 assert.deepEqual(sections.map(s=>s.index),[4,5,6,7]);assert.match(prompt,/original clothes/);assert.match(prompt,/最小差分/);assert.match(prompt,/特写/);
});
test('no missing sections makes no paid request; duplicate clicks share the existing story lock',async()=>{
 const f=await setup();let calls=0;const d=deferred();f.get('generation/client').requestJson=async()=>{calls++;return d.promise;};
 f.mv.patchTegaki(song.id,{range:'custom',rangeFrom:0,rangeTo:3});assert.equal((await f.mv.continueStoryboard(song.id)).alreadyComplete,true);assert.equal(calls,0);
 f.mv.patchTegaki(song.id,{range:'full'});const pending=f.mv.continueStoryboard(song.id);await assert.rejects(f.mv.continueStoryboard(song.id),/正在写/);d.resolve(raw([4,5,6,7]));await pending;assert.equal(calls,1);
});
test('a short model reply can be continued again without losing either completed batch',async()=>{
 const f=await setup();let calls=0;realClient(f,()=>raw(++calls===1?[4,5]:[6,7]));
 await f.mv.continueStoryboard(song.id);const mid=plain(f.mv.readMv(f.host,song.id));assert.deepEqual(plain(f.mv.missingStoryboardSections(mid,song)),[6,7]);
 await f.mv.continueStoryboard(song.id);const end=f.mv.readMv(f.host,song.id);assert.equal(end.shots.length,8);assert.deepEqual(plain(end.shots.slice(0,6)),mid.shots);assert.equal(calls,2);
});
test('append merges concurrent drawing, timing, wardrobe, export and range edits',async()=>{
 const f=await setup();realClient(f,()=>{f.mv.patchRecord(song.id,{duration:96,timing:{taps:{4:48},shift:2},exportRange:{range:'custom',rangeFrom:1,rangeTo:2}});f.mv.patchTegaki(song.id,{range:'chorus'});f.mv.patchWardrobe(song.id,{char:'edited clothes'});f.mv.writeMv(f.mv.mvScope(f.host),song.id,r=>{r.groups[0].diffs[0].image={url:'/user/images/latest.png'};return r;});return raw([4,5,6,7]);});
 const result=await f.mv.continueStoryboard(song.id);assert.equal(result.pending,false);const saved=f.mv.readMv(f.host,song.id);assert.equal(saved.groups[0].diffs[0].image.url,'/user/images/latest.png');assert.equal(saved.timing.taps[4],48);assert.equal(saved.duration,96);assert.equal(saved.tegaki.range,'chorus');assert.equal(saved.wardrobe.char,'edited clothes');assert.equal(saved.exportRange.rangeFrom,1);
});
test('regeneration while append is running holds paid append instead of overwriting the replacement',async()=>{
 const f=await setup();realClient(f,()=>{f.mv.writeMv(f.mv.mvScope(f.host),song.id,r=>({...r,shots:[{...r.shots[0],id:'NEW_STORY'}]}));return raw([4,5]);});
 const result=await f.mv.continueStoryboard(song.id);assert.equal(result.pending,true);assert.equal(f.mv.readMv(f.host,song.id).shots[0].id,'NEW_STORY');assert.match(f.mv.exportMvRecovery(result.scope),/line 5/);
});
test('switching chat journals append; fresh runtime can save it once without another request',async()=>{
 const f=await setup();f.mv.writeMv(f.mv.mvScope(f.host),song.id,r=>r);let calls=0;
 realClient(f,()=>{calls++;f.switchTo({...f.host,chatId:'B',chatMetadata:{}});return raw([4,5,6,7]);});
 const result=await f.mv.continueStoryboard(song.id);assert.equal(result.pending,true);assert.equal(f.mv.readMv(f.host,song.id).shots.length,4);
 const g=await setup();for(const[k,v]of f.disk)g.disk.set(k,v);assert.equal((await g.mv.retryMvSave(result.scope,result.id)).pending,false);assert.equal(g.mv.readMv(g.host,song.id).shots.length,8);await g.mv.retryMvSave(result.scope,result.id);assert.equal(g.mv.readMv(g.host,song.id).shots.length,8);assert.equal(calls,1);
});
test('request failure and malformed/out-of-range paid results keep all existing images',async()=>{
 for(const response of [null,{invalid:'PAID_RAW'},raw([0,1])]){
  const f=await setup();const old=plain(f.record);f.get('generation/client').requestJson=async()=>{if(!response)throw Error('offline');return response;};
  if(!response)await assert.rejects(f.mv.continueStoryboard(song.id),/offline/);else {const r=await f.mv.continueStoryboard(song.id);assert.equal(r.pending,true);assert.ok(f.mv.pendingMv(r.scope)[0].raw);}
  assert.deepEqual(plain(f.mv.readMv(f.host,song.id)),old);assert.equal(f.mv.isMvRunning(`story:${f.mv.mvScope(f.host)}:${song.id}`),false);
 }
});
test('legacy shots accept new v2 continuation while preserving existing local images',async()=>{
 const f=await setup();delete f.record.version;delete f.record.groups;f.record.shots.forEach((s,i)=>{s.image={local:`old-${i}`};delete s.group;});
 realClient(f,()=>raw([4,5,6,7]));const result=await f.mv.continueStoryboard(song.id);assert.equal(result.pending,false);const saved=f.mv.readMv(f.host,song.id);assert.equal(f.mv.isV2(saved),false);assert.equal(saved.shots[0].image.local,'old-0');assert.match(saved.shots[4].imagePrompt,/one scene/);
});
test('legacy flat model reply can append to v2 without making new shots undrawable',async()=>{
 const f=await setup();realClient(f,()=>({shots:[{sectionIndex:4,plain:'flat reply',imagePrompt:'walking outside',who:'char'}]}));
 const result=await f.mv.continueStoryboard(song.id);assert.equal(result.pending,false);const r=f.mv.readMv(f.host,song.id),s=r.shots.at(-1);assert.ok(f.mv.assetOf(r,`${s.group}:${s.diff}`));assert.match(f.mv.assetPrompt(r,`${s.group}:${s.diff}`,f.host),/walking outside/);
});
test('normalization retains more than 8 groups, 5 diffs and 2 backgrounds without remapping to first',async()=>{
 const f=await setup(),input=raw(Array.from({length:18},(_,i)=>i));input.groups[17].diffs=Array.from({length:7},(_,i)=>({id:`D${i+1}`,change:`change${i}`}));input.groups[17].bgs=Array.from({length:4},(_,i)=>({id:`B${i+1}`,prompt:`background${i}`}));input.frames[17].diff='D7';input.frames[17].bg='B4';
 const built=f.mv.buildShots(input,f.bank,18,{output:'tegaki'});assert.equal(built.groups.length,18);assert.equal(built.groups[17].diffs.length,7);assert.equal(built.groups[17].bgs.length,4);assert.equal(built.shots[17].group,'G18');assert.equal(built.shots[17].diff,'D7');assert.equal(built.shots[17].bg,'B4');
});
test('range generation no longer treats a stretched previous shot as part of an empty section',async()=>{
 const f=await setup();f.record.tegaki={range:'custom',rangeFrom:4,rangeTo:7};assert.equal(f.mv.shotsInRange(f.record,song).length,0);assert.equal(f.mv.assetKeys(f.record,song).length,0);
});
test('completed clips exclude holes, undrawn diffs and missing cutout backgrounds; optional motif is not a gate',async()=>{
 const f=await setup();f.record.groups[1].diffs[0].image=null;f.record.motif={name:'petals',prompt:'petals',image:null};
 assert.deepEqual(plain(f.mv.completedMvRanges(f.record,song)),[{range:'custom',rangeFrom:0,rangeTo:0},{range:'custom',rangeFrom:2,rangeTo:3}]);
 f.record.groups[2].layer='cutout';assert.deepEqual(plain(f.mv.completedMvRanges(f.record,song)),[{range:'custom',rangeFrom:0,rangeTo:0},{range:'custom',rangeFrom:3,rangeTo:3}]);
});
test('custom partial export uses section times, supports reverse selection, and keeps source data untouched',async()=>{
 const f=await setup();f.record.exportRange={range:'custom',rangeFrom:3,rangeTo:1};const before=plain(f.record);const range=f.mv.exportRange(f.record,song),copy=f.mv.exportRecord(f.record,song);
 assert.equal(range.start,10);assert.equal(range.end,40);assert.deepEqual(plain(f.mv.playbackTimeline(copy,song).rows.map(r=>r.sectionIndex)),[1,2,3]);assert.deepEqual(plain(f.record),before);assert.equal(copy.duration,80);
});
test('manual full/unfinished export is still available and export choice survives save/reload',async()=>{
 const f=await setup();f.mv.patchRecord(song.id,{exportRange:{range:'full'}});assert.equal(f.mv.exportRange(f.mv.readMv(f.host,song.id),song).end,80);
 f.mv.patchRecord(song.id,{exportRange:{range:'custom',rangeFrom:5,rangeTo:7}});const g=await setup();for(const[k,v]of f.disk)g.disk.set(k,v);const range=g.mv.exportRange(g.mv.readMv(g.host,song.id),song);assert.equal(range.start,50);assert.equal(range.end,80);
});
async function uiSetup(){
 const f=await ui(setup),errors=[],loaded=[],drawn=[],downloads=[];
 f.sb.toastr={error:msg=>errors.push(msg),success(){},info(){}};f.sb.Event=Event;
 const g=new Proxy({measureText:t=>({width:String(t).length*12}),drawImage:img=>drawn.push(img.src),getImageData:()=>({data:new Uint8ClampedArray(48*48*4)}),createLinearGradient:()=>({addColorStop(){}}),createRadialGradient:()=>({addColorStop(){}})}, {get:(obj,k)=>k in obj?obj[k]:()=>{}});
 f.canvas.getContext=()=>g;const media=recorderHost(f);
 f.sb.Image=class{constructor(){this.complete=true;this.naturalWidth=540;this.naturalHeight=960;}set src(v){this._src=v;loaded.push(v);if(v.includes('bad'))this.naturalWidth=0;}get src(){return this._src;}};
 const create=f.sb.document.createElement;
 f.sb.document.createElement=tag=>tag==='a'?{click(){downloads.push(this.download);},remove(){}}:create(tag);
 const change=(key,value)=>f.mvui.handleMvChange({target:{dataset:{rmtMvExportRange:key},value:String(value),matches:s=>s==='[data-rmt-mv-export-range]'}});
 const tick=()=>{const entries=[...f.frames.entries()];for(const[id,fn]of entries){f.frames.delete(id);fn();}};
 return {...f,media,errors,loaded,drawn,downloads,change,tick};
}
test('v2 UI displays continuation, invokes it once, and renders both saved and appended groups',async()=>{
 const f=await uiSetup();let calls=0;realClient(f,()=>{calls++;return raw([4,5,6,7]);});f.mvui.openMv({songId:song.id,page:'board'});f.click('group-open','G1');
 assert.match(f.body.innerHTML,/data-rmt-mv="continue-board"/);assert.match(f.body.innerHTML,/补上 4 段/);f.click('continue-board');for(let i=0;i<12&&f.mv.readMv(f.host,song.id).shots.length===4;i++)await flush();
 assert.equal(calls,1);assert.equal(f.mv.readMv(f.host,song.id).shots.length,8);assert.match(f.body.innerHTML,/scene 7/);assert.match(f.body.innerHTML,/\/user\/images\/G1.png/);assert.deepEqual(f.errors,[]);f.mvui.disposeMv();
});
test('export UI selects a completed clip independently of generation range and offers later clips separately',async()=>{
 const f=await uiSetup();f.record.groups[1].diffs[0].image=null;f.mvui.openMv({songId:song.id});f.click('go-tegaki');f.click('editor-drawer','export');
 assert.match(f.body.innerHTML,/已完成：1–1 段/);assert.match(f.body.innerHTML,/已完成：3–4 段/);f.click('export-range','2:3');assert.equal(f.mv.exportRange(f.mv.readMv(f.host,song.id),song).start,20);assert.equal(f.mv.readMv(f.host,song.id).tegaki.range,'full');
 f.change('to',2);assert.equal(f.mv.exportRange(f.mv.readMv(f.host,song.id),song).end,30);f.click('export-range','full');assert.equal(f.mv.exportRange(f.mv.readMv(f.host,song.id),song).end,80);assert.deepEqual(f.errors,[]);f.mvui.disposeMv();
});
test('audio export seeks selected start, omits broken out-of-range image and stops at selected end',async()=>{
 const f=await uiSetup();f.record.groups[3].diffs[0].image={url:'/user/images/bad-unselected.png'};
 f.mvui.openMv({songId:song.id});f.get('extras/mvMedia').putMedia=async()=>true;f.upload();f.audios.at(-1).duration=80;f.audios.at(-1).onloadedmetadata();f.click('go-tegaki');f.click('export-range','1:2');
 f.loaded.length=0;f.click('export');await flush();const recorder=f.media.recorders[0];assert.ok(recorder);assert.equal(recorder.state,'recording');const audio=f.audios.at(-1);assert.equal(audio.currentTime,10);assert.ok(!f.loaded.some(s=>s.includes('bad-unselected')));
 // The active export keeps its frozen clip even if a background/manual edit changes the stored choice.
 f.mv.patchRecord(song.id,{exportRange:{range:'full'}});audio.currentTime=29;f.tick();assert.equal(recorder.state,'recording');audio.currentTime=30;f.tick();assert.equal(recorder.state,'inactive');assert.ok(f.media.tracks.every(t=>t.stopped));assert.deepEqual(f.errors,[]);f.mvui.disposeMv();
});
test('silent export uses the same chosen clip length instead of the whole song',async()=>{
 const f=await uiSetup();let now=1000;f.sb.performance={now:()=>now};f.mvui.openMv({songId:song.id});f.click('go-tegaki');f.click('export-range','1:2');f.click('export');await flush();const recorder=f.media.recorders[0];assert.equal(recorder.state,'recording');
 now+=19000;f.tick();assert.equal(recorder.state,'recording');now+=1100;f.tick();assert.equal(recorder.state,'inactive');assert.deepEqual(f.errors,[]);f.mvui.disposeMv();
});
test('selected unavailable image reports export failure, and explicit stop releases recorder resources',async()=>{
 const f=await uiSetup();f.record.groups[1].diffs[0].image={url:'/user/images/bad-selected.png'};f.mvui.openMv({songId:song.id});f.click('go-tegaki');f.click('export-range','1:1');f.click('export');await flush();assert.equal(f.media.recorders.length,0);assert.equal(f.errors.length,1);
 f.click('export-range','0:0');f.click('export');await flush();assert.equal(f.media.recorders[0].state,'recording');f.click('export-stop');assert.equal(f.media.recorders[0].state,'inactive');assert.equal(f.media.tracks[0].stopped,true);assert.equal(f.media.contexts.length,0);f.mvui.disposeMv();
});
test('recording fallback seeks and stops at its separately selected clip',async()=>{
 const f=await uiSetup();f.mvui.openMv({songId:song.id});f.get('extras/mvMedia').putMedia=async()=>true;f.upload();f.audios.at(-1).duration=80;f.audios.at(-1).onloadedmetadata();f.click('go-tegaki');f.click('export-range','1:2');f.click('record-mode');const countdown=[...f.timers.values()][0];await countdown();await countdown();await countdown();
 const audio=f.audios.at(-1);assert.equal(audio.currentTime,10);assert.equal(audio.paused,false);audio.dispatchEvent=()=>audio.onended?.();audio.currentTime=30;f.tick();assert.equal(audio.paused,true);assert.deepEqual(f.errors,[]);f.mvui.disposeMv();
});
test('storage outage retains the paid append and save-only retry is idempotent without another generation',async()=>{
 const f=await setup();let calls=0;realClient(f,()=>{calls++;f.host.saveMetadataDebounced=()=>{throw Error('disk')};f.sb.localStorage.setItem=()=>{throw Error('quota')};return raw([4,5,6,7]);});
 const result=await f.mv.continueStoryboard(song.id);assert.equal(result.pending,true);assert.equal(result.durable,false);assert.match(f.mv.exportMvRecovery(result.scope),/line 8/);assert.equal(f.mv.readMv(f.host,song.id).groups[0].diffs[0].image.url,'/user/images/G1.png');
 f.sb.localStorage.setItem=(k,v)=>f.disk.set(k,v);assert.equal((await f.mv.retryMvSave(result.scope,result.id)).pending,false);assert.equal(f.mv.readMv(f.host,song.id).shots.length,8);await f.mv.retryMvSave(result.scope,result.id);assert.equal(f.mv.readMv(f.host,song.id).shots.length,8);assert.equal(calls,1);
});
test('paid asset finishing after append still saves to the original group',async()=>{
 const f=await setup(),d=deferred();f.get('generation/cgImageCore').invokeImageGeneration=()=>d.promise;
 const drawing=f.mv.drawAsset(song.id,'G1:D1');realClient(f,()=>raw([4,5,6,7]));await f.mv.continueStoryboard(song.id);d.resolve('/user/images/late-original.png');const saved=await drawing;
 assert.equal(saved.pending,false);assert.equal(f.mv.readMv(f.host,song.id).groups[0].diffs[0].image.url,'/user/images/late-original.png');assert.equal(f.mv.readMv(f.host,song.id).groups[4].diffs[0].image,null);
});
test('export progress starts at zero and measures only the chosen duration',async()=>{
 const f=await uiSetup(),bar={style:{}},label={textContent:''};const query=f.sb.document.querySelector;
 f.sb.document.querySelector=s=>s==='[data-rmt-mv-export-bar]'?bar:s==='[data-rmt-mv-export-time]'?label:query(s);
 f.mvui.openMv({songId:song.id});f.upload();f.audios.at(-1).duration=80;f.audios.at(-1).onloadedmetadata();f.click('go-tegaki');f.click('export-range','1:2');f.click('export');await flush();f.tick();assert.equal(bar.style.width,'0%');assert.equal(label.textContent,'0:00 / 0:20');
 f.audios.at(-1).currentTime=20;f.tick();assert.equal(bar.style.width,'50%');assert.equal(label.textContent,'0:10 / 0:20');f.click('export-stop');assert.deepEqual(f.errors,[]);f.mvui.disposeMv();
});
test('leaving during audio metadata wait cannot restart a cancelled export',async()=>{
 const f=await uiSetup();f.mvui.openMv({songId:song.id});f.upload();f.audios.at(-1).duration=80;f.audios.at(-1).onloadedmetadata();f.click('go-tegaki');f.click('export-range','1:2');
 const Original=f.sb.Audio,events={};f.sb.Audio=class extends Original{constructor(...a){super(...a);this.readyState=0;}addEventListener(type,fn){events[type]=fn;}};
 f.click('export');await flush();assert.equal(f.media.recorders[0].state,'inactive');f.mvui.disposeMv();events.loadedmetadata();await flush();assert.ok(f.audios.every(a=>a.paused!==false));assert.ok(f.media.tracks.every(t=>t.stopped));assert.equal(f.media.recorders[0].state,'inactive');
});
test('a verse-only export does not preload a motif that is only rendered in the chorus',async()=>{
 const f=await uiSetup();f.record.motif={name:'petal',prompt:'petal',image:{url:'/user/images/bad-chorus-only.png'}};f.mvui.openMv({songId:song.id});f.click('go-tegaki');f.click('export-range','1:2');f.click('export');await flush();assert.equal(f.media.recorders[0].state,'recording');assert.ok(!f.loaded.some(s=>s.includes('bad-chorus-only')));assert.deepEqual(f.errors,[]);f.click('export-stop');f.mvui.disposeMv();
});

test('clipping preserves original first-shot timing and beat/lyric boundaries instead of recalculating from zero',async()=>{
 const f=await setup();f.record.exportRange={range:'custom',rangeFrom:2,rangeTo:3};f.record.timing.lineTaps={'2:0':21.25,'3:0':31.25};
 const original=f.mv.shotTimeline(f.record,song).rows.filter(r=>[2,3].includes(r.sectionIndex));const clipped=f.mv.playbackTimeline(f.mv.exportRecord(f.record,song),song).rows;
 assert.deepEqual(plain(clipped),plain(original));assert.equal(clipped[0].start,21.25);
});
