// Existing production-DOM fixture, actual Chromium; not a cloud tavern or TT.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.resolve(process.env.TEST_ROOT || '.');
const out = path.resolve(process.env.UI_TEST_OUTPUT || '/tmp/hearttrace-typography-preview');
fs.mkdirSync(out, { recursive: true });
// Reuse the existing setup verbatim without running its unrelated scenario loop.
const setup = fs.readFileSync(path.join(root, 'tools/verification/mv-ratio-browser.cjs'), 'utf8').split('async function main() {')[0];
const { boot, server, chromium, setImage } = new Function('require', 'process', setup + '\nreturn { boot, server, chromium, setImage: value => { fixtureImage = Buffer.from(value.split(",")[1], "base64"); } };')(require, process);

async function main() {
    await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
    const browser = await chromium.launch({ headless: true, executablePath: process.env.UI_TEST_CHROME || undefined, args: ['--no-sandbox'] });
    const report = { environment: 'Chromium with simulated host, no cloud tavern/TT', layouts: [], pageErrors: [], externalRequests: [] };
    try {
        const context = await browser.newContext({ viewport: { width: 390, height: 844 } });
        const page = await context.newPage(); page.setDefaultTimeout(7000);
        await page.exposeFunction('setFixtureImage', setImage);
        page.on('pageerror', error => report.pageErrors.push(error.message));
        await context.route('**/*', route => {
            if (route.request().url().startsWith('http://127.0.0.1:')) return route.continue();
            report.externalRequests.push(route.request().url()); return route.abort();
        });
        await boot(page);
        await page.evaluate(() => fixture.show('songMv'));
        await page.locator('[data-rmt-mv="editor-tab"][data-rmt-mv-id="look"]').click();
        await page.locator('.rmt-mv-text-layout>summary').click();
        await page.locator('[data-rmt-mv-text-style="textScale"]').fill('1.15');
        await page.locator('[data-rmt-mv-text-style="textScale"]').press('Tab');
        await page.locator('[data-rmt-mv-text-style="textTracking"]').fill('0.12');
        await page.locator('[data-rmt-mv-text-style="textTracking"]').press('Tab');
        await page.locator('[data-rmt-mv-text-style="textLeading"]').fill('1.25');
        await page.locator('[data-rmt-mv-text-style="textLeading"]').press('Tab');
        for (const width of [320, 390, 768, 1366]) {
            await page.setViewportSize({ width, height: 900 });
            await page.locator('.rmt-mv-text-layout').scrollIntoViewIfNeeded();
            const state = await page.evaluate(() => {
                const group = document.querySelector('.rmt-mv-text-layout');
                const body = document.querySelector('.rmt-body'), panel = document.querySelector('.rmt-mve-panel');
                const inputs = [...group.querySelectorAll('input')].map(el => ({ value: Number(el.value), width: el.getBoundingClientRect().width, left: el.getBoundingClientRect().left, right: el.getBoundingClientRect().right }));
                const summary = group.querySelector('summary'), css = getComputedStyle(summary);
                const record = fixture.get('extras/mv').readMv(fixture.host, fixture.song.id);
                return { inputs, open: group.open, overflow: Math.max(body.scrollWidth - body.clientWidth, panel.scrollWidth - panel.clientWidth),
                    radius: css.borderRadius, border: css.borderTopWidth, stored: record.tegaki, errorPage: body.textContent.includes('这一页没能打开') };
            });
            assert.equal(state.open, true); assert.equal(state.errorPage, false); assert.ok(state.overflow <= 1);
            assert.deepEqual(state.inputs.map(x => x.value), [1.15, .12, 1.25]);
            assert.ok(state.inputs.every(x => x.width > 40 && x.left >= 0 && x.right <= width));
            assert.ok(parseFloat(state.radius) >= 20); assert.ok(parseFloat(state.border) >= 1);
            for (const [key, value] of Object.entries({ textScale: 1.15, textTracking: .12, textLeading: 1.25 })) assert.equal(state.stored[key], value);
            report.layouts.push({ width, ...state });
            if (width === 390 || width === 1366) await page.screenshot({ path: path.join(out, `typography-${width}.png`) });
        }
        await page.locator('[data-rmt-mv="tegaki-text-reset"]').click();
        assert.equal(await page.locator('[data-rmt-mv-text-style="textTracking"]').inputValue(), '0');
        assert.deepEqual(report.pageErrors, []); assert.deepEqual(report.externalRequests, []);
        report.toasts = await page.evaluate(() => fixture.errors); assert.deepEqual(report.toasts, []);
        fs.writeFileSync(path.join(out, 'typography-browser.json'), JSON.stringify(report, null, 2));
        console.log(JSON.stringify({ layouts: report.layouts.length, pageErrors: report.pageErrors, externalRequests: report.externalRequests, output: out }));
    } finally { await browser.close(); await new Promise(resolve => server.close(resolve)); }
}
main().catch(error => { console.error(error); server.close(); process.exitCode = 1; });
