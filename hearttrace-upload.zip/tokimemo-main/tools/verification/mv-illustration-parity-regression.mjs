// Feature-specific boundary against the delivered pre-feature build, not the
// historical UI-only redesign rule that disallowed all new non-UI features.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const candidate = path.resolve(process.env.TEST_ROOT || path.join(here, '../..'));
const baseline = path.resolve(process.env.BASELINE_ROOT || '/workspace/scratch/8e568532ca62/candidate-1.0.36/tokimemo-main');

function files(root, prefix = '') {
    return fs.readdirSync(path.join(root, prefix), { withFileTypes: true }).flatMap(entry => {
        const name = prefix ? prefix + '/' + entry.name : entry.name;
        return entry.isDirectory() ? files(root, name) : [name];
    }).sort();
}

test('dynamic illustration only adds two local modules and leaves unrelated source byte-identical to 1.0.36', () => {
    const before = path.join(baseline, 'src'), after = path.join(candidate, 'src');
    const oldFiles = files(before), newFiles = files(after);
    assert.deepEqual(oldFiles.filter(file => !newFiles.includes(file)), [], 'No existing source is removed');
    assert.deepEqual(newFiles.filter(file => !oldFiles.includes(file)), [
        'extras/mvIllustration.js', 'ui/mvIllustrationCanvas.js',
    ]);
    const approved = new Set(['extras/mv.js', 'extras/mvDirection.js', 'ui/mvView.js', 'core/releaseNotes.js']);
    let checked = 0;
    for (const file of oldFiles) {
        if (approved.has(file)) continue;
        const normalize = value => file === 'core/selfUpdater.js'
            ? value.replace(/^(export const INSTALLED_BUILD = )'[^']+';/m, "$1'<release-version>';") : value;
        assert.equal(normalize(fs.readFileSync(path.join(after, file), 'utf8')),
            normalize(fs.readFileSync(path.join(before, file), 'utf8')), file + ' must not change');
        checked++;
    }
    assert.ok(checked >= 300, 'Guard the real generation, persistence, provider and unrelated UI tree');
});
