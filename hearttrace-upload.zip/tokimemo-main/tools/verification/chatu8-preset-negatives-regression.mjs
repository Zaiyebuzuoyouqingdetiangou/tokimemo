import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const root = process.env.TEST_ROOT || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const realm = vm.createContext({});
const modules = new Map();
async function moduleFor(relative) {
    if (modules.has(relative)) return modules.get(relative);
    const source = relative === 'src/core/settings.js' ? 'export function getPluginSettings(context) { return context.settings || {}; }'
        : relative === 'src/core/text.js' ? 'export function normalizeText(value) { return value; }'
            : await fs.readFile(path.join(root, relative), 'utf8');
    const mod = new vm.SourceTextModule(source, { context: realm, identifier: relative });
    modules.set(relative, mod);
    await mod.link((specifier, parent) => moduleFor(path.posix.normalize(path.posix.join(path.posix.dirname(parent.identifier), specifier))));
    return mod;
}
const entry = await moduleFor('src/generation/imageAppearancePresets.js');
await entry.evaluate();
const resolve = entry.namespace.resolveImageAppearancePresets;
const direct = modules.get('src/generation/chatu8Presets.js').namespace.chatu8PresetAppearance;
const plain = value => JSON.parse(JSON.stringify(value));
const context = presets => ({ settings: { imageGenerationProvider: 'chatu8-image' },
    extensionSettings: { 'st-chatu8': { characterPresets: presets } } });
const preset = (negative, fields = {}) => ({ nameEN: 'Alex', characterTraits: 'blonde hair, pale skin', facialFeatures: 'blue eyes',
    facialFeaturesBack: 'short nape hair', ...(negative === undefined ? {} : { negative }), ...fields });
const people = [{ id: 'a', name: 'Alex' }];

test('absent or empty character negative preserves the old result shape', () => {
    for (const negative of [undefined, '', ' \n\t ']) {
        const ctx = context({ a: preset(negative) });
        const expected = { tag: 'blonde hair, pale skin, blue eyes', source: 'chatu8', presetKey: 'a' };
        assert.deepEqual(plain(direct(ctx, 'Alex')), expected);
        assert.deepEqual(plain(resolve(ctx, people).get('a')), expected);
    }
});

test('each unique preset carries only its own literal negative through the shared resolver', () => {
    const ctx = context({ a: preset('red hair, brown eyes'), b: preset('blonde hair, blue eyes', { nameEN: 'Beth', characterTraits: 'black hair' }) });
    const before = JSON.stringify(ctx);
    const result = resolve(ctx, [...people, { id: 'b', name: 'Beth' }]);
    assert.equal(result.get('a').negative, 'red hair, brown eyes');
    assert.equal(result.get('b').negative, 'blonde hair, blue eyes');
    assert.equal(JSON.stringify(ctx), before);
});

test('literal weighting, punctuation and internal newlines are preserved without reinterpretation', () => {
    const negative = '  {{red hair, brown eyes}}, [blue skin], (extra fingers:1.3);\n2::missing fingers::  ';
    const ctx = context({ a: preset(negative) });
    assert.equal(direct(ctx, 'Alex').negative, negative.trim());
    assert.equal(resolve(ctx, people).get('a').negative, negative.trim());
});

test('malformed or dynamic negative is omitted independently of valid positive appearance', () => {
    for (const negative of [null, false, 123, {}, ['red hair'], '$Missing$', 'red hair, $Other$', '{{char}}', '{{getvar::negative}}',
        '{{unknown::negative}}', '{{random::red hair::blue hair}}']) {
        const ctx = context({ a: preset(negative) });
        for (const result of [direct(ctx, 'Alex'), resolve(ctx, people).get('a')]) {
            assert.equal(result.tag, 'blonde hair, pale skin, blue eyes');
            assert.equal(Object.hasOwn(result, 'negative'), false);
        }
    }
});

test('negative getters and unsupported negative descriptors cannot break a valid positive identity', () => {
    let reads = 0;
    const getter = preset(undefined);
    Object.defineProperty(getter, 'negative', { enumerable: true, get() { reads++; throw Error('must not invoke'); } });
    const proxy = new Proxy(preset(undefined), { getOwnPropertyDescriptor(target, key) {
        if (key === 'negative') throw Error('unsupported negative field');
        return Object.getOwnPropertyDescriptor(target, key);
    } });
    for (const row of [getter, proxy]) {
        const ctx = context({ a: row });
        assert.equal(direct(ctx, 'Alex')?.tag, 'blonde hair, pale skin, blue eyes');
        assert.equal(resolve(ctx, people).get('a')?.tag, 'blonde hair, pale skin, blue eyes');
        assert.equal(Object.hasOwn(direct(ctx, 'Alex'), 'negative'), false);
    }
    assert.equal(reads, 0);
});

test('ambiguous names or shared aliases cannot lend a negative to either person', () => {
    const duplicate = context({ a: preset('red hair'), b: preset('black hair') });
    assert.equal(direct(duplicate, 'Alex'), null);
    assert.equal(resolve(duplicate, people).size, 0);
    const aliases = context({ a: preset('red hair', { nameEN: 'Alex|Alexander', nameCN: '小亚' }),
        b: preset('blue hair', { nameEN: 'Beth' }) });
    assert.equal(direct(aliases, '小亚').negative, 'red hair');
    const result = resolve(aliases, [...people, { id: 'alias', name: '小亚' }, { id: 'b', name: 'Beth' }]);
    assert.deepEqual([...result.keys()], ['b']);
    assert.equal(result.get('b').negative, 'blue hair');
});

test('full, back and hands preserve character exclusions without treating them as positive traits', () => {
    const negative = '{{red eyes}}, long hair, extra fingers, white gloves';
    const ctx = context({ a: preset(negative) });
    for (const visible of ['full', 'face', 'back', 'hands']) {
        assert.equal(direct(ctx, 'Alex', { visible }).negative, negative);
        assert.equal(resolve(ctx, [{ ...people[0], visible }]).get('a').negative, negative);
    }
    const backOnly = context({ a: preset(negative, { characterTraits: '', facialFeatures: '', facialFeaturesBack: 'short nape hair' }) });
    assert.equal(resolve(backOnly, [{ ...people[0], visible: 'back' }]).get('a').negative, negative);
    assert.equal(resolve(backOnly, people).size, 0);
});

test('character negative has no additional length cap', () => {
    const negative = 'red hair, '.repeat(4000) + '{{extra fingers}}';
    const ctx = context({ a: preset(negative) });
    assert.equal(direct(ctx, 'Alex').negative, negative);
    assert.equal(resolve(ctx, people).get('a').negative, negative);
});

test('BaiBai retains its public schema and never reads an undeclared character negative', () => {
    let reads = 0;
    const row = { name: 'Alex', tag: 'black hair' };
    Object.defineProperty(row, 'negative', { get() { reads++; throw Error('not in public API'); } });
    const api = { apiVersion: 1, capabilities: { characterLibrary: true }, getCharacters() { return { apiVersion: 1, characters: [row] }; } };
    const result = resolve(context({ a: preset('red hair') }), people, { provider: 'baibai-image', api });
    assert.deepEqual(plain(result.get('a')), { tag: 'black hair', source: 'baibai', presetKey: 'Alex' });
    assert.equal(reads, 0);
});
