import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';
import { ui } from './mv-ui-fixture.mjs';

const song = { id: 'SONG_nav', title: 'Navigation', lyrics: '[Verse]\none\n[Chorus]\ntwo' };
const tick = () => new Promise(resolve => setImmediate(resolve));
async function setup() {
    const f = await fixture(), mv = f.get('extras/mv');
    f.get('core/cache').loadSession = () => ({ songs: [song] });
    f.host.chatMetadata[mv.MV_KEY] = { songs: { [song.id]: {
        version: 2, storyRevision: 'original', settings: { output: 'tegaki', range: 'full' },
        groups: [{ id: 'G1', layer: 'full', diffs: [{ id: 'D1', label: 'picture', image: { url: '/user/images/original.png' } }] }],
        shots: [{ id: 'S1', group: 'G1', diff: 'D1', lyric: 'one', sectionIndex: 0 }],
    } } };
    return { ...f, mv };
}
async function screen() {
    const f = await ui(setup); let html = '', editor;
    f.sb.Image = class { constructor() { this.complete = false; } };
    // Browser clamps a scrolled container when a shorter page replaces its contents.
    Object.defineProperty(f.body, 'innerHTML', { get: () => html, set: value => { html = value; f.body.scrollTop = 0; } });
    f.body.querySelector = selector => selector === '[data-rmt-mv-editor-host]' ? {} : null;
    f.body.querySelectorAll = () => [];
    f.get('ui/mvImageEditor').mountAssetEditor = (_host, options) => { editor = options; return { dispose() {} }; };
    f.get('ui/workspace').openWorkspaceTab = () => { throw Error('must not leave the current module'); };
    f.sb.document.querySelectorAll = () => [];
    f.mvui.openMv({ songId: song.id });
    return { ...f, editor: () => editor };
}
function toolbarBack(f) {
    const button = { dataset: { rmtAction: 'back' } };
    f.get('ui/overlayCore').handleOverlayClick({ target: { closest: selector => selector === '[data-rmt-action]' ? button : null },
        currentTarget: { querySelector: () => null }, preventDefault() {}, stopPropagation() {} });
}

test('saving an MV prompt returns to its picture without changing images or generating', async () => {
    const f = await screen(); let generated = 0;
    f.get('generation/cgImageCore').invokeImageGeneration = async () => { generated++; throw Error('unexpected generation'); };
    f.body.scrollTop = 1234;
    f.click('edit-asset', 'G1:D1'); await tick();
    assert.ok(f.editor());
    assert.equal(await f.editor().onSave({ prompt: 'my custom prompt' }), true);
    f.editor().onClose();
    assert.equal(f.body.scrollTop, 1234);
    assert.match(f.body.innerHTML, /构图卡片/);
    assert.equal(f.mv.readMv(f.host, song.id).assetPrompts['G1:D1'], 'my custom prompt');
    assert.equal(f.mv.readMv(f.host, song.id).groups[0].diffs[0].image.url, '/user/images/original.png');
    assert.equal(generated, 0); f.mvui.disposeMv();
});

test('toolbar returns from material editor to the same picture and leaves unsaved prompt unchanged', async () => {
    const f = await screen(); f.body.scrollTop = 850;
    f.click('edit-asset', 'G1:D1'); await tick();
    toolbarBack(f);
    assert.equal(f.body.scrollTop, 850);
    assert.match(f.body.innerHTML, /构图卡片/);
    assert.equal(f.mv.readMv(f.host, song.id).assetPrompts, undefined); f.mvui.disposeMv();
});

test('same-page image completion rerenders keep the current scroll position', async () => {
    const f = await screen(); f.body.scrollTop = 763;
    f.mvui.renderMv(); assert.equal(f.body.scrollTop, 763); f.mvui.disposeMv();
});

test('preview and timing return one level at a time, restoring each parent position', async () => {
    const f = await screen(); f.body.scrollTop = 1450;
    f.click('go-tegaki'); f.body.scrollTop = 315;
    f.click('go-sync'); toolbarBack(f);
    assert.match(f.body.innerHTML, /手书剪辑台/); assert.equal(f.body.scrollTop, 315);
    toolbarBack(f); assert.match(f.body.innerHTML, /构图卡片/); assert.equal(f.body.scrollTop, 1450);
    f.mvui.disposeMv();
});

test('page-local return works through the overlay click dispatcher without exiting to interactions', async () => {
    const f = await screen(); f.body.scrollTop = 510;
    f.click('go-tegaki'); assert.match(f.body.innerHTML, /data-rmt-mv="back"/);
    const button = { dataset: { rmtMv: 'back' } };
    f.get('ui/overlayCore').handleOverlayClick({ target: { closest: selector => selector === '[data-rmt-mv]' ? button : null },
        currentTarget: { querySelector: () => null }, preventDefault() {}, stopPropagation() {} });
    assert.match(f.body.innerHTML, /构图卡片/); assert.equal(f.body.scrollTop, 510); f.mvui.disposeMv();
});

test('old editor callbacks cannot restore the previous song page after leaving and reopening', async () => {
    const f = await screen(); f.body.scrollTop = 999;
    f.click('edit-asset', 'G1:D1'); await tick(); const old = f.editor();
    f.mvui.disposeMv(); f.mvui.openMv({ songId: song.id }); f.body.scrollTop = 75;
    old.onClose(); assert.equal(f.body.scrollTop, 75);
    assert.equal(await old.onSave({ prompt: 'late' }), false); f.mvui.disposeMv();
});

test('picture anchor, expanded inspection and horizontal thumbnails survive changed layout', async () => {
    const f = await screen(); let pictureY = 1400;
    const detail = { open: true }, strip = { scrollLeft: 185 };
    const anchor = { dataset: { rmtMvAnchor: 'G1:D1' }, getBoundingClientRect: () => ({ top: 100 + pictureY - f.body.scrollTop, bottom: 196 + pictureY - f.body.scrollTop }) };
    f.body.getBoundingClientRect = () => ({ top: 100 });
    f.body.querySelectorAll = selector => selector === '[data-rmt-mv-anchor]' ? [anchor] : selector === 'details:not(.rmt-mv-inspect)' ? [detail] : [strip];
    f.body.scrollTop = 1200;
    f.click('edit-asset', 'G1:D1'); await tick();
    pictureY += 180; detail.open = false; strip.scrollLeft = 0;
    f.editor().onClose();
    assert.equal(f.body.scrollTop, 1380); assert.equal(anchor.getBoundingClientRect().top, 300);
    assert.equal(detail.open, true); assert.equal(strip.scrollLeft, 185); f.mvui.disposeMv();
});

test('completed timing navigation does not make a preview/timing back loop', async () => {
    const f = await screen(); f.body.scrollTop = 660;
    f.click('go-tegaki'); f.click('go-sync'); f.click('go-tegaki');
    toolbarBack(f); assert.match(f.body.innerHTML, /构图卡片/); assert.equal(f.body.scrollTop, 660); f.mvui.disposeMv();
});

test('preserving page state never reverses an explicit inspection expand/collapse click', async () => {
    const f = await screen(); let overwritten = false; const scheduled = [];
    f.sb.setTimeout = callback => { scheduled.push(callback); return scheduled.length; };
    const inspection = { get open() { return /class="rmt-mv-inspect" open/.test(f.body.innerHTML); }, set open(_v) { overwritten = true; } };
    f.body.querySelectorAll = selector => selector === 'details' ? [inspection] : [];
    f.click('inspect', 'G1'); scheduled.shift()(); assert.equal(inspection.open, true);
    f.click('inspect', 'G1'); scheduled.shift()(); assert.equal(inspection.open, false);
    assert.equal(overwritten, false); f.mvui.disposeMv();
});

test('closed editor callbacks cannot dismiss a newer editor in the same song', async () => {
    const f = await screen(); f.click('edit-asset', 'G1:D1'); await tick(); const old = f.editor();
    old.onClose(); f.click('edit-asset', 'G1:D1'); await tick();
    old.onClose(); assert.match(f.body.innerHTML, /data-rmt-mv-editor-host/);
    assert.equal(await old.onSave({ prompt: 'old' }), false); f.mvui.disposeMv();
});

test('rapid repeated edit clicks still return once to the original picture', async () => {
    const f = await screen(); f.body.scrollTop = 711;
    f.click('edit-asset', 'G1:D1'); f.click('edit-asset', 'G1:D1'); await tick();
    f.editor().onClose(); assert.match(f.body.innerHTML, /构图卡片/);
    assert.doesNotMatch(f.body.innerHTML, /data-rmt-mv-editor-host/);
    assert.equal(f.body.scrollTop, 711); f.mvui.disposeMv();
});

test('the first successful storyboard becomes the root instead of returning to the generate wizard', async () => {
    const f = await screen(); const complete = structuredClone(f.mv.readMv(f.host, song.id));
    f.mv.writeMv(f.mv.mvScope(f.host), song.id, r => ({ ...r, shots: [] }));
    f.mvui.openMv({ songId: song.id });
    let generations = 0, returns = 0;
    f.mv.generateStoryboard = async () => { generations++; f.mv.writeMv(f.mv.mvScope(f.host), song.id, () => complete); return { pending: false }; };
    f.get('ui/overlay').openCachedOrGenerate = () => { returns++; };
    f.click('setup-generate'); await tick();
    assert.match(f.body.innerHTML, /构图卡片/); toolbarBack(f);
    assert.equal(returns, 1); assert.equal(generations, 1); f.mvui.disposeMv();
});

test('pending save keeps the editor open and still allows returning without losing the original picture', async () => {
    const f = await screen(); f.body.scrollTop = 905;
    f.mv.saveAssetEdit = async () => ({ pending: true, message: 'saved for retry' });
    f.click('edit-asset', 'G1:D1'); await tick();
    assert.equal(await f.editor().onSave({ prompt: 'unsaved' }), false);
    f.mvui.renderMv(); assert.match(f.body.innerHTML, /data-rmt-mv-editor-host/);
    toolbarBack(f); assert.equal(f.body.scrollTop, 905);
    assert.equal(f.mv.readMv(f.host, song.id).groups[0].diffs[0].image.url, '/user/images/original.png'); f.mvui.disposeMv();
});

async function albumScreen() {
    const f = await screen(), state = f.get('core/state').state;
    state.activeMode = f.constants.MODE.ALBUM;
    state.activeSession = { kind: f.constants.MODE.ALBUM, title: 'Album', page: 1, pageSize: 8, category: '全部', selectedId: 'A1',
        entries: [{ id: 'A1', title: 'Picture', date: '2026/07/01', desc: 'Memory', unlocked: true, comments: ['hello'], cgImage: { url: '/user/images/picture.png' } }] };
    f.get('generation/imageGeneration').cgImageProviderBar = () => '';
    f.get('generation/imageGeneration').cgImageProgressHtml = () => '';
    f.get('generation/imageGeneration').cgImageLayerHtml = () => '<img alt="saved picture">';
    f.get('ui/cgFormatControl').mountCgFormatControl = () => {};
    f.get('ui/albumView').renderAlbum();
    return { ...f, state, album: f.get('ui/albumView') };
}

test('album thumbnails have no rabbit menu but retain memory and detail image actions', async () => {
    const f = await albumScreen();
    const card = f.body.innerHTML.match(/<article class="rmt-card[\s\S]*?<\/article>/)[0];
    assert.doesNotMatch(card, /rmt-cg-menu|<svg/); assert.match(card, /共同回忆/);
    f.album.albumEnterSharedMemory('A1');
    assert.match(f.body.innerHTML, /data-rmt-action="edit-cg-prompt"/);
    assert.match(f.body.innerHTML, /data-rmt-journal-clip=/);
});

test('album detail has a local return and toolbar returns to the scrolled album', async () => {
    const f = await albumScreen(); f.body.scrollTop = 640;
    f.album.albumEnterSharedMemory('A1'); assert.match(f.body.innerHTML, /返回回忆相簿/);
    toolbarBack(f); assert.equal(f.state.activeSession.sharedMemory, false);
    assert.equal(f.body.scrollTop, 640); assert.match(f.body.innerHTML, /class="rmt-album"/);
});

test('read-only album hides write actions and a different album cannot inherit the return position', async () => {
    const f = await albumScreen(); f.body.scrollTop = 812;
    f.album.albumEnterSharedMemory('A1');
    f.state.activeSession = structuredClone(f.state.activeSession);
    f.state.activeArchiveSnapshot = { characterName: 'archived' }; f.state.activeArchiveReadOnly = true;
    f.album.renderSharedMemory();
    assert.doesNotMatch(f.body.innerHTML, /data-rmt-action="edit-cg-prompt"|data-rmt-journal-clip=/);
    toolbarBack(f); assert.equal(f.body.scrollTop, 0);
});
