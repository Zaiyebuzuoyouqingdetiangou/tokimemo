// Read-only synchronous UI probe. Synthetic 86-memory / 20-picture metadata and
// four recovery segments; no browser layout, image decoding, provider or TT host.
import { fixture } from './fixture.mjs';
import { performance } from 'node:perf_hooks';
const f = await fixture(), g = f.get, c = f.constants;
f.sb.structuredClone = value => value === undefined ? undefined : f.json(value);
const now = Date.now(), recipePrompt = '公共记忆材料'.repeat(3000);
const journal = f.json({ kind: 'generation-recovery', version: 1,
    identity: { characterKey: 'char.png|slot:0', characterId: '0', characterAvatar: 'char.png', chatId: 'A', archiveRevision: 'r1', archiveTargetEntryId: '', mode: 'album' },
    settingsHash: 'a'.repeat(64), createdAt: now - 1000, updatedAt: now - 100, draftId: 'probe', pageId: 'album',
    contentSnapshotVersion: 1, contentSnapshot: {
        memoryBank: { ...f.bank, memories: Array.from({ length: 86 }, (_, i) => ({ id: `M${i}`, summary: '记忆的内容'.repeat(80) })) },
        previous: { entries: Array.from({ length: 20 }, (_, i) => ({ id: `CG${i}`, desc: '画面描述'.repeat(80), comments: ['旧对白'.repeat(70)], cgImage: { url: 'https://example.test/image.jpg' } })) },
    },
    segments: Array.from({ length: 4 }, (_, i) => ({ slot: `album:comments:${i}`, requestHash: 'b'.repeat(64), state: i < 2 ? 'complete' : 'retry',
        ...(i < 2 ? { rawJson: JSON.stringify({ comments: ['共同回忆'.repeat(600)] }) } : { failureCode: 'RMT_CONNECTION_FAILED' }),
        requestRecipe: { version: 1, identity: { contextEnvelope: recipePrompt, prompt: recipePrompt }, actualPrompt: recipePrompt + '\n' + recipePrompt } })),
});
f.host.chatMetadata[c.CACHE_KEY] = f.json({ chatId: 'A', archiveRevision: 'r1',
    [g('core/cache').GENERATION_DRAFTS_CACHE_KEY]: { version: 1, records: { probe: { status: 'open', journal } } } });
const node = () => ({ hidden: false, textContent: '', innerHTML: '', scrollTop: 0, setAttribute() {}, classList: { toggle() {} } });
const element = node(), panel = node(); panel.hidden = process.argv[2] !== 'open';
f.sb.document.querySelector = selector => selector.includes('data-rmt-task-center') ? panel
    : selector.includes('data-rmt-live-tasks') || selector.includes('data-rmt-task-count') ? element : null;
f.sb.document.querySelectorAll = () => [];
g('archive/repository').getCurrentArchiveImportRecoverySummary = () => null;
g('archive/repository').getCurrentArchiveProfileRecoverySummary = () => null;
let reads = [];
const read = g('core/cache').listGenerationDrafts;
g('core/cache').listGenerationDrafts = (...args) => { const result = read(...args); reads.push(result); return result; };
const measurements = [];
for (let i = 0; i < 5; i++) {
    reads = [];
    const start = performance.now(); g('ui/taskCenter').syncTaskCenterChrome({ refreshRecovery: true });
    const ms = +(performance.now() - start).toFixed(1);
    measurements.push({ ms, draftReads: reads.length, draftReadChars: reads.reduce((total, rows) => total + JSON.stringify(rows).length, 0) });
}
console.log(JSON.stringify({ syntheticJournalChars: JSON.stringify(journal).length, taskPanelOpen: !panel.hidden, measurements }));
