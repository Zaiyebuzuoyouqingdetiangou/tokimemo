// Real production bundle and DOM; only the host, stored records and provider boundary are fixtures.
// TEST_ROOT=$PWD UI_TEST_CHROME=/path/to/chrome node tools/verification/ui-refresh-browser.cjs
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const assert = require('node:assert/strict');
const { chromium } = require(require.resolve('playwright', { paths: [process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES || process.cwd()] }));
const root = path.resolve(process.env.TEST_ROOT || '.');
const out = path.resolve(process.env.UI_TEST_OUTPUT || path.join(root, 'verification/ui-refresh'));
fs.mkdirSync(out, { recursive: true });
const source = fs.readFileSync(path.join(root, 'dist/heartbeatMemories.bundle.js'), 'utf8');
const names = [...source.matchAll(/^const (__m_\w+) = Object.create\(null\);/gm)].map(m => m[1]);
const exposed = source + '\nwindow.__rmtModules={' + names.join(',') + '};';
const font = process.env.UI_TEST_FONT && fs.readFileSync(process.env.UI_TEST_FONT);
let fixtureImage;
const server = http.createServer((req, res) => {
  if (req.url === '/runtime.js') { res.setHeader('Content-Type', 'text/javascript; charset=utf-8'); return res.end(exposed); }
  if (req.url === '/fixture.woff' && font) { res.setHeader('Content-Type', 'font/woff'); return res.end(font); }
  if (req.url === '/user/images/fixture.png' && fixtureImage) { res.setHeader('Content-Type', 'image/png'); return res.end(fixtureImage); }
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.end('<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>' + (font ? '@font-face{font-family:"Microsoft YaHei";src:url(/fixture.woff)}' : '') + '*{box-sizing:border-box}body{margin:0;font-family:system-ui,"Microsoft YaHei",sans-serif;background:#ddd}button,input,textarea,select{font:inherit}button{cursor:pointer}button:disabled{cursor:default}</style><script type="module" src="/runtime.js"></script>');
});

async function boot(page) {
  await page.goto('http://127.0.0.1:' + server.address().port);
  await page.waitForFunction(() => !!window.__rmtModules);
  await page.evaluate(async () => {
    const get = p => window.__rmtModules['__m_' + (p + '.js').replace(/[^a-zA-Z0-9]/g, '_')];
    const constants = get('core/constants');
    const bank = { version: 3, archiveRevision: 'ui-r1', chatId: 'UI_TEST', characterName: '角色', userName: '你', archiveName: '我们的故事', summary: '从初次相识，到一起走过的每个日常。', memories: [{ id: 'M001', title: '雨后重逢', summary: '两个人在雨后的街道重逢。', anchors: ['重逢'] }] };
    const host = { characterId: 0, characters: [{ name: '角色', avatar: 'fixture.png', data: { description: '测试角色' } }], name1: '你', name2: '角色', chat: [], chatId: 'UI_TEST', getCurrentChatId() { return this.chatId; }, chatMetadata: { [constants.MEMORY_KEY]: bank }, extensionSettings: {}, getTokenCountAsync: async () => 1, saveMetadataDebounced() {}, saveSettingsDebounced() {} };
    window.SillyTavern = { getContext: () => host };
    const errors = []; window.toastr = { error: (...args) => errors.push(args), success() {}, info() {}, warning() {} };
    const settings = get('core/settings').getPluginSettings(host);
    settings.themeMode = 'default';
    get('core/settings').getPluginSettings = () => settings;
    get('archive/repository').requireArchive = () => bank;
    const image = document.createElement('canvas'); image.width = 640; image.height = 360;
    const g = image.getContext('2d'); g.fillStyle = '#dcd8ce'; g.fillRect(0, 0, 640, 360); g.fillStyle = '#919c92'; g.fillRect(50, 40, 240, 320); g.fillStyle = '#d4bdaf'; g.fillRect(330, 80, 250, 280);
    await window.setFixtureImage(image.toDataURL('image/png'));
    const picture = { url: '/user/images/fixture.png', provider: 'fixture', createdAt: 1 };
    const lyrics = '[Verse 1]\n雨落以后，灯还亮着\n你在街口，回头看我\n[Chorus]\n一路走来，愿你记得\n每个故事，都有回声\n[Outro]\n风停以后，我们唱着\n[End]';
    const song = { id: 'SONG_ui', title: '故事的回声', singer: '角色', subject: 'character', subjectTitle: '角色', voice: 'char', language: 'zh', lyrics, stylePrompt: 'warm acoustic pop, 84 BPM, piano, intimate vocals', styleDescription: '温暖的钢琴与木吉他，副歌逐渐明亮。', vocalDescription: '轻声演唱，副歌加入和声。', bpm: 84, createdAt: 1, sourceMemoryIds: ['M001'], cgImage: picture, visual: { cgImage: picture } };
    song.fiction = true; song.sourceMemoryIds = []; song.sourceMemoryAnchor = '';
    const base = { chatId: bank.chatId, archiveRevision: bank.archiveRevision };
    const sessions = {
      themeSong: { ...get('core/themeSongContract').emptyThemeSongs(bank, get('core/context').currentCharacterRuntimeKey(host)), songs: [song, { ...song, id: 'SONG_empty', title: '雨后', cgImage: null, visual: {} }], selectedId: song.id },
      album: { ...base, kind: 'album', category: '全部', page: 1, pageSize: 6, selectedId: '', entries: Array.from({ length: 4 }, (_, i) => ({ id: 'A' + i, title: '雨后重逢 ' + (i + 1), date: '2026/10/01', desc: '两个人在雨后的街道相逢，灯光落在熟悉的身影上。', unlocked: true, cgImage: picture, comments: [], visualSeed: [] })) },
    };
    const coverTarget = get('core/cgTargets').describeExpandedCgTarget(sessions.themeSong, { kind: 'song-cover', containerId: song.id });
    get('core/cgTargets').expandedCgItem(sessions.themeSong, coverTarget).item.cgImage = picture;
    get('core/cache').loadSession = mode => sessions[mode] ? structuredClone(sessions[mode]) : null;
    get('core/cache').getCache = () => sessions;
    const mv = get('extras/mv');
    const raw = { stage: { backgrounds: [{ id: 'main', label: '共享舞台', kind: 'solid', colors: ['#f4e6e9'], prompt: 'empty backdrop' }] }, groups: Array.from({ length: 6 }, (_, i) => ({ id: 'G' + i, composition: '正面半身 · 表情 ' + (i + 1), stageBackground: 'main', scale: 'medium', position: 'center', who: 'char', diffs: [{ id: 'D1', label: '抬眼微笑', imagePrompt: 'one person, gentle smile' }, { id: 'D2', label: '认真注视', imagePrompt: 'one person, steady gaze' }] })), frames: Array.from({ length: 12 }, (_, i) => ({ sectionIndex: Math.floor(i / 4), lyric: '每个故事，都有回声', group: 'G' + Math.floor(i / 2), diff: i % 2 ? 'D2' : 'D1', hold: 1, stage: { text: '回声', layout: 'sides', entrance: 'pop' } })) };
    const mvSettings = mv.normalizeSettings({ output: 'tegaki', ratio: '16:9', range: 'full', storyType: 'expression' });
    const built = mv.buildShots(raw, bank, 3, mvSettings);
    for (const group of built.groups) for (const diff of group.diffs) diff.image = { ...picture };
    const record = { ...built, id: song.id, version: 2, storyRevision: 'ui-original', settings: mvSettings, createdAt: 1, updatedAt: 1, duration: 90, timing: { taps: { 0: 0, 1: 30, 2: 60 }, lineTaps: {} }, tegaki: { range: 'full', lyric: 'stage', introSeconds: 0, outroSeconds: 0, showKeyword: false, showMotif: false } };
    host.chatMetadata[mv.MV_KEY] = { songs: { [song.id]: record } };
    window.fixture = { get, host, bank, settings, sessions, song, record, errors,
      theme(mode) { settings.themeMode = mode; get('core/theme').applyThemeToElement(document.getElementById(constants.OVERLAY_ID), settings); },
      show(route) { if (route === 'settings') get('ui/workspace').openWorkspaceTab('settings'); else if (['archive', 'content'].includes(route)) get('ui/workspace').openWorkspaceTab(route); else if (route === 'songMv') get('ui/mvView').openMv({ songId: song.id }); else get('ui/workspace').handleWorkspaceClick({ target: { closest: () => ({ dataset: { rmtWorkspaceRoute: route } }) } }); },
    };
    get('ui/homeView').showHome();
  });
  await page.evaluate(() => document.fonts.ready);
}

async function main() {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const browser = await chromium.launch({ executablePath: process.env.UI_TEST_CHROME || undefined, headless: true, args: ['--no-sandbox'] });
  const report = { layouts: [], flows: [], errors: [], requests: [] };
  try {
    const context = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 1 });
    const page = await context.newPage();
    page.setDefaultTimeout(8000);
    await page.exposeFunction('setFixtureImage', value => { fixtureImage = Buffer.from(value.split(',')[1], 'base64'); });
    page.on('pageerror', error => report.errors.push(error.message));
    await context.route('**/*', route => {
      const url = route.request().url();
      if (url.startsWith('http://127.0.0.1:') || url.startsWith('data:') || url.startsWith('blob:')) return route.continue();
      report.requests.push(url); return route.abort();
    });
    await boot(page);
    for (const width of [320, 390, 768, 1366]) {
      await page.setViewportSize({ width, height: 900 });
      for (const theme of ['default', 'night']) for (const route of ['settings', 'content', 'archive', 'themeSong', 'album', 'songMv']) {
        await page.evaluate(({ route, theme }) => { fixture.show(route); fixture.theme(theme); }, { route, theme });
        await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
        const layout = await page.evaluate(() => {
          const host = document.getElementById('heartbeat_memories_overlay'), body = host.querySelector('.rmt-body'), nav = host.querySelector('.rmt-workspace-tabs');
          const box = el => { const b = el.getBoundingClientRect(); return { x: b.x, y: b.y, w: b.width, h: b.height, bottom: b.bottom }; };
          return { text: body.innerText.slice(0, 150), body: box(body), nav: box(nav), client: body.clientWidth, scroll: body.scrollWidth, visible: !host.hidden, controls: body.querySelectorAll('button').length };
        });
        report.layouts.push({ width, theme, route, ...layout });
        assert.ok(layout.visible, route + ' hidden');
        assert.ok(layout.scroll <= layout.client + 2, `${route} ${width} ${theme} overflows ${layout.scroll}/${layout.client}`);
        if (width <= 760) assert.ok(layout.body.bottom <= layout.nav.y + 1, 'bottom nav covers the scroller');
        assert.ok(!layout.text.includes('这一页没能打开'), route + ' renderer failed');
        if (width === 390 || (width === 1366 && theme === 'default')) await page.screenshot({ path: path.join(out, `${route}-${width}-${theme}.png`) });
      }
    }
    await page.setViewportSize({ width: 390, height: 844 });
    await page.evaluate(() => { fixture.show('settings'); fixture.theme('default'); });
    await page.locator('.rmt-workspace-tabs [data-rmt-workspace-tab="content"]').click();
    await page.locator('[data-rmt-workspace-group="interaction"]').click();
    await page.locator('.rmt-workspace-card [data-rmt-workspace-route="themeSong"]').click();
    assert.equal(await page.locator('.rmt-theme-song').count(), 1);
    assert.equal(await page.locator('[data-rmt-mv="open"]').count(), 1);
    await page.locator('.rmt-song-composer>summary').click();
    await page.locator('[data-rmt-song-direction]').fill('轻快，适合表情卡拍；副歌要留出表情切换的停顿。');
    await page.locator('[data-rmt-song="view-format"]').click();
    assert.equal(await page.locator('[data-rmt-song-presentation="format"]').count(), 1);
    assert.match(await page.locator('[data-rmt-song-direction]').inputValue(), /表情卡拍/);
    assert.equal(await page.locator('[data-rmt-song-direction]').getAttribute('maxlength'), '400');
    await page.locator('[data-rmt-song="view-read"]').click();
    await page.locator('.rmt-song-list [data-rmt-song-id="SONG_empty"]').click();
    assert.equal(await page.locator('.rmt-song-cover-empty').count(), 1);
    await page.locator('.rmt-song-list [data-rmt-song-id="SONG_ui"]').click();
    assert.equal(await page.locator('.rmt-song-cover img.rmt-cg-real').count(), 1);
    await page.locator('.rmt-song-cover .rmt-cg-menu-toggle').click();
    assert.equal(await page.locator('.rmt-song-cover .rmt-cg-menu').evaluate(e => e.open), true);
    await page.locator('.rmt-song-cover .rmt-cg-menu-toggle').click();
    report.flows.push('bottom navigation → category → saved song; single MV action; creative draft survives reading/creation switch; empty cover');
    await page.locator('.rmt-topbar [data-rmt-action="tasks"]').click();
    assert.equal(await page.locator('[data-rmt-task-center]').evaluate(e => e.hidden), false);
    await page.locator('.rmt-topbar [data-rmt-action="tasks"]').click();
    await page.locator('.rmt-topbar [data-rmt-action="toolbar-more"]').click();
    assert.equal(await page.locator('[data-rmt-toolbar-more-menu]').evaluate(e => e.hidden), false);
    await page.keyboard.press('Escape');
    report.flows.push('task panel and more menu open through original delegated handlers');
    await page.evaluate(() => fixture.show('songMv'));
    await page.locator('.rmt-mv-edit-open').nth(4).scrollIntoViewIfNeeded();
    await page.screenshot({ path: path.join(out, 'mv-assets-390.png') });
    const scroll = await page.locator('.rmt-body').evaluate(e => e.scrollTop);
    await page.locator('.rmt-mv-edit-open').nth(4).click();
    await page.evaluate(() => fixture.theme('night'));
    await page.screenshot({ path: path.join(out, 'mv-editor-390-night.png') });
    await page.locator('.rmt-mv-editor textarea').fill('one person, steady gaze, one still image');
    await page.locator('[data-edit="save"]').click();
    await page.waitForSelector('.rmt-mv-gcard');
    const restored = await page.locator('.rmt-body').evaluate(e => e.scrollTop);
    assert.ok(Math.abs(restored - scroll) <= 2, `editor return ${scroll} → ${restored}`);
    report.flows.push({ flow: 'MV prompt save restores picture scroll position', scroll, restored });
    await page.evaluate(() => fixture.show('songMv'));
    await page.locator('[data-rmt-mv="go-tegaki"]').first().click();
    await page.locator('[data-rmt-mv="go-sync"]').first().click();
    assert.ok(await page.locator('[data-rmt-mv="select-section"]').count() >= 3);
    await page.locator('[data-rmt-mv="select-section"][data-rmt-mv-id="1"]').click();
    await page.locator('.rmt-topbar [data-rmt-action="back"]').click();
    assert.ok((await page.locator('.rmt-body').innerText()).includes('手书剪辑台'));
    await page.locator('.rmt-topbar [data-rmt-action="back"]').click();
    assert.ok((await page.locator('.rmt-body').innerText()).includes('构图卡片'));
    report.flows.push('MV preview → timing → section select → back one level → board');
    report.toasts = await page.evaluate(() => fixture.errors);
    assert.deepEqual(report.errors, []);
    assert.deepEqual(report.toasts, []);
    assert.deepEqual(report.requests, []);
    console.log(JSON.stringify({ layouts: report.layouts.length, flows: report.flows.length, errors: report.errors, requests: report.requests }));
  } finally {
    fs.writeFileSync(path.join(out, 'browser-report.json'), JSON.stringify(report, null, 2));
    await browser.close(); server.close();
  }
}
main().catch(error => { console.error(error); server.close(); process.exitCode = 1; });
