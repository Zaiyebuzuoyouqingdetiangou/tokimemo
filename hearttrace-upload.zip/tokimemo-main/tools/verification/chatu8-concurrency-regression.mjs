import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { fixture } from './fixture.mjs';
import { stageSetup, song } from './mv-stage-fixture.mjs';

const flush = async () => { for (let i = 0; i < 8; i++) await new Promise(resolve => setImmediate(resolve)); };
function connect(f, mode = 'comfyui') {
    const source = new EventEmitter(); source.setMaxListeners(0);
    const requests = [], notices = [];
    source.on('generate-image-request', request => requests.push(request));
    f.host.eventSource = source;
    f.host.extensionSettings['st-chatu8'] = { scriptEnabled: true, mode, comfyui_max_concurrency: 10 };
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS, imageGenerationProvider: 'chatu8-image', imageGenerationFallback: false });
    f.sb.toastr = { info: message => notices.push(message), error: message => notices.push(message), success: () => {} };
    const adapter = f.get('generation/chatu8Image');
    const controls = [], tasks = [];
    const start = (targetKey, options = {}) => {
        const controller = new AbortController(); controls.push(controller);
        const promise = adapter.generateChatu8Image('one figure ' + targetKey, { context: f.host, targetKey, signal: controller.signal, ...options });
        promise.catch(() => {}); tasks.push(promise); return promise;
    };
    const reply = (request, suffix = requests.indexOf(request)) => source.emit('generate-image-response', { id: request.id, success: true, imageData: `/user/images/chatu-${suffix}.png` });
    const cleanup = async () => { controls.forEach(controller => controller.abort()); await Promise.allSettled(tasks); };
    return { source, requests, notices, adapter, start, reply, cleanup, controls };
}

test('twelve distinct Chatu8 requests are accepted and out-of-order responses stay paired', async () => {
    const f = await fixture(), c = connect(f), before = JSON.stringify(f.host.extensionSettings);
    let foreign = 0; const observer = () => foreign++;
    c.source.on('generate-image-response', observer);
    try {
        const jobs = Array.from({ length: 12 }, (_, i) => c.start(`target-${i}`));
        assert.equal(c.requests.length, 12);
        assert.equal(new Set(c.requests.map(r => r.id)).size, 12);
        assert.equal(c.adapter.chatu8ImagePendingCount(), 12);
        c.source.emit('generate-image-response', { id: 'another-plugin', success: true, imageData: '/user/images/foreign.png' });
        assert.equal(c.adapter.chatu8ImagePendingCount(), 12);
        for (const request of [...c.requests].reverse()) c.reply(request);
        const results = await Promise.all(jobs);
        assert.deepEqual(results.map(r => r.url), Array.from({ length: 12 }, (_, i) => `/user/images/chatu-${i}.png`));
        assert.equal(c.adapter.chatu8ImagePendingCount(), 0);
        assert.equal(c.source.listenerCount('generate-image-response'), 1);
        assert.equal(foreign, 13);
        assert.equal(JSON.stringify(f.host.extensionSettings), before);
    } finally { await c.cleanup(); }
});

test('same-target dedupe and cancelling one request leave other requests usable', async () => {
    const f = await fixture(), c = connect(f);
    try {
        const a = c.start('A'), b = c.start('B'), other = c.start('C');
        await assert.rejects(c.start('A'), { code: 'CH8_TARGET_BUSY' });
        assert.equal(c.requests.length, 3);
        c.controls[1].abort(); await assert.rejects(b, { code: 'CH8_ABORTED' });
        assert.equal(c.adapter.isChatu8ImageTargetPending('A'), true);
        assert.equal(c.adapter.isChatu8ImageTargetPending('B'), false);
        c.reply(c.requests[2]); c.reply(c.requests[0]);
        assert.equal((await a).url, '/user/images/chatu-0.png');
        assert.equal((await other).url, '/user/images/chatu-2.png');
        assert.equal(c.adapter.chatu8ImagePendingCount(), 0);
        assert.equal(c.source.listenerCount('generate-image-response'), 0);
    } finally { await c.cleanup(); }
});

test('a slow provider queue keeps its response listener and reservation after five minutes', async () => {
    const f = await fixture(), timers = new Map(), c = connect(f, 'novelai'), phases = [];
    let serial = 0, status = 'waiting';
    f.sb.setTimeout = (fn, ms) => { timers.set(++serial, { fn, ms }); return serial; };
    f.sb.clearTimeout = id => timers.delete(id);
    try {
        const job = c.start('slow', { onProgress: p => phases.push(p.phase) });
        job.then(() => { status = 'done'; }, () => { status = 'failed'; });
        assert.equal(timers.size, 1);
        const timer = [...timers.values()][0]; assert.equal(timer.ms, 300000); timer.fn();
        await flush();
        assert.equal(status, 'waiting');
        assert.equal(c.source.listenerCount('generate-image-response'), 1);
        assert.equal(c.adapter.isChatu8ImageTargetPending('slow'), true);
        assert.ok(phases.includes('waiting'));
        await assert.rejects(c.start('slow'), { code: 'CH8_TARGET_BUSY' });
        assert.equal(c.requests.length, 1);
        c.reply(c.requests[0]); await job;
        assert.equal(status, 'done'); assert.equal(timers.size, 0);
    } finally { await c.cleanup(); }
});

test('CG admission permits Chatu8 beyond existing image and general task counts', async () => {
    const f = await fixture(), c = connect(f), state = f.get('core/state').state;
    const core = f.get('generation/cgImageCore'), coordinator = f.get('core/requestCoordinator');
    for (let i = 0; i < 12; i++) state.activeCgImageTasks.set('other-' + i, {});
    assert.equal(core.cgImageStartBlockedReason(f.constants.MODE.ALBUM, 'new', f.host), '');
    assert.equal(coordinator.canStartGenerationTask('cg-new', { ignoreConcurrencyLimit: true }), true);
    assert.equal(coordinator.canStartGenerationTask('ordinary-text'), false);
    state.busy = true;
    assert.equal(coordinator.canStartGenerationTask('cg-new', { ignoreConcurrencyLimit: true }), false);
    state.busy = false;
    state.activeModeBuildScopes.add('same-task');
    assert.equal(coordinator.canStartGenerationTask('same-task', { ignoreConcurrencyLimit: true }), false);
    const key = core.cgImageTaskKey(f.constants.MODE.ALBUM, 'same-image', f.host);
    state.activeCgImageTasks.set(key, {});
    assert.match(core.cgImageStartBlockedReason(f.constants.MODE.ALBUM, 'same-image', f.host), /这张图片/);
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS, imageGenerationProvider: 'baibai-image' });
    assert.equal(core.cgImageStartBlockedReason(f.constants.MODE.ALBUM, 'new', f.host), '');
    await c.cleanup();
});

test('parallel base64 uploads keep their own paths and a save failure never resubmits generation', async () => {
    const f = await fixture(), c = connect(f), uploads = [];
    f.host.getRequestHeaders = () => ({ 'X-CSRF-Token': 'test-token' });
    f.sb.fetch = (url, options) => new Promise(resolve => uploads.push({ url, options, resolve }));
    try {
        const jobs = ['A', 'B', 'C'].map(key => c.start(key));
        const results = Promise.allSettled(jobs);
        for (let i = 0; i < 3; i++) c.source.emit('generate-image-response', {
            id: c.requests[i].id, success: true, imageData: 'data:image/png;base64,' + ['QQ==', 'Qg==', 'Qw=='][i],
        });
        await flush(); assert.equal(uploads.length, 3);
        for (const upload of uploads) {
            assert.equal(upload.url, '/api/images/upload');
            assert.equal(upload.options.headers['X-CSRF-Token'], 'test-token');
            assert.equal(JSON.parse(upload.options.body).format, 'png');
        }
        uploads[2].resolve(new Response(JSON.stringify({ path: '/user/images/upload-C.png' })));
        uploads[1].resolve(new Response('storage failed', { status: 500 }));
        uploads[0].resolve(new Response(JSON.stringify({ path: '/user/images/upload-A.png' })));
        const outcomes = await results;
        assert.equal(outcomes[0].value.url, '/user/images/upload-A.png');
        assert.equal(outcomes[1].reason.code, 'CH8_SAVE_FAILED');
        assert.equal(outcomes[2].value.url, '/user/images/upload-C.png');
        assert.equal(c.requests.length, 3);
        assert.equal(c.adapter.chatu8ImagePendingCount(), 0);
    } finally {
        for (const upload of uploads) upload.resolve(new Response('cleanup', { status: 500 }));
        await c.cleanup();
    }
});

test('MV accepts multiple distinct assets and keeps reverse-order results in their original slots', async () => {
    const f = await stageSetup('image'), c = connect(f);
    const keys = ['G1:D1', 'G2:D1', 'stage:S1'];
    const jobs = keys.map(key => f.mv.drawAsset(song.id, key)); jobs.forEach(job => job.catch(() => {}));
    try {
        assert.equal(c.requests.length, 3);
        for (const request of [...c.requests].reverse()) c.reply(request);
        const outcomes = await Promise.all(jobs);
        assert.ok(outcomes.every(result => !result.pending));
        const record = f.mv.readMv(f.host, song.id);
        assert.equal(record.groups[0].diffs[0].image.url, '/user/images/chatu-0.png');
        assert.equal(record.groups[1].diffs[0].image.url, '/user/images/chatu-1.png');
        assert.equal(record.stage.backgrounds[0].image.url, '/user/images/chatu-2.png');
    } finally {
        for (const request of c.requests) c.reply(request);
        await Promise.allSettled(jobs); await c.cleanup();
    }
});

test('ordinary CG workflow sends ten requests without the shared five-task cap and saves each to its own card', async () => {
    const f = await fixture(), c = connect(f), state = f.get('core/state').state;
    const mode = f.constants.MODE.ALBUM;
    const session = { kind: mode, chatId: 'A', archiveRevision: 'r1', selectedId: 'C0',
        entries: Array.from({ length: 10 }, (_, i) => ({ id: `C${i}`, title: `画面${i}`, cgDesc: `figure ${i}`, unlocked: true })) };
    let stored = structuredClone(session);
    state.activeMode = mode; state.activeSession = session; state.activeArchiveReadOnly = false;
    f.get('archive/library').requireWritableArchiveAction = () => true;
    f.get('archive/repository').getImportedMemory = () => f.bank;
    f.get('core/cache').getCache = () => ({});
    f.get('core/cache').loadSession = () => stored;
    f.get('core/cache').commitSessionMutation = async (kind, chatId, origin, mutate) => {
        assert.equal(kind, mode); assert.equal(chatId, 'A');
        stored = mutate(structuredClone(stored), f.bank); return stored;
    };
    f.get('ui/overlay').confirmExplicitAction = () => true;
    f.get('ui/albumView').renderAlbum = () => {};
    f.get('core/requestCoordinator').noteChatTaskPhase = () => {};
    f.get('core/requestCoordinator').rememberStandaloneChatTask = () => {};
    const actions = f.get('generation/cgImageActions'), jobs = [];
    try {
        for (const item of session.entries) {
            session.selectedId = item.id;
            jobs.push(actions.drawSelectedCgImage({ promptOverride: item.cgDesc, promptMetadata: null }));
        }
        assert.equal(c.requests.length, 10, c.notices.join('\n'));
        assert.equal(state.activeCgImageTasks.size, 10);
        session.selectedId = 'C0';
        await actions.drawSelectedCgImage({ promptOverride: 'same card', promptMetadata: null });
        assert.equal(c.requests.length, 10);
        for (const request of [...c.requests].reverse()) c.reply(request);
        await Promise.all(jobs);
        for (let i = 0; i < 10; i++) assert.equal(stored.entries[i].cgImage?.url, `/user/images/chatu-${i}.png`);
        assert.equal(state.activeCgImageTasks.size, 0);
        assert.equal(c.adapter.chatu8ImagePendingCount(), 0);
    } finally {
        for (const task of state.activeCgImageTasks.values()) task.controller.abort();
        await Promise.allSettled(jobs); await c.cleanup();
    }
});
