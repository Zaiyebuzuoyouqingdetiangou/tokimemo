import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';
import { stageRaw, song } from './mv-stage-fixture.mjs';

const plain = value => JSON.parse(JSON.stringify(value));
async function setup() {
    const f = await fixture();
    f.get('core/cache').loadSession = () => ({ songs: [song] });
    return { ...f, mv: f.get('extras/mv') };
}

test('dynamic illustration is a separate type; all previous types keep their defaults', async () => {
    const f = await setup(), direction = f.get('extras/mvDirection');
    assert.equal(f.mv.normalizeSettings({ storyType: 'illustration' }).storyType, 'illustration');
    assert.equal(direction.directionOf('illustration').name, '动态插画');
    for (const id of ['auto', 'narrative', 'interaction', 'impact', 'loop', 'expression', 'reveal']) {
        assert.equal(direction.directionOf(id).id, id);
        assert.deepEqual(plain(direction.directionDefaults(id)), { motion: 'still', transition: 'cut' });
    }
    assert.deepEqual(plain(direction.directionDefaults('lyrical')), { motion: 'push', transition: 'fade' });
});

test('one storyboard request carries illustration directions, reusable full-color art and optional effects', async () => {
    const f = await setup(); let count = 0, prompt = '';
    f.get('generation/client').requestJson = async p => { count++; prompt = p; return f.json(stageRaw('image')); };
    const result = await f.mv.generateStoryboard(song.id, { storyType: 'illustration', range: 'full' });
    assert.equal(result.pending, false); assert.equal(count, 1);
    const saved = f.mv.readMv(f.host, song.id), example = JSON.parse(prompt.split('\n').at(-1));
    assert.equal(saved.settings.storyType, 'illustration');
    assert.equal(saved.stage.backgrounds.length, 1);
    assert.equal(saved.tegaki.lyric, 'subtitle');
    assert.equal(example.frames[0].diff, example.frames[1].diff);
    assert.ok(example.frames[0].illustration);
    assert.match(prompt, /同一张|同一素材/);
    assert.match(prompt, /显影/);
    assert.doesNotMatch(prompt, /其余段落尽量用新的构图/);
    assert.deepEqual(Array.from(f.mv.assetKeys(saved, song)), ['stage:S1', 'G1:D1', 'G2:D1']);
    assert.ok(saved.shots.every(s => s.illustration));
});

test('missing or invalid optional effects never prevent full-frame or legacy storyboard generation', async () => {
    const f = await setup(), settings = f.mv.normalizeSettings({ storyType: 'illustration' });
    const raw = stageRaw(); delete raw.stage; for (const g of raw.groups) delete g.stageBackground;
    raw.frames[0].illustration = { reveal: 'invalid', seconds: 'bad', light: 'bad' };
    const built = f.mv.buildShots(f.json(raw), f.bank, 2, settings);
    assert.equal(built.shots.length, 4); assert.equal(built.groups[0].layer, 'full');
    assert.equal(built.stage, undefined); assert.equal(built.shots[0].illustration.reveal, 'ink');
    const legacy = f.mv.buildShots(f.json({ shots: [{ plain: '一张主图', imagePrompt: 'a quiet scene' }] }), f.bank, 2, settings);
    assert.equal(legacy.shots.length, 1);
    assert.equal(legacy.shots[0].illustration.reveal, 'ink');
    const ordinary = f.mv.buildShots(f.json(raw), f.bank, 2, f.mv.normalizeSettings({ storyType: 'narrative' }));
    assert.ok(ordinary.shots.every(s => !s.illustration));
});

test('same-picture reveal clock crosses lyrics, seeks deterministically and can be disabled', async () => {
    const f = await setup(), fx = f.get('extras/mvIllustration');
    assert.ok(fx, 'illustration clock module is present');
    const config = { reveal: 'ink', light: 'halo', particles: 'dust', movement: 'parallax', seconds: 6 };
    const record = { settings: { storyType: 'illustration' } };
    const rows = [0, 4, 8].map((start, i) => ({ start, end: start + 4, shot: { id: `F${i}`, group: 'G1', diff: i < 2 ? 'D1' : 'D2', illustration: config } }));
    const a = fx.state(record, rows, 0, 3.99), b = fx.state(record, rows, 1, 4.01);
    assert.ok(b.progress > a.progress); assert.equal(b.start, 0);
    assert.deepEqual(plain(fx.state(record, rows, 1, 4.01)), plain(b));
    assert.equal(fx.state(record, rows, 2, 8.01).start, 8);
    assert.ok(fx.state({ settings: { storyType: 'expression' } }, rows, 0, 1), 'changing the future generation type does not remove saved effects');
    assert.equal(fx.state(record, [{ start: 0, end: 4, shot: { id: 'old' } }], 0, 1), null, 'choosing the new type does not add effects to existing ordinary shots');
    const off = fx.normalize({ reveal: 'none', light: 'none', particles: 'none', movement: 'still' });
    assert.equal(off.reveal, 'none'); assert.equal(off.light, 'none');
});

test('effect edits preserve drawings, timing and other shots with no provider request', async () => {
    const f = await setup(), settings = f.mv.normalizeSettings({ storyType: 'illustration' });
    const record = { ...f.mv.buildShots(f.json(stageRaw()), f.bank, 2, settings), id: song.id, settings, timing: { taps: { 0: 0, 1: 8 } } };
    record.groups[0].diffs[0].image = { url: '/saved.png', crop: [1, 2, 3, 4] };
    f.host.chatMetadata[f.mv.MV_KEY] = { songs: { [song.id]: record } };
    let calls = 0; f.get('generation/client').requestJson = async () => { calls++; };
    f.get('generation/cgImageCore').invokeImageGeneration = async () => { calls++; };
    f.mv.patchIllustration(song.id, record.shots[0].id, { reveal: 'none', particles: 'spark', seconds: 5 });
    const saved = f.mv.readMv(f.host, song.id);
    assert.equal(saved.shots[0].illustration.reveal, 'none');
    assert.equal(saved.shots[0].illustration.particles, 'spark');
    assert.equal(saved.shots[1].illustration.reveal, 'ink');
    assert.deepEqual(plain(saved.groups), plain(record.groups));
    assert.deepEqual(plain(saved.timing), plain(record.timing)); assert.equal(calls, 0);
});

test('many illustration groups remain accepted without a fixed image-count limit', async () => {
    const f = await setup(), settings = f.mv.normalizeSettings({ storyType: 'illustration' });
    const raw = { groups: [], frames: [] };
    for (let i = 0; i < 45; i++) {
        raw.groups.push({ id: `A${i}`, diffs: [{ id: 'D1', imagePrompt: 'one still illustration' }] });
        raw.frames.push({ sectionIndex: 0, group: `A${i}`, diff: 'D1', hold: 1 });
    }
    const built = f.mv.buildShots(f.json(raw), f.bank, 2, settings);
    assert.equal(built.groups.length, 45); assert.equal(built.shots.length, 45);
    assert.equal(f.mv.assetKeys({ ...built, settings }).length, 45);
});

test('changing a local effect while a paid image is in flight preserves both the result and the edit', async () => {
    const f = await setup(), settings = f.mv.normalizeSettings({ storyType: 'illustration' });
    const record = { ...f.mv.buildShots(f.json(stageRaw('image')), f.bank, 2, settings), id: song.id, settings };
    f.host.chatMetadata[f.mv.MV_KEY] = { songs: { [song.id]: record } };
    let resolve, count = 0;
    f.get('generation/cgImageCore').invokeImageGeneration = () => { count++; return new Promise(done => { resolve = done; }); };
    const pending = f.mv.drawAsset(song.id, 'G1:D1');
    f.mv.patchIllustration(song.id, record.shots[0].id, { light: 'none' });
    resolve('/user/images/new-illustration.png');
    assert.equal((await pending).pending, false); assert.equal(count, 1);
    const saved = f.mv.readMv(f.host, song.id);
    assert.equal(saved.shots[0].illustration.light, 'none');
    assert.equal(saved.groups[0].diffs[0].image.url, '/user/images/new-illustration.png');
});
