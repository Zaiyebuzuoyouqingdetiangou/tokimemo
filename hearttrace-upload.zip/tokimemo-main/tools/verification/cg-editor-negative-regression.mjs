import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';

async function editorMetadataFixture({ multi = false, resolved = false } = {}) {
    const f = await fixture();
    let provider = 'chatu8-image';
    f.get('core/settings').getPluginSettings = () => ({ imageGenerationProvider: provider });
    const key = multi ? 'person-a' : 'char';
    const fields = new Map([
        ['[data-rmt-cg-scene-tags]', { value: 'solo, walking' }],
        ['[data-rmt-cg-flat-prompt]', { value: '' }],
        ['[data-rmt-cg-role-selected="char"]', { checked: true }],
        ['[data-rmt-cg-role-selected="user"]', { checked: false }],
        ['[data-rmt-cg-tag-input="char"]', { value: 'silver hair' }],
    ]);
    const current = { multi, characterNames: { char: 'Char', user: 'User' }, appearanceEdited: {},
        appearanceSources: { [key]: { [resolved ? 'resolvedAppearance' : 'presetAppearance']: true,
            negative: 'blonde hair, {{{blue eyes}}}', fallbackTag: 'brown hair' } },
        people: [{ id: key, name: 'Char', sourceRefs: [], selected: true, tag: 'silver hair', nl: '' }],
        element: { querySelector: selector => fields.get(selector) || null },
    };
    return { current, key, fields, provider: value => { provider = value; },
        read: () => f.get('ui/cgPromptEditor').cgEditorPromptMetadata(current) };
}

for (const multi of [false, true]) test(`${multi ? 'participant' : 'legacy'} editor preserves preset negative through non-appearance draft edits`, async () => {
    const e = await editorMetadataFixture({ multi });
    assert.equal(e.read().characters[0].negative, 'blonde hair, {{{blue eyes}}}');
    e.fields.get('[data-rmt-cg-scene-tags]').value = 'solo, sitting';
    assert.equal(e.read().characters[0].negative, 'blonde hair, {{{blue eyes}}}');
    e.current.appearanceEdited[e.key] = true;
    const manual = e.read().characters[0];
    assert.equal(manual.appearanceOverride, true);
    assert.equal(manual.negative, undefined, 'manual appearance cannot inherit a contradictory preset negative');
});

test('editor does not carry Chatu8 negative when the selected provider changes', async () => {
    const e = await editorMetadataFixture();
    assert.ok(e.read().characters[0].negative);
    e.provider('baibai-image');
    assert.equal(e.read().characters[0].negative, undefined);
    e.provider('sillytavern');
    assert.equal(e.read().characters[0].negative, undefined);
});

test('resolved negative remains associated with an unedited row, never an untrusted bare row', async () => {
    const e = await editorMetadataFixture({ resolved: true });
    assert.ok(e.read().characters[0].negative);
    delete e.current.appearanceSources[e.key].resolvedAppearance;
    assert.equal(e.read().characters[0].negative, undefined);
});

// A bounded event host for the actual open-editor preview flow. No provider is
// invoked; the provider boundary supplies the exact channels to be displayed.
class PreviewElement {
    constructor() { this.value = ''; this.checked = false; this.isConnected = true; this.fields = new Map(); this.dataset = {}; }
    querySelector(selector) {
        if (!this.fields.has(selector)) this.fields.set(selector, new PreviewElement());
        return this.fields.get(selector);
    }
    querySelectorAll(selector) { return selector.split(',').map(part => this.querySelector(part.trim())); }
    addEventListener() {}
    removeEventListener() {}
    setAttribute() {}
    removeAttribute() {}
    appendChild(child) { this.child = child; }
    focus() {}
    remove() { this.isConnected = false; }
}

test('public editor preview displays optional flat negative channel without changing ordinary preview', async () => {
    for (const negative of ['', 'blonde hair, {{{blue eyes}}}']) {
        const f = await fixture(), images = f.get('generation/imageGeneration');
        f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS,
            imageGenerationProvider: 'chatu8-image', cgPromptFormat: 'nai45-tags' });
        const item = { id: 'one', title: 'test picture' };
        const target = { mode: f.constants.MODE.CG, session: {}, itemId: item.id,
            origin: f.get('core/context').captureTaskOrigin(f.host, 'r1') };
        Object.assign(images, { selectedCgTarget: () => target, captureCgImageTarget: () => target,
            assertCgImageTargetCurrent() {}, cgItemInSession: () => item, normalizeCgImageRecord: () => null,
            isCgImageDrawing: () => false, hasPendingCgImage: () => false, cgImagePromptForItem: () => 'solo, walking',
            cgEditorSendPreview: () => ({ prompt: 'solo, walking', nl: '', ...(negative ? { negative_prompt: negative } : {}) }),
        });
        f.get('archive/library').requireWritableArchiveAction = () => true;
        const host = new PreviewElement(), shell = host.querySelector('.rmt-shell');
        f.sb.document = { getElementById: () => host, createElement: () => new PreviewElement() };
        f.sb.toastr = { error: message => assert.fail(message) };
        f.get('ui/cgPromptEditor').openCgPromptEditor();
        assert.ok(shell.child, 'editor opened');
        const preview = shell.child.querySelector('[data-rmt-cg-send-preview]').value;
        assert.equal(preview, `prompt:\nsolo, walking${negative ? `\n\nnegative_prompt:\n${negative}` : ''}`);
    }
});
