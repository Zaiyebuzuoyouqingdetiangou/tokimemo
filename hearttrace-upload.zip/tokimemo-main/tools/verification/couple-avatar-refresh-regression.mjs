import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';
import { fixture } from './fixture.mjs';

const root = path.resolve(process.env.TEST_ROOT || '.');
const plain = value => JSON.parse(JSON.stringify(value));

async function setup() {
    const f = await fixture();
    f.host.getCharacterCardFields = () => ({ description: 'black hair, long hair, green eyes', persona: 'silver hair, blue eyes' });
    f.host.extensionSettings[f.constants.EXTENSION_SETTINGS_KEY] = { imageGenerationProvider: 'baibai-image', cgPromptFormat: 'nai5-natural' };
    const library = [], calls = { image: 0, text: 0, saved: 0, confirms: 0 };
    f.sb.STBaiBaiImage = { apiVersion: 1, capabilities: { characterLibrary: true }, getCharacters: () => ({ apiVersion: 1, characters: library }) };
    f.get('generation/cgImageCore').invokeImageGeneration = async () => { calls.image++; throw Error('refresh must not generate'); };
    f.host.generateRaw = async () => { calls.text++; throw Error('refresh must not generate'); };
    f.sb.confirm = () => { calls.confirms++; return true; };
    const couple = f.get('extras/coupleAvatar');
    const save = couple.saveCoupleSettings;
    couple.saveCoupleSettings = async (...args) => { calls.saved++; return save(...args); };
    const modules = new Map();
    async function load(id) {
        if (modules.has(id)) return modules.get(id);
        const fresh = ['extras/coupleAvatarAppearance', 'ui/coupleAvatarView'].includes(id);
        let module;
        if (fresh) {
            let source = await fs.readFile(path.join(root, 'src', id + '.js'), 'utf8');
            if (id === 'ui/coupleAvatarView') source += '\nexport { refreshAppearance, formHtml, draft }; export function activateForTest(view) { active = view; }';
            module = new vm.SourceTextModule(source, { context: vm.createContext(f.sb), identifier: id });
        } else {
            const exports = f.get(id);
            assert.ok(exports, 'runtime dependency: ' + id);
            module = new vm.SyntheticModule(Object.keys(exports), function () {
                for (const [key, value] of Object.entries(exports)) this.setExport(key, value);
            }, { context: vm.createContext(f.sb), identifier: id });
        }
        modules.set(id, module);
        await module.link((specifier, parent) => load(path.posix.normalize(path.posix.join(path.posix.dirname(parent.identifier), specifier)).replace(/\.js$/, '')));
        return module;
    }
    const helper = await load('extras/coupleAvatarAppearance'); await helper.evaluate();
    const ui = await load('ui/coupleAvatarView'); await ui.evaluate();
    const settings = couple.normalizeCoupleSettings({ styleId: 'chibi-doodle', direction: 'keep our pose', people: [
        { id: 'char', name: 'Char', appearance: 'old short black hair', appearanceOverride: true },
        { id: 'user', name: 'User', appearance: 'frozen silver hair', presetAppearance: 'frozen silver hair', fallbackAppearance: 'local brown hair', presetNegative: 'pink hair' },
    ] }, null);
    const inputs = new Map(), status = { textContent: '' };
    for (let i = 0; i < 2; i++) for (const key of ['name', 'appearance']) inputs.set(`[data-pair-person="${i}"][data-pair-key="${key}"]`, { value: settings.people[i][key] });
    const view = { settings, context: f.host, scope: couple.coupleScope(f.host), host: { hidden: false }, draftTimer: 0,
        root: { isConnected: true, querySelector: selector => inputs.get(selector) || null, querySelectorAll: () => [status] },
        records: [{ id: 'frozen-history', settings: plain(settings) }] };
    f.get('core/state').state.activeMode = couple.COUPLE_MODE;
    ui.namespace.activateForTest(view);
    return { ...f, helper: helper.namespace, ui: ui.namespace, couple, settings, library, calls, view, inputs, status };
}

test('explicit refresh reads the current card instead of stale automatic looks or the old avatar draft', async () => {
    const f = await setup();
    f.host.chatMetadata[f.get('core/castLooks').CAST_LOOKS_KEY] = { chatId: 'A', char: 'pink hair', user: 'red hair', manual: false };
    const before = plain(f.settings);
    const result = f.helper.readCoupleAppearance(f.settings, 0, f.host);
    assert.equal(result.source, 'local');
    assert.match(result.person.appearance, /black hair/); assert.match(result.person.appearance, /long hair/);
    assert.doesNotMatch(result.person.appearance, /pink hair|old short/);
    assert.equal(result.person.appearanceOverride, undefined);
    assert.deepEqual(plain(f.settings), before);
    assert.equal(f.calls.image + f.calls.text + f.calls.saved, 0);
});

test('current manually confirmed local looks take precedence over card extraction', async () => {
    const f = await setup();
    f.host.chatMetadata[f.get('core/castLooks').CAST_LOOKS_KEY] = { chatId: 'A', char: 'my preserved literal hair tag', user: 'white blindfold, silver hair', manual: true };
    assert.equal(f.helper.readCoupleAppearance(f.settings, 0, f.host).person.appearance, 'my preserved literal hair tag');
    assert.equal(f.helper.readCoupleAppearance(f.settings, 1, f.host).person.appearance, 'white blindfold, silver hair');
});

test('only the selected provider preset is preferred and custom names cannot receive another role fallback', async () => {
    const f = await setup();
    f.library.push({ name: 'Custom', tag: 'blonde hair, green eyes' });
    f.host.extensionSettings['st-chatu8'] = { characterPresets: { custom: { nameEN: 'Custom', characterTraits: 'purple hair', negative: 'orange hair' } } };
    const custom = plain(f.settings); custom.people[0].name = 'Custom';
    const bbi = f.helper.readCoupleAppearance(custom, 0, f.host);
    assert.equal(bbi.person.appearance, 'blonde hair, green eyes');
    assert.equal(bbi.person.presetAppearance, 'blonde hair, green eyes');
    f.host.extensionSettings[f.constants.EXTENSION_SETTINGS_KEY].imageGenerationProvider = 'chatu8-image';
    const chatu8 = f.helper.readCoupleAppearance(custom, 0, f.host);
    assert.equal(chatu8.person.appearance, 'purple hair'); assert.equal(chatu8.person.presetNegative, 'orange hair');
    f.host.extensionSettings['st-chatu8'] = {};
    assert.equal(f.helper.readCoupleAppearance(custom, 0, f.host), null);
    const wrongId = plain(f.settings); wrongId.people[0].id = 'custom-id';
    assert.equal(f.helper.readCoupleAppearance(wrongId, 0, f.host), null);
});

test('duplicate provider presets fall back locally and no source preserves existing appearance', async () => {
    const f = await setup();
    f.library.push({ name: 'Char', tag: 'blonde hair' }, { name: 'Char', tag: 'red hair' });
    const result = f.helper.readCoupleAppearance(f.settings, 0, f.host);
    assert.equal(result.source, 'local'); assert.match(result.person.appearance, /black hair/);
    f.library.length = 0; f.host.getCharacterCardFields = () => ({});
    const before = plain(f.settings);
    assert.equal(f.helper.readCoupleAppearance(f.settings, 0, f.host), null);
    await f.ui.refreshAppearance(f.view, 0);
    assert.deepEqual(plain(f.view.settings), before);
    assert.match(f.status.textContent, /原内容已保留/); assert.equal(f.calls.saved, 0);
});

test('accepted refresh updates only the selected side and leaves opposite presets, history and other settings exact', async () => {
    const f = await setup();
    f.library.push({ name: 'User', tag: 'new purple hair' });
    const before = plain(f.settings), history = plain(f.view.records);
    await f.ui.refreshAppearance(f.view, 0);
    assert.match(f.view.settings.people[0].appearance, /long hair/);
    assert.equal(f.view.settings.people[0].appearanceOverride, undefined);
    assert.deepEqual(plain(f.view.settings.people[1]), before.people[1]);
    assert.deepEqual(plain(f.view.records), history);
    assert.deepEqual({ ...plain(f.view.settings), people: [] }, { ...before, people: [] });
    const stored = await f.couple.readCouples(f.view.scope);
    assert.deepEqual(plain(stored.settings.people[1]), before.people[1]);
    assert.equal(f.calls.confirms, 1); assert.equal(f.calls.saved, 1); assert.equal(f.calls.image + f.calls.text, 0);
});

test('cancelled replacement leaves manual content and override intact', async () => {
    const f = await setup(), before = plain(f.settings);
    f.sb.confirm = () => false;
    await f.ui.refreshAppearance(f.view, 0);
    assert.deepEqual(plain(f.view.settings), before); assert.equal(f.calls.saved, 0);
});

test('chat changes or selected-field edits during confirmation cannot apply stale refresh results', async () => {
    for (const change of ['chat', 'edit']) {
        const f = await setup(), before = plain(f.settings);
        let approve;
        f.sb.confirm = () => new Promise(resolve => { approve = resolve; });
        const pending = f.ui.refreshAppearance(f.view, 0);
        assert.equal(typeof approve, 'function');
        if (change === 'chat') f.host.chatId = 'B';
        else f.inputs.get('[data-pair-person="0"][data-pair-key="appearance"]').value = 'a new handwritten appearance';
        approve(true); await pending;
        assert.deepEqual(plain(f.view.settings), before); assert.equal(f.calls.saved, 0);
    }
});

test('form contains two explicit refresh actions and conditional BaiBai advice, without changing prompt/history data', async () => {
    const f = await setup(), before = plain(f.settings);
    let html = f.ui.formHtml(f.view);
    assert.equal((html.match(/data-pair-action="refresh-appearance"/g) || []).length, 2);
    assert.match(html, /使用柏宝绘 NAI 时会沿用其画师串和负面词/);
    f.host.extensionSettings[f.constants.EXTENSION_SETTINGS_KEY].imageGenerationProvider = 'chatu8-image';
    html = f.ui.formHtml(f.view);
    assert.doesNotMatch(html, /使用柏宝绘 NAI 时/);
    assert.deepEqual(plain(f.settings), before); assert.equal(f.calls.saved + f.calls.image + f.calls.text, 0);
});

test('refresh resolves current sources again after confirmation instead of applying an obsolete provider snapshot', async () => {
    const f = await setup();
    f.library.push({ name: 'Char', tag: 'red hair' });
    f.host.extensionSettings['st-chatu8'] = { characterPresets: { char: { nameEN: 'Char', characterTraits: 'blonde hair', negative: 'red hair' } } };
    let approve;
    f.sb.confirm = () => new Promise(resolve => { approve = resolve; });
    const pending = f.ui.refreshAppearance(f.view, 0);
    f.host.extensionSettings[f.constants.EXTENSION_SETTINGS_KEY].imageGenerationProvider = 'chatu8-image';
    approve(true); await pending;
    assert.equal(f.view.settings.people[0].appearance, 'blonde hair');
    assert.equal(f.view.settings.people[0].presetNegative, 'red hair');
    assert.equal(f.calls.saved, 1);
});

test('both-person preset collisions are rejected even when refreshing only one side', async () => {
    const f = await setup();
    f.library.push({ name: 'Shared', tag: 'red hair' });
    const both = plain(f.settings);
    both.people[0].name = both.people[1].name = 'Shared';
    assert.equal(f.helper.readCoupleAppearance(both, 0, f.host), null);
    assert.equal(f.helper.readCoupleAppearance(both, 1, f.host), null);
});

test('changed role descriptions during confirmation are read fresh; vanished sources do not erase the old draft', async () => {
    for (const vanished of [false, true]) {
        const f = await setup(), before = plain(f.settings);
        let approve;
        f.sb.confirm = () => new Promise(resolve => { approve = resolve; });
        const pending = f.ui.refreshAppearance(f.view, 0);
        f.host.getCharacterCardFields = () => vanished ? {} : { description: 'white hair, yellow eyes' };
        approve(true); await pending;
        if (vanished) {
            assert.deepEqual(plain(f.view.settings), before);
            assert.match(f.status.textContent, /原内容已保留/); assert.equal(f.calls.saved, 0);
        } else {
            assert.match(f.view.settings.people[0].appearance, /white hair/);
            assert.doesNotMatch(f.view.settings.people[0].appearance, /black hair/); assert.equal(f.calls.saved, 1);
        }
        assert.equal(f.calls.image + f.calls.text, 0);
    }
});
