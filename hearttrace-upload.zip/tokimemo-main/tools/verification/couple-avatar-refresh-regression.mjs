import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';
import { fixture, realClient } from './fixture.mjs';

const root = path.resolve(process.env.TEST_ROOT || '.');
const plain = value => JSON.parse(JSON.stringify(value));

async function setup({ realRequest = false } = {}) {
    const f = await fixture();
    f.host.getCharacterCardFields = () => ({ description: 'black hair, long hair, green eyes', persona: 'silver hair, blue eyes' });
    f.host.extensionSettings[f.constants.EXTENSION_SETTINGS_KEY] = { imageGenerationProvider: 'baibai-image', cgPromptFormat: 'nai5-natural' };
    const library = [], calls = { image: 0, text: 0, saved: 0, confirms: 0, requests: [], response: () => ({ appearance: 'black hair, long hair, green eyes' }) };
    if (!realRequest) f.get('generation/client').requestJson = async (prompt, status, options) => {
        calls.text++; calls.requests.push({ prompt, status, options }); return calls.response(prompt, options);
    };
    f.sb.STBaiBaiImage = { apiVersion: 1, capabilities: { characterLibrary: true }, getCharacters: () => ({ apiVersion: 1, characters: library }) };
    f.get('generation/cgImageCore').invokeImageGeneration = async () => { calls.image++; throw Error('refresh must not generate'); };
    f.host.generateRaw = async () => { throw Error('tests must not reach paid transport'); };
    f.sb.confirm = () => { calls.confirms++; return true; };
    const couple = f.get('extras/coupleAvatar');
    const save = couple.saveCoupleSettings;
    couple.saveCoupleSettings = async (...args) => { calls.saved++; return save(...args); };
    const modules = new Map();
    async function load(id) {
        if (modules.has(id)) return modules.get(id);
        const fresh = ['extras/coupleAvatarAppearance', 'ui/coupleAvatarView'].includes(id);
        let module;
        if (fresh) {
            let source = await fs.readFile(path.join(root, 'src', id + '.js'), 'utf8');
            if (id === 'ui/coupleAvatarView') source += '\nexport { refreshAppearance, formHtml, draft }; export function activateForTest(view) { active = view; }';
            module = new vm.SourceTextModule(source, { context: vm.createContext(f.sb), identifier: id });
        } else {
            const exports = f.get(id);
            assert.ok(exports, 'runtime dependency: ' + id);
            module = new vm.SyntheticModule(Object.keys(exports), function () {
                for (const [key, value] of Object.entries(exports)) this.setExport(key, value);
            }, { context: vm.createContext(f.sb), identifier: id });
        }
        modules.set(id, module);
        await module.link((specifier, parent) => load(path.posix.normalize(path.posix.join(path.posix.dirname(parent.identifier), specifier)).replace(/\.js$/, '')));
        return module;
    }
    const helper = await load('extras/coupleAvatarAppearance'); await helper.evaluate();
    const ui = await load('ui/coupleAvatarView'); await ui.evaluate();
    const settings = couple.normalizeCoupleSettings({ styleId: 'chibi-doodle', direction: 'keep our pose', people: [
        { id: 'char', name: 'Char', appearance: 'old short black hair', appearanceOverride: true },
        { id: 'user', name: 'User', appearance: 'frozen silver hair', presetAppearance: 'frozen silver hair', fallbackAppearance: 'local brown hair', presetNegative: 'pink hair' },
    ] }, null);
    const inputs = new Map(), status = { textContent: '' };
    for (let i = 0; i < 2; i++) for (const key of ['name', 'appearance']) inputs.set(`[data-pair-person="${i}"][data-pair-key="${key}"]`, { value: settings.people[i][key] });
    const view = { settings, context: f.host, scope: couple.coupleScope(f.host), host: { hidden: false }, draftTimer: 0,
        root: { isConnected: true, querySelector: selector => inputs.get(selector) || null, querySelectorAll: () => [status] },
        records: [{ id: 'frozen-history', settings: plain(settings) }] };
    f.get('core/state').state.activeMode = couple.COUPLE_MODE;
    ui.namespace.activateForTest(view);
    return { ...f, helper: helper.namespace, ui: ui.namespace, couple, settings, library, calls, view, inputs, status };
}

test('explicit refresh reads the current card instead of stale automatic looks or the old avatar draft', async () => {
    const f = await setup();
    f.host.chatMetadata[f.get('core/castLooks').CAST_LOOKS_KEY] = { chatId: 'A', char: 'pink hair', user: 'red hair', manual: false };
    const before = plain(f.settings);
    const result = f.helper.readCoupleAppearance(f.settings, 0, f.host);
    assert.equal(result.source, 'local');
    assert.match(result.person.appearance, /black hair/); assert.match(result.person.appearance, /long hair/);
    assert.doesNotMatch(result.person.appearance, /pink hair|old short/);
    assert.equal(result.person.appearanceOverride, undefined);
    assert.deepEqual(plain(f.settings), before);
    assert.equal(f.calls.image + f.calls.text + f.calls.saved, 0);
});

test('current manually confirmed local looks take precedence over card extraction', async () => {
    const f = await setup();
    f.host.chatMetadata[f.get('core/castLooks').CAST_LOOKS_KEY] = { chatId: 'A', char: 'my preserved literal hair tag', user: 'white blindfold, silver hair', manual: true };
    assert.equal(f.helper.readCoupleAppearance(f.settings, 0, f.host).person.appearance, 'my preserved literal hair tag');
    assert.equal(f.helper.readCoupleAppearance(f.settings, 1, f.host).person.appearance, 'white blindfold, silver hair');
});

test('only the selected provider preset is preferred and custom names cannot receive another role fallback', async () => {
    const f = await setup();
    f.library.push({ name: 'Custom', tag: 'blonde hair, green eyes' });
    f.host.extensionSettings['st-chatu8'] = { characterPresets: { custom: { nameEN: 'Custom', characterTraits: 'purple hair', negative: 'orange hair' } } };
    const custom = plain(f.settings); custom.people[0].name = 'Custom';
    const bbi = f.helper.readCoupleAppearance(custom, 0, f.host);
    assert.equal(bbi.person.appearance, 'blonde hair, green eyes');
    assert.equal(bbi.person.presetAppearance, 'blonde hair, green eyes');
    f.host.extensionSettings[f.constants.EXTENSION_SETTINGS_KEY].imageGenerationProvider = 'chatu8-image';
    const chatu8 = f.helper.readCoupleAppearance(custom, 0, f.host);
    assert.equal(chatu8.person.appearance, 'purple hair'); assert.equal(chatu8.person.presetNegative, 'orange hair');
    f.host.extensionSettings['st-chatu8'] = {};
    assert.equal(f.helper.readCoupleAppearance(custom, 0, f.host), null);
    const wrongId = plain(f.settings); wrongId.people[0].id = 'custom-id';
    assert.equal(f.helper.readCoupleAppearance(wrongId, 0, f.host), null);
});

test('duplicate provider presets fall back locally and no source preserves existing appearance', async () => {
    const f = await setup();
    f.library.push({ name: 'Char', tag: 'blonde hair' }, { name: 'Char', tag: 'red hair' });
    const result = f.helper.readCoupleAppearance(f.settings, 0, f.host);
    assert.equal(result.source, 'local'); assert.match(result.person.appearance, /black hair/);
    f.library.length = 0; f.host.getCharacterCardFields = () => ({});
    const before = plain(f.settings);
    assert.equal(f.helper.readCoupleAppearance(f.settings, 0, f.host), null);
    await f.ui.refreshAppearance(f.view, 0);
    assert.deepEqual(plain(f.view.settings), before);
    assert.match(f.status.textContent, /原内容已保留/); assert.equal(f.calls.saved, 0);
});

test('accepted refresh updates only the selected side and leaves opposite presets, history and other settings exact', async () => {
    const f = await setup();
    f.library.push({ name: 'User', tag: 'new purple hair' });
    const before = plain(f.settings), history = plain(f.view.records);
    await f.ui.refreshAppearance(f.view, 0);
    assert.match(f.view.settings.people[0].appearance, /long hair/);
    assert.equal(f.view.settings.people[0].appearanceOverride, undefined);
    assert.deepEqual(plain(f.view.settings.people[1]), before.people[1]);
    assert.deepEqual(plain(f.view.records), history);
    assert.deepEqual({ ...plain(f.view.settings), people: [] }, { ...before, people: [] });
    const stored = await f.couple.readCouples(f.view.scope);
    assert.deepEqual(plain(stored.settings.people[1]), before.people[1]);
    assert.equal(f.calls.confirms, 0); assert.equal(f.calls.saved, 1); assert.equal(f.calls.image, 0); assert.equal(f.calls.text, 1);
});

// 1.0.53 deliberately replaces native confirm with cancellable, explicit
// button work. A suppressed host confirm must no longer turn clicks into no-ops.
test('native confirmation unavailable or false no longer blocks explicit refresh', async () => {
    for (const confirm of [undefined, () => false]) {
        const f = await setup(); f.sb.confirm = confirm;
        await f.ui.refreshAppearance(f.view, 0);
        assert.match(f.view.settings.people[0].appearance, /long hair/);
        assert.equal(f.calls.saved, 1); assert.equal(f.calls.text, 1); assert.equal(f.calls.confirms, 0);
        assert.match(f.status.textContent, /最新人设/);
    }
});

test('chat changes or selected-field edits during extraction cannot apply stale refresh results', async () => {
    for (const change of ['chat', 'edit', 'persona', 'source', 'provider']) {
        const f = await setup(), before = plain(f.settings);
        let complete;
        f.calls.response = () => new Promise(resolve => { complete = resolve; });
        const pending = f.ui.refreshAppearance(f.view, 0);
        assert.equal(typeof complete, 'function');
        if (change === 'chat') f.host.chatId = 'B';
        else if (change === 'edit') f.inputs.get('[data-pair-person="0"][data-pair-key="appearance"]').value = 'a new handwritten appearance';
        else if (change === 'persona') f.host.user_avatar = 'changed-persona.png';
        else if (change === 'source') f.host.getCharacterCardFields = () => ({ description: 'white hair' });
        else f.host.extensionSettings[f.constants.EXTENSION_SETTINGS_KEY].imageGenerationProvider = 'chatu8-image';
        complete({ appearance: 'late red hair' }); await pending;
        assert.deepEqual(plain(f.view.settings), before); assert.equal(f.calls.saved, 0);
    }
});

test('form contains two explicit refresh actions and conditional BaiBai advice, without changing prompt/history data', async () => {
    const f = await setup(), before = plain(f.settings);
    let html = f.ui.formHtml(f.view);
    assert.equal((html.match(/data-pair-action="refresh-appearance"/g) || []).length, 2);
    assert.match(html, /豆豆眼／Q版若不符/);
    assert.doesNotMatch(html, /画师串/);
    f.host.extensionSettings[f.constants.EXTENSION_SETTINGS_KEY].imageGenerationProvider = 'chatu8-image';
    html = f.ui.formHtml(f.view);
    assert.doesNotMatch(html, /豆豆眼／Q版若不符/);
    assert.deepEqual(plain(f.settings), before); assert.equal(f.calls.saved + f.calls.image + f.calls.text, 0);
});

test('current preset refresh takes a local fast path without text or image requests', async () => {
    const f = await setup();
    f.library.push({ name: 'Char', tag: 'red hair' });
    await f.ui.refreshAppearance(f.view, 0);
    assert.equal(f.view.settings.people[0].appearance, 'red hair');
    assert.equal(f.view.settings.people[0].presetAppearance, 'red hair');
    assert.equal(f.calls.saved, 1); assert.equal(f.calls.text + f.calls.image, 0);
});

test('both-person preset collisions are rejected even when refreshing only one side', async () => {
    const f = await setup();
    f.library.push({ name: 'Shared', tag: 'red hair' });
    const both = plain(f.settings);
    both.people[0].name = both.people[1].name = 'Shared';
    assert.equal(f.helper.readCoupleAppearance(both, 0, f.host), null);
    assert.equal(f.helper.readCoupleAppearance(both, 1, f.host), null);
});

test('empty or failed extraction preserves old field, override and history', async () => {
    for (const fail of [false, true]) {
        const f = await setup(), before = plain(f.settings), history = plain(f.view.records);
        f.calls.response = () => { if (fail) throw Error('mock transport failure'); return { appearance: '' }; };
        await f.ui.refreshAppearance(f.view, 0);
        assert.deepEqual(plain(f.view.settings), before); assert.deepEqual(plain(f.view.records), history);
        assert.equal(f.calls.saved, 0); assert.equal(f.calls.text, 1); assert.equal(f.calls.image, 0);
        assert.match(f.status.textContent, /原内容已保留/);
    }
});

test('fresh full user persona overrides saved manual summary and preserves output beyond 400 characters', async () => {
    const f = await setup();
    const description = '背景资料。'.repeat(1500) + '银色长发，白色眼罩，额前有齐刘海，左耳有银环。';
    f.host.getCharacterCardFields = () => ({ persona: description });
    f.host.chatMetadata[f.get('core/castLooks').CAST_LOOKS_KEY] = { chatId: 'A', user: 'old short black hair', manual: true };
    const output = 'silver hair, white blindfold, detailed visible feature, '.repeat(20);
    f.calls.response = () => ({ appearance: output });
    const prepared = f.helper.prepareCoupleAppearance(f.settings, 1, f.host);
    assert.equal(prepared.kind, 'persona'); assert.equal(prepared.sourceText, description);
    await f.ui.refreshAppearance(f.view, 1);
    assert.equal(f.view.settings.people[1].appearance, output.trim());
    assert.ok(f.view.settings.people[1].appearance.length > 400);
    assert.ok(f.calls.requests[0].prompt.includes(description));
    assert.ok(!f.calls.requests[0].prompt.includes('old short black hair'));
    assert.equal(f.calls.requests[0].options.contextEnvelope, '');
    assert.equal(f.calls.requests[0].options.temperatureCeiling, 0.2);
    assert.equal(f.calls.requests[0].options.enforceGeneratedPhrasePolicy, false);
    assert.equal(f.calls.text, 1); assert.equal(f.calls.image, 0);
});

test('latest char personality and user persona fallback are read without old automatic extraction limits', async () => {
    const f = await setup();
    f.host.getCharacterCardFields = () => ({ description: 'high ponytail', personality: 'He wears a white blindfold.' });
    f.host.powerUserSettings = { persona_description: 'blue eyes, waist-length silver hair' };
    assert.match(f.helper.prepareCoupleAppearance(f.settings, 0, f.host).sourceText, /white blindfold/);
    assert.equal(f.helper.prepareCoupleAppearance(f.settings, 1, f.host).sourceText, f.host.powerUserSettings.persona_description);
    const old = plain(f.settings); old.people[1].name = 'Someone else';
    assert.equal(f.helper.prepareCoupleAppearance(old, 1, f.host).kind, 'saved');
});

test('only absent persona falls back to saved looks and clearly reports the source', async () => {
    const f = await setup(); f.host.getCharacterCardFields = () => ({});
    f.host.chatMetadata[f.get('core/castLooks').CAST_LOOKS_KEY] = { chatId: 'A', user: 'saved silver hair', manual: true };
    await f.ui.refreshAppearance(f.view, 1);
    assert.equal(f.view.settings.people[1].appearance, 'saved silver hair');
    assert.equal(f.calls.text + f.calls.image, 0); assert.match(f.status.textContent, /沿用保存的外貌/);
});

test('format follows current selection in the one explicit extraction request', async () => {
    for (const format of ['nai45-tags', 'nai5-natural']) {
        const f = await setup(); f.host.extensionSettings[f.constants.EXTENSION_SETTINGS_KEY].cgPromptFormat = format;
        await f.ui.refreshAppearance(f.view, 0);
        assert.match(f.calls.requests[0].prompt, format === 'nai45-tags' ? /NAI 4\.5.*英文 tag/ : /NAI 5.*英文自然语言/);
        assert.equal(f.calls.text, 1); assert.equal(f.calls.image, 0);
    }
});

test('second click cancels the same side without submitting another request or overwriting the field', async () => {
    const f = await setup(), before = plain(f.settings);
    f.calls.response = (_prompt, options) => new Promise((_resolve, reject) => {
        options.signal.addEventListener('abort', () => reject(new DOMException('cancelled', 'AbortError')), { once: true });
    });
    const pending = f.ui.refreshAppearance(f.view, 0);
    await f.ui.refreshAppearance(f.view, 0); await pending;
    assert.deepEqual(plain(f.view.settings), before); assert.equal(f.calls.saved, 0);
    assert.equal(f.calls.text, 1); assert.match(f.status.textContent, /已取消/);
});

test('source signature tracks provider, format, persona and cast names without mutating drafts', async () => {
    const f = await setup(), before = plain(f.settings);
    const original = f.helper.prepareCoupleAppearance(f.settings, 0, f.host).signature;
    f.host.getCharacterCardFields = () => ({ description: 'different current hair' });
    assert.notEqual(f.helper.prepareCoupleAppearance(f.settings, 0, f.host).signature, original);
    const changed = plain(f.settings); changed.people[1].name = 'Char';
    assert.notEqual(f.helper.prepareCoupleAppearance(changed, 0, f.host).signature, original);
    assert.deepEqual(plain(f.settings), before); assert.equal(f.calls.text + f.calls.image + f.calls.saved, 0);
});

test('closing the view or switching persona aborts the in-flight request without a write', async () => {
    for (const change of ['close', 'persona']) {
        const f = await setup(), before = plain(f.settings);
        let requestSignal;
        f.calls.response = (_prompt, options) => new Promise((_resolve, reject) => {
            requestSignal = options.signal;
            options.signal.addEventListener('abort', () => reject(new DOMException('cancelled', 'AbortError')), { once: true });
        });
        const pending = f.ui.refreshAppearance(f.view, 0);
        if (change === 'close') f.view.host.hidden = true;
        else f.host.user_avatar = 'another.png';
        await pending;
        assert.equal(requestSignal.aborted, true); assert.equal(f.calls.saved, 0);
        assert.deepEqual(plain(f.view.settings), before); assert.equal(f.calls.text, 1);
    }
});

test('an opposite-side appearance edit survives the selected-side result', async () => {
    const f = await setup(); let complete;
    f.calls.response = () => new Promise(resolve => { complete = resolve; });
    const pending = f.ui.refreshAppearance(f.view, 0);
    f.view.settings.people[1] = { ...f.view.settings.people[1], appearance: 'new opposite handwritten look', appearanceOverride: true };
    f.inputs.get('[data-pair-person="1"][data-pair-key="appearance"]').value = 'new opposite handwritten look';
    complete({ appearance: 'white hair, amber eyes' }); await pending;
    assert.equal(f.view.settings.people[0].appearance, 'white hair, amber eyes');
    assert.equal(f.view.settings.people[1].appearance, 'new opposite handwritten look');
    assert.equal(f.view.settings.people[1].appearanceOverride, true); assert.equal(f.calls.saved, 1);
});

test('real request composition extracts without an archive, excludes creative supplement and keeps user tag policy', async () => {
    const f = await setup({ realRequest: true });
    delete f.host.chatMetadata[f.constants.MEMORY_KEY];
    f.host.getCharacterCardFields = () => ({ persona: 'silver hair, blue eyes <omitlook>private unwanted marker</omitlook>' });
    const userSettings = {
        ...f.constants.DEFAULT_SETTINGS, apiConnectionMode: 'profile', connectionProfileId: 'TEST', maxTokens: 120000,
        imageGenerationProvider: 'baibai-image', cgPromptFormat: 'nai5-natural',
        creativeSupplementEnabled: true, creativeSupplement: 'NARRATIVE_SUPPLEMENT_SENTINEL', excludedContextTags: ['omitlook'],
    };
    f.host.extensionSettings[f.constants.EXTENSION_SETTINGS_KEY] = userSettings;
    realClient(f, async () => ({ appearance: 'silver hair, blue eyes' }));
    f.get('core/settings').getPluginSettings = () => userSettings;
    const send = f.host.ConnectionManagerRequestService.sendRequest;
    let sent = '', requests = 0;
    f.host.ConnectionManagerRequestService.sendRequest = async (...args) => {
        requests++; sent = JSON.stringify(args[1]); return send(...args);
    };
    const prepared = f.helper.prepareCoupleAppearance(f.settings, 1, f.host);
    assert.equal(prepared.kind, 'persona');
    const result = await f.helper.refreshCoupleAppearance(prepared, { context: f.host, taskKey: 'test:appearance-real-client' });
    assert.equal(result.person.appearance, 'silver hair, blue eyes'); assert.equal(requests, 1);
    assert.match(sent, /silver hair, blue eyes/);
    assert.doesNotMatch(sent, /NARRATIVE_SUPPLEMENT_SENTINEL|private unwanted marker/);
    assert.equal(userSettings.creativeSupplementEnabled, true);
    assert.deepEqual(userSettings.excludedContextTags, ['omitlook']);
    assert.equal(f.host.chatMetadata[f.constants.MEMORY_KEY], undefined);
});
