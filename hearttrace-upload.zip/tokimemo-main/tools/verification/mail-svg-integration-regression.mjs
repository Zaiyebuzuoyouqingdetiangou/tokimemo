import { runIf } from './optional.mjs';
// 缺少条件时明确跳过并说明原因；满足时加载同名 .impl.mjs 里的原测试。
await runIf([
    {
        "module": "@xmldom/xmldom",
        "why": "信件 SVG 测试需要 DOM 解析器"
    },
    {
        "module": "@napi-rs/canvas",
        "why": "手书画布/图片合成测试需要在 Node 里渲染 canvas"
    }
],
    () => import('./mail-svg-integration-regression.impl.mjs'));
