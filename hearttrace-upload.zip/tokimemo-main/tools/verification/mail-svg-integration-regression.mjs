import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fixture, realClient } from './fixture.mjs';
const require = createRequire(import.meta.url);
const dom = require(process.env.LETTER_SVG_DOM_MODULE || '/workspace/scratch/8e568532ca62/test-deps/node_modules/@xmldom/xmldom');
const root = path.resolve(process.env.TEST_ROOT || '.');
const date = new Date('2026-10-07T08:00:00Z');
const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 200"><path d="M10 160 Q90 30 200 70 L290 180Z" fill="#db6677"/><circle cx="80" cy="50" r="20" fill="#304a67"/></svg>`;
const art = (slot='daily') => ({slot, version:3, characterName:'Char', summary:'台阶上低头编绳，微笑，练功服，侧面全身', svg});
const letter = (slot='daily') => ({slot,title:'今日近况',greeting:'你好',body:'我练完剑，坐在台阶上编红绳，忽然想到你。',closing:'Char'});
async function setup(){const f=await fixture();f.sb.DOMParser=dom.DOMParser;f.sb.XMLSerializer=dom.XMLSerializer;return f;}
const plan = f => f.get('modes/inbox').inboxPlan(f.bank,null,date);
const normalize = (f,raw) => f.get('modes/inbox').normalizeInboxLetters(f.json(raw),f.bank,plan(f),date);

test('one actual configured text request returns prose and SVG with user output budget intact',async()=>{
 const f=await setup();let requests=0,transport;
 realClient(f,()=>{requests++;return {letters:[letter()],letterIllustrations:[art()]};});
 const send=f.host.ConnectionManagerRequestService.sendRequest;
 f.host.ConnectionManagerRequestService.sendRequest=async(...args)=>{transport=args;return send(...args);};
 const inbox=f.get('modes/inbox');
 const result=await inbox.generateInbox(f.host,f.bank,f.get('core/context').captureTaskOrigin(f.host,f.bank.archiveRevision),'test-mail',null,{date});
 assert.equal(requests,1);assert.equal(result.letters.length,1);assert.equal(result.letters[0].body,letter().body);
 assert.equal(result.letters[0].illustration.version,3);
 assert.ok(JSON.stringify(transport).includes('120000'),'configured 120000 budget reaches provider');
 assert.ok(JSON.stringify(transport).includes('letterIllustrations'));
});

test('no scene token, appearance quote, metadata, pose enum or drawing-count gate',async()=>{
 const f=await setup();const input=letter();input.body='尚有牵挂，愿安。';
 const result=normalize(f,{letters:[input],letterIllustrations:[{slot:'daily',svg}]});
 assert.equal(result.letters[0].illustration.version,3);assert.equal(result.letters[0].body,input.body);
 const big=normalize(f,{letters:[input],letterIllustrations:[{slot:'daily',svg:svg.replace('</svg>','<circle cx="1" cy="1" r="1"/>'.repeat(1200)+'</svg>')}]});
 assert.equal(big.letters[0].illustration.version,3);
});

test('SVG format failures, missing SVG and absent DOM parser preserve the complete letter',async()=>{
 const f=await setup();
 for(const invalid of [null,{},art('unrelated'),{slot:'daily',svg:'not svg'}, {slot:'daily',version:3,svg:'<svg><script>alert(1)</script></svg>'}]){
  const saved=normalize(f,{letters:[letter()],letterIllustrations:[invalid]});
  assert.equal(saved.letters[0].body,letter().body);assert.equal(saved.letters[0].closing,'Char');
 }
 delete f.sb.DOMParser;
 assert.equal(normalize(f,{letters:[letter()],letterIllustrations:[art()]}).letters[0].body,letter().body);
});

test('pictures associate by slot regardless of order; current SVGs remain different',async()=>{
 const f=await setup();f.bank.memories=[{id:'M001',title:'初见',summary:'初次相识',anchors:['初见']}];
 const stage={...art('stage'),svg:svg.replace('M10 160 Q90 30 200 70 L290 180Z','M30 170 L150 20 L270 170Z')};
 const result=normalize(f,{letters:[letter('stage'),letter()],letterIllustrations:[art(),stage]});
 assert.equal(result.letters.length,2);assert.match(result.letters[0].illustration.svg,/M30 170/);assert.match(result.letters[1].illustration.svg,/M10 160/);
});

test('new SVG survives reopen, append, gallery and hand journal roundtrip; old v1/v2 still render',async()=>{
 const f=await setup(),inbox=f.get('modes/inbox'),api=f.get('core/letterIllustration');
 const saved=normalize(f,{letters:[letter()],letterIllustrations:[art()]});
 const reopened=inbox.normalizeInboxSession(f.json(saved));
 assert.equal(reopened.letters[0].illustration.svg,saved.letters[0].illustration.svg);
 assert.equal(f.get('core/mailGallery').savedMailDrawings(reopened).length,1);
 assert.match(f.get('ui/inboxView').inboxGalleryHtml(reopened),/data:image\/svg\+xml/);
 const before=JSON.stringify(reopened);const appended=inbox.mergeInboxLatest(reopened,inbox.emptyInbox(f.bank));
 assert.equal(JSON.stringify(reopened),before);assert.equal(appended.letters[0].illustration.svg,saved.letters[0].illustration.svg);
 const journal=f.get('core/handJournal'),entries=journal.extractJournalEntries('inbox',reopened);
 assert.ok(entries[0].blocks.some(b=>b.type==='letterIllustration'&&b.illustration.version===3));
 const page=journal.createJournalPage({title:'来信',entries});
 const restored=journal.importJournal(journal.exportJournal([page]));
 assert.equal(restored[0].entries[0].blocks.find(b=>b.type==='letterIllustration').illustration.svg,saved.letters[0].illustration.svg);
 assert.match(api.renderLetterIllustrationSvg(saved.letters[0].illustration),/^<svg/);
 for(const old of [{version:1,subject:'person',action:'read',palette:'rose',accessories:[]},{version:2,characterName:'Char',focus:'person',visualFacts:[{kind:'hairColor',value:'black',evidence:'黑发'}],scene:{kind:'read',evidence:'读书'}}]){
  const value=f.json(old);assert.match(api.renderLetterIllustration(value),new RegExp('data-rmt-letter-illustration-version="'+old.version+'"'));assert.match(api.renderLetterIllustrationSvg(value),/^<svg/);
 }
});

test('recent drawings are included as creative references without SVG payload or evidence gates',async()=>{
 const f=await setup(),inbox=f.get('modes/inbox');
 const previous=normalize(f,{letters:[letter()],letterIllustrations:[art()]});
 const digest=inbox.recentLetterDigest(previous);assert.match(digest[0].illustration,/台阶.*编绳/);
 const prompt=inbox.inboxPrompt(f.bank,plan(f),previous);
 assert.match(prompt,/先完整输出全部 letters 正文/);assert.match(prompt,/同一回复末尾输出 letterIllustrations/);assert.match(prompt,/相似不妨碍本次输出/);
 assert.ok(!prompt.includes(svg));assert.doesNotMatch(prompt,/scene\.evidence|只能使用 v2|关键词之一|最多\d+|至少给一项/);
});

test('truncated SVG after all prose keeps both letters and completed art in readable recovery',async()=>{
 const f=await setup();f.bank.memories=[{id:'M001',title:'初见',summary:'初次相识',anchors:['初见']}];
 const prefix=JSON.stringify({letters:[letter('stage'),letter()],letterIllustrations:[art('stage')]}).slice(0,-2)+',{"slot":"daily","version":3,"svg":"<svg';
 const parser=f.get('generation/jsonParser');
 const parsed=parser.parseInboxRecoveryObject(prefix);
 const recovered=f.get('modes/inbox').projectInboxProgress({segments:[parsed],memoryBank:f.bank,context:f.host,previousSession:null,operation:{inboxDate:date.toISOString(),inboxPlanVersion:2},createdAt:date.getTime()});
 assert.equal(recovered.letters.length,2);assert.equal(recovered.letters[0].illustration.version,3);assert.equal(recovered.letters[1].body,letter().body);
});

test('recovery merge retains complete art atomically by slot',async()=>{
 const f=await setup(),input={memoryBank:f.bank,previousSession:null,operation:{inboxDate:date.toISOString(),inboxPlanVersion:2},createdAt:date.getTime()};
 const schema=f.get('generation/recoveryAdapters').recoveryProgressSchema('inbox',input);
 const result=f.get('generation/recoveryMerge').mergeRecoveryPartials([JSON.stringify({letters:[letter()],letterIllustrations:[art()]}),JSON.stringify({letters:[letter()]})],schema);
 assert.ok(JSON.stringify(result).includes('M10 160'));
});

test('hand journal export uses SVG source while gallery styles support isolated images',()=>{
 assert.match(fs.readFileSync(path.join(root,'src/ui/handJournalView.js'),'utf8'),/renderIllustration:\(value,key\)=>letterArt\.renderLetterIllustrationSvg/);
 assert.match(fs.readFileSync(path.join(root,'src/ui/inboxStyles.js'),'utf8'),/\.rmt-mail-drawing-art img\.rmt-letter-illustration/);
});

test('native rasterization paints generated SVG in the full hand-journal image export',async()=>{
 const f=await setup();
 const native=require(require.resolve('@napi-rs/canvas',{paths:[process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES||process.cwd()]}));
 const made=normalize(f,{letters:[letter()],letterIllustrations:[art()]});
 const journal=f.get('core/handJournal');
 const page=journal.createJournalPage({title:'来信画册',entries:journal.extractJournalEntries('inbox',made)});
 const urls=[];
 f.sb.Blob=class{constructor(parts){this.parts=parts;}};
 f.sb.URL=class extends URL{static createObjectURL(blob){const buffer=Buffer.from(blob.parts.join(''));urls.push(buffer);return buffer;}static revokeObjectURL(){}};
 f.sb.Image=native.Image;
 f.sb.document.createElement=tag=>{assert.equal(tag,'canvas');const canvas=native.createCanvas(1,1);canvas.toBlob=(callback,type)=>callback(new Blob([canvas.toBuffer(type)],{type}));return canvas;};
 const render=f.get('core/letterIllustration').renderLetterIllustrationSvg;
 const result=await f.get('ui/journalImage').renderJournalPageImage(page,0,{renderIllustration:render});
 assert.equal(result.missing,0);assert.equal(result.width,1080);assert.ok(result.height>500);
 assert.match(urls[0].toString(),/^<svg/);
 const png=Buffer.from(await result.blob.arrayBuffer());assert.ok(png.length>1000);
 const image=await native.loadImage(png);const canvas=native.createCanvas(image.width,image.height),ctx=canvas.getContext('2d');ctx.drawImage(image,0,0);
 const pixels=ctx.getImageData(0,0,canvas.width,canvas.height).data;let colored=0;
 for(let i=0;i<pixels.length;i+=4)if(pixels[i]===219&&pixels[i+1]===102&&pixels[i+2]===119&&pixels[i+3]===255)colored++;
 assert.ok(colored>500,'actual SVG shape pixels survive journal export');
});

test('recovery never attaches a changed-response drawing to retained earlier prose',async()=>{
 const f=await setup(),parser=f.get('generation/jsonParser');
 const input={memoryBank:f.bank,previousSession:null,operation:{inboxDate:date.toISOString(),inboxPlanVersion:2},createdAt:date.getTime()};
 const schema=f.get('generation/recoveryAdapters').recoveryProgressSchema('inbox',input);
 const initial=JSON.stringify({letters:[letter()],letterIllustrations:[]}).slice(0,-2)+'{"slot":"daily","svg":"unfinished';
 const changed={...letter(),body:'我蹲在田埂，拨开稻叶看一只蜻蜓。'};
 const next=JSON.stringify({letters:[changed],letterIllustrations:[{...art(),summary:'田埂上看蜻蜓'}]});
 const merged=f.get('generation/recoveryMerge').mergeRecoveryPartials([initial,next],schema,{parsePartial:parser.parseInboxRecoveryObject});
 const recovered=f.get('modes/inbox').projectInboxProgress({...input,context:f.host,segments:[merged]});
 assert.equal(recovered.letters[0].body,letter().body);
 assert.notEqual(recovered.letters[0].illustration?.summary,'田埂上看蜻蜓');
 const same=JSON.stringify({letters:[letter()],letterIllustrations:[art()]});
 const mergedSame=f.get('generation/recoveryMerge').mergeRecoveryPartials([initial,same],schema,{parsePartial:parser.parseInboxRecoveryObject});
 const recoveredSame=f.get('modes/inbox').projectInboxProgress({...input,context:f.host,segments:[mergedSame]});
 assert.equal(recoveredSame.letters[0].illustration.version,3);
});
