import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { fixture } from './fixture.mjs';

async function setup(provider = 'baibai-image', supportsCharacters = true, backend = 'nai') {
    const f = await fixture(), requests = [], source = new EventEmitter();
    f.host.chatMetadata = {};
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS, imageGenerationProvider: provider, imageGenerationFallback: false });
    f.sb.STBaiBaiImage = { apiVersion: 1, capabilities: { generate: true, saveToGallery: true },
        getBackendStatus: () => ({ configured: true, backend, supportsCharacters }),
        generate: async request => { requests.push(request); return { path: '/user/images/identity.png' }; } };
    f.host.eventSource = source; f.host.extensionSettings['st-chatu8'] = { scriptEnabled: true, mode: 'comfyui' };
    source.on('generate-image-request', request => { requests.push(request); source.emit('generate-image-response', { id: request.id, success: true, imageData: '/user/images/identity.png' }); });
    f.get('generation/client').requestJson = async () => { throw Error('No extra text request is allowed'); };
    return { ...f, requests, core: f.get('extras/coupleAvatar'), styles: f.get('extras/coupleAvatarStyles') };
}
const people = [
    { id: 'char', name: '青禾', appearance: '1boy, black hair, high ponytail, golden eyes, pale skin, red bracelet' },
    { id: 'user', name: '阿月', appearance: '1girl, long silver hair, pink eyes, white ribbon' },
];

test('every style has construction guidance and all 48 interactions have independent left/right actions', async () => {
    const f = await setup();
    assert.equal(f.styles.COUPLE_STYLES.length, 72);
    const constructions = f.styles.COUPLE_STYLES.map(style => f.styles.coupleStyleConstruction(style));
    assert.equal(new Set(constructions).size, 72);
    for (const preset of f.styles.INTERACTION_PRESETS) {
        assert.equal(preset.roles.length, 2, preset.label);
        assert.ok(preset.roles[0] && preset.roles[1]); assert.notEqual(preset.roles[0], preset.roles[1]);
        const parts = f.core.couplePromptParts({ people, interaction: preset.label });
        assert.ok(parts.characters[0].tag.includes(preset.roles[0])); assert.ok(parts.characters[1].tag.includes(preset.roles[1]));
    }
    assert.equal(f.requests.length, 0);
});

test('BaiBai NAI gets two independent identity channels, not two appearances in the global scene', async () => {
    const f = await setup();
    const saved = await f.core.generateCouple({ people, styleId: 'art-watercolor', interaction: '递出一朵花' }, { context: f.host });
    const sent = f.requests[0];
    assert.equal(sent.characters?.length, 2, 'both actual subjects use the documented character channels');
    assert.match(sent.characters[0].nl, /On the left/); assert.match(sent.characters[1].nl, /On the right/);
    assert.match(sent.characters[0].tag, /golden eyes/); assert.doesNotMatch(sent.characters[0].tag, /pink eyes|silver hair/);
    assert.match(sent.characters[1].tag, /pink eyes/); assert.doesNotMatch(sent.characters[1].tag, /golden eyes|red bracelet/);
    assert.doesNotMatch(sent.prompt, /golden eyes|pink eyes|high ponytail/);
    assert.match(sent.prompt, /watercolor/); assert.match(sent.nl, /offers a flower/);
    assert.match(sent.characters[0].nl, /offer a flower toward the right/);
    assert.match(sent.characters[1].nl, /receive the flower/); assert.equal(f.requests.length, 1);
    assert.deepEqual(JSON.parse(JSON.stringify(saved.record.settings.people)), people);
});

test('animal conversion does not turn pale human skin into a competing pale coat or keep a human ponytail', async () => {
    const f = await setup();
    const input = { people, styleId: 'chibi-animal' }, before = JSON.stringify(input);
    const sent = f.core.couplePrompt(input);
    assert.match(sent, /black fur/);
    assert.doesNotMatch(sent, /pale coat|pale skin|high ponytail|\b1boy\b|\b1girl\b/);
    assert.match(sent, /golden eyes/); assert.match(sent, /pink eyes/); assert.match(sent, /red bracelet/);
    assert.match(sent, /animal anatomy/);
    assert.equal(JSON.stringify(input), before);
    const chinese = f.core.couplePrompt({ styleId: 'animal-cat', people: [{ name: '甲', appearance: '黑发，高马尾，金色眼睛，白皙皮肤，红绳手链' }] });
    assert.doesNotMatch(chinese, /白皙毛色|高马尾|白皙皮肤/);
    assert.match(chinese, /金色眼睛|红绳手链/);
});

const treatments = [
    ['chibi-dumpling', /head occupies about half/], ['chibi-three-head', /one third/],
    ['art-watercolor', /pigment blooms|wet-on-wet/], ['art-sketch', /crosshatching/],
    ['anime-webtoon', /one or two shadow shapes/], ['anime-shojo', /screentone.*faces/],
    ['graphic-pixel', /pixel grid.*faces/], ['craft-plush', /seams.*face/],
    ['art-oil', /brushstrokes.*face/], ['craft-clay', /sculpted.*face/],
];
for (const [styleId, pattern] of treatments) test(`${styleId}: visible style construction reaches the real provider`, async () => {
    const f = await setup();
    await f.core.generateCouple({ styleId, people }, { context: f.host });
    const sent = f.requests[0];
    assert.match(sent.nl, pattern);
    const selected = f.styles.COUPLE_STYLES.find(style => style.id === styleId);
    assert.ok(sent.characters.every(row => row.tag.includes(selected.prompt)), 'both character tags retain the actual selected medium');
    assert.match(sent.nl, /Render both subjects entirely in the selected medium/);
    assert.equal(f.requests.length, 1);
});

for (const [provider, support, backend] of [['baibai-image', false, 'nai'], ['baibai-image', true, 'comfyui'], ['chatu8-image', false, 'comfyui']]) {
    test(`${provider}/${backend}/${support}: flat backend keeps both identities and explicit style without new conditions`, async () => {
        const f = await setup(provider, support, backend);
        await f.core.generateCouple({ styleId: 'art-sketch', people }, { context: f.host });
        assert.equal(f.requests.length, 1); const sent = f.requests[0];
        for (const fragment of ['LEFT HALF', 'RIGHT HALF', people[0].appearance, people[1].appearance, 'crosshatching']) assert.ok(sent.prompt.includes(fragment), fragment);
        assert.equal(sent.characters, undefined);
    });
}

test('same-name subjects retain two separate positions, custom text, shared traits and blank optional appearances', async () => {
    const f = await setup();
    await f.core.generateCouple({ styleId: 'custom', customStyle: '用户自写的画法', interaction: '自定义互动', interactionDetail: '左边藏花，右边偷笑',
        people: [{ name: '同名', appearance: 'black hair, red scarf' }, { name: '同名', appearance: 'black hair, white scarf' }] }, { context: f.host });
    let sent = f.requests[0]; assert.equal(sent.characters?.length, 2);
    assert.notEqual(sent.characters[0].name, sent.characters[1].name);
    assert.ok(sent.characters.every(row => row.tag.includes('black hair')));
    assert.match(sent.prompt, /用户自写的画法/); assert.match(sent.nl, /左边藏花，右边偷笑/);
    await f.core.generateCouple({ people: [{ name: '', appearance: '' }, { name: '', appearance: '' }] }, { context: f.host });
    assert.equal(f.requests.length, 2); assert.equal((await f.core.readCouples(f.core.coupleScope(f.host))).records.length, 2);
});

test('long separate and flat appearances are not truncated and invalid optional channel data falls back to the flat prompt', async () => {
    const f = await setup(), long = '深色卷发。'.repeat(1100) + 'LEFT_END_MARKER';
    await f.core.generateCouple({ people: [{ name: '左', appearance: long }, { name: '右', appearance: 'RIGHT_END_MARKER' }] }, { context: f.host });
    assert.ok(f.requests[0].characters?.[0].tag.includes(long));
    assert.ok(f.requests[0].characters?.[1].tag.includes('RIGHT_END_MARKER'));
    await f.get('generation/cgImageCore').invokeImageGeneration('unchanged flat fallback', f.host, { singlePrompt: true, preservePrompt: true, avatarPromptParts: { scene: '', characters: [] } });
    assert.equal(f.requests[1].prompt, 'unchanged flat fallback'); assert.equal(f.requests[1].characters, undefined);
    assert.equal(f.requests.length, 2);
});
