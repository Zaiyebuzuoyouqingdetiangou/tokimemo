"""r84.215: compare every pre-existing regression against the delivered r84.214.

Exactly one historical failure may become passing; all remaining failures keep
their original assertions and payloads. New scoped regression suites must pass.
"""
from pathlib import Path
import concurrent.futures
import hashlib
import json
import os
import re
import subprocess
import sys
import time

root = Path(sys.argv[1]).resolve()
dest = Path(sys.argv[2]).resolve()
base = Path(os.environ['BASELINE_ROOT']).resolve()
v = Path(__file__).resolve().parent
dest.mkdir(parents=True, exist_ok=True)
commands = []
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
fixed = 'absent/silent local storage and rejected metadata never claim durable success'
new_suites = {'theme-song-writing-regression.mjs', 'mv-save-confirmation-regression.mjs'}
allowed_source = ['src/extras/mv.js', 'src/modes/themeSong.js']
build = '0.99.99-r84.215-song-writing-save'

def run(name, argv, env=None, required=True):
    start = time.monotonic()
    p = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                       env={**os.environ, **(env or {})}, timeout=45)
    (dest/(name+'.log')).write_bytes(p.stdout)
    commands.append({'name': name, 'argv': argv, 'exit_code': p.returncode,
                     'seconds': round(time.monotonic()-start, 3)})
    (dest/'commands.json').write_text(json.dumps(commands, indent=2))
    if required and p.returncode:
        raise AssertionError((name, p.returncode, p.stdout[-3000:].decode(errors='replace')))
    return p.returncode, p.stdout.decode(errors='replace')

run('build-1', ['python3', str(v/'build.py'), str(root)])
first = sha(root/'dist/heartbeatMemories.bundle.js')
run('build-2', ['python3', str(v/'build.py'), str(root)])
assert first == sha(root/'dist/heartbeatMemories.bundle.js')

files = sorted([*root.rglob('*.js'), *root.rglob('*.mjs')])
def syntax(p):
    r = subprocess.run(['node', '--check', str(p)], capture_output=True, timeout=15)
    return {'file': str(p.relative_to(root)), 'exit_code': r.returncode, 'stderr': r.stderr.decode()}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    checks = list(pool.map(syntax, files))
(dest/'syntax.json').write_text(json.dumps(checks, indent=2))
assert all(c['exit_code'] == 0 for c in checks)

imports = []
for p in (root/'src').rglob('*.js'):
    for rel in re.findall(r'^import\s+.*?from\s+[\'"]([^\'"]+)', p.read_text(), re.M):
        assert (p.parent/rel).resolve().is_file(), (p, rel)
        imports.append([str(p.relative_to(root)), rel])
(dest/'imports.json').write_text(json.dumps(imports, indent=2))
run('source-entry', ['node', '-e', "import(process.argv[1]).then(m=>console.log(Object.keys(m).length))", (root/'src/heartbeatMemories.js').as_uri()])
run('runtime-bindings', ['node', '--experimental-vm-modules', str(v/'runtime-bindings.mjs'), str(root)])

env = {'TEST_ROOT': str(root), 'BASELINE_ROOT': str(base)}
old_tests = sorted(str(p) for p in v.glob('*regression.mjs') if p.name not in new_suites)
argv = ['node', '--experimental-vm-modules', '--test', '--test-reporter=tap', *old_tests]
old_code, old_out = run('baseline-full', argv, {**env, 'TEST_ROOT': str(base)}, required=False)
new_code, new_out = run('candidate-full', argv, env, required=False)
def outcomes(output):
    return re.findall(r'^(not ok|ok) \d+ - (.+)$', output, re.M)
assert ('not ok', fixed) in outcomes(old_out)
expected = [('ok' if name == fixed else status, name) for status, name in outcomes(old_out)]
assert expected == outcomes(new_out), 'Unexpected change to a historical outcome'
assert not re.search(r'^# (?:cancelled|skipped|todo) [1-9]', new_out, re.M)
def failure_payloads(output):
    # Normalize only generated clock-dependent IDs, as in the r84.214 comparator.
    output = re.sub(r'\bF(\d+)_[a-z0-9]+\b', r'F\1_<generated-clock>', output)
    return [(name, re.search(r'  error: ([\s\S]+?)  stack:', body).group(1)
             if re.search(r'  error: ([\s\S]+?)  stack:', body) else body)
            for name, body in re.findall(r'^not ok \d+ - (.+)\n([\s\S]+?)^  \.\.\.$', output, re.M)
            if name != fixed]
assert failure_payloads(old_out) == failure_payloads(new_out), 'Historical failure details changed'

_, focused = run('song-save', ['node', '--experimental-vm-modules', '--test', '--test-reporter=tap',
                             *[str(v/name) for name in sorted(new_suites)]], env)
run('previous-source', ['node', '--test', '--test-reporter=tap', str(v/'previous-regression.mjs')], env)
run('previous-bundle', ['node', '--test', '--test-reporter=tap', str(v/'previous-regression.mjs')], {**env, 'TEST_BUNDLE': '1'})
run('prompt-hashes', ['node', '--experimental-vm-modules', str(v/'prompt-hashes.mjs'), str(base), str(root), str(dest/'prompt-hashes.json')],
    {'ALLOWED_PROMPT_CHANGES': '__m_modes_themeSong_js.themeSongPrompt'})

baseline_hashes = {str(p.relative_to(base)): sha(p) for p in base.rglob('*') if p.is_file()}
hashes = {str(p.relative_to(root)): sha(p) for p in root.rglob('*') if p.is_file()}
changes = [{'file': k, 'before': baseline_hashes.get(k), 'after': hashes.get(k)}
           for k in sorted(set(baseline_hashes)|set(hashes)) if baseline_hashes.get(k) != hashes.get(k)]
assert [c['file'] for c in changes if c['file'].startswith('src/')] == allowed_source
assert all(hashes.get(k) is not None for k in baseline_hashes), 'Baseline file removed'
assert (root/'index.js').read_text().replace(build, '0.99.99-r84.214-mv-sync-dark') == (base/'index.js').read_text()
old_manifest = json.loads((base/'manifest.json').read_text())
manifest = json.loads((root/'manifest.json').read_text())
assert {k:v for k,v in manifest.items() if k not in {'js','description'}} == {k:v for k,v in old_manifest.items() if k not in {'js','description'}}
assert manifest['js'] == 'index.js?heartbeat='+build
# All pre-existing test source files are immutable, including failing ones.
for p in (base/'tools/verification').glob('*regression.mjs'):
    assert sha(p) == sha(root/'tools/verification'/p.name), p.name
# The creative prompt is the only changed code in the song module.
def without_song_prompt(p):
    text = p.read_text(); start = text.index('export function themeSongPrompt(')
    end = text.index('// 新歌附带 BPM', start)
    return text[:start] + '<themeSongPrompt>' + text[end:]
assert without_song_prompt(base/'src/modes/themeSong.js') == without_song_prompt(root/'src/modes/themeSong.js')
(dest/'baseline-file-hashes.json').write_text(json.dumps(baseline_hashes, indent=2))
(dest/'file-hashes.json').write_text(json.dumps(hashes, indent=2))
(dest/'scope-diff.json').write_text(json.dumps(changes, ensure_ascii=False, indent=2))
code, patch = run('full-diff', ['git', 'diff', '--no-index', '--binary', str(base), str(root)], required=False)
assert code == 1
(dest/'full-change.patch').write_text(patch)
run('package', ['python3', str(v/'package.py'), str(root), str(dest/'checked-package.zip')])
prompts = json.loads((dest/'prompt-hashes.json').read_text())
assert [p['function'] for p in prompts if not p['unchanged']] == ['themeSongPrompt']
stats = lambda out: {kind: int(re.search(r'^# '+kind+r' (\d+)$', out, re.M).group(1)) for kind in ['tests', 'pass', 'fail']}
summary = {'new_regressions': 0, 'all_historical_tests_pass': new_code == 0,
           'baseline_historical': stats(old_out), 'candidate_historical': stats(new_out),
           'fixed_historical_test': fixed,
           'historical_failures_same_as_baseline': [n for status,n in outcomes(new_out) if status == 'not ok'],
           'focused': stats(focused), 'syntax_files': len(checks), 'resolved_imports': len(imports),
           'deterministic_build': True, 'bundle_sha256': first,
           'prompt_functions_unchanged': sum(p['unchanged'] for p in prompts), 'prompt_functions_changed': 1,
           'production_source_files_changed': allowed_source,
           'unchanged_baseline_files': sum(hashes.get(k) == value for k,value in baseline_hashes.items()),
           'not_executed': ['real iPhone/TT', 'real paid text/image/audio providers', 'browser CSS rendering', 'independent reviewer']}
(dest/'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2))
print(json.dumps({k:v for k,v in summary.items() if k != 'historical_failures_same_as_baseline'}, ensure_ascii=False))
