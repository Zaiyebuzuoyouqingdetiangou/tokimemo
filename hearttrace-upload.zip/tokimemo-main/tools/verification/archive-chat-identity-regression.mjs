import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { webcrypto } from 'node:crypto';

const root = path.resolve(process.env.TEST_ROOT || '.');
const plain = value => value == null ? value : JSON.parse(JSON.stringify(value));
const token = id => '__m_' + id.replace(/[^a-zA-Z0-9_]/g, '_');
// Rebuild the same registry in memory from *current source*, not an old dist bundle.
// This project deliberately uses a frozen registry order for cyclic dependencies.
function sourceRegistry() {
    const sources = new Map();
    const imports = /^import\s+(\*\s+as\s+\w+|\{[^}]+\})\s+from\s+['"]([^'"]+)['"];\s*$/gm;
    function visit(id) {
        if (sources.has(id)) return;
        const code = fs.readFileSync(path.join(root, 'src', id), 'utf8'); sources.set(id, code);
        for (const match of code.matchAll(imports)) visit(path.posix.normalize(path.posix.join(path.posix.dirname(id), match[2])));
    }
    visit('heartbeatMemories.js');
    const frozen = JSON.parse(fs.readFileSync(path.join(root, 'tools/verification/runtime-order.json'), 'utf8'));
    const order = [...[...sources.keys()].filter(id => !frozen.includes(id)).sort(), ...frozen.filter(id => sources.has(id))];
    const blocks = [...sources.keys()].map(id => `const ${token(id)}=Object.create(null);`);
    for (const id of order) {
        const source = sources.get(id);
        const exports = [...source.matchAll(/^export (?:(?:async )?function|const)\s+([\w$]+)/gm)].map(m => m[1]);
        const code = source.replace(imports, (_, spec, rel) => {
            const dep = token(path.posix.normalize(path.posix.join(path.posix.dirname(id), rel)));
            if (spec.startsWith('*')) return `const ${spec.split(/\s+/).at(-1)}=${dep};`;
            return spec.slice(1, -1).split(',').filter(v => v.trim()).map(v => {
                const [name, alias] = v.trim().split(/\s+as\s+/); return `const ${alias || name}=${dep}.${name};`;
            }).join('\n');
        }).replace(/^export (?=(?:async )?function\s|const\s)/gm, '');
        assert.doesNotMatch(code, /^(?:export|import)\s/m, `supported registry syntax: ${id}`);
        // Expose the real IDB transaction implementation only in this test runtime.
        const boundary = id === 'archive/backupStore.js' ? `${token(id)}.__idbPutRecord=idbPutRecord;` : '';
        blocks.push(`{\n${code}\n${exports.map(name => `${token(id)}.${name}=${name};`).join('\n')}\n${boundary}\n}`);
    }
    blocks.push(`export {${[...sources.keys()].map(token).join(',')}};`);
    return blocks.join('\n');
}
const registry = sourceRegistry();

// IndexedDB boundary substitute, including asynchronous requests, atomic commit,
// and abort. The production idbPutRecord performs identity/revision/cache CAS.
function transaction(records) {
    let aborted = false, pending = 0, completion = null;
    const staged = new Map(records);
    const tx = { error: null, abort() { if (aborted) return; aborted = true; clearImmediate(completion); queueMicrotask(() => tx.onabort?.()); } };
    const schedule = () => { clearImmediate(completion); completion = setImmediate(() => {
        if (aborted || pending) return;
        records.clear(); for (const [key, value] of staged) records.set(key, plain(value));
        tx.oncomplete?.();
    }); };
    const request = action => {
        pending++;
        const req = {};
        queueMicrotask(() => {
            if (aborted) return;
            try { req.result = plain(action()); req.onsuccess?.(); }
            catch (error) { req.error = error; req.onerror?.(); tx.error = error; tx.abort(); }
            finally { pending--; schedule(); }
        });
        return req;
    };
    tx.objectStore = () => ({
        get: key => request(() => staged.get(key)),
        put: value => request(() => { staged.set(value.entryId, plain(value)); return value.entryId; }),
        delete: key => request(() => staged.delete(key)),
        index: field => ({ getAll: value => request(() => [...staged.values()].filter(row => row[field] === value)) }),
    });
    return tx;
}

async function setup({ compressed = false, claimed = false } = {}) {
    let live;
    const records = new Map(), controls = { writes: [], read: null, put: null, saves: 0 };
    const sb = { console, TextEncoder, TextDecoder, URL, URLSearchParams, AbortController, DOMException, structuredClone,
        queueMicrotask, setTimeout, clearTimeout, setInterval, clearInterval, crypto: webcrypto, Response, Headers,
        Blob, CompressionStream, DecompressionStream, atob, btoa, document: { getElementById: () => null, querySelector: () => null },
        SillyTavern: { getContext: () => live }, localStorage: { getItem: () => null, setItem() {} } };
    const module = new vm.SourceTextModule(registry, { context: vm.createContext(sb) }); await module.link(() => {}); await module.evaluate();
    const get = id => module.namespace[token(id + '.js')];
    const constants = get('core/constants'), cache = get('core/cache'), repository = get('archive/repository');
    const bank = { version: constants.ARCHIVE_SCHEMA_VERSION, archiveRevision: 'r1', chatId: claimed ? 'new' : 'old',
        characterName: 'Char', userName: 'User', archiveName: 'existing story', memories: [{ id: 'M001', title: 'snow', summary: 'walking together', anchors: ['snow'] }] };
    if (claimed) bank.claimedFromChatId = 'old';
    const album = { kind: constants.MODE.ALBUM, chatId: 'old', archiveRevision: 'r1', title: 'our album',
        cards: [{ id: 'p1', memoryId: 'M001', imageUrl: '/user/images/kept.png', favorite: true, crop: { x: 12, y: 13, scale: 1.7 } }] };
    const draft = { identity: { chatId: 'old', archiveRevision: 'r1', characterId: '0' }, draftId: 'old-task', kind: constants.MODE.ALBUM, createdAt: 10 };
    const original = { chatId: 'old', archiveRevision: 'r1', updatedAt: 10, commitToken: 10000, [constants.MODE.ALBUM]: album,
        [cache.GENERATION_DRAFTS_CACHE_KEY]: { version: 1, records: { 'old-task': { journal: draft } } },
        [get('generation/recovery').GENERATION_RECOVERY_CACHE_KEY]: { [constants.MODE.ALBUM]: draft },
        [constants.PHONE_DRAFT_CACHE_KEY]: { kind: 'phone-draft', chatId: 'old', archiveRevision: 'r1' } };
    live = { characterId: 0, characters: [{ name: 'Char', avatar: 'char.png', data: { description: 'same character' } }],
        name1: 'User', name2: 'Char', chat: [], chatId: 'new', getCurrentChatId() { return this.chatId; }, extensionSettings: {},
        chatMetadata: { [constants.MEMORY_KEY]: bank, [constants.CACHE_KEY]: compressed ? cache.compressedCacheManifest(original, await cache.gzipJson(original)) : plain(original) },
        saveMetadataDebounced() { controls.saves++; }, saveSettingsDebounced() {} };
    const host = live, store = get('archive/backupStore');
    store.setArchiveBackupBackendForTests({
        async read(entry) { if (controls.read) await controls.read(entry); return plain(records.get(entry.entryId)); },
        async put(record, expected, options) {
            if (controls.put) await controls.put(record, expected, options);
            const result = await store.__idbPutRecord(transaction(records), record, expected, options);
            controls.writes.push({ record: plain(record), expected: plain(expected), options: { ...options } }); return result;
        }, delete: async () => { throw Error('migration must never delete archives'); },
    });
    return { get, sb, constants, cache, repository, store, host, bank, original, album, draft, records, controls,
        switchTo: value => { live = value; }, load: () => cache.loadSession(constants.MODE.ALBUM, { context: host }),
        raw: async value => cache.isCompressedCacheRecord(value) ? cache.gunzipJson(value.data) : plain(value) };
}

function assertArtwork(actual, expected) {
    assert.ok(actual, 'loadSession must return the album, not merely migrated fields');
    assert.deepEqual(plain(actual.cards), plain(expected.cards), 'image URL, favorite and crop remain exact');
}

for (const compressed of [false, true]) test(`explicit claim makes ${compressed ? 'gzip' : 'raw'} album readable without losing artwork`, async () => {
    const f = await setup({ compressed });
    assert.equal(f.load(), null);
    const sourceMemory = plain(f.bank), sourceCache = plain(f.host.chatMetadata[f.constants.CACHE_KEY]);
    const result = await f.repository.claimMismatchedArchive(f.host);
    assert.ok(result); assert.equal(f.host.chatMetadata[f.constants.MEMORY_KEY].chatId, 'new');
    await f.cache.ensureCacheHydrated(f.host);
    assertArtwork(f.load(), f.album);
    const newCache = await f.raw(f.host.chatMetadata[f.constants.CACHE_KEY]);
    assert.equal(newCache.chatId, 'new'); assert.equal(newCache[f.constants.MODE.ALBUM].chatId, 'new');
    assert.equal(newCache[f.cache.GENERATION_DRAFTS_CACHE_KEY], undefined, 'old task must not become active in new chat');
    assert.equal(newCache[f.get('generation/recovery').GENERATION_RECOVERY_CACHE_KEY], undefined);
    const durable = [...f.records.values()].find(row => row.memory?.chatId === 'new');
    assert.ok(durable, 'new archive must be durable');
    const durableCache = await f.raw(durable.cache);
    const snapshotKey = f.get('archive/chatIdentityMigration').CHAT_IDENTITY_SNAPSHOTS_KEY;
    const old = durableCache[snapshotKey]?.find(row => row.memory?.chatId === 'old');
    assert.ok(old, 'old snapshot must survive in acknowledged durable cache');
    assert.deepEqual(plain(old.memory), sourceMemory);
    const oldCache = await f.raw(old.cache);
    assert.deepEqual(plain(oldCache), plain(await f.raw(sourceCache)));
    assert.equal(oldCache[f.cache.GENERATION_DRAFTS_CACHE_KEY].records['old-task'].journal.identity.chatId, 'old');
    assert.ok([...f.records.values()].some(row => row.memory?.chatId === 'new'), 'new archive is durable');
});

test('prepareInheritedArchive migrates every owned session and actual album read while keeping source unchanged', async () => {
    const f = await setup();
    const snapshot = { entryId: 'source-entry', memory: plain(f.bank), cache: plain(f.original) };
    for (const mode of Object.values(f.constants.MODE)) snapshot.cache[mode] ||= { kind: mode, chatId: 'old', archiveRevision: 'r1' };
    const before = plain(snapshot);
    const result = f.get('archive/inheritance').prepareInheritedArchive(snapshot, f.host, 1234);
    assert.deepEqual(plain(snapshot), before);
    assertArtwork(f.cache.loadSession(f.constants.MODE.ALBUM, { cache: result.cache, memoryBank: result.memory, chatId: 'new' }), f.album);
    for (const mode of Object.values(f.constants.MODE)) {
        assert.equal(result.cache[mode].chatId, 'new', mode);
        assert.equal(result.cache[mode].archiveRevision, result.memory.archiveRevision, mode);
    }
    assert.equal(result.cache[f.cache.GENERATION_DRAFTS_CACHE_KEY], undefined);
    assert.equal(result.memory.inheritanceV1.sourceChatId, 'old');
});

test('inheritance cannot adopt a same-revision session from an unrelated chat', async () => {
    const f = await setup();
    const cache = plain(f.original); cache[f.constants.MODE.ALBUM].chatId = 'stranger';
    const result = f.get('archive/inheritance').prepareInheritedArchive({ entryId: 'source', memory: f.bank, cache }, f.host, 1234);
    assert.equal(f.cache.loadSession(f.constants.MODE.ALBUM, { cache: result.cache, memoryBank: result.memory, chatId: 'new' }), null);
    assert.notEqual(result.cache[f.constants.MODE.ALBUM]?.chatId, 'new');
});

for (const compressed of [false, true]) test(`repair restores proven previously claimed ${compressed ? 'gzip' : 'raw'} content`, async () => {
    const f = await setup({ compressed, claimed: true });
    assert.equal(f.load(), null);
    assert.equal(typeof f.get('archive/chatIdentityMigration')?.repairArchiveChatIdentity, 'function');
    await f.get('archive/chatIdentityMigration').repairArchiveChatIdentity(f.host);
    await f.cache.ensureCacheHydrated(f.host);
    assertArtwork(f.load(), f.album);
});

test('repair never adopts an unknown same-revision cache without identity evidence', async () => {
    const f = await setup({ claimed: true }); delete f.bank.claimedFromChatId;
    const before = plain(f.host.chatMetadata);
    await f.get('archive/chatIdentityMigration').repairArchiveChatIdentity(f.host);
    assert.deepEqual(plain(f.host.chatMetadata), before); assert.equal(f.load(), null); assert.equal(f.controls.writes.length, 0);
});

for (const mutation of ['write-failure', 'switch-chat', 'cache-edit', 'identity-edit']) test(`claim preserves metadata when ${mutation} occurs at durable boundary`, async () => {
    const f = await setup();
    let changed = false, expected;
    f.controls.put = async () => {
        if (changed) return; changed = true;
        if (mutation === 'switch-chat') f.switchTo({ ...f.host, chatId: 'other', chatMetadata: {} });
        if (mutation === 'cache-edit') f.host.chatMetadata[f.constants.CACHE_KEY][f.constants.MODE.ALBUM].cards[0].favorite = false;
        if (mutation === 'identity-edit') f.host.characters[0].avatar = 'another.png';
        expected = plain(f.host.chatMetadata);
        if (mutation === 'write-failure') throw Error('test disk unavailable');
    };
    const before = plain(f.host.chatMetadata);
    try { await f.repository.claimMismatchedArchive(f.host); } catch {}
    assert.ok(changed, 'real durable boundary must be exercised');
    assert.deepEqual(plain(f.host.chatMetadata), expected || before, 'no migration metadata leaks on failure or staleness');
    assert.equal(f.host.chatMetadata[f.constants.MEMORY_KEY].chatId, 'old');
});

test('repair restores the recorded inheritance source after both cache and revision were already promoted', async () => {
    const f = await setup({ claimed: true }); delete f.bank.claimedFromChatId;
    f.bank.archiveRevision = 'inherit-r2';
    f.bank.inheritanceV1 = { version: 1, sourceChatId: 'old', sourceArchiveRevision: 'r1', sourceEntryId: 'source-entry' };
    const cache = f.host.chatMetadata[f.constants.CACHE_KEY];
    cache.chatId = 'new'; cache.archiveRevision = 'inherit-r2';
    cache[f.constants.MODE.ALBUM].archiveRevision = 'inherit-r2';
    const beforeDraft = plain(cache[f.cache.GENERATION_DRAFTS_CACHE_KEY]);
    await f.get('archive/chatIdentityMigration').repairArchiveChatIdentity(f.host);
    await f.cache.ensureCacheHydrated(f.host);
    assertArtwork(f.load(), f.album);
    const after = await f.raw(f.host.chatMetadata[f.constants.CACHE_KEY]);
    // Even a previously promoted cache cannot make its original jobs runnable here.
    assert.equal(after[f.cache.GENERATION_DRAFTS_CACHE_KEY], undefined);
    const old = after[f.get('archive/chatIdentityMigration').CHAT_IDENTITY_SNAPSHOTS_KEY]?.[0];
    assert.ok(old); assert.deepEqual(plain(old.cache[f.cache.GENERATION_DRAFTS_CACHE_KEY]), beforeDraft);
});

test('claimed provenance is not permission to adopt a different same-revision session', async () => {
    const f = await setup({ claimed: true });
    f.host.chatMetadata[f.constants.CACHE_KEY].chatId = 'new';
    f.host.chatMetadata[f.constants.CACHE_KEY][f.constants.MODE.ALBUM].chatId = 'stranger';
    const before = plain(f.host.chatMetadata);
    await f.get('archive/chatIdentityMigration').repairArchiveChatIdentity(f.host);
    assert.deepEqual(plain(f.host.chatMetadata), before); assert.equal(f.load(), null); assert.equal(f.controls.writes.length, 0);
});

test('actual IndexedDB CAS refuses to replace a concurrently updated durable album', async () => {
    const f = await setup({ claimed: true });
    f.host.chatMetadata[f.constants.CACHE_KEY].chatId = 'new';
    const entry = f.cache.archiveBackupEntryForContext(f.host, f.bank);
    await f.store.seedArchiveBackup(entry, f.bank, f.host.chatMetadata[f.constants.CACHE_KEY]);
    const before = plain(f.host.chatMetadata);
    let raced = false;
    f.controls.put = async record => {
        if (raced) return; raced = true;
        const existing = plain(f.records.get(record.entryId));
        existing.cache.commitToken += 1;
        existing.cache[f.constants.MODE.ALBUM].cards[0].favorite = false;
        f.records.set(existing.entryId, existing);
    };
    await assert.rejects(() => f.get('archive/chatIdentityMigration').repairArchiveChatIdentity(f.host));
    assert.ok(raced);
    assert.deepEqual(plain(f.host.chatMetadata), before);
    assert.equal(f.records.get(entry.entryId).cache[f.constants.MODE.ALBUM].cards[0].favorite, false);
});

for (const compressed of [false, true]) test(`actual adoptForeignArchive reads the ${compressed ? 'gzip' : 'raw'} album in the destination`, async () => {
    const f = await setup({ compressed });
    const count = f.bank.memories.length;
    const result = await f.get('archive/archiveFile').adoptForeignArchive({ context: f.host, sameHistory: false });
    assert.equal(result.memories, count);
    await f.cache.ensureCacheHydrated(f.host);
    assertArtwork(f.load(), f.album);
    assert.equal(f.host.chatMetadata[f.constants.MEMORY_KEY].inheritanceV1.sourceChatId, 'old');
    assert.equal(f.host.chatMetadata[f.constants.MEMORY_KEY].sourceMessageCount, 0);
});

for (const sameHistory of [false, true]) test(`actual importArchiveFile preserves artwork and sameHistory=${sameHistory} floor semantics`, async () => {
    const f = await setup();
    const data = { format: 'hearttrace-archive-file', version: 1, exportedAt: '2026-10-09T10:00:00Z',
        sourceChatId: 'old', memory: plain(f.bank), cache: plain(f.original), metadata: { heartbeatMemoriesTestExtra: { note: 'preserved' } } };
    f.host.chatMetadata = {};
    f.host.chat = Array.from({ length: 3 }, (_, n) => ({ is_user: false, name: 'Char', mes: `source line ${n}`, send_date: '2026-10-09' }));
    const result = await f.get('archive/archiveFile').importArchiveFile(JSON.stringify(data), { context: f.host, sameHistory });
    assert.equal(result.memories, 1);
    await f.cache.ensureCacheHydrated(f.host);
    assertArtwork(f.load(), f.album);
    assert.equal(f.host.chatMetadata[f.constants.MEMORY_KEY].sourceMessageCount, sameHistory ? 3 : 0);
    assert.equal(f.host.chatMetadata.heartbeatMemoriesTestExtra.note, 'preserved');
    assert.equal(data.cache[f.constants.MODE.ALBUM].chatId, 'old');
});

for (const entry of ['adopt', 'import']) test(`${entry} sameHistory cannot commit after a chat switch during asynchronous full-history reading`, async () => {
    const f = await setup();
    const data = { format: 'hearttrace-archive-file', version: 1, sourceChatId: 'old', memory: plain(f.bank), cache: plain(f.original), metadata: { heartbeatMemoriesTestExtra: 'must not cross' } };
    if (entry === 'import') f.host.chatMetadata = {};
    f.host.chat = Array.from({ length: 130 }, (_, n) => ({ is_user: false, name: 'Char', mes: `source line ${n}`, send_date: '2026-10-09' }));
    const before = plain(f.host.chatMetadata), other = { ...f.host, chatId: 'other', chatMetadata: { keep: 'unchanged' } };
    let switched = false;
    f.sb.setTimeout = (callback, delay, ...args) => {
        if (delay === 0 && !switched) { switched = true; queueMicrotask(() => f.switchTo(other)); }
        return setTimeout(callback, delay, ...args);
    };
    const file = f.get('archive/archiveFile');
    await assert.rejects(() => entry === 'adopt' ? file.adoptForeignArchive({ context: f.host, sameHistory: true })
        : file.importArchiveFile(JSON.stringify(data), { context: f.host, sameHistory: true }));
    assert.ok(switched, 'actual history loop must yield at the async boundary');
    assert.deepEqual(plain(f.host.chatMetadata), before);
    assert.deepEqual(other.chatMetadata, { keep: 'unchanged' });
    assert.equal(f.controls.writes.length, 0);
});

test('claim after an old incomplete claim migrates A → B → C with the original album intact', async () => {
    const f = await setup({ claimed: true });
    f.host.chatId = 'third';
    assert.equal(f.bank.chatId, 'new'); assert.equal(f.original[f.constants.MODE.ALBUM].chatId, 'old');
    await f.repository.claimMismatchedArchive(f.host);
    await f.cache.ensureCacheHydrated(f.host);
    assert.equal(f.host.chatMetadata[f.constants.MEMORY_KEY].chatId, 'third');
    assertArtwork(f.load(), f.album);
    assert.equal(f.load().chatId, 'third');
});

for (const claimed of [false, true]) for (const asynchronous of [false, true]) test(`${claimed ? 'repair' : 'claim'} rolls back a ${asynchronous ? 'rejected' : 'throwing'} metadata save and retries from durable content`, async () => {
    const f = await setup({ claimed });
    const scope = f.cache.cacheScopeFromContext(f.host), runtime = f.get('core/state').state.runtimeSessionCache;
    f.cache.rememberRuntimeSessionCache(scope, plain(f.original));
    const metadataBefore = plain(f.host.chatMetadata), runtimeBefore = plain(runtime.get(scope));
    f.host.saveMetadataDebounced = () => {
        const error = Error('test metadata save failure');
        if (asynchronous) return Promise.reject(error); throw error;
    };
    const operation = () => claimed ? f.get('archive/chatIdentityMigration').repairArchiveChatIdentity(f.host)
        : f.repository.claimMismatchedArchive(f.host);
    await assert.rejects(operation, /test metadata save failure/);
    assert.deepEqual(plain(f.host.chatMetadata), metadataBefore);
    assert.deepEqual(plain(runtime.get(scope)), runtimeBefore);
    const durable = [...f.records.values()].find(row => row.memory?.chatId === 'new');
    assert.ok(durable, 'canonical commit is retained after host mirror failure');
    const canonical = await f.raw(durable.cache);
    const snapshots = canonical[f.get('archive/chatIdentityMigration').CHAT_IDENTITY_SNAPSHOTS_KEY];
    assert.ok(snapshots.some(row => row.cache?.[f.constants.MODE.ALBUM]?.cards?.[0]?.imageUrl === f.album.cards[0].imageUrl));
    // A later edit of the successful canonical result must win over old metadata.
    canonical[f.constants.MODE.ALBUM].cards[0].favorite = false;
    canonical.commitToken += 1;
    durable.cache = f.cache.compressedCacheManifest(canonical, await f.cache.gzipJson(canonical));
    f.records.set(durable.entryId, plain(durable));
    f.host.saveMetadataDebounced = () => { f.controls.saves++; };
    await operation(); await f.cache.ensureCacheHydrated(f.host);
    const expected = plain(f.album); expected.cards[0].favorite = false;
    assertArtwork(f.load(), expected);
    assert.equal(f.load().chatId, 'new');
});

test('opening the album repairs a proven old claim through the real workspace entry without generation', async () => {
    const f = await setup({ compressed: true, claimed: true });
    let requests = 0;
    f.sb.fetch = f.host.generateRaw = async () => { requests++; throw Error('must not generate'); };
    assert.equal(f.load(), null);
    await f.get('ui/overlayCore').openCachedOrGenerate(f.constants.MODE.ALBUM);
    assertArtwork(f.load(), f.album);
    const state = f.get('core/state').state;
    assert.equal(state.activeMode, f.constants.MODE.ALBUM);
    assertArtwork(state.activeSession, f.album);
    assert.equal(requests, 0);
});

test('ensureCurrentArchiveBackup naturally repairs the old claim and preserves readable content without generation', async () => {
    const f = await setup({ compressed: true, claimed: true });
    let requests = 0;
    f.sb.fetch = f.host.generateRaw = async () => { requests++; throw Error('must not generate'); };
    await f.cache.ensureCurrentArchiveBackup(f.host);
    await f.cache.ensureCacheHydrated(f.host);
    assertArtwork(f.load(), f.album);
    assert.ok([...f.records.values()].some(row => row.memory?.chatId === 'new'));
    assert.equal(requests, 0);
});

for (const entry of ['adopt', 'import']) test(`${entry} retries failed host metadata save from its committed canonical inheritance`, async () => {
    const f = await setup();
    const data = { format: 'hearttrace-archive-file', version: 1, exportedAt: '2026-10-09T10:00:00Z',
        sourceChatId: 'old', memory: plain(f.bank), cache: plain(f.original), metadata: { heartbeatMemoriesTestExtra: 'inherited extra' } };
    if (entry === 'import') f.host.chatMetadata = {};
    const before = plain(f.host.chatMetadata), scope = f.cache.cacheScopeFromContext(f.host);
    const file = f.get('archive/archiveFile');
    const operation = () => entry === 'adopt' ? file.adoptForeignArchive({ context: f.host, sameHistory: false })
        : file.importArchiveFile(JSON.stringify(data), { context: f.host, sameHistory: false });
    f.host.saveMetadataDebounced = async () => { throw Error('metadata mirror unavailable'); };
    await assert.rejects(operation, /metadata mirror unavailable/);
    assert.deepEqual(plain(f.host.chatMetadata), before);
    assert.equal(f.get('core/state').state.runtimeSessionCache.has(scope), false);
    const durable = [...f.records.values()].find(row => row.memory?.chatId === 'new');
    assert.ok(durable);
    const revision = durable.archiveRevision;
    const canonical = await f.raw(durable.cache);
    canonical[f.constants.MODE.ALBUM].cards[0].imageUrl = '/user/images/latest-canonical.png';
    canonical[f.constants.MODE.ALBUM].cards[0].favorite = false;
    canonical.commitToken += 1;
    durable.cache = f.cache.compressedCacheManifest(canonical, await f.cache.gzipJson(canonical));
    f.records.set(durable.entryId, plain(durable));
    f.host.saveMetadataDebounced = () => {};
    await operation(); await f.cache.ensureCacheHydrated(f.host);
    const expected = plain(f.album);
    expected.cards[0].imageUrl = '/user/images/latest-canonical.png'; expected.cards[0].favorite = false;
    assertArtwork(f.load(), expected);
    assert.equal(f.host.chatMetadata[f.constants.MEMORY_KEY].archiveRevision, revision, 'retry reuses acknowledged canonical revision');
});

test('rename rebinds only the verified archived prefix and leaves later messages pending', async () => {
    const f = await setup();
    f.host.chat = Array.from({ length: 5 }, (_, n) => ({ is_user: n % 2 === 0, name: n % 2 === 0 ? 'User' : 'Char', mes: `unchanged source line ${n}`, send_date: '2026-10-09' }));
    const api = f.get('core/context');
    const old = await api.buildChatSnapshot(f.host, { expectedChatId: 'old', completeSource: true, prefixCount: 3 });
    f.bank.sourceMessageCount = 3;
    f.bank.sourceFingerprint = `${old.prefixFingerprint}:external-source-kept`;
    f.bank.fullSourceFingerprint = old.fullPrefixFingerprint;
    await f.repository.claimMismatchedArchive(f.host);
    const migrated = f.host.chatMetadata[f.constants.MEMORY_KEY];
    const current = await api.buildChatSnapshot(f.host, { expectedChatId: 'new', completeSource: true, prefixCount: 3 });
    assert.equal(migrated.sourceMessageCount, 3);
    assert.equal(migrated.sourceFingerprint, `${current.prefixFingerprint}:external-source-kept`);
    assert.equal(migrated.fullSourceFingerprint, current.fullPrefixFingerprint);
    assert.equal(f.repository.getMemoryState(f.host).pendingMessages, 2);
    assert.deepEqual(plain(current.incrementalMessages.map(row => row.text)), ['unchanged source line 3', 'unchanged source line 4']);
    assertArtwork(f.load(), f.album);
});

test('rename does not forgive a changed archived prefix or mark pending messages as already imported', async () => {
    const f = await setup();
    f.host.chat = Array.from({ length: 5 }, (_, n) => ({ is_user: false, name: 'Char', mes: `source line ${n}`, send_date: '2026-10-09' }));
    const api = f.get('core/context');
    const old = await api.buildChatSnapshot(f.host, { expectedChatId: 'old', completeSource: true, prefixCount: 3 });
    f.bank.sourceMessageCount = 3;
    f.bank.sourceFingerprint = `${old.prefixFingerprint}:external-source-kept`;
    f.bank.fullSourceFingerprint = old.fullPrefixFingerprint;
    const before = { sourceMessageCount: f.bank.sourceMessageCount, sourceFingerprint: f.bank.sourceFingerprint, fullSourceFingerprint: f.bank.fullSourceFingerprint };
    f.host.chat[1].mes = 'an actual replacement of previously archived content';
    await f.repository.claimMismatchedArchive(f.host);
    const migrated = f.host.chatMetadata[f.constants.MEMORY_KEY];
    assert.deepEqual({ sourceMessageCount: migrated.sourceMessageCount, sourceFingerprint: migrated.sourceFingerprint, fullSourceFingerprint: migrated.fullSourceFingerprint }, before);
    assert.equal(f.repository.getMemoryState(f.host).pendingMessages, 2);
    assertArtwork(f.load(), f.album);
});
