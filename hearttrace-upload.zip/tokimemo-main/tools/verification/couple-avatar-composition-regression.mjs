import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';

// 构图随机: one variation per drawing, always keeping the couple-avatar contract.
const people = [{ name: 'L', appearance: '1boy, black hair' }, { name: 'R', appearance: '1girl, long black hair' }];
const plain = value => JSON.parse(JSON.stringify(value));
async function setup() { const f = await fixture(); return { core: f.get('extras/coupleAvatar'), styles: f.get('extras/coupleAvatarStyles') }; }

test('absent and classic composition keep the previous prompt exactly', async () => {
    const { core } = await setup();
    for (const promptFormat of ['', 'nai5-natural', 'nai45-tags']) {
        const base = core.couplePromptParts({ people, styleId: 'anime-clean', promptFormat }, null);
        assert.deepEqual(plain(core.couplePromptParts({ people, styleId: 'anime-clean', promptFormat, composition: 'classic' }, null)), plain(base));
    }
    assert.equal(Object.hasOwn(core.normalizeCoupleSettings({ composition: 'nope' }, null), 'composition'), false);
    assert.equal(core.normalizeCoupleSettings({ composition: 'classic' }, null).composition, 'classic');
});

test('every variation adds its camera line and the couple-pair cue in all three dialects', async () => {
    const { core, styles } = await setup();
    assert.ok(styles.COMPOSITION_VARIANTS.length >= 10);
    for (const variant of styles.COMPOSITION_VARIANTS) {
        for (const promptFormat of ['', 'nai5-natural']) {
            const parts = core.couplePromptParts({ people, styleId: 'anime-clean', interaction: '交给灵感', promptFormat, composition: variant.id }, null);
            for (const text of [parts.prompt, parts.nai.nl]) {
                assert.ok(text.includes(variant.prompt), variant.id);
                assert.ok(text.includes(variant.sets.length ? `Pose accent: ${variant.prompt} The interaction's own actions stay exactly as described.` : `Camera: ${variant.prompt}`), variant.id);
                assert.match(text, /couple avatar pair: complementary, not mirrored, poses/);
                assert.match(text, /cropped into two avatars/);
            }
        }
        const tags = core.couplePromptParts({ people, styleId: 'anime-clean', interaction: '交给灵感', promptFormat: 'nai45-tags', composition: variant.id }, null);
        assert.ok(tags.scene.includes(variant.tags), variant.id);
        assert.doesNotMatch(tags.scene, /[^\x20-\x7e\r\n]|\.(?:\s|$)|;/u, variant.id);
    }
});

test('choices: none for layout styles, no head re-orienting for front-facing interactions, no portrait-only crops for full figures', async () => {
    const { core } = await setup();
    assert.equal(core.coupleCompositionChoices({ styleId: 'layout-closeup' }).length, 0);
    assert.ok(core.couplePromptParts({ people, styleId: 'layout-closeup', composition: 'tilt' }, null).prompt.indexOf('Camera:') < 0);
    const front = core.coupleCompositionChoices({ styleId: 'anime-clean', interaction: '许愿流星' }).map(row => row.id);
    assert.ok(!front.includes('three-quarter') && !front.includes('one-turns') && !front.includes('over-shoulder'));
    const chibi = core.coupleCompositionChoices({ styleId: 'chibi-dumpling', interaction: '半颗爱心' }).map(row => row.id);
    assert.ok(!chibi.includes('close') && !chibi.includes('heads-close') && chibi.includes('three-quarter'));
});

test('a composition never changes what the interaction already sets', async () => {
    const { core, styles } = await setup();
    const camera = styles.COMPOSITION_VARIANTS.filter(row => !row.sets.length);
    assert.ok(camera.length >= 4);
    for (const row of camera) assert.doesNotMatch(row.prompt, /\b(?:look|looks|gaze|hand|hands|lean|smil\w*|seated|turn\w*)\b/i, `${row.id} is camera-only`);
    for (const preset of styles.INTERACTION_PRESETS) {
        const claims = core.coupleCompositionClaims({ interaction: preset.label });
        const choices = core.coupleCompositionChoices({ styleId: 'anime-clean', interaction: preset.label });
        for (const row of choices) assert.ok(!row.sets.some(key => claims.includes(key)), `${preset.label} × ${row.id}`);
        for (const row of camera) assert.ok(choices.includes(row), `${preset.label} keeps camera ${row.id}`);
    }
    const ids = (interaction, extra = {}) => core.coupleCompositionChoices({ styleId: 'anime-clean', interaction, ...extra }).map(row => row.id);
    for (const id of ['lean-in', 'heads-close', 'three-quarter', 'seated', 'over-shoulder', 'one-turns']) assert.ok(!ids('背靠背依偎').includes(id), `背靠背 × ${id}`);
    for (const id of ['lean-in', 'heads-close']) assert.ok(!ids('隔空对望').includes(id), `隔空 × ${id}`);
    assert.ok(!ids('一起散步').includes('seated'));
    assert.ok(!ids('额头相抵').includes('one-turns'));
    assert.ok(!ids('递出一朵花').includes('reach') && !ids('递出一朵花').includes('over-shoulder'));
    assert.deepEqual(ids('比谁更高'), camera.map(row => row.id), 'heavily posed interaction: camera only');
    assert.equal(ids('交给灵感').length, styles.COMPOSITION_VARIANTS.length, 'inspiration leaves every pose open');
    // Free Chinese text and the user's own direction are read too.
    const custom = ids('自定义互动', { interactionDetail: '左边牵着右边的手，两人坐在长椅上' });
    assert.ok(!custom.includes('reach') && !custom.includes('seated'));
    assert.ok(!ids('假装生气', { direction: '两人对视，头靠在一起' }).includes('heads-close'));
    // A stored or explicitly chosen clashing variation is dropped from the prompt.
    const clash = core.couplePromptParts({ people, styleId: 'anime-clean', interaction: '背靠背依偎', promptFormat: 'nai5-natural', composition: 'heads-close' }, null);
    assert.doesNotMatch(clash.nai.nl, /Pose accent|couple avatar pair/);
    const fine = core.couplePromptParts({ people, styleId: 'anime-clean', interaction: '背靠背依偎', promptFormat: 'nai5-natural', composition: 'tilt' }, null);
    assert.match(fine.nai.nl, /Camera: A slight diagonal camera tilt/);
});
