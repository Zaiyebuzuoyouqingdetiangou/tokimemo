import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';

// 构图随机: one variation per drawing, always keeping the couple-avatar contract.
const people = [{ name: 'L', appearance: '1boy, black hair' }, { name: 'R', appearance: '1girl, long black hair' }];
const plain = value => JSON.parse(JSON.stringify(value));
async function setup() { const f = await fixture(); return { core: f.get('extras/coupleAvatar'), styles: f.get('extras/coupleAvatarStyles') }; }

test('absent and classic composition keep the previous prompt exactly', async () => {
    const { core } = await setup();
    for (const promptFormat of ['', 'nai5-natural', 'nai45-tags']) {
        const base = core.couplePromptParts({ people, styleId: 'anime-clean', promptFormat }, null);
        assert.deepEqual(plain(core.couplePromptParts({ people, styleId: 'anime-clean', promptFormat, composition: 'classic' }, null)), plain(base));
    }
    assert.equal(Object.hasOwn(core.normalizeCoupleSettings({ composition: 'nope' }, null), 'composition'), false);
    assert.equal(core.normalizeCoupleSettings({ composition: 'classic' }, null).composition, 'classic');
});

test('every variation adds its camera line and the couple-pair cue in all three dialects', async () => {
    const { core, styles } = await setup();
    assert.ok(styles.COMPOSITION_VARIANTS.length >= 10);
    for (const variant of styles.COMPOSITION_VARIANTS) {
        for (const promptFormat of ['', 'nai5-natural']) {
            const parts = core.couplePromptParts({ people, styleId: 'anime-clean', promptFormat, composition: variant.id }, null);
            for (const text of [parts.prompt, parts.nai.nl]) {
                assert.ok(text.includes(variant.prompt), variant.id);
                assert.match(text, /couple avatar pair: complementary, not mirrored, poses/);
                assert.match(text, /cropped into two avatars/);
            }
        }
        const tags = core.couplePromptParts({ people, styleId: 'anime-clean', promptFormat: 'nai45-tags', composition: variant.id }, null);
        assert.ok(tags.scene.includes(variant.tags), variant.id);
        assert.doesNotMatch(tags.scene, /[^\x20-\x7e\r\n]|\.(?:\s|$)|;/u, variant.id);
    }
});

test('choices: none for layout styles, no head re-orienting for front-facing interactions, no portrait-only crops for full figures', async () => {
    const { core } = await setup();
    assert.equal(core.coupleCompositionChoices({ styleId: 'layout-closeup' }).length, 0);
    assert.ok(core.couplePromptParts({ people, styleId: 'layout-closeup', composition: 'tilt' }, null).prompt.indexOf('Camera and pose') < 0);
    const front = core.coupleCompositionChoices({ styleId: 'anime-clean', interaction: '许愿流星' }).map(row => row.id);
    assert.ok(!front.includes('three-quarter') && !front.includes('one-turns') && !front.includes('over-shoulder'));
    const chibi = core.coupleCompositionChoices({ styleId: 'chibi-dumpling', interaction: '半颗爱心' }).map(row => row.id);
    assert.ok(!chibi.includes('close') && !chibi.includes('heads-close') && chibi.includes('three-quarter'));
});
