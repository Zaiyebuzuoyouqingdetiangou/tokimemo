// Real libxml-parsed HTML and native Canvas with a minimal event-host double.
// This is controller/pixel evidence, not a browser layout or touch-device test.
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import {execFileSync} from 'node:child_process';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const native=require(require.resolve('@napi-rs/canvas',{paths:[process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES]}));
const root=path.resolve(process.env.TEST_ROOT||'.');
export const html=fs.readFileSync(path.join(root,'preview/hearttrace-editor-redesign.html'),'utf8');
export const script=html.match(/<script>\s*([\s\S]*?)<\/script>/)[1];
const parse=markup=>JSON.parse(execFileSync('python3',['-c',`import sys,json
from lxml import html
r=html.fragment_fromstring(sys.stdin.read(),create_parent='root')
def node(e): return {'tag':e.tag,'attrs':dict(e.attrib),'text':e.text or '', 'children':[node(c) for c in e if isinstance(c.tag,str)]}
print(json.dumps(node(r)))`],{input:markup,encoding:'utf8',maxBuffer:8000000}));
const initial=parse(html);
export async function preview(customReadme){
 let document,focused=null,serial=0;
 const frames=new Map(),timers=new Map(),images=[];
 class Element{
  constructor(tag){this.tag=tag;this.attrs={};this.dataset={};this.style={};this.children=[];this.listeners={};this.hidden=false;this.value='';this._text='';if(tag==='canvas')this.native=native.createCanvas(300,150);}
  setAttribute(k,v){this.attrs[k]=String(v);if(k.startsWith('data-'))this.dataset[k.slice(5).replace(/-([a-z])/g,(_,a)=>a.toUpperCase())]=String(v);if(k==='value')this.value=String(v);if(k==='hidden')this.hidden=true;if(k==='checked')this.checked=true;if(k==='width')this.width=Number(v);if(k==='height')this.height=Number(v);}
  getAttribute(k){return this.attrs[k]??null}get id(){return this.attrs.id||''}set id(v){this.setAttribute('id',v)}get className(){return this.attrs.class||''}set className(v){this.attrs.class=v}
  get classList(){const n=this;return {contains:x=>n.className.split(' ').includes(x),add:x=>n.className=[...new Set([...n.className.split(' '),x])].filter(Boolean).join(' '),toggle(x,force){const current=n.className.split(' ').filter(Boolean),on=force??!current.includes(x);n.className=(on?[...new Set([...current,x])]:current.filter(c=>c!==x)).join(' ');return on}}}
  get textContent(){return this._text+this.children.map(c=>c.textContent).join('')}set textContent(v){this._text=String(v);this.children=[]}
  set innerHTML(v){this._text='';this.children=[];for(const child of parse(v).children)this.append(fromTree(child))}
  append(...items){for(const child of items){child.parent=this;this.children.push(child)}}replaceChildren(...items){this._text='';this.children=[];this.append(...items)}
  matches(s){if(s.startsWith('.'))return this.classList.contains(s.slice(1));if(s.startsWith('#'))return this.id===s.slice(1);const m=/^\[([^=\]]+)(?:="([^"]*)")?\]$/.exec(s);return m?m[1] in this.attrs&&(m[2]===undefined||this.attrs[m[1]]===m[2]):this.tag===s}
  closest(s){return this.matches(s)?this:this.parent?.closest(s)||null}querySelectorAll(s){return this.children.flatMap(c=>[...(c.matches(s)?[c]:[]),...c.querySelectorAll(s)])}querySelector(s){return this.querySelectorAll(s)[0]||null}
  addEventListener(k,f){(this.listeners[k]??=[]).push(f)}fire(k,extra={}){const e={target:this,key:'',preventDefault(){},...extra};let current=this;while(current){current['on'+k]?.(e);for(const f of current.listeners[k]||[])f(e);current=current.parent}return e}click(){this.fire('click')}focus(){focused=this.id}showModal(){this.open=true}close(){this.open=false}setPointerCapture(){}
  get width(){return this.native.width}set width(v){this.native.width=v}get height(){return this.native.height}set height(v){this.native.height=v}
  getContext(){const g=this.native.getContext('2d');if(!this.contextPatched){const draw=g.drawImage.bind(g);g.drawImage=(img,...args)=>draw(img.native||img,...args);this.contextPatched=true}return g}
  get clientWidth(){return this.id==='filmstrip'?370:91}get offsetLeft(){return this.parent?this.parent.children.indexOf(this)*99:0}
 }
 function fromTree(tree){const e=new Element(tree.tag);for(const [k,v] of Object.entries(tree.attrs))e.setAttribute(k,v);e._text=tree.text;e.append(...tree.children.map(fromTree));return e}
 document=fromTree(initial);document.getElementById=id=>document.querySelector('#'+id);document.createElement=tag=>new Element(tag);document.hidden=false;
 const node=id=>document.getElementById(id);node('captions').value='on';
 if(customReadme!==undefined)node('readme-data').textContent=JSON.stringify(customReadme);
 class Image extends native.Image{set src(v){super.src=v;images.push(this.decode())}get src(){return super.src}}
 const sandbox={console,document,Image,URL,Error,requestAnimationFrame:f=>{const id=++serial;frames.set(id,f);return id},cancelAnimationFrame:id=>frames.delete(id),setTimeout:f=>{const id=++serial;timers.set(id,f);return id},clearTimeout:id=>timers.delete(id),window:{addEventListener(){}}};
 const context=vm.createContext(sandbox);new vm.Script(script).runInContext(context);await Promise.all(images);
 await new Promise(resolve=>setImmediate(resolve));
 return {node,context,document,focused:()=>focused,run:code=>vm.runInContext(code,context),frame(now){const callbacks=[...frames.values()];frames.clear();for(const fn of callbacks)fn(now)}};
}
