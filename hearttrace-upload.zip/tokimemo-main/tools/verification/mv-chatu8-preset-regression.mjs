import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { fixture } from './fixture.mjs';

const song = { id: 'SONG_preset', title: 'Preset cast', lyrics: '[Verse 1]\n看向你\n[End]' };
const plain = value => JSON.parse(JSON.stringify(value));
const cast = { version: 1, cardType: 'multi', selectedIds: ['r', 'k'], people: [
    { id: 'r', name: 'Raphael', sourceRefs: [] }, { id: 'k', name: 'Kamael', sourceRefs: [] },
], appearances: [{ participantId: 'r', tag: 'brown hair, brown eyes', manual: true },
    { participantId: 'k', tag: 'black hair, amber eyes, slender fingers', manual: true }] };

async function setup({ provider = 'chatu8-image', mode = 'novelai', visible = 'full', legacy = false, who = 'both' } = {}) {
    const f = await fixture(), mv = f.get('extras/mv'), castApi = f.get('extras/mvCast');
    f.host.name2 = 'Raphael'; f.host.name1 = 'Kamael';
    f.get('core/cache').loadSession = () => ({ songs: [song] });
    f.get('core/castLooks').readCastLooks = () => ({ manual: true, char: 'brown hair, brown eyes', user: 'black hair, amber eyes, slender fingers' });
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS, imageGenerationProvider: provider, imageGenerationFallback: false });
    const raw = { groups: [{ id: 'A', who, layer: 'full', composition: 'hands reaching toward light',
        cast: [{ participantId: 'r', visible }, { participantId: 'k', visible }],
        diffs: [{ id: 'open', imagePrompt: 'hands reaching toward light' }], bgs: [{ id: 'street', prompt: 'empty snowy street' }] }],
        frames: [{ sectionIndex: 0, lyric: '看向你', group: 'A', diff: 'open' }] };
    if (legacy) delete raw.groups[0].cast;
    const settings = mv.normalizeSettings({ output: 'tegaki', storyType: 'interaction', range: 'full', appear: 'face' });
    const built = mv.buildShots(f.json(raw), f.bank, 1, settings, legacy ? null : f.json(cast));
    const record = { ...built, settings, id: song.id, createdAt: 1,
        ...(legacy ? {} : { cast: f.json(cast) }), wardrobe: { characters: [{ participantId: 'k', clothing: 'blue cloak' }] } };
    f.host.chatMetadata[mv.MV_KEY] = { songs: { [song.id]: record } };
    const requests = [], baibai = [];
    const source = new EventEmitter(); f.host.eventSource = source;
    f.host.extensionSettings['st-chatu8'] = { scriptEnabled: true, mode, novelaimode: 'nai-diffusion-4-full', characterPresets: {
        gold: { nameEN: 'Kamael', characterTraits: 'blonde hair, pale skin, long fingers', facialFeatures: 'green eyes', facialFeaturesBack: 'short nape hair', upperBodySFW: 'red dress' },
    } };
    source.on('generate-image-request', request => {
        requests.push(request);
        source.emit('generate-image-response', { id: request.id, success: true, imageData: `/user/images/preset-${requests.length}.png` });
    });
    f.sb.STBaiBaiImage = { apiVersion: 1, capabilities: { generate: true, saveToGallery: true },
        getBackendStatus: () => ({ configured: true, backend: 'nai', supportsCharacters: true }),
        generate: async request => { baibai.push(request); return { path: '/user/images/baibai.png' }; } };
    return { ...f, mv, castApi, record, requests, baibai, presets: f.host.extensionSettings['st-chatu8'].characterPresets };
}

for (const mode of ['novelai', 'comfyui']) test(`MV ${mode} preview, shared asset and frame use per-person preset then local fallback`, async () => {
    const f = await setup({ mode }), before = plain(f.record.cast);
    const preview = f.mv.assetPrompt(f.record, 'G1:D1', f.host);
    assert.match(preview, /Raphael.*brown hair/); assert.match(preview, /Kamael.*blonde hair/);
    assert.doesNotMatch(preview, /black hair|amber eyes|red dress/); assert.match(preview, /blue cloak/);
    assert.equal((await f.mv.drawAsset(song.id, 'G1:D1')).pending, false);
    assert.equal((await f.mv.drawFrame(song.id, f.record.shots[0].id)).pending, false);
    assert.equal(f.requests.length, 2);
    for (const request of f.requests) {
        assert.match(request.prompt, /brown hair/); assert.match(request.prompt, /blonde hair/);
        assert.doesNotMatch(request.prompt, /black hair|amber eyes|red dress|\$Kamael/);
    }
    assert.deepEqual(plain(f.mv.readMv(f.host, song.id).cast), before);
});

test('MV ignores installed Chatu8 presets when BaiBai is selected', async () => {
    const f = await setup({ provider: 'baibai-image' });
    assert.match(f.mv.assetPrompt(f.record, 'G1:D1', f.host), /black hair/);
    assert.doesNotMatch(f.mv.assetPrompt(f.record, 'G1:D1', f.host), /blonde hair/);
    await f.mv.drawAsset(song.id, 'G1:D1');
    assert.equal(f.requests.length, 0); assert.equal(f.baibai.length, 1);
    assert.match(JSON.stringify(f.baibai[0]), /black hair/); assert.doesNotMatch(JSON.stringify(f.baibai[0]), /blonde hair/);
});

test('MV missing and ambiguous presets keep the corresponding local tag without blocking generation', async () => {
    for (const kind of ['missing', 'ambiguous']) {
        const f = await setup();
        if (kind === 'missing') delete f.presets.gold;
        else f.presets.other = { ...f.presets.gold, characterTraits: 'silver hair' };
        const preview = f.mv.assetPrompt(f.record, 'G1:D1', f.host);
        assert.match(preview, /black hair/); assert.doesNotMatch(preview, /blonde hair|silver hair/);
        assert.equal((await f.mv.drawAsset(song.id, 'G1:D1')).pending, false);
        assert.equal(f.requests.length, 1); assert.match(f.requests[0].prompt, /black hair/);
    }
});

test('same-name MV roster identities keep their own tags even when the provider has one unique name match', async () => {
    const f = await setup(); f.record.cast.people[0].name = 'Kamael';
    const preview = f.mv.assetPrompt(f.record, 'G1:D1', f.host);
    assert.match(preview, /brown hair/); assert.match(preview, /black hair/); assert.doesNotMatch(preview, /blonde hair/);
    await f.mv.drawAsset(song.id, 'G1:D1');
    assert.equal(f.requests.length, 1); assert.doesNotMatch(f.requests[0].prompt, /blonde hair/);
});

test('resolved MV hands, back and silhouette remain cropped through the actual Chatu8 adapter', async () => {
    for (const visible of ['hands', 'back', 'silhouette']) {
        const f = await setup({ visible });
        f.record.groups[0].cast = [{ participantId: 'k', visible }];
        const meta = f.castApi.castMetadata(f.record, f.record.groups[0], f.host);
        assert.equal(meta.characters[0].appearanceOverride, true);
        const normalized = f.get('generation/cgAppearance').normalizeCgPromptMetadata(meta);
        assert.equal(normalized.characters[0].appearanceOverride, true);
        const preview = f.mv.assetPrompt(f.record, 'G1:D1', f.host);
        await f.mv.drawAsset(song.id, 'G1:D1');
        assert.equal(f.requests.length, 1);
        for (const prompt of [preview, f.requests[0].prompt]) {
            assert.doesNotMatch(prompt, /green eyes|amber eyes/);
            if (visible === 'back') { assert.match(prompt, /blonde hair|short nape hair/); }
            else assert.doesNotMatch(prompt, /blonde hair|short nape hair/);
            if (visible === 'hands') { assert.match(prompt, /pale skin|long fingers/); assert.doesNotMatch(prompt, /blue cloak/); }
            if (visible === 'silhouette') assert.doesNotMatch(prompt, /pale skin|long fingers/);
        }
    }
});

test('MV empty scenes, backgrounds and full manual prompts do not gain preset people', async () => {
    const f = await setup(); f.record.groups[0].cast = [];
    f.record.motif = { name: '雪', prompt: 'small snowflake', image: null };
    const empty = f.mv.assetPrompt(f.record, 'G1:D1', f.host);
    assert.doesNotMatch(empty, /blonde hair|brown hair|black hair/);
    await f.mv.drawAsset(song.id, 'G1:D1');
    assert.doesNotMatch(f.requests[0].prompt, /blonde hair|brown hair|black hair/);
    for (const key of ['G1:bg', 'motif']) {
        assert.ok(f.mv.assetOf(f.record, key));
        assert.doesNotMatch(f.mv.assetPrompt(f.record, key, f.host), /blonde hair|brown hair/);
        assert.equal((await f.mv.drawAsset(song.id, key)).pending, false);
        assert.doesNotMatch(f.requests.at(-1).prompt, /blonde hair|brown hair/);
    }
    f.mv.writeMv(f.mv.mvScope(f.host), song.id, value => ({ ...value, assetPrompts: { 'G1:D1': 'my complete snowy landscape' } }));
    await f.mv.drawAsset(song.id, 'G1:D1');
    assert.equal(f.requests.at(-1).prompt, 'my complete snowy landscape');
});

test('legacy MV asset roles and pre-group video frames use only the on-screen preset identity', async () => {
    for (const legacyFrame of [false, true]) {
        const f = await setup({ legacy: true, who: 'user' });
        if (legacyFrame) {
            f.record.version = 1; delete f.record.groups;
            f.record.shots = [{ id: 'legacy-frame', who: 'user', imagePrompt: 'one person gazing at snow', sectionIndex: 0 }];
        }
        const preview = legacyFrame ? f.mv.framePrompt(f.record, f.record.shots[0], f.host) : f.mv.assetPrompt(f.record, 'G1:D1', f.host);
        assert.match(preview, /blonde hair/); assert.doesNotMatch(preview, /brown hair|black hair/);
        const result = legacyFrame ? await f.mv.drawFrame(song.id, 'legacy-frame') : await f.mv.drawAsset(song.id, 'G1:D1');
        assert.equal(result.pending, false); assert.equal(f.requests.length, 1);
        assert.match(f.requests[0].prompt, /blonde hair/); assert.doesNotMatch(f.requests[0].prompt, /brown hair|black hair/);
    }
});

for (const kind of ['modern-asset', 'legacy-asset', 'legacy-frame']) test(`long resolved preset keeps its final traits in MV ${kind} preview and send`, async () => {
    const f = await setup({ legacy: kind !== 'modern-asset', who: 'user' });
    const tag = 'blonde hair, ' + 'delicate freckles, '.repeat(165) + 'unique_appearance_tail';
    assert.ok(tag.length > 3000);
    f.presets.gold.characterTraits = tag; f.presets.gold.facialFeatures = '';
    if (kind === 'modern-asset') f.record.groups[0].cast = [{ participantId: 'k', visible: 'full' }];
    if (kind === 'legacy-frame') {
        f.record.version = 1; delete f.record.groups;
        f.record.shots = [{ id: 'legacy-frame', who: 'user', imagePrompt: 'one person gazing at snow', sectionIndex: 0 }];
    }
    const preview = kind === 'legacy-frame' ? f.mv.framePrompt(f.record, f.record.shots[0], f.host) : f.mv.assetPrompt(f.record, 'G1:D1', f.host);
    assert.ok(preview.includes(tag), 'the default preview must not truncate a resolved preset appearance');
    if (kind === 'modern-asset') {
        const metadata = f.get('generation/cgAppearance').normalizeCgPromptMetadata(f.castApi.castMetadata(f.record, f.record.groups[0], f.host));
        assert.equal(metadata.characters[0].tag, tag, 'normalization must preserve the locally resolved appearance');
    }
    const result = kind === 'legacy-frame' ? await f.mv.drawFrame(song.id, 'legacy-frame') : await f.mv.drawAsset(song.id, 'G1:D1');
    assert.equal(result.pending, false); assert.equal(f.requests.length, 1);
    assert.ok(f.requests[0].prompt.includes(tag), 'the sent prompt must include every appearance trait shown in preview');
});
