import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import fs from 'node:fs/promises';
const root = path.resolve(process.env.TEST_ROOT || 'candidate');
let bundled = null;
if (process.env.TEST_BUNDLE === '1') {
  const code = await fs.readFile(path.join(root,'dist/heartbeatMemories.bundle.js'),'utf8');
  const names = [...code.matchAll(/^const (__m_\w+) = Object.create\(null\);$/gm)].map(m=>m[1]);
  bundled = (await import('data:text/javascript;base64,'+Buffer.from(code+'\nexport const verificationModules={'+names.join(',')+'};').toString('base64'))).verificationModules;
}
const mod = name => bundled ? Promise.resolve(bundled['__m_'+(name+'.js').replace(/[^A-Za-z0-9_]/g,'_')]) : import(pathToFileURL(path.join(root, 'src', name + '.js')));
const [gate, plans, runner, registry, drawing, draft, store, recovery, context, constants, draftView, recoveryView, songs, targets, patch, cg, expanded] = await Promise.all([
  'autoMemory/incrementalGate','autoMemory/planStore','autoMemory/moduleRunner','autoMemory/moduleRegistry','autoMemory/draw',
  'archive/importRecovery','core/localRecoveryStore','generation/recovery','core/context','core/constants','archive/recoveryDrafts','ui/recoveryView',
  'core/themeSongContract','core/cgTargets','core/cgImagePatch','generation/cgImageCore','ui/expandedCgView',
].map(mod));
const modulePlans = await mod('autoMemory/modulePlans');
const bank = {version:3, chatId:'chat-test', archiveRevision:'revision-1', characterName:'角色甲', userName:'用户乙', memories:[]};
const host = {characterId:0, characters:[{name:'角色甲',avatar:'character-a.png',data:{name:'角色甲'}}], name2:'角色甲',name1:'用户乙',chat:[],chatId:bank.chatId,
  getCurrentChatId:()=>bank.chatId,chatMetadata:{[constants.MEMORY_KEY]:bank},extensionSettings:{},saveMetadataDebounced:async()=>{}};
globalThis.SillyTavern = {getContext:()=>host};
globalThis.location = {href:'https://example.test/',origin:'https://example.test'};
const clone = value => structuredClone(value);

function snapshot({finished=true, status='drawn', nextDue=5, dueFloor=4, module='pastLives'}={}) {
  let modulePlan = modulePlans.buildModulePlan(module,{drawId:'draw_test_0001',chatId:bank.chatId,archiveRevision:bank.archiveRevision,sourceMemoryIds:['M001'],frozenAt:1});
  if(finished) modulePlan.steps = modulePlan.steps.map(s=>({...s,status:'completed',recoverySlot:'saved-body'}));
  return plans.parseAutoMemorySnapshot({plan:plans.createAutoMemoryPlan({enabled:true,intervalFloors:1,lastCompletedFloor:dueFloor,nextDueFloor:nextDue,activeDrawTicketId:'draw_test_0001'}),
    drawTickets:[{id:'draw_test_0001',dueFloor,archiveRevision:bank.archiveRevision,candidates:[{id:module,weight:100}],selectedModuleId:module,sourceMemoryIds:['M001'],status}],modulePlan,revealRecords:[]});
}
function runnerIo(extra={}) {return {now:100,module:{contentKind:'historical'},persist:async()=>{},execute:async()=>({saved:true}),...extra};}
test('completed body + open draw ticket: settle without new body requests; repeated wake is idle', async()=>{
  let s=snapshot(), executed=0, prepared=0;
  const io={persist:async n=>{s=n;},prepareModulePlan:async()=>{prepared++;throw Error('must not regenerate');},resumeModule:n=>runner.runPending(n,runnerIo({persist:async n=>{s=n;},execute:async()=>{executed++;}}))};
  const result=await gate.runAutoMemoryRound({snapshot:s,floor:4},io);
  assert.equal(result.action,'settled');assert.equal(executed,0);assert.equal(prepared,0);
  assert.equal(s.plan.activeDrawTicketId,null);assert.equal(s.revealRecords.length,1);
  const repeated=await gate.runAutoMemoryRound({snapshot:s,floor:4,seenFloor:4},io);
  assert.equal(repeated.moduleRequest,false);assert.equal(s.revealRecords.length,1);
});
test('settlement failure can be retried without rerunning completed body',async()=>{
  const s=snapshot();let executed=0, writes=0;
  const io={resumeModule:n=>runner.runPending(n,runnerIo({execute:async()=>{executed++;},persist:async()=>{writes++;if(writes===1)throw Error('storage interruption');}}))};
  await assert.rejects(gate.runAutoMemoryRound({snapshot:s,floor:4},io),/storage interruption/);
  assert.equal((await gate.runAutoMemoryRound({snapshot:s,floor:4},io)).action,'settled');assert.equal(executed,0);
});
test('failed pending step on same floor remains resumable; saved steps never execute',async()=>{
  const s=snapshot({finished:false});s.modulePlan=modulePlans.buildModulePlan('pastLives',{...s.modulePlan,dossiers:0});
  s.modulePlan.steps[0]={...s.modulePlan.steps[0],status:'completed',recoverySlot:'saved-prologue'};s.modulePlan.steps[1].status='failed';let executed=0;
  const result=await gate.runAutoMemoryRound({snapshot:s,floor:4},{resumeModule:n=>runner.runPending(n,runnerIo({execute:async({step})=>{assert.equal(step.id,'echo');executed++;return{saved:true};}}))});
  assert.equal(result.action,'hold');assert.equal(executed,1);
});
async function fourFloors(single=false) {
  let s={plan:plans.createAutoMemoryPlan({enabled:true,intervalFloors:1,lastCompletedFloor:0,nextDueFloor:1}),drawTickets:[],revealRecords:[],modulePlan:null};
  let memoryIds=[], requests=0, sequence=0;const picked=[];
  for(let floor=1;floor<=4;floor++){
    const before=[...memoryIds];
    const run=n=>runner.runPending(n,runnerIo({persist:async n=>{s=n;},execute:async()=>{requests++;return{saved:true};}}));
    const io={random:()=>0,nextId:()=>`draw_next_${++sequence}`,prepareModulePlan:async args=>{picked.push(args.moduleId);return modulePlans.buildModulePlan(args.moduleId,args);},
      importIncremental:async()=>{memoryIds.push(`M00${floor}`);return{status:'saved'};},readMemoryIds:async()=>memoryIds,persist:async n=>{s=n;},startModule:run,resumeModule:run};
    const modules=registry.listAutoMemoryModules().filter(m=>(single?['pastLives']:['pastLives','themeSong']).includes(m.id));
    const input={snapshot:s,floor,memoryIds:before,chatId:bank.chatId,archiveRevision:bank.archiveRevision,modules,now:100+floor};
    assert.equal((await gate.runAutoMemoryRound(input,io)).action,'drawn');
    for(let n=0;n<3;n++)assert.equal((await gate.runAutoMemoryRound({...input,snapshot:s},io)).moduleRequest,false);
  }
  assert.equal(requests,4);assert.equal(s.drawTickets.length,4);assert.equal(s.revealRecords.length,4);return picked;
}
test('every 1 floor, 4 floors with repeated wakeups -> exactly 4 bodies and no adjacent repeat in multi-candidate pool',async()=>{
  const picked=await fourFloors();for(let i=1;i<picked.length;i++)assert.notEqual(picked[i],picked[i-1]);
  assert.equal(picked.filter(x=>x==='pastLives').length,2);
});
test('only one eligible module continues generating each floor (no added block)',async()=>assert.deepEqual(await fourFloors(true),Array(4).fill('pastLives')));
test('completed ticket on next due floor does not consume or block the new draw',async()=>{
  const s=snapshot();assert.equal(gate.floorDecision({enabled:true,floor:5,interval:1,nextDueFloor:5,modulePlan:s.modulePlan,activeTicket:s.drawTickets[0]}).action,'due');
  let generated=0;
  const result=await gate.runAutoMemoryRound({snapshot:s,floor:5,memoryIds:['M001'],chatId:bank.chatId,archiveRevision:bank.archiveRevision,modules:registry.listAutoMemoryModules().filter(m=>m.id==='themeSong'),now:10},
    {importIncremental:async()=>({status:'saved'}),readMemoryIds:async()=>['M001','M002'],random:()=>0,nextId:()=> 'draw_next_floor',prepareModulePlan:async args=>modulePlans.buildModulePlan(args.moduleId,args),persist:async()=>{},startModule:async()=>{generated++;}});
  assert.equal(result.action,'drawn');assert.equal(generated,1);
});

let records, failWrite, requestCount;
function recoverySetup(){draft.resetArchiveRecoveryMemoryForTests();records=new Map();failWrite=false;requestCount=0;
  store.setLocalRecoveryBackendForTests({read:async key=>clone(records.get(key)||null),compare:async(key,expected,payload)=>{
    if(failWrite)throw Object.assign(Error('simulated storage failure'),{code:'RMT_LOCAL_STORAGE'});
    assert.equal(records.get(key)?.revision||0,expected,'CAS revision must match');records.set(key,{key,revision:expected+1,payload:clone(payload)});return expected+1;
  }});
  return context.captureTaskOrigin(host,bank.archiveRevision);
}
async function begin(origin,sourceIdentity='batch-1',extra={}){return draft.beginArchiveRecovery({origin,sourceIdentity,settingsIdentity:'settings-test',...extra});}
async function segment(ticket){return recovery.withRecoverySegment('test prompt',{origin:ticket.origin,taskKey:'external:0'},value=>value,async(prompt,options,accept)=>{requestCount++;const raw={memories:[{id:'M001',title:'fixture'}]};await accept(raw);return raw;});}
test('batch progress preserves page-only flag and displays a working save-only entry',async()=>{
  const origin=recoverySetup();failWrite=true;await assert.rejects(begin(origin));
  bank.archiveImportProgress={version:1,nextBatch:1,batches:[[{refs:[{length:10}]}],[{refs:[{length:20}]}]]};
  const summary=draftView.getCurrentArchiveImportRecoverySummary(host);
  assert.equal(summary.pageOnly,true);assert.equal(summary.completed,0);assert.match(summary.notice,/尚未确认保存/);
  const html=recoveryView.archiveRecoveryHtml(summary);assert.match(html,/data-rmt-archive-save-draft="import"/);assert.match(html,/先点「保存本页草稿（不生成）」/);
  failWrite=false;const saved=await draftView.saveCurrentArchiveRecovery(host);assert.equal(saved.pageOnly,false);assert.equal(requestCount,0);
  delete bank.archiveImportProgress;
});
test('successful paid segment survives storage failure; explicit save makes it durable with zero additional model calls',async()=>{
  const origin=recoverySetup(), ticket=await begin(origin);
  let call=0;store.setLocalRecoveryBackendForTests({read:async key=>clone(records.get(key)||null),compare:async(key,expected,payload)=>{
    call++;if(payload?.rows.some(([,e])=>e.journal.segments.some(s=>s.state==='complete')))throw Object.assign(Error('disk full'),{code:'RMT_LOCAL_STORAGE'});
    records.set(key,{key,revision:expected+1,payload:clone(payload)});return expected+1;
  }});
  await assert.rejects(segment(ticket));assert.equal(requestCount,1);
  const summary=draft.archiveRecoverySummary(origin);assert.equal(summary.pageOnly,true);assert.equal(summary.completed,1);assert.equal(summary.savedCompleted,0);
  store.setLocalRecoveryBackendForTests({read:async key=>clone(records.get(key)||null),compare:async(key,expected,payload)=>{assert.equal(records.get(key)?.revision||0,expected);records.set(key,{key,revision:expected+1,payload:clone(payload)});return expected+1;}});
  await draft.flushArchiveRecovery(origin);assert.equal(draft.archiveRecoverySummary(origin).savedCompleted,1);assert.equal(requestCount,1);
  draft.releaseArchiveRecovery(ticket);await draft.flushArchiveRecovery(origin);
  draft.resetArchiveRecoveryMemoryForTests();await draft.hydrateArchiveRecovery(origin);assert.equal(draft.archiveRecoverySummary(origin).completed,1);
});
test('new batch reusing storage slot never counts previous batch successes as current saved successes',async()=>{
  const origin=recoverySetup(), ticket=await begin(origin);await segment(ticket);await draft.retainCompletedArchiveImport(ticket,bank);
  draft.releaseArchiveRecovery(ticket);await draft.flushArchiveRecovery(origin);failWrite=true;
  await assert.rejects(begin(origin,'batch-2',{nextIndependentBatch:true}));
  const summary=draft.archiveRecoverySummary(origin);assert.equal(summary.completed,0);assert.equal(summary.savedCompleted,0);
  assert.match(summary.notice,/之前已保存的档案与旧草稿仍保留/);
  assert.equal([...records.values()][0].payload.rows[0][1].journal.segments.filter(x=>x.state==='complete').length,1);
  failWrite=false;await draft.flushArchiveRecovery(origin);assert.equal(requestCount,1);
});
test('manual save waits for a failed in-flight write, then performs its own save retry',async()=>{
  const origin=recoverySetup();let rejectFirst, entered;
  const entry=new Promise(resolve=>{entered=resolve;});let calls=0;
  store.setLocalRecoveryBackendForTests({read:async()=>null,compare:async(key,expected,payload)=>{calls++;if(calls===1){entered();return new Promise((resolve,reject)=>{rejectFirst=reject;});}records.set(key,{revision:expected+1,payload:clone(payload)});return expected+1;}});
  const first=begin(origin).catch(error=>error);await entry;const retry=draft.flushArchiveRecovery(origin);rejectFirst(Error('first failed'));
  await first;assert.equal(await retry,true);assert.equal(calls,2);assert.equal(draft.archiveRecoverySummary(origin).pageOnly,false);
});
test('storage CAS conflicts still preserve page data and do not overwrite external data',async()=>{
  const origin=recoverySetup();const ticket=await begin(origin);await segment(ticket);draft.releaseArchiveRecovery(ticket);await draft.flushArchiveRecovery(origin);
  const before=clone([...records.values()][0]);store.setLocalRecoveryBackendForTests({read:async()=>before,compare:async()=>{throw Object.assign(Error('conflict'),{code:'RMT_LOCAL_CAS'});}});
  await assert.rejects(draft.flushArchiveRecovery(origin));assert.equal(draft.archiveRecoverySummary(origin).completed,1);assert.deepEqual([...records.values()][0],before);assert.equal(requestCount,1);
});
test('finished result or parked old draft with failed storage still exposes save-only action',async()=>{
  const origin=recoverySetup(),ticket=await begin(origin);await segment(ticket);failWrite=true;
  await assert.rejects(draft.retainCompletedArchiveImport(ticket,bank));
  let summary=draft.archiveRecoverySummary(origin,'import',{includeArchived:true});assert.equal(summary.onlyArchivedDrafts,true);assert.match(recoveryView.archiveRecoveryHtml(summary),/data-rmt-archive-save-draft/);
  draft.releaseArchiveRecovery(ticket);await assert.rejects(draft.flushArchiveRecovery(origin));
  draft.parkArchiveRecovery(origin);await assert.rejects(draft.flushArchiveRecovery(origin));
  summary=draft.archiveRecoverySummary(origin,'import',{includeArchived:true});assert.equal(summary.pageOnly,true);assert.match(recoveryView.archiveRecoveryHtml(summary),/data-rmt-archive-save-draft/);
  failWrite=false;await draft.flushArchiveRecovery(origin);assert.equal(draft.archiveRecoverySummary(origin,'import',{includeArchived:true}).pageOnly,false);assert.equal(requestCount,1);
});

export function songSession(){return{...songs.emptyThemeSongs(bank),selectedId:'SONG_test',songs:[{id:'SONG_test',language:'zh',voice:'char',subject:'character',fiction:true,createdAt:1,title:'霓虹逆光',singer:'角色甲',vocalDescription:'温暖的低音',styleDescription:'电影感电子流行，霓虹都市与破晓的张力',stylePrompt:'cinematic synth pop',lyrics:'[Verse 1]\n你站在风里\n[Chorus]\n破晓时仍握住光\n[End]',sourceMemoryIds:[],sourceMemoryAnchor:'',subjectTitle:'角色甲的印象曲'}]};}
function cover(session){return targets.expandedCgItem(session,targets.describeExpandedCgTarget(session,{kind:'song-cover',containerId:'SONG_test'}))?.item;}
function makePatch(session,url='/user/images/test/cover.png'){const item=cover(session);assert.ok(item,'cover target must exist');return{version:1,mode:'themeSong',itemId:item.id,expectedSignature:patch.cgItemSignature(item),image:{url,prompt:'cinematic album cover, fashion editorial',provider:'baibai-image',generatedAt:1}};}
test('legacy songs remain readable, with optional cover absent and no data mutation on opening',()=>{
  const session=songSession(),before=JSON.stringify(session);assert.deepEqual(songs.normalizeStoredThemeSongs(session,bank),session);assert.ok(cover(session));assert.equal(JSON.stringify(session),before);
  const html=expanded.expandedCgHtml(session,{kind:'song-cover',containerId:'SONG_test'},false);assert.match(html,/设置画面并预览生图/);
});
test('cover apply/reopen/redraw/history touches only the selected cover, preserving lyrics and neighboring songs',()=>{
  let session=songSession();session.songs.push({...clone(session.songs[0]),id:'SONG_other',title:'另一首'});const old=clone(session);
  const first=patch.applyCgImagePatch(session,makePatch(session));assert.equal(first.status,'applied');session=songs.normalizeStoredThemeSongs(first.session,bank);
  assert.equal(cover(session).cgImage.url,'/user/images/test/cover.png');assert.equal(session.songs[0].lyrics,old.songs[0].lyrics);assert.deepEqual(session.songs[1],old.songs[1]);assert.deepEqual(old,songSessionWithOther());
  const second=patch.applyCgImagePatch(session,makePatch(session,'/user/images/test/cover2.png'));assert.equal(second.status,'applied');session=songs.normalizeStoredThemeSongs(second.session,bank);
  assert.equal(cover(session).cgImageHistory.length,1);assert.equal(cover(session).cgImageHistory[0].url,'/user/images/test/cover.png');
  const item=cover(session);assert.ok(patch.swapCgImageToVersion(item,'/user/images/test/cover.png'));assert.equal(cover(session).cgImage.url,'/user/images/test/cover.png');
});
function songSessionWithOther(){const s=songSession();s.songs.push({...clone(s.songs[0]),id:'SONG_other',title:'另一首'});return s;}
test('late cover cannot overwrite changed lyrics, another song, or another mode',()=>{
  const s=songSession(),p=makePatch(s);s.songs[0].lyrics='[Verse 1]\n风改变方向\n[Chorus]\n晨光\n[End]';assert.equal(patch.applyCgImagePatch(s,p).status,'conflict');
  const other=songSession();other.songs[0].id='SONG_new';assert.equal(patch.applyCgImagePatch(other,p).status,'conflict');assert.equal(patch.applyCgImagePatch({...s,kind:'album'},p).status,'invalid');
});
test('newer redraw is preserved when an older image completion arrives late',()=>{
  const s=songSession(),old=makePatch(s),newer=makePatch(s,'/user/images/test/new.png');const saved=patch.applyCgImagePatch(s,newer).session;
  assert.equal(patch.applyCgImagePatch(saved,old).status,'conflict');assert.equal(cover(saved).cgImage.url,'/user/images/test/new.png');
});
test('cover sidecar rejects remote / embedded / script / traversal paths using existing saved-image contract',()=>{
  const s=songSession();for(const url of ['https://evil.test/x.png','data:image/png;base64,AAAA','javascript:alert(1)','//evil.test/x.png','/user/images/../secret.png','/user/images/%2e%2e/secret.png'])assert.equal(patch.applyCgImagePatch(s,makePatch(s,url)).status,'invalid',url);
  s.songs[0].visual={sourceHash:'anything',cgImage:{url:'https://evil.test/x.png'}};assert.equal(songs.normalizeStoredThemeSongs(s).songs[0].visual,undefined);
});
test('concurrent new song commit keeps latest stored cover and still rejects text conflicts',()=>{
  const incoming=songSessionWithOther();const current=patch.applyCgImagePatch(songSession(),makePatch(songSession())).session;
  const merged=songs.mergeThemeSongs(current,incoming);assert.equal(merged.songs.length,2);assert.equal(cover(merged).cgImage.url,'/user/images/test/cover.png');
  incoming.songs[0].title='conflicting title';assert.throws(()=>songs.mergeThemeSongs(current,incoming),/更新/);
});
test('initial and reconceived album art prompts are cinematic fashion covers, not old generic 16:9 scene instructions',()=>{
  const s=songSession(),item=cover(s);const initial=cg.cgImagePromptForItem(item);assert.match(initial,/电影大片/);assert.match(initial,/时尚/);assert.match(initial,/专辑封面/);assert.doesNotMatch(initial,/16:9/);assert.equal(item.cgOrientation,'portrait');
  for(const format of ['','nai45-tags','nai5-natural']){const prompt=cg.buildCgReconceptPrompt(item,host,'themeSong',null,format);assert.match(prompt,/UNTRUSTED_SONG_COVER_JSON/);assert.match(prompt,/霓虹逆光/);assert.match(prompt,/破晓时仍握住光/);assert.doesNotMatch(prompt,/16:9横向乙女|不要只画人物肖像|保持原镜头|衣着、姿态、动作和表情只取当前事件/);}
  assert.equal(item.cgPortrait,true);s.songs[0].voice='duet';assert.equal(cover(s).cgPortrait,false);
});
test('read-only cover view displays saved art without edit buttons',()=>{
  const s=patch.applyCgImagePatch(songSession(),makePatch(songSession())).session;
  const html=expanded.expandedCgHtml(s,{kind:'song-cover',containerId:'SONG_test'},true);assert.match(html,/查看大图/);assert.doesNotMatch(html,/编辑画面|预览生图|夹进手帐/);
});
test('album concept preserves participant identities and existing appearance contract in both text formats',()=>{
  const appearance={castSnapshot:{people:[{id:'person_a',name:'同名'},{id:'person_b',name:'同名'}]},characters:[{participantId:'person_a',description:'红发',knownTag:'red hair',knownNl:'红发'},{participantId:'person_b',description:'黑发',knownTag:'black hair'}]};
  for(const format of ['nai45-tags','nai5-natural']){
    const prompt=cg.buildCgReconceptPrompt(cover(songSession()),host,'themeSong',appearance,format);assert.match(prompt,/person_a/);assert.match(prompt,/person_b/);assert.match(prompt,/red hair/);assert.match(prompt,/black hair/);assert.doesNotMatch(prompt,/undefined|NaN/);assert.match(prompt,/布景.*可以使用/s);
  }
});
test('manual album prompt remains editable and sendable with empty appearance; no new formatting gate',async()=>{
  const actions=await mod('generation/cgImageActions'), item=cover(songSession());
  for(const format of ['nai45-tags','nai5-natural']){
    const preview=actions.cgEditorSendPreview('themeSong',item,'时尚专辑封面，银色灯光与深蓝丝绸',null,format);
    assert.match(preview.prompt,/时尚专辑封面/);
  }
});
test('cover capture uses existing chat/revision identity and becomes stale on changed song content',async()=>{
  const {state}=await mod('core/state');const session=songSession();state.activeMode='themeSong';state.activeSession=session;bank.memories=[{id:'M001',title:'相遇',content:'测试回忆'}];
  const target=cg.captureCgImageTarget({mode:'themeSong',session,item:cover(session)});assert.ok(target);assert.equal(cg.isCgImageTargetCurrent(target),true);
  session.songs[0].lyrics='[Verse 1]\n新的词\n[Chorus]\n新的歌\n[End]';assert.equal(cg.isCgImageTargetCurrent(target),false);state.activeSession=null;state.activeMode='';bank.memories=[];
});
