import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const root = path.resolve(process.env.TEST_ROOT || '.');
const moduleAt = file => import(pathToFileURL(path.join(root, 'src', file)).href);
// Enter through the production entry to preserve its required initialization order.
await moduleAt('heartbeatMemories.js');
const contract = await moduleAt('core/themeSongContract.js');
const mv = await moduleAt('extras/mv.js');
const view = await moduleAt('ui/themeSongView.js');
const songMode = await moduleAt('modes/themeSong.js');
const compound = '[Verse 1 - Male Vocal]\n雪落在掌心\n[Chorus - Duet]\n让光靠近你\n[End]';
const cues = '[Verse 1]\n[Male Vocal]\n雪落在掌心\n[Female Vocal]\n我看见微光\n[Chorus]\n[Duet]\n让光靠近你\n[End]';
const plain = '[Verse 1]\n雪落在掌心\n我看见微光\n[Chorus]\n让光靠近你\n[End]';
const song = lyrics => ({ id: 'SONG_vocals', title: '微光', bpm: 88, lyricTagVersion: 2, lyrics });
const record = () => ({ version: 2, duration: 80, settings: { output: 'tegaki', range: 'full' },
    tegaki: { range: 'full' }, shots: [
        { id: 'S1', sectionIndex: 0, lyric: '雪落在掌心' },
        { id: 'S2', sectionIndex: 0, lyric: '我看见微光' },
        { id: 'S3', sectionIndex: 1, lyric: '让光靠近你' }],
    timing: { lineTaps: { '0:0': 10.5, '0:1': 20.5, '1:0': 40.5 } } });

test('complete lyrics accept compound section labels without rewriting them', () => {
    assert.equal(contract.assertCompleteLyrics(compound), compound);
});

test('standalone vocal cues can follow a section and change voice inside it', () => {
    assert.equal(contract.assertCompleteLyrics(cues), cues);
    assert.equal(contract.assertCompleteLyrics(cues.replace('[Male Vocal]', '[Vocal A]').replace('[Female Vocal]', '[Vocal B]')), cues.replace('[Male Vocal]', '[Vocal A]').replace('[Female Vocal]', '[Vocal B]'));
});

test('vocal cues never satisfy an empty verse or chorus and End remains required', () => {
    const bad = [
        '[Verse 1]\n[Male Vocal]\n[Chorus]\nhook\n[End]',
        '[Verse 1]\nline\n[Chorus]\n[Duet]\n[End]',
        '[Verse 1 - Male Vocal]\n[Chorus - Duet]\nhook\n[End]',
        '[Verse 1]\nline\n[End]\n[Chorus]\nhook\n[End]',
        plain.replace('[End]', ''), plain.replace('让光靠近你', '副歌同上')
    ];
    for (const lyrics of bad) assert.throws(() => contract.assertCompleteLyrics(lyrics), error => error.code === 'RMT_SONG_LYRICS');
});

test('reading keeps section headings and voice cues in their original order without empty stanzas', () => {
    const html = view.songLyricsReadingHtml(cues);
    assert.equal((html.match(/class="rmt-song-stanza"/g) || []).length, 2);
    for (const marker of ['主歌 1', '副歌', 'Male Vocal', 'Female Vocal', 'Duet', '雪落在掌心']) assert.ok(html.includes(marker), marker);
    assert.ok(html.indexOf('Male Vocal') < html.indexOf('雪落在掌心'));
    assert.ok(html.indexOf('Female Vocal') < html.indexOf('我看见微光'));
    const unsafe = view.songLyricsReadingHtml('[Verse 1 - <img src=x onerror=alert(1)>]\nline\n[Chorus]\nhook\n[End]');
    assert.ok(!unsafe.includes('<img')); assert.ok(unsafe.includes('&lt;img'));
});

test('new tagged songs have only musical sections and real lyric lines for MV', () => {
    const sections = mv.parseSongSections(song(cues));
    assert.deepEqual(sections.map(s => [s.tag, s.name, s.lines]), [
        ['Verse 1', '主歌 1', ['雪落在掌心', '我看见微光']],
        ['Chorus', '副歌', ['让光靠近你']]
    ]);
    assert.deepEqual(mv.parseSongSections(song(compound)).map(s => [s.tag, s.name]), [['Verse 1', '主歌 1'], ['Chorus', '副歌']]);
});

test('vocal changes do not become subtitle lines or alter new song tap keys', () => {
    const saved = record(), before = JSON.stringify(saved);
    assert.deepEqual(mv.syncLines(saved, song(cues)), mv.syncLines(saved, song(plain)));
    assert.deepEqual(mv.shotTimeline(saved, song(cues)).rows.map(r => r.start), [10.5, 20.5, 40.5]);
    const subtitles = mv.srtText(saved, song(cues));
    assert.doesNotMatch(subtitles, /Male Vocal|Female Vocal|Duet/);
    assert.match(subtitles, /00:00:10,500/);
    assert.equal(JSON.stringify(saved), before);
});

test('unversioned songs keep legacy sections, saved tap keys and data unchanged', () => {
    const lyrics = '[Male Vocal]\n[Verse 1]\n雪落在掌心\n[Duet]\n[Chorus]\n让光靠近你\n[End]';
    const old = { id: 'SONG_old', bpm: 88, lyrics }, beforeSong = JSON.stringify(old);
    const saved = { ...record(), shots: [
        { id: 'S1', sectionIndex: 1, lyric: '雪落在掌心' },
        { id: 'S2', sectionIndex: 3, lyric: '让光靠近你' }], timing: { lineTaps: { '1:0': 25.5, '3:0': 55.5 } } };
    const before = JSON.stringify(saved);
    const parse = mv.parseSongSections || (value => mv.parseSections(value.lyrics));
    assert.deepEqual(parse(old), mv.parseSections(lyrics));
    assert.deepEqual(mv.syncLines(saved, old).map(row => row.key), ['1:0', '3:0']);
    assert.deepEqual(mv.shotTimeline(saved, old).rows.map(row => row.start), [25.5, 55.5]);
    assert.equal(JSON.stringify(saved), before); assert.equal(JSON.stringify(old), beforeSong);
});

test('instrumental and unknown headings preserve musical segment boundaries', () => {
    const lyrics = '[Intro]\n[Verse 1]\n[Male Vocal]\nline\n[Interlude]\n[Custom scene]\nscene line\n[Chorus]\n[Duet]\nhook\n[Outro]\n[End]';
    const sections = mv.parseSongSections(song(lyrics));
    assert.deepEqual(sections.map(s => s.tag), ['Intro', 'Verse 1', 'Interlude', 'Custom scene', 'Chorus', 'Outro']);
    assert.deepEqual(sections.map(s => s.lines.length), [0, 1, 0, 1, 1, 0]);
});

test('copy and export preserve generated lyrics and English style verbatim', () => {
    const value = { ...song(cues), stylePrompt: 'Mandarin duet, bright tenor, cool alto, 88 BPM', vocalDescription: '角色甲与角色乙轮唱' };
    assert.equal(contract.themeSongExport(value, 'lyrics'), cues);
    assert.equal(contract.themeSongExport(value, 'style'), value.stylePrompt);
    assert.ok(!contract.themeSongExport(value, 'style').includes(value.vocalDescription));
});

test('vocal tag detection only selects new cue-bearing outputs for versioned parsing', () => {
    assert.equal(contract.hasSongVocalCues(cues), true);
    assert.equal(contract.hasSongVocalCues(compound), true);
    assert.equal(contract.hasSongVocalCues(plain), false);
    assert.equal(contract.hasSongVocalCues('[Intro]\n[Custom scene]\nline\n[End]'), false);
});

test('only local new-song normalization enables vocal parsing and storage preserves it', () => {
    const bank = { version: 3, archiveRevision: 'r1', chatId: 'A', characterName: '角色甲', userName: '角色乙', memories: [] };
    const plan = songMode.createThemeSongPlan({ voice: 'duet' }, bank);
    const raw = { title: '微光', stylePrompt: 'Mandarin duet, 88 BPM', styleDescription: '疏朗流行', vocalDescription: '两人轮唱', lyrics: cues, lyricTagVersion: 999 };
    const generated = songMode.normalizeGeneratedSong(raw, plan, bank);
    assert.equal(generated.lyricTagVersion, 2);
    const regular = songMode.normalizeGeneratedSong({ ...raw, lyrics: plain, lyricTagVersion: 2 }, plan, bank);
    assert.equal(Object.hasOwn(regular, 'lyricTagVersion'), false);
    const session = { ...contract.emptyThemeSongs(bank), songs: [generated], selectedId: generated.id };
    assert.equal(contract.normalizeStoredThemeSongs(session, bank).songs[0].lyricTagVersion, 2);
    const old = { ...generated }; delete old.lyricTagVersion;
    const oldSession = { ...session, songs: [old] }, before = JSON.stringify(oldSession);
    assert.equal(Object.hasOwn(contract.normalizeStoredThemeSongs(oldSession, bank).songs[0], 'lyricTagVersion'), false);
    assert.equal(JSON.stringify(oldSession), before);
});
