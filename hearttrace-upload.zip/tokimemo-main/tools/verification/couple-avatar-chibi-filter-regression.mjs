import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { fixture } from './fixture.mjs';

const root = process.env.TEST_ROOT || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const F = await import('data:text/javascript;base64,' + Buffer.from(await fs.readFile(path.join(root, 'src/extras/coupleAvatarChibiFilter.js'), 'utf8')).toString('base64'));

const longMale = 'An 18-year-old male with a height of 183 cm. He has exquisite, delicate facial features and a well-defined bone structure, carrying a blend of youthful boyish charm and refined good looks. He has bright, clear eyebrows, large sparkling eyes. His black hair is styled in a messy high ponytail secured with a handwoven black cord. He wears clothing in a black and red color scheme accented with gold decorative accessories. Around his wrists are braided cord bracelets, and he wears a longevity lock amulet close to his chest.';
const longFemale = "1girl, 18 years old, 166 cm tall, with a slender, delicate build, narrow shoulders, a slim waist, an elegant neck, and prominent deep collarbones. She has extremely fair cold white, poreless, translucent skin with faint blue veins. Her face is a classic oval shape with a smooth jawline, a full forehead, and a high, neatly shaped hairline. She has long straight black hair. Located below the corner of her right eye is a cinnabar-red tear mole. A white gauze blindfold covers her eyes. She has a high-rooted nose with narrow nostrils, as well as sharply contoured lips with a defined cupid's bow.";

test('realistic body detail goes; identity (hair, eyes, marks, covering, accessories, gender) stays', () => {
    const male = F.chibiFilterAppearance(longMale);
    for (const kept of ['male', 'black hair', 'high ponytail', 'eyebrows', 'black and red color scheme', 'bracelets', 'longevity lock amulet']) assert.ok(male.text.includes(kept), kept);
    assert.doesNotMatch(male.text, /183|18-year|bone structure|boyish charm/);
    const female = F.chibiFilterAppearance(longFemale);
    for (const kept of ['1girl', 'fair cold white skin', 'long straight black hair', 'tear mole', 'white gauze blindfold']) assert.ok(female.text.includes(kept), kept);
    assert.doesNotMatch(female.text, /166|18 years|slender|waist|collarbones|poreless|veins|jawline|hairline|nose|nostrils|lips|cupid/);
});

test('tag lists and Chinese personas are filtered clause by clause', () => {
    assert.equal(F.chibiFilterAppearance('1boy, tall, muscular, broad shoulders, black hair, red eyes, scar on cheek, mature male, abs').text,
        '1boy, black hair, red eyes, scar on cheek, male');
    assert.equal(F.chibiFilterAppearance('男，25岁，身高183，身材修长，宽肩窄腰，黑色长发，高马尾，金色眼睛，左眼下有泪痣，下颌线清晰，鼻梁高挺，常穿黑色长衫').text,
        '男，黑色长发，高马尾，金色眼睛，左眼下有泪痣，常穿黑色长衫');
    const short = '1girl, short silver hair, blue eyes';
    assert.deepEqual(JSON.parse(JSON.stringify(F.chibiFilterAppearance(short))), { text: short, removed: [] });
    assert.equal(F.chibiFilterPeople([{ appearance: short }, { appearance: '' }]).changed, false, 'nothing to filter → no dialog');
    assert.equal(F.chibiFilterPeople([{ appearance: longMale }, { appearance: short }]).changed, true);
});

test('the mode is stored only when chosen; ask is the default', async () => {
    const f = await fixture(), core = f.get('extras/coupleAvatar');
    assert.equal(Object.hasOwn(core.normalizeCoupleSettings({}, null), 'chibiFilter'), false);
    assert.equal(core.normalizeCoupleSettings({ chibiFilter: 'auto' }, null).chibiFilter, 'auto');
    assert.equal(core.normalizeCoupleSettings({ chibiFilter: 'off' }, null).chibiFilter, 'off');
    assert.equal(Object.hasOwn(core.normalizeCoupleSettings({ chibiFilter: 'whatever' }, null), 'chibiFilter'), false);
    assert.equal(F.chibiFilterMode(undefined), 'ask');
    assert.deepEqual([...F.CHIBI_FILTER_GROUPS], ['chibi', 'animal']);
});
