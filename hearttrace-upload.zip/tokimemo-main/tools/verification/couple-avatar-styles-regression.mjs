import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { fixture } from './fixture.mjs';

// NAI now receives identities in its documented character channels. Assert the
// complete public request, not an obsolete assumption that all text is global.
const sentText = request => [request.prompt, request.nl, ...(request.characters || []).flatMap(row => [row.name, row.tag, row.nl])].filter(Boolean).join('\n');

async function setup(provider, supportsCharacters = true) {
    const f = await fixture(), requests = [], source = new EventEmitter();
    f.sb.location = { href: 'tauri://localhost/', origin: 'null', protocol: 'tauri:' };
    f.host.chatMetadata = {};
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS, imageGenerationProvider: provider, imageGenerationFallback: false });
    f.sb.STBaiBaiImage = { apiVersion: 1, capabilities: { generate: true, saveToGallery: true },
        getBackendStatus: () => ({ configured: true, backend: 'nai', supportsCharacters }),
        generate: async request => { requests.push(request); return { path: '/user/images/style.png' }; } };
    f.host.eventSource = source;
    f.host.extensionSettings['st-chatu8'] = { scriptEnabled: true, mode: 'comfyui' };
    source.on('generate-image-request', request => {
        requests.push(request);
        source.emit('generate-image-response', { id: request.id, success: true, imageData: '/user/images/style.png' });
    });
    return { ...f, requests, core: f.get('extras/coupleAvatar'), styles: f.get('extras/coupleAvatarStyles') };
}

test('72 unique styles keep every legacy identifier; 48 concrete interactions stay optional', async () => {
    const f = await setup('baibai-image'), s = f.styles;
    assert.equal(s.COUPLE_STYLES.length, 72);
    assert.equal(new Set(s.COUPLE_STYLES.map(x => x.id)).size, 72);
    assert.equal(s.INTERACTION_PRESETS.length, 48);
    for (const style of s.COUPLE_STYLES) {
        assert.ok(s.STYLE_GROUPS.some(g => g.id === style.group));
        assert.ok(style.label && style.description && style.prompt);
        assert.equal(f.core.normalizeCoupleSettings({ styleId: style.id }).styleId, style.id);
    }
    const legacy = ['chibi-dumpling','chibi-three-head','chibi-headshot','chibi-doodle','chibi-animal','chibi-meme','anime-clean','anime-cel','anime-shojo','anime-retro90','anime-korean','anime-storybook','art-gongbi','art-ink','art-watercolor','art-pencil','art-oil','art-sketch','craft-plush','craft-clay','craft-crochet','craft-felt','craft-vinyl','craft-paper','graphic-pixel','graphic-line','graphic-silhouette','graphic-print','graphic-sticker','graphic-geometric','photo-film','photo-daylight','photo-studio','photo-night','photo-backlight','photo-mono'];
    assert.ok(legacy.every(id => s.COUPLE_STYLES.some(style => style.id === id)));
    for (const row of s.INTERACTION_PRESETS) assert.ok(f.core.couplePrompt({ interaction: row.label }).includes(row.prompt));
    const empty = f.core.normalizeCoupleSettings({ interaction: '', people: [{ name: '', appearance: '' }, { name: '', appearance: '' }] });
    await f.core.generateCouple(empty, { context: f.host });
    assert.equal(f.requests.length, 1);
});

for (const provider of ['baibai-image', 'chatu8-image']) {
    test(`${provider}: animal style changes subjects, not props; original appearances stay unchanged`, async () => {
        const f = await setup(provider), input = { styleId: 'chibi-animal', interaction: '隔空对望', people: [
            { name: '青禾', appearance: '1boy, black hair, gold eyes, pale skin, red bracelet' },
            { name: '阿月', appearance: '1girl, long black hair, pink eyes, white ribbon' },
        ] }, before = JSON.stringify(input);
        const saved = await f.core.generateCouple(input, { context: f.host });
        assert.equal(f.requests.length, 1);
        const sent = sentText(f.requests[0]);
        assert.match(sent, /^(Rendering style: )?animal-only/);
        assert.match(sent, /Two complete animals/);
        if (provider === 'baibai-image') {
            assert.match(f.requests[0].characters[0].name, /左边 · 青禾/);
            assert.match(f.requests[0].characters[1].name, /右边 · 阿月/);
            assert.match(f.requests[0].characters[0].nl, /On the left/);
            assert.match(f.requests[0].characters[1].nl, /On the right/);
        } else {
            assert.match(sent, /LEFT HALF animal: 青禾/);
            assert.match(sent, /RIGHT HALF animal: 阿月/);
        }
        assert.doesNotMatch(sent, /One person centered|HALF person|\b1boy\b|\b1girl\b/);
        assert.match(sent, /red bracelet/);
        assert.equal(JSON.stringify(input), before);
        assert.equal(saved.record.settings.people[0].appearance, input.people[0].appearance);
        assert.equal(saved.record.original.url, '/user/images/style.png');
    });

    test(`${provider}: long avatar style, interaction and both identities reach the actual provider intact`, async () => {
        const f = await setup(provider), input = {
            styleId: 'craft-plush', interaction: '自定义互动', interactionDetail: '左边递出小花，右边接住，然后一起笑。',
            customStyle: '', direction: '细节丰富。'.repeat(550), background: 'BACKGROUND_END_MARKER',
            people: [{ name: 'LEFT_IDENTITY', appearance: '深色卷发。'.repeat(550) }, { name: 'RIGHT_IDENTITY', appearance: 'RIGHT_APPEARANCE_END_MARKER' }],
        };
        await f.core.generateCouple(input, { context: f.host });
        const sent = sentText(f.requests[0]);
        assert.ok(sent.length > 5000);
        for (const marker of ['soft plush dolls', 'Two crafted figures', input.interactionDetail, 'LEFT_IDENTITY', 'RIGHT_IDENTITY', 'RIGHT_APPEARANCE_END_MARKER', 'BACKGROUND_END_MARKER']) assert.ok(sent.includes(marker), marker);
        assert.equal(f.requests.length, 1);
        if (provider === 'baibai-image') {
            assert.ok(f.requests[0].characters.every(row => row.nl.includes(input.interactionDetail)));
            assert.ok(f.requests[0].nl.includes(input.direction));
        } else assert.ok(sent.includes('expressions and reactions belong to each subject'));
        assert.equal(f.get('core/diagnosticReport').buildDiagnosticReport().runtime.coupleAvatarTasks, 0);
    });

    test(`${provider}: all 72 styles can generate once each without archive or new conditions`, async () => {
        const f = await setup(provider);
        for (const style of f.styles.COUPLE_STYLES) {
            await f.core.generateCouple({ styleId: style.id }, { context: f.host });
            assert.ok(f.requests.at(-1).prompt.includes(style.prompt));
        }
        assert.equal(f.requests.length, 72);
        assert.equal((await f.core.readCouples(f.core.coupleScope(f.host))).records.length, 72);
    });
}

test('BaiBai without character channels receives the complete avatar prompt in both public fields', async () => {
    const f = await setup('baibai-image', false);
    await f.core.generateCouple({ direction: '完整描述'.repeat(1600), background: 'TAIL_MARKER' }, { context: f.host });
    assert.ok(f.requests[0].prompt.includes('TAIL_MARKER'));
    assert.equal(f.requests[0].nl, f.requests[0].prompt);
});

test('local inspiration produces three different ideas, avoids last set, and never touches providers', async () => {
    const f = await setup('baibai-image');
    let previous = [];
    for (let i = 0; i < 30; i++) {
        const ideas = f.styles.randomCoupleIdeas(previous, i % 2 ? () => .999 : () => 0);
        assert.equal(ideas.length, 3);
        assert.equal(new Set(ideas).size, 3);
        assert.ok(ideas.every(idea => !previous.includes(idea) && idea.includes('左边') && idea.includes('右边')));
        previous = ideas;
    }
    assert.equal(f.requests.length, 0);
    const settings = { styleId: 'animal-cat', interaction: '自定义互动', interactionDetail: previous[0] + ' 保留这句修改', direction: '单独的小心思' };
    await f.core.saveCoupleSettings('TEST', settings);
    const restored = (await f.core.readCouples('TEST')).settings;
    assert.equal(restored.interactionDetail, settings.interactionDetail);
    assert.equal(restored.direction, settings.direction);
    assert.ok(f.core.couplePrompt(restored).includes(settings.interactionDetail));
});

test('human styles still receive literal looks; old backups and custom interaction text are not rewritten', async () => {
    const f = await setup('baibai-image');
    const old = { styleId: 'anime-clean', interaction: '原有备份里的自由互动', people: [{ name: '青禾', appearance: '1boy, black hair, pale skin' }] };
    assert.ok(f.core.couplePrompt(old).includes(old.people[0].appearance));
    assert.ok(f.core.couplePrompt(old).includes(old.interaction));
    assert.equal(f.core.normalizeCoupleSettings(old).interactionDetail, '');
});
