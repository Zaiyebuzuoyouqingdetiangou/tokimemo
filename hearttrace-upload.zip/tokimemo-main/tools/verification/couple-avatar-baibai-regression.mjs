import { runIf } from './optional.mjs';
// 缺少条件时明确跳过并说明原因；满足时加载同名 .impl.mjs 里的原测试。
await runIf([
    {
        "env": "BAIBAI_SOURCE_ROOT",
        "kind": "dir",
        "inside": "baibai-size-current.ts",
        "why": "柏宝绘上游源码目录（baibai-size-current.ts、baibai-nai-current.ts）"
    }
],
    () => import('./couple-avatar-baibai-regression.impl.mjs'));
