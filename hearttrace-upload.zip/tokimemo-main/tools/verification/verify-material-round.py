"""1.0 material editor verification. Existing tests remain immutable, including failures."""
from pathlib import Path
import concurrent.futures
import difflib
import hashlib
import json
import os
import re
import subprocess
import sys
import time
import zipfile

root, dest = map(lambda s: Path(s).resolve(), sys.argv[1:3])
base = Path(os.environ['BASELINE_ROOT']).resolve()
legacy = Path(os.environ['LEGACY_MV_ROOT']).resolve()
v = root/'tools/verification'
dest.mkdir(parents=True, exist_ok=True)
build = '1.0.0-r84.217-mv-material-editor'
old_build = '0.99.99-r84.216-mv-restore-safe-continue'
expected_failures = {
    'revision drift journals paid result and survives a fresh runtime',
    'frame cast is the exact intersection of shot people and appearance preference',
}
allowed_source = sorted(['src/extras/mv.js', 'src/extras/mvImageTools.js', 'src/ui/mvView.js', 'src/ui/mvImageEditor.js'])
commands = []
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def run(name, argv, env=None, required=True):
    start = time.monotonic()
    p = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        env={**os.environ, **(env or {})}, timeout=55)
    (dest/(name+'.log')).write_bytes(p.stdout)
    commands.append({'name': name, 'argv': argv, 'exit_code': p.returncode, 'seconds': round(time.monotonic()-start, 3)})
    if required and p.returncode:
        raise AssertionError((name, p.returncode, p.stdout[-3000:].decode(errors='replace')))
    return p.returncode, p.stdout.decode(errors='replace')

run('build-1', ['python3', str(v/'build.py'), str(root)])
bundle_hash = sha(root/'dist/heartbeatMemories.bundle.js')
run('build-2', ['python3', str(v/'build.py'), str(root)])
assert sha(root/'dist/heartbeatMemories.bundle.js') == bundle_hash

files = sorted([*root.rglob('*.js'), *root.rglob('*.mjs')])
def syntax(p):
    r = subprocess.run(['node', '--check', str(p)], capture_output=True, timeout=15)
    return {'file': str(p.relative_to(root)), 'exit_code': r.returncode, 'stderr': r.stderr.decode()}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    checks = list(pool.map(syntax, files))
(dest/'syntax.json').write_text(json.dumps(checks, indent=2))
assert all(c['exit_code'] == 0 for c in checks)
imports = []
for p in (root/'src').rglob('*.js'):
    for rel in re.findall(r'^import\s+.*?from\s+[\'"]([^\'"]+)', p.read_text(), re.M):
        assert (p.parent/rel).resolve().is_file(), (p, rel)
        imports.append([str(p.relative_to(root)), rel])
(dest/'imports.json').write_text(json.dumps(imports, indent=2))
run('source-entry', ['node', '-e', 'import(process.argv[1]).then(m=>console.log(Object.keys(m).length))', (root/'src/heartbeatMemories.js').as_uri()])
run('runtime-bindings', ['node', '--experimental-vm-modules', str(v/'runtime-bindings.mjs'), str(root)])

env = {'TEST_ROOT': str(root), 'BASELINE_ROOT': str(legacy), 'PREVIOUS_BUILD_ROOT': os.environ['JOURNAL_BASELINE_ROOT']}
old_tests = sorted(str(v/p.name) for p in (base/'tools/verification').glob('*regression.mjs'))
new_tests = sorted(str(p) for p in v.glob('*regression.mjs'))
argv = ['node', '--experimental-vm-modules', '--test', '--test-reporter=tap']
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    before_task = pool.submit(run, 'baseline-full', [*argv, *old_tests], {**env, 'TEST_ROOT': str(base)}, False)
    after_task = pool.submit(run, 'candidate-full', [*argv, *new_tests], env, False)
    before_code, before = before_task.result()
    after_code, after = after_task.result()
def outcomes(text): return dict((name, status) for status, name in re.findall(r'^(not ok|ok) \d+ - (.+)$', text, re.M))
old_outcomes, new_outcomes = outcomes(before), outcomes(after)
assert set(old_outcomes).issubset(new_outcomes)
assert {n for n,s in new_outcomes.items() if s == 'not ok'} == expected_failures
assert expected_failures.issubset({n for n,s in old_outcomes.items() if s == 'not ok'})
assert not [n for n,s in old_outcomes.items() if s == 'ok' and new_outcomes[n] != 'ok']
assert not re.search(r'^# (?:cancelled|skipped|todo) [1-9]', after, re.M)
fixed = [n for n,s in old_outcomes.items() if s == 'not ok' and new_outcomes[n] == 'ok']
assert len(fixed) == 0, ('Existing outcomes must stay identical', len(fixed))
def failure_payloads(output):
    output = re.sub(r'\bF(\d+)_[a-z0-9]+\b', r'F\1_<generated-clock>', output)
    return {name: re.search(r'  error: ([\s\S]+?)  stack:', body).group(1)
        for name,body in re.findall(r'^not ok \d+ - (.+)\n([\s\S]+?)^  \.\.\.$', output, re.M)
        if name in expected_failures}
assert failure_payloads(before) == failure_payloads(after)
run('previous-source', ['node', '--test', '--test-reporter=tap', str(v/'previous-regression.mjs')], env)
run('previous-bundle', ['node', '--test', '--test-reporter=tap', str(v/'previous-regression.mjs')], {**env, 'TEST_BUNDLE': '1'})
run('prompt-hashes', ['node', '--experimental-vm-modules', str(v/'material-prompt-hashes.mjs'), str(base), str(root), str(dest/'prompt-hashes.json')])

baseline_hashes = {str(p.relative_to(base)): sha(p) for p in base.rglob('*') if p.is_file()}
hashes = {str(p.relative_to(root)): sha(p) for p in root.rglob('*') if p.is_file()}
changes = [{'file': k, 'before': baseline_hashes.get(k), 'after': hashes.get(k)}
    for k in sorted(set(baseline_hashes)|set(hashes)) if baseline_hashes.get(k) != hashes.get(k)]
assert [c['file'] for c in changes if c['file'].startswith('src/')] == allowed_source
assert all(k in hashes for k in baseline_hashes), 'No baseline files may disappear'
for p in (base/'tools/verification').glob('*regression.mjs'):
    assert sha(p) == sha(root/'tools/verification'/p.name), 'Old tests must not be edited: '+p.name
assert sha(base/'src/modes/themeSong.js') == sha(root/'src/modes/themeSong.js')
assert (root/'index.js').read_text().replace(build, old_build).replace("const VERSION = '1.0.0';", "const VERSION = '0.99.99';") == (base/'index.js').read_text()
old_manifest = json.loads((base/'manifest.json').read_text())
manifest = json.loads((root/'manifest.json').read_text())
assert {k:v for k,v in manifest.items() if k not in {'js','description','version'}} == {k:v for k,v in old_manifest.items() if k not in {'js','description','version'}}
assert manifest['version'] == '1.0.0'
assert manifest['js'] == 'index.js?heartbeat='+build
assert "const BUILD = '"+build+"';" in (root/'index.js').read_text()
(dest/'baseline-file-hashes.json').write_text(json.dumps(baseline_hashes, indent=2))
(dest/'file-hashes.json').write_text(json.dumps(hashes, indent=2))
(dest/'scope-diff.json').write_text(json.dumps(changes, ensure_ascii=False, indent=2))
(dest/'unchanged-file-hashes.json').write_text(json.dumps({k:v for k,v in baseline_hashes.items() if hashes.get(k)==v}, indent=2))
code, patch = run('full-diff', ['git', 'diff', '--no-index', '--binary', str(base), str(root)], required=False)
assert code == 1
(dest/'full-change.patch').write_text(patch)

package = dest/'checked-package.zip'
with zipfile.ZipFile(package, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(root.rglob('*')):
        if not p.is_file(): continue
        assert not p.is_symlink()
        relative = p.relative_to(root)
        assert not any(part in {'.git','.github','__pycache__'} for part in relative.parts)
        i = zipfile.ZipInfo('tokimemo-main/'+str(relative), date_time=(2026,10,2,0,0,0))
        i.compress_type = zipfile.ZIP_DEFLATED; i.external_attr=0o100644<<16
        z.writestr(i, p.read_bytes())
with zipfile.ZipFile(package) as z:
    assert z.testzip() is None
    for name in z.namelist():
        assert '..' not in Path(name).parts and name.startswith('tokimemo-main/')
        assert z.read(name) == (root/Path(name).relative_to('tokimemo-main')).read_bytes()
    package_files = len(z.namelist())
stats = lambda output: {k: int(re.search(r'^# '+k+r' (\d+)$',output,re.M).group(1)) for k in ['tests','pass','fail']}
prompts = json.loads((dest/'prompt-hashes.json').read_text())['rows']
summary = {'build': build, 'baseline': stats(before), 'candidate': stats(after),
    'fixed_historical_tests': fixed, 'new_regressions': 0,
    'retained_historical_failures': sorted(expected_failures),
    'new_workflow_tests_passed': len(set(new_outcomes)-set(old_outcomes)),
    'syntax_files': len(checks), 'resolved_imports': len(imports),
    'deterministic_build': True, 'bundle_sha256': bundle_hash,
    'prompt_functions_unchanged': sum(r['unchanged'] for r in prompts),
    'prompt_functions_changed': sum(not r['unchanged'] and not r['added'] for r in prompts),
    'new_default_prompt_wrapper': sum(r['added'] for r in prompts),
    'default_templates_changed': 0,
    'production_source_files_changed_or_restored': allowed_source,
    'unchanged_baseline_files': sum(hashes.get(k)==v for k,v in baseline_hashes.items()),
    'package': {'files': package_files, 'crc': 'pass', 'source_bytes': 'identical', 'sha256': sha(package), 'bytes': package.stat().st_size},
    'not_executed': ['real iPhone/TT', 'paid model/image/Suno calls', 'real browser DOM/CSS', 'native browser IndexedDB', 'independent agent review']}
(dest/'commands.json').write_text(json.dumps(commands, indent=2))
(dest/'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2))
print(json.dumps({k:v for k,v in summary.items() if k != 'fixed_historical_tests'},ensure_ascii=False))
