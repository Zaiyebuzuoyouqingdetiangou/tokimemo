import fs from 'node:fs';import path from 'node:path';import vm from 'node:vm';import crypto from 'node:crypto';import assert from 'node:assert/strict';
const [base,root,out]=process.argv.slice(2),sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const allowedChanges = new Set((process.env.ALLOWED_PROMPT_CHANGES || '').split(',').filter(Boolean));
async function load(dir){const code=fs.readFileSync(path.join(dir,'dist/heartbeatMemories.bundle.js'),'utf8').replace(/\n(__m_extras_mv_js\.\w+ = \w+;)/, '\n__m_extras_mv_js.__storyboardPrompt = storyboardPrompt;\n__m_extras_mv_js.__tegakiGrammar = tegakiGrammar;\n$1').replace(/\n(__m_extras_waiting_js\.\w+ = \w+;)/, '\n__m_extras_waiting_js.__waitingPrompt = waitingPrompt;\n$1'),names=[...code.matchAll(/^const (__m_\w+) = Object.create\(null\);/gm)].map(x=>x[1]);const m=new vm.SourceTextModule(code+'\nexport { '+names.join(',')+' };',{context:vm.createContext({console,queueMicrotask,TextEncoder,TextDecoder,URL,URLSearchParams,AbortController,DOMException,structuredClone,setTimeout,clearTimeout,setInterval,clearInterval,crypto:crypto.webcrypto})});await m.link(()=>{});await m.evaluate();return m.namespace;}
const [a,b]=await Promise.all([load(base),load(root)]),rows=[];
for(const mod of Object.keys(a))for(const[k,v]of Object.entries(a[mod]))if(typeof v==='function'&&!k.startsWith('__')&&/prompt/i.test(k)&&k!=='assertPromptBudget'){
 const before=v.toString(),after=b[mod][k].toString();if(!allowedChanges.has(mod+'.'+k))assert.equal(after,before,mod+'.'+k);rows.push({module:mod,function:k,baseline_sha256:sha(before),current_sha256:sha(after),unchanged:before===after});
}
function functionSource(dir,file,name){const ns=dir===base?a:b;const mod='__m_'+file.slice(4).replace(/[^a-zA-Z0-9]/g,'_');const fn=ns[mod]['__'+name]||ns[mod][name];assert.equal(typeof fn,'function',name);return fn.toString();}
for(const[file,name]of [['src/extras/waiting.js','waitingPrompt'],['src/extras/mv.js','storyboardPrompt'],['src/extras/mv.js','tegakiGrammar'],['src/extras/mv.js','rewriteShot']]){
 const before=functionSource(base,file,name),after=functionSource(root,file,name);
 assert.equal(after,before,name);
 rows.push({file,function:name,baseline_sha256:sha(before),current_sha256:sha(after),unchanged:before===after});
}
const promptBlock=dir=>{const text=functionSource(dir,'src/extras/mv.js','continueStoryboard');return text.slice(text.indexOf('        const continuity ='),text.indexOf('        const data ='));};const previousBlock=promptBlock(base),currentBlock=promptBlock(root);assert.equal(currentBlock,previousBlock,'Continuation prompt unchanged');rows.push({file:'src/extras/mv.js',function:'continueStoryboard.promptBlock',baseline_sha256:sha(previousBlock),current_sha256:sha(currentBlock),unchanged:previousBlock===currentBlock});
assert.deepEqual(rows.filter(r=>!r.unchanged).map(r=>r.module+'.'+r.function).sort(),[...allowedChanges].sort(),'Only explicitly authorized prompt functions may change');
fs.writeFileSync(out,JSON.stringify(rows,null,2)+'\n');console.log(JSON.stringify({promptFunctionsChecked:rows.length,promptFunctionsUnchanged:rows.filter(r=>r.unchanged).length,promptFunctionsChanged:rows.filter(r=>!r.unchanged&&!r.added).length,newPromptPaths:rows.filter(r=>r.added).length}));
