import fs from 'node:fs';import path from 'node:path';import vm from 'node:vm';import crypto from 'node:crypto';import assert from 'node:assert/strict';
const [base,root,out]=process.argv.slice(2);
async function load(dir){const code=fs.readFileSync(path.join(dir,'dist/heartbeatMemories.bundle.js'),'utf8'),names=[...code.matchAll(/^const (__m_\w+) = Object.create\(null\);/gm)].map(x=>x[1]);const m=new vm.SourceTextModule(code+'\nexport { '+names.join(',')+' };',{context:vm.createContext({console,queueMicrotask,TextEncoder,TextDecoder,URL,URLSearchParams,AbortController,DOMException,structuredClone,setTimeout,clearTimeout,setInterval,clearInterval,crypto:crypto.webcrypto})});await m.link(()=>{});await m.evaluate();return m.namespace;}
const [a,b]=await Promise.all([load(base),load(root)]),rows=[];const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
for(const mod of Object.keys(a))for(const[k,v]of Object.entries(a[mod]))if(typeof v==='function'&& /prompt/i.test(k)&&k!=='assertPromptBudget'){
 const before=v.toString(),after=b[mod][k].toString(),unchanged=before===after;
 if (!(mod==='__m_extras_mv_js' && k==='framePrompt')) assert.equal(after,before,mod+'.'+k);
 rows.push({module:mod,function:k,baseline_sha256:sha(before),current_sha256:sha(after),unchanged,reason:unchanged?'':'修正出镜人数与人物外貌对应关系'});}
for(const [file,start,end] of [['src/extras/waiting.js','function waitingPrompt(', '\nfunction normalizePoint('],['src/extras/mv.js','function storyboardPrompt(', '\nfunction normalizeShots(']]){
 const slice=dir=>{const s=fs.readFileSync(path.join(dir,file),'utf8');return s.slice(s.indexOf(start),s.indexOf(end));};assert.equal(slice(base),slice(root));rows.push({file,function:start.split(' ')[1].split('(')[0],sha256:sha(slice(base)),unchanged:true});}
fs.writeFileSync(out,JSON.stringify(rows,null,2)+'\n');console.log(JSON.stringify({promptFunctionsChecked:rows.length,promptFunctionsUnchanged:rows.filter(r=>r.unchanged).length,promptFunctionsChanged:rows.filter(r=>!r.unchanged).length}));
