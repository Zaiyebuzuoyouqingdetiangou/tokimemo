import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';
const song = { id: 'SONG_a', title: 'A', lyrics: '[Verse]\nline\n[Chorus]\nhook\n[End]' };
const raw = () => ({ groups: [{ id: 'G1', composition: 'room', characterPrompt: 'room', diffs: [{ id: 'D1', change: 'look' }] }], frames: [{ sectionIndex: 0, group: 'G1', diff: 'D1', lyric: 'line' }] });
async function legacyFactory() {
    const current = process.env.TEST_ROOT, previous = process.env.PREVIOUS_BUILD_ROOT;
    assert.ok(previous, 'PREVIOUS_BUILD_ROOT must identify the delivered r84.215');
    process.env.TEST_ROOT = previous;
    try { return (await import('./fixture.mjs?r215-journal')).fixture; }
    finally { process.env.TEST_ROOT = current; }
}
async function setup(factory = fixture) {
    const f = await factory(), mv = f.get('extras/mv'); f.get('core/cache').loadSession = () => ({ songs: [song] });
    f.host.chatMetadata[mv.MV_KEY] = { songs: { [song.id]: { id: song.id, settings: { output: 'tegaki' }, createdAt: 1, updatedAt: 1, ...mv.buildShots(raw(), f.bank, 2, { output: 'tegaki' }) } } };
    return { ...f, mv };
}
async function upgrade(old) {
    const f = await setup(); for (const [k, v] of old.disk) f.disk.set(k, v);
    f.get('generation/client').requestJson = () => { throw Error('Save-only recovery must not request generation'); };
    f.get('generation/cgImageCore').invokeImageGeneration = () => { throw Error('Save-only recovery must not draw again'); };
    return f;
}
test('actual r215 paid image journal saves after upgrade without regenerating', async () => {
    const old = await setup(await legacyFactory()); old.mv.writeMv(old.mv.mvScope(old.host), song.id, r => r);
    old.get('generation/cgImageCore').invokeImageGeneration = async () => { old.switchTo({ ...old.host, chatId: 'B', chatMetadata: {} }); return '/user/images/r215-paid.png'; };
    const held = await old.mv.drawAsset(song.id, 'G1:D1'); assert.equal(held.pending, true);
    const f = await upgrade(old); assert.equal((await f.mv.retryMvSave(held.scope, held.id)).pending, false);
    assert.equal(f.mv.readMv(f.host, song.id).groups[0].diffs[0].image.url, '/user/images/r215-paid.png');
});
test('actual r215 story journal saves after upgrade when its original record is unchanged', async () => {
    const old = await setup(await legacyFactory()); old.mv.writeMv(old.mv.mvScope(old.host), song.id, r => r);
    old.get('generation/client').requestJson = async () => { old.switchTo({ ...old.host, chatId: 'B', chatMetadata: {} }); const r = raw(); r.groups[0].composition = 'new room'; return r; };
    const held = await old.mv.generateStoryboard(song.id, { output: 'tegaki' }); assert.equal(held.pending, true);
    const f = await upgrade(old); assert.equal((await f.mv.retryMvSave(held.scope, held.id)).pending, false);
    assert.equal(f.mv.readMv(f.host, song.id).groups[0].composition, 'new room');
});
test('actual r215 snapshot story journal cannot erase a newer image after upgrade', async () => {
    const old = await setup(await legacyFactory()); old.mv.writeMv(old.mv.mvScope(old.host), song.id, r => r);
    old.get('generation/client').requestJson = async () => {
        old.mv.writeMv(old.mv.mvScope(old.host), song.id, r => { r.groups[0].diffs[0].image = { url: '/user/images/keep-paid.png' }; return r; });
        old.switchTo({ ...old.host, chatId: 'B', chatMetadata: {} }); return raw();
    };
    const held = await old.mv.generateStoryboard(song.id, { output: 'tegaki' }); assert.equal(held.pending, true);
    const f = await upgrade(old); assert.equal((await f.mv.retryMvSave(held.scope, held.id)).pending, true);
    assert.equal(f.mv.readMv(f.host, song.id).groups[0].diffs[0].image.url, '/user/images/keep-paid.png');
    assert.match(f.mv.exportMvRecovery(held.scope), /keep-paid.png/);
});
