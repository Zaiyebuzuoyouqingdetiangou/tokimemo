import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';
import { ui, recorderHost } from './mv-ui-fixture.mjs';

const plain = x => JSON.parse(JSON.stringify(x));
const song = { id: 'SONG_material', title: 'Song', lyrics: '[Verse 1]\none\n[End]' };
async function setup() {
    const f = await fixture(), mv = f.get('extras/mv');
    f.get('core/cache').loadSession = () => ({ songs: [song] });
    const record = { version: 2, storyRevision: 'first', settings: { output: 'tegaki', range: 'full', ratio: '9:16' },
        groups: [{ id: 'G1', layer: 'full', scale: 'close', characterPrompt: 'single person', diffs: [{ id: 'D1', label: 'pose', change: 'looks up', image: { url: '/user/images/original.png', at: 1 } }] }],
        shots: [{ id: 'S1', group: 'G1', diff: 'D1', sectionIndex: 0, lyric: 'one' }] };
    f.host.chatMetadata[mv.MV_KEY] = { songs: { [song.id]: record } };
    return { ...f, mv, record };
}

test('four vertical panels: each selection is exactly one quarter, not another half', async () => {
    const f = await fixture(), p = f.get('extras/mvImageTools');
    for (let i = 0; i < 4; i++) assert.deepEqual(plain(p.pixelRect(p.gridCrop(4, 1, i), 400, 800)), [0, i * 200, 400, 200]);
    assert.deepEqual(plain(p.pixelRect(p.gridCrop(2, 2, 3), 400, 800)), [200, 400, 200, 400]);
    assert.equal(p.gridCrop(4, 1, 4), null);
});

test('free crop handles reversed/invalid coordinates without sampling outside the image', async () => {
    const p = (await fixture()).get('extras/mvImageTools');
    assert.deepEqual(plain(p.pixelRect({ x: .25, y: .2, w: .5, h: .3 }, 400, 1000)), [100, 200, 200, 300]);
    assert.equal(p.normalizeCrop({ x: 0, y: 0, w: NaN, h: 1 }), null);
    assert.deepEqual(plain(p.pixelRect({ x: .99, y: .99, w: .5, h: .5 }, 100, 100)), [99, 99, 1, 1]);
});

test('automatic preview preserves enclosed white clothing even when its area is large', async () => {
    const p = (await fixture()).get('extras/mvImageTools'), w = 100, data = new Uint8ClampedArray(w * w * 4).fill(255);
    for (let y = 15; y < 85; y++) for (let x = 15; x < 85; x++) if (x < 20 || x >= 80 || y < 20 || y >= 80) {
        const i = (y * w + x) * 4; data[i] = 30; data[i + 1] = 40; data[i + 2] = 50;
    }
    const result = p.eraseEdgeWhite(data, w, w);
    assert.equal(result[3], 0); assert.equal(result[(50 * w + 50) * 4 + 3], 255); assert.equal(data[3], 255);
});

test('manual erase/restore fills fast strokes and restores original alpha and color', async () => {
    const p = (await fixture()).get('extras/mvImageTools'), original = new Uint8ClampedArray(20 * 20 * 4).fill(123), data = new Uint8ClampedArray(original);
    p.paintAlpha(data, original, 20, 20, { x: 2, y: 10 }, { x: 18, y: 10 }, 2);
    assert.equal(data[(10 * 20 + 10) * 4 + 3], 0); assert.equal(data[3], 123);
    p.paintAlpha(data, original, 20, 20, { x: 2, y: 10 }, { x: 18, y: 10 }, 2, true);
    assert.deepEqual(data, original);
});

test('saving prompt makes zero generation calls; redraw sends exactly that prompt without appended cast', async () => {
    const f = await setup(), before = plain(f.mv.readMv(f.host, song.id)), calls = [];
    f.get('generation/cgImageCore').invokeImageGeneration = async (...args) => { calls.push(args); return '/user/images/new.png'; };
    const custom = '中文单幅画面，白纱覆眼。\nkeep my tags <literal>';
    const result = await f.mv.saveAssetEdit(f.mv.captureAssetEdit(song.id, 'G1:D1'), { prompt: custom });
    assert.equal(result.pending, false); assert.equal(calls.length, 0);
    assert.deepEqual(plain(f.mv.readMv(f.host, song.id).groups), before.groups);
    assert.equal((await f.mv.drawAsset(song.id, 'G1:D1', { fresh: true })).pending, false);
    assert.equal(calls.length, 1); assert.equal(calls[0][0], custom); assert.equal(calls[0][2].promptMetadata, undefined);
});

test('reset prompt recovers the unchanged default and never erases a saved picture', async () => {
    const f = await setup(), original = f.mv.defaultAssetPrompt(f.record, 'G1:D1', f.host);
    await f.mv.saveAssetEdit(f.mv.captureAssetEdit(song.id, 'G1:D1'), { prompt: 'temporary' });
    await f.mv.saveAssetEdit(f.mv.captureAssetEdit(song.id, 'G1:D1'), { prompt: null });
    const r = f.mv.readMv(f.host, song.id);
    assert.equal(f.mv.assetPrompt(r, 'G1:D1', f.host), original); assert.equal(r.groups[0].diffs[0].image.url, '/user/images/original.png');
});

test('manual transparent local image and original reference survive a fresh runtime', async () => {
    const f = await setup();
    const image = { local: 'unique-png', original: { url: '/user/images/original.png' }, crop: { x: 0, y: .5, w: 1, h: .25 }, split: 'none', editMode: 'cutout', at: 2 };
    assert.equal((await f.mv.saveAssetEdit(f.mv.captureAssetEdit(song.id, 'G1:D1'), { image, prompt: 'edited' })).pending, false);
    const second = await setup(); for (const [k, v] of f.disk) second.disk.set(k, v);
    const r = second.mv.readMv(second.host, song.id);
    assert.deepEqual(plain(r.groups[0].diffs[0].image), image); assert.equal(r.assetPrompts['G1:D1'], 'edited');
    assert.deepEqual(plain(second.mv.completedMvRanges(r, song)), [{ range: 'custom', rangeFrom: 0, rangeTo: 0 }]);
});

test('late generated picture cannot replace a manual cutout saved while drawing', async () => {
    const f = await setup(); let release;
    f.get('generation/cgImageCore').invokeImageGeneration = () => new Promise(r => { release = r; });
    const drawing = f.mv.drawAsset(song.id, 'G1:D1');
    await f.mv.saveAssetEdit(f.mv.captureAssetEdit(song.id, 'G1:D1'), { image: { local: 'manual', editMode: 'cutout' } });
    release('/user/images/late.png'); const result = await drawing;
    assert.equal(result.pending, true); assert.equal(f.mv.readMv(f.host, song.id).groups[0].diffs[0].image.local, 'manual');
});

test('an editor opened on an older picture cannot overwrite a newer picture or new storyboard', async () => {
    for (const kind of ['image', 'story']) {
        const f = await setup(), target = f.mv.captureAssetEdit(song.id, 'G1:D1');
        f.mv.writeMv(target.scope, song.id, r => { if (kind === 'image') r.groups[0].diffs[0].image = { url: '/user/images/new.png' }; else r.storyRevision = 'replacement'; return r; });
        const before = plain(f.mv.readMv(f.host, song.id));
        assert.equal((await f.mv.saveAssetEdit(target, { image: { local: 'stale' }, prompt: 'stale' })).pending, true);
        assert.deepEqual(plain(f.mv.readMv(f.host, song.id)), before);
    }
});

test('manual save in a different chat is held for the original scope', async () => {
    const f = await setup(), target = f.mv.captureAssetEdit(song.id, 'G1:D1');
    const other = { ...f.host, chatMetadata: structuredClone(f.host.chatMetadata), chatId: 'B', getCurrentChatId: () => 'B' }; f.switchTo(other);
    assert.equal((await f.mv.saveAssetEdit(target, { prompt: 'scope A' })).pending, true);
    assert.equal(f.mv.readMv(other, song.id).assetPrompts, undefined);
});

test('manual save awaits failing metadata and keeps a recoverable result', async () => {
    const f = await setup(); delete f.sb.localStorage; f.host.saveMetadataDebounced = async () => false;
    const result = await f.mv.saveAssetEdit(f.mv.captureAssetEdit(song.id, 'G1:D1'), { image: { local: 'safe-blob' }, prompt: 'preserved' });
    assert.equal(result.pending, true); assert.equal(result.durable, false);
    assert.match(f.mv.exportMvRecovery(result.scope), /safe-blob/);
    f.host.saveMetadataDebounced = async () => true;
    assert.equal((await f.mv.retryMvSave(result.scope, result.id)).pending, false);
});

test('locally edited images are counted as drawn and never queued again by draw remaining', async () => {
    const f = await ui(setup), calls = [];
    f.mv.writeMv(f.mv.mvScope(f.host), song.id, r => { r.groups[0].diffs[0].image = { local: 'manual' }; return r; });
    f.mv.drawAsset = async (...args) => { calls.push(args); };
    f.mvui.openMv({ songId: song.id, page: 'board' }); f.click('group-open', 'G1');
    assert.match(f.body.innerHTML, /已画 1 \/ 1 张/); assert.match(f.body.innerHTML, /data-rmt-mv="edit-asset"/);
    f.click('draw-all'); await new Promise(r => setImmediate(r)); assert.equal(calls.length, 0); f.mvui.disposeMv();
});

test('editor integration commits unique media after durable blob writes and preserves an open draft across renders', async () => {
    const f = await ui(setup), media = new Map(); let options;
    f.body.querySelector = () => ({});
    f.get('ui/mvImageEditor').mountAssetEditor = (_host, o) => { options = o; return { dispose() {} }; };
    f.get('extras/mvMedia').putMedia = async (key, blob) => { media.set(key, blob); return true; };
    f.mvui.openMv({ songId: song.id }); f.click('edit-asset', 'G1:D1'); await new Promise(r => setImmediate(r));
    assert.ok(options); const before = f.body.innerHTML; f.mvui.renderMv(); assert.equal(f.body.innerHTML, before);
    const blob = new Blob(['png-test-double'], { type: 'image/png' });
    assert.equal(await options.onSave({ prompt: 'custom', image: { blob, originalRef: options.image, crop: { x: 0, y: .5, w: 1, h: .25 }, mode: 'cutout' } }), true);
    const saved = f.mv.readMv(f.host, song.id).groups[0].diffs[0].image;
    assert.equal(media.get(saved.local), blob); assert.equal(saved.original.url, '/user/images/original.png'); assert.equal(saved.split, 'none');
    assert.equal(saved.editMode, 'cutout'); assert.equal(f.mv.readMv(f.host, song.id).assetPrompts['G1:D1'], 'custom'); f.mvui.disposeMv();
});

test('failed blob transaction leaves the previous picture and prompt intact', async () => {
    const f = await ui(setup); let options;
    f.body.querySelector = () => ({}); f.get('ui/mvImageEditor').mountAssetEditor = (_host, o) => { options = o; return { dispose() {} }; };
    f.get('extras/mvMedia').putMedia = async () => false;
    f.mvui.openMv({ songId: song.id }); f.click('edit-asset', 'G1:D1'); await new Promise(r => setImmediate(r));
    await assert.rejects(options.onSave({ prompt: 'unsaved', image: { blob: new Blob(['x']), originalRef: options.image, mode: 'cutout' } }), /保存/);
    const r = f.mv.readMv(f.host, song.id); assert.equal(r.groups[0].diffs[0].image.url, '/user/images/original.png'); assert.equal(r.assetPrompts, undefined); f.mvui.disposeMv();
});

test('v2 export waits for an edited local PNG before it starts recording', async () => {
    const f = await ui(setup); let release;
    const pending = new Promise(r => { release = r; }); const media = recorderHost(f);
    f.mv.writeMv(f.mv.mvScope(f.host), song.id, r => { r.groups[0].diffs[0].image = { local: 'cold-png', split: 'none', editMode: 'full' }; return r; });
    f.get('extras/mvMedia').getMedia = key => key === 'cold-png' ? pending : Promise.resolve(null);
    f.get('extras/mvMedia').putMedia = async () => true;
    f.mvui.openMv({ songId: song.id }); f.upload(); f.audios.at(-1).onloadedmetadata(); f.click('go-tegaki'); f.click('export');
    await new Promise(r => setImmediate(r)); assert.equal(media.recorders.length, 0);
    release({ blob: new Blob(['PNG']) }); await new Promise(r => setImmediate(r)); await new Promise(r => setImmediate(r));
    assert.equal(media.recorders.length, 1); assert.equal(media.recorders[0].state, 'recording'); f.mvui.disposeMv();
});
