import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fixture } from './fixture.mjs';
import { ui } from './mv-ui-fixture.mjs';

const flush = async () => { for (let i = 0; i < 8; i++) await new Promise(resolve => setImmediate(resolve)); };
// The approved music row adds decorative icons around the same one entry.
const musicLabels = html => [...html.matchAll(/<button[^>]*data-rmt-mv="editor-drawer"[^>]*data-rmt-mv-id="audio"[^>]*>([\s\S]*?)<\/button>/g)]
    .map(m => m[1].replace(/<span aria-hidden="true">[\s\S]*?<\/span>/g, '').replace(/<[^>]+>/g, '').trim());
async function setup() {
    const f = await ui(fixture), mv = f.get('extras/mv');
    f.sb.document.querySelector = () => null;
    const song = { id: 'SINGLE', title: '同一首歌', lyrics: '[Verse 1]\n第一句\n[Chorus]\n第二句' };
    f.get('core/cache').loadSession = () => ({ songs: [song] });
    const record = { id: song.id, version: 1, duration: 123, settings: { output: 'tegaki' },
        timing: { taps: { 0: 0, 1: 60 }, lineTaps: { '0:0': 2.5 }, shift: 0 },
        shots: [{ id: 'A', sectionIndex: 0, lyric: '第一句', image: { url: '/first.png' } }, { id: 'B', sectionIndex: 1, lyric: '第二句' }] };
    f.host.chatMetadata[mv.MV_KEY] = { songs: { [song.id]: record } };
    f.get('extras/mvMedia').putMedia = async () => true;
    f.mvui.openMv({ songId: song.id }); f.click('go-tegaki');
    const loaded = async () => { f.upload(); f.audios.at(-1).onloadedmetadata(); await flush(); };
    return { ...f, loaded, saved: () => mv.readMv(f.host, song.id) };
}

test('one music entry changes from import to current filename and keeps one player', async () => {
    const f = await setup(); try {
        assert.deepEqual(musicLabels(f.body.innerHTML), ['导入音乐']);
        await f.loaded();
        assert.deepEqual(musicLabels(f.body.innerHTML), ['manual.wav']);
        assert.equal((f.body.innerHTML.match(/data-rmt-mv="play"/g) || []).length, 1);
        assert.equal((f.body.innerHTML.match(/data-rmt-mv-seek/g) || []).length, 1);
        f.click('editor-drawer', 'audio');
        assert.match(f.body.innerHTML, /data-rmt-mv-audio/);
        assert.match(f.body.innerHTML, /video\/quicktime/);
        assert.match(f.body.innerHTML, /data-rmt-mv-music-link/);
        assert.match(f.body.innerHTML, /data-rmt-mv="audio-remove"/);
    } finally { f.mvui.disposeMv(); }
});

test('removing only the current music keeps saved frames and timing', async () => {
    const f = await setup(), removed = []; try {
        await f.loaded(); const before = JSON.stringify(f.saved());
        f.get('extras/mvMedia').deleteMedia = async key => { removed.push(key); return true; };
        f.click('editor-drawer', 'audio'); f.click('audio-remove'); await flush();
        assert.equal(removed.length, 1); assert.ok(removed[0].includes('SINGLE'));
        assert.equal(JSON.stringify(f.saved()), before);
        assert.deepEqual(musicLabels(f.body.innerHTML), ['导入音乐']);
        assert.doesNotMatch(f.body.innerHTML, /data-rmt-mv="audio-remove"/);
    } finally { f.mvui.disposeMv(); }
});

test('failed music removal leaves the original track available', async () => {
    const f = await setup(), errors = []; try {
        f.sb.toastr = { error: message => errors.push(message) };
        await f.loaded(); f.get('extras/mvMedia').deleteMedia = async () => false;
        f.click('audio-remove'); await flush();
        assert.deepEqual(musicLabels(f.body.innerHTML), ['manual.wav']);
        assert.ok(errors.length); assert.match(errors[0], /原有音源保留/);
    } finally { f.mvui.disposeMv(); }
});

test('a new import wins over a pending removal of the previous song', async () => {
    const f = await setup(); let finishRemoval; try {
        await f.loaded();
        f.get('extras/mvMedia').deleteMedia = () => new Promise(resolve => { finishRemoval = resolve; });
        f.click('audio-remove'); await flush();
        f.mvui.handleMvChange({ target: { matches: s => s === '[data-rmt-mv-audio]', files: [{ name: 'new-song.wav' }] } });
        f.audios.at(-1).onloadedmetadata(); await flush(); finishRemoval(true); await flush();
        assert.deepEqual(musicLabels(f.body.innerHTML), ['new-song.wav']);
        f.click('editor-drawer', 'audio'); assert.doesNotMatch(f.body.innerHTML, /正在移除音源/);
    } finally { finishRemoval?.(true); f.mvui.disposeMv(); }
});

test('current filename is escaped and does not create another HTML control', async () => {
    const f = await setup(); try {
        f.mvui.handleMvChange({ target: { matches: s => s === '[data-rmt-mv-audio]', files: [{ name: '<img src=x onerror=alert(1)>.wav' }] } });
        f.audios.at(-1).onloadedmetadata(); await flush();
        assert.doesNotMatch(f.body.innerHTML, /<img src=x/);
        assert.equal((f.body.innerHTML.match(/data-rmt-mv-id="audio"/g) || []).length, 1);
    } finally { f.mvui.disposeMv(); }
});

test('plain release version remains compatible with the uploaded changelog parser', async () => {
    const f = await fixture(), updater = f.get('core/selfUpdater');
    const root = path.resolve(process.env.TEST_ROOT || '.');
    const sections = updater.parseHearttraceChangelog(fs.readFileSync(path.join(root, 'CHANGELOG.md'), 'utf8'));
    assert.equal(sections[0].version, '1.0.31');
    assert.ok(updater.compareHearttraceVersions('1.0.31', '1.0.30') > 0);
    assert.ok(sections.some(section => section.items.some(item => item.includes('@nancyindaeyo'))));
});

test('all current version surfaces use plain 1.0.31 and changelog credit remains', () => {
    const root = path.resolve(process.env.TEST_ROOT || '.');
    const manifest = JSON.parse(fs.readFileSync(path.join(root, 'manifest.json'), 'utf8'));
    assert.equal(manifest.version, '1.0.31'); assert.equal(manifest.js, 'index.js?heartbeat=1.0.31&layout=8');
    assert.match(fs.readFileSync(path.join(root, 'index.js'), 'utf8'), /heartbeat=\$\{BUILD\}&layout=8/);
    assert.match(fs.readFileSync(path.join(root, 'index.js'), 'utf8'), /const BUILD = '1\.0\.31';/);
    assert.match(fs.readFileSync(path.join(root, 'src/core/selfUpdater.js'), 'utf8'), /INSTALLED_BUILD = '1\.0\.31'/);
    const readme = fs.readFileSync(path.join(root, 'README.md'), 'utf8');
    assert.match(readme, /新增了更新日志板块，感谢@nancyindaeyo的更新。/);
    assert.doesNotMatch(readme, /r84|1\.0\.2[0-4]/);
    assert.ok(readme.length < 1500);
    assert.match(fs.readFileSync(path.join(root, 'src/ui/homeView.js'), 'utf8'), /mountHomeUpdateChrome/);
});
