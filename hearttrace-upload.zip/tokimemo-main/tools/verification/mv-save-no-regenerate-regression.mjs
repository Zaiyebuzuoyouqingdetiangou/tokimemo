import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { fixture } from './fixture.mjs';

const song = { id: 'SONG_legacy_save', title: 'Legacy asset', lyrics: '[Verse 1]\n看向你\n[End]' };
const plain = value => JSON.parse(JSON.stringify(value));

async function setup(provider, fallback = false) {
    const f = await fixture(), mv = f.get('extras/mv');
    f.get('core/cache').loadSession = () => ({ songs: [song] });
    f.get('core/castLooks').readCastLooks = () => ({ manual: true, char: 'black hair, blue eyes', user: 'blonde hair, green eyes' });
    const settings = mv.normalizeSettings({ output: 'tegaki', storyType: 'expression', range: 'full', appear: 'front' });
    const built = mv.buildShots(f.json({ groups: [{ id: 'A', who: 'both', layer: 'full', composition: '两人相望',
        diffs: [{ id: 'open', imagePrompt: 'two people facing each other' }] }],
        frames: [{ sectionIndex: 0, lyric: '看向你', group: 'A', diff: 'open' }] }), f.bank, 1, settings);
    const record = { ...built, id: song.id, settings, createdAt: 1 };
    assert.equal(record.cast, undefined, 'exercise the legacy path without a per-song cast');
    record.groups[0].diffs[0].image = { url: '/user/images/paid-original.png', at: 7 };
    f.host.chatMetadata[mv.MV_KEY] = { songs: { [song.id]: record } };
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS,
        imageGenerationProvider: provider, imageGenerationFallback: fallback });
    const calls = { chatu8: [], baibai: [], upload: [] }, state = { failSave: true, supportsCharacters: true };
    const source = new EventEmitter();
    f.host.eventSource = source;
    f.host.extensionSettings['st-chatu8'] = { scriptEnabled: true, mode: 'novelai', novelai_model: 'nai-diffusion-4-full' };
    source.on('generate-image-request', request => {
        calls.chatu8.push(request);
        source.emit('generate-image-response', { id: request.id, success: true, imageData: 'data:image/png;base64,QQ==' });
    });
    f.sb.fetch = async (url, options) => {
        calls.upload.push({ url, options });
        return state.failSave ? new Response('storage unavailable', { status: 500 })
            : new Response(JSON.stringify({ path: '/user/images/chatu8-recovered.png' }));
    };
    f.sb.STBaiBaiImage = { apiVersion: 1, capabilities: { generate: true, saveToGallery: true },
        getBackendStatus: () => ({ configured: true, backend: 'nai', supportsCharacters: state.supportsCharacters }),
        generate: async request => {
            calls.baibai.push(request);
            return state.failSave ? { dataUrl: 'data:image/png;base64,QQ==' } : { path: '/user/images/baibai-recovered.png' };
        } };
    return { ...f, mv, calls, state };
}

for (const [provider, code, own, other] of [
    ['chatu8-image', 'CH8_SAVE_FAILED', 'chatu8', 'baibai'],
    ['baibai-image', 'BBI_SAVE_FAILED', 'baibai', 'chatu8'],
]) for (const fallback of [false, true]) {
    test(`legacy ${provider} paid save failure sends once, keeps the old image and never switches provider (fallback ${fallback})`, async () => {
        const f = await setup(provider, fallback), before = plain(f.mv.readMv(f.host, song.id));
        await assert.rejects(f.mv.drawAsset(song.id, 'G1:D1'), { code });
        assert.equal(f.calls[own].length, 1, 'a save failure must not trigger a second paid drawing');
        assert.equal(f.calls[other].length, 0, 'a paid save failure must not fall back to another provider');
        assert.deepEqual(plain(f.mv.readMv(f.host, song.id)), before);
        assert.equal(f.mv.isAssetDrawing(f.mv.mvScope(f.host), song.id, 'G1:D1'), false);
        if (own === 'chatu8') assert.equal(f.calls.upload.length, 1);
        // A later user click remains available; this is not an automatic retry.
        f.state.failSave = false;
        assert.equal((await f.mv.drawAsset(song.id, 'G1:D1')).pending, false);
        assert.equal(f.calls[own].length, 2);
        assert.equal(f.calls[other].length, 0);
        assert.match(f.mv.readMv(f.host, song.id).groups[0].diffs[0].image.url, /recovered\.png$/);
    });
}

test('legacy metadata is flattened locally for a provider without character support, with one successful request', async () => {
    const f = await setup('baibai-image');
    f.state.failSave = false; f.state.supportsCharacters = false;
    assert.equal((await f.mv.drawAsset(song.id, 'G1:D1')).pending, false);
    assert.equal(f.calls.baibai.length, 1); assert.equal(f.calls.chatu8.length, 0);
    const request = f.calls.baibai[0];
    assert.equal(request.characters, undefined);
    assert.match(request.prompt, /black hair/); assert.match(request.prompt, /blonde hair/);
});

test('legacy metadata does not cause a second drawing after an ordinary provider failure', async () => {
    const f = await setup('baibai-image'), before = plain(f.mv.readMv(f.host, song.id));
    f.sb.STBaiBaiImage.generate = async request => { f.calls.baibai.push(request); throw { code: 'backend_error' }; };
    await assert.rejects(f.mv.drawAsset(song.id, 'G1:D1'), { code: 'BBI_BACKEND_ERROR' });
    assert.equal(f.calls.baibai.length, 1); assert.equal(f.calls.chatu8.length, 0);
    assert.deepEqual(plain(f.mv.readMv(f.host, song.id)), before);
});
