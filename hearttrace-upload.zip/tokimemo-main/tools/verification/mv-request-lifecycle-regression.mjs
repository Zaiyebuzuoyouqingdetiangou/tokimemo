import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture, realClient } from './fixture.mjs';
import { ui } from './mv-ui-fixture.mjs';
const flush = () => new Promise(resolve => setImmediate(resolve));
const deferred = () => { let resolve; const promise = new Promise(r => { resolve = r; }); return { promise, resolve }; };
const plain = x => JSON.parse(JSON.stringify(x));
const song = { id: 'SONG_a', title: 'A', lyrics: Array.from({ length: 8 }, (_, i) => `[Verse ${i + 1}]\nline ${i + 1}`).join('\n') + '\n[End]' };
const other = { ...song, id: 'SONG_b', title: 'B' };
function raw(indexes) { return { groups: indexes.map(i => ({ id: `G${i}`, composition: `scene ${i}`, characterPrompt: 'one scene', diffs: [{ id: 'D1', label: 'moment', change: 'looks up' }], bgs: [{ id: 'B1', prompt: 'garden' }] })), frames: indexes.map(i => ({ sectionIndex: i, lyric: `line ${i + 1}`, group: `G${i}`, diff: 'D1', bg: 'B1' })) }; }
async function setup(existing = true) {
    const f = await fixture(); f.get('core/cache').loadSession = () => ({ songs: [song, other] });
    const mv = f.get('extras/mv');
    if (existing) {
        const record = { id: song.id, createdAt: 1, updatedAt: 1, settings: { output: 'tegaki', range: 'full' }, tegaki: { range: 'full' }, ...mv.buildShots(raw([0, 1]), f.bank, 8, { output: 'tegaki' }) };
        f.host.chatMetadata[mv.MV_KEY] = { songs: { [song.id]: record, [other.id]: { ...structuredClone(record), id: other.id } } };
    }
    f.sb.toastr = { success() {}, info() {}, error() {} };
    return { ...f, mv };
}

test('one setup click makes one storyboard request; drawing screen does not launch another batch', async () => {
    const f = await ui(() => setup(false)); let calls = 0;
    realClient(f, () => { calls++; return raw([0]); });
    f.mvui.openMv({ songId: song.id }); f.click('setup-generate');
    for (let i = 0; i < 12; i++) await flush();
    try { assert.equal(calls, 1); assert.equal(f.mv.readMv(f.host, song.id).shots.length, 1); assert.match(f.body.innerHTML, /data-rmt-mv="continue-board"/); }
    finally { f.mvui.disposeMv(); }
});

test('an explicit continuation click requests one batch even when the reply leaves more sections', async () => {
    const f = await ui(setup); let calls = 0;
    realClient(f, () => { calls++; return raw([2]); });
    f.mvui.openMv({ songId: song.id }); f.click('continue-board');
    for (let i = 0; i < 12; i++) await flush();
    try { assert.equal(calls, 1); assert.equal(f.mv.readMv(f.host, song.id).shots.length, 3); assert.match(f.body.innerHTML, /data-rmt-mv="continue-board"/); }
    finally { f.mvui.disposeMv(); }
});

test('late setup completion cannot launch story requests for a newly opened song', async () => {
    const f = await ui(setup), d = deferred(), calls = [];
    f.mv.generateStoryboard = () => d.promise;
    f.mv.continueStoryboard = async id => { calls.push(id); return { pending: true }; };
    f.mvui.openMv({ songId: song.id }); f.click('rewrite-board'); f.click('setup-generate');
    f.mvui.openMv({ songId: other.id }); const before = f.body.innerHTML;
    d.resolve({ pending: false }); await flush(); await flush();
    try { assert.deepEqual(calls, []); assert.equal(f.body.innerHTML, before); }
    finally { f.mvui.disposeMv(); }
});

test('regeneration arriving after a v2 image was drawn holds the response and preserves that image', async () => {
    const f = await setup();
    realClient(f, () => { f.mv.writeMv(f.mv.mvScope(f.host), song.id, r => { r.groups[0].diffs[0].image = { url: '/user/images/newly-paid.png' }; return r; }); return raw([0, 1, 2]); });
    const result = await f.mv.generateStoryboard(song.id, { output: 'tegaki' });
    assert.equal(result.pending, true); assert.equal(f.mv.readMv(f.host, song.id).groups[0].diffs[0].image.url, '/user/images/newly-paid.png');
    assert.match(f.mv.exportMvRecovery(result.scope), /scene 2/);
    assert.equal((await f.mv.retryMvSave(result.scope, result.id)).pending, true);
});

test('story single-flight remains locked until an asynchronous metadata save settles', async () => {
    const f = await setup(false), entered = deferred(), saving = deferred(); delete f.sb.localStorage;
    f.host.saveMetadataDebounced = () => { entered.resolve(); return saving.promise; };
    let calls = 0; realClient(f, () => { calls++; return raw([0]); });
    const task = f.mv.generateStoryboard(song.id, { output: 'tegaki' }); await entered.promise;
    try { assert.equal(f.mv.isMvRunning(`story:${f.mv.mvScope(f.host)}:${song.id}`), true); await assert.rejects(f.mv.generateStoryboard(song.id, { output: 'tegaki' }), /正在写/); assert.equal(calls, 1); }
    finally { saving.resolve(); await task; }
    assert.equal(f.mv.isMvRunning(`story:${f.mv.mvScope(f.host)}:${song.id}`), false);
});

test('queued group drawing never jumps to a newly opened song after its first image finishes', async () => {
    const f = await ui(setup), d = deferred(), calls = [];
    f.mv.writeMv(f.mv.mvScope(f.host), song.id, a => {
        a.groups[0].diffs.push({ id: 'D2', label: 'next', change: 'looks away', image: null });
        a.shots.push({ ...a.shots[0], id: 'S_extra', diff: 'D2' }); return a;
    });
    f.mv.drawAsset = async (id, key) => { calls.push([id, key]); return calls.length === 1 ? d.promise : { pending: false }; };
    f.mvui.openMv({ songId: song.id }); f.click('draw-group', 'G1');
    assert.deepEqual(calls, [[song.id, 'G1:D1']]);
    f.mvui.openMv({ songId: other.id }); const before = f.body.innerHTML; d.resolve({ pending: false });
    await flush(); await flush();
    try { assert.deepEqual(calls, [[song.id, 'G1:D1']]); assert.equal(f.body.innerHTML, before); }
    finally { f.mvui.disposeMv(); }
});

test('late paid asset is held if its group key was reused by an explicit replacement storyboard', async () => {
    const f = await setup(), d = deferred();
    f.get('generation/cgImageCore').invokeImageGeneration = () => d.promise;
    const drawing = f.mv.drawAsset(song.id, 'G1:D1');
    realClient(f, () => raw([0, 1, 2])); assert.equal((await f.mv.generateStoryboard(song.id, { output: 'tegaki' })).pending, false);
    d.resolve('/user/images/old-story.png'); const result = await drawing;
    assert.equal(result.pending, true); assert.equal(f.mv.readMv(f.host, song.id).groups[0].diffs[0].image, null);
    assert.match(f.mv.exportMvRecovery(result.scope), /old-story.png/);
});

test('a continuation can consist entirely of reused paid images without cloning or redrawing them', async () => {
    const f = await setup(); let requests = 0;
    f.mv.writeMv(f.mv.mvScope(f.host), song.id, r => { r.groups[0].diffs[0].image = { url: '/user/images/reuse-paid.png' }; return r; });
    const old = plain(f.mv.readMv(f.host, song.id));
    realClient(f, () => { requests++; return { frames: [{ sectionIndex: 2, lyric: 'line 3', group: 'G1', diff: 'D1', hold: 0.25 }] }; });
    const result = await f.mv.continueStoryboard(song.id); assert.equal(result.pending, false);
    const r = f.mv.readMv(f.host, song.id);
    assert.deepEqual(plain(r.groups), old.groups); assert.equal(r.shots.at(-1).group, 'G1'); assert.equal(r.shots.at(-1).reuseGroup, undefined); assert.equal(requests, 1);
});

test('mixed new and reused groups preserve the correct image keys even when new raw IDs overlap old IDs', async () => {
    const f = await setup(); const reply = raw([2]); reply.groups[0].id = 'G1'; reply.frames[0].group = 'G1';
    reply.frames.push({ sectionIndex: 3, lyric: 'line 4', group: 'G2', diff: 'D1' });
    realClient(f, () => reply); assert.equal((await f.mv.continueStoryboard(song.id)).pending, false);
    const r = f.mv.readMv(f.host, song.id); assert.equal(r.groups.length, 3);
    assert.equal(r.shots.find(s => s.sectionIndex === 2).group, 'G3');
    assert.equal(r.shots.find(s => s.sectionIndex === 3).group, 'G2');
});

test('single-image redraw sends a fresh seed and a group redraw shares its new seed across differences', async () => {
    const f = await ui(setup), seen = [];
    f.mv.writeMv(f.mv.mvScope(f.host), song.id, r => {
        r.groups[0].seed = 123; r.groups[0].diffs[0].image = { url: '/user/images/old.png' };
        r.groups[0].diffs.push({ id: 'D2', label: 'next', change: 'looks away', image: { url: '/user/images/old2.png' } });
        r.shots.push({ ...r.shots[0], id: 'S_extra', diff: 'D2' }); return r;
    });
    f.get('generation/cgImageCore').invokeImageGeneration = async (_p, _c, options) => { seen.push(options.seed); return { url: '/user/images/new' + seen.length + '.png', seed: 456 }; };
    f.mvui.openMv({ songId: song.id }); f.click('draw-asset', 'G1:D1'); for (let i = 0; i < 4; i++) await flush();
    assert.equal(seen.length, 1); assert.ok(!seen[0]);
    f.click('redraw-group', 'G1'); for (let i = 0; i < 8; i++) await flush();
    try { assert.equal(seen.length, 3); assert.ok(!seen[1]); assert.equal(seen[2], 456); assert.equal(f.mv.readMv(f.host, song.id).groups[0].diffs[1].image.url, '/user/images/new3.png'); }
    finally { f.mvui.disposeMv(); }
});

test('the existing ten-line request batch size remains, with no total section limit', async () => {
    const f = await setup(false), longSong = { ...song, lyrics: Array.from({ length: 25 }, (_, i) => `[Verse ${i + 1}]\nline ${i + 1}`).join('\n') };
    f.get('core/cache').loadSession = () => ({ songs: [longSong] });
    const requested = []; f.get('generation/client').requestJson = async prompt => {
        const sections = JSON.parse(prompt.split('段落（sectionIndex 从 0 开始）：\n')[1].split('\n')[0]);
        requested.push(sections.map(s => s.index)); return raw(sections.map(s => s.index));
    };
    assert.equal((await f.mv.generateStoryboard(song.id, { output: 'tegaki', range: 'full' })).pending, false);
    assert.equal((await f.mv.continueStoryboard(song.id)).pending, false);
    assert.equal((await f.mv.continueStoryboard(song.id)).pending, false);
    assert.deepEqual(requested.map(s => s.length), [10, 10, 5]); assert.equal(f.mv.readMv(f.host, song.id).shots.length, 25);
});

test('saved r215 custom export selection remains effective when the restored clip controls first open', async () => {
    const f = await setup(); const r = f.mv.readMv(f.host, song.id);
    r.tegaki = { range: 'full', exportMode: 'custom', exportFrom: 1, exportTo: 3 };
    assert.deepEqual(plain(f.mv.exportOptions(r, song)), { range: 'custom', rangeFrom: 1, rangeTo: 3 });
    r.exportRange = { range: 'custom', rangeFrom: 4, rangeTo: 5 };
    assert.equal(f.mv.exportOptions(r, song).rangeFrom, 4);
});

test('queued drawing stops when an explicit replacement story arrives, even on the same page', async () => {
    const f = await ui(setup), d = deferred(), calls = [];
    f.mv.drawAsset = async (id, key) => { calls.push([id, key]); return d.promise; };
    f.mvui.openMv({ songId: song.id }); f.click('draw-all'); assert.equal(calls.length, 1);
    realClient(f, () => raw([0, 1])); assert.equal((await f.mv.generateStoryboard(song.id, { output: 'tegaki' })).pending, false);
    d.resolve({ pending: false }); await flush(); await flush();
    try { assert.deepEqual(calls, [[song.id, 'G1:D1']]); }
    finally { f.mvui.disposeMv(); }
});

test('a manual image filled while another asset is drawing is skipped by the remaining-image queue', async () => {
    const f = await ui(setup), d = deferred(), calls = [];
    f.mv.drawAsset = async (id, key) => { calls.push([id, key]); return d.promise; };
    f.mvui.openMv({ songId: song.id }); f.click('draw-all'); assert.equal(calls.length, 1);
    f.mv.writeMv(f.mv.mvScope(f.host), song.id, r => { r.groups[1].diffs[0].image = { url: '/user/images/manual-second.png' }; return r; });
    d.resolve({ pending: false }); await flush(); await flush();
    try { assert.deepEqual(calls, [[song.id, 'G1:D1']]); assert.equal(f.mv.readMv(f.host, song.id).groups[1].diffs[0].image.url, '/user/images/manual-second.png'); }
    finally { f.mvui.disposeMv(); }
});

test('append retains images paid before it finishes and late image saves to the unchanged original group', async () => {
    const f = await setup(), response = deferred(), image = deferred();
    f.get('generation/client').requestJson = () => response.promise;
    const appending = f.mv.continueStoryboard(song.id);
    f.get('generation/cgImageCore').invokeImageGeneration = () => image.promise;
    const drawing = f.mv.drawAsset(song.id, 'G1:D1');
    image.resolve('/user/images/concurrent.png'); assert.equal((await drawing).pending, false);
    const before = plain(f.mv.readMv(f.host, song.id).groups);
    response.resolve(raw([2, 3])); assert.equal((await appending).pending, false);
    assert.deepEqual(plain(f.mv.readMv(f.host, song.id).groups.slice(0, 2)), before);
});
