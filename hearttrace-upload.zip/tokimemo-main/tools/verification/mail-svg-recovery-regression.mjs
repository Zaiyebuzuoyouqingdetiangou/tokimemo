import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fixture, realClient } from './fixture.mjs';

const root = path.resolve(process.env.TEST_ROOT || '.');
const f = await fixture();
let parser = f.get('generation/jsonParser');
if (process.env.TEST_BUNDLE !== '1') {
  const source = fs.readFileSync(path.join(root, 'src/generation/jsonParser.js'), 'utf8').replace(/^import .*;\n/gm, '');
  const context = vm.createContext({ structuredClone, response_config: f.get('core/independentApiConfig'),
    output_budget: f.get('core/outputBudget'), core_constants: f.constants, core_text: f.get('core/text') });
  const module = new vm.SourceTextModule(source, { context });
  await module.link(() => {}); await module.evaluate(); parser = module.namespace;
}
const plain = value => JSON.parse(JSON.stringify(value));
const letter = (slot = 'daily', title = '新信') => ({ slot, title, greeting: '你：', body: '窗外的雨停了，等你回来。', closing: '甲' });
const art = (slot = 'daily') => ({ slot, version: 3, characterName: '甲', summary: '窗边等雨停', svg: '<svg viewBox="0 0 320 280"><path d="M1 1L20 20"/></svg>' });
const boundArt = (row = art(), prose = letter()) => ({ ...row, _rmtLetterTextKey: JSON.stringify(['slot', 'title', 'greeting', 'body', 'closing'].map(key => prose[key] || '')) });
const brokenArt = '{"slot":"stage","version":3,"characterName":"甲","summary":"桌旁","svg":"<svg viewBox=\\"0 0 320 280\\"><path d=\\"M1';
const inboxPrefix = () => '{"letters":' + JSON.stringify([letter(), letter('stage', '另一封')]) + ',"letterIllustrations":[' + JSON.stringify(art()) + ',' + brokenArt;

test('valid same-response prose and static SVG are returned unchanged', () => {
  const input = { letters: [letter()], letterIllustrations: [art()] };
  assert.deepEqual(plain(parser.extractJson(JSON.stringify(input), { mode: 'inbox' })), input);
});
test('truncated optional art retains all complete letters and earlier complete art rows', () => {
  const result = parser.extractJson(inboxPrefix(), { mode: 'inbox' });
  assert.deepEqual(plain(result.letters), [letter(), letter('stage', '另一封')]);
  assert.deepEqual(plain(result.letterIllustrations), [art()]);
});
test('recovery projection keeps complete top-level art without closing the broken reply', () => {
  const result = parser.parseInboxRecoveryObject(inboxPrefix());
  assert.equal(result.complete, false); assert.equal(result.has('/letters'), false);
  assert.equal(result.items('/letters').length, 2);
  assert.deepEqual(plain(result.items('/letterIllustrations')), [boundArt()]);
});
test('complete recovery binds artwork to its own received prose and overwrites spoofed keys', () => {
  const result = parser.parseInboxRecoveryObject(JSON.stringify({ letters: [letter()], letterIllustrations: [{ ...art(), _rmtLetterTextKey: 'spoof' }, art('stage')] }));
  assert.equal(result.complete, true); assert.equal(result.has('/letters'), true);
  assert.deepEqual(plain(result.items('/letterIllustrations')), [boundArt()]);
});
test('transport exception requires a rooted JSON reply with completed prose and optional art', () => {
  assert.equal(parser.hasCompleteInboxProseBeforeArt(inboxPrefix(), { mode: 'inbox' }), true);
  assert.equal(parser.hasCompleteInboxProseBeforeArt('```json\n' + inboxPrefix(), { mode: 'inbox' }), true);
  assert.equal(parser.hasCompleteInboxProseBeforeArt(mergedPrefix(), mergedOptions), true);
  for (const source of ['<!--error-->\n' + inboxPrefix(), '<html><body>' + inboxPrefix(), 'error: ' + inboxPrefix(),
    JSON.stringify({ letters: [letter()], letterIllustrations: [] }) + '<html>error</html>',
    '{"letters":[{"slot":"daily","title":"新信","body":"半句']) {
    assert.equal(parser.hasCompleteInboxProseBeforeArt(source, { mode: 'inbox' }), false);
  }
  assert.equal(parser.hasCompleteInboxProseBeforeArt(inboxPrefix(), { mode: 'cabinet' }), false);
  assert.equal(parser.hasCompleteInboxProseBeforeArt(mergedPrefix(), { mode: 'inbox' }), false);
});
test('unescaped SVG quotes cannot hide preceding complete prose', () => {
  const text = '{"letters":' + JSON.stringify([letter()]) + ',"letterIllustrations":[{"slot":"daily","version":3,"svg":"<svg viewBox="0 0 320 280">"}]}';
  const result = parser.extractJson(text, { mode: 'inbox' });
  assert.deepEqual(plain(result.letters), [letter()]);
  assert.deepEqual(plain(result.letterIllustrations || []), []);
});
test('an unfinished body is never completed using illustration text', () => {
  const text = '{"letters":[{"slot":"daily","title":"新信","body":"还没有写完';
  assert.throws(() => parser.extractJson(text, { mode: 'inbox' }), error => error.code === 'RMT_JSON_TRUNCATED');
});
test('mail salvage selects the final reply and its own art, not the preceding example', () => {
  const example = JSON.stringify({ letters: [letter('daily', '示例')], letterIllustrations: [art('stage')] });
  const result = parser.extractJson('示例：' + example + '\n实际答复：' + inboxPrefix(), { mode: 'inbox' });
  assert.equal(result.letters[0].title, '新信');
  assert.deepEqual(plain(result.letterIllustrations), [art()]);
});
test('legacy inline illustration salvage remains compatible', () => {
  const input = { ...letter(), letterIllustration: { version: 2, focus: 'person' } };
  const result = parser.extractJson('{"letters":[' + JSON.stringify(input), { mode: 'inbox' });
  assert.deepEqual(plain(result.letters), [input]);
});

const mergedPrefix = () => '{"modules":{"cabinet":{"items":[{"name":"书签"}]},"inbox":' + inboxPrefix();
const mergedOptions = { mode: 'cabinet', mergedInboxIllustrations: true };
test('explicit merged mail-art salvage preserves closed siblings, prose and complete art only', () => {
  const result = parser.extractJson(mergedPrefix(), mergedOptions);
  assert.deepEqual(plain(result.modules.cabinet), { items: [{ name: '书签' }] });
  assert.deepEqual(plain(result.modules.inbox.letters), [letter(), letter('stage', '另一封')]);
  assert.deepEqual(plain(result.modules.inbox.letterIllustrations), [art()]);
  assert.equal(Object.hasOwn(result.modules, 'themeSong'), false);
});
test('normal modes and unmarked merged replies keep strict parsing', () => {
  for (const options of [{}, { mode: 'cabinet' }, { mode: 'inbox' }, { mode: 'cabinet', mergedInboxIllustrations: false }]) {
    assert.throws(() => parser.extractJson(mergedPrefix(), options), error => error.code === 'RMT_JSON_TRUNCATED');
  }
});
test('merged artwork flag does not repair an unrelated broken module', () => {
  const text = '{"modules":{"inbox":' + JSON.stringify({ letters: [letter()], letterIllustrations: [art()] }) + ',"cabinet":{"items":[{"name":"未写完';
  assert.throws(() => parser.extractJson(text, mergedOptions), error => error.code === 'RMT_JSON_TRUNCATED');
});
test('merged artwork flag does not invent an incomplete letter body', () => {
  const text = '{"modules":{"inbox":{"letters":[{"slot":"daily","title":"新信","body":"未写完';
  assert.throws(() => parser.extractJson(text, mergedOptions), error => error.code === 'RMT_JSON_TRUNCATED');
});
test('merged salvage selects final reply instead of an earlier complete example', () => {
  const example = JSON.stringify({ modules: { inbox: { letters: [letter('daily', '示例')] }, cabinet: { items: [] } } });
  const result = parser.extractJson('示例：' + example + '\n实际答复：' + mergedPrefix(), mergedOptions);
  assert.equal(result.modules.inbox.letters[0].title, '新信');
  assert.equal(result.modules.cabinet.items[0].name, '书签');
});
test('a later complete non-mail answer is not replaced by a mail example', () => {
  const example = JSON.stringify({ modules: { inbox: { letters: [letter('daily', '示例')] } } });
  assert.deepEqual(plain(parser.extractJson(example + '\n{"answer":"实际答复"}', mergedOptions)), { answer: '实际答复' });
});
test('valid merged response is unchanged, including non-mail siblings', () => {
  const input = { modules: { inbox: { letters: [letter()], letterIllustrations: [art()] }, themeSong: { title: '歌' } } };
  assert.deepEqual(plain(parser.extractJson(JSON.stringify(input), mergedOptions)), input);
});
test('bundled request pipeline saves damaged mail-art response with one request and the configured output budget',
  { skip: process.env.TEST_BUNDLE !== '1' }, async () => {
    const live = await fixture(); realClient(live, () => null);
    let requests = 0, outputTokens = 0;
    live.host.ConnectionManagerRequestService.sendRequest = async (_profile, _messages, tokens) => {
      requests++; outputTokens = tokens;
      return { choices: [{ message: { content: mergedPrefix() } }] };
    };
    const result = await live.get('generation/client').requestValidatedSegment('按原方案交回各页。', '', {
      context: live.host, contextEnvelope: '', mode: 'cabinet', mergedInboxIllustrations: true,
      maxTokens: 4000, background: true, taskKey: 'mail-svg-recovery-test',
    }, value => { assert.ok(value.modules?.inbox?.letters?.length); return value; });
    assert.equal(requests, 1); assert.equal(outputTokens, 120000);
    assert.equal(result.modules.inbox.letters[0].body, letter().body);
    assert.equal(result.modules.inbox.letterIllustrations[0].svg, art().svg);
  });

async function bundledRequest(reply, options = {}) {
  const live = await fixture(); realClient(live, () => null);
  let requests = 0;
  live.host.ConnectionManagerRequestService.sendRequest = async () => { requests++; return reply; };
  const promise = live.get('generation/client').requestValidatedSegment('先写全部信，再画小画。', '', {
    context: live.host, contextEnvelope: '', mode: 'inbox', background: true, taskKey: 'mail-svg-transport-test', ...options,
  }, value => value);
  return { promise, requests: () => requests, live };
}
for (const finishReason of ['length', 'max_tokens']) {
  test(`bundled ${finishReason} response retains complete mail before damaged SVG without a second request`,
    { skip: process.env.TEST_BUNDLE !== '1' }, async () => {
      const run = await bundledRequest({ choices: [{ message: { content: inboxPrefix() }, finish_reason: finishReason }] });
      const value = await run.promise;
      assert.equal(run.requests(), 1); assert.equal(value.letters[0].body, letter().body);
      assert.equal(value.letterIllustrations[0].svg, art().svg);
    });
}
test('bundled complete JSON with length finish keeps complete prose and picture',
  { skip: process.env.TEST_BUNDLE !== '1' }, async () => {
    const input = { letters: [letter()], letterIllustrations: [art()] };
    const run = await bundledRequest({ choices: [{ message: { content: JSON.stringify(input) }, finish_reason: 'length' }] });
    assert.deepEqual(plain(await run.promise), input); assert.equal(run.requests(), 1);
  });
test('bundled interrupted public stream retains complete mail without pretending the stream completed',
  { skip: process.env.TEST_BUNDLE !== '1' }, async () => {
    const run = await bundledRequest(async function* () {
      yield { text: inboxPrefix(), state: { reasoning: '' } };
      throw Error('connection closed');
    });
    const value = await run.promise; assert.equal(run.requests(), 1); assert.equal(value.letters.length, 2);
    const config = run.live.get('core/independentApiConfig');
    const incomplete = config.streamCompletion(inboxPrefix(), 'unknown', true, 0, true);
    assert.equal(config.manualStreamCompletionInfo(incomplete).complete, false);
    assert.throws(() => config.assertManualStreamComplete(incomplete), error => error.code === 'RMT_JSON_TRUNCATED');
  });
test('bundled truncated body still stops and never turns into complete prose',
  { skip: process.env.TEST_BUNDLE !== '1' }, async () => {
    const run = await bundledRequest({ choices: [{ message: { content: '{"letters":[{"slot":"daily","title":"新信","body":"半句' }, finish_reason: 'length' }] });
    await assert.rejects(run.promise, error => error.code === 'RMT_JSON_TRUNCATED'); assert.equal(run.requests(), 1);
  });
test('bundled transport guard rejects HTML wrappers, JSON islands and optional SVG in other modes',
  { skip: process.env.TEST_BUNDLE !== '1' }, async () => {
    for (const [content, options] of [
      ['<!--proxy error-->\n' + inboxPrefix(), {}], ['<html><body>' + inboxPrefix(), {}],
      [JSON.stringify({ letters: [letter()], letterIllustrations: [] }) + '<html>error</html>', {}],
      [inboxPrefix(), { mode: 'cabinet' }], [mergedPrefix(), { mode: 'cabinet' }],
    ]) {
      const run = await bundledRequest({ choices: [{ message: { content } }] }, options);
      await assert.rejects(run.promise, error => error.code === 'RMT_RESPONSE_HTML'); assert.equal(run.requests(), 1);
    }
  });
test('bundled provider error envelope remains an error even with complete mail-shaped content',
  { skip: process.env.TEST_BUNDLE !== '1' }, async () => {
    const run = await bundledRequest({ error: { message: 'provider failed' }, choices: [{ message: { content: inboxPrefix() } }] });
    await assert.rejects(run.promise); assert.equal(run.requests(), 1);
  });
