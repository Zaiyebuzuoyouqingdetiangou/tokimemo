import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const root = process.env.TEST_ROOT || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const module = new vm.SourceTextModule(await fs.readFile(path.join(root, 'src/generation/chatu8Presets.js'), 'utf8'));
await module.link(() => { throw new Error('Preset resolver must not depend on providers or request code'); });
await module.evaluate();
const resolve = (context, name, options) => {
    const value = module.namespace.chatu8PresetAppearance(context, name, options);
    return value ? JSON.parse(JSON.stringify(value)) : value;
};
const person = (nameEN, characterTraits = 'blonde hair', fields = {}) => ({ nameEN, nameCN: '', characterTraits, facialFeatures: 'light brown eyes', ...fields });
const context = (characterPresets, fields = {}) => ({ extensionSettings: { 'st-chatu8': { characterPresets, ...fields } } });

test('literal identity fields override neither scene clothes nor actions and do not mutate provider settings', () => {
    const ctx = context({ Kamael: person('Kamael', 'short blonde hair, pale skin', {
        upperBodySFW: 'red shirt, waving', fullBodySFW: 'standing, black boots', outfits: ['unused outfit'],
    }) });
    const before = JSON.stringify(ctx);
    assert.deepEqual(resolve(ctx, 'Kamael'), { tag: 'short blonde hair, pale skin, light brown eyes', source: 'chatu8', presetKey: 'Kamael' });
    assert.equal(JSON.stringify(ctx), before);
});

test('exact normalized Chinese and English aliases and the preset key resolve, not substrings', () => {
    const ctx = context({ 'current-card-Kamael': person('Kamael | Ka-mael', 'blonde hair', { nameCN: '卡玛尔 | 小卡' }) });
    for (const name of ['  ＫＡＭＡＥＬ  ', 'Ka mael', '卡玛尔', '小卡', 'current-card-Kamael']) {
        assert.equal(resolve(ctx, name)?.presetKey, 'current-card-Kamael');
    }
    for (const name of ['Kam', 'Kamael II', '卡', '', null, {}, '$Kamael$']) assert.equal(resolve(ctx, name), null);
});

test('string and object enabled/common references work without requiring active lists', () => {
    for (const characters of [['K1'], [{ characterPresetName: 'K1' }]]) {
        for (const tier of ['Enable', 'Common']) {
            const ctx = context({ K1: person('Kamael') }, {
                [`character${tier}PresetId`]: 'selected', [`character${tier}Presets`]: { selected: { characters } },
            });
            assert.equal(resolve(ctx, 'Kamael')?.presetKey, 'K1');
        }
    }
    assert.equal(resolve(context({ K1: person('Kamael') }), 'Kamael')?.presetKey, 'K1');
});

test('same-name presets remain ambiguous globally even when only one is enabled or common', () => {
    const ctx = context({ old: person('Kamael', 'brown hair'), current: person('Kamael', 'blonde hair') }, {
        characterEnablePresetId: 'old-card', characterEnablePresets: { 'old-card': { characters: ['old'] } },
        characterCommonPresetId: 'current-card', characterCommonPresets: { 'current-card': { characters: [{ characterPresetName: 'current' }] } },
    });
    assert.equal(resolve(ctx, 'Kamael'), null);
    assert.equal(resolve(ctx, 'current')?.tag, 'blonde hair, light brown eyes');
});

test('duplicate aliases within one preset are not an identity conflict but key-alias collisions are', () => {
    assert.equal(resolve(context({ K: person('Kamael|kamael', 'blonde hair', { nameCN: 'Kamael' }) }), 'Kamael')?.presetKey, 'K');
    assert.equal(resolve(context({ Kamael: person('different person'), K: person('Kamael') }), 'Kamael'), null);
});

test('missing and unsupported provider schemas fall back without throwing', () => {
    const cases = [undefined, null, {}, { extensionSettings: {} }, { extensionSettings: { 'st-chatu8': null } },
        context(null), context([]), context({ K: 'Kamael' }), context({ K: { nameEN: ['Kamael'] } }),
        context({ K: person('Kamael') }, { characterEnablePresetId: {} }),
        context({ K: person('Kamael') }, { characterEnablePresetId: 'x', characterEnablePresets: { x: { characters: {} } } })];
    for (const ctx of cases) assert.equal(resolve(ctx, 'Kamael'), null);
});

test('getters are not invoked; throwy proxy boundaries and unknown appearance fields return null', () => {
    let reads = 0;
    const getter = { get() { reads++; throw new Error('must not invoke getters'); }, enumerable: true };
    const ctx = context({ K: person('Kamael') });
    Object.defineProperty(ctx.extensionSettings['st-chatu8'], 'apiKey', getter);
    Object.defineProperty(ctx.extensionSettings['st-chatu8'], 'apiEndpoint', getter);
    Object.defineProperty(ctx.extensionSettings['st-chatu8'].characterPresets.K, 'upperBodySFW', getter);
    assert.ok(resolve(ctx, 'Kamael'));
    Object.defineProperty(ctx.extensionSettings['st-chatu8'].characterPresets.K, 'facialFeatures', getter);
    assert.equal(resolve(ctx, 'Kamael'), null);
    assert.equal(reads, 0);
    assert.equal(resolve(new Proxy({}, { getOwnPropertyDescriptor() { throw new Error('unsupported host'); } }), 'Kamael'), null);
    assert.equal(resolve(context({ K: person('Kamael', { tag: 'blonde hair' }) }), 'Kamael'), null);
});

test('unresolved preset macros never become literal model input', () => {
    for (const raw of ['$Missing$', 'blonde hair, $Other-sfw-upperbody$', '{{char}}', '{{getvar::outfit}}']) {
        assert.equal(resolve(context({ K: person('Kamael', raw) }), 'Kamael'), null);
        assert.equal(resolve(context({ K: person('Kamael', 'blonde hair', { facialFeatures: raw }) }), 'Kamael'), null);
    }
    assert.equal(resolve(context({ K: person('Kamael', '', { facialFeatures: '' }) }), 'Kamael'), null);
});

test('back view uses back identity without front-facing eyes or an outfit', () => {
    const ctx = context({ K: person('Kamael', 'blonde hair, blue eyes, pale skin, front view', {
        facialFeatures: 'red lips', facialFeaturesBack: 'short nape hair', upperBodySFWBack: 'blue jacket',
    }) });
    assert.equal(resolve(ctx, 'Kamael', { visible: 'back' })?.tag, 'blonde hair, pale skin, short nape hair');
});

test('hands and silhouettes cannot import portraits, hair, clothing or full-body framing', () => {
    const ctx = context({ K: person('Kamael', '1boy, full body, blonde hair, pale skin, slender fingers, skin on smiling face, full-body pale skin', {
        facialFeatures: 'blue eyes, thin lips', facialFeaturesBack: 'short nape hair', upperBodySFW: 'white gloves',
    }) });
    assert.equal(resolve(ctx, 'Kamael', { visible: 'hands' })?.tag, 'pale skin, slender fingers');
    assert.equal(resolve(ctx, 'Kamael', { visible: 'silhouette' }), null);
    assert.equal(resolve(ctx, 'Kamael', { visible: 'unknown-version-crop' }), null);
    assert.equal(resolve(context({ K: person('Kamael') }), 'Kamael', { visible: 'hands' }), null);
});

test('preset identity tags have no new arbitrary size cap and preserve user weighting', () => {
    const raw = '(blonde hair:1.2), ' + 'long hair, '.repeat(400);
    assert.equal(resolve(context({ K: person('Kamael', raw, { facialFeatures: '' }) }), 'Kamael')?.tag, raw.trim());
});
