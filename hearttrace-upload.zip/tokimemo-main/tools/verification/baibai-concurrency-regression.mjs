import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';
import { stageSetup, song } from './mv-stage-fixture.mjs';

const flush = async () => { for (let i = 0; i < 8; i++) await new Promise(resolve => setImmediate(resolve)); };
function connect(f) {
    const calls = [], notices = [], controls = [], tasks = [];
    let draining = false;
    f.sb.STBaiBaiImage = { apiVersion: 1, capabilities: { generate: true, saveToGallery: true },
        getBackendStatus: () => ({ configured: true, backend: 'nai', supportsCharacters: true }),
        generate: (request, options) => new Promise((resolve, reject) => {
            calls.push({ request, options, resolve, reject });
            if (draining) resolve({ path: '/user/images/cleanup.png' });
        }) };
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS, imageGenerationProvider: 'baibai-image', imageGenerationFallback: false });
    f.sb.toastr = { info: message => notices.push(message), error: message => notices.push(message), success: () => {} };
    const adapter = f.get('generation/baibaiImage');
    const start = (targetKey, options = {}) => {
        const controller = new AbortController(); controls.push(controller);
        const job = adapter.generateBaiBaiImage('one figure ' + targetKey, { targetKey, signal: controller.signal, ...options });
        job.catch(() => {}); tasks.push(job); return job;
    };
    const reply = (call, suffix = calls.indexOf(call)) => call.resolve({ path: `/user/images/baibai-${suffix}.png`, seed: 100 + Number(suffix) });
    const cleanup = async () => {
        draining = true;
        controls.forEach(controller => controller.abort());
        calls.forEach(call => reply(call));
        await Promise.allSettled(tasks); await flush();
    };
    return { calls, notices, controls, adapter, start, reply, cleanup };
}

test('twelve BaiBai requests retain independent prompts, seed and reverse-order results', async () => {
    const f = await fixture(), c = connect(f);
    try {
        const jobs = Array.from({ length: 12 }, (_, i) => c.start(`target-${i}`, { seed: i + 1, characterName: 'Char', singlePrompt: true }));
        assert.equal(c.calls.length, 12);
        assert.equal(c.adapter.baiBaiImagePendingCount(), 12);
        c.calls.forEach((call, i) => {
            assert.equal(call.request.seed, i + 1); assert.equal(call.request.prompt, `one figure target-${i}`);
            assert.equal(call.request.nl, ''); assert.equal(call.request.save, true); assert.equal(call.request.character, 'Char');
        });
        for (const call of [...c.calls].reverse()) c.reply(call);
        const results = await Promise.all(jobs);
        results.forEach((result, i) => { assert.equal(result.url, `/user/images/baibai-${i}.png`); assert.equal(result.seed, 100 + i); });
        assert.equal(c.adapter.baiBaiImagePendingCount(), 0);
    } finally { await c.cleanup(); }
});

test('cancelled BaiBai request stays deduped until the provider settles and other images continue', async () => {
    const f = await fixture(), c = connect(f); let settled = 0;
    try {
        const a = c.start('A', { onSettled: () => settled++ }), b = c.start('B'), d = c.start('D');
        await assert.rejects(c.start('A'), { code: 'BBI_TARGET_BUSY' });
        assert.equal(c.calls.length, 3);
        c.controls[0].abort(); await assert.rejects(a, { code: 'BBI_ABORTED' });
        assert.equal(c.calls[0].options.signal.aborted, true);
        assert.equal(c.calls[1].options.signal.aborted, false);
        assert.equal(c.adapter.isBaiBaiImageTargetPending('A'), true); assert.equal(settled, 0);
        await assert.rejects(c.start('A'), { code: 'BBI_TARGET_BUSY' });
        c.reply(c.calls[2]); c.reply(c.calls[1]); await Promise.all([b, d]);
        c.reply(c.calls[0]); await flush();
        assert.equal(c.adapter.isBaiBaiImageTargetPending('A'), false); assert.equal(settled, 1);
        const again = c.start('A'); assert.equal(c.calls.length, 4); c.reply(c.calls[3]); await again;
    } finally { await c.cleanup(); }
});

test('five-minute BaiBai wait notice does not abort queued work or send it twice', async () => {
    const f = await fixture(), c = connect(f), timers = new Map(), phases = [];
    let serial = 0, status = 'waiting';
    f.sb.setTimeout = (fn, ms) => { timers.set(++serial, { fn, ms }); return serial; };
    f.sb.clearTimeout = id => timers.delete(id);
    try {
        const job = c.start('slow', { onProgress: progress => phases.push(progress.phase) });
        job.then(() => { status = 'done'; }, () => { status = 'failed'; });
        c.calls[0].options.onProgress({ phase: 'queued' });
        const timer = [...timers.values()][0]; assert.equal(timer.ms, 300000); timer.fn(); await flush();
        assert.equal(status, 'waiting'); assert.equal(c.calls[0].options.signal.aborted, false);
        assert.ok(phases.includes('waiting'));
        await assert.rejects(c.start('slow'), { code: 'BBI_TARGET_BUSY' });
        assert.equal(c.calls.length, 1);
        c.reply(c.calls[0]); await job;
        assert.equal(status, 'done'); assert.equal(timers.size, 0);
    } finally { await c.cleanup(); }
});

test('one provider failure or invalid saved path leaves the other concurrent result intact', async () => {
    const f = await fixture(), c = connect(f);
    try {
        const jobs = ['A', 'B', 'C'].map(key => c.start(key)), results = Promise.allSettled(jobs);
        assert.equal(c.calls.length, 3);
        c.calls[0].reject({ code: 'rate_limited', message: 'private provider message' });
        c.calls[1].resolve({ dataUrl: 'data:image/png;base64,AAAA' });
        c.reply(c.calls[2]);
        const outcomes = await results;
        assert.equal(outcomes[0].reason.code, 'BBI_RATE_LIMITED');
        assert.doesNotMatch(outcomes[0].reason.message, /private provider message/);
        assert.equal(outcomes[1].reason.code, 'BBI_SAVE_FAILED');
        assert.equal(outcomes[2].value.url, '/user/images/baibai-2.png');
        assert.equal(c.calls.length, 3); assert.equal(c.adapter.baiBaiImagePendingCount(), 0);
    } finally { await c.cleanup(); }
});

test('BaiBai MV assets save to their own slots when three results finish out of order', async () => {
    const f = await stageSetup('image'), c = connect(f), jobs = ['G1:D1', 'G2:D1', 'stage:S1'].map(key => f.mv.drawAsset(song.id, key));
    jobs.forEach(job => job.catch(() => {}));
    try {
        assert.equal(c.calls.length, 3);
        for (const call of [...c.calls].reverse()) c.reply(call);
        assert.ok((await Promise.all(jobs)).every(result => !result.pending));
        const record = f.mv.readMv(f.host, song.id);
        assert.equal(record.groups[0].diffs[0].image.url, '/user/images/baibai-0.png');
        assert.equal(record.groups[1].diffs[0].image.url, '/user/images/baibai-1.png');
        assert.equal(record.stage.backgrounds[0].image.url, '/user/images/baibai-2.png');
    } finally {
        await c.cleanup(); await Promise.allSettled(jobs);
    }
});

test('ordinary BaiBai CG sends ten images beyond the general task cap and retains per-card saves', async () => {
    const f = await fixture(), c = connect(f), state = f.get('core/state').state, mode = f.constants.MODE.ALBUM;
    const session = { kind: mode, chatId: 'A', archiveRevision: 'r1', selectedId: 'C0',
        entries: Array.from({ length: 10 }, (_, i) => ({ id: `C${i}`, title: `画面${i}`, cgDesc: `figure ${i}`, unlocked: true })) };
    let stored = structuredClone(session);
    state.activeMode = mode; state.activeSession = session; state.activeArchiveReadOnly = false;
    f.get('archive/library').requireWritableArchiveAction = () => true;
    f.get('archive/repository').getImportedMemory = () => f.bank;
    f.get('core/cache').getCache = () => ({});
    f.get('core/cache').loadSession = () => stored;
    f.get('core/cache').commitSessionMutation = async (kind, chatId, origin, mutate) => {
        assert.equal(kind, mode); assert.equal(chatId, 'A'); stored = mutate(structuredClone(stored), f.bank); return stored;
    };
    f.get('ui/overlay').confirmExplicitAction = () => true;
    f.get('ui/albumView').renderAlbum = () => {};
    f.get('core/requestCoordinator').noteChatTaskPhase = () => {};
    f.get('core/requestCoordinator').rememberStandaloneChatTask = () => {};
    const actions = f.get('generation/cgImageActions'), jobs = [];
    try {
        for (const item of session.entries) {
            session.selectedId = item.id;
            jobs.push(actions.drawSelectedCgImage({ promptOverride: item.cgDesc, promptMetadata: null }));
        }
        assert.equal(c.calls.length, 10, c.notices.join('\n'));
        assert.equal(state.activeCgImageTasks.size, 10);
        session.selectedId = 'C0'; await actions.drawSelectedCgImage({ promptOverride: 'same card', promptMetadata: null });
        assert.equal(c.calls.length, 10);
        for (const call of [...c.calls].reverse()) c.reply(call);
        await Promise.all(jobs);
        for (let i = 0; i < 10; i++) assert.equal(stored.entries[i].cgImage?.url, `/user/images/baibai-${i}.png`);
        assert.equal(state.activeCgImageTasks.size, 0);
        assert.equal(c.adapter.baiBaiImagePendingCount(), 0);
    } finally {
        for (const task of state.activeCgImageTasks.values()) task.controller.abort();
        for (const call of c.calls) c.reply(call);
        await Promise.allSettled(jobs); await c.cleanup();
    }
});
