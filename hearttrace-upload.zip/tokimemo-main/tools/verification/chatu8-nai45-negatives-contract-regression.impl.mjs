import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { EventEmitter } from 'node:events';
import { fixture } from './fixture.mjs';

// Actual upstream matching, macro processing, positive/negative assembly and
// NAI payload construction. Only configuration, queue and network are isolated.
const upstreamPath = process.env.CHATU8_SOURCE || '/workspace/scratch/8e568532ca62/inspection/chatu8-current.js';
const upstream = fs.readFileSync(upstreamPath, 'utf8');
function upstreamFunction(name) {
    const found = upstream.match(new RegExp('^(?:async )?function ' + name + '\\([^\\n]*\\{[\\s\\S]*?^}', 'm'));
    assert.ok(found, 'upstream function: ' + name);
    return found[0];
}
const names = ['getBaseTag', 'hasWeight', 'deduplicateTags', 'getSortedCharacterIds', 'parsePromptStringWithCoordinates',
    'centersToCoordinates', 'stripChineseAnnotations', 'normalizeName', 'calculateMatchScore', 'collectCharacterCandidates',
    'collectOutfitCandidates', 'findBestCharacterMatch', 'findBestOutfitMatch', 'collectNegativeToGlobal',
    'processCharacterPrompt', 'processMultiCharacterPrompt', 'reconstructPromptString', 'zhengmian', 'fumian',
    'extractIfCondition', 'evaluateCondition', 'safeEvaluateIf', 'parseReWrapper', 'splitRuleLine', 'applyPromptReplaceRules',
    'prompt_replace', 'prompt_replace_for_character', 'cleanNovelAIPayload', 'validateNovelAIPayload', 'generateNovelAIImage'];
const nativeSource = names.map(upstreamFunction).join('\n');
const presetRows = () => ({
    r: { nameCN: '拉斐尔', nameEN: 'Raphael', characterTraits: '{{dark brown hair}}', facialFeatures: 'brown eyes',
        negative: '{{blonde hair}}, blue eyes' },
    k: { nameCN: '卡玛尔', nameEN: 'Kamael', characterTraits: '{{short blonde hair}}', facialFeatures: 'green eyes',
        negative: '{{black hair}}, red eyes' },
});
const scene = '2people, tea ceremony, sitting at a wooden table';
const localMetadata = (selectedRoles = ['char', 'user']) => ({ promptFormat: 'nai45-tags', sceneTags: scene, selectedRoles,
    characters: [
        { role: 'char', name: '拉斐尔', tag: 'silver hair' },
        { role: 'user', name: '卡玛尔', tag: 'white hair' },
    ] });
async function nativeRequest(event, { model = 'nai-diffusion-4-5-full', automaticCoordinates = true, presets = presetRows() } = {}) {
    let actual;
    const config = { mode: 'novelai', novelaimode: model, client: 'api', novelaiApi: 'TEST_ONLY',
        novelaisite: '官网', novelai_width: 1216, novelai_height: 832, novelai_seed: '1', novelai_steps: 28,
        novelai_sampler: 'k_euler_ancestral', Schedule: 'karras', nai3Scale: 5, cfg_rescale: 0,
        nai3Variety: false, nai3CharRef: false, nai3VibeTransfer: false, enableVibeGroupTransfer: false,
        enableCloudQueue: false, AI_use_coords: automaticCoordinates, AQT_novelai: '', UCP_novelai: 'None',
        characterPresets: presets, characterEnablePresetId: 'cast', characterEnablePresets: { cast: { characters: ['r', 'k'] } },
        prompt_replace_id: 'none', prompt_replace: { none: { text: '' } },
        yushe: { test: { fixedPrompt: 'artist:fixture_artist, soft shading（固定画师注释）', fixedPrompt_end: 'detailed background',
            negativePrompt: 'lowres, bad anatomy（固定负面注释）' } } };
    const noop = () => {};
    const sandbox = { console: { log: noop, warn: noop, error: noop }, window: {}, AbortController, Date,
        extensionName: 'st-chatu8', extension_settings3: { 'st-chatu8': config }, extension_settings29: { 'st-chatu8': config }, extension_settings62: { 'st-chatu8': config },
        taskQueue: { addTask: () => 'test', updateStatus: noop, completeTask: noop, isTaskInQueue: () => true },
        TaskType: { NOVELAI: 'nai' }, TaskStatus: { RUNNING: 'running' }, activeAbortControllers: new Map(),
        currentCloudQueueInfo: null, currentTaskId: null, NOVELAI_TIMEOUT_SECONDS: 300,
        setTimeout: () => 0, clearTimeout: noop, clearLog: noop, addLog: noop,
        isPluginToastDisabled: () => true, toastr: { error: noop, info: noop, success: noop },
        acquireSerialLock: async () => {}, releaseSerialLock: noop, getRandomYusheId: () => 'test',
        isSettingFalse: value => value === false || value === 'false', isSettingTrue3: value => value === true || value === 'true',
        buildGenParams: (_, values) => values, createLoggableNovelAIPayload: value => value,
        getNovelAICandidateUrls: () => ({ candidates: ['https://fixture.invalid'], rawOtherSite: '' }), getDirectHeaders3: () => ({}),
        postNovelAIWithFallback: async options => { actual = JSON.parse(options.body); return { arrayBuffer: async () => new ArrayBuffer(0) }; },
        unzipFile: async () => 'TEST_IMAGE',
    };
    vm.createContext(sandbox);
    vm.runInContext(nativeSource, sandbox);
    await sandbox.generateNovelAIImage({ prompt: event.prompt, width: event.width, height: event.height, extraNegativePrompt: event.negative_prompt });
    assert.ok(actual, 'real upstream NAI builder reached intercepted network boundary');
    return actual;
}

async function setup({ model = 'nai-diffusion-4-5-full', automaticCoordinates = true, client = 'api' } = {}) {
    const f = await fixture(), requests = [], events = new EventEmitter();
    let provider = 'chatu8-image';
    f.host.name2 = '拉斐尔'; f.host.name1 = '卡玛尔'; f.host.eventSource = events;
    f.host.extensionSettings['st-chatu8'] = { scriptEnabled: true, mode: 'novelai', novelaimode: model,
        AI_use_coords: automaticCoordinates, client, characterPresets: presetRows() };
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS, imageGenerationProvider: provider, imageGenerationFallback: false });
    f.sb.STBaiBaiImage = { apiVersion: 1, capabilities: { generate: true, saveToGallery: true },
        getBackendStatus: () => ({ configured: true, backend: 'nai', supportsCharacters: true }),
        generate: async () => { throw Error('wrong provider'); } };
    f.get('generation/client').requestJson = async () => { throw Error('unexpected extra paid text call'); };
    events.on('generate-image-request', request => { requests.push(request); events.emit('generate-image-response',
        { id: request.id, success: true, imageData: '/user/images/contract.png' }); });
    return { ...f, requests, selectProvider: value => { provider = value; },
        preview: meta => f.get('generation/cgImageActions').cgEditorSendPreview(f.constants.MODE.ALBUM, {}, scene, meta, 'nai45-tags', f.host),
        send: meta => f.get('generation/cgImageCore').invokeImageGeneration(scene, f.host, { promptMetadata: meta }) };
}
async function previewAndSend(f, metadata) {
    const count = f.requests.length, preview = f.preview(metadata);
    assert.equal(f.requests.length, count, 'preview never sends a request');
    await f.send(metadata);
    assert.equal(f.requests.length, count + 1, 'one user action sends one image request');
    const event = f.requests.at(-1);
    assert.equal(event.prompt, preview.prompt);
    assert.equal(event.negative_prompt || '', preview.negative_prompt || '');
    return { preview, event };
}
function assertFixedChannels(actual) {
    assert.match(actual.input, /artist:fixture_artist, soft shading/);
    assert.match(actual.input, /detailed background/);
    assert.match(actual.parameters.negative_prompt, /^lowres, bad anatomy(?:,|$)/);
    assert.doesNotMatch(actual.input + actual.parameters.negative_prompt, /[\u3400-\u9fff]/u);
}

test('actual upstream macro behavior independently establishes native UC and flat negative merging', async () => {
    const native = await nativeRequest({ prompt: 'Scene Composition: tea ceremony; Character 1 Prompt: $Raphael-sfw-upperbody$; Character 2 Prompt: $Kamael-sfw-upperbody$;' });
    assertFixedChannels(native);
    assert.deepEqual(native.parameters.v4_negative_prompt.caption.char_captions.map(row => row.char_caption),
        [presetRows().r.negative, presetRows().k.negative]);
    const flat = await nativeRequest({ prompt: 'tea ceremony, $Raphael-sfw-upperbody$, $Kamael-sfw-upperbody$' }, { automaticCoordinates: false });
    assertFixedChannels(flat);
    assert.equal(flat.parameters.negative_prompt, `lowres, bad anatomy, ${presetRows().r.negative}, ${presetRows().k.negative}`);
});

for (const model of ['nai-diffusion-4-full', 'nai-diffusion-4-5-full', 'nai-diffusion-5-full']) {
    test(`${model}: one and two native tag captions keep isolated literal negatives and no local display names`, async () => {
        const f = await setup({ model }), before = JSON.stringify(f.host.extensionSettings);
        for (const selectedRoles of [['user'], ['char', 'user']]) {
            const { event } = await previewAndSend(f, localMetadata(selectedRoles));
            assert.doesNotMatch(event.prompt, /[\u3400-\u9fff]|Raphael|Kamael|local .* exclusion/u);
            const actual = await nativeRequest(event, { model });
            assertFixedChannels(actual);
            const expected = selectedRoles.map(role => role === 'char' ? presetRows().r : presetRows().k);
            assert.deepEqual(actual.parameters.v4_prompt.caption.char_captions.map(row => row.char_caption),
                expected.map(row => `${row.characterTraits}, ${row.facialFeatures}`));
            assert.deepEqual(actual.parameters.v4_negative_prompt.caption.char_captions.map(row => row.char_caption), expected.map(row => row.negative));
            assert.equal(actual.parameters.negative_prompt, 'lowres, bad anatomy');
        }
        assert.equal(JSON.stringify(f.host.extensionSettings), before);
    });
}

test('manual coordinate configuration emits flat tags and the same merged negatives as upstream flat macros', async () => {
    const f = await setup({ automaticCoordinates: false });
    const { event, preview } = await previewAndSend(f, localMetadata());
    assert.doesNotMatch(event.prompt, /[\u3400-\u9fff]|Scene Composition:|Character \d+ Prompt:|centers:/u);
    assert.ok(event.prompt.includes(presetRows().r.characterTraits));
    assert.ok(event.prompt.includes(presetRows().k.characterTraits));
    assert.equal(preview.negative_prompt, `${presetRows().r.negative}, ${presetRows().k.negative}`);
    const actual = await nativeRequest(event, { automaticCoordinates: false });
    const oracle = await nativeRequest({ prompt: 'tea ceremony, $Raphael-sfw-upperbody$, $Kamael-sfw-upperbody$' }, { automaticCoordinates: false });
    assertFixedChannels(actual);
    assert.equal(actual.parameters.negative_prompt, oracle.parameters.negative_prompt);
    assert.equal(actual.parameters.v4_prompt.caption.char_captions.length, 0);
});

test('Jiuguan transport receives a flat event carrying character negatives even with automatic coordinates enabled', async () => {
    const f = await setup({ client: 'jiuguan' });
    const { event } = await previewAndSend(f, localMetadata());
    assert.doesNotMatch(event.prompt, /[\u3400-\u9fff]|Scene Composition:|Character \d+ UC:/u);
    assert.equal(event.negative_prompt, `${presetRows().r.negative}, ${presetRows().k.negative}`);
});

test('switching to Chatu8 and changing or removing a preset updates positives and negatives together', async () => {
    const f = await setup();
    const local = localMetadata(['user']);
    f.selectProvider('baibai-image');
    const other = f.preview(local);
    assert.doesNotMatch(JSON.stringify(other), /black hair|red eyes/);
    f.selectProvider('chatu8-image');
    const frozen = f.get('generation/cgAppearance').resolveCgAppearanceMetadata(f.host, local);
    f.host.extensionSettings['st-chatu8'].characterPresets.k.characterTraits = '{{golden hair}}';
    f.host.extensionSettings['st-chatu8'].characterPresets.k.negative = 'purple hair';
    let sent = await previewAndSend(f, frozen);
    let actual = await nativeRequest(sent.event);
    assert.match(actual.parameters.v4_prompt.caption.char_captions[0].char_caption, /\{\{golden hair\}\}/);
    assert.equal(actual.parameters.v4_negative_prompt.caption.char_captions[0].char_caption, 'purple hair');
    delete f.host.extensionSettings['st-chatu8'].characterPresets.k;
    sent = await previewAndSend(f, frozen);
    actual = await nativeRequest(sent.event);
    assert.equal(actual.parameters.v4_prompt.caption.char_captions[0].char_caption, 'white hair');
    assert.equal(actual.parameters.v4_negative_prompt.caption.char_captions[0].char_caption, '');
    assert.doesNotMatch(sent.event.prompt, /golden hair|purple hair|black hair|red eyes/);
});

test('manual appearance override does not inherit the previously displayed preset negative', async () => {
    const f = await setup();
    const meta = f.get('generation/cgAppearance').resolveCgAppearanceMetadata(f.host, localMetadata(['user']));
    meta.characters[0] = { ...meta.characters[0], tag: 'silver hair', appearanceOverride: true };
    const { event } = await previewAndSend(f, meta);
    const actual = await nativeRequest(event);
    assert.equal(actual.parameters.v4_prompt.caption.char_captions[0].char_caption, 'silver hair');
    assert.equal(actual.parameters.v4_negative_prompt.caption.char_captions[0].char_caption, '');
    assert.doesNotMatch(event.prompt, /black hair|red eyes/);
});

test('full manual prompt remains exact and gains neither preset identities nor character negatives', async () => {
    const f = await setup(), manual = '{{silver hair}}, tea ceremony';
    const meta = { ...localMetadata(), flatPromptOverride: true, flatPrompt: manual };
    const { event } = await previewAndSend(f, meta);
    assert.equal(event.prompt, manual);
    assert.equal(event.negative_prompt, undefined);
    const actual = await nativeRequest(event);
    assertFixedChannels(actual);
    assert.equal(actual.parameters.negative_prompt, 'lowres, bad anatomy');
    assert.doesNotMatch(actual.input, /dark brown hair|short blonde hair/);
});
