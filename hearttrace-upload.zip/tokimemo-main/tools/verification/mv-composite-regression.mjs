import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';
import { scene, native } from './mv-stage-canvas-fixture.mjs';
import { editor, decode } from './motif-editor-fixture.mjs';
import { ui } from './mv-ui-fixture.mjs';
import { song, stageSetup } from './mv-stage-fixture.mjs';

function actor() {
    const c = native.createCanvas(200, 240), g = c.getContext('2d');
    g.fillStyle = '#ebebeb'; g.fillRect(0, 0, 200, 240);
    g.fillStyle = '#20252e'; g.beginPath(); g.arc(100, 38, 25, 0, Math.PI * 2); g.fill();
    g.fillRect(85, 60, 30, 170); g.fillRect(30, 90, 140, 95);
    const triangle = points => { g.beginPath(); points.forEach(([x, y], i) => i ? g.lineTo(x, y) : g.moveTo(x, y)); g.closePath(); g.fill(); };
    g.fillStyle = '#ebebeb'; triangle([[42, 115], [75, 135], [65, 169]]); triangle([[158, 115], [125, 135], [135, 169]]);
    g.fillRect(86, 82, 28, 107); g.fillRect(88, 33, 7, 4); g.fillRect(105, 33, 7, 4);
    return { c, w: c.width, h: c.height, data: g.getImageData(0, 0, c.width, c.height).data };
}
const alpha = (data, w, x, y) => data[(y * w + x) * 4 + 3];
const plain = value => JSON.parse(JSON.stringify(value));

test('interior arm matte is cleared while the central white garment, eyes and original stay intact', async () => {
    const f = await fixture(), p = actor(), before = Buffer.from(p.data);
    const result = f.get('extras/mvImageTools').prepareCharacterPixels(p.data, p.w, p.h);
    assert.equal(result.status, 'prepared');
    for (const [x, y] of [[0, 0], [62, 141], [138, 141]]) assert.equal(alpha(result.data, p.w, x, y), 0);
    for (const [x, y] of [[100, 130], [90, 35], [108, 35], [35, 125]]) assert.equal(alpha(result.data, p.w, x, y), 255);
    assert.deepEqual(Buffer.from(p.data), before);
});

test('explicit cleanup continues an old transparent edit, is repeatable, and never rekeys playback alpha', async () => {
    const f = await fixture(), p = actor(), m = f.get('extras/mvImageTools');
    const old = m.eraseEdgeWhite(p.data, p.w, p.h);
    assert.equal(alpha(old, p.w, 62, 141), 255);
    assert.equal(m.prepareCharacterPixels(old, p.w, p.h).data, old);
    const cleaned = m.prepareCutoutPixels(old, p.w, p.h, { reference: p.data });
    assert.equal(cleaned.status, 'prepared'); assert.equal(alpha(cleaned.data, p.w, 62, 141), 0);
    const again = m.prepareCutoutPixels(cleaned.data, p.w, p.h, { reference: p.data });
    assert.deepEqual(Buffer.from(again.data), Buffer.from(cleaned.data), 'repeat must not eat away alpha edges');
    assert.equal(alpha(again.data, p.w, 100, 130), 255);
    const multiple = m.prepareCutoutPixels(old, p.w, p.h, { reference: p.data, multiple: true });
    assert.equal(alpha(multiple.data, p.w, 62, 141), 255, 'ambiguous multi-person holes stay editable');
});

test('point removal affects only the chosen connected region and can be undone before PNG save', async () => {
    const p = actor(), e = await editor(p.c.toDataURL(), { url: '/original.png' }, { autoCutout: true, multipleCharacters: true });
    try {
        const canvas = e.find('[data-editor-canvas]');
        const at = (x, y) => canvas.getContext('2d').getImageData(x, y, 1, 1).data[3];
        assert.equal(at(62, 141), 255); await e.click('region');
        const rect = canvas.getBoundingClientRect();
        await canvas.fire('pointerdown', { pointerId: 1, clientX: rect.width * 62 / p.w, clientY: rect.height * 141 / p.h });
        await canvas.fire('pointerup', { pointerId: 1 });
        assert.equal(at(62, 141), 0); assert.equal(at(138, 141), 255); assert.equal(at(100, 130), 255);
        await e.click('undo'); assert.equal(at(62, 141), 255);
        await e.click('region'); await canvas.fire('pointerdown', { pointerId: 2, clientX: rect.width * 62 / p.w, clientY: rect.height * 141 / p.h });
        await canvas.fire('pointerup', { pointerId: 2 }); await e.click('save');
        const png = await decode(e.saves[0].image.blob);
        assert.equal(png.getContext('2d').getImageData(62, 141, 1, 1).data[3], 0);
        assert.equal(e.saves[0].image.originalRef.url, '/original.png');
    } finally { e.controller.dispose(); }
});

for (const scale of ['full', 'wide', 'medium']) test(`${scale}: transparent padding does not change visible scale or floor`, async () => {
    const f = await fixture(), placement = f.get('ui/mvStageCanvas').foregroundPlacement;
    const group = { scale, position: 'center' };
    const a = placement({ x: 0, top: 0, cx: .5, bottom: 1, width: 1, height: 1 }, 100, 180, group, 960, 540);
    const b = placement({ x: .25, top: .25, cx: .5, bottom: .75, width: .5, height: .5 }, 200, 360, group, 960, 540);
    for (const key of ['x', 'y', 'width', 'height']) assert.ok(Math.abs(a.subject[key] - b.subject[key]) < 1e-8, key);
    if (scale === 'medium') assert.ok(a.subject.y + a.subject.height > 540, 'half-body cut edge goes below the frame');
    else assert.ok(Math.abs(a.subject.y + a.subject.height - a.foot) < 1e-8);
});

test('only deliberate local closeups become full-frame inserts', async () => {
    const f = await fixture(), detail = f.get('ui/mvStageCanvas').isDetailInsert;
    assert.equal(detail({ scale: 'close', composition: '眼部特写' }, {}), true);
    assert.equal(detail({ scale: 'close', cast: [{ visible: 'hands' }] }, {}), true);
    assert.equal(detail({ scale: 'medium', composition: '双眼闭起，半身抱臂' }, {}), false);
    assert.equal(detail({ scale: 'full', composition: '全身站立' }, { imagePrompt: 'one boy with red eyes, full body' }), false);
});

test('an oval eye insert fills the frame and keeps its caption above the picture', async () => {
    const c = native.createCanvas(240, 160), g = c.getContext('2d');
    g.fillStyle = '#c48a73'; g.beginPath(); g.ellipse(120, 80, 105, 57, 0, 0, Math.PI * 2); g.fill();
    g.fillStyle = '#201924'; g.fillRect(68, 65, 30, 12); g.fillRect(142, 65, 30, 12);
    const f = await scene({ imageBackground: true, createArt: () => ({ url: c.toDataURL(), editMode: 'cutout', split: 'none' }),
        configure: r => { r.groups[0].scale = 'close'; r.groups[0].composition = '眼部特写'; } });
    try {
        const draws = f.seek(1), context = f.preview.getContext('2d');
        for (const [x, y] of [[2, 2], [f.w - 3, 2], [2, f.h - 3], [f.w - 3, f.h - 3]]) {
            const pixel = [...context.getImageData(x, y, 1, 1).data];
            assert.deepEqual(pixel, [196, 138, 115, 255], 'transparent oval must not float over the green stage');
        }
        assert.ok(draws.findIndex(d => d.text) > draws.findIndex(d => d.image === f.art1.url));
        assert.equal(f.record().groups[0].diffs[0].image.url, f.art1.url); assert.equal(f.calls(), 0);
    } finally { f.mvui.disposeMv(); }
});

function lettering(g) {
    const drawn = [], fill = g.fillText.bind(g), stroke = g.strokeText.bind(g);
    g.fillText = (text, x, y) => { drawn.push({ text, x, y, width: g.measureText(text).width, fill: g.fillStyle, outline: g.strokeStyle }); fill(text, x, y); };
    g.strokeText = (...args) => stroke(...args);
    return drawn;
}
const font = { weight: 700, stack: 'sans-serif' };
const state = text => ({ active: true, text, cue: { layout: 'sides', depth: 'back' }, background: { colors: ['#141414', '#151515', '#944b67'] } });

test('side captions split once at word boundaries and stay outside the actor in dark scenes', async () => {
    const f = await fixture(), m = f.get('ui/mvStageCanvas'), c = native.createCanvas(960, 540), g = c.getContext('2d');
    const text = '无情道暂缓执行，今晚陪你看星星', subject = { x: 365, width: 230 };
    const s = state(text), plan = m.textRegions(s, {}, 960, 540, subject);
    assert.equal(plan.regions.length, 2); assert.equal(plan.regions.map(r => r.text).join(''), text);
    const drawn = lettering(g); m.drawText(g, s, {}, 960, 540, font, false, { subject, pass: 'back' });
    assert.equal(drawn.map(d => d.text).join(''), text);
    for (const d of drawn) {
        assert.ok(d.x + d.width / 2 < subject.x || d.x - d.width / 2 > subject.x + subject.width);
        assert.match(d.outline, /255|fff|fffd/i, 'dark letters receive a light outline');
        assert.ok(d.x - d.width / 2 >= 0 && d.x + d.width / 2 <= 960);
    }
});

test('side captions shrink to keep ordinary English words whole', async () => {
    const f = await fixture(), c = native.createCanvas(960, 540), g = c.getContext('2d'), drawn = lettering(g);
    const text = 'I will stay by your side, tonight and tomorrow.';
    f.get('ui/mvStageCanvas').drawText(g, state(text), {}, 960, 540, font, false, { subject: { x: 340, width: 280 }, pass: 'back' });
    assert.deepEqual(drawn.flatMap(d => d.text.trim().split(/\s+/)), text.split(/\s+/));
});

for (const [w, h] of [[960, 540], [540, 960]]) test(`crowded ${w}x${h} captions use one complete front lane without clipping`, async () => {
    const f = await fixture(), m = f.get('ui/mvStageCanvas'), c = native.createCanvas(w, h), g = c.getContext('2d');
    const text = '可本少侠的字典里没有退缩的字眼，今晚我陪你看漫天星河。';
    const s = state(text), subject = { x: w * .08, width: w * .84 }, drawn = lettering(g);
    g.font = '13px serif'; m.drawText(g, s, {}, w, h, font, false, { subject, pass: 'back' });
    assert.equal(drawn.length, 0); assert.equal(g.font, '13px serif', 'skipped pass restores context');
    m.drawText(g, s, {}, w, h, font, false, { subject, pass: 'front' });
    assert.equal(drawn.map(d => d.text).join(''), text);
    for (const d of drawn) assert.ok(d.y < h * .94 && d.y > h * .5 && d.x - d.width / 2 >= 0 && d.x + d.width / 2 <= w);
});

test('a crowded keyword never lands on the complete lyric and a fade renders only current captions', async () => {
    const f = await scene({ ratio: '9:16' });
    try {
        const r = f.record(); r.groups[0].scale = 'close';
        r.shots[0].stage.text = '关键字'; r.shots[0].lyric = '完整歌词';
        f.mvui.renderMv(); const first = f.seek(1).filter(d => d.text).map(d => d.text).join('');
        assert.equal(first, '完整歌词');
        r.shots[1].cut = 'fade'; r.shots[1].lyric = '前一行'; r.shots[1].stage.text = '前一行';
        r.shots[2].lyric = '后一行'; r.shots[2].stage.text = '后一行';
        f.mvui.renderMv(); const fading = f.seek(8.1).filter(d => d.text).map(d => d.text).join('');
        assert.equal(fading, '后一行'); assert.equal(f.calls(), 0);
    } finally { f.mvui.disposeMv(); }
});

test('punctuation differences do not add a second copy of a complete stage lyric', async () => {
    const f = await scene({ configure: r => {
        r.groups[0].scale = 'wide'; r.shots[0].lyric = '可本少侠的字典里，没有退缩的字眼。';
        r.shots[0].stage.text = '可本少侠的字典里 没有退缩的字眼';
    } });
    try {
        const letters = f.seek(1).filter(d => d.text).map(d => d.text).join('').replace(/[\s\p{P}\p{S}]/gu, '');
        assert.equal(letters, '可本少侠的字典里没有退缩的字眼'); assert.equal(f.calls(), 0);
    } finally { f.mvui.disposeMv(); }
});

test('seven songs start folded, every song remains reachable, and actions follow the selected song', async () => {
    const f = await ui(stageSetup), s = f.get('core/state').state;
    s.activeMode = 'themeSong'; s.activeSession = { kind: 'themeSong', songs: Array.from({ length: 7 }, (_, i) => ({ ...song, id: `SONG_${i}`, title: `歌${i}`, singer: '角色' })), selectedId: 'SONG_4' };
    f.get('archive/repository').getImportedMemory = () => f.bank; f.get('core/cache').getCache = () => ({});
    f.get('ui/recoveryView').recoveryBannerHtml = () => ''; f.get('ui/expandedCgView').expandedCgHtml = () => '';
    f.get('core/generationOptions').readSongOptions = () => ({});
    const view = f.get('ui/themeSongView'); view.renderThemeSongs();
    const html = f.body.innerHTML;
    assert.match(html, /<details class="rmt-song-library">/); assert.match(html, /歌曲列表 · 7 首/);
    assert.equal((html.match(/data-rmt-song="select"/g) || []).length, 7);
    const detail = html.slice(html.indexOf('data-rmt-current-song="SONG_4"'));
    assert.match(detail, /data-rmt-song="view-read"/); assert.match(detail, /data-rmt-song="view-format"/);
    assert.match(detail, /data-rmt-mv-id="SONG_4"/);
    assert.equal((html.slice(0, html.indexOf('data-rmt-current-song')).match(/data-rmt-song="view-/g) || []).length, 0);
    assert.equal(s.activeSession.songs.length, 7);
});
