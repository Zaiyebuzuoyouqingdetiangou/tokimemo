import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fixture } from './fixture.mjs';

const root = path.resolve(process.env.TEST_ROOT || '.');

test('a deleted pair leaves this chat history and stays gone; other pairs and scopes are untouched', async () => {
    const f = await fixture(), core = f.get('extras/coupleAvatar');
    const scope = 'delete-test', other = 'delete-other';
    const a = (await core.addCouple(scope, { original: 'data:image/png;base64,YQ==' })).record;
    const b = (await core.addCouple(scope, { original: 'data:image/png;base64,Yg==' })).record;
    await core.addCouple(other, { original: 'data:image/png;base64,Yw==' });
    const result = await core.deleteCouple(scope, a.id);
    assert.equal(result.deleted, true);
    assert.deepEqual([...(await core.readCouples(scope)).records.map(row => row.id)], [b.id]);
    assert.equal((await core.readCouples(other)).records.length, 1);
    assert.equal((await core.deleteCouple(scope, a.id)).deleted, false, 'deleting twice is harmless');
    await assert.rejects(core.updateCouple(scope, a.id, { favorite: true }), { code: 'RMT_COUPLE_MISSING' });
});

test('history cards and multi-select offer one confirmed delete; the open pair has no delete', () => {
    const ui = fs.readFileSync(path.join(root, 'src/ui/coupleAvatarView.js'), 'utf8');
    assert.match(ui, /button\('history-delete', '删除'/);
    assert.doesNotMatch(ui, /删除这一对'/, 'the open pair keeps its paired button grid; delete lives in history');
    assert.match(ui, /删除「\$\{names\}」这一对头像？/);
    assert.match(ui, /删除选中的 \$\{records\.length\} 对头像？/);
    assert.match(ui, /confirmExplicitAction\(title, [^]*destructive: true/);
    assert.match(ui, /couple\.deleteCouple\(view\.scope, record\.id\)/);
    for (const action of ['select-mode', 'history-toggle', 'select-page', 'select-clear', 'delete-selected']) assert.match(ui, new RegExp(`action === '${action}'`));
});
