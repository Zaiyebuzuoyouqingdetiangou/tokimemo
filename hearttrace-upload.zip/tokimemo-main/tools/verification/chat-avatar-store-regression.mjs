import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';

const root = path.resolve(process.env.TEST_ROOT || '.');
const source = await fs.readFile(path.join(root, 'src/core/chatAvatarStore.js'), 'utf8');
const PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j99kAAAAASUVORK5CYII=';
const plain = value => JSON.parse(JSON.stringify(value));

function storage(records = new Map()) {
    return { records, fail: false, failReads: false, failRemoves: false,
        getItem(key) { if (this.failReads) throw Error('read blocked'); return records.get(key) ?? null; },
        setItem(key, value) { if (this.fail) throw Error('quota'); records.set(key, value); },
        removeItem(key) { if (this.failRemoves) throw Error('remove blocked'); records.delete(key); } };
}

function indexedDB(records = new Map()) {
    const api = { records, failWrites: false, failReads: false, holdOpen: false, releaseOpen: null,
        open() {
            const request = {};
            const deliver = () => {
                const db = { objectStoreNames: { contains: () => true }, close() {},
                    transaction(_name, mode) {
                        const tx = { abort() { queueMicrotask(() => tx.onabort?.()); }, objectStore() {
                            return { get(key) {
                                const item = {}; queueMicrotask(() => {
                                    if (api.failReads) { item.onerror?.(); tx.onerror?.(); }
                                    else { item.result = records.get(key); item.onsuccess?.(); tx.oncomplete?.(); }
                                }); return item;
                            }, put(value) {
                                queueMicrotask(() => {
                                    if (api.failWrites) tx.onerror?.();
                                    else { records.set(value.scope, plain(value)); tx.oncomplete?.(); }
                                });
                            } };
                        } }; return tx;
                    } };
                request.result = db; request.onsuccess?.();
            };
            if (api.holdOpen) api.releaseOpen = deliver;
            else queueMicrotask(deliver);
            return request;
        } };
    return api;
}

async function setup(options = {}) {
    const context = options.host || { characterId: 0, name1: 'User', name2: 'Char', chatId: 'A',
        characters: [{ avatar: 'char.png', name: 'Char', data: { description: 'untouched' } }],
        userAvatar: 'persona.png', powerUserSettings: { persona_description: 'untouched' }, chatMetadata: {} };
    const events = [], local = options.local || storage(), idb = options.idb;
    const sb = { console, Promise, Map, Set, Symbol, Date, JSON, Object, Number, String, Error, document: options.document,
        atob, queueMicrotask, localStorage: local, indexedDB: idb,
        CustomEvent: class { constructor(type) { this.type = type; } },
        dispatchEvent(event) { events.push(event); }, SillyTavern: { getContext: () => context } };
    const realm = vm.createContext(sb);
    async function copy() {
        const mod = new vm.SourceTextModule(source, { context: realm });
        await mod.link(() => { throw Error('store must not import full runtime'); }); await mod.evaluate();
        return mod.namespace;
    }
    const api = await copy();
    const pair = { char: { name: 'Char', url: PNG }, user: { name: 'User', url: PNG } };
    return { api, context, realm, sb, events, local, idb, copy, pair,
        opts: () => ({ context, expectedScope: api.chatAvatarScope(context) }) };
}

test('scope isolates chat, character card, slot, user and available persona identity without mutation', async () => {
    const f = await setup(), before = plain(f.context), scope = f.api.chatAvatarScope(f.context);
    assert.ok(scope); assert.equal(f.api.chatAvatarScope({ ...f.context, groupId: 'G' }), '');
    assert.equal(f.api.chatAvatarScope({ ...f.context, chatId: '' }), '');
    assert.equal(f.api.chatAvatarScope({ ...f.context, characterId: null }), '');
    assert.equal(f.api.chatAvatarScope({ ...f.context, characterId: '' }), '');
    for (const delta of [{ chatId: 'B' }, { name1: 'Other' }, { name2: 'Another' },
        { userAvatar: 'different.png' }, { personaId: 'another-persona' }, { characterId: 1 },
        { characters: [{ avatar: 'other.png', name: 'Char' }] }]) {
        assert.notEqual(f.api.chatAvatarScope({ ...f.context, ...delta }), scope);
    }
    assert.deepEqual(plain(f.context), before);
});

test('valid pair commits atomically and can hydrate after realm restart without host mutations', async () => {
    const f = await setup(), before = plain(f.context);
    assert.equal(f.api.readChatAvatarSnapshot(f.context), null);
    const saved = await f.api.saveChatAvatarPair(f.pair, f.opts());
    assert.deepEqual(plain(saved.char), f.pair.char); assert.deepEqual(plain(saved.user), f.pair.user);
    assert.ok(Object.isFrozen(saved)); assert.ok(Object.isFrozen(saved.char));
    assert.deepEqual(plain(f.context), before);
    const restarted = await setup({ local: f.local, host: f.context });
    assert.deepEqual(plain(await restarted.api.loadChatAvatarSnapshot()), plain(saved));
    assert.ok(f.events.some(event => event.type === 'hearttrace:avatars-changed'));
    assert.ok(f.events.every(event => !('detail' in event)));
});

test('invalid or incomplete pair never saves either side or changes the confirmed cache', async () => {
    const f = await setup(); const saved = await f.api.saveChatAvatarPair(f.pair, f.opts());
    const count = f.events.length;
    for (const bad of ['javascript:alert(1)', 'https://example.test/a.png', 'data:image/svg+xml,<svg/>', 'data:image/png;base64,bm90cG5n']) {
        await assert.rejects(f.api.saveChatAvatarPair({ ...f.pair, user: { name: 'User', url: bad } }, f.opts()));
        assert.deepEqual(plain(f.api.readChatAvatarSnapshot()), plain(saved));
    }
    await assert.rejects(f.api.saveChatAvatarPair({ char: f.pair.char }, f.opts()));
    assert.equal(f.events.length, count);
});

test('real storage failure keeps the old pair and emits no false success', async () => {
    const idb = indexedDB(), f = await setup({ idb });
    const saved = await f.api.saveChatAvatarPair(f.pair, f.opts()); const count = f.events.length;
    f.local.fail = true; idb.failWrites = true;
    await assert.rejects(f.api.saveChatAvatarPair({ ...f.pair, char: { name: 'Updated', url: PNG } }, f.opts()), /保存|存储/);
    await assert.rejects(f.api.clearChatAvatarPair(f.opts()), /保存|存储/);
    assert.deepEqual(plain(f.api.readChatAvatarSnapshot()), plain(saved));
    assert.equal(f.events.length, count);
});

test('cold async hydrate and in-flight scope changes never expose another chat', async () => {
    const local = storage(); const seed = await setup({ local }); await seed.api.saveChatAvatarPair(seed.pair, seed.opts());
    const idb = indexedDB(); idb.holdOpen = true;
    const f = await setup({ local, idb }); const load = f.api.loadChatAvatarSnapshot();
    f.context.chatId = 'B'; idb.releaseOpen();
    assert.equal(await load, null); assert.equal(f.api.readChatAvatarSnapshot(), null);
    f.context.chatId = 'A'; assert.equal((await f.api.loadChatAvatarSnapshot()).char.name, 'Char');
});

test('scope changed while storage opens rejects before any durable write', async () => {
    const idb = indexedDB(); idb.holdOpen = true;
    const f = await setup({ idb }), opts = f.opts();
    const pending = f.api.saveChatAvatarPair(f.pair, opts);
    await Promise.resolve(); await Promise.resolve();
    f.context.chatId = 'B'; idb.releaseOpen();
    await assert.rejects(pending, /聊天|身份/);
    assert.equal(f.local.records.size, 0); assert.equal(idb.records.size, 0);
});

test('clear persists a newer tombstone and stale fallback records cannot resurrect the pair', async () => {
    const idb = indexedDB(), f = await setup({ idb });
    await f.api.saveChatAvatarPair(f.pair, f.opts());
    const stale = new Map(f.local.records);
    await f.api.clearChatAvatarPair(f.opts()); assert.equal(f.api.readChatAvatarSnapshot(), null);
    const restarted = await setup({ local: storage(stale), idb, host: f.context });
    assert.equal(await restarted.api.loadChatAvatarSnapshot(), null);
    const idbStale = indexedDB(new Map([[f.api.chatAvatarScope(f.context), plain(JSON.parse([...stale.values()][0]))]]));
    const restartedAgain = await setup({ local: f.local, idb: idbStale, host: f.context });
    assert.equal(await restartedAgain.api.loadChatAvatarSnapshot(), null);
});

test('separate bundled and lightweight module copies share state and the read-only bridge lifecycle', async () => {
    const f = await setup(), second = await f.copy();
    const cleanupA = f.api.installChatAvatarBridge(), bridge = f.sb.HearttraceAvatars;
    const cleanupB = second.installChatAvatarBridge();
    assert.equal(f.sb.HearttraceAvatars, bridge); assert.equal(bridge.apiVersion, 1);
    assert.ok(Object.isFrozen(bridge)); assert.equal(bridge.save, undefined);
    let calls = 0; const off = bridge.subscribe(() => { calls++; });
    bridge.subscribe(() => { throw Error('untrusted subscriber'); });
    const saved = await second.saveChatAvatarPair(f.pair, f.opts());
    assert.deepEqual(plain(bridge.getCurrent()), plain(saved));
    assert.deepEqual(plain(f.api.readChatAvatarSnapshot()), plain(saved)); assert.ok(calls);
    off(); const before = calls; await f.api.clearChatAvatarPair(f.opts()); assert.equal(calls, before);
    cleanupA(); assert.equal(f.sb.HearttraceAvatars, bridge);
    cleanupB(); assert.equal(f.sb.HearttraceAvatars, undefined);
});

test('external public API owner is not replaced or removed during cleanup', async () => {
    const f = await setup(), existing = { apiVersion: 99 }; f.sb.HearttraceAvatars = existing;
    const cleanup = f.api.installChatAvatarBridge(); assert.equal(f.sb.HearttraceAvatars, existing);
    cleanup(); assert.equal(f.sb.HearttraceAvatars, existing);
});

test('a database error falls back without deleting the previous pair when both stores reject writes', async () => {
    const idb = indexedDB(); idb.failWrites = true;
    const f = await setup({ idb });
    const first = await f.api.saveChatAvatarPair(f.pair, f.opts());
    assert.equal(idb.records.size, 0); assert.ok(f.local.records.size);
    const restarted = await setup({ idb, local: f.local, host: f.context });
    assert.deepEqual(plain(await restarted.api.loadChatAvatarSnapshot()), plain(first));
    f.local.fail = true;
    await assert.rejects(f.api.clearChatAvatarPair(f.opts()));
    const restartedAgain = await setup({ idb, local: f.local, host: f.context });
    assert.deepEqual(plain(await restartedAgain.api.loadChatAvatarSnapshot()), plain(first));
});

test('database-only success removes stale quota-blocked fallback and survives restart', async () => {
    const idb = indexedDB(), f = await setup({ idb });
    await f.api.saveChatAvatarPair(f.pair, f.opts()); f.local.fail = true;
    const pair = { ...f.pair, user: { name: 'Updated User', url: PNG } };
    const saved = await f.api.saveChatAvatarPair(pair, f.opts());
    assert.equal(f.local.records.size, 0);
    const restarted = await setup({ idb, local: f.local, host: f.context });
    assert.deepEqual(plain(await restarted.api.loadChatAvatarSnapshot()), plain(saved));
    await restarted.api.clearChatAvatarPair(restarted.opts());
    assert.equal(await (await setup({ idb, local: f.local, host: f.context })).api.loadChatAvatarSnapshot(), null);
});

test('concurrent save and restore serialize without reviving older pending writes', async () => {
    const f = await setup(), opts = f.opts();
    const first = f.api.saveChatAvatarPair(f.pair, opts);
    const second = f.api.saveChatAvatarPair({ ...f.pair, user: { name: 'Second', url: PNG } }, opts);
    const clear = f.api.clearChatAvatarPair(opts);
    const [a, b, restored] = await Promise.all([first, second, clear]);
    assert.ok(b.revision > a.revision); assert.equal(restored, null);
    assert.equal(f.api.readChatAvatarSnapshot(), null);
    const restarted = await setup({ local: f.local, host: f.context });
    assert.equal(await restarted.api.loadChatAvatarSnapshot(), null);
});

test('read-only bridge synchronously hides cached data after same-name card/persona changes', async () => {
    const f = await setup(); f.api.installChatAvatarBridge();
    await f.api.saveChatAvatarPair(f.pair, f.opts());
    const before = plain(f.context);
    f.context.characters[0].avatar = 'same-name-other-card.png';
    assert.equal(f.sb.HearttraceAvatars.getCurrent(), null);
    f.context.characters[0].avatar = before.characters[0].avatar;
    assert.ok(f.sb.HearttraceAvatars.getCurrent());
    f.context.userAvatar = 'same-name-other-persona.png';
    assert.equal(f.sb.HearttraceAvatars.getCurrent(), null);
    f.context.userAvatar = before.userAvatar;
    assert.ok(f.sb.HearttraceAvatars.getCurrent());
});

test('same-name Personas use the live selected DOM avatar when the host context omits it', async () => {
    let selected = 'first-persona.png';
    const document = { querySelector(selector) {
        assert.equal(selector, '#user_avatar_block .avatar-container.selected');
        return { getAttribute(key) { assert.equal(key, 'data-avatar-id'); return selected; } };
    } };
    const f = await setup({ document }); delete f.context.userAvatar;
    const before = plain(f.context), firstScope = f.api.chatAvatarScope(f.context);
    f.api.installChatAvatarBridge(); await f.api.saveChatAvatarPair(f.pair, f.opts());
    selected = 'same-name-different-persona.png';
    assert.notEqual(f.api.chatAvatarScope(f.context), firstScope);
    assert.equal(f.sb.HearttraceAvatars.getCurrent(), null);
    selected = 'first-persona.png'; assert.ok(f.sb.HearttraceAvatars.getCurrent());
    assert.deepEqual(plain(f.context), before);
});

test('context Persona outranks DOM selection and locked chat Persona is only the last fallback', async () => {
    let selected = 'selected.png';
    const document = { querySelector() { return { getAttribute() { return selected; } }; } };
    const f = await setup({ document }); f.context.chatMetadata.persona = 'locked.png';
    const contextScope = f.api.chatAvatarScope(f.context);
    selected = 'different-selected.png'; assert.equal(f.api.chatAvatarScope(f.context), contextScope);
    delete f.context.userAvatar;
    const selectedScope = f.api.chatAvatarScope(f.context);
    f.context.chatMetadata.persona = 'different-locked.png';
    assert.equal(f.api.chatAvatarScope(f.context), selectedScope);
    selected = '';
    const lockedScope = f.api.chatAvatarScope(f.context);
    assert.notEqual(lockedScope, selectedScope);
    f.context.chatMetadata.persona = 'another-locked.png';
    assert.notEqual(f.api.chatAvatarScope(f.context), lockedScope);
    assert.equal(f.api.chatAvatarScope(f.context, null), f.api.chatAvatarScope(f.context));
});

test('returning to an already cached chat notifies consumers without recursive getCurrent loops', async () => {
    const f = await setup(); f.api.installChatAvatarBridge();
    const a = await f.api.saveChatAvatarPair(f.pair, f.opts());
    f.context.chatId = 'B';
    const b = await f.api.saveChatAvatarPair({ ...f.pair, user: { name: 'B User', url: PNG } }, f.opts());
    await Promise.resolve();
    const seen = [], bridge = f.sb.HearttraceAvatars;
    bridge.subscribe(() => { seen.push(bridge.getCurrent()?.scope || ''); });
    f.context.chatId = 'A'; assert.equal(bridge.getCurrent().scope, a.scope);
    assert.equal(seen.length, 0, 'identity notification is deferred to avoid re-entry');
    await Promise.resolve(); assert.deepEqual(seen, [a.scope]);
    f.context.chatId = 'B'; assert.equal((await bridge.refresh()).scope, b.scope);
    await Promise.resolve(); assert.deepEqual(seen, [a.scope, b.scope]);
    f.context.characterId = null; assert.equal(bridge.getCurrent(), null);
    await Promise.resolve(); assert.deepEqual(seen, [a.scope, b.scope, '']);
});

test('same-name selected Persona changes notify subscribers when a native display reads the new scope', async () => {
    let selected = 'first.png';
    const f = await setup({ document: { querySelector: () => ({ getAttribute: () => selected }) } });
    delete f.context.userAvatar; f.api.installChatAvatarBridge();
    const a = await f.api.saveChatAvatarPair(f.pair, f.opts());
    selected = 'second.png'; const b = await f.api.saveChatAvatarPair(f.pair, f.opts());
    await Promise.resolve();
    const seen = []; f.sb.HearttraceAvatars.subscribe(() => { seen.push(f.sb.HearttraceAvatars.getCurrent()?.scope || ''); });
    selected = 'first.png'; assert.equal(f.api.readChatAvatarSnapshot().scope, a.scope);
    await Promise.resolve(); assert.deepEqual(seen, [a.scope]);
    selected = 'second.png'; assert.equal(f.api.readChatAvatarSnapshot().scope, b.scope);
    await Promise.resolve(); assert.deepEqual(seen, [a.scope, b.scope]);
});

test('a captured old context cannot read or write after the host replaces its context object', async () => {
    const f = await setup(), opts = f.opts();
    await f.api.saveChatAvatarPair(f.pair, opts);
    const persisted = [...f.local.records.entries()];
    f.sb.SillyTavern.getContext = () => ({ ...f.context, chatId: 'new-host-chat' });
    assert.equal(f.api.readChatAvatarSnapshot(f.context), null);
    assert.equal(await f.api.loadChatAvatarSnapshot(f.context), null);
    await assert.rejects(f.api.saveChatAvatarPair(f.pair, opts), /聊天|身份/);
    await assert.rejects(f.api.clearChatAvatarPair(opts), /聊天|身份/);
    assert.deepEqual([...f.local.records.entries()], persisted);
});

test('restore reports incomplete persistence when a committed tombstone cannot replace or remove the stale fallback', async () => {
    const idb = indexedDB(), f = await setup({ idb });
    await f.api.saveChatAvatarPair(f.pair, f.opts());
    f.local.fail = true; f.local.failRemoves = true;
    await assert.rejects(f.api.clearChatAvatarPair(f.opts()), error => {
        assert.match(error.message, /未能完整保存/);
        assert.doesNotMatch(error.message, /原头像已保留/);
        return true;
    });
    assert.equal(f.api.readChatAvatarSnapshot(), null, 'current session follows the successfully committed tombstone');
    assert.equal(idb.records.get(f.api.chatAvatarScope(f.context)).deleted, true);
    assert.equal(JSON.parse([...f.local.records.values()][0]).deleted, undefined, 'fault actually retains the old fallback');
    await assert.rejects(f.api.loadChatAvatarSnapshot(), /未能完整保存/, 'restore UI cannot report completion while a known conflict remains');
    assert.equal(f.api.readChatAvatarSnapshot(), null, 'failed reconciliation does not roll back the committed display');
});

test('apply reports incomplete persistence while exposing the primary committed pair and can reconcile on retry', async () => {
    const idb = indexedDB(), f = await setup({ idb });
    await f.api.saveChatAvatarPair(f.pair, f.opts());
    f.local.fail = true; f.local.failRemoves = true;
    const next = { ...f.pair, char: { name: 'Updated Char', url: PNG } };
    await assert.rejects(f.api.saveChatAvatarPair(next, f.opts()), /未能完整保存/);
    assert.deepEqual(plain(f.api.readChatAvatarSnapshot().char), next.char);
    f.local.fail = false; f.local.failRemoves = false;
    const saved = await f.api.saveChatAvatarPair(next, f.opts());
    idb.failReads = true;
    const restarted = await setup({ local: f.local, idb, host: f.context });
    assert.deepEqual(plain(await restarted.api.loadChatAvatarSnapshot()), plain(saved));
});

test('refresh repairs an old fallback after partial restore before a later offline restart', async () => {
    const idb = indexedDB(), f = await setup({ idb });
    await f.api.saveChatAvatarPair(f.pair, f.opts());
    f.local.fail = true; f.local.failRemoves = true;
    await assert.rejects(f.api.clearChatAvatarPair(f.opts()), /未能完整保存/);
    f.local.fail = false; f.local.failRemoves = false;
    assert.equal(await f.api.loadChatAvatarSnapshot(), null);
    idb.failReads = true;
    const restarted = await setup({ local: f.local, idb, host: f.context });
    assert.equal(await restarted.api.loadChatAvatarSnapshot(), null, 'repaired local storage cannot revive the restored pair');
});

test('database-only save still succeeds when no stale fallback exists despite blocked local writes and removals', async () => {
    const local = storage(); local.fail = true; local.failRemoves = true;
    const idb = indexedDB(), f = await setup({ local, idb });
    const saved = await f.api.saveChatAvatarPair(f.pair, f.opts());
    assert.deepEqual(plain(saved.char), f.pair.char);
    assert.equal(local.records.size, 0);
    assert.equal(await f.api.clearChatAvatarPair(f.opts()), null);
});

test('unknown fallback state cannot be reported as complete when its update and cleanup both fail', async () => {
    const idb = indexedDB(), f = await setup({ idb });
    await f.api.saveChatAvatarPair(f.pair, f.opts());
    f.local.fail = true; f.local.failReads = true; f.local.failRemoves = true;
    await assert.rejects(f.api.clearChatAvatarPair(f.opts()), /未能完整保存/);
    assert.equal(f.api.readChatAvatarSnapshot(), null);
    f.local.failReads = false; f.local.failRemoves = false;
    assert.equal(await f.api.clearChatAvatarPair(f.opts()), null, 'successful removal remains enough even while local writes still fail');
    assert.equal(f.local.records.size, 0);
});

test('known incomplete restore remains pending when fallback reads start failing until cleanup is verified', async () => {
    const idb = indexedDB(), f = await setup({ idb });
    await f.api.saveChatAvatarPair(f.pair, f.opts());
    f.local.fail = true; f.local.failRemoves = true;
    await assert.rejects(f.api.clearChatAvatarPair(f.opts()), /未能完整保存/);
    f.local.failReads = true;
    await assert.rejects(f.api.loadChatAvatarSnapshot(), /未能完整保存/, 'a failed read cannot erase an already known conflict');
    assert.equal(f.api.readChatAvatarSnapshot(), null);
    idb.failReads = true;
    await assert.rejects(f.api.loadChatAvatarSnapshot(), /未能完整保存/, 'losing both reads cannot turn partial persistence into success');
    idb.failReads = false; f.local.failRemoves = false;
    assert.equal(await f.api.loadChatAvatarSnapshot(), null, 'verified removal resolves the conflict even while reads and writes remain blocked');
    assert.equal(f.local.records.size, 0);
    assert.equal(await f.api.loadChatAvatarSnapshot(), null, 'unknown reads alone do not recreate a resolved conflict');
});
