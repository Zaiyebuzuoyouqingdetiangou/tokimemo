import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture, realClient } from './fixture.mjs';
import { ui } from './mv-ui-fixture.mjs';

const plain = value => JSON.parse(JSON.stringify(value));
const song = { id: 'SONG_cast', title: '归途', bpm: 76, styleDescription: '抒情民谣，钢琴与弦乐，舒缓',
    lyrics: '[Verse 1]\n月光落在空荡的窗\n旧信留着未干的墨\n[Chorus]\n我们沿着长街回家\n[End]' };
const cast = { version: 1, cardType: 'multi', revision: '', selectedIds: ['a', 'b', 'c'], people: [
    { id: 'a', name: '甲', sourceRefs: [{ world: '人物', uid: '1', title: '兄弟', content: '甲：黑发金眼。乙：白发蓝眼。' }] },
    { id: 'b', name: '乙', sourceRefs: [{ world: '人物', uid: '1', title: '兄弟', content: '甲：黑发金眼。乙：白发蓝眼。' }] },
    { id: 'c', name: '丙', sourceRefs: [] },
], appearances: [{ participantId: 'a', tag: 'black hair, golden eyes', manual: true }, { participantId: 'b', tag: 'white hair, blue eyes', manual: true }] };
function raw(index = 0) { return { groups: [{ id: 'G1', composition: '递伞', characterPrompt: '甲 hands an umbrella to 乙 in the same scene',
    cast: [{ participantId: 'a', position: 'left', action: 'hands the umbrella to 乙' }, { participantId: 'b', position: 'right', action: 'receives the umbrella from 甲' }],
    diffs: [{ id: 'D1', label: '递伞', change: 'the hands meet at the handle' }], bgs: [{ id: 'B1', prompt: 'rainy street' }] }],
    frames: [{ sectionIndex: index, lyric: index ? '我们沿着长街回家' : '月光落在空荡的窗', group: 'G1', diff: 'D1', bg: 'B1' }] }; }
async function setup() {
    const f = await fixture();
    f.get('core/cache').loadSession = () => ({ songs: [song] });
    f.get('core/cache').readParticipantRoster = () => f.json(cast);
    return { ...f, mv: f.get('extras/mv'), castApi: f.get('extras/mvCast'), direction: f.get('extras/mvDirection') };
}

test('song recommendations rank lyrical, impact, interaction, loop and reveal from meaningful evidence', async () => {
    const f = await setup();
    assert.equal(typeof f.direction?.recommendDirections, 'function');
    assert.equal(f.direction.recommendDirections(song)[0].id, 'lyrical');
    assert.equal(f.direction.recommendDirections({ bpm: 172, stylePrompt: 'fast energetic metal rock battle anthem' })[0].id, 'impact');
    assert.equal(f.direction.recommendDirections({ voice: 'duet', styleDescription: '双人对唱，应答与互动' })[0].id, 'interaction');
    assert.equal(f.direction.recommendDirections({ bpm: 126, stylePrompt: 'electronic dance loop', lyrics: 'again\nagain\nagain' })[0].id, 'loop');
    assert.equal(f.direction.recommendDirections({ styleDescription: '悬疑，反转，不可靠叙述' })[0].id, 'reveal');
    assert.equal(f.direction.recommendDirections({})[0].id, 'auto');
    assert.ok(f.direction.recommendDirections(song)[0].reasons.length);
});

test('three selected NPCs are kept independently of user visibility; one frame uses only its two named actors', async () => {
    const f = await setup();
    const settings = f.mv.normalizeSettings({ storyType: 'interaction', appear: 'none' });
    assert.equal(settings.storyType, 'interaction');
    const built = f.mv.buildShots(raw(), f.bank, 2, settings, f.json(cast));
    assert.deepEqual(plain(built.groups[0].cast.map(p => p.participantId)), ['a', 'b']);
    const record = { ...built, settings, cast: f.json(cast), wardrobe: {} };
    const prompt = f.mv.assetPrompt(record, 'G1:D1', f.host);
    assert.match(prompt, /甲/); assert.match(prompt, /乙/);
    assert.match(prompt, /black hair/); assert.match(prompt, /white hair/);
    assert.doesNotMatch(prompt, /丙|solo, single figure/);
});

test('worldbook cast source is supplied once, with stable person bindings and no card-as-person instruction', async () => {
    const f = await setup(); let request = '';
    f.get('generation/client').requestJson = async p => { request = p; return raw(); };
    const result = await f.mv.generateStoryboard(song.id, { storyType: 'lyrical' }, f.json(cast));
    assert.equal(result.pending, false);
    assert.equal(request.split('甲：黑发金眼。乙：白发蓝眼。').length - 1, 1);
    assert.match(request, /participantId/); assert.match(request, /抒情意象/);
    assert.doesNotMatch(request, /Char 是主角|衣着必须明显不同/);
    assert.equal(f.mv.readMv(f.host, song.id).cast.people.length, 3);
});

test('opening recommendation controls and editing type never calls text/image providers', async () => {
    const f = await ui(setup); let requests = 0;
    f.get('core/cache').loadSession = () => ({ songs: [song] });
    f.get('core/cache').readParticipantRoster = () => f.json(cast);
    f.get('generation/client').requestJson = async () => { requests++; return raw(); };
    f.get('generation/cgImageCore').invokeImageGeneration = async () => { requests++; return '/user/images/fake.png'; };
    f.mvui.openMv({ songId: song.id }); f.click('setup-next');
    assert.match(f.body.innerHTML, /分镜类型/); assert.match(f.body.innerHTML, /抒情意象/);
    f.mvui.handleMvChange({ target: { matches: s => s === '[data-rmt-mv-story-type]', value: 'impact', dataset: {} } });
    assert.match(f.body.innerHTML, /value="impact" selected/);
    assert.equal(requests, 0);
});

async function generated() {
    const f = await setup();
    realClient(f, () => raw());
    await f.mv.generateStoryboard(song.id, { storyType: 'interaction', range: 'custom', rangeFrom: 0, rangeTo: 0 }, f.json(cast));
    return f;
}
const defer = () => { let resolve; const promise = new Promise(r => { resolve = r; }); return { promise, resolve }; };

test('storyboard JSON examples use real participant IDs in both image and video modes', async () => {
    for (const output of ['tegaki', 'video']) {
        const f = await setup(); let prompt = '';
        f.get('generation/client').requestJson = async p => { prompt = p; return output === 'video' ? { shots: [{ sectionIndex: 0, plain: '甲递伞给乙', cast: raw().groups[0].cast }] } : raw(); };
        const result = await f.mv.generateStoryboard(song.id, { output }, f.json(cast));
        assert.equal(result.pending, false);
        const example = JSON.parse(prompt.split('\n').at(-1));
        assert.equal((example.groups || example.shots)[0].cast[0].participantId, 'a');
        assert.equal(example.wardrobe.characters[0].participantId, 'a');
        assert.equal(example.wardrobe.char, undefined);
    }
});

test('same-name NPCs retain separate identity, appearance and provider labels without renaming saved people', async () => {
    const f = await setup(), roster = plain(cast);
    roster.people[1].name = '甲';
    const record = { cast: roster, wardrobe: {} }, shot = { cast: raw().groups[0].cast };
    const metadata = f.castApi.castMetadata(record, shot);
    assert.deepEqual(plain(metadata.castSnapshot.people.map(p => p.name)), ['甲 [a]', '甲 [b]']);
    assert.match(f.castApi.castVisual(record, shot), /甲 \[b\].*white hair/);
    assert.equal(roster.people[1].name, '甲');
    const ambiguous = f.castApi.bindShotCast({ cast: [{ name: '甲' }] }, roster);
    assert.equal(ambiguous.castUnresolved, true); assert.equal(ambiguous.cast.length, 0);
});

test('user visibility filters only explicit user identity, never NPCs sharing the persona name', async () => {
    const f = await setup(), roster = plain(cast);
    roster.people[0].name = f.host.name1;
    roster.people.push({ id: 'u', name: f.host.name1, identity: 'user', sourceRefs: [] }); roster.selectedIds.push('u');
    const input = { cast: ['a', 'b', 'u'] };
    assert.deepEqual(plain(f.castApi.bindShotCast(input, roster, { appear: 'none' }).cast.map(p => p.participantId)), ['a', 'b']);
    const back = f.castApi.bindShotCast(input, roster, { appear: 'back' }).cast;
    assert.equal(back[0].visible, 'full'); assert.equal(back[2].visible, 'back');
});

test('explicit empty cast stays an empty landscape; missing cast remains repairable, not a generation gate', async () => {
    const f = await setup(), input = raw(); input.groups[0].cast = [];
    input.groups[0].characterPrompt = 'empty street'; input.groups[0].diffs[0].change = 'rain';
    const built = f.mv.buildShots(input, f.bank, 2, {}, f.json(cast));
    assert.match(f.mv.assetPrompt({ ...built, cast, settings: {} }, 'G1:D1', f.host), /no humans/);
    assert.doesNotMatch(f.mv.assetPrompt({ ...built, cast, settings: {} }, 'G1:D1', f.host), /black hair|white hair|solo/);
    delete input.groups[0].cast;
    const missing = f.mv.buildShots(input, f.bank, 2, {}, f.json(cast));
    assert.equal(missing.groups[0].castUnresolved, true); assert.equal(missing.shots.length, 1);
});

test('model name fallback binds only a unique name and unknown IDs warn without dropping valid cast', async () => {
    const f = await setup();
    const bound = f.castApi.bindShotCast({ cast: [{ name: '乙' }, { participantId: 'invented' }] }, cast);
    assert.deepEqual(plain(bound.cast.map(p => p.participantId)), ['b']); assert.equal(bound.castUnresolved, true);
});

test('one person can keep multiple worldbook sources and deselection preserves paid old-shot identities', async () => {
    const f = await setup(), next = plain(cast);
    next.people[0].sourceRefs.push({ world: '服装', uid: '9', title: '衣着', content: '黑色长袍' });
    next.selectedIds = ['a'];
    const merged = f.castApi.mergeMvCast(cast, next);
    assert.equal(merged.people[0].sourceRefs.length, 2); assert.equal(merged.people.length, 3);
    assert.equal(f.castApi.shotPeople({ cast: merged }, { cast: [{ participantId: 'b' }] })[0].name, '乙');
});

test('no new actor count cap: 24 identities and appearances survive multi-character and flat provider preparation', async () => {
    const f = await setup(), roster = { version: 1, cardType: 'multi', revision: '', people: [], selectedIds: [], appearances: [] };
    for (let i = 0; i < 24; i++) { const id = `p${i}`; roster.people.push({ id, name: `Actor${i}`, sourceRefs: [] }); roster.selectedIds.push(id); roster.appearances.push({ participantId: id, tag: `mark${i}` }); }
    const record = { cast: f.castApi.normalizeMvCast(roster) }, shot = { cast: roster.selectedIds.map(participantId => ({ participantId, visible: 'full' })) };
    const meta = f.get('generation/cgAppearance').normalizeCgPromptMetadata(f.castApi.castMetadata(record, shot));
    assert.equal(meta.characters.length, 24);
    const flat = f.get('generation/cgAppearance').cgPreparedVisualPrompt(f.castApi.castVisual(record, shot, { appearance: false }), meta);
    assert.match(flat, /Actor23.*mark23/); assert.match(flat, /24 people/);
});

test('hands-only framing does not append face, hair, wardrobe or full-body framing', async () => {
    const f = await setup(), input = raw(), roster = plain(cast);
    roster.appearances[0].tag = 'black hair, golden eyes, pale skin, slender fingers';
    input.groups[0].cast = [{ participantId: 'a', visible: 'hands', action: 'ties a knot' }];
    input.groups[0].scale = 'full'; input.groups[0].characterPrompt = 'hands tying string';
    const record = { ...f.mv.buildShots(input, f.bank, 2, {}, roster), cast: roster, wardrobe: { characters: [{ participantId: 'a', clothing: 'red coat' }] } };
    const prompt = f.mv.assetPrompt(record, 'G1:D1', f.host);
    assert.match(prompt, /pale skin|slender fingers/); assert.match(prompt, /only hands/);
    assert.doesNotMatch(prompt, /black hair|golden eyes|red coat|full body shot/);
});

test('missing appearance is allowed; generated appearance cannot overwrite manual facts or create strangers', async () => {
    const f = await setup();
    const result = f.castApi.generatedMvCast(cast, { appearances: [{ participantId: 'a', tag: 'green hair' }, { participantId: 'c', tag: 'brown hair' }, { participantId: 'ghost', tag: 'blue hair' }] });
    assert.equal(result.appearances.find(p => p.participantId === 'a').tag, 'black hair, golden eyes');
    assert.equal(result.appearances.find(p => p.participantId === 'c').tag, 'brown hair'); assert.equal(result.appearances.length, 3);
    assert.equal(f.castApi.generatedMvCast({ ...cast, appearances: [] }, {}).appearances.length, 0);
});

test('song-owned cast and type survive reload and stay isolated from another song and chat', async () => {
    const f = await generated();
    f.get('core/cache').loadSession = () => ({ songs: [song, { ...song, id: 'SONG_other' }] });
    f.mv.saveMvCast('SONG_other', { ...cast, selectedIds: ['c'] });
    assert.deepEqual(plain(f.mv.readMv(f.host, song.id).cast.selectedIds), ['a', 'b', 'c']);
    const g = await setup(); for (const [k, v] of f.disk) g.disk.set(k, v);
    assert.equal(g.mv.readMv(g.host, song.id).settings.storyType, 'interaction');
    assert.equal(g.mv.readMv(g.host, song.id).cast.people[0].sourceRefs[0].content, cast.people[0].sourceRefs[0].content);
    const other = { ...f.host, chatId: 'B', chatMetadata: { [f.constants.MEMORY_KEY]: { ...f.bank, chatId: 'B' } } };
    f.switchTo(other); assert.equal(f.mv.readMv(other, song.id), null);
});

test('continuation freezes per-song cast despite archive edits, keeps images and clothing, and adds only missing sections', async () => {
    const f = await generated();
    f.mv.writeMv(f.mv.mvScope(f.host), song.id, r => { r.groups[0].diffs[0].image = { url: '/user/images/old.png' }; return r; });
    f.mv.patchWardrobe(song.id, { characters: [{ participantId: 'a', clothing: 'original robe' }] });
    f.mv.patchTegaki(song.id, { range: 'full' });
    const old = plain(f.mv.readMv(f.host, song.id)); let prompt = '';
    f.get('core/cache').readParticipantRoster = () => ({ ...cast, people: [{ id: 'alien', name: 'ALIEN_NEW_CARD', sourceRefs: [] }], selectedIds: ['alien'] });
    f.get('generation/client').requestJson = async p => { prompt = p; return { ...raw(1), wardrobe: { characters: [{ participantId: 'a', clothing: 'changed robe' }] } }; };
    const result = await f.mv.continueStoryboard(song.id); assert.equal(result.pending, false);
    const end = f.mv.readMv(f.host, song.id);
    assert.deepEqual(plain(end.groups[0]), old.groups[0]); assert.equal(end.shots.length, 2);
    assert.equal(end.wardrobe.characters[0].clothing, 'original robe'); assert.doesNotMatch(prompt, /ALIEN_NEW_CARD/);
    assert.deepEqual(plain(end.shots[1].cast.map(p => p.participantId)), ['a', 'b']);
});

test('editing cast during a paid request holds its response for save-only retry instead of overwriting the edit', async () => {
    const f = await generated(), before = plain(f.mv.readMv(f.host, song.id)), d = defer(); let calls = 0;
    f.get('generation/client').requestJson = () => { calls++; return d.promise; };
    const work = f.mv.generateStoryboard(song.id, before.settings);
    f.mv.saveMvCast(song.id, { ...cast, selectedIds: ['c'] }); d.resolve(raw());
    const result = await work; assert.equal(result.pending, true);
    assert.deepEqual(plain(f.mv.readMv(f.host, song.id).cast.selectedIds), ['c']);
    f.mv.saveMvCast(song.id, before.cast);
    assert.equal((await f.mv.retryMvSave(result.scope, result.id)).pending, false); assert.equal(calls, 1);
});

test('chat switch journals new cast response and fresh-runtime save-only recovery preserves IDs', async () => {
    const f = await setup(); let calls = 0;
    realClient(f, () => { calls++; f.switchTo({ ...f.host, chatId: 'B', chatMetadata: { [f.constants.MEMORY_KEY]: { ...f.bank, chatId: 'B' } } }); return raw(); });
    const result = await f.mv.generateStoryboard(song.id, {}, f.json(cast)); assert.equal(result.pending, true);
    const g = await setup(); for (const [k, v] of f.disk) g.disk.set(k, v);
    assert.equal((await g.mv.retryMvSave(result.scope, result.id)).pending, false);
    assert.deepEqual(plain(g.mv.readMv(g.host, song.id).groups[0].cast.map(p => p.participantId)), ['a', 'b']); assert.equal(calls, 1);
});

test('draw failure sends no automatic extra request and preserves an already-paid asset', async () => {
    const f = await generated(); let calls = 0;
    f.mv.writeMv(f.mv.mvScope(f.host), song.id, r => { r.groups[0].diffs[0].image = { url: '/user/images/old.png' }; return r; });
    f.get('generation/cgImageCore').invokeImageGeneration = async () => { calls++; throw Error('backend unavailable'); };
    await assert.rejects(f.mv.drawAsset(song.id, 'G1:D1'), /backend unavailable/);
    assert.equal(calls, 1); assert.equal(f.mv.readMv(f.host, song.id).groups[0].diffs[0].image.url, '/user/images/old.png');
});

test('draw delivers scene and matched appearance metadata without duplicating lorebook bodies in image prompt', async () => {
    const f = await generated(); let captured;
    f.get('generation/cgImageCore').invokeImageGeneration = async (prompt, context, options) => { captured = { prompt, options }; return '/user/images/new.png'; };
    assert.equal((await f.mv.drawAsset(song.id, 'G1:D1')).pending, false);
    assert.match(captured.prompt, /甲.*left/); assert.match(captured.prompt, /乙.*right/);
    assert.doesNotMatch(captured.prompt, /甲：黑发金眼|black hair/);
    assert.deepEqual(plain(captured.options.promptMetadata.characters.map(p => p.participantId)), ['a', 'b']);
    assert.equal(captured.options.promptMetadata.characters[1].tag, 'white hair, blue eyes');
});

test('manual shot binding keeps assets and edits all reused frames of that composition', async () => {
    const f = await generated();
    f.mv.writeMv(f.mv.mvScope(f.host), song.id, r => { r.groups[0].diffs[0].image = { url: '/user/images/old.png' }; r.shots.push({ ...r.shots[0], id: 'again' }); return r; });
    f.mv.patchMvShotCast(song.id, 'G1', [{ participantId: 'c', position: 'center', action: 'looks up', visible: 'back' }]);
    const end = f.mv.readMv(f.host, song.id); assert.equal(end.groups[0].diffs[0].image.url, '/user/images/old.png');
    assert.ok(end.shots.every(s => s.cast[0].participantId === 'c')); assert.equal(end.groups[0].cast[0].visible, 'back');
});

test('cast editor uses song-only snapshot, and late picker confirmation after chat switch is rejected', async () => {
    const f = await ui(generated); let picker;
    f.get('ui/participantPicker').showParticipantPicker = async options => { picker = options; };
    f.mvui.openMv({ songId: song.id }); f.click('edit-cast');
    assert.equal(picker.selectionLabel, '用于本曲');
    assert.equal(picker.onConfirm({ ...cast, selectedIds: ['b'] }), true);
    assert.deepEqual(plain(f.mv.readMv(f.host, song.id).cast.selectedIds), ['b']);
    assert.equal(f.get('core/cache').readParticipantRoster().selectedIds.length, 3);
    f.click('edit-cast');
    f.switchTo({ ...f.host, chatId: 'B', chatMetadata: { [f.constants.MEMORY_KEY]: { ...f.bank, chatId: 'B' } } });
    assert.equal(picker.onConfirm(cast), false); f.mvui.disposeMv();
});

test('stale picker cannot overwrite newer per-song appearance edits', async () => {
    const f = await generated(), target = f.mv.captureMvTarget(f.host, song.id), before = JSON.stringify(f.mv.readMv(f.host, song.id).cast);
    const next = plain(cast); next.appearances[0].tag = 'manual updated look'; f.mv.saveMvCast(song.id, next);
    assert.throws(() => f.mv.saveMvCast(song.id, cast, target, before), /已有新修改/);
    assert.equal(f.mv.readMv(f.host, song.id).cast.appearances[0].tag, 'manual updated look');
});

test('persona is added only explicitly and adding it twice never duplicates or reclassifies an NPC', async () => {
    const f = await setup(); f.host.getCharacterCardFields = () => ({ persona: '用户有棕色头发' });
    const first = f.castApi.addMvUser(f.host, cast), second = f.castApi.addMvUser(f.host, first);
    assert.equal(first.people.length, 4); assert.equal(second.people.length, 4);
    assert.equal(second.people.filter(p => p.identity === 'user').length, 1);
    assert.equal(second.people.at(-1).sourceRefs[0].content, '用户有棕色头发');
});

test('loop reuses paid asset keys and fractional short-shot weights survive timeline building', async () => {
    const f = await setup(), input = raw(); input.frames = [0.25, 0.75].map(hold => ({ ...input.frames[0], hold }));
    const built = f.mv.buildShots(input, f.bank, 1, { storyType: 'loop' }, cast);
    const record = { ...built, duration: 8, settings: { storyType: 'loop' } }, one = { ...song, bpm: 120, lyrics: '[Verse]\n一句歌词\n[End]' };
    assert.equal(f.mv.assetKeys(record).length, 1);
    const timeline = f.mv.shotTimeline(record, one); assert.equal(timeline.rows[1].start, 2); assert.equal(timeline.rows[1].end, 8);
    record.settings.storyType = 'lyrical'; assert.deepEqual(plain(f.mv.shotTimeline(record, one)), plain(timeline));
});

test('manual nonrecommended type is accepted and malformed recommendation metadata never becomes a gate', async () => {
    const f = await setup();
    assert.equal(f.mv.normalizeSettings({ storyType: 'reveal' }).storyType, 'reveal');
    assert.equal(f.mv.normalizeSettings({ storyType: 'unsupported-old-value' }).storyType, 'auto');
    assert.equal(f.direction.recommendDirections({ bpm: Infinity })[0].id, 'auto');
    assert.doesNotMatch(f.direction.directionPrompt('lyrical', song), /悬念反转|静态关键姿势剪辑/);
});

test('UI escapes names, IDs and actions, and keeps all style options selectable without percentages', async () => {
    const f = await setup(), controls = f.get('ui/mvCastControls'), roster = plain(cast);
    roster.people[0].name = '<img src=x onerror=alert(1)>';
    const html = controls.castControls(roster, {});
    assert.doesNotMatch(html, /<img/); assert.match(html, /&lt;img/);
    const types = controls.directionControls(song, { storyType: 'reveal' });
    assert.equal((types.match(/<option /g) || []).length, 8); assert.match(types, /value="reveal" selected/); assert.doesNotMatch(types, /\d+%/);
});

test('real public image adapter forwards names and looks to character and flat backends without changing user settings', async () => {
    for (const supportsCharacters of [true, false]) {
        const f = await generated(); let request;
        f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS, imageGenerationProvider: 'baibai-image', imageGenerationFallback: false });
        f.sb.STBaiBaiImage = { apiVersion: 1, capabilities: { generate: true, saveToGallery: true },
            getBackendStatus: () => ({ configured: true, backend: 'nai', supportsCharacters }),
            generate: async value => { request = value; return { path: '/user/images/adapter.png' }; } };
        const result = await f.mv.drawAsset(song.id, 'G1:D1'); assert.equal(result.pending, false);
        if (supportsCharacters) {
            assert.deepEqual(plain(request.characters.map(p => [p.name, p.tag])), [['甲', 'black hair, golden eyes'], ['乙', 'white hair, blue eyes']]);
        } else {
            assert.equal(request.characters, undefined); assert.match(request.prompt, /甲.*black hair/); assert.match(request.prompt, /乙.*white hair/);
        }
        assert.match(request.prompt, /left/); assert.match(request.prompt, /right/);
        assert.doesNotMatch(JSON.stringify(request), /兄弟|甲：黑发金眼/);
    }
});

test('back-only persona setting still permits hand and silhouette crops', async () => {
    const f = await setup(), roster = f.castApi.addMvUser(f.host, cast), id = roster.people.at(-1).id;
    for (const visible of ['hands', 'silhouette', 'back']) {
        const result = f.castApi.bindShotCast({ cast: [{ participantId: id, visible }] }, roster, { appear: 'back' });
        assert.equal(result.cast[0].visible, visible);
    }
});

test('empty scene cannot inherit full-body framing from a model group default', async () => {
    const f = await setup(), input = raw(); input.groups[0].cast = []; input.groups[0].scale = 'full';
    input.groups[0].characterPrompt = 'empty room'; input.groups[0].diffs[0].change = 'light changes';
    const record = { ...f.mv.buildShots(input, f.bank, 2, {}, cast), cast };
    assert.doesNotMatch(f.mv.assetPrompt(record, 'G1:D1', f.host), /full body|single figure|one person/);
});

test('legacy grouped-frame replies inherit their cast without additional schema rejection', async () => {
    const f = await setup();
    const result = f.mv.normalizeShots({ groups: [{ cast: [{ participantId: 'b', position: 'right' }], frames: [{ plain: 'receives umbrella', sectionIndex: 0, change: 'receives umbrella' }] }] }, f.bank, 2, {}, cast);
    assert.equal(result[0].cast[0].participantId, 'b'); assert.equal(result[0].cast[0].position, 'right');
});

test('a delayed continuation never overwrites per-person wardrobe edited while it was running', async () => {
    const f = await generated(), d = defer();
    f.mv.patchWardrobe(song.id, { characters: [{ participantId: 'a', clothing: 'old robe' }] });
    f.mv.patchTegaki(song.id, { range: 'full' });
    f.get('generation/client').requestJson = () => d.promise;
    const pending = f.mv.continueStoryboard(song.id);
    f.mv.patchWardrobe(song.id, { characters: [{ participantId: 'a', clothing: 'manual new robe' }] });
    d.resolve({ ...raw(1), wardrobe: { characters: [{ participantId: 'a', clothing: 'model robe' }, { participantId: 'b', clothing: 'blue robe' }] } });
    assert.equal((await pending).pending, false);
    const clothes = f.mv.readMv(f.host, song.id).wardrobe.characters;
    assert.equal(clothes.find(p => p.participantId === 'a').clothing, 'manual new robe');
    assert.equal(clothes.find(p => p.participantId === 'b').clothing, 'blue robe');
});

test('record UI type, appearance and outfit edits are song-local and keep existing assets', async () => {
    const f = await ui(generated); let calls = 0;
    f.get('generation/client').requestJson = async () => { calls++; return raw(); };
    f.mv.writeMv(f.mv.mvScope(f.host), song.id, r => { r.groups[0].diffs[0].image = { url: '/user/images/kept.png' }; return r; });
    f.mvui.openMv({ songId: song.id });
    function change(selector, dataset, value) { f.mvui.handleMvChange({ target: { matches: s => s === selector, dataset, value } }); }
    change('[data-rmt-mv-story-type]', { rmtMvScope: 'record' }, 'impact');
    change('[data-rmt-mv-person-look]', { rmtMvScope: 'record', rmtMvPersonLook: 'a' }, 'black hair, brown eyes');
    change('[data-rmt-mv-person-outfit]', { rmtMvPersonOutfit: 'b' }, 'green robe');
    const saved = f.mv.readMv(f.host, song.id);
    assert.equal(saved.settings.storyType, 'impact'); assert.equal(saved.cast.appearances.find(p => p.participantId === 'a').tag, 'black hair, brown eyes');
    assert.equal(saved.wardrobe.characters.find(p => p.participantId === 'b').clothing, 'green robe');
    assert.equal(saved.groups[0].diffs[0].image.url, '/user/images/kept.png'); assert.equal(calls, 0);
    assert.equal(f.get('core/cache').readParticipantRoster().appearances[0].tag, 'black hair, golden eyes');
    f.mvui.disposeMv();
});
