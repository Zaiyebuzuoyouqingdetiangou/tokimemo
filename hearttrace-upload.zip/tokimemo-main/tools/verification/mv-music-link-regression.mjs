// Shipped bundle + public MV actions; HTTP, host, media decoding and recorder are doubles.
// These checks do not claim that Suno, a real browser, iPhone or TT was connected.
import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';
import { ui, recorderHost } from './mv-ui-fixture.mjs';

const song = { id: 'LINK_SONG', title: '本曲', lyrics: '[Verse 1]\n一句\n[Chorus]\n二句\n[End]' };
const link = 'https://suno.com/song/5619ac37-2d29-4393-9af2-98134b004b68';
const flush = async () => { for (let i = 0; i < 8; i++) await new Promise(resolve => setImmediate(resolve)); };
const plain = value => JSON.parse(JSON.stringify(value));
const audioResponse = () => new Response(new Uint8Array([82, 73, 70, 70, 0, 0, 0, 0]), { headers: { 'content-type': 'audio/wav' } });
async function setup(stored = new Map()) {
    const f = await ui(fixture), mv = f.get('extras/mv'), requests = [], errors = [], revoked = [], writes = [];
    f.sb.document.querySelector = () => null;
    f.sb.toastr = { error: message => errors.push(message), success() {}, info() {}, warning() {} };
    const songs = [song, { ...song, id: 'OTHER', title: '另一曲' }];
    f.get('core/cache').loadSession = () => ({ songs });
    f.get('generation/client').generate = () => { throw Error('unexpected generation'); };
    const record = { id: song.id, version: 1, duration: 100, settings: { output: 'tegaki', range: 'full', appear: 'none' },
        tegaki: { range: 'full', lyric: 'none', introSeconds: 0, outroSeconds: 0, showMotif: false },
        timing: { taps: { 0: 0, 1: 50 }, lineTaps: { '0:0': 0 }, shift: 0 },
        shots: [{ id: 'A', sectionIndex: 0, lyric: '一句', plain: 'room', who: 'none' }, { id: 'B', sectionIndex: 1, lyric: '二句', plain: 'room', who: 'none' }] };
    f.host.chatMetadata[mv.MV_KEY] = { songs: { [song.id]: record, OTHER: { ...structuredClone(record), id: 'OTHER' } } };
    f.sb.URL.revokeObjectURL = url => revoked.push(url);
    f.get('extras/mvMedia').getMedia = async key => stored.get(key) || null;
    f.get('extras/mvMedia').putMedia = async (key, blob, name, details = {}) => { const row = { blob, name, ...details }; stored.set(key, row); writes.push({ key, ...row }); return true; };
    const input = { value: '' };
    f.body.querySelector = selector => selector === '[data-rmt-mv-music-link]' ? input : null;
    f.sb.fetch = async (...args) => { requests.push(args); return audioResponse(); };
    f.mvui.openMv({ songId: song.id }); f.click('go-tegaki'); f.click('editor-drawer', 'audio');
    const load = async (url = 'https://music.example/本曲.mp3') => { input.value = url; f.click('audio-link'); await flush(); };
    const complete = async (duration = 120) => { const probe = f.audios.at(-1); assert.equal(typeof probe?.onloadedmetadata, 'function'); probe.duration = duration; probe.onloadedmetadata(); await flush(); };
    return { ...f, mv, record, songs, input, requests, errors, revoked, writes, stored, load, complete, saved: () => mv.readMv(f.host, song.id) };
}

test('opening the music drawer keeps file import and performs no network request', async () => {
    const f = await setup(); try { await flush(); assert.match(f.body.innerHTML, /data-rmt-mv-music-link/); assert.match(f.body.innerHTML, /data-rmt-mv-audio/); assert.doesNotMatch(f.body.innerHTML, /<iframe|<audio/); assert.equal(f.requests.length, 0); } finally { f.mvui.disposeMv(); }
});
test('HTTPS input accepts Suno song and short links without inventing media endpoints', async () => {
    const f = await fixture(), m = f.get('extras/mvMusicLink');
    assert.equal(m.musicUrl(link + '?x=1#comments'), link + '?x=1');
    assert.equal(m.musicUrl('https://suno.com/s/example'), 'https://suno.com/s/example');
});
test('unsafe schemes, credential URLs and remote HTTP are rejected before a request', async () => {
    const f = await setup(); try { for (const value of ['javascript:alert(1)', 'data:audio/wav,abc', 'file:///tmp/a.mp3', 'https://user:pass@example.com/a.mp3', 'http://example.com/a.mp3', '<iframe>']) await f.load(value); assert.equal(f.requests.length, 0); assert.equal(f.audios.length, 0); } finally { f.mvui.disposeMv(); }
});
test('public metadata resolves escaped relative audio without executing page scripts', async () => {
    const f = await fixture(), m = f.get('extras/mvMusicLink');
    const result = m.publicMusicSource('<script>throw Error("never run")</script><meta content="曲名 &amp; 名字" property="og:title"><meta property="og:audio" content="/song.mp3?a=1&amp;b=2">', 'https://example.com/page');
    assert.deepEqual(plain(result), { url: 'https://example.com/song.mp3?a=1&b=2', title: '曲名 & 名字' });
});
test('explicit audio and source tags work while video-only sources are ignored', async () => {
    const f = await fixture(), m = f.get('extras/mvMusicLink');
    assert.equal(m.publicMusicSource('<audio src="/a.mp3"></audio>', 'https://example.com/page').url, 'https://example.com/a.mp3');
    assert.equal(m.publicMusicSource('<audio><source type="audio/ogg" src="/a.ogg"></audio>', 'https://example.com/page').url, 'https://example.com/a.ogg');
    assert.equal(m.publicMusicSource('<video><source src="/v.mp4"></video>', 'https://example.com/page'), null);
});
test('comments, scripts, malformed scripts and unsupported URL schemes never become media requests', async () => {
    const f = await fixture(), m = f.get('extras/mvMusicLink');
    for (const html of ['<!--<meta property="og:audio" content="/a.mp3">-->', '<script>"<meta property="og:audio" content="/a.mp3">"</script>', '<script>"<meta property="og:audio" content="/a.mp3">', '<meta property="og:audio" content="javascript:alert(1)">', '<audio src="data:audio/wav;base64,abc"></audio>']) assert.equal(m.publicMusicSource(html, 'https://example.com/page'), null);
});
test('direct audio import uses anonymous CORS fetch and commits only after decoding', async () => {
    const f = await setup(); try {
        await f.load(); assert.equal(f.writes.length, 0); assert.equal(f.saved().duration, 100);
        const [, options] = f.requests[0]; assert.equal(options.credentials, 'omit'); assert.equal(options.mode, 'cors'); assert.equal(options.referrerPolicy, 'no-referrer');
        await f.complete(); assert.equal(f.writes.length, 1); assert.equal(f.saved().duration, 120); assert.match(f.body.innerHTML, /已导入，与画面共用播放进度/);
        assert.deepEqual(plain(f.saved().timing), plain(f.record.timing)); assert.equal(f.saved().shots.length, 2);
    } finally { f.mvui.disposeMv(); }
});
test('the existing play, pause, seek and lyric marking all use the imported audio clock', async () => {
    const f = await setup(); try {
        await f.load(); await f.complete(); f.click('editor-drawer'); f.click('play'); await flush();
        const audio = f.audios.at(-1), total = f.audios.length; assert.equal(audio.paused, false); assert.match(audio.src, /^blob:/);
        f.mvui.handleMvChange({ target: { matches: s => s === '[data-rmt-mv-seek]', value: '37.5' } }); assert.equal(audio.currentTime, 37.5);
        f.click('tap-line', '1:0'); assert.equal(f.saved().timing.lineTaps['1:0'], 37.5);
        f.click('play'); await flush(); assert.equal(audio.paused, true); assert.equal(f.audios.length, total); assert.deepEqual(f.errors, []);
    } finally { f.mvui.disposeMv(); }
});
test('export consumes the same local blob as preview through the existing sound path', async () => {
    const f = await setup(); try {
        await f.load(); await f.complete(); f.click('play'); await flush(); const preview = f.audios.at(-1);
        const recorder = recorderHost(f); f.click('export'); await flush();
        assert.equal(f.audios.at(-1).src, preview.src); assert.equal(recorder.contexts.length, 1); assert.equal(recorder.recorders[0].state, 'recording'); f.click('export-stop'); assert.equal(recorder.contexts[0].closed, true);
    } finally { f.mvui.disposeMv(); }
});
test('a Suno-shaped public metadata response imports through the same path without an iframe', async () => {
    const f = await setup(); try {
        f.sb.fetch = async (url, options) => { f.requests.push([url, options]); return url === link ? new Response('<meta property="og:title" content="测试歌曲"><meta property="og:audio" content="https://media.example/song.mp3">', { headers: { 'content-type': 'text/html' } }) : audioResponse(); };
        await f.load(link); await f.complete(); assert.deepEqual(f.requests.map(x => x[0]), [link, 'https://media.example/song.mp3']); assert.equal(f.writes[0].sourceUrl, link); assert.match(f.body.innerHTML, /测试歌曲/); assert.doesNotMatch(f.body.innerHTML, /<iframe/);
    } finally { f.mvui.disposeMv(); }
});
test('a real-shaped Suno 403 leaves the old audio, timings, artwork and saved data intact', async () => {
    const f = await setup(); try {
        f.upload(); await f.complete(123); f.click('play'); await flush(); const old = f.audios.at(-1), before = JSON.stringify(f.saved()), writes = f.writes.length;
        f.sb.fetch = async () => new Response('Access denied', { status: 403, headers: { 'content-type': 'text/html' } });
        await f.load(link); assert.match(f.body.innerHTML, /403/); assert.equal(JSON.stringify(f.saved()), before); assert.equal(f.writes.length, writes); assert.equal(old.paused, false); assert.ok(!f.revoked.includes(old.src));
    } finally { f.mvui.disposeMv(); }
});
test('a share page without published audio fails explicitly and never becomes a phantom audio track', async () => {
    const f = await setup(); try { f.sb.fetch = async () => new Response('<html><p>song</p><script>privateState={audio_url:"not-an-api"}</script></html>', { headers: { 'content-type': 'text/html' } }); await f.load(link); assert.match(f.body.innerHTML, /没有提供可导入的公开音频/); assert.equal(f.audios.length, 0); assert.equal(f.writes.length, 0); assert.equal(f.saved().duration, 100); } finally { f.mvui.disposeMv(); }
});
test('CORS/network failure does not fall back to proxies or hidden playback', async () => {
    const f = await setup(); try { let calls = 0; f.sb.fetch = async () => { calls++; throw new TypeError('secret server detail'); }; await f.load(link); assert.equal(calls, 1); assert.match(f.body.innerHTML, /跨站读取/); assert.doesNotMatch(f.body.innerHTML, /secret server detail|<iframe/); assert.equal(f.audios.length, 0); } finally { f.mvui.disposeMv(); }
});
test('empty, JSON and nested HTML responses never replace music', async () => {
    for (const response of [new Response(null), new Response('{}', { headers: { 'content-type': 'application/json' } }), new Response('<meta property="og:audio" content="https://example.com/another">', { headers: { 'content-type': 'text/html' } })]) {
        const f = await setup(); try { let calls = 0; f.sb.fetch = async () => ++calls === 1 ? response : new Response('<html>not audio</html>', { headers: { 'content-type': 'text/html' } }); await f.load(); assert.equal(f.writes.length, 0); assert.equal(f.audios.length, 0); assert.equal(f.saved().duration, 100); } finally { f.mvui.disposeMv(); }
    }
});
test('decode failure preserves the prior cached track and can be retried', async () => {
    const f = await setup(); try { f.upload(); await f.complete(); const before = JSON.stringify(f.saved()); await f.load(); f.audios.at(-1).onerror(); await flush(); assert.equal(f.writes.length, 1); assert.equal(JSON.stringify(f.saved()), before); assert.match(f.body.innerHTML, /音频未能导入/); await f.load(); await f.complete(140); assert.equal(f.saved().duration, 140); } finally { f.mvui.disposeMv(); }
});
test('cancel aborts a download and a late response cannot replace the current track', async () => {
    const f = await setup(); try { let finish, signal; f.sb.fetch = (url, options) => { signal = options.signal; return new Promise(resolve => { finish = resolve; }); }; await f.load(); f.click('audio-link-cancel'); assert.equal(signal.aborted, true); finish(audioResponse()); await flush(); assert.equal(f.writes.length, 0); assert.equal(f.audios.length, 0); } finally { f.mvui.disposeMv(); }
});
test('cancel during decoding also discards a stale loadedmetadata event', async () => {
    const f = await setup(); try { await f.load(); const probe = f.audios.at(-1), late = probe.onloadedmetadata; f.click('audio-link-cancel'); late(); await flush(); assert.equal(f.writes.length, 0); assert.ok(f.revoked.includes(probe.src)); assert.equal(f.saved().duration, 100); } finally { f.mvui.disposeMv(); }
});
test('switching songs aborts loading and never imports into either song afterward', async () => {
    const f = await setup(); try { let finish; f.sb.fetch = () => new Promise(resolve => { finish = resolve; }); await f.load(link); f.mvui.openMv({ songId: 'OTHER' }); finish(audioResponse()); await flush(); assert.equal(f.writes.length, 0); assert.equal(f.saved().duration, 100); assert.equal(f.mv.readMv(f.host, 'OTHER').duration, 100); f.click('go-tegaki'); f.click('editor-drawer', 'audio'); assert.doesNotMatch(f.body.innerHTML, /5619ac37/); } finally { f.mvui.disposeMv(); }
});
test('chat changes during decoding cannot commit into old or new chat', async () => {
    const f = await setup(); try { await f.load(); const late = f.audios.at(-1).onloadedmetadata; f.switchTo({ ...f.host, chatId: 'B', chatMetadata: {} }); late(); await flush(); assert.equal(f.writes.length, 0); assert.equal(f.saved().duration, 100); } finally { f.mvui.disposeMv(); }
});
test('choosing a local file wins over an unfinished link import', async () => {
    const f = await setup(); try { await f.load(); const late = f.audios.at(-1).onloadedmetadata; f.upload(); await f.complete(150); late(); await flush(); assert.equal(f.saved().duration, 150); assert.equal(f.writes.length, 1); assert.equal(f.writes[0].name, 'manual.wav'); assert.equal(f.writes[0].sourceUrl, undefined); } finally { f.mvui.disposeMv(); }
});
test('fresh runtime restores cached link audio for the same song without network access', async () => {
    const media = new Map(), first = await setup(media); await first.load(); await first.complete(160); first.mvui.disposeMv();
    const second = await setup(media); try { await flush(); await second.complete(160); assert.equal(second.requests.length, 0); assert.equal(second.saved().duration, 160); assert.match(second.body.innerHTML, /music.example/); second.click('play'); await flush(); assert.match(second.audios.at(-1).src, /^blob:/); } finally { second.mvui.disposeMv(); }
});
test('music media metadata remains local and does not add URLs or blobs to the MV record', async () => {
    const f = await setup(); try { await f.load('https://music.example/a.mp3?token=LOCAL_ONLY'); await f.complete(); assert.match(f.writes[0].sourceUrl, /LOCAL_ONLY/); assert.doesNotMatch(JSON.stringify(f.saved()), /LOCAL_ONLY|music.example|blob:/); } finally { f.mvui.disposeMv(); }
});
test('non-seekable live audio is rejected without changing the current timeline', async () => {
    const f = await setup(); try { await f.load(); await f.complete(Infinity); assert.equal(f.saved().duration, 100); assert.equal(f.writes.length, 0); assert.match(f.body.innerHTML, /音频未能导入/); } finally { f.mvui.disposeMv(); }
});
test('changing the song text during metadata decoding invalidates the import', async () => {
    const f = await setup(); try { await f.load(); f.songs[0] = { ...song, lyrics: '[Verse 1]\n已经改写\n[End]' }; await f.complete(); assert.equal(f.writes.length, 0); assert.equal(f.saved().duration, 100); } finally { f.mvui.disposeMv(); }
});
test('download timeout clears the busy state and keeps the old track available', async () => {
    const f = await setup(), scheduled = new Map(); let seq = 0;
    try {
        f.sb.setTimeout = (fn, ms) => { scheduled.set(++seq, { fn, ms }); return seq; }; f.sb.clearTimeout = id => scheduled.delete(id);
        f.sb.fetch = (url, options) => new Promise((resolve, reject) => options.signal.addEventListener('abort', () => reject(new DOMException('cancelled', 'AbortError')), { once: true }));
        await f.load(); const timer = [...scheduled.values()].find(x => x.ms === 60000); assert.ok(timer); timer.fn(); await flush();
        assert.match(f.body.innerHTML, /音乐读取超时/); assert.match(f.body.innerHTML, /data-rmt-mv="audio-link"/); assert.equal(f.writes.length, 0); assert.equal(scheduled.size, 0);
    } finally { f.mvui.disposeMv(); }
});
test('stream read failures never expose a source URL or provider error details in the UI', async () => {
    const f = await setup(); try {
        f.sb.fetch = async () => ({ ok: true, url: '', headers: new Headers({ 'content-type': 'audio/wav' }), blob: async () => { throw Error('PRIVATE_TOKEN_IN_SOURCE_URL'); } });
        await f.load(); assert.match(f.body.innerHTML, /音乐读取失败/); assert.doesNotMatch(f.body.innerHTML, /PRIVATE_TOKEN_IN_SOURCE_URL/); assert.equal(f.writes.length, 0);
    } finally { f.mvui.disposeMv(); }
});
test('typed link survives redraws and Enter imports through the same action', async () => {
    const f = await setup(), listeners = {};
    try {
        const root = { addEventListener: (name, fn) => { listeners[name] = fn; }, querySelector: () => null };
        f.body.querySelector = selector => selector === '.rmt-mv-editor' ? root : selector === '[data-rmt-mv-music-link]' ? f.input : null;
        f.mvui.renderMv(); const target = { matches: selector => selector === '[data-rmt-mv-music-link]', value: 'https://music.example/from-keyboard.mp3' };
        listeners.input({ target }); f.mvui.renderMv(); assert.match(f.body.innerHTML, /value="https:\/\/music.example\/from-keyboard.mp3"/);
        listeners.keydown({ key: 'Enter', target, preventDefault() {} }); await flush(); await f.complete(); assert.match(f.body.innerHTML, /from-keyboard.mp3/); assert.equal(f.requests.length, 1);
    } finally { f.mvui.disposeMv(); }
});
test('the real media module stores the link alongside the blob and keeps older rows compatible', async () => {
    const f = await fixture(), rows = new Map(), m = f.get('extras/mvMedia');
    f.sb.indexedDB = { open(name, version) {
        assert.equal(name, 'heartbeatMemoriesMvMedia'); assert.equal(version, 1);
        const request = { result: { transaction(storeName, mode) {
            assert.equal(storeName, 'files'); const tx = { objectStore: () => ({
                put(row) { rows.set(row.key, structuredClone(row)); return { result: row.key }; },
                get(key) { return { result: structuredClone(rows.get(key)) }; },
            }) }; queueMicrotask(() => tx.oncomplete()); return tx;
        } } }; queueMicrotask(() => request.onsuccess()); return request;
    } };
    const first = m.mediaKey('audio', 'chat-A', song.id), second = m.mediaKey('audio', 'chat-B', song.id), blob = new Blob(['audio'], { type: 'audio/wav' });
    assert.equal(await m.putMedia(first, blob, '链接歌曲', { sourceUrl: link }), true);
    assert.equal(await m.putMedia(second, blob, '原文件'), true);
    assert.equal((await m.getMedia(first)).sourceUrl, link); assert.equal((await m.getMedia(first)).blob.size, 5);
    assert.equal((await m.getMedia(second)).sourceUrl, undefined); assert.equal((await m.getMedia(second)).name, '原文件');
});
test('legacy video MV also exposes the current-song music entry without switching its output setting', async () => {
    const f = await setup(); try {
        f.mv.patchRecord(song.id, { settings: { ...f.saved().settings, output: 'video' } }); f.mvui.openMv({ songId: song.id });
        assert.match(f.body.innerHTML, /data-rmt-mv="music-preview"/); f.click('music-preview'); assert.match(f.body.innerHTML, /data-rmt-mv-music-link/);
        await f.load(); await f.complete(); assert.equal(f.saved().settings.output, 'video'); f.click('play'); await flush(); assert.equal(f.audios.at(-1).paused, false);
    } finally { f.mvui.disposeMv(); }
});
