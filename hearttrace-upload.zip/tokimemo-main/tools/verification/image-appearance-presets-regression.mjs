import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const root = process.env.TEST_ROOT || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const realm = vm.createContext({});
const modules = new Map();
async function moduleFor(relative) {
    if (modules.has(relative)) return modules.get(relative);
    const source = relative === 'src/core/settings.js' ? 'export function getPluginSettings(context) { return context.settings || {}; }'
        : relative === 'src/core/text.js' ? 'export function normalizeText(value) { return value; }'
            : await fs.readFile(path.join(root, relative), 'utf8');
    const mod = new vm.SourceTextModule(source, { context: realm, identifier: relative });
    modules.set(relative, mod);
    await mod.link((specifier, parent) => moduleFor(path.posix.normalize(path.posix.join(path.posix.dirname(parent.identifier), specifier))));
    return mod;
}
const entry = await moduleFor('src/generation/imageAppearancePresets.js');
await entry.evaluate();
const resolver = entry.namespace.resolveImageAppearancePresets;
const plain = value => JSON.parse(JSON.stringify(value));
const rows = result => plain([...result]);
const person = (id, name, visible) => ({ id, name, ...(visible ? { visible } : {}) });
const context = (presets = {}, provider = 'chatu8-image') => ({ settings: { imageGenerationProvider: provider },
    extensionSettings: { 'st-chatu8': { characterPresets: presets } } });
const api = characters => ({ apiVersion: 1, capabilities: { characterLibrary: true },
    getCharacters: () => ({ apiVersion: 1, characters }) });

test('Chatu8 resolves complete roster collectively and preserves independent valid people after alias collision', () => {
    const ctx = context({ shared: { nameEN: 'Alex', nameCN: '小亚', characterTraits: 'blonde hair' },
        independent: { nameEN: 'Beth', characterTraits: 'green eyes' } });
    assert.deepEqual(rows(resolver(ctx, [person('a', 'Alex'), person('b', '小亚'), person('c', 'Beth')])),
        [['c', { tag: 'green eyes', source: 'chatu8', presetKey: 'independent' }]]);
});

test('a hidden or hands-only second alias still blocks shared Chatu8 identity', () => {
    const ctx = context({ shared: { nameEN: 'Alex|Alexander', characterTraits: 'blonde hair' } });
    for (const visible of ['hands', 'silhouette']) {
        assert.deepEqual(rows(resolver(ctx, [person('a', 'Alex'), person('b', 'Alexander', visible)])), []);
    }
    assert.deepEqual(rows(resolver(ctx, [person('a', 'Alex'), person('b', 'Alex'), person('c', 'Alexander')])), []);
});

test('normalized duplicate roster names and duplicated IDs never choose a preset', () => {
    const ctx = context({ k: { nameEN: 'Ka-mael', characterTraits: 'blonde hair' } });
    for (const roster of [[person('a', 'Ka-mael'), person('b', '  ＫＡ　ＭＡＥＬ ')],
        [person('a', 'Ka-mael'), person('a', 'Someone else')]]) assert.deepEqual(rows(resolver(ctx, roster)), []);
});

test('ambiguous and missing Chatu8 presets leave only the reliable person available', () => {
    const ctx = context({ a: { nameEN: 'Alex', characterTraits: 'blonde hair' }, b: { nameEN: 'Alex', characterTraits: 'black hair' },
        c: { nameEN: 'Beth', characterTraits: 'green eyes' } });
    assert.deepEqual([...resolver(ctx, [person('a', 'Alex'), person('b', 'Missing'), person('c', 'Beth')]).keys()], ['c']);
});

test('valid NAI weighting survives while real template macros and missing dollar macros fall back', () => {
    for (const tag of ['{{blonde hair}}, {{{blue eyes}}}', '{{1.2::blonde hair::}}, [green eyes]', '(blonde hair:1.2)']) {
        const ctx = context({ a: { nameEN: 'Alex', characterTraits: tag } });
        assert.equal(resolver(ctx, [person('a', 'Alex')]).get('a')?.tag, tag);
    }
    for (const tag of ['{{char}}', '{{ user }}', '{{getvar::appearance}}', '{{random::blue hair::red hair}}', '{{unknown::appearance}}', '$Missing$', '{{time}}']) {
        const ctx = context({ a: { nameEN: 'Alex', characterTraits: tag } });
        assert.equal(resolver(ctx, [person('a', 'Alex')]).size, 0, tag);
    }
});

test('BaiBai only reads its advertised API 1 snapshot and uses exact unique names', () => {
    const ctx = context({}, 'baibai-image'), publicApi = api([{ name: 'Alex', tag: 'black hair' }, { name: 'Beth', tag: 'green eyes' }]);
    assert.deepEqual(rows(resolver(ctx, [person('a', 'Alex'), person('b', 'alex'), person('c', 'Beth')], { api: publicApi })),
        [['c', { tag: 'green eyes', source: 'baibai', presetKey: 'Beth' }]]);
    assert.equal(resolver(ctx, [person('a', 'alex')], { api: publicApi }).size, 0);
    assert.equal(resolver(ctx, [person('a', 'Alex')], { api: api([{ name: 'Alex', tag: 'black hair' }, { name: 'Alex', tag: 'red hair' }]) }).size, 0);
    for (const invalid of [{ ...publicApi, apiVersion: 2 }, { ...publicApi, capabilities: {} }, { ...publicApi, getCharacters: () => ({ apiVersion: 2, characters: [] }) },
        { ...publicApi, getCharacters: () => { throw Error('unavailable'); } }]) assert.equal(resolver(ctx, [person('a', 'Alex')], { api: invalid }).size, 0);
});

test('BaiBai imports stable appearance without outfits, actions, facial expression or framing', () => {
    const ctx = context({}, 'baibai-image');
    const source = [{ name: 'Alex', tag: '{{blonde hair}}, (green eyes:1.2), pale skin, blue shirt, leather gloves, waving hands, smiling, full body, long sleeves',
        nl: 'short blond hair, wearing a jacket, slender fingers' }];
    assert.deepEqual(plain(resolver(ctx, [person('a', 'Alex')], { api: api(source) }).get('a')),
        { tag: '{{blonde hair}}, (green eyes:1.2), pale skin', nl: 'short blond hair, slender fingers', source: 'baibai', presetKey: 'Alex' });
});

test('BaiBai natural-only stable appearance remains usable and visibility does not import a portrait', () => {
    const ctx = context({}, 'baibai-image'), publicApi = api([{ name: 'Alex', tag: '', nl: 'blonde hair, blue eyes, pale skin, slender fingers' }]);
    assert.equal(resolver(ctx, [person('a', 'Alex')], { api: publicApi }).get('a')?.nl, 'blonde hair, blue eyes, pale skin, slender fingers');
    assert.equal(resolver(ctx, [person('a', 'Alex', 'hands')], { api: publicApi }).get('a')?.nl, 'pale skin, slender fingers');
    assert.equal(resolver(ctx, [person('a', 'Alex', 'back')], { api: publicApi }).get('a')?.nl, 'blonde hair, pale skin, slender fingers');
    assert.equal(resolver(ctx, [person('a', 'Alex', 'silhouette')], { api: publicApi }).size, 0);
});

test('provider selection reads only the selected snapshot and explicit send-provider override is honored', () => {
    const ctx = context({ a: { nameEN: 'Alex', characterTraits: 'blonde hair' } });
    let reads = 0;
    const publicApi = { ...api([{ name: 'Alex', tag: 'black hair' }]), getCharacters() { reads++; return { apiVersion: 1, characters: [{ name: 'Alex', tag: 'black hair' }] }; } };
    assert.equal(resolver(ctx, [person('a', 'Alex')], { api: publicApi }).get('a')?.tag, 'blonde hair');
    assert.equal(reads, 0);
    assert.equal(resolver(ctx, [person('a', 'Alex')], { provider: 'baibai-image', api: publicApi }).get('a')?.tag, 'black hair');
    assert.equal(reads, 1);
    ctx.settings.imageGenerationProvider = 'baibai-image';
    assert.equal(resolver(ctx, [person('a', 'Alex')], { api: publicApi }).get('a')?.tag, 'black hair');
    assert.equal(resolver(ctx, [person('a', 'Alex')], { provider: 'chatu8-image', api: publicApi }).get('a')?.tag, 'blonde hair');
    assert.equal(reads, 2);
});

test('BaiBai no hidden getter, generation method or settings write is needed', () => {
    let unsafeReads = 0;
    const forbidden = { get() { unsafeReads++; throw Error('must not read'); } };
    const source = [{ name: 'Alex', tag: 'black hair' }], publicApi = api(source), ctx = context({}, 'baibai-image');
    for (const key of ['generate', 'apiKey', 'settings']) Object.defineProperty(publicApi, key, forbidden);
    Object.defineProperty(source[0], 'fields', forbidden);
    const before = JSON.stringify(ctx);
    assert.equal(resolver(ctx, [person('a', 'Alex')], { api: publicApi }).get('a')?.tag, 'black hair');
    Object.defineProperty(source[0], 'tag', forbidden);
    assert.equal(resolver(ctx, [person('a', 'Alex')], { api: publicApi }).size, 0);
    assert.equal(unsafeReads, 0);
    assert.equal(JSON.stringify(ctx), before);
});

test('BaiBai library and appearance lengths have no arbitrary quota', () => {
    const characters = Array.from({ length: 1100 }, (_, index) => ({ name: `Other ${index}`, tag: 'black hair' }));
    const tag = 'blonde hair, '.repeat(600) + 'green eyes';
    characters.push({ name: 'Alex', tag });
    assert.equal(resolver(context({}, 'baibai-image'), [person('a', 'Alex')], { api: api(characters) }).get('a')?.tag, tag);
});

test('back-only preset identity participates in collisions without leaking back traits into a front view', () => {
    const ctx = context({ a: { nameEN: 'Alex|Alexander', characterTraits: '', facialFeatures: '', facialFeaturesBack: 'short silver nape hair' } });
    assert.equal(resolver(ctx, [person('a', 'Alex', 'back')]).get('a')?.tag, 'short silver nape hair');
    assert.equal(resolver(ctx, [person('a', 'Alex')]).size, 0);
    assert.equal(resolver(ctx, [person('a', 'Alex', 'back'), person('b', 'Alexander')]).size, 0);
});

test('facial anatomy clauses cannot enter hands or back projections for either provider', () => {
    const tag = 'pale skin, skin with freckles across cheeks, narrow jaw, pointed chin, thick eyebrows, slender fingers';
    for (const provider of ['chatu8-image', 'baibai-image']) {
        const ctx = context({ a: { nameEN: 'Alex', characterTraits: tag } }, provider);
        for (const visible of ['hands', 'back']) assert.equal(resolver(ctx, [person('a', 'Alex', visible)], { api: api([{ name: 'Alex', tag }]) }).get('a')?.tag,
            'pale skin, slender fingers');
    }
});

test('filtering a grouped weight never emits orphan syntax, while intact weighting stays exact', () => {
    for (const provider of ['chatu8-image', 'baibai-image']) {
        for (const [tag, expected] of [['{{pale skin, blue eyes}}', 'pale skin'], ['[[blue eyes, pale skin]]', 'pale skin'],
            ['(blue eyes, pale skin:1.2)', 'pale skin'], ['{{pale skin}}, blue eyes', '{{pale skin}}']]) {
            const ctx = context({ a: { nameEN: 'Alex', characterTraits: tag } }, provider);
            const options = { api: api([{ name: 'Alex', tag }]) };
            assert.equal(resolver(ctx, [person('a', 'Alex', 'hands')], options).get('a')?.tag, expected, `${provider}: ${tag}`);
            assert.equal(resolver(ctx, [person('a', 'Alex')], options).get('a')?.tag, tag, `${provider}: intact ${tag}`);
        }
    }
    assert.equal(resolver(context({}, 'baibai-image'), [person('a', 'Alex')], { api: api([{ name: 'Alex', tag: '{{blonde hair, white dress}}' }]) }).get('a')?.tag,
        'blonde hair');
});
