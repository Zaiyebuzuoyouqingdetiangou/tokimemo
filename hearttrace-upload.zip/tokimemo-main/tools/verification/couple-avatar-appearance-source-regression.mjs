import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';

const plain = value => JSON.parse(JSON.stringify(value));
const story = '血糊了半边脸，老头拍着他的肩膀，喂胡同里的流浪猫，现在每天清早在餐厅后门吃三文鱼边角料，第二天那些人会鼻青脸肿地来自首，冷脸相对';
const response = '脸颊泛红，那双眼睛会立刻眯成弯弯的月牙，冲淡了所有棱角与威严，卸下警帽时';
async function setup() {
    const f = await fixture(), requests = [], library = [];
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS,
        imageGenerationProvider: 'baibai-image', cgPromptFormat: 'nai5-natural', imageGenerationFallback: false });
    f.sb.STBaiBaiImage = { apiVersion: 1, capabilities: { generate: true, saveToGallery: true, characterLibrary: true },
        getCharacters: () => ({ apiVersion: 1, characters: library }),
        getBackendStatus: () => ({ configured: true, backend: 'nai', supportsCharacters: true }),
        generate: async value => { requests.push(plain(value)); return { path: '/user/images/source-fixture.png' }; } };
    let textCalls = 0;
    f.get('generation/client').requestJson = async () => { textCalls++; throw Error('No implicit text request'); };
    return { ...f, requests, library, textCalls: () => textCalls,
        couple: f.get('extras/coupleAvatar'), looks: f.get('core/castLooks') };
}

test('default couple appearances reject narrative noun collisions but retain their own explicit visual facts', async () => {
    const f = await setup();
    const card = { description: `性别：男，黑色短发，身高：188cm，眉骨有疤斜劈入鬓，鼻梁微拱，肩宽脖粗，${story}`,
        persona: `性别：女，黑色长发，皮肤很白，左颊一个深深的酒窝，右眼眼角下方一颗小小的泪痣，${response}` };
    f.host.getCharacterCardFields = () => card;
    const before = plain(card), settings = f.couple.defaultCoupleSettings(f.host);
    for (const fragment of ['性别：男', '黑色短发', '眉骨有疤', '鼻梁微拱', '肩宽脖粗']) assert.ok(settings.people[0].appearance.includes(fragment), fragment);
    for (const fragment of ['性别：女', '黑色长发', '皮肤很白', '酒窝', '泪痣']) assert.ok(settings.people[1].appearance.includes(fragment), fragment);
    for (const p of settings.people) assert.doesNotMatch(p.appearance, /胡同|边角料|老头|血糊|自首|冷脸|泛红|会立刻|威严|卸下|警帽/);
    assert.doesNotMatch(settings.people[0].appearance, /酒窝|泪痣/);
    assert.doesNotMatch(settings.people[1].appearance, /眉骨有疤|肩宽/);
    assert.deepEqual(plain(card), before); assert.equal(f.textCalls(), 0); assert.equal(f.requests.length, 0);
});

test('explicit gender tags survive local extraction without guessing from names, pronouns or occupations', async () => {
    const f = await setup();
    for (const value of ['性别：女', '男', '女性', '1boy', '1girl', 'adult male', 'gender: female', 'non-binary']) {
        assert.equal(f.looks.lookFromDescription(value), value);
    }
    for (const value of ['他的朋友是男性', '她负责这个片区', '名字：小月', '职业：警察']) assert.equal(f.looks.lookFromDescription(value), '');
});

test('automatic keyword matches respect English words and preserve legitimate Chinese horns, tails and facial detail', async () => {
    const f = await setup();
    for (const value of ['that story ends here', 'retail trade', 'a capable leader', '胡同口有一只猫', '三文鱼边角料']) assert.equal(f.looks.lookFromDescription(value), '');
    for (const value of ['black_hair', 'left_eyebrow_scar', '胡须', '弯角', '狐尾', '深酒窝', '薄嘴唇']) assert.equal(f.looks.lookFromDescription(value), value);
});

test('current full card beats an old automatic summary and retains traits after the legacy source/output cuts', async () => {
    const f = await setup(), traits = Array.from({ length: 30 }, (_, i) => `facial scar number ${i}`).join(', ');
    f.host.chatMetadata[f.looks.CAST_LOOKS_KEY] = { chatId: 'A', char: 'old pink hair', user: 'old green eyes', manual: false };
    f.host.getCharacterCardFields = () => ({ description: '背景记录。'.repeat(1300) + '黑色短发，' + traits,
        personality: 'left eyebrow scar', persona: '背景记录。'.repeat(1300) + '性别：女，白色眼罩，银色长发' });
    const settings = f.couple.defaultCoupleSettings(f.host);
    assert.match(settings.people[0].appearance, /黑色短发/); assert.match(settings.people[0].appearance, /facial scar number 29/);
    assert.match(settings.people[0].appearance, /left eyebrow scar/); assert.ok(settings.people[0].appearance.length > 400);
    assert.match(settings.people[1].appearance, /性别：女.*白色眼罩.*银色长发/);
    assert.doesNotMatch(settings.people.map(p => p.appearance).join(' '), /old pink|old green|背景记录/);
    // Shared archive storage/callers keep their existing explicit quota.
    assert.ok(f.looks.lookFromDescription(traits).length <= 400);
});

test('provider preset retains explicit per-person gender and weights, without importing clothing or action', async () => {
    const f = await setup();
    f.library.push({ name: 'Char', tag: '1boy, adult male, black hair, scar on eyebrow, holding a flower' },
        { name: 'User', tag: '1.2::1girl::, adult female, silver hair, mole under right eye, police hat, waving' });
    const settings = f.couple.defaultCoupleSettings(f.host);
    assert.match(settings.people[0].appearance, /^1boy, adult male, black hair/);
    assert.match(settings.people[1].appearance, /^1\.2::1girl::, adult female, silver hair/);
    assert.doesNotMatch(settings.people.map(p => p.appearance).join(' '), /holding|police hat|waving/);
    assert.equal(f.textCalls(), 0);
});

test('complete drafts do not repeatedly rescan personas and literal user fields remain byte-exact', async () => {
    const f = await setup(); let reads = 0;
    f.host.getCharacterCardFields = () => { reads++; return { description: story, persona: response }; };
    const draft = { people: [{ id: 'char', name: 'Char', appearance: story, appearanceOverride: true },
        { id: 'user', name: 'User', appearance: '', appearanceOverride: true }], styleId: 'chibi-mochi' };
    const before = plain(draft);
    for (let i = 0; i < 3; i++) {
        const normalized = f.couple.normalizeCoupleSettings(draft, f.host);
        assert.deepEqual(plain(normalized.people), before.people);
    }
    assert.equal(reads, 0); assert.deepEqual(plain(draft), before);
});

test('manual saved looks and legacy/historical draft appearances are not silently rewritten', async () => {
    const f = await setup();
    f.host.getCharacterCardFields = () => ({ description: 'black hair', persona: 'silver hair' });
    f.host.chatMetadata[f.looks.CAST_LOOKS_KEY] = { chatId: 'A', char: story, user: response, manual: true };
    const settings = f.couple.defaultCoupleSettings(f.host);
    assert.equal(settings.people[0].appearance, story); assert.equal(settings.people[1].appearance, response);
    const historical = { people: [{ id: 'char', name: 'Char', appearance: story }, { id: 'user', name: 'User', appearance: response }] };
    assert.deepEqual(plain(f.couple.normalizeCoupleSettings(historical, null).people), historical.people);
});

test('default-to-generation sends two clean independent actors with zero text calls and no extra generation gate', async () => {
    const f = await setup();
    f.host.getCharacterCardFields = () => ({ description: `1boy，black hair，eyebrow scar，${story}`,
        persona: `1girl，silver hair，mole under right eye，${response}` });
    const settings = f.couple.defaultCoupleSettings(f.host);
    await f.couple.generateCouple({ ...settings, styleId: 'chibi-headshot' }, { context: f.host });
    assert.equal(f.requests.length, 1); assert.equal(f.textCalls(), 0);
    const sent = f.requests[0]; assert.equal(sent.characters.length, 2);
    assert.match(sent.characters[0].tag, /1boy/); assert.doesNotMatch(sent.characters[0].tag, /silver hair|mole under/);
    assert.match(sent.characters[1].tag, /1girl/); assert.doesNotMatch(sent.characters[1].tag, /eyebrow scar|black hair/);
    assert.doesNotMatch(JSON.stringify(sent), /胡同|边角料|老头|血糊|自首|泛红|会立刻|卸下/);
    assert.match(sent.nl, /without adult facial proportions/);
    await f.couple.generateCouple({ people: [{ appearance: '' }, { appearance: '' }] }, { context: f.host });
    assert.equal(f.requests.length, 2); assert.equal(f.textCalls(), 0);
});
