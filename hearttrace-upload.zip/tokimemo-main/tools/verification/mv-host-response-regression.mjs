import test from 'node:test';
import assert from 'node:assert/strict';
import {fixture, realClient} from './fixture.mjs';

// TauriTavern ai-routes.js buildErrorCompletionPayload + zh-cn API Error label.
// Public source revision: a1855be4a4f8b6ee7cd0374a84dbb3709c3e5375.
const backend = 'Custom OpenAI endpoint failed with status 524: error code: 524';
const localized = '[API 错误]\n' + backend;
const response = content => ({choices: [{index: 0, message: {role: 'assistant', content}, finish_reason: 'stop'}]});
const hostError = (content = localized) => ({id: 'tauritavern-error-1790850000', object: 'chat.completion',
    created: 1790850000, model: 'test-model', ...response(content), usage: {prompt_tokens: 0, completion_tokens: 0, total_tokens: 0}});
const song = {id: 'SONG_host_response', title: '分镜接口响应', lyrics: '[Verse]\n窗边的灯\n[Chorus]\n回家的路', bpm: 120};
const storyboard = {groups: [{id: 'G1', characterPrompt: 'at the window', diffs: [{id: 'D1', change: 'looks up'}]}],
    frames: [{sectionIndex: 0, lyric: '窗边的灯', group: 'G1', diff: 'D1'}, {sectionIndex: 1, lyric: '回家的路', group: 'G1', diff: 'D1'}]};
async function setup(onRequest) {
    const f = await fixture(); f.get('core/cache').loadSession = () => ({songs: [song]}); realClient(f, () => storyboard);
    let calls = 0; const sent = [];
    f.host.ConnectionManagerRequestService.sendRequest = async (...args) => {sent.push(args); return onRequest(++calls);};
    return {...f, mv: f.get('extras/mv'), calls: () => calls, sent};
}
async function fail(fn, code) {
    let error; try {await fn();} catch (caught) {error = caught;}
    assert.ok(error, 'must report failure'); assert.equal(error.code, code); return error;
}

test('TT Chinese 71-character synthetic completion is a transport failure, not missing JSON', async () => {
    assert.equal(localized.length, 71);
    const f = await setup(() => hostError());
    const error = await fail(() => f.mv.generateStoryboard(song.id, {output: 'tegaki'}), 'RMT_CONNECTION_SERVER');
    assert.equal(error.status, 524); assert.match(error.safeUserMessage, /超时/); assert.equal(f.calls(), 1);
    assert.equal(f.mv.readMv(f.host, song.id), null); assert.equal(f.mv.pendingMv(f.mv.mvScope(f.host)).length, 0);
    const trace = f.get('core/taskTrace').taskTraceSnapshot().at(-1);
    assert.equal(trace.mode, 'songMv'); assert.equal(trace.httpStatus, 524); assert.equal(trace.response.shape, 'error');
    assert.ok(!trace.stages.some(stage => stage.startsWith('parse')));
});

test('localized error labels work after host metadata is stripped, including profile streams', async () => {
    const f = await fixture(), api = f.get('core/independentApiConfig');
    for (const label of ['[API Error]', '[API 错误]', '[API 錯誤]']) {
        const content = label + '\n' + backend;
        for (const payload of [content, response(content), {content: [{type: 'text', text: content}]},
            await api.readProfileCompletion(async function* () {yield {text: content, state: {reasoning: ''}};})]) {
            const error = await fail(() => api.assertIndependentResponsePayload(payload), 'RMT_PROVIDER_STATUS');
            assert.equal(error.status, 524); assert.equal(api.transportFailureSummary(error).shape, 'error');
        }
    }
});

test('canonical TT error envelopes support other locales and never accept JSON from an error body', async () => {
    const f = await fixture(), api = f.get('core/independentApiConfig');
    for (const content of ['[Erreur API]\nUne erreur est survenue', JSON.stringify(storyboard)]) {
        const payload = hostError(content);
        assert.equal(api.payloadHasProviderError(payload), true);
        assert.equal(api.responseShapeSummary(payload).shape, 'error');
        const error = await fail(() => api.assertIndependentResponsePayload(payload), 'RMT_CONNECTION_FAILED');
        assert.equal(error.retryable, false);
    }
});

test('recognized host envelope preserves status before a nested upstream JSON error', async () => {
    const f = await fixture(), api = f.get('core/independentApiConfig');
    const payload = hostError('[API 错误]\nCustom OpenAI endpoint failed with status 401: {"error":{"message":"PRIVATE-key-secret"}}');
    const error = await fail(() => api.assertIndependentResponsePayload(payload), 'RMT_PROVIDER_STATUS');
    assert.equal(error.status, 401); assert.ok(!String(error).includes('PRIVATE'));
    const authoritative = hostError(); authoritative.status = 403;
    assert.equal((await fail(() => api.assertIndependentResponsePayload(authoritative), 'RMT_PROVIDER_STATUS')).status, 403);
});

test('known API error without a status remains an unknown connection failure, not an invented 524', async () => {
    const f = await setup(() => response('[API 错误]\nPRIVATE endpoint unavailable'));
    const error = await fail(() => f.mv.generateStoryboard(song.id, {output: 'tegaki'}), 'RMT_CONNECTION_FAILED');
    assert.equal(error.status, undefined); assert.equal(f.calls(), 1);
    const traces = f.get('core/taskTrace').taskTraceSnapshot();
    assert.equal(traces.at(-1).response.shape, 'error');
    assert.ok(!JSON.stringify(traces).includes('PRIVATE')); assert.ok(!String(error).includes('PRIVATE'));
});

test('validated requests never automatically reroll recognized TT error placeholders', async () => {
    for (const payload of [hostError(), response(localized), hostError('[API 错误]\n服务异常')]) {
        const f = await setup(() => payload);
        await assert.rejects(() => f.get('generation/client').requestValidatedSegment('test', 'test', {mode: 'songMv', context: f.host}, value => value));
        assert.equal(f.calls(), 1);
    }
});

test('normal JSON and existing safe wrappers keep every field, quote, brace, tag and lyric unchanged', async () => {
    const f = await fixture(), api = f.get('core/independentApiConfig'), parser = f.get('generation/jsonParser');
    const expected = {...storyboard, literal: '[API 错误]\n' + backend + ' {{char}} <span>雨</span> {保留} \\"引号\\"'};
    const raw = JSON.stringify(expected);
    for (const content of [raw, '```json\n' + raw + '\n```', '<think>internal only</think>\n' + raw]) {
        assert.deepEqual(JSON.parse(JSON.stringify(parser.extractJson(api.assertIndependentResponsePayload(response(content))))), expected);
    }
    for (const content of ['以下是分镜：\n' + JSON.stringify(storyboard), '[API 错误]\n' + JSON.stringify(storyboard), '[API 错误]\n' + backend + '\n' + JSON.stringify(storyboard)]) {
        assert.deepEqual(JSON.parse(JSON.stringify(parser.extractJson(api.assertIndependentResponsePayload(response(content))))), storyboard);
    }
});

test('partial JSON is not stripped; unfinished data, HTML and reasoning remain on their existing paths', async () => {
    const f = await fixture(), api = f.get('core/independentApiConfig'), parser = f.get('generation/jsonParser');
    const partial = '[API 错误]\n' + backend + '\n{"frames":[';
    assert.equal(api.assertIndependentResponsePayload(response(partial)), partial);
    await fail(() => parser.extractJson(partial), 'RMT_JSON_TRUNCATED');
    await fail(() => api.assertIndependentResponsePayload(response('[API 错误]\n<html>{"frames":[]}</html>')), 'RMT_RESPONSE_HTML');
    await fail(() => api.assertIndependentResponsePayload(response('<think>{"frames":[]}</think>')), 'RMT_JSON_EMPTY_FINAL_WITH_REASONING');
});

test('incidental labels and noncanonical IDs do not become new generation gates', async () => {
    const f = await fixture(), api = f.get('core/independentApiConfig');
    for (const text of ['角色看见 [API 错误] 后笑了', '[API 错误] 是屏幕上的文字', '[角色]\nerror code: 524', '同样只有普通说明，没有分镜']) {
        assert.equal(api.assertIndependentResponsePayload(response(text)), text);
    }
    for (const fields of [{id: 'tauritavern-error-example', object: 'chat.completion'}, {id: 'tauritavern-error-123', object: 'custom'}, {id: 'ordinary-123', object: 'chat.completion'}]) {
        assert.equal(api.assertIndependentResponsePayload({...fields, ...response(JSON.stringify(storyboard))}), JSON.stringify(storyboard));
    }
});

test('failed regeneration leaves existing pictures, timings and shots intact; next manual attempt succeeds', async () => {
    const f = await setup(n => n === 2 ? hostError() : response('```json\n' + JSON.stringify(storyboard) + '\n```'));
    await f.mv.generateStoryboard(song.id, {output: 'tegaki'});
    f.mv.writeMv(f.mv.mvScope(f.host), song.id, record => {record.groups[0].diffs[0].image = {url: '/old-paid.png'}; return record;});
    const before = JSON.stringify(f.mv.readMv(f.host, song.id));
    await fail(() => f.mv.generateStoryboard(song.id, {output: 'tegaki'}), 'RMT_CONNECTION_SERVER');
    assert.equal(JSON.stringify(f.mv.readMv(f.host, song.id)), before); assert.equal(f.calls(), 2);
    assert.equal((await f.mv.generateStoryboard(song.id, {output: 'tegaki'})).pending, false); assert.equal(f.calls(), 3);
    // MV now prefers streaming; budgets, temperature and one request per click
    // remain identical. A JSON response to that same request is still accepted.
    assert.equal(f.sent[2][2], 120000); assert.equal(f.sent[2][3].stream, true);
    assert.equal(f.sent[2][4].temperature, f.constants.DEFAULT_SETTINGS.temperature);
});

test('nested and streaming TT envelopes are recognized without treating quoted envelopes as errors', async () => {
    const f = await fixture(), api = f.get('core/independentApiConfig');
    const chunk = {id: 'tauritavern-error-1790850000', object: 'chat.completion.chunk', choices: [{index: 0, delta: {content: localized}, finish_reason: null}]};
    for (const payload of [{data: hostError()}, {result: {response: hostError()}}, chunk]) {
        const error = await fail(() => api.assertIndependentResponsePayload(payload), 'RMT_PROVIDER_STATUS'); assert.equal(error.status, 524);
    }
    const raw = JSON.stringify({example: hostError()});
    assert.equal(api.assertIndependentResponsePayload(response(raw)), raw);
});
