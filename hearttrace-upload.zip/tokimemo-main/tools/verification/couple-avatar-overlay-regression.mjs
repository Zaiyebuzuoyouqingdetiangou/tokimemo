import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';

// "叠在我的画师串上": the image provider prepends the user's own artist string.
// Form styles keep their proportion/framing words once at full strength,
// mixed styles once at reduced weight, medium styles never stack. Off = old output.
const people = [{ id: 'char', name: 'Left', appearance: '1boy, black long hair, golden eyes' },
    { id: 'user', name: 'Right', appearance: '1girl, short silver hair, blue eyes' }];
const plain = value => JSON.parse(JSON.stringify(value));
const count = (text, needle) => text.split(needle).length - 1;

async function setup() {
    const f = await fixture();
    return { ...f, core: f.get('extras/coupleAvatar'), styles: f.get('extras/coupleAvatarStyles') };
}

test('every style has exactly one blend class and medium styles cannot stack', async () => {
    const f = await setup();
    for (const style of f.styles.COUPLE_STYLES) {
        const blend = f.styles.coupleStyleBlend(style);
        assert.ok(['form', 'mixed', 'medium'].includes(blend), style.id);
        assert.equal(f.styles.coupleOverlayAvailable(style), blend !== 'medium', style.id);
    }
    assert.equal(f.styles.coupleOverlayAvailable(null), true, 'custom text is the light form');
    for (const id of ['art-watercolor', 'craft-plush', 'photo-film', 'render-toon', 'fantasy-glass']) {
        const off = f.core.couplePromptParts({ people, styleId: id }, null);
        const on = f.core.couplePromptParts({ people, styleId: id, overlayArtist: true }, null);
        assert.deepEqual(plain(on), plain(off), id);
    }
});

test('overlay is opt-in and absent from normalized settings unless chosen', async () => {
    const f = await setup();
    assert.equal(Object.hasOwn(f.core.normalizeCoupleSettings({ people }, null), 'overlayArtist'), false);
    assert.equal(Object.hasOwn(f.core.normalizeCoupleSettings({ people, overlayArtist: 'yes' }, null), 'overlayArtist'), false);
    assert.equal(f.core.normalizeCoupleSettings({ people, overlayArtist: true }, null).overlayArtist, true);
});

for (const promptFormat of ['', 'nai5-natural']) test(`form style (${promptFormat || 'formatless'}): style once, last, no medium sentences, identities stay bare`, async () => {
    const f = await setup();
    const style = f.styles.COUPLE_STYLES.find(row => row.id === 'chibi-dumpling');
    const on = f.core.couplePromptParts({ people, styleId: style.id, overlayArtist: true, promptFormat }, null);
    assert.ok(on.nai.prompt.endsWith(style.prompt), 'artist string leads, the style follows');
    assert.equal(count(JSON.stringify(on.nai), style.prompt), 1);
    assert.deepEqual(plain(on.nai.characters.map(row => row.tag)), people.map(person => person.appearance));
    assert.deepEqual(plain(on.characters.map(row => /two-head-tall/.test(row.tag))), [false, false]);
    for (const text of [on.nai.nl, on.prompt, on.scene, f.core.couplePromptParts({ people, styleId: style.id, overlayArtist: true, promptFormat, clothing: 'red scarf' }, null).prompt]) {
        assert.doesNotMatch(text, /selected medium|medium's own texture|Rendering style:/);
        assert.match(text, /half of the full figure height/, 'proportion construction kept');
    }
    assert.match(on.prompt, /Proportions, framing and pose: two-head-tall/);
});

test('mixed style is weighted once in the NAI tag channel; prose labels it secondary', async () => {
    const f = await setup();
    const style = f.styles.COUPLE_STYLES.find(row => row.id === 'anime-flat');
    const on = f.core.couplePromptParts({ people, styleId: style.id, overlayArtist: true }, null);
    assert.ok(on.nai.prompt.endsWith(`${f.styles.OVERLAY_MIXED_WEIGHT}::${style.prompt}::`));
    assert.match(on.prompt, /Light style accent, secondary to the base art style/);
    assert.doesNotMatch(on.nai.nl, /Style construction|flat local colors/);
});

test('mood styles stack as light and atmosphere; custom text moves after the artist string', async () => {
    const f = await setup();
    const mood = f.core.couplePromptParts({ people, styleId: 'mood-golden', overlayArtist: true }, null);
    assert.match(mood.prompt, /Light and atmosphere: golden hour/);
    const custom = f.core.couplePromptParts({ people, styleId: 'custom', customStyle: 'two-head-tall chibi', overlayArtist: true }, null);
    assert.equal(custom.nai.prompt, 'two distinct characters, side by side, two-head-tall chibi');
    assert.match(custom.prompt, /Style direction: two-head-tall chibi\.$/);
});

test('NAI 4.5 tags: artist-first scene with the style trailing once, bare actor tags, ASCII only', async () => {
    const f = await setup();
    for (const [id, weighted] of [['chibi-dumpling', false], ['layout-closeup', false], ['anime-flat', true]]) {
        const on = f.core.couplePromptParts({ people, styleId: id, overlayArtist: true, promptFormat: 'nai45-tags' }, null);
        const off = f.core.couplePromptParts({ people, styleId: id, promptFormat: 'nai45-tags' }, null);
        assert.notEqual(on.scene, off.scene, id);
        assert.doesNotMatch(on.scene, /consistent medium across/, id);
        assert.equal(/::$/.test(on.scene), weighted, id);
        for (const row of on.characters) assert.doesNotMatch(row.tag, /chibi, two-head|tight face close-up|flat-color anime/, id);
        for (const value of [on.scene, ...on.characters.map(row => row.tag)]) assert.doesNotMatch(value, /[^\x20-\x7e\r\n]/u, id);
    }
});

test('new interactions and random ideas have their own English tag recipes in 4.5', async () => {
    const f = await setup();
    for (const preset of f.styles.INTERACTION_PRESETS) {
        const parts = f.core.couplePromptParts({ people, interaction: preset.label, promptFormat: 'nai45-tags' }, null);
        for (const value of [parts.scene, ...parts.characters.map(row => row.tag)]) assert.doesNotMatch(value, /[^\x20-\x7e\r\n]/u, preset.label);
    }
    let previous = [];
    for (let i = 0; i < 40; i++) {
        const ideas = f.styles.randomCoupleIdeas(previous);
        for (const idea of ideas) {
            const parts = f.core.couplePromptParts({ people, interaction: '自定义互动', interactionDetail: idea, promptFormat: 'nai45-tags' }, null);
            for (const value of [parts.scene, ...parts.characters.map(row => row.tag)]) assert.doesNotMatch(value, /[^\x20-\x7e\r\n]/u, idea);
            const prose = f.core.couplePromptParts({ people, interaction: '自定义互动', interactionDetail: idea }, null);
            assert.doesNotMatch(prose.prompt, /follow the LEFT subject/, idea);
        }
        previous = ideas;
    }
});

test('full-figure layouts get full-figure framing; portrait layouts do not', async () => {
    const f = await setup();
    for (const id of ['layout-fullbody', 'layout-sitting', 'layout-lying', 'layout-dynamic']) {
        assert.match(f.core.couplePromptParts({ people, styleId: id }, null).nai.nl, /complete stylized figure fills most/, id);
    }
    for (const id of ['layout-closeup', 'layout-bust', 'mood-moon']) {
        assert.match(f.core.couplePromptParts({ people, styleId: id }, null).nai.nl, /Close head-and-shoulder/, id);
    }
});
