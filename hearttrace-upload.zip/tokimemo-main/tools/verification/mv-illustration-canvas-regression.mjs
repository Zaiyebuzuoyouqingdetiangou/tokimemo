import test from 'node:test';
import assert from 'node:assert/strict';
import { scene, native } from './mv-stage-canvas-fixture.mjs';

const pixels = canvas => Buffer.from(canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height).data);
const configure = record => {
    record.settings.storyType = 'illustration'; record.tegaki.lyric = 'subtitle';
    for (const s of record.shots) s.illustration = { reveal: 'ink', light: 'none', particles: 'none', movement: 'still', seconds: 6 };
};

test('same-image reveal uses monochrome then original colour; transparent pixels and source art are unchanged', async () => {
    const f = await scene();
    try {
        const draw = f.get('ui/mvIllustrationCanvas').drawPicture;
        const src = native.createCanvas(120, 100), sg = src.getContext('2d');
        sg.fillStyle = '#ff2020'; sg.fillRect(10, 10, 100, 80); const original = pixels(src);
        const out = native.createCanvas(120, 100), g = out.getContext('2d');
        draw(g, src, [0, 0], { reveal: 'ink', progress: 0 });
        let p = [...g.getImageData(60, 50, 1, 1).data];
        assert.ok(Math.abs(p[0] - p[1]) <= 1 && Math.abs(p[1] - p[2]) <= 1, 'first state is actually monochrome');
        assert.equal(g.getImageData(0, 0, 1, 1).data[3], 0);
        g.clearRect(0, 0, 120, 100); draw(g, src, [0, 0], { reveal: 'ink', progress: .6 });
        const left = g.getImageData(20, 50, 1, 1).data, right = g.getImageData(100, 50, 1, 1).data;
        assert.ok(left[0] > left[1] * 2); assert.ok(Math.abs(right[0] - right[1]) <= 1, 'wipe is spatial, not a whole-picture fade');
        g.clearRect(0, 0, 120, 100); draw(g, src, [0, 0], { reveal: 'silhouette', progress: 0 });
        assert.deepEqual([...g.getImageData(60, 50, 1, 1).data], [23, 27, 41, 255]);
        g.clearRect(0, 0, 120, 100); draw(g, src, [0, 0], { reveal: 'ink', progress: 1 });
        assert.deepEqual(pixels(out), original); assert.deepEqual(pixels(src), original); assert.equal(f.calls(), 0);
    } finally { f.mvui.disposeMv(); }
});

for (const ratio of ['16:9', '9:16']) for (const opaque of [false, true]) test(`real player ${ratio} ${opaque ? 'full picture' : 'transparent layers'}: reveal, seek and controls work without new images`, async () => {
    const f = await scene({ ratio, opaque, imageBackground: true, configure });
    try {
        const saved = JSON.stringify(f.record());
        f.seek(0); const beginning = pixels(f.preview);
        f.seek(4.1); const middle = pixels(f.preview);
        assert.notDeepEqual(middle, beginning, 'same saved picture visibly reveals colour');
        f.seek(9); f.seek(4.1); assert.deepEqual(pixels(f.preview), middle);
        assert.equal(JSON.stringify(f.record()), saved, 'rendering does not change saved art or timing');
        assert.match(f.body.innerHTML, /<summary>动态插画<\/summary>/);
        assert.match(f.body.innerHTML, /data-rmt-mv-illustration="reveal"/);
        f.mvui.handleMvChange({ target: { matches: s => s === '[data-rmt-mv-illustration]', dataset: { rmtMvIllustration: 'particles', shot: f.record().shots[0].id }, value: 'spark' } });
        assert.equal(f.record().shots[0].illustration.particles, 'spark');
        assert.equal(f.calls(), 0); assert.deepEqual(f.errors, []);
    } finally { f.mvui.disposeMv(); }
});

for (const sharedStage of [true, false]) test(`dynamic light, particles and parallax export exactly the preview at the same song clock (${sharedStage ? 'shared stage' : 'full picture without stage'})`, async () => {
    const f = await scene({ imageBackground: true, opaque: !sharedStage, configure: record => {
        configure(record);
        for (const s of record.shots) Object.assign(s.illustration, { light: 'rays', particles: 'spark', movement: 'parallax', seconds: 12 });
        record.shots[2].diff = record.shots[0].diff; record.shots[2].group = record.shots[0].group;
        for (const group of record.groups) group.motion = 'push';
        if (!sharedStage) { delete record.stage; for (const group of record.groups) group.layer = 'full'; }
    } });
    let clock = 1000, exportCanvas, started, scheduled, timer;
    const ready = new Promise(resolve => { started = resolve; }), playing = new Promise(resolve => { scheduled = resolve; });
    const raf = f.sb.requestAnimationFrame;
    f.sb.requestAnimationFrame = fn => { const id = raf(fn); if (fn.name === 'loop' && exportCanvas) scheduled(); return id; };
    f.sb.performance.now = () => clock;
    f.sb.MediaStream = class { constructor(tracks) { this.tracks = tracks; } };
    f.sb.AudioContext = class {};
    f.sb.MediaRecorder = class {
        static isTypeSupported() { return true; }
        constructor(stream) { this.state = 'inactive'; exportCanvas = stream.tracks[0].canvas; }
        start() { this.state = 'recording'; started(); }
        stop() { this.state = 'inactive'; this.onstop?.(); }
    };
    try {
        f.seek(8.1); const expected = pixels(f.preview);
        f.click('export-range', '1:1'); f.click('export');
        await Promise.race([Promise.all([ready, playing]), new Promise((_, reject) => { timer = setTimeout(() => reject(Error('export did not start')), 5000); })]);
        clock = 1100; for (const [id, tick] of [...f.frames]) { f.frames.delete(id); tick(); }
        assert.ok(pixels(exportCanvas).equals(expected), 'excerpt keeps the original reveal and light clocks');
        assert.equal(f.calls(), 0); assert.deepEqual(f.errors, []);
    } finally { clearTimeout(timer); f.mvui.disposeMv(); }
});

test('local light follows an extracted RGB cover palette when no explicit colour is chosen', async () => {
    const f = await scene();
    try {
        const out = native.createCanvas(120, 100), g = out.getContext('2d');
        f.get('ui/mvIllustrationCanvas').drawLight(g, { light: 'halo', songTime: 0 }, 120, 100, ['#000000', '#333333', 'rgb(255,0,0)']);
        const p = g.getImageData(62, 38, 1, 1).data;
        assert.ok(p[0] > p[1] * 2 && p[0] > p[2] * 2, 'red cover colours must not fall back to purple');
    } finally { f.mvui.disposeMv(); }
});
