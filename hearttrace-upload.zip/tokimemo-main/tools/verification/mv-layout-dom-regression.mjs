// Actual production markup parsed by libxml, not a browser layout engine.
import test from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { ui } from './mv-ui-fixture.mjs';
import { stageSetup } from './mv-stage-fixture.mjs';
const parse = html => JSON.parse(execFileSync('python3', ['-c', `
import sys,json
from lxml import html
r=html.fromstring(sys.stdin.read())
def nodes(cls): return r.xpath('.//*[contains(concat(" ",normalize-space(@class)," ")," '+cls+' ")]')
def parent_classes(cls): return [n.getparent().get('class','') for n in nodes(cls)]
print(json.dumps({
 'scrollParents':parent_classes('rmt-mve-panel-scroll'),
 'dockParents':parent_classes('rmt-mve-dock'),
 'imageFooterParents':parent_classes('rmt-mvi-footer'),
 'imageCanvasParents':[n.getparent().get('class','') for n in r.xpath('.//*[@data-editor-canvas]')],
 'music':len(r.xpath('.//*[@data-rmt-mv="editor-drawer" and @data-rmt-mv-id="audio"]')),
 'play':len(r.xpath('.//*[@data-rmt-mv="play"]')),
 'seek':len(r.xpath('.//*[@data-rmt-mv-seek]')),
 'saveInScroll':len(r.xpath('.//*[contains(@class,"rmt-mvi-tool-scroll")]//*[@data-edit="save" or @data-edit="save-next"]')),
 'toolsInitiallyHidden':len(r.xpath('.//*[contains(@class,"rmt-mvi-tool-scroll") and @hidden]')),
 'toolsToggle':len(r.xpath('.//*[@data-edit="tools" and @aria-expanded="false"]')),
 'persistentActions':[n.get('data-edit') for n in r.xpath('.//*[contains(@class,"rmt-mvi-footer")]//*[@data-edit]')],
 'imageActions':[n.get('data-edit') for n in r.xpath('.//*[@data-edit]')],
 'ids':[n.get('id') for n in r.xpath('.//*[@id]')],
}))
`], { input: html, encoding: 'utf8' }));

test('each production tool panel retains its content and separate timing/navigation dock', async () => {
    const f = await ui(stageSetup); f.sb.document.querySelector = () => null;
    for (const g of f.record.groups) for (const d of g.diffs) d.image = { url: '/frame.png' };
    try {
        f.mvui.openMv({ songId: f.song.id });
        for (const tab of ['shots', 'timing', 'look']) {
            f.click('editor-tab', tab); const dom = parse(f.body.innerHTML);
            assert.deepEqual(dom.scrollParents, ['rmt-mve-panel']);
            assert.deepEqual(dom.dockParents, tab === 'look' ? [] : ['rmt-mve-panel']);
            assert.equal(dom.music, 1); assert.equal(dom.play, 1); assert.equal(dom.seek, 1);
            assert.equal(new Set(dom.ids).size, dom.ids.length);
        }
    } finally { f.mvui.disposeMv(); }
});

test('image save controls are outside the scroll area and the canvas is in its own viewport', async () => {
    const f = await ui(stageSetup), module = f.get('ui/mvImageEditorUi');
    const dom = parse(module.imageEditorMarkup({ hasNext: true }));
    assert.deepEqual(dom.imageFooterParents, ['rmt-mv-editor rmt-mvi-workbench']);
    assert.deepEqual(dom.imageCanvasParents, ['rmt-mv-editor-viewport']); assert.equal(dom.saveInScroll, 0);
    for (const action of ['save', 'save-next', 'undo', 'close', 'select', 'crop', 'paint']) assert.equal(dom.imageActions.filter(x => x === action).length, 1);
});

test('large image canvas has a foldable tool panel and prominent persistent undo/save actions', async () => {
    const f = await ui(stageSetup), module = f.get('ui/mvImageEditorUi');
    const html = module.imageEditorMarkup({ hasNext: true }), dom = parse(html), css = module.imageEditorCss('#test');
    assert.equal(dom.toolsInitiallyHidden, 1); assert.equal(dom.toolsToggle, 1);
    assert.deepEqual(dom.persistentActions, ['undo', 'save', 'save-next']);
    assert.match(html, /class="rmt-mvi-primary" data-edit="save"/);
    assert.match(css, /\.rmt-mvi-layout\{[^}]*grid-template-rows:minmax\(0,1fr\)/);
    assert.doesNotMatch(css, /minmax\(170px,\.65fr\)|min-height:460px/);
    assert.match(css, /\.rmt-mvi-footer\{[^}]*flex:none/);
    assert.match(css, /\.rmt-mvi-save-row[^}]*min-height:48px/);
    // The workspace theme applies important background/ink to every button.
    assert.match(css, /\.rmt-mvi-primary\{[^}]*background:var\(--rmt-theme-accent-ink,[^)]*\)!important;[^}]*color:var\(--rmt-theme-surface-solid,[^)]*\)!important/);
});

test('editor CSS is scoped, balanced and retains paging without requiring container-query support', async () => {
    const f = await ui(stageSetup);
    const css = f.get('ui/mvEditorUi').editorCss('#test') + f.get('ui/mvImageEditorUi').imageEditorCss('#test');
    assert.equal((css.match(/{/g) || []).length, (css.match(/}/g) || []).length);
    assert.match(css, /@media\(min-width:960px\)/);
    assert.match(css, /@supports\(container-type:inline-size\)/);
    assert.match(css, /rmt-mve-panel-scroll\{[^}]*overflow:visible/);
    assert.match(css, /rmt-mvi-tool-scroll\{[^}]*overflow:auto/);
    assert.match(css, /rmt-mvi-footer\{flex:none/);
    assert.doesNotMatch(css, /rmt-mve-strip-nav\{display:none/);
    assert.doesNotMatch(css, /https?:\/\/|@font-face/);
});
