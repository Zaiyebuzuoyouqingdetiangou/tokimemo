import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { EventEmitter } from 'node:events';
import { fixture } from './fixture.mjs';

// Run the actual upstream parser and NAI request builder. The only replaced
// services are configuration, queue, preset expansion and the network boundary.
// This verifies request shape, NOT generated image quality.
const upstreamPath = process.env.CHATU8_SOURCE || '/workspace/scratch/8e568532ca62/inspection/chatu8-current.js';
const upstream = fs.readFileSync(upstreamPath, 'utf8');
function upstreamFunction(name) {
    const found = upstream.match(new RegExp('^(?:async )?function ' + name + '\\([^\\n]*\\{[\\s\\S]*?^}', 'm'));
    assert.ok(found, 'upstream function: ' + name); return found[0];
}
async function nativeRequest(event, { model = 'nai-diffusion-4-5-full', automaticCoordinates = false } = {}) {
    let actual;
    const config = { mode: 'novelai', novelaimode: model, client: 'api', novelaiApi: 'TEST_ONLY',
        novelaisite: '官网', novelai_width: 1216, novelai_height: 832, novelai_seed: '1', novelai_steps: 28,
        novelai_sampler: 'k_euler_ancestral', Schedule: 'karras', nai3Scale: 5, cfg_rescale: 0,
        nai3Variety: false, nai3CharRef: false, nai3VibeTransfer: false, enableVibeGroupTransfer: false,
        enableCloudQueue: false, AI_use_coords: automaticCoordinates, AQT_novelai: '', UCP_novelai: 'None',
        yushe: { test: { fixedPrompt: 'USER_POSITIVE', fixedPrompt_end: '', negativePrompt: 'USER_NEGATIVE' } } };
    const noop = () => {};
    const sandbox = { console: { log: noop, warn: noop, error: noop }, window: {}, AbortController, Date,
        extensionName: 'st-chatu8', extension_settings62: { 'st-chatu8': config }, extension_settings29: { 'st-chatu8': config },
        taskQueue: { addTask: () => 'test', updateStatus: noop, completeTask: noop, isTaskInQueue: () => true },
        TaskType: { NOVELAI: 'nai' }, TaskStatus: { RUNNING: 'running' }, activeAbortControllers: new Map(),
        currentCloudQueueInfo: null, currentTaskId: null, NOVELAI_TIMEOUT_SECONDS: 300,
        setTimeout: () => 0, clearTimeout: noop, clearLog: noop, addLog: noop,
        isPluginToastDisabled: () => true, toastr: { error: noop, info: noop, success: noop },
        acquireSerialLock: async () => {}, releaseSerialLock: noop,
        getRandomYusheId: () => 'test',
        prompt_replace: async prompt => ({ modifiedPrompt: prompt, insertions: [] }),
        prompt_replace_for_character: async prompt => prompt,
        zhengmian: async (start, prompt, end, quality) => [start, prompt, end, quality].filter(Boolean).join(', '),
        fumian: async (negative, preset) => [negative, preset].filter(Boolean).join(', '),
        isSettingFalse: value => value === false || value === 'false',
        isSettingTrue3: value => value === true || value === 'true',
        buildGenParams: (_, values) => values, createLoggableNovelAIPayload: value => value,
        getNovelAICandidateUrls: () => ({ candidates: ['https://fixture.invalid'], rawOtherSite: '' }),
        getDirectHeaders3: () => ({}),
        postNovelAIWithFallback: async options => { actual = JSON.parse(options.body); return { arrayBuffer: async () => new ArrayBuffer(0) }; },
        unzipFile: async () => 'TEST_IMAGE',
    };
    const names = ['getBaseTag', 'hasWeight', 'deduplicateTags', 'getSortedCharacterIds', 'parsePromptStringWithCoordinates',
        'centersToCoordinates', 'stripChineseAnnotations', 'processCharacterPrompt', 'processMultiCharacterPrompt', 'reconstructPromptString',
        'cleanNovelAIPayload', 'validateNovelAIPayload', 'generateNovelAIImage'];
    vm.createContext(sandbox);
    vm.runInContext(names.map(upstreamFunction).join('\n'), sandbox);
    await sandbox.generateNovelAIImage({ prompt: event.prompt, width: event.width, height: event.height, extraNegativePrompt: event.negative_prompt });
    assert.ok(actual, 'actual upstream NAI request reached the intercepted network boundary');
    return actual;
}

async function setup({ backend = 'novelai', model = 'nai-diffusion-4-5-full', width = 1216, height = 832, provider = 'chatu8-image', supportsCharacters = true } = {}) {
    const f = await fixture(), requests = [], source = new EventEmitter();
    f.host.chatMetadata = {};
    f.host.eventSource = source;
    f.host.extensionSettings['st-chatu8'] = { scriptEnabled: true, mode: backend, novelaimode: model,
        novelai_width: width, novelai_height: height, sd_cwidth: width, sd_cheight: height, comfyui_width: width, comfyui_height: height };
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS, imageGenerationProvider: provider, imageGenerationFallback: false });
    source.on('generate-image-request', request => { requests.push(request); source.emit('generate-image-response', { id: request.id, success: true, imageData: '/user/images/test.png' }); });
    f.sb.STBaiBaiImage = { apiVersion: 1, capabilities: { generate: true, saveToGallery: true },
        getBackendStatus: () => ({ configured: true, backend, supportsCharacters }),
        generate: async request => { requests.push(request); return { path: '/user/images/test.png' }; } };
    f.get('generation/client').requestJson = async () => { throw Error('unexpected extra paid text call'); };
    return { ...f, requests, core: f.get('extras/coupleAvatar') };
}
const settings = { styleId: 'art-gongbi', interaction: '递出一朵花', people: [
    { name: '左角色', appearance: '1boy, black hair, high ponytail; golden eyes; angular face; red bracelet（LEFT_END）' },
    { name: '右角色', appearance: '1girl, black hair, short bob；pink eyes；round face；white ribbon（RIGHT_END）' },
] };

test('the actual upstream NAI builder receives two isolated identities, preserved negatives and a 2:1 size', async () => {
    const f = await setup(), before = JSON.stringify(f.host.extensionSettings);
    await f.core.generateCouple(settings, { context: f.host });
    assert.equal(f.requests.length, 1);
    const actual = await nativeRequest(f.requests[0]);
    assert.equal(actual.parameters.width, 1408); assert.equal(actual.parameters.height, 704);
    const captions = actual.parameters.v4_prompt.caption.char_captions;
    assert.equal(captions.length, 2);
    assert.match(captions[0].char_caption, /golden eyes.*angular face.*red bracelet.*LEFT_END/s);
    assert.doesNotMatch(captions[0].char_caption, /pink eyes|short bob|RIGHT_END/);
    assert.match(captions[1].char_caption, /pink eyes.*round face.*white ribbon.*RIGHT_END/s);
    assert.doesNotMatch(captions[1].char_caption, /golden eyes|high ponytail|LEFT_END/);
    assert.deepEqual(captions.map(c => c.centers), [[{ x: .25, y: .5 }], [{ x: .75, y: .5 }]]);
    assert.doesNotMatch(actual.input, /golden eyes|pink eyes|rounded portrait cards|circular picture frames/);
    assert.match(actual.parameters.negative_prompt, /USER_NEGATIVE.*central white gutter/s);
    assert.match(actual.input, /USER_POSITIVE/);
    assert.equal(JSON.stringify(f.host.extensionSettings), before);
});

test('NAI 4 and 5 keep separate captions while the upstream automatic-position preference remains respected', async () => {
    for (const model of ['nai-diffusion-4-full', 'nai-diffusion-5-full']) {
        const f = await setup({ model }); await f.core.generateCouple(settings, { context: f.host });
        const actual = await nativeRequest(f.requests[0], { model, automaticCoordinates: true });
        assert.equal(actual.parameters.v4_prompt.caption.char_captions.length, 2);
        assert.equal(actual.parameters.use_coords, false);
        assert.match(actual.parameters.v4_prompt.caption.char_captions[0].char_caption, /LEFT_END/);
        assert.match(actual.parameters.v4_prompt.caption.char_captions[1].char_caption, /RIGHT_END/);
    }
});

test('2:1 respects different configured pixel budgets without a new cap', async () => {
    for (const [width, height] of [[1024, 1024], [2048, 2048], [1536, 768], [832, 1216]]) {
        const f = await setup({ width, height }); await f.core.generateCouple(settings, { context: f.host });
        const sent = f.requests[0];
        assert.equal(sent.width, sent.height * 2); assert.equal(sent.width % 64, 0); assert.equal(sent.height % 64, 0);
        assert.ok(sent.width * sent.height <= width * height);
        if (width === 2048) assert.ok(sent.width > 2048, 'configured high-resolution budgets are not capped');
    }
});

test('flat backends keep both literal identities early and use only supported negative fields', async () => {
    for (const backend of ['sd', 'comfyui', 'runninghub', 'banana', 'novelai']) {
        const f = await setup({ backend, model: 'nai-diffusion-3' });
        await f.core.generateCouple(settings, { context: f.host }); const sent = f.requests[0];
        assert.ok(sent.prompt.includes(settings.people[0].appearance)); assert.ok(sent.prompt.includes(settings.people[1].appearance));
        assert.ok(sent.prompt.indexOf('One continuous') > 0 && sent.prompt.indexOf('RIGHT_END') < sent.prompt.indexOf('One continuous'));
        assert.doesNotMatch(sent.prompt, /Scene Composition:|rounded portrait cards|circular picture frames|later circular crop/);
        assert.equal(typeof sent.negative_prompt === 'string', backend !== 'banana');
        assert.equal(f.requests.length, 1);
    }
});

test('BaiBai uses only its public capabilities: NAI character channels; ComfyUI dynamic negative; orientation size', async () => {
    for (const backend of ['nai', 'comfyui']) {
        const f = await setup({ provider: 'baibai-image', backend, supportsCharacters: backend === 'nai' });
        await f.core.generateCouple(settings, { context: f.host }); const sent = f.requests[0];
        assert.equal(sent.size, 'landscape');
        assert.equal(sent.width, undefined); assert.equal(sent.height, undefined); assert.equal(sent.aspectRatio, undefined);
        assert.equal(sent.negative_prompt, undefined);
        if (backend === 'nai') {
            assert.equal(sent.characters.length, 2); assert.equal(sent.negative, undefined);
            assert.doesNotMatch(sent.prompt, /golden eyes|pink eyes/);
        } else assert.match(sent.negative, /central white gutter/);
        assert.equal(f.requests.length, 1);
    }
});

test('ordinary CG remains free of avatar fields; malformed optional parts retain the complete prompt', async () => {
    const f = await setup();
    await f.get('generation/cgImageCore').invokeImageGeneration('ordinary CG', f.host);
    assert.equal(f.requests[0].prompt, 'ordinary CG');
    for (const field of ['width', 'height', 'negative_prompt']) assert.equal(f.requests[0][field], undefined);
    await f.get('generation/cgImageCore').invokeImageGeneration('complete fallback', f.host,
        { preservePrompt: true, singlePrompt: true, avatarPromptParts: { scene: 'scene', characters: [] } });
    assert.equal(f.requests[1].prompt, 'complete fallback');
});
