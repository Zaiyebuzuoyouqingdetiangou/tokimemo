import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture, realClient } from './fixture.mjs';
const wrapped = content => ({ choices: [{ message: { content }, finish_reason: 'stop' }] });
const hostError = content => ({ id: 'tauritavern-error-1791125779', object: 'chat.completion', ...wrapped(content) });

for (const [body, code] of [
    ['TypeError: Failed to fetch PRIVATE-KEY', 'RMT_CONNECTION_NETWORK'],
    ['Network request failed PRIVATE-KEY', 'RMT_CONNECTION_NETWORK'],
    ['TypeError: Load failed PRIVATE-KEY', 'RMT_CONNECTION_NETWORK'],
    ['error sending request for url (https://private.test/api?key=PRIVATE-KEY)', 'RMT_CONNECTION_NETWORK'],
    ['Failed to generate chat completion: Internal error: request timed out PRIVATE-KEY', 'RMT_CONNECTION_SERVER'],
    ['Gateway timeout PRIVATE-KEY', 'RMT_CONNECTION_SERVER'],
]) test(`known host failure retains ${code} without exposing error text`, async () => {
    const f = await fixture(), api = f.get('core/independentApiConfig');
    for (const payload of [hostError('[API 错误]\n' + body), wrapped('[API 错误]\n' + body), { error: { message: body } }]) {
        let error;
        try { api.assertIndependentResponsePayload(payload); } catch (caught) { error = caught; }
        assert.ok(error);
        const normalized = f.get('generation/generationRequest').normalizeConnectionManagerError(error);
        assert.equal(normalized.code, code); assert.equal(normalized.status, undefined);
        assert.doesNotMatch(JSON.stringify(normalized) + String(normalized), /PRIVATE|private\.test/);
    }
});

test('numeric status remains authoritative over text hints and unknown wrappers stay unknown', async () => {
    const f = await fixture(), api = f.get('core/independentApiConfig'), normalize = f.get('generation/generationRequest').normalizeConnectionManagerError;
    for (const [payload, code, status] of [
        [{ status: 401, ...hostError('[API 错误]\nFailed to fetch') }, 'RMT_CONNECTION_AUTH', 401],
        [hostError('[API 错误]\n服务异常 PRIVATE-KEY'), 'RMT_CONNECTION_FAILED', undefined],
        [hostError('[API 错误]\nPRIVATE endpoint unavailable'), 'RMT_CONNECTION_FAILED', undefined],
    ]) {
        let error; try { api.assertIndependentResponsePayload(payload); } catch (caught) { error = normalize(caught); }
        assert.equal(error.code, code); assert.equal(error.status, status);
        assert.doesNotMatch(JSON.stringify(error) + String(error), /PRIVATE/);
    }
});

test('ordinary final text and JSON quoting error labels do not acquire a new error gate', async () => {
    const f = await fixture(), api = f.get('core/independentApiConfig');
    for (const content of ['Failed to fetch is an error phrase', 'Gateway timeout is printed on the screen',
        JSON.stringify({ text: '[API 错误]\nFailed to fetch' }), '[API 错误]\n' + JSON.stringify({ text: 'Failed to fetch' })]) {
        assert.equal(api.assertIndependentResponsePayload(wrapped(content)), content);
    }
});

test('classified TT network failure still issues one request and exports only safe classification', async () => {
    const f = await fixture(); realClient(f, () => ({})); let calls = 0;
    f.host.ConnectionManagerRequestService.sendRequest = async () => { calls++; return hostError('[API 错误]\nFailed to fetch PRIVATE-KEY'); };
    await assert.rejects(() => f.get('generation/client').requestValidatedSegment('test', 'test', { mode: 'album', context: f.host }, value => value), error => error.code === 'RMT_CONNECTION_NETWORK');
    assert.equal(calls, 1);
    const traces = f.get('core/taskTrace').taskTraceSnapshot();
    assert.doesNotMatch(JSON.stringify(traces), /PRIVATE|private\.test/);
    assert.equal(f.get('core/state').state.activeProviderRequestCount, 0);
});
