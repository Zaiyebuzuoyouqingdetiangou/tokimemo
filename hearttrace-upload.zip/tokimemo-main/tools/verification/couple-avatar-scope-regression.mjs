import { runIf } from './optional.mjs';
// 缺少条件时明确跳过并说明原因；满足时加载同名 .impl.mjs 里的原测试。
await runIf([
    {
        "env": "BASELINE_ROOT",
        "kind": "dir",
        "why": "已交付的 1.0.40 源码目录，做逐文件对照"
    }
],
    () => import('./couple-avatar-scope-regression.impl.mjs'));
