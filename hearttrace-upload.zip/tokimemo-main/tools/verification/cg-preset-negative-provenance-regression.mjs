import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';

const negativeA = '{{low quality}}, [text], 1.2::extra fingers::, (wrong eye color:0.7)';
const negativeB = '{{duplicate face}}, [watermark], 0.8::extra arms::';
const positive = '{{golden hair}}, blue eyes';

async function setup(kind) {
    const f = await fixture();
    const state = { provider: 'chatu8-image' };
    const presets = { protagonist: { nameEN: 'Char', characterTraits: positive, negative: negativeA } };
    f.host.extensionSettings['st-chatu8'] = { characterPresets: presets };
    f.get('core/settings').getPluginSettings = () => ({ imageGenerationProvider: state.provider });
    f.get('core/castLooks').readCastLooks = () => ({ manual: true, char: 'own brown hair', user: 'own grey eyes' });
    f.get('core/castLooks').readParticipantLooks = () => ({ characters: [{ participantId: 'a', tag: 'own brown hair', nl: '' }] });
    const snapshot = f.json({ version: 1, people: [{ id: 'a', name: 'Char', sourceRefs: [] }] });
    const options = kind === 'snapshot' ? { castSnapshot: snapshot } : { selectedRoles: ['char'] };
    const api = f.get('generation/cgAppearance');
    const key = kind === 'snapshot' ? 'a' : 'char';
    const capture = extra => api.captureCgAppearanceEvidence(f.host, { ...options, ...extra });
    const prepare = evidence => api.normalizeCgPreparedPrompt({ imagePrompt: 'Char wears a ring by the window',
        sceneTags: 'solo, ring, window', flatPrompt: 'Char wears a ring by the window',
        characters: evidence.characters.map(row => ({ ...(kind === 'snapshot' ? { participantId: row.participantId } : { role: row.role }),
            tag: row.knownTag, nl: row.knownNl || '' })) }, evidence);
    const roundtrip = metadata => api.normalizeCgPromptMetadata(f.json(JSON.parse(JSON.stringify(metadata))));
    return { ...f, api, state, presets, key, capture, prepare, roundtrip };
}

for (const kind of ['legacy', 'snapshot']) {
    test(`${kind}: literal preset negatives survive extraction, serialization, scene edit and current resolution`, async () => {
        const f = await setup(kind);
        const evidence = f.capture();
        assert.equal(evidence.characters[0].negative, negativeA);
        assert.equal(evidence.characters[0].knownTag, positive);
        const draft = { [f.key]: { tag: 'own brown hair', nl: '' } };
        const combined = f.api.appearanceEvidenceWithDraft(evidence, draft, f.host);
        const prepared = f.prepare(combined);
        assert.equal(prepared.characters[0].negative, negativeA);
        assert.equal(prepared.characters[0].tag, positive);
        const serialized = f.roundtrip(prepared);
        const edited = f.api.metadataAfterSceneEdit(serialized);
        assert.equal(edited.characters[0].negative, negativeA);
        const resolved = f.api.resolveCgAppearanceMetadata(f.host, edited);
        assert.equal(resolved.characters[0].negative, negativeA);
        assert.equal(resolved.characters[0].fallbackTag, 'own brown hair');
    });

    test(`${kind}: fresh preset negative replaces a stale draft negative through both evidence and send resolution`, async () => {
        const f = await setup(kind);
        const old = f.roundtrip(f.prepare(f.capture()));
        f.presets.protagonist.negative = negativeB;
        const fresh = f.capture();
        const merged = f.api.appearanceEvidenceWithDraft(fresh, { [f.key]: old.characters[0] }, f.host);
        assert.equal(merged.characters[0].negative, negativeB);
        const prepared = f.roundtrip(f.prepare(merged));
        assert.equal(prepared.characters[0].negative, negativeB);
        assert.equal(f.api.resolveCgAppearanceMetadata(f.host, old).characters[0].negative, negativeB);
        assert.equal(old.characters[0].negative, negativeA, 'resolving the draft must not mutate its saved metadata');
    });

    test(`${kind}: a preset with no negative keeps its positive appearance without retaining old exclusions`, async () => {
        const f = await setup(kind);
        const old = f.roundtrip(f.prepare(f.capture()));
        delete f.presets.protagonist.negative;
        const merged = f.api.appearanceEvidenceWithDraft(f.capture(), { [f.key]: old.characters[0] }, f.host);
        assert.equal(merged.characters[0].negative, undefined);
        const prepared = f.roundtrip(f.prepare(merged));
        assert.equal(prepared.characters[0].tag, positive);
        assert.equal(prepared.characters[0].negative, undefined);
        assert.equal(f.api.resolveCgAppearanceMetadata(f.host, old).characters[0].negative, undefined);
    });

    test(`${kind}: removing the matching preset restores own appearance and clears its negative`, async () => {
        const f = await setup(kind);
        const old = f.roundtrip(f.prepare(f.capture()));
        delete f.presets.protagonist;
        const merged = f.api.appearanceEvidenceWithDraft(f.capture(), { [f.key]: old.characters[0] }, f.host);
        assert.equal(merged.characters[0].knownTag, 'own brown hair');
        assert.equal(merged.characters[0].negative, undefined);
        const prepared = f.roundtrip(f.prepare(merged));
        assert.equal(prepared.characters[0].tag, 'own brown hair');
        assert.equal(prepared.characters[0].negative, undefined);
        const resolved = f.api.resolveCgAppearanceMetadata(f.host, old);
        assert.equal(resolved.characters[0].tag, 'own brown hair');
        assert.equal(resolved.characters[0].negative, undefined);
    });

    test(`${kind}: unavailable provider and BaiBai do not inherit Chatu8 preset negatives`, async () => {
        const f = await setup(kind);
        const old = f.roundtrip(f.prepare(f.capture()));
        f.state.provider = 'none';
        const noneEvidence = f.api.appearanceEvidenceWithDraft(f.capture(), { [f.key]: old.characters[0] }, f.host);
        assert.equal(f.prepare(noneEvidence).characters[0].negative, undefined);
        assert.equal(f.api.resolveCgAppearanceMetadata(f.host, old, { provider: 'none' }).characters[0].negative, undefined);
        f.state.provider = 'baibai-image';
        const baiBai = { apiVersion: 1, capabilities: { characterLibrary: true }, getCharacters: () => ({ apiVersion: 1,
            characters: [{ name: 'Char', tag: 'silver hair, green eyes', negative: 'not an advertised BaiBai appearance field' }] }) };
        const baiEvidence = f.api.appearanceEvidenceWithDraft(f.capture({ api: baiBai }), { [f.key]: old.characters[0] }, f.host);
        const prepared = f.roundtrip(f.prepare(baiEvidence));
        assert.equal(prepared.characters[0].tag, 'silver hair, green eyes');
        assert.equal(prepared.characters[0].negative, undefined);
        const resolved = f.api.resolveCgAppearanceMetadata(f.host, old, { provider: 'baibai-image', api: baiBai });
        assert.equal(resolved.characters[0].tag, 'silver hair, green eyes');
        assert.equal(resolved.characters[0].negative, undefined);
    });

    test(`${kind}: manual positive replacement clears preset exclusions and remains authoritative`, async () => {
        const f = await setup(kind);
        const old = f.roundtrip(f.prepare(f.capture()));
        const manual = { ...old.characters[0], tag: 'own red hair', appearanceOverride: true };
        const combined = f.api.appearanceEvidenceWithDraft(f.capture(), { [f.key]: manual }, f.host);
        assert.equal(combined.characters[0].knownTag, 'own red hair');
        assert.equal(combined.characters[0].negative, undefined);
        const prepared = f.roundtrip(f.prepare(combined));
        assert.equal(prepared.characters[0].appearanceOverride, true);
        assert.equal(prepared.characters[0].negative, undefined);
        const manualMetadata = f.roundtrip({ ...old, characters: [manual] });
        assert.equal(manualMetadata.characters[0].negative, undefined);
        const edited = f.api.metadataAfterSceneEdit(manualMetadata);
        const resolved = f.api.resolveCgAppearanceMetadata(f.host, edited);
        assert.equal(resolved.characters[0].tag, 'own red hair');
        assert.equal(resolved.characters[0].negative, undefined);
    });
}
