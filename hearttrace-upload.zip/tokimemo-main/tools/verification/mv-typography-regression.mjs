// Public editor/storage/render paths; real Canvas, simulated host and recorder.
import test from 'node:test';
import assert from 'node:assert/strict';
import { scene, native } from './mv-stage-canvas-fixture.mjs';

const settings = { textScale: 1.15, textTracking: .12, textLeading: 1.25 };
function change(f, key, value) {
    return f.mvui.handleMvChange({ target: { value: String(value), dataset: { rmtMvTextStyle: key },
        matches: selector => selector === '[data-rmt-mv-text-style]' } });
}
const pixels = c => Buffer.from(c.getContext('2d').getImageData(0, 0, c.width, c.height).data);

test('saved typography defaults preserve old records and malformed data does not stop rendering', async () => {
    const f = await scene(); try {
        const o = f.mv.tegakiOptions(f.record());
        for (const [key, value] of Object.entries({ textScale: 1, textTracking: 0, textLeading: 1 })) assert.equal(o[key], value);
        for (const bad of [null, '', 'bad', Infinity]) {
            const o = f.mv.tegakiOptions({ tegaki: { textScale: bad, textTracking: bad, textLeading: bad } });
            assert.equal(o.textScale, 1); assert.equal(o.textTracking, 0); assert.equal(o.textLeading, 1);
        }
    } finally { f.mvui.disposeMv(); }
});

test('editor exposes optional size, tracking and leading without adding a font dependency', async () => {
    const f = await scene(); try {
        f.click('editor-tab', 'look');
        for (const key of Object.keys(settings)) assert.match(f.body.innerHTML, new RegExp('data-rmt-mv-text-style="' + key + '"'));
        assert.doesNotMatch(f.body.innerHTML, /fonts\.googleapis|\.woff2|@font-face/);
    } finally { f.mvui.disposeMv(); }
});

test('typography changes persist for the current song without touching images, shots or timing', async () => {
    // Pixel oracle uses a glyph set present in the native test font. Chinese
    // completeness and geometry are checked independently below.
    const f = await scene({ configure: r => { r.shots[0].lyric = 'TYPE PROBE'; r.shots[0].stage.text = 'TYPE PROBE'; r.shots[0].stage.layout = 'banner'; } }); try {
        const before = JSON.stringify({ groups: f.record().groups, shots: f.record().shots, timing: f.record().timing });
        const original = pixels(f.preview);
        for (const [key, value] of Object.entries(settings)) assert.equal(change(f, key, value), true);
        f.seek(0);
        assert.notDeepEqual(pixels(f.preview), original);
        for (const [key, value] of Object.entries(settings)) assert.equal(f.record().tegaki[key], value);
        f.mvui.disposeMv(); f.open();
        for (const [key, value] of Object.entries(settings)) assert.equal(f.record().tegaki[key], value);
        assert.equal(JSON.stringify({ groups: f.record().groups, shots: f.record().shots, timing: f.record().timing }), before);
        assert.equal(f.calls(), 0);
    } finally { f.mvui.disposeMv(); }
});

test('reset restores original typography only and fragment export keeps the chosen settings', async () => {
    const f = await scene(); try {
        for (const [key, value] of Object.entries(settings)) change(f, key, value);
        f.mv.patchRecord(f.song.id, { exportRange: { range: 'full' } });
        const copy = f.mv.exportRecord(f.record(), f.song);
        for (const [key, value] of Object.entries(settings)) assert.equal(copy.tegaki[key], value);
        const saved = JSON.stringify({ groups: f.record().groups, timing: f.record().timing });
        f.click('tegaki-text-reset');
        assert.equal(f.record().tegaki.textScale, 1); assert.equal(f.record().tegaki.textTracking, 0); assert.equal(f.record().tegaki.textLeading, 1);
        assert.equal(JSON.stringify({ groups: f.record().groups, timing: f.record().timing }), saved);
    } finally { f.mvui.disposeMv(); }
});

for (const ratio of ['9:16', '16:9']) {
    test('long subtitles stay complete and inside the ' + ratio + ' canvas', async () => {
        const lyric = '这是一段需要完整显示的歌词，字距与行距都能调整，不应该被裁掉末尾。'.repeat(3);
        const f = await scene({ ratio, configure: r => { r.tegaki.lyric = 'subtitle'; r.shots[0].lyric = lyric; Object.assign(r.tegaki, settings); } });
        try {
            const draws = [], g = f.preview.getContext('2d'), original = g.fillText.bind(g);
            g.fillText = (text, x, y, ...args) => { draws.push({ text, x, y, width: g.measureText(text).width, align: g.textAlign }); original(text, x, y, ...args); };
            f.seek(0);
            assert.equal(draws.map(d => d.text).join('').replace(/\s/g, ''), lyric.replace(/\s/g, ''));
            assert.ok(draws.every(d => {
                const left = d.x - (d.align === 'center' ? d.width / 2 : d.align === 'right' ? d.width : 0);
                return left >= 0 && left + d.width <= f.w && d.y >= 0 && d.y <= f.h;
            }), 'the complete width of every drawn glyph/line must fit');
        } finally { f.mvui.disposeMv(); }
    });
}

test('tracking does not split emoji families or combining accents and zero tracking uses whole text', async () => {
    const f = await scene(); try {
        const types = f.get('extras/mvTypography'), g = native.createCanvas(400, 200).getContext('2d');
        assert.ok(types, 'shared typography module is bundled');
        const text = '你👨‍👩‍👧‍👦e\u0301好', written = [];
        g.font = '24px sans-serif'; g.textAlign = 'center';
        g.fillText = (value, x) => written.push({ value, x });
        types.paint(g, text, 200, 100, 2, false);
        assert.deepEqual(written.map(x => x.value), ['你', '👨‍👩‍👧‍👦', 'e\u0301', '好']);
        written.length = 0; types.paint(g, text, 200, 100, 0, false);
        assert.equal(written.length, 1); assert.equal(written[0].value, text);
    } finally { f.mvui.disposeMv(); }
});

test('big lyrics do not discard text after the third line', async () => {
    const lyric = '写到这里也不能丢掉后面的歌词'.repeat(12);
    const f = await scene({ ratio: '9:16', configure: r => { r.tegaki.lyric = 'big'; r.shots[0].lyric = lyric; } });
    try { assert.equal(f.seek(2).filter(d => d.text).map(d => d.text).join(''), lyric); }
    finally { f.mvui.disposeMv(); }
});

test('repeated layout reuses measurements and does not change text or font size', async () => {
    const f = await scene(); try {
        const types = f.get('extras/mvTypography'), g = native.createCanvas(540, 960).getContext('2d');
        let calls = 0; const measure = g.measureText.bind(g);
        g.measureText = text => { calls++; return measure(text); };
        const font = { stack: 'sans-serif', weight: 600 }, text = '排版只改变显示，重复播放不能每帧重新测量全部歌词。'.repeat(4);
        const first = types.fit(g, text, font, 30, 440, 270, settings), cost = calls;
        for (let i = 0; i < 60; i++) assert.deepEqual(types.fit(g, text, font, 30, 440, 270, settings), first);
        assert.equal(calls, cost); assert.ok(cost > 0);
    } finally { f.mvui.disposeMv(); }
});

test('video export and preview render the same adjusted typography at the same music time', async () => {
    const f = await scene({ configure: r => { r.tegaki.lyric = 'subtitle'; r.shots[0].lyric = 'TYPE PROBE\nSecond line'; Object.assign(r.tegaki, settings); } });
    let clock = 1000, exportCanvas, started, scheduled, timer;
    const start = new Promise(resolve => { started = resolve; }), schedule = new Promise(resolve => { scheduled = resolve; });
    const raf = f.sb.requestAnimationFrame;
    f.sb.requestAnimationFrame = tick => { const id = raf(tick); scheduled(); return id; };
    f.sb.performance.now = () => clock;
    f.sb.MediaStream = class { constructor(tracks) { this.tracks = tracks; } };
    f.sb.AudioContext = class {};
    f.sb.MediaRecorder = class {
        static isTypeSupported() { return true; }
        constructor(stream) { this.state = 'inactive'; exportCanvas = stream.tracks[0].canvas; }
        start() { this.state = 'recording'; started(); }
        stop() { this.state = 'inactive'; this.onstop?.(); }
    };
    try {
        f.seek(1); const expected = pixels(f.preview);
        f.click('export-range', 'full'); f.click('export');
        await Promise.race([Promise.all([start, schedule]), new Promise((_, reject) => { timer = setTimeout(() => reject(Error('export did not start')), 5000); })]);
        clock = 2000;
        for (const [id, tick] of [...f.frames]) { f.frames.delete(id); tick(); }
        assert.deepEqual(pixels(exportCanvas), expected);
        assert.equal(f.calls(), 0);
    } finally { clearTimeout(timer); f.mvui.disposeMv(); }
});

test('typography stays in its own song and invalid input does not overwrite saved values', async () => {
    const f = await scene(); try {
        const other = structuredClone(f.record()); other.id = 'OTHER_TYPE'; other.tegaki.textScale = .9;
        f.mv.writeMv(f.mv.mvScope(f.host), other.id, () => other);
        change(f, 'textScale', 1.15); change(f, 'textScale', ''); change(f, 'textScale', 'bad');
        assert.equal(f.record().tegaki.textScale, 1.15);
        assert.equal(f.mv.readMv(f.host, other.id).tegaki.textScale, .9);
        f.click('tegaki-text-reset'); assert.equal(f.mv.readMv(f.host, other.id).tegaki.textScale, .9);
    } finally { f.mvui.disposeMv(); }
});

test('manual vertical typography keeps long text on-screen without dropping characters', async () => {
    const lyric = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.repeat(3);
    const f = await scene({ ratio: '9:16', configure: r => { r.duration = 80; r.timing = { taps: { 0: 0, 1: 70 } }; r.shots = [r.shots[0]]; r.tegaki.lyric = 'vertical'; r.shots[0].lyric = lyric; Object.assign(r.tegaki, { textScale: 2, textTracking: .2, textLeading: 1.5 }); } });
    try {
        const g = f.preview.getContext('2d'), original = g.fillText.bind(g), draws = [];
        g.fillText = (text, x, y, ...args) => { draws.push({ text, x, y, width: g.measureText(text).width }); original(text, x, y, ...args); };
        f.seek(10); assert.equal(draws.map(d => d.text).join(''), lyric);
        assert.ok(draws.every(d => d.x - d.width / 2 >= 0 && d.x + d.width / 2 <= f.w && d.y >= 0 && d.y < f.h));
    } finally { f.mvui.disposeMv(); }
});
