from pathlib import Path
import subprocess,sys,os,json,hashlib,re,time,concurrent.futures
root=Path(sys.argv[1]).resolve();dest=Path(sys.argv[2]).resolve();dest.mkdir(parents=True,exist_ok=True)
v=Path(__file__).resolve().parent;base=Path(os.environ.get('BASELINE_ROOT',str(v.parent/'baseline'))).resolve();commands=[]
if not base.is_dir():raise SystemExit('Set BASELINE_ROOT to the extracted original r84.208 folder.')
known_failures=['revision drift journals paid result and survives a fresh runtime','absent/silent local storage and rejected metadata never claim durable success','frame cast is the exact intersection of shot people and appearance preference']
def run(name,argv,env=None,legacy=False):
 t=time.monotonic();p=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env={**os.environ,**(env or {})},timeout=40)
 output=p.stdout.decode(errors='replace');(dest/(name+'.log')).write_bytes(p.stdout)
 commands.append({'name':name,'argv':argv,'returncode':p.returncode,'elapsed_seconds':round(time.monotonic()-t,3),'classification':'preexisting-baseline-differences' if legacy else 'required-pass'})
 if legacy:
  failures=re.findall(r'^not ok \d+ - (.+)$',output,re.M)
  assert p.returncode==1 and failures==known_failures,(name,failures,output[-3000:])
  assert re.search(r'^# tests 27$',output,re.M) and re.search(r'^# pass 24$',output,re.M)
 else:assert p.returncode==0,(name,output[-3000:])
 return output
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
run('build-1',['python3',str(v/'build.py'),str(root)]);first=sha(root/'dist/heartbeatMemories.bundle.js')
run('build-2',['python3',str(v/'build.py'),str(root)]);assert first==sha(root/'dist/heartbeatMemories.bundle.js')
files=sorted([*root.rglob('*.js'),*root.rglob('*.mjs')])
def syntax(p):
 t=subprocess.run(['node','--check',str(p)],capture_output=True,timeout=15)
 return {'file':str(p.relative_to(root)),'returncode':t.returncode,'stderr':t.stderr.decode()}
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:checks=list(pool.map(syntax,files))
(dest/'syntax.json').write_text(json.dumps(checks,indent=2));assert all(x['returncode']==0 for x in checks)
imports=[]
for p in (root/'src').rglob('*.js'):
 for rel in re.findall(r'^import\s+.*?from\s+[\'"]([^\'"]+)',p.read_text(),re.M):
  target=(p.parent/rel).resolve();assert target.is_file(),(p,rel);imports.append({'file':str(p.relative_to(root)),'import':rel})
(dest/'imports.json').write_text(json.dumps(imports,indent=2))
env={'TEST_ROOT':str(root),'BASELINE_ROOT':str(base)}
run('mv-continuation-bundle',['node','--experimental-vm-modules','--test','--test-reporter=tap',str(v/'mv-continuation-regression.mjs')],env)
baseline_result=run('baseline-mv-update',['node','--experimental-vm-modules','--test','--test-reporter=tap',str(v/'mv-update-regression.mjs')],{**env,'TEST_ROOT':str(base)},legacy=True)
candidate_result=run('mv-update-bundle',['node','--experimental-vm-modules','--test','--test-reporter=tap',str(v/'mv-update-regression.mjs')],env,legacy=True)
def errors(output):
 return [re.search(r'  error: ([\s\S]+?)  stack:',block)[1] for block in re.findall(r'^not ok [\s\S]+?^  \.\.\.$',output,re.M)]
assert errors(baseline_result)==errors(candidate_result),'Legacy failure payload changed'
run('source-entry',['node','-e',"import(process.argv[1]).then(m=>console.log('source entry exports',Object.keys(m).length))",(root/'src/heartbeatMemories.js').as_uri()])
run('runtime-bindings',['node','--experimental-vm-modules',str(v/'runtime-bindings.mjs'),str(root)])
run('generation-bundle',['node','--experimental-vm-modules','--test','--test-reporter=tap',str(v/'generation-regression.mjs')],env)
run('previous-source',['node','--test','--test-reporter=tap',str(v/'previous-regression.mjs')],env)
run('previous-bundle',['node','--test','--test-reporter=tap',str(v/'previous-regression.mjs')],{**env,'TEST_BUNDLE':'1'})
run('bedtime-bundle',['node','--test','--test-reporter=tap',str(v/'bedtime-regression.mjs')],env)
run('prompt-hashes',['node','--experimental-vm-modules',str(v/'prompt-hashes.mjs'),str(base),str(root),str(dest/'prompt-hashes.json')])
allfiles=sorted(p for p in root.rglob('*') if p.is_file());hashes={str(p.relative_to(root)):sha(p) for p in allfiles}
baseline_hashes={str(p.relative_to(base)):sha(p) for p in base.rglob('*') if p.is_file()}
changes=[{'file':name,'before':baseline_hashes.get(name),'after':hashes.get(name)} for name in sorted(set(hashes)|set(baseline_hashes)) if hashes.get(name)!=baseline_hashes.get(name)]
assert {x['file'] for x in changes if x['file'].startswith('src/')}=={'src/extras/mv.js','src/ui/mvView.js'}
assert (root/'index.js').read_text().replace('0.99.99-r84.209-mv-continue-clips','0.99.99-r84.208-poster-intro')==(base/'index.js').read_text()
(dest/'scope-diff.json').write_text(json.dumps(changes,indent=2,ensure_ascii=False)+'\n');(dest/'file-hashes.json').write_text(json.dumps(hashes,indent=2));(dest/'baseline-file-hashes.json').write_text(json.dumps(baseline_hashes,indent=2))
run('package',['python3',str(v/'package.py'),str(root),str(dest/'checked-package.zip')])
(dest/'commands.json').write_text(json.dumps(commands,indent=2))
test_names=['mv-continuation-bundle','mv-update-bundle','generation-bundle','previous-source','previous-bundle','bedtime-bundle']
stats={name:{kind:int(re.search(r'# '+kind+r' (\d+)',(dest/(name+'.log')).read_text())[1]) for kind in ['tests','pass','fail']} for name in test_names}
prompts=json.loads((dest/'prompt-hashes.json').read_text())
summary={'new_regressions':0,'all_tests_pass':False,'preexisting_legacy_failures':known_failures,'js_files':len(checks),'imports_resolved':len(imports),'files':len(allfiles),'unchanged_baseline_files':sum(hashes.get(k)==value for k,value in baseline_hashes.items()),'bundle_sha256':first,'deterministic_build':True,'tests':stats,'prompt_functions_checked':len(prompts),'prompt_functions_unchanged':sum(row['unchanged'] for row in prompts),'prompt_functions_changed':sum(not row['unchanged'] and not row.get('added') for row in prompts),'prompt_paths_added':sum(bool(row.get('added')) for row in prompts)}
(dest/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary))
