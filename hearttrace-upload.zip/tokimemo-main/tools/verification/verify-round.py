from pathlib import Path
import subprocess,sys,os,json,hashlib,re,time,concurrent.futures
root=Path(sys.argv[1]).resolve(); dest=Path(sys.argv[2]).resolve();dest.mkdir(parents=True,exist_ok=True)
v=Path(__file__).resolve().parent;base=Path(os.environ.get('BASELINE_ROOT',str(v.parent/'baseline'))).resolve();commands=[]
if not base.is_dir(): raise SystemExit('Set BASELINE_ROOT to the extracted original r84.186 folder before full verification.')
def run(name,argv,env=None):
 t=time.monotonic();p=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env={**os.environ,**(env or {})},timeout=40)
 (dest/(name+'.log')).write_bytes(p.stdout);commands.append({'name':name,'argv':argv,'returncode':p.returncode,'elapsed_seconds':round(time.monotonic()-t,3)})
 assert p.returncode==0,(name,p.stdout[-3000:].decode(errors='replace'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
run('build-1',['python3',str(v/'build.py'),str(root)]);first=sha(root/'dist/heartbeatMemories.bundle.js')
run('build-2',['python3',str(v/'build.py'),str(root)]);assert first==sha(root/'dist/heartbeatMemories.bundle.js')
files=sorted([*root.rglob('*.js'),*root.rglob('*.mjs')])
def syntax(p):
 t=subprocess.run(['node','--check',str(p)],capture_output=True,timeout=15)
 return {'file':str(p.relative_to(root)),'returncode':t.returncode,'stderr':t.stderr.decode()}
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool: checks=list(pool.map(syntax,files))
(dest/'syntax.json').write_text(json.dumps(checks,indent=2));assert all(x['returncode']==0 for x in checks)
imports=[]
for p in (root/'src').rglob('*.js'):
 for rel in re.findall(r'^import\s+.*?from\s+[\'"]([^\'"]+)',p.read_text(),re.M):
  target=(p.parent/rel).resolve();assert target.is_file(),(p,rel);imports.append({'file':str(p.relative_to(root)),'import':rel})
(dest/'imports.json').write_text(json.dumps(imports,indent=2))
env={'TEST_ROOT':str(root),'BASELINE_ROOT':str(base)}
run('mv-update-bundle',['node','--experimental-vm-modules','--test','--test-reporter=tap',str(v/'mv-update-regression.mjs')],env)
run('source-entry',['node','-e',"import(process.argv[1]).then(m=>console.log('source entry exports',Object.keys(m).length))",(root/'src/heartbeatMemories.js').as_uri()])
run('generation-bundle',['node','--experimental-vm-modules','--test','--test-reporter=tap',str(v/'generation-regression.mjs')],env)
run('previous-source',['node','--test','--test-reporter=tap',str(v/'previous-regression.mjs')],env)
run('previous-bundle',['node','--test','--test-reporter=tap',str(v/'previous-regression.mjs')],{**env,'TEST_BUNDLE':'1'})
run('bedtime-bundle',['node','--test','--test-reporter=tap',str(v/'bedtime-regression.mjs')],env)
run('prompt-hashes',['node','--experimental-vm-modules',str(v/'prompt-hashes.mjs'),str(base),str(root),str(dest/'prompt-hashes.json')])
allfiles=sorted(p for p in root.rglob('*') if p.is_file());hashes={str(p.relative_to(root)):sha(p) for p in allfiles}
(dest/'file-hashes.json').write_text(json.dumps(hashes,indent=2));(dest/'commands.json').write_text(json.dumps(commands,indent=2))
summary={'success':True,'js_files':len(checks),'imports_resolved':len(imports),'files':len(allfiles),'bundle_sha256':first,'deterministic_build':True,'tests':{name:int(re.search(r'# tests (\d+)',(dest/(name+'.log')).read_text())[1]) for name in ['mv-update-bundle','generation-bundle','previous-source','previous-bundle','bedtime-bundle']},'prompt_functions_checked':len(json.loads((dest/'prompt-hashes.json').read_text())), 'prompt_functions_changed':sum(not row['unchanged'] for row in json.loads((dest/'prompt-hashes.json').read_text()))}
(dest/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary))
