import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const root = path.resolve(process.env.TEST_ROOT || '.');
const details = await import(pathToFileURL(path.join(root, 'src/extras/coupleAvatarSubjectDetails.js')));
const people = [{ name: '方祁洛' }, { name: '纪时卿' }];

test('covered-eye guidance distinguishes worn covers from removed covers and single eyepatches', () => {
    for (const appearance of ['双眼系纯白轻纱', 'white blindfold', '蒙住双目', '戴白色眼罩', 'both eyes covered by gauze']) {
        assert.equal(details.coupleEyesCovered(appearance), true, appearance);
    }
    for (const appearance of ['not blindfolded', 'no blindfold', 'without a blindfold', 'blindfold removed, eyes visible',
        'blindfold hanging around neck', 'blindfold on the forehead', '眼罩已摘下', '白纱系在脖子上',
        'left eyepatch', '左眼眼罩', '黑色眼罩遮住右眼，左眼绿色', '单眼罩']) {
        assert.equal(details.coupleEyesCovered(appearance), false, appearance);
    }
    assert.equal(details.coupleCoveredEyeGuidance(false), '');
});

test('only owned eye recipes are adapted and the same unmasked style keeps its eyes', () => {
    const sleepy = 'sleepy miniature chibi, half-closed eyes, stubby body';
    assert.equal(details.coupleVisibleRecipe(sleepy, false), sleepy);
    assert.doesNotMatch(details.coupleVisibleRecipe(sleepy, true), /half-closed eyes/);
    assert.match(details.coupleVisibleRecipe(sleepy, true), /drowsy head tilt/);
    assert.doesNotMatch(details.coupleVisibleRecipe('dot eyes, loose outlines', true), /dot eyes/);
    assert.match(details.coupleVisibleRecipe('dot eyes, loose outlines', true), /loose outlines/);
});

test('explicit side and exact-name clothing is bound to its owner with comma continuations', () => {
    assert.deepEqual(details.coupleClothingParts('左边穿红衣，黑色长裤；右边穿白裙，银色腰带', people).people,
        ['左边穿红衣, 黑色长裤', '右边穿白裙, 银色腰带']);
    assert.deepEqual(details.coupleClothingParts('方祁洛穿红衣，纪时卿穿白裙', people).people,
        ['方祁洛穿红衣', '纪时卿穿白裙']);
    assert.deepEqual(details.coupleClothingParts('left black hanfu; right white robe', people).people,
        ['left black hanfu', 'right white robe']);
    assert.deepEqual(details.coupleClothingParts('方祁洛是黑红劲装；纪时卿是白色宽袖长袍', people).people,
        ['方祁洛是黑红劲装', '纪时卿是白色宽袖长袍']);
    assert.deepEqual(details.coupleClothingParts('左边是黑衣；右边是白裙', people).people,
        ['左边是黑衣', '右边是白裙']);
});

test('garment-local left and right do not turn shared clothing into one-person instructions', () => {
    for (const clothing of ['matching jackets with red left chest pockets', 'black coats, red patches on the right sleeve',
        '白衬衫，左侧袖口绣花', 'matching jackets, right sleeve embroidered with a star']) {
        const split = details.coupleClothingParts(clothing, people);
        assert.equal(split.source, clothing);
        assert.ok(split.people[0]);
        assert.equal(split.people[0], split.people[1], clothing);
    }
});

test('mixed prose is retained in the scene without guessing a different wearer', () => {
    const clothing = '方祁洛穿红衣而纪时卿穿白裙';
    assert.deepEqual(details.coupleClothingParts(clothing, people), { source: clothing, people: ['', ''] });
    const equalNames = [{ name: 'Alex' }, { name: 'Alex' }];
    assert.deepEqual(details.coupleClothingParts('Alex wears green', equalNames).people, ['', '']);
    assert.deepEqual(details.coupleClothingParts('方祁洛换成红衣；纪时卿换成白裙', people).people, ['', '']);
});
