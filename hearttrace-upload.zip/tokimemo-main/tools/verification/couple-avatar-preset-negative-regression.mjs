import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const root = process.env.TEST_ROOT || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const plain = value => JSON.parse(JSON.stringify(value));
const input = { styleId: 'art-gongbi', interaction: '递出一朵花', direction: 'keep the gentle reactions', people: [
    { id: 'char', name: 'Alex', appearance: 'local black hair' },
    { id: 'user', name: 'Beth', appearance: 'local brown hair' },
] };

async function setup() {
    const presets = {
        a: { nameEN: 'Alex', characterTraits: 'blonde hair', facialFeatures: 'green eyes', negative: '{{red hair}}, (blue eyes:1.2)' },
        b: { nameEN: 'Beth', characterTraits: 'silver hair', facialFeatures: 'violet eyes', negative: 'black hair, short hair' },
    };
    const context = { name2: 'Alex', name1: 'Beth', imageProvider: 'chatu8-image', extensionSettings: { 'st-chatu8': { characterPresets: presets } } };
    const requests = [], realm = vm.createContext({ URL, console, setTimeout, clearTimeout });
    const stubs = {
        'core/context': { currentCharacterGuard: () => context, chatScopeKey: () => 'pair-scope' },
        'core/castLooks': { readCastLooks: () => ({ char: 'local black hair', user: 'local brown hair', manual: true }), lookFromDescription: value => value || '' },
        'core/settings': { getPluginSettings: ctx => ({ imageGenerationProvider: ctx.imageProvider }) },
        'core/text': { safeUserError: (message, code) => Object.assign(new Error(message), { code, safeToDisplay: true }) },
        'generation/cgImageCore': { normalizeCgImageUrl: url => url, invokeImageGeneration: async (prompt, ctx, options) => {
            requests.push({ prompt, options }); return { url: 'https://example.test/pair.png' };
        } },
        'core/cgImagePatch': { imageResourceBase: () => 'https://example.test/', isSameImageHost: () => true },
        'core/taskTrace': { startTaskTrace: () => ({}), beginStage() {}, markStage() {}, endTaskTrace() {} },
        'core/state': { state: { activeCoupleAvatarTasks: new Map() } },
    };
    const cache = new Map();
    async function load(id) {
        if (cache.has(id)) return cache.get(id);
        const stub = stubs[id];
        const module = stub
            ? new vm.SyntheticModule(Object.keys(stub), function () { for (const [key, value] of Object.entries(stub)) this.setExport(key, value); }, { context: realm, identifier: id })
            : new vm.SourceTextModule(await fs.readFile(path.join(root, 'src', id + '.js'), 'utf8'), { context: realm, identifier: id });
        cache.set(id, module);
        await module.link((specifier, parent) => load(path.posix.normalize(path.posix.join(path.posix.dirname(parent.identifier), specifier)).replace(/\.js$/, '')));
        return module;
    }
    const module = await load('extras/coupleAvatar'); await module.evaluate();
    return { core: module.namespace, context, presets, requests };
}

function characterNegatives(parts) {
    return [parts.characters, parts.nai.characters].map(rows => rows.map(row => row.negative));
}

test('each preset negative reaches both paired-character channels without entering the positive prompt', async () => {
    const f = await setup(), before = plain(input);
    const settings = f.core.normalizeCoupleSettings(input, f.context);
    assert.equal(settings.people[0].presetNegative, f.presets.a.negative);
    assert.equal(settings.people[1].presetNegative, f.presets.b.negative);
    const parts = f.core.couplePromptParts(settings, f.context);
    assert.deepEqual(plain(characterNegatives(parts)), Array.from({ length: 2 }, () => [f.presets.a.negative, f.presets.b.negative]));
    for (const positive of [parts.prompt, parts.scene, parts.nai.prompt, parts.nai.nl, ...parts.characters.map(row => row.tag), ...parts.nai.characters.map(row => row.tag)]) {
        assert.doesNotMatch(positive, /red hair|blue eyes:1\.2|black hair, short hair/);
    }
    assert.doesNotMatch(parts.negative, /red hair|black hair, short hair/);
    assert.deepEqual(plain(input), before);
    assert.equal(f.requests.length, 0);
});

test('absent negatives preserve the old settings and channel shapes; art direction and positive output stay exact', async () => {
    const f = await setup();
    const withNegative = f.core.couplePromptParts(input, f.context);
    delete f.presets.a.negative; delete f.presets.b.negative;
    const withoutNegative = f.core.couplePromptParts(input, f.context);
    const settings = f.core.normalizeCoupleSettings(input, f.context);
    assert.ok(settings.people.every(person => !Object.hasOwn(person, 'presetNegative')));
    for (const rows of [withoutNegative.characters, withoutNegative.nai.characters]) assert.ok(rows.every(row => !Object.hasOwn(row, 'negative')));
    const removeNegative = value => JSON.parse(JSON.stringify(value, (key, data) => key === 'negative' && typeof data === 'string' && data !== withoutNegative.negative ? undefined : data));
    assert.deepEqual(removeNegative(withNegative), plain(withoutNegative));
});

test('provider switch, missing or colliding presets drop stale negatives while retaining each local fallback', async () => {
    for (const kind of ['provider', 'missing', 'collision']) {
        const f = await setup(), resolved = f.core.normalizeCoupleSettings(input, f.context);
        if (kind === 'provider') f.context.imageProvider = 'baibai-image';
        if (kind === 'missing') delete f.presets.a;
        if (kind === 'collision') { f.presets.a.nameEN = 'Alex|Beth'; delete f.presets.b; }
        const refreshed = f.core.normalizeCoupleSettings(resolved, f.context);
        assert.equal(refreshed.people[0].appearance, 'local black hair');
        assert.equal(refreshed.people[0].presetNegative, undefined);
        assert.equal(refreshed.people[1].appearance, kind === 'missing' ? 'silver hair, violet eyes' : 'local brown hair');
        const parts = f.core.couplePromptParts(refreshed, f.context);
        for (const channels of characterNegatives(parts)) {
            assert.equal(channels[0], undefined);
            assert.equal(channels[1], kind === 'missing' ? f.presets.b.negative : undefined);
        }
    }
});

test('an explicit positive appearance override keeps its literal value and does not inherit its old preset negative', async () => {
    const f = await setup(), settings = f.core.normalizeCoupleSettings(input, f.context);
    settings.people[0].appearance = 'my manually written white hair';
    const edited = f.core.normalizeCoupleSettings(settings, f.context);
    assert.equal(edited.people[0].appearance, 'my manually written white hair');
    assert.equal(edited.people[0].appearanceOverride, true);
    assert.equal(edited.people[0].presetNegative, undefined);
    const parts = f.core.couplePromptParts(edited, f.context);
    for (const negatives of characterNegatives(parts)) { assert.equal(negatives[0], undefined); assert.equal(negatives[1], f.presets.b.negative); }
    assert.match(parts.prompt, /my manually written white hair/);
});

test('negative-only preset edits refresh new drafts while saved settings and contextless history remain frozen', async () => {
    const f = await setup(), settings = f.core.normalizeCoupleSettings(input, f.context);
    const original = plain(settings);
    const saved = await f.core.saveCoupleSettings('pair-scope', settings);
    assert.deepEqual(plain(saved.settings), original);
    f.presets.a.negative = 'yellow eyes';
    assert.equal(f.core.normalizeCoupleSettings(settings, f.context).people[0].presetNegative, 'yellow eyes');
    assert.deepEqual(plain(f.core.normalizeCoupleSettings(settings, null)), original);
    assert.equal(f.core.couplePromptParts(settings, null).characters[0].negative, original.people[0].presetNegative);
    f.presets.a.negative = '';
    assert.equal(f.core.normalizeCoupleSettings(settings, f.context).people[0].presetNegative, undefined);
    f.presets.a.negative = 'yellow eyes';
    const result = await f.core.generateCouple(input, { context: f.context });
    assert.equal(f.requests.length, 1);
    assert.equal(f.requests[0].options.avatarPromptParts.characters[0].negative, 'yellow eyes');
    assert.equal(f.requests[0].options.avatarPromptParts.nai.characters[0].negative, 'yellow eyes');
    assert.equal(result.record.settings.people[0].presetNegative, 'yellow eyes');
    await f.core.retryCoupleSave(result.scope, result.record.id);
    assert.equal(f.requests.length, 1);
});

test('animal, crafted and custom styles retain their positive rendering while preset negatives stay literal and isolated', async () => {
    for (const styleId of ['animal-cat', 'craft-clay', 'custom']) {
        const f = await setup();
        const settings = { ...input, styleId, customStyle: 'charcoal smudges and hand drawn marks' };
        const withNegative = f.core.couplePromptParts(settings, f.context);
        const negative = f.presets.a.negative;
        delete f.presets.a.negative; delete f.presets.b.negative;
        const withoutNegative = f.core.couplePromptParts(settings, f.context);
        for (const key of ['prompt', 'scene', 'negative']) assert.equal(withNegative[key], withoutNegative[key]);
        assert.equal(withNegative.nai.prompt, withoutNegative.nai.prompt);
        assert.equal(withNegative.nai.nl, withoutNegative.nai.nl);
        assert.equal(withNegative.characters[0].negative, negative);
        assert.equal(withNegative.nai.characters[0].negative, negative);
        if (styleId === 'animal-cat') assert.match(withNegative.prompt, /blonde fur markings/);
        if (styleId === 'custom') assert.match(withNegative.prompt, /charcoal smudges and hand drawn marks/);
    }
});
