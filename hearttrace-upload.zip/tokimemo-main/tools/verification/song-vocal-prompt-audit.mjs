import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const [baseline, candidate, output] = process.argv.slice(2);
const sha = value => crypto.createHash('sha256').update(value).digest('hex');
async function load(root) {
    let code = fs.readFileSync(path.join(root, 'dist/heartbeatMemories.bundle.js'), 'utf8');
    code = code.replace(/\n(__m_extras_mv_js\.\w+ = \w+;)/,
        '\n__m_extras_mv_js.__storyboardPrompt = storyboardPrompt;\n__m_extras_mv_js.__tegakiGrammar = tegakiGrammar;\n$1')
        .replace(/\n(__m_extras_waiting_js\.\w+ = \w+;)/,
            '\n__m_extras_waiting_js.__waitingPrompt = waitingPrompt;\n$1');
    const names = [...code.matchAll(/^const (__m_\w+) = Object.create\(null\);/gm)].map(row => row[1]);
    const module = new vm.SourceTextModule(code + '\nexport { ' + names.join(',') + ' };', { context: vm.createContext({
        console, queueMicrotask, TextEncoder, TextDecoder, URL, URLSearchParams, AbortController, DOMException,
        structuredClone, setTimeout, clearTimeout, setInterval, clearInterval, crypto: crypto.webcrypto }) });
    await module.link(() => {}); await module.evaluate(); return module.namespace;
}
const [before, after] = await Promise.all([load(baseline), load(candidate)]), rows = [];
function record(module, key) {
    const oldCode = before[module][key].toString(), newCode = after[module][key].toString();
    let change = 'unchanged';
    if (oldCode !== newCode) {
        if (module === '__m_modes_themeSong_js' && key === 'themeSongPrompt') change = 'authorized_songwriting_guidance';
        else {
            assert.equal(module, '__m_extras_mv_js', 'Unexpected changed prompt module: ' + module + '.' + key);
            assert.equal(newCode, oldCode.replace(/\bparseSections\(song\.lyrics\)/g, 'parseSongSections(song)'),
                'Only song-aware section parsing may change an MV prompt path: ' + key);
            change = 'song_aware_parser_call_only';
        }
    }
    rows.push({ module, function: key, change, before_sha256: sha(oldCode), after_sha256: sha(newCode) });
}
for (const module of Object.keys(before)) for (const [key, value] of Object.entries(before[module])) {
    if (typeof value === 'function' && !key.startsWith('__') && /prompt/i.test(key) && key !== 'assertPromptBudget') record(module, key);
}
for (const [module, key] of [['__m_extras_waiting_js', '__waitingPrompt'], ['__m_extras_mv_js', '__storyboardPrompt'],
    ['__m_extras_mv_js', '__tegakiGrammar'], ['__m_extras_mv_js', 'rewriteShot'], ['__m_extras_mv_js', 'continueStoryboard']]) record(module, key);
assert.equal(rows.filter(row => row.change === 'authorized_songwriting_guidance').length, 1);
fs.writeFileSync(output, JSON.stringify(rows, null, 2) + '\n');
console.log(JSON.stringify({ checked: rows.length, unchanged: rows.filter(row => row.change === 'unchanged').length,
    changed: rows.filter(row => row.change !== 'unchanged').map(row => ({ function: row.function, change: row.change })) }));
