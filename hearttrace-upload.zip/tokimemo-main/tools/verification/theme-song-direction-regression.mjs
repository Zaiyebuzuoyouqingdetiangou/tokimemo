import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture, realClient } from './fixture.mjs';

function plan(f, options = {}) {
    const m = f.get('modes/themeSong');
    return m.validateThemeSongPlan(m.createThemeSongPlan(options, f.bank), f.bank);
}
const rawSong = () => ({ title: '雪落手心', vocalDescription: 'Char 为明亮男高音（Voice A）；User 为清冷女中音（Voice B）。副歌合唱。',
    styleDescription: '国风氛围流行，钢琴与弦乐托住两种声线。',
    stylePrompt: 'Atmospheric Chinese pop, 88 BPM. Duet: Voice A is a bright clear tenor; Voice B is a cool delicate alto. Alternating verses, shared chorus. Piano, strings, sparse guzheng and flute, restrained drums.',
    lyrics: '[Verse 1 - Voice A]\n雪在你指尖停留\n[Verse 2 - Voice B]\n影子向灯下靠拢\n[Chorus - Duet]\n你的手心还有光\n[End]' });

test('each singing mode supplies its own voice intent and puts audible direction in the copyable style', async () => {
    const f = await fixture(), m = f.get('modes/themeSong');
    const expected = { char: /角色独唱：以角色为主唱/, duet: /双人合唱：双方都是主唱/,
        narrator: /旁观者演唱：声线服务于旁观叙述/, ensemble: /群像演唱：.*各声部与人物的对应/ };
    for (const [voice, rule] of Object.entries(expected)) {
        const prompt = m.themeSongPrompt(plan(f, { voice }), f.bank);
        assert.match(prompt, rule);
        assert.match(prompt, /所有演唱模式的关键声线都写进 stylePrompt/);
        assert.match(prompt, /声线优先遵循用户明确要求/);
        assert.match(prompt, /不凭姓名或性格猜性别/);
        assert.match(prompt, /中文人声说明、英文曲风、歌词声部标签相互一致/);
        if (voice !== 'duet') assert.doesNotMatch(prompt, /双人合唱：双方都是主唱/);
        if (voice !== 'narrator') assert.doesNotMatch(prompt, /旁观者演唱：声线服务于旁观叙述/);
    }
});

test('duet direction supports same-gender and unspecified voices without imposing this conversation genre or tempo', async () => {
    const f = await fixture(), m = f.get('modes/themeSong');
    for (const direction of ['双男声，温暖男中音与清亮男高音，爵士，112 BPM',
        '双女声：低沉气声与通透清晰声线；民谣，76 BPM', '不指定性别，Voice A沙哑、Voice B柔和；环境流行']) {
        const prompt = m.themeSongPrompt(plan(f, { voice: 'duet', direction }), f.bank);
        assert.equal(JSON.parse(prompt.match(/^UNTRUSTED_DIRECTION_JSON: (.+)$/m)[1]), direction);
        assert.match(prompt, /双男、双女及未说明性别/);
        assert.match(prompt, /未知性别用 Voice A \/ Voice B/);
        assert.doesNotMatch(prompt, /88 BPM|方祁洛|纪时卿/);
    }
});

test('one generated duet keeps voice, genre and lyrics intact through normalization, copying and MV parsing', async () => {
    const f = await fixture(), m = f.get('modes/themeSong'), c = f.get('core/themeSongContract');
    const p = plan(f, { voice: 'duet', direction: '国风氛围流行，88 BPM，男声清亮、女声清冷，主歌轮唱副歌合唱' });
    let calls = 0;
    realClient(f, () => { calls++; return rawSong(); });
    const result = await m.generateThemeSong(f.host, f.bank,
        f.get('core/context').captureTaskOrigin(f.host, f.bank.archiveRevision), 'voice-direction', null, { plan: p });
    const song = result.songs[0];
    assert.equal(calls, 1);
    assert.equal(song.lyricTagVersion, 2);
    assert.equal(song.bpm, 88);
    assert.equal(c.themeSongExport(song, 'style'), rawSong().stylePrompt);
    assert.equal(c.themeSongExport(song, 'lyrics'), rawSong().lyrics);
    assert.deepEqual(Array.from(f.get('extras/mv').parseSongSections(song), section => Array.from(section.lines)),
        [['雪在你指尖停留'], ['影子向灯下靠拢'], ['你的手心还有光']]);
});

test('legacy stored songs are never stamped or rewritten, and simple new songs retain the existing shape', async () => {
    const f = await fixture(), m = f.get('modes/themeSong'), c = f.get('core/themeSongContract');
    const legacyRaw = { ...rawSong(), lyrics: '[Male Vocal]\n[Verse 1]\n雪落在指尖\n[Duet]\n[Chorus]\n手心还有光\n[End]' };
    const song = m.normalizeGeneratedSong(f.json(legacyRaw), plan(f, { voice: 'duet' }), f.bank);
    delete song.lyricTagVersion;
    const stored = f.json({ ...c.emptyThemeSongs(f.bank), songs: [song], selectedId: song.id });
    const before = JSON.stringify(stored);
    assert.equal(JSON.stringify(c.normalizeStoredThemeSongs(stored, f.bank)), before);
    assert.equal(JSON.stringify(stored), before);
    const simple = m.normalizeGeneratedSong(f.json({ ...legacyRaw, lyricTagVersion: 2,
        lyrics: '[Verse 1]\n雪落在指尖\n[Chorus]\n手心还有光\n[End]' }), plan(f), f.bank);
    assert.equal(Object.hasOwn(simple, 'lyricTagVersion'), false, 'model-supplied parsing flags are ignored');
});

test('musical quality remains guidance with no extra voice or hook acceptance gate', async () => {
    const f = await fixture(), m = f.get('modes/themeSong'), c = f.get('core/themeSongContract');
    for (const voice of Object.keys(c.SONG_VOICES)) {
        const p = plan(f, { voice }), prompt = m.themeSongPrompt(p, f.bank);
        assert.match(prompt, /主副歌的旋律起伏、句长或力度对比/);
        assert.match(prompt, /不把所有歌固定成高音副歌、转调或必须有桥段/);
        const raw = { title: '灯', vocalDescription: '轻声', styleDescription: '民谣', stylePrompt: 'folk',
            lyrics: '[Verse]\n灯亮了\n[Chorus]\n回来吧\n[End]' };
        assert.equal(m.normalizeGeneratedSong(f.json(raw), p, f.bank).lyrics, raw.lyrics);
    }
});
