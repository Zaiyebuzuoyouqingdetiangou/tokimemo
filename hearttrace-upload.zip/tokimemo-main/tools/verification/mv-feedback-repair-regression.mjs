import test from 'node:test';
import assert from 'node:assert/strict';
import { stageSetup } from './mv-stage-fixture.mjs';
import { ui } from './mv-ui-fixture.mjs';
import { scene, native } from './mv-stage-canvas-fixture.mjs';

function seedPending(f) {
    const scope = f.mv.mvScope(f.host), key = `heartbeatMemoriesMvV1:${scope}:pending`;
    const rows = [1, 2, 3].map(n => ({ id: `held-${n}`, scope, songId: n === 1 ? f.song.id : 'other-song', song: { title: `暂存歌曲${n}` }, raw: { image: `/paid-${n}.png` }, reason: '保存未确认' }));
    f.disk.set(key, JSON.stringify(rows));
    return { scope, key, rows };
}

test('clearing one/all pending rows persists across fresh runtimes without modifying any song record', async () => {
    const f = await stageSetup(), { scope, key } = seedPending(f), before = JSON.stringify(f.mv.readMvStore(f.host));
    f.disk.set('heartbeatMemoriesMvV1:other-chat:pending', '[{"id":"keep"}]');
    assert.equal(f.mv.clearPendingMv(scope, ['held-2']).count, 1);
    assert.deepEqual(Array.from(f.mv.pendingMv(scope), r => r.id), ['held-1', 'held-3']);
    const fresh = await stageSetup(); for (const [k, v] of f.disk) fresh.disk.set(k, v);
    assert.deepEqual(Array.from(fresh.mv.pendingMv(scope), r => r.id), ['held-1', 'held-3']);
    assert.equal(f.mv.clearPendingMv(scope, ['held-1', 'held-3']).count, 2);
    assert.equal(f.mv.pendingMv(scope).length, 0); assert.equal(JSON.parse(f.disk.get(key)).length, 0);
    assert.equal(JSON.stringify(f.mv.readMvStore(f.host)), before);
    assert.equal(f.disk.get('heartbeatMemoriesMvV1:other-chat:pending'), '[{"id":"keep"}]');
    assert.equal((await f.mv.retryMvSave(scope, 'held-2')).alreadySaved, true);
});

test('failed persistent removal keeps recoverable rows, and quota failure can remove the final journal', async () => {
    const f = await stageSetup(), { scope, key } = seedPending(f);
    f.sb.localStorage.setItem = () => { throw Error('quota'); };
    assert.equal(f.mv.clearPendingMv(scope, ['held-1']).cleared, false);
    assert.equal(f.mv.pendingMv(scope).length, 3);
    f.sb.localStorage.removeItem = k => f.disk.delete(k);
    assert.equal(f.mv.clearPendingMv(scope, ['held-1', 'held-2', 'held-3']).cleared, true);
    assert.equal(f.disk.has(key), false); assert.equal(f.mv.pendingMv(scope).length, 0);
});

// Drive the actual overlay click dispatcher, not just the MV action function.
function dispatch(f, action, id = '') {
    const element = { dataset: { rmtMv: action, rmtMvId: id } };
    const target = { closest: selector => selector === '[data-rmt-mv]' ? element : null };
    f.get('ui/overlayCore').handleOverlayClick({ target, currentTarget: { querySelector: () => null }, preventDefault() {} });
}
test('production overlay routes more/close/material navigation and confirmed clear without another generation', async () => {
    const f = await ui(stageSetup), { scope } = seedPending(f), errors = [];
    f.sb.document.querySelector = () => null; f.sb.toastr = { error: e => errors.push(e), info() {} };
    for (const g of f.record.groups) for (const d of g.diffs) d.image = { url: '/saved.png' };
    let paid = 0; f.get('generation/cgImageCore').invokeImageGeneration = async () => { paid++; };
    try {
        f.mvui.openMv({ songId: f.song.id });
        dispatch(f, 'editor-drawer', 'more'); assert.match(f.body.innerHTML, /关闭选项面板/);
        assert.equal((f.body.innerHTML.match(/data-rmt-mv="clear-pending"/g) || []).length, 4);
        dispatch(f, 'clear-pending', 'held-2'); assert.match(f.body.innerHTML, /确认清除/); assert.equal(f.mv.pendingMv(scope).length, 3);
        dispatch(f, 'cancel-clear-pending'); assert.doesNotMatch(f.body.innerHTML, /确认清除/);
        dispatch(f, 'clear-pending', 'held-2'); dispatch(f, 'confirm-clear-pending');
        assert.equal(f.mv.pendingMv(scope).length, 2); assert.doesNotMatch(f.body.innerHTML, /暂存歌曲2/);
        dispatch(f, 'editor-drawer'); assert.doesNotMatch(f.body.innerHTML, /关闭选项面板/);
        dispatch(f, 'editor-drawer', 'more'); dispatch(f, 'go-board'); assert.match(f.body.innerHTML, /构图卡片/);
        assert.doesNotMatch(f.body.innerHTML, /关闭选项面板/); assert.match(f.body.innerHTML, /<details class="rmt-mve-recovery">/);
        assert.equal(paid, 0); assert.deepEqual(errors, []);
    } finally { f.mvui.disposeMv(); }
});

class Element {
    constructor(name) { this.name = name; this.children = []; this.events = new Map(); this.inert = false; }
    appendChild(node) { node.remove(); node.parent = this; this.children.push(node); }
    remove() { if (this.parent) this.parent.children = this.parent.children.filter(n => n !== this); this.parent = null; }
    addEventListener(type, fn) { this.events.set(type, fn); }
    removeEventListener(type) { this.events.delete(type); }
    closest(name) { return this.name === name ? this : this.parent?.closest(name); }
    querySelector(name) { return this.children.find(n => n.name === name) || this.children.map(n => n.querySelector(name)).find(Boolean) || null; }
    send(type, target, key) { const e = { type, target, key, preventDefault() { this.prevented = true; }, stopPropagation() {}, stopImmediatePropagation() {} }; this.events.get(type)?.(e); return e; }
}
test('editor panel escapes the scrolling body but stays inside the native host dialog, and dismissal releases background controls', async () => {
    const f = await stageSetup(), host = new Element('dialog'), shell = new Element('.rmt-shell'), body = new Element('.rmt-body'), bar = new Element('.bar'), shade = new Element('.rmt-mve-sheet-shade'), button = new Element('button');
    host.appendChild(shell); shell.appendChild(bar); shell.appendChild(body); body.appendChild(shade); shade.appendChild(button); bar.inert = true;
    let dismissed = 0;
    const panel = f.get('ui/mvEditorDialog').mountEditorDialog(body, () => { dismissed++; });
    assert.equal(shade.parent, shell); assert.equal(shade.closest('dialog'), host); assert.equal(body.inert, true);
    shade.send('click', button); assert.equal(dismissed, 0, 'buttons must reach overlay delegation');
    shade.send('click', shade); assert.equal(dismissed, 1);
    assert.equal(shade.send('keydown', button, 'Escape').prevented, true); assert.equal(dismissed, 2);
    assert.equal(host.send('cancel', host).prevented, true); assert.equal(dismissed, 3);
    panel.dispose(); assert.equal(shade.parent, null); assert.equal(body.inert, false); assert.equal(bar.inert, true);
    assert.equal(host.events.has('cancel'), false);
    const css = f.get('ui/mvEditorUi').editorCss('#test');
    assert.match(css, /\.rmt-shell>\.rmt-mve-sheet-shade\{position:absolute;inset:0/);
    assert.match(css, /\.rmt-mve-sheet>header\{[^}]*flex:0 0 auto/);
    assert.match(css, /\.rmt-mve-sheet>div\{[^}]*min-height:0;overflow-y:auto/);
});

for (const ratio of ['16:9', '9:16']) test(`Chatu8 ${ratio} submits exact frame dimensions for shared images and per-shot redraws without changing provider settings`, async () => {
    const f = await stageSetup(), requests = [], handlers = new Map(); f.record.settings.ratio = ratio;
    f.host.extensionSettings['st-chatu8'] = { scriptEnabled: true, mode: 'novelai', novelai_width: 832, novelai_height: 1216 };
    const before = JSON.stringify(f.host.extensionSettings);
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS, imageGenerationProvider: 'chatu8-image', imageGenerationFallback: false });
    f.host.eventSource = { on: (k, v) => handlers.set(k, v), removeListener: k => handlers.delete(k), emit(k, r) {
        if (k === 'generate-image-request') { requests.push(r); handlers.get('generate-image-response')({ id: r.id, success: true, imageData: '/user/images/result.png' }); }
    } };
    await f.mv.drawAsset(f.song.id, 'G1:D1');
    f.mv.writeMv(f.mv.mvScope(f.host), f.song.id, r => { r.shots[0].image = { url: '/own.png' }; return r; });
    await f.mv.drawFrame(f.song.id, f.record.shots[0].id);
    assert.equal(requests.length, 2);
    for (const r of requests) {
        assert.equal(r.width / r.height, ratio === '16:9' ? 16 / 9 : 9 / 16);
        assert.equal(r.width % 64, 0); assert.equal(r.height % 64, 0);
    }
    assert.equal(JSON.stringify(f.host.extensionSettings), before);
});

function edgeArt() {
    const c = native.createCanvas(320, 180), g = c.getContext('2d');
    g.fillStyle = '#ed314a'; g.fillRect(0, 82, 320, 16); // arms intentionally end at both source edges
    g.fillRect(142, 40, 36, 140); // body intentionally ends at the bottom edge
    return { url: c.toDataURL(), editMode: 'cutout', split: 'none' };
}
for (const ratio of ['16:9', '9:16']) test(`native Canvas ${ratio}: source-cut arms stay at frame edges and cropped body has no floating bottom`, async () => {
    const f = await scene({ ratio, imageBackground: true, createArt: edgeArt, configure: r => {
        r.groups[0].scale = 'full'; r.groups[0].motion = 'push'; r.tegaki.lyric = 'none';
        r.shots[0].cut = 'cut'; r.shots[0].stage.entrance = 'slide';
    } });
    const redCount = (x, y, w, h) => {
        const data = f.preview.getContext('2d').getImageData(x, y, w, h).data; let total = 0;
        for (let i = 0; i < data.length; i += 4) if (data[i] > 180 && data[i + 1] < 90 && data[i + 2] < 120) total++;
        return total;
    };
    try {
        const before = JSON.stringify(f.record());
        for (const t of [.01, .12, 1, 3.8]) {
            f.seek(t);
            assert.ok(redCount(0, 0, 2, f.h) > 20, 'left cut arm must meet the left frame edge');
            assert.ok(redCount(f.w - 2, 0, 2, f.h) > 20, 'right cut arm must meet the right frame edge');
            assert.ok(redCount(0, f.h - 2, f.w, 2) > 20, 'cropped torso must meet the bottom, not float above it');
        }
        assert.equal(JSON.stringify(f.record()), before); assert.equal(f.calls(), 0);
    } finally { f.mvui.disposeMv(); }
});

test('native export uses the same edge-attached framing as preview and leaves source pixels unchanged', async () => {
    const f = await scene({ imageBackground: true, createArt: edgeArt, configure: r => {
        r.groups[0].scale = 'full'; r.groups[0].motion = 'still'; r.tegaki.lyric = 'none'; r.shots[0].cut = 'cut';
    } });
    let clock = 1000, output, started, scheduled, timer;
    const start = new Promise(resolve => { started = resolve; }), loop = new Promise(resolve => { scheduled = resolve; });
    const raf = f.sb.requestAnimationFrame;
    f.sb.requestAnimationFrame = fn => { const id = raf(fn); if (fn.name === 'loop' && output) scheduled(); return id; };
    f.sb.performance.now = () => clock;
    f.sb.MediaStream = class { constructor(tracks) { this.tracks = tracks; } };
    f.sb.AudioContext = class {};
    f.sb.MediaRecorder = class {
        static isTypeSupported() { return true; }
        constructor(stream) { this.state = 'inactive'; output = stream.tracks[0].canvas; }
        start() { this.state = 'recording'; started(); }
        stop() { this.state = 'inactive'; this.onstop?.(); }
    };
    const pixels = c => Buffer.from(c.getContext('2d').getImageData(0, 0, c.width, c.height).data);
    try {
        const before = JSON.stringify(f.record()); f.seek(1); const expected = pixels(f.preview);
        f.click('export');
        await Promise.race([Promise.all([start, loop]), new Promise((_, reject) => { timer = setTimeout(() => reject(Error('export not started')), 5000); })]);
        clock = 2000;
        for (const [id, tick] of [...f.frames]) { f.frames.delete(id); tick(); }
        assert.deepEqual(pixels(output), expected);
        assert.equal(JSON.stringify(f.record()), before); assert.equal(f.calls(), 0);
    } finally { clearTimeout(timer); f.mvui.disposeMv(); }
});
