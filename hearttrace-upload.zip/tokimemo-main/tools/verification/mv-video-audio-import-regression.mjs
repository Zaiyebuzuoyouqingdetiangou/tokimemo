// Production bundle, real MP4/MOV container inspection. Host/media decoder and
// recorder are doubles: passing this suite is not real-device playback proof.
import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';
import { ui, recorderHost } from './mv-ui-fixture.mjs';
import { audioSourceFixtures } from './mv-audio-source-fixtures.mjs';

const recordings = audioSourceFixtures();
test.after(() => recordings.cleanup());
const song = { id: 'VIDEO_AUDIO', title: '当前歌曲', lyrics: '[Verse 1]\n一句\n[Chorus]\n二句\n[End]' };
const fileFor = kind => Object.assign(new Blob([recordings[kind].bytes], { type: recordings[kind].type }), { name: recordings[kind].name });
const flush = async () => { for (let i = 0; i < 12; i++) await new Promise(resolve => setImmediate(resolve)); };
async function until(fn) { for (let i = 0; i < 300; i++) { if (fn()) return; await new Promise(resolve => setImmediate(resolve)); } assert.ok(fn(), 'pending fixture step finished'); }
async function setup(stored = new Map()) {
    const f = await ui(fixture), mv = f.get('extras/mv'), errors = [], writes = [], revoked = [], reads = [];
    f.sb.document.querySelector = () => null;
    f.sb.toastr = { error: message => errors.push(message), success() {}, info() {}, warning() {} };
    f.sb.URL.revokeObjectURL = url => revoked.push(url);
    f.get('core/cache').loadSession = () => ({ songs: [song, { ...song, id: 'OTHER', title: '另一首' }] });
    const record = { id: song.id, version: 1, duration: 120, settings: { output: 'tegaki', range: 'full', appear: 'none' },
        tegaki: { range: 'full', lyric: 'none', introSeconds: 0, outroSeconds: 0, showMotif: false },
        timing: { taps: { 0: 0, 1: 60 }, lineTaps: { '0:0': 0 }, shift: 0 },
        shots: [{ id: 'A', sectionIndex: 0, lyric: '一句', plain: 'room', who: 'none' }, { id: 'B', sectionIndex: 1, lyric: '二句', plain: 'room', who: 'none' }] };
    f.host.chatMetadata[mv.MV_KEY] = { songs: { [song.id]: record, OTHER: { ...structuredClone(record), id: 'OTHER' } } };
    f.get('extras/mvMedia').getMedia = async key => { reads.push(key); return stored.get(key) || null; };
    f.get('extras/mvMedia').putMedia = async (key, blob, name, details = {}) => { const row = { blob, name, ...details }; stored.set(key, row); writes.push({ key, ...row }); return true; };
    f.mvui.openMv({ songId: song.id }); f.click('go-tegaki'); f.click('editor-drawer', 'audio');
    const uploadVideo = file => f.mvui.handleMvChange({ target: { matches: selector => selector === '[data-rmt-mv-audio]', files: [file] } });
    const ready = async (probe = f.audios.at(-1)) => { probe.duration = 1; probe.readyState = 2; probe.onloadeddata(); await flush(); };
    const oldAudio = async () => { f.upload(); f.audios.at(-1).onloadedmetadata(); await flush(); f.click('play'); await flush(); return f.audios.at(-1); };
    return { ...f, mv, errors, writes, revoked, reads, stored, record, uploadVideo, ready, oldAudio, saved: () => mv.readMv(f.host, song.id) };
}

test('existing song file control includes MP4 and MOV without changing the storyboard', async () => {
    const f = await setup(); try { assert.match(f.body.innerHTML, /accept="audio\/\*,video\/mp4,video\/quicktime,[^"]*\.mov/); assert.match(f.body.innerHTML, /选择音频、录屏/); assert.equal(f.saved().shots.length, 2); } finally { f.mvui.disposeMv(); }
});
for (const kind of ['mp4', 'mov', 'fragmented']) test(`${kind}: metadata alone cannot replace the old song; decoded data commits original container`, async () => {
    const f = await setup(); try {
        const old = await f.oldAudio(), before = JSON.stringify(f.saved().timing), file = fileFor(kind);
        f.uploadVideo(file); const probe = f.audios.at(-1); await until(() => probe.src);
        probe.readyState = 1; probe.duration = 1; probe.onloadedmetadata(); await flush();
        assert.equal(f.writes.length, 1); assert.equal(f.saved().duration, 123); assert.equal(old.paused, false);
        await f.ready(probe);
        assert.equal(f.writes.length, 2); assert.equal(f.writes[1].blob, file); assert.equal(f.saved().duration, 1);
        assert.equal(old.paused, true); assert.equal(JSON.stringify(f.saved().timing), before); assert.equal(f.saved().shots.length, 2);
        assert.match(f.body.innerHTML, /视频音轨/); assert.deepEqual(f.errors, []);
    } finally { f.mvui.disposeMv(); }
});
for (const kind of ['silent', 'emptyTrack', 'damaged']) test(`${kind}: rejected before media load and keeps old audio, duration, timing and saved file`, async () => {
    const f = await setup(); try {
        const old = await f.oldAudio(), before = JSON.stringify(f.saved());
        f.uploadVideo(fileFor(kind)); const probe = f.audios.at(-1); await until(() => f.errors.length);
        assert.equal(probe.src, undefined); assert.equal(JSON.stringify(f.saved()), before); assert.equal(f.writes.length, 1);
        assert.equal(old.paused, false); assert.ok(!f.revoked.includes(old.src));
    } finally { f.mvui.disposeMv(); }
});
test('host decode error after valid audio-track inspection preserves old song', async () => {
    const f = await setup(); try {
        const old = await f.oldAudio(), before = JSON.stringify(f.saved());
        f.uploadVideo(fileFor('mp4')); const probe = f.audios.at(-1); await until(() => probe.src);
        probe.onerror(); await flush(); assert.equal(f.writes.length, 1); assert.equal(JSON.stringify(f.saved()), before); assert.equal(old.paused, false);
        assert.match(f.errors[0], /没法播放/);
    } finally { f.mvui.disposeMv(); }
});
test('video audio shares preview play, pause, seek, timing marks and export source', async () => {
    const f = await setup(); try {
        f.uploadVideo(fileFor('mp4')); const probe = f.audios.at(-1); await until(() => probe.src); await f.ready(probe);
        f.click('play'); await flush(); const audio = f.audios.at(-1); assert.equal(audio.paused, false);
        f.mvui.handleMvChange({ target: { matches: selector => selector === '[data-rmt-mv-seek]', value: '0.4' } });
        assert.equal(audio.currentTime, 0.4); f.click('tap-line', '0:0'); assert.equal(f.saved().timing.lineTaps['0:0'], 0.4);
        f.click('play'); await flush(); assert.equal(audio.paused, true);
        const host = recorderHost(f); f.click('export'); await flush();
        assert.equal(f.audios.at(-1).src, audio.src); assert.equal(host.contexts.length, 1); assert.equal(host.recorders[0].state, 'recording'); f.click('export-stop');
        assert.equal(host.contexts[0].closed, true);
    } finally { f.mvui.disposeMv(); }
});
test('a newer file selection wins over a delayed video decoder result', async () => {
    const f = await setup(); try {
        f.uploadVideo(fileFor('mp4')); const first = f.audios.at(-1); await until(() => first.src); const late = first.onloadeddata;
        f.uploadVideo(fileFor('mov')); const second = f.audios.at(-1); await until(() => second.src); await f.ready(second);
        first.readyState = 2; first.duration = 900; late(); await flush();
        assert.equal(f.writes.length, 1); assert.equal(f.writes[0].name, recordings.mov.name); assert.equal(f.saved().duration, 1);
    } finally { f.mvui.disposeMv(); }
});
test('switching songs during track inspection or decoding never commits into either song', async () => {
    for (const loaded of [false, true]) {
        const f = await setup(); try {
            f.uploadVideo(fileFor('mp4')); const probe = f.audios.at(-1), late = probe.onloadeddata;
            if (loaded) await until(() => probe.src);
            f.mvui.openMv({ songId: 'OTHER' }); probe.readyState = 2; probe.duration = 300; late(); await flush();
            assert.equal(f.writes.length, 0); assert.equal(f.saved().duration, 120); assert.equal(f.mv.readMv(f.host, 'OTHER').duration, 120);
        } finally { f.mvui.disposeMv(); }
    }
});
test('fresh runtime restores original video container and validates it before use', async () => {
    const stored = new Map(), first = await setup(stored);
    try { first.uploadVideo(fileFor('mov')); const probe = first.audios.at(-1); await until(() => probe.src); await first.ready(probe); } finally { first.mvui.disposeMv(); }
    const second = await setup(stored); try {
        await until(() => second.audios.at(-1)?.src); const probe = second.audios.at(-1); await second.ready(probe);
        assert.equal(second.writes.length, 0); assert.match(second.body.innerHTML, /有声录屏.mov/); assert.match(second.body.innerHTML, /视频音轨/);
        second.click('play'); await flush(); assert.equal(second.audios.at(-1).paused, false);
    } finally { second.mvui.disposeMv(); }
});
test('failed cached-video restore stops after one attempt instead of retrying on its own redraw', async () => {
    const stored = new Map(), first = await setup(stored);
    try { first.uploadVideo(fileFor('mov')); const probe = first.audios.at(-1); await until(() => probe.src); await first.ready(probe); } finally { first.mvui.disposeMv(); }
    const row = [...stored.values()][0]; row.blob = fileFor('damaged'); row.name = recordings.damaged.name;
    const second = await setup(stored); try {
        await until(() => second.errors.length); await flush(); second.mvui.renderMv(); await flush();
        assert.equal(second.errors.length, 1); assert.equal(second.audios.length, 1); assert.equal(second.reads.length, 1); assert.equal(second.writes.length, 0);
        second.mvui.openMv({ songId: song.id }); second.click('go-tegaki'); await until(() => second.errors.length === 2);
        assert.equal(second.reads.length, 2, 'explicit reopen may try the saved file again');
    } finally { second.mvui.disposeMv(); }
});
