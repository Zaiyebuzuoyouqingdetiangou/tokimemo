import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { webcrypto } from 'node:crypto';
const root=path.resolve(process.env.TEST_ROOT || 'candidate-r84185/tokimemo-main');
const source=fs.readFileSync(path.join(root,'dist/heartbeatMemories.bundle.js'),'utf8');
export async function fixture() {
 const sb={console,TextEncoder,TextDecoder,URL,URLSearchParams,AbortController,DOMException,structuredClone,queueMicrotask,setTimeout,clearTimeout,setInterval,clearInterval,crypto:webcrypto,Response,Headers,
 document:{getElementById:()=>null,querySelector:()=>null}};
 const names=[...source.matchAll(/^const (__m_\w+) = Object.create\(null\);/gm)].map(x=>x[1]);
 const m=new vm.SourceTextModule(source+'\nexport { '+names.join(',')+' };',{context:vm.createContext(sb)});await m.link(()=>{});await m.evaluate();
 const get=p=>m.namespace['__m_'+(p+'.js').replace(/[^a-zA-Z0-9]/g,'_')];
 const constants=get('core/constants');
 const bank={version:3,archiveRevision:'r1',chatId:'A',characterName:'Char',userName:'User',memories:[{id:'M001',title:'事件',summary:'普通相处',anchors:['事件']}]};
 const host={characterId:0,characters:[{name:'Char',avatar:'char.png',data:{description:'test'}}],name1:'User',name2:'Char',chat:[],chatId:'A',getCurrentChatId(){return this.chatId},chatMetadata:{[constants.MEMORY_KEY]:bank},extensionSettings:{},getTokenCountAsync:async()=>1,saveMetadataDebounced:()=>{}};
 let live=host;sb.SillyTavern={getContext:()=>live};
 const disk=new Map();sb.localStorage={getItem:k=>disk.get(k)??null,setItem:(k,v)=>disk.set(k,v)};
 get('archive/repository').requireArchive=(c=live)=>{const b=c.chatMetadata[constants.MEMORY_KEY];if(!b)throw Error('missing archive');return b;};
 return {get,sb,host,bank,disk,switchTo:c=>{live=c},constants,json:value=>vm.runInContext("JSON.parse("+JSON.stringify(JSON.stringify(value))+")",m.context)};
}
const waitingRaw=()=>({points:[{id:'P1',name:'书桌',state:'想念',detail:'台历上 9 月 17 日',voice:'回来吧'}],locked:[],letter:{title:'信',body:'等你'},roomNode:{text:'灯还亮着'}});
export function realClient(f, onRequest) {
 const {get,host,constants}=f;
 host.ConnectionManagerRequestService={validateProfile:()=>({selected:'openai',source:'openai'}),sendRequest:async()=>({choices:[{message:{content:JSON.stringify(await onRequest())}}]})};
 get('core/settings').getPluginSettings=()=>({...constants.DEFAULT_SETTINGS,apiConnectionMode:'profile',connectionProfileId:'TEST',maxTokens:120000});
 get('core/settings').prepareManualCredential=async()=>{};
 get('core/independentApi').assertConnectionManagerProfileSupport=()=>{};
 get('core/settings').rawConnectionProfile=()=>({id:'TEST',api:'openai'});
 get('core/settings').resolvedProfileTransportFingerprint=async()=> 'TEST';
 get('core/cache').buildControlledContextEnvelope=async()=>'';
 get('core/requestCoordinator').refreshConcurrentTaskUi=()=>{};
}
