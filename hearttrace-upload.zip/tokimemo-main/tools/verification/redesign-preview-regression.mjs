import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {preview,html} from './redesign-preview-fixture.mjs';

test('self-contained preview loads reference pixels and one shared player',async()=>{
 const f=await preview();assert.equal(f.node('filmstrip').children.length,17);
 assert.equal(f.document.querySelectorAll('#play').length,1);assert.equal(f.document.querySelectorAll('#seek').length,1);
 assert.equal(f.node('stage').classList.contains('ready'),true);
 assert.ok(f.node('screen').getContext().getImageData(480,270,1,1).data[3]>0);
 assert.doesNotMatch(html,/<(?:script|img|link)[^>]*(?:src|href)="https?:/);
 assert.doesNotMatch(html,/\b(?:fetch|XMLHttpRequest|WebSocket)\s*\(/);
});
test('selecting and seeking follow one current shot and retain 17 visible choices',async()=>{
 const f=await preview();f.node('filmstrip').children[6].click();assert.equal(f.node('shot-number').textContent,'第 7 镜');assert.equal(f.node('seek').value,'42.7');
 f.node('seek').value='40.5';f.node('seek').fire('input');assert.equal(f.node('shot-number').textContent,'第 6 镜');
 f.node('all-shots').click();assert.equal(f.node('sheet-body').querySelectorAll('.shot').length,17);assert.equal(f.node('sheet').open,true);
});
test('play pause and focus view are reversible without resetting the timeline',async()=>{
 const f=await preview();f.node('play').click();f.frame(1000);f.frame(2000);assert.equal(f.node('clock').textContent,'0:41.3');
 f.node('play').click();const before=f.node('clock').textContent;f.frame(4000);assert.equal(f.node('clock').textContent,before);
 f.node('focus').click();assert.ok(f.node('studio').classList.contains('focus-mode'));f.node('focus').click();assert.ok(!f.node('studio').classList.contains('focus-mode'));
});
test('tabs have keyboard navigation and portrait ratio keeps original width-height relationship',async()=>{
 const f=await preview();f.node('tab-shots').fire('keydown',{key:'ArrowRight'});assert.equal(f.focused(),'tab-timing');assert.equal(f.node('panel-shots').hidden,true);assert.equal(f.node('panel-timing').hidden,false);
 f.node('tab-style').click();f.node('ratio-tall').click();assert.equal(f.node('screen').width,540);assert.equal(f.node('screen').height,960);assert.ok(f.node('stage').classList.contains('portrait'));
 f.node('ratio-wide').click();assert.equal(f.node('screen').width,960);assert.equal(f.node('screen').height,540);
});
test('image editor keeps save controls, foldable tools, zoom reset and next-shot navigation',async()=>{
 const f=await preview();f.node('edit-image').click();assert.ok(f.node('image-dialog').open);assert.ok(f.node('edit-options').hidden);
 f.node('zoom-in').click();assert.equal(f.node('zoom-value').textContent,'125%');f.node('fit-image').click();assert.equal(f.node('zoom-value').textContent,'100%');
 const brush=f.document.querySelectorAll('[data-mode]').find(n=>n.dataset.mode==='brush');brush.click();assert.equal(f.node('edit-options').hidden,false);brush.click();assert.equal(f.node('edit-options').hidden,true);
 f.node('image-next').click();assert.equal(f.node('image-title').textContent,'编辑第 7 镜');assert.ok(f.node('image-dialog').open);f.node('image-save').click();assert.equal(f.node('image-dialog').open,false);
 assert.equal(f.node('image-save').parent.className,'image-footer');assert.equal(f.node('image-undo').parent.className,'image-footer');
});
test('README view and release dialog share the exact current README and do not show history',async()=>{
 const f=await preview(),expected=fs.readFileSync(path.join(process.env.TEST_ROOT||'.','README.md'),'utf8');
 f.node('more').click();f.node('readme').click();assert.equal(f.node('sheet-body').textContent,expected);
 f.node('sheet-close').click();f.node('more').click();f.node('notes').click();assert.match(f.node('sheet-body').textContent,/@nancyindaeyo/);assert.match(f.node('sheet-body').textContent,/图片编辑保留/);assert.doesNotMatch(f.node('sheet-body').textContent,/234|1\.0\.26/);
});
test('timing edits are local and undo restores the previous marks',async()=>{
 const f=await preview();const before=f.run('JSON.stringify(marks)');f.node('seek').value='41';f.node('seek').fire('input');f.node('mark-time').click();assert.equal(f.run('marks[1]'),41);f.node('undo-mark').click();assert.equal(f.run('JSON.stringify(marks)'),before);
});
test('release text containing markup remains inert in the prototype',async()=>{
 const f=await preview('# 心迹回廊 1.0.27\n\n## 本次变动\n- <img src=x onerror=alert(1)>\n');f.node('more').click();f.node('notes').click();assert.equal(f.node('sheet-body').querySelectorAll('img').length,0);assert.match(f.node('sheet-body').textContent,/<img src=x onerror=alert\(1\)>/);
});
