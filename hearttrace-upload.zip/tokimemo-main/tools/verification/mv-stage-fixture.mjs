import { fixture } from './fixture.mjs';
export const song = { id: 'SONG_stage', title: '舞台', lyrics: '[Verse 1]\n抬眼\n看向我\n[Chorus]\n再抬眼\n[End]' };
export function stageRaw(kind = 'rays') {
    return { stage: { backgrounds: [{ id: 'main', label: '主舞台', kind, colors: ['#162538', '#e8cf91', '#cc5679'], motion: 'rotate', prompt: 'empty paper stage' }] },
        groups: [
            { id: 'A', composition: '正面半身', stageBackground: 'main', scale: 'medium', position: 'center', who: 'char',
                diffs: [{ id: 'open', label: '摊手笑', imagePrompt: 'one boy, open palms, broad smile' }] },
            { id: 'B', composition: '侧身抱臂', stageBackground: 'main', scale: 'medium', position: 'left', who: 'char',
                diffs: [{ id: 'crossed', label: '抱臂', imagePrompt: 'one boy, arms crossed, confident gaze' }] },
        ], frames: [
            { sectionIndex: 0, lyric: '抬眼', group: 'A', diff: 'open', hold: 1, stage: { text: '抬眼', layout: 'sides', entrance: 'pop' } },
            { sectionIndex: 0, lyric: '看向我', group: 'A', diff: 'open', hold: 1, stage: { text: '看向我', layout: 'stack', entrance: 'pop' } },
            { sectionIndex: 1, lyric: '再抬眼', group: 'B', diff: 'crossed', hold: 1, stage: { text: '再抬眼', layout: 'banner', entrance: 'slide' } },
            { sectionIndex: 1, lyric: '再抬眼', group: 'A', diff: 'open', hold: 1, stage: { text: '再抬眼', layout: 'sides', tone: 'accent', entrance: 'pop' } },
        ] };
}
export async function stageSetup(kind = 'rays') {
    const f = await fixture(), mv = f.get('extras/mv');
    f.get('core/cache').loadSession = () => ({ songs: [song] });
    const settings = mv.normalizeSettings({ output: 'tegaki', ratio: '16:9', range: 'full', storyType: 'expression' });
    const built = mv.buildShots(f.json(stageRaw(kind)), f.bank, 2, settings);
    built.stage.backgrounds[0].kind = kind; // Existing/user-selected pattern fixture.
    const record = { ...built, id: song.id, settings, createdAt: 1, duration: 16,
        timing: { taps: { 0: 0, 1: 8 }, lineTaps: { '0:0': 0, '0:1': 4, '1:0': 8 } },
        tegaki: { range: 'full', lyric: 'stage', introSeconds: 0, outroSeconds: 0, showKeyword: false, showMotif: false } };
    f.host.chatMetadata[mv.MV_KEY] = { songs: { [song.id]: record } };
    return { ...f, mv, song, record };
}

