// Production bundle actions; DOM geometry still needs a real browser/device.
import test from 'node:test';
import assert from 'node:assert/strict';
import { ui } from './mv-ui-fixture.mjs';
import { stageSetup } from './mv-stage-fixture.mjs';
const flush = () => new Promise(resolve => setImmediate(resolve));
async function setup(change = () => {}) {
    const f = await ui(stageSetup), errors = [], classes = new Set();
    f.body.classList = { toggle(k, v) { if (v) classes.add(k); else classes.delete(k); }, remove(k) { classes.delete(k); } };
    f.sb.document.querySelector = () => null;
    f.sb.toastr = { error: text => errors.push(text), success() {}, info() {} };
    for (const g of f.record.groups) for (const d of g.diffs) d.image = { url: `/user/images/${g.id}-${d.id}.png` };
    change(f.record);
    let paid = 0;
    f.get('generation/cgImageCore').invokeImageGeneration = async () => { paid++; throw Error('unexpected generation'); };
    f.mvui.openMv({ songId: f.song.id });
    return { ...f, errors, classes, saved: () => f.mv.readMv(f.host, f.song.id), paid: () => paid };
}

test('production editor has bounded workbench, independent tools scroll and a single top music entry', async () => {
    const f = await setup(); try {
        assert.ok(f.classes.has('rmt-mve-body'));
        assert.match(f.body.innerHTML, /rmt-mve-projectbar/);
        assert.match(f.body.innerHTML, /rmt-mve-panel-scroll/);
        assert.equal((f.body.innerHTML.match(/data-rmt-mv-id="audio"/g) || []).length, 1);
        assert.doesNotMatch(f.body.innerHTML.split('rmt-mve-transport')[1].split('rmt-mve-meta')[0], /data-rmt-mv-id="audio"/);
        assert.match(f.body.innerHTML, /data-rmt-mv="editor-step"/);
        f.click('go-board'); assert.ok(!f.classes.has('rmt-mve-body'));
        f.click('go-tegaki'); assert.ok(f.classes.has('rmt-mve-body'));
        f.mvui.disposeMv(); assert.ok(!f.classes.has('rmt-mve-body'));
    } finally { f.mvui.disposeMv(); }
});

test('preview-only mode and shot stepping preserve all images and timing and keep one clock', async () => {
    const f = await setup(); try {
        const before = JSON.stringify(f.saved());
        f.click('editor-preview'); assert.match(f.body.innerHTML, /data-preview-only="true"/);
        assert.equal((f.body.innerHTML.match(/data-rmt-mv-seek/g) || []).length, 1);
        f.click('editor-preview'); assert.match(f.body.innerHTML, /data-preview-only="false"/);
        f.click('editor-step', '1'); assert.match(f.body.innerHTML, /第 2 镜/);
        f.click('editor-step', '-1'); assert.match(f.body.innerHTML, /第 1 镜/);
        assert.equal(JSON.stringify(f.saved()), before); assert.equal(f.paid(), 0);
    } finally { f.mvui.disposeMv(); }
});

test('shared material editor supplies save-and-next and returns directly to the workbench', async () => {
    const f = await setup(); const mounted = [];
    f.body.querySelector = s => s === '[data-rmt-mv-editor-host]' ? {} : null;
    f.get('ui/mvImageEditor').mountAssetEditor = (_host, options) => { mounted.push(options); return { dispose() {} }; };
    try {
        f.click('edit-asset', 'G1:D1'); await flush();
        assert.equal(typeof mounted[0].onNext, 'function');
        assert.match(mounted[0].title, /第 1 镜/);
        await mounted[0].onNext(); await flush();
        assert.match(mounted[1].title, /第 2 镜/);
        mounted[1].onClose(); assert.match(f.body.innerHTML, /rmt-mve-workspace/);
        assert.match(f.body.innerHTML, /第 2 镜/);
        assert.equal(f.paid(), 0); assert.deepEqual(f.errors, []);
    } finally { f.mvui.disposeMv(); }
});

test('a single-shot replacement opens its own image editor and saves without changing the shared image or prompts', async () => {
    const f = await setup(r => { r.shots[0].image = { url: '/own-shot.png' }; }); let editor;
    f.body.querySelector = s => s === '[data-rmt-mv-editor-host]' ? {} : null;
    f.get('ui/mvImageEditor').mountAssetEditor = (_host, options) => { editor = options; return { dispose() {} }; };
    f.get('extras/mvMedia').putMedia = async () => true;
    try {
        const before = JSON.parse(JSON.stringify(f.saved()));
        assert.match(f.body.innerHTML, /data-rmt-mv="edit-frame"/);
        f.click('edit-frame', before.shots[0].id); await flush();
        assert.equal(editor.sourceUrl, '/own-shot.png'); assert.equal(editor.autoCharacter, false);
        assert.equal(await editor.onSave({ image: { blob: new Blob(['png']), originalRef: before.shots[0].image, crop: { x: 0, y: 0, w: 1, h: 1 }, mode: 'full' } }), true);
        const after = JSON.parse(JSON.stringify(f.saved()));
        assert.ok(after.shots[0].image.local); assert.equal(after.shots[0].image.original.url, '/own-shot.png');
        assert.deepEqual(after.groups, before.groups); assert.deepEqual(after.timing, before.timing);
        assert.deepEqual(after.assetPrompts, before.assetPrompts); assert.equal(f.paid(), 0);
    } finally { f.mvui.disposeMv(); }
});

test('production image editor markup contains the canvas before local tool panes and permanent save actions', async () => {
    const f = await setup(); try {
        const html = f.get('ui/mvImageEditorUi').imageEditorMarkup({ hasNext: true });
        assert.ok(html.indexOf('data-editor-canvas') < html.indexOf('data-select-tools'));
        for (const action of ['select','crop','paint','auto','erase','restore','region','pan','undo','reset','original','default-prompt','download','save','save-next','close']) assert.ok(html.includes(`data-edit="${action}"`), action);
        assert.match(html, /rmt-mvi-footer/); assert.match(html, /data-editor-prompt/);
        assert.match(html, /data-import="full"/); assert.match(html, /data-import="cutout"/);
        assert.match(html, /data-edit="compare"/); assert.match(html, /data-matte="dark"/);
    } finally { f.mvui.disposeMv(); }
});

test('a workspace route replacement releases editor-specific body scrolling and its observer', async () => {
    const f = await setup(); let notify, disconnected = 0, observed;
    f.sb.MutationObserver = class {
        constructor(fn) { notify = fn; }
        observe(el, opts) { observed = opts; }
        disconnect() { disconnected++; }
    };
    try {
        f.mvui.openMv({ songId: f.song.id });
        assert.equal(observed.childList, true); assert.equal(observed.subtree, undefined);
        assert.ok(f.classes.has('rmt-mve-body'));
        f.body.innerHTML = '<section>其他内容</section>'; f.body.querySelector = () => null;
        notify(); assert.ok(!f.classes.has('rmt-mve-body')); assert.equal(disconnected, 1);
    } finally { f.mvui.disposeMv(); }
});

test('panel position survives its own setting redraw but does not leak into another tab', async () => {
    const f = await setup();
    let html = f.body.innerHTML;
    const panel = { dataset: { rmtMvScroll: 'shots' }, scrollTop: 123 };
    f.body.querySelectorAll = selector => selector === '[data-rmt-mv-scroll]' ? [panel] : [];
    Object.defineProperty(f.body, 'innerHTML', { get: () => html, set(value) {
        html = value; panel.scrollTop = 0; panel.dataset.rmtMvScroll = value.match(/data-rmt-mv-scroll="([^"]+)"/)?.[1] || '';
    } });
    try {
        f.mvui.renderMv(); assert.equal(panel.scrollTop, 123);
        f.click('editor-tab', 'timing'); assert.equal(panel.scrollTop, 0);
        panel.scrollTop = 88; f.mvui.renderMv(); assert.equal(panel.scrollTop, 88);
    } finally { f.mvui.disposeMv(); }
});
