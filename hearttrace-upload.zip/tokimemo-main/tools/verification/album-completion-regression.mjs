// Shipped bundle with deterministic host/provider/storage doubles; no paid requests.
import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture, realClient } from './fixture.mjs';
const plain = value => JSON.parse(JSON.stringify(value));
const comments = id => Array.from({ length: 6 }, (_, n) => `${id}的共同回忆第${n + 1}段。`);
const relationship = { charState: '未确认', userState: '未确认', relationshipState: '普通相处',
    relationshipSummary: '普通相处', relationshipSourceMemoryIds: ['M001'], relationshipSourceMemoryAnchor: '事件' };
const entry = n => ({ id: `CG${n}`, title: `旧相片${n}`, date: '10/01', desc: `事件中的画面${n}`, unlocked: true,
    category: '约会', categoryManual: true, visualSeed: ['窗', '灯', '书', '雨'], sourceMemoryIds: ['M001'],
    sourceMemoryAnchor: '事件', comments: [], relationshipSnapshot: null, cgImage: { key: `paid-${n}`, customImage: true },
    imageEdit: { crop: [0, 0, 1, 1] }, userNote: `保留${n}` });
const previousAlbum = () => ({ kind: 'album', title: '原相簿', entries: Array.from({ length: 6 }, (_, n) => entry(n + 1)),
    selectedId: 'CG4', page: 2, category: '约会', sharedMemory: true, dialogueIndex: 2, hintVisible: true,
    generationMeta: { contentSelection: { schemaVersion: 1, scannedMemoryIds: ['M001'], last: { memoryIds: ['M001'], added: 6 } } },
    userMetadata: { text: '旧册字段' } });
const envelope = raw => ({ choices: [{ message: { content: JSON.stringify(raw) }, finish_reason: 'stop' }] });
const connectionError = () => ({ id: 'tauritavern-error-1791125779', object: 'chat.completion',
    choices: [{ message: { content: '[API 错误]\n服务异常' }, finish_reason: 'stop' }] });

async function setup({ previous = previousAlbum(), existing = null, failComment = -1, gate = null } = {}) {
    const f = await fixture(), g = f.get, calls = [], journals = [], partials = [], commits = [], errors = [];
    f.sb.structuredClone = value => value === undefined ? undefined : f.json(structuredClone(value));
    f.sb.console = { ...console, error: (...args) => errors.push(args), warn: () => {} };
    realClient(f, () => ({}));
    const settings = g('core/settings').getPluginSettings();
    g('core/settings').getPluginSettings = () => ({ ...settings, autoSecondPass: false });
    g('core/cache').loadSession = mode => mode === 'album' ? previous : null;
    g('core/cache').loadGenerationRecovery = () => existing ? f.json(existing) : null;
    g('core/cache').claimLiveModeGeneration = async () => {};
    g('core/cache').saveGenerationRecovery = async (context, bank, mode, journal) => { if (journal) journals.push(plain(journal)); return true; };
    g('core/cache').saveGenerationTaskResult = async (context, mode, session) => { partials.push(plain(session)); return { durable: true }; };
    g('core/cache').commitSession = async (mode, session) => { commits.push(plain(session)); return true; };
    g('ui/settingsPanel').refreshSettingsMemoryStatus = () => {};
    let commentIndex = 0;
    f.host.ConnectionManagerRequestService.sendRequest = async (profile, messages) => {
        const prompt = messages[0].content;
        if (!prompt.includes('UNTRUSTED_ALBUM_COMMENT_CONTEXT_JSON:')) {
            if (prompt.includes('CURRENT_RELATIONSHIP_SCAN_JSON:') || prompt.includes('UNTRUSTED_INCREMENTAL_CG_ARCHIVE_JSON:')) {
                calls.push({ kind: 'index' }); throw new Error('Unexpected new CG request during dialogue completion');
            }
            calls.push({ kind: 'relationship' }); return envelope(relationship);
        }
        const payload = JSON.parse(prompt.split('UNTRUSTED_ALBUM_COMMENT_CONTEXT_JSON:\n')[1].split('\n\n严格输出')[0]);
        const index = commentIndex++;
        calls.push({ kind: 'comments', ids: payload.entries.map(row => row.id), index });
        if (gate) await gate(index);
        if (index === failComment) return connectionError();
        return envelope({ items: payload.entries.map(row => ({ id: row.id, comments: comments(row.id) })) });
    };
    const run = options => g('generation/generationModes').generateMode('album', {
        background: true, participantSnapshot: null,
        ...(existing ? { existing: f.json(existing), continueRecovery: true } : { newTask: true }), ...options,
    });
    return { ...f, calls, journals, partials, commits, errors, previous, run };
}

test('album second-step intent is saved before requests and old pictures/fields are preserved on completion', async () => {
    const f = await setup(), before = plain(f.previous);
    const result = await f.run({ secondStep: true });
    assert.ok(result); assert.equal(f.journals[0].operation.secondStep, true);
    assert.deepEqual(f.calls.map(row => row.kind), ['relationship', 'comments', 'comments']);
    assert.equal(f.commits.length, 1);
    for (const row of result.entries) assert.equal(row.comments.length, 6);
    for (const key of ['selectedId', 'page', 'category', 'sharedMemory', 'dialogueIndex', 'hintVisible', 'generationMeta', 'userMetadata']) {
        assert.deepEqual(plain(result[key]), before[key], key);
    }
    for (let n = 0; n < before.entries.length; n++) for (const key of ['cgImage', 'imageEdit', 'categoryManual', 'userNote']) {
        assert.deepEqual(plain(result.entries[n][key]), before.entries[n][key], key);
    }
    assert.deepEqual(plain(f.previous), before);
});

test('failed dialogue batch keeps successful partials readable and fresh runtime resumes only missing dialogue', async () => {
    const first = await setup({ failComment: 1 });
    assert.equal(await first.run({ secondStep: true }), null);
    const journal = first.journals.at(-1);
    assert.equal(journal.segments.filter(row => row.state === 'complete').length, 2);
    assert.equal(journal.segments.filter(row => row.state === 'retry').length, 1);
    assert.equal(first.commits.length, 0);
    assert.ok(first.partials.some(row => row.entries?.filter(item => item.comments?.length === 6).length === 3), 'paid dialogue can be read from partial result');
    const next = await setup({ existing: journal });
    const result = await next.run();
    assert.ok(result, 'saved second-step resumes');
    assert.deepEqual(next.calls.map(row => row.kind), ['comments']);
    assert.deepEqual(next.calls[0].ids, ['CG4', 'CG5', 'CG6']);
    assert.equal(result.entries.filter(row => row.comments.length === 6).length, 6);
    assert.equal(next.get('core/state').state.activeGenerationTasks.size, 0);
    assert.equal(next.get('core/state').state.activeProviderRequestCount, 0);
});

test('legacy second-step journal without intent flag resumes from its original relation/comment slots', async () => {
    const first = await setup({ failComment: 1 }); await first.run({ secondStep: true });
    const journal = first.journals.at(-1); delete journal.operation.secondStep;
    const next = await setup({ existing: journal });
    assert.ok(await next.run());
    assert.deepEqual(next.calls.map(row => row.kind), ['comments']);
    assert.deepEqual(next.calls[0].ids, ['CG4', 'CG5', 'CG6']);
});

test('filling a new photograph retains already complete legacy four-line dialogue and its relationship basis', async () => {
    const previous = previousAlbum();
    previous.entries[0].comments = ['历史对白一', '历史对白二', '历史对白三', '历史对白四'];
    previous.entries = previous.entries.slice(0, 2);
    const f = await setup({ previous }), before = plain(previous.entries[0]);
    const result = await f.run({ secondStep: true });
    assert.ok(result); assert.deepEqual(plain(result.entries[0]), before);
    assert.deepEqual(f.calls.filter(row => row.kind === 'comments').flatMap(row => row.ids), ['CG2']);
    assert.equal(result.entries[1].comments.length, 6);
});

test('an incomplete six-line-contract entry is completed, and a four-line new reply still fails validation', async () => {
    const previous = previousAlbum(); previous.entries = previous.entries.slice(0, 1);
    previous.entries[0].comments = comments('old').slice(0, 5);
    previous.entries[0].relationshipSnapshot = relationship;
    const f = await setup({ previous });
    const result = await f.run({ secondStep: true });
    assert.ok(result); assert.equal(result.entries[0].comments.length, 6);
    assert.deepEqual(f.calls.filter(row => row.kind === 'comments').flatMap(row => row.ids), ['CG1']);
    assert.throws(() => f.get('modes/album').normalizeAlbumCommentsBatch({ items: [{ id: 'CG1', comments: comments('new').slice(0, 4) }] }, previous.entries), /不足 6/);
});

test('concurrent error waits for in-flight successful dialogue and does not dispatch later batches', async () => {
    let release, notify;
    const released = new Promise(resolve => { release = resolve; });
    const inFlight = new Promise(resolve => { notify = resolve; });
    const previous = previousAlbum(); previous.entries.push(...[7, 8, 9].map(entry));
    const f = await setup({ previous, failComment: 0, gate: async index => { if (index === 1) { notify(); await released; } } });
    let settled = false;
    const pending = f.run({ secondStep: true }).then(result => { settled = true; return result; });
    await inFlight;
    await new Promise(resolve => setTimeout(resolve, 0));
    assert.equal(settled, false, 'do not detach while another paid result is pending');
    release(); assert.equal(await pending, null);
    assert.equal(f.calls.filter(row => row.kind === 'comments').length, 2);
    assert.ok(f.journals.at(-1).segments.some(row => /:comments:1$/.test(row.slot) && row.state === 'complete'));
    assert.equal(f.get('core/state').state.activeGenerationTasks.size, 0);
    assert.equal(f.get('core/state').state.activeProviderRequestCount, 0);
});

test('cancelling the two in-flight dialogue requests releases task state and preserves the old album', async () => {
    let release, notify, started = 0;
    const released = new Promise(resolve => { release = resolve; });
    const inFlight = new Promise(resolve => { notify = resolve; });
    const f = await setup({ gate: async () => { if (++started === 2) notify(); await released; } });
    const before = plain(f.previous), pending = f.run({ secondStep: true });
    await inFlight;
    assert.ok(f.get('core/requestCoordinator').cancelCurrentChatBlockingTasks(f.host).cancelled > 0);
    assert.equal(await pending, null);
    release();
    assert.equal(f.commits.length, 0); assert.deepEqual(plain(f.previous), before);
    assert.equal(f.get('core/state').state.activeGenerationTasks.size, 0);
    assert.equal(f.get('core/state').state.activeProviderRequestCount, 0);
    assert.equal(f.get('core/requestTasks').logicalGenerationTasks.size, 0);
});
