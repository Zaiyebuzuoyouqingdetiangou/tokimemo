from pathlib import Path
import zipfile,sys,json,hashlib,re
root=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.parent.mkdir(parents=True,exist_ok=True)
build_tools={'tools/verification/build.py','tools/verification/runtime-order.json','tools/verification/package.py'}
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(root.rglob('*')):
  if not p.is_file():continue
  relative=p.relative_to(root)
  # Keep all runtime/source files and the small reproducible build toolchain.
  # Local test evidence, prototypes and development fixtures are not installed.
  if relative.parts[0] in {'verification','preview','dev'}:continue
  if relative.parts[0]=='tools' and relative.as_posix() not in build_tools:continue
  if any(part in {'node_modules','__pycache__','.git','.github'} for part in p.relative_to(root).parts) or p.suffix=='.pyc':continue
  assert not p.is_symlink()
  assert not any(part in {'.git','.github'} for part in p.relative_to(root).parts)
  i=zipfile.ZipInfo('tokimemo-main/'+str(p.relative_to(root)),date_time=(2026,10,1,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,p.read_bytes())
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 assert all(n.startswith('tokimemo-main/') and '..' not in Path(n).parts for n in z.namelist())
 assert not any(Path(n).parts[1] in {'verification','preview','dev','.github','.git'} for n in z.namelist())
 assert all('tokimemo-main/'+p.relative_to(root).as_posix() in z.namelist() for p in (root/'src').rglob('*') if p.is_file())
 for name in z.namelist():assert z.read(name)==(root/Path(name).relative_to('tokimemo-main')).read_bytes()
 manifest=json.loads(z.read('tokimemo-main/manifest.json'));index=z.read('tokimemo-main/index.js').decode();build=re.search(r"^const BUILD = '([^']+)';$",index,re.M)[1];version=re.search(r"^const VERSION = '([^']+)';$",index,re.M)[1]
 assert manifest['js']=='index.js?heartbeat='+build+'&layout=8';assert manifest['version']==version;assert build==version
 assert './dist/heartbeatMemories.bundle.js?heartbeat=${BUILD}&layout=8' in index
 result={'files':len(z.namelist()),'root':'tokimemo-main/','crc':'pass','exact_source_bytes':True,'version':version,'build':build,'github_workflows':False,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'bytes':out.stat().st_size}
print(json.dumps(result))
