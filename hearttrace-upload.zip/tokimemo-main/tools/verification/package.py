from pathlib import Path
import zipfile,sys,json,hashlib
root=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(root.rglob('*')):
  if not p.is_file():continue
  assert not p.is_symlink()
  assert not any(part in {'.git','.github'} for part in p.relative_to(root).parts)
  i=zipfile.ZipInfo('tokimemo-main/'+str(p.relative_to(root)),date_time=(2026,9,29,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,p.read_bytes())
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 assert all(n.startswith('tokimemo-main/') and '..' not in Path(n).parts for n in z.namelist())
 for name in z.namelist():assert z.read(name)==(root/Path(name).relative_to('tokimemo-main')).read_bytes()
 manifest=json.loads(z.read('tokimemo-main/manifest.json'));index=z.read('tokimemo-main/index.js').decode();build='0.99.99-r84.187-mv-update-recovery';assert manifest['js']=='index.js?heartbeat='+build;assert "const BUILD = '"+build+"';" in index
 result={'files':len(z.namelist()),'root':'tokimemo-main/','crc':'pass','exact_source_bytes':True,'build':build,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'bytes':out.stat().st_size}
print(json.dumps(result))
