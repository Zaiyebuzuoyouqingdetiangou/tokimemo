import test from 'node:test';
import assert from 'node:assert/strict';
import { stageSetup, stageRaw, song } from './mv-stage-fixture.mjs';
import { ui } from './mv-ui-fixture.mjs';

function baibai(f) {
    const requests = [];
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS, imageGenerationProvider: 'baibai-image', imageGenerationFallback: false });
    f.sb.STBaiBaiImage = { apiVersion: 1, capabilities: { generate: true, saveToGallery: true },
        getBackendStatus: () => ({ configured: true, backend: 'nai', supportsCharacters: true }),
        generate: async request => { requests.push(request); return { path: `/user/images/ratio-${requests.length}.png` }; } };
    return requests;
}

function chatu8(f, mode = 'novelai', sizes = { novelai_width: 832, novelai_height: 1216 }) {
    const requests = [], listeners = new Map();
    f.host.extensionSettings['st-chatu8'] = { scriptEnabled: true, mode, ...sizes };
    f.host.eventSource = {
        on: (name, handler) => listeners.set(name, handler),
        removeListener: name => listeners.delete(name),
        emit(name, request) {
            if (name !== 'generate-image-request') return;
            requests.push(request);
            listeners.get('generate-image-response')({ id: request.id, success: true, imageData: `/user/images/chatu-${requests.length}.png` });
        },
    };
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS, imageGenerationProvider: 'chatu8-image', imageGenerationFallback: false });
    return requests;
}

for (const [ratio, expected] of [['16:9', 'landscape'], ['9:16', 'portrait']]) {
    test(`${ratio}: BaiBai receives the selected orientation for shared poses, scene assets and redraws`, async () => {
        const f = await stageSetup('image'); f.record.settings.ratio = ratio;
        const requests = baibai(f), beforeTiming = JSON.stringify(f.record.timing);
        await f.mv.drawAsset(song.id, 'G1:D1');
        await f.mv.drawFrame(song.id, f.record.shots[0].id);
        f.mv.writeMv(f.mv.mvScope(f.host), song.id, record => {
            record.shots[0].image = { url: '/user/images/imported.png' };
            record.groups[1].layer = 'full';
            return record;
        });
        await f.mv.drawFrame(song.id, f.record.shots[0].id);
        await f.mv.drawAsset(song.id, 'G2:D1');
        await f.mv.drawAsset(song.id, 'stage:S1');
        assert.equal(requests.length, 5);
        for (const request of requests) {
            assert.equal(request.size, expected);
            assert.match(request.prompt, ratio === '16:9' ? /horizontal 16:9/ : /vertical 9:16/);
            assert.doesNotMatch(request.prompt, ratio === '16:9' ? /portrait character illustration|vertical 9:16/ : /horizontal 16:9/);
        }
        assert.equal(JSON.stringify(f.mv.readMv(f.host, song.id).timing), beforeTiming);
    });

    test(`${ratio}: non-stage cutout assets and complete manual prompts retain the selected orientation`, async () => {
        const f = await stageSetup(), requests = baibai(f);
        f.record.settings.ratio = ratio; delete f.record.stage;
        for (const group of f.record.groups) delete group.stageBackground;
        f.record.assetPrompts = { 'G2:D1': 'my exact saved prompt' };
        await f.mv.drawAsset(song.id, 'G1:D1');
        await f.mv.drawAsset(song.id, 'G2:D1');
        assert.equal(requests.length, 2);
        assert.equal(requests[0].size, expected); assert.equal(requests[1].size, expected);
        assert.equal(requests[1].prompt, 'my exact saved prompt');
    });
}

for (const [mode, sizes] of [
    ['novelai', { novelai_width: 832, novelai_height: 1216 }],
    ['sd', { sd_cwidth: 512, sd_cheight: 768 }],
    ['comfyui', { comfyui_width: 768, comfyui_height: 1344 }],
]) test(`Chatu8 ${mode}: MV uses its exact ratio only for this request`, async () => {
    const f = await stageSetup(), requests = chatu8(f, mode, sizes);
    const before = JSON.stringify(f.host.extensionSettings['st-chatu8']);
    await f.mv.drawAsset(song.id, 'G1:D1');
    assert.equal(requests.length, 1);
    assert.equal(requests[0].width / requests[0].height, 16 / 9);
    assert.equal(requests[0].width % 64, 0); assert.equal(requests[0].height % 64, 0);
    assert.equal(JSON.stringify(f.host.extensionSettings['st-chatu8']), before);
    f.mv.writeMv(f.mv.mvScope(f.host), song.id, record => { record.settings.ratio = '9:16'; return record; });
    await f.mv.drawFrame(song.id, f.record.shots[0].id);
    assert.equal(requests[1].width / requests[1].height, 9 / 16);
});

test('ordinary Chatu8 CG requests retain provider sizes and MV square settings get an oriented request', async () => {
    const f = await stageSetup(), requests = chatu8(f, 'novelai', { novelai_width: 1024, novelai_height: 1024 });
    await f.get('generation/cgImageCore').invokeImageGeneration('an ordinary CG', f.host);
    assert.equal(requests[0].width, undefined); assert.equal(requests[0].height, undefined);
    await f.mv.drawAsset(song.id, 'G1:D1');
    assert.ok(requests[1].width > requests[1].height);
    assert.equal(requests[1].width % 64, 0); assert.equal(requests[1].height % 64, 0);
    assert.ok(requests[1].width * requests[1].height <= 1024 * 1024);
    assert.equal(f.host.extensionSettings['st-chatu8'].novelai_width, 1024);
});

test('automatic provider fallback carries the MV orientation to Chatu8', async () => {
    const f = await stageSetup(); baibai(f); const requests = chatu8(f);
    f.sb.STBaiBaiImage.generate = async () => { throw { code: 'backend_error' }; };
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS, imageGenerationProvider: 'baibai-image', imageGenerationFallback: true });
    assert.equal((await f.mv.drawAsset(song.id, 'G1:D1')).pending, false);
    assert.equal(requests.length, 1); assert.equal(requests[0].width / requests[0].height, 16 / 9);
});

test('Chatu8 missing size fields still permit MV generation without changing settings', async () => {
    for (const mode of ['novelai', 'sd', 'comfyui', 'banana', 'runninghub']) {
        const f = await stageSetup(), requests = chatu8(f, mode, {});
        const before = JSON.stringify(f.host.extensionSettings['st-chatu8']);
        assert.equal((await f.mv.drawAsset(song.id, 'G1:D1')).pending, false);
        assert.equal(requests.length, 1);
        assert.ok(Number.isSafeInteger(requests[0].width) && requests[0].width > requests[0].height);
        assert.equal(JSON.stringify(f.host.extensionSettings['st-chatu8']), before);
    }
});

test('legacy standalone frames honor the orientation and motif generation keeps its existing contract', async () => {
    const f = await stageSetup(), requests = baibai(f);
    f.record.version = 1; delete f.record.stage; delete f.record.groups;
    f.record.shots = [{ id: 'S1', sectionIndex: 0, who: 'char', imagePrompt: 'one boy, steady gaze', image: null }];
    await f.mv.drawFrame(song.id, 'S1');
    assert.equal(requests[0].size, 'landscape'); assert.match(requests[0].prompt, /horizontal 16:9/);
    const other = await stageSetup(), motifRequests = chatu8(other);
    other.record.motif = { name: 'leaf', prompt: 'one leaf', image: null };
    await other.mv.drawAsset(song.id, 'motif');
    assert.equal(motifRequests.length, 1); assert.equal(motifRequests[0].width, undefined);
});

test('horizontal board thumbnails include a wide shape while vertical boards keep portrait tiles', async () => {
    const f = await ui(stageSetup);
    try {
        f.mvui.openMv({ songId: song.id, page: 'board' }); f.click('group-open', 'G1');
        assert.match(f.body.innerHTML, /class="rmt-mv-asset wide[^\"]*"[^>]*data-rmt-mv-id="G1:D1"/);
        f.mv.writeMv(f.mv.mvScope(f.host), song.id, record => { record.settings.ratio = '9:16'; return record; });
        f.mvui.openMv({ songId: song.id, page: 'board' }); f.click('group-open', 'G1');
        assert.doesNotMatch(f.body.innerHTML, /class="rmt-mv-asset wide/);
    } finally { f.mvui.disposeMv(); }
});

test('choosing horizontal in setup persists through storyboard generation and drawing the remaining images', async () => {
    const f = await ui(stageSetup), requests = baibai(f), flush = () => new Promise(resolve => setImmediate(resolve));
    f.record.settings.ratio = '9:16';
    f.get('generation/client').requestJson = async prompt => { assert.match(prompt, /横屏 16:9/); return f.json(stageRaw()); };
    try {
        f.mvui.openMv({ songId: song.id }); f.click('rewrite-board'); f.click('set-ratio', '16:9'); f.click('setup-generate');
        for (let i = 0; i < 12; i++) await flush();
        assert.equal(f.mv.readMv(f.host, song.id).settings.ratio, '16:9');
        f.click('draw-all'); for (let i = 0; i < 12; i++) await flush();
        assert.equal(requests.length, 3); assert.ok(requests.every(request => request.size === 'landscape')); // One shared backdrop and two poses.
    } finally { f.mvui.disposeMv(); }
});
