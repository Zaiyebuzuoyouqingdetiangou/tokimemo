import { runIf } from './optional.mjs';
// 缺少条件时明确跳过并说明原因；满足时加载同名 .impl.mjs 里的原测试。
await runIf([
    {
        "env": "CHATU8_SOURCE",
        "kind": "file",
        "why": "智绘姬上游源码 chatu8-current.js，用来运行真实的解析与请求拼装"
    }
],
    () => import('./chatu8-nai45-negatives-contract-regression.impl.mjs'));
