import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';

test('automatic appearance keeps explicit bangs, blindfold and hair silhouette in English tags', async () => {
    const f = await fixture(), looks = f.get('core/castLooks');
    const actual = looks.lookFromDescription('black hair, pink eyes, long hair, blunt bangs, white blindfold');
    for (const trait of ['black hair', 'pink eyes', 'long hair', 'blunt bangs', 'white blindfold']) assert.ok(actual.includes(trait), trait);
    for (const trait of ['side-swept bangs', 'hime cut', 'twin braids', 'double bun', 'hair ribbon', 'black eyepatch']) {
        assert.equal(looks.lookFromDescription(trait), trait);
    }
});

test('Chinese face framing and visible accessories survive the same automatic fallback', async () => {
    const f = await fixture(), looks = f.get('core/castLooks');
    const traits = ['黑色长发', '齐刘海', '中分', '侧分', '发髻', '白色眼罩', '红色发饰'];
    const actual = looks.lookFromDescription(traits.join('，'));
    for (const trait of traits) assert.ok(actual.includes(trait), trait);
});

test('fallback still excludes biography, transient emotions and inferred attributes', async () => {
    const f = await fixture(), looks = f.get('core/castLooks');
    const actual = looks.lookFromDescription('black hair, blunt bangs, white blindfold, likes long hair, personality: cold, often blushes, wears a blue shirt, 平时眼睛带着笑, 喜欢齐刘海, 关系复杂');
    assert.equal(actual, 'black hair，blunt bangs，white blindfold');
    assert.equal(looks.lookFromDescription('性格清冷，名字纪时卿，擅长舞剑'), '');
    assert.equal(looks.lookFromDescription('black hair, pink eyes'), 'black hair，pink eyes');
});

test('fresh own appearance reaches separate avatar actors without invented differences or card mutation', async () => {
    const f = await fixture(), looks = f.get('core/castLooks'), couple = f.get('extras/coupleAvatar');
    f.host.name2 = '方祁洛'; f.host.name1 = '纪时卿';
    const card = { description: 'black hair, high ponytail, messy hair', persona: 'black hair, pink eyes, long hair, blunt bangs, white blindfold' };
    f.host.getCharacterCardFields = () => card;
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS, imageGenerationProvider: 'baibai-image', cgPromptFormat: 'nai5-natural' });
    f.sb.STBaiBaiImage = { apiVersion: 1, capabilities: { characterLibrary: true }, getCharacters: () => ({ apiVersion: 1, characters: [] }) };
    const before = JSON.stringify(card), defaults = couple.defaultCoupleSettings(f.host);
    const parts = couple.couplePromptParts(defaults, f.host);
    assert.match(parts.nai.characters[0].tag, /high ponytail/);
    assert.doesNotMatch(parts.nai.characters[0].tag, /pink eyes|white blindfold/);
    assert.match(parts.nai.characters[1].tag, /blunt bangs/);
    assert.match(parts.nai.characters[1].tag, /white blindfold/);
    assert.doesNotMatch(parts.nai.characters[1].tag, /high ponytail|silver hair|blonde hair/);
    assert.equal(JSON.stringify(card), before);
    assert.equal(looks.readCastLooks(f.host), null);
});

test('automatic capture retains the new traits but never replaces confirmed manual looks', async () => {
    const f = await fixture(), looks = f.get('core/castLooks');
    f.host.getCharacterCardFields = () => ({ description: 'black hair, blunt bangs, white blindfold', persona: 'pink eyes, side-swept bangs' });
    const captured = looks.ensureCastLooks(f.host);
    assert.match(captured.char, /blunt bangs，white blindfold/);
    assert.match(captured.user, /side-swept bangs/);
    f.host.chatMetadata[looks.CAST_LOOKS_KEY] = { ...captured, char: 'MANUAL_LEFT', user: 'MANUAL_RIGHT', manual: true };
    const before = JSON.stringify(f.host.chatMetadata[looks.CAST_LOOKS_KEY]);
    looks.ensureCastLooks(f.host);
    assert.equal(JSON.stringify(f.host.chatMetadata[looks.CAST_LOOKS_KEY]), before);
});
