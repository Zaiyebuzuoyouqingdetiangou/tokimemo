import { modulePaths } from './optional.mjs';
// Event host reused unchanged from mv-editor-native-regression.mjs.
// Native Canvas/PNG pixels with a small event-host double; this is not a browser DOM test.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { fixture } from './fixture.mjs';
import { ui } from './mv-ui-fixture.mjs';
const require = createRequire(import.meta.url);
const native = require(require.resolve('@napi-rs/canvas', { paths: modulePaths() }));

class Element {
    constructor(tag, attributes = '') {
        this.tag = tag; this.listeners = {}; this.dataset = {}; this.style = {}; this.value = ''; this.checked = false; this.disabled = false;
        for (const [, name, value] of attributes.matchAll(/([\w-]+)(?:="([^"]*)")?/g)) {
            if (name.startsWith('data-')) this.dataset[name.slice(5).replace(/-([a-z])/g, (_, c) => c.toUpperCase())] = value || '';
            if (name === 'value') this.value = value;
            if (name === 'class') this.className = value;
        }
        if (tag === 'canvas') this.native = native.createCanvas(300, 150);
    }
    set innerHTML(value) { this.html = value; this.nodes = [...value.matchAll(/<([a-z]+)([^>]*)>/g)].map(([, tag, attrs]) => new Element(tag, attrs)); this.firstElementChild = this.nodes[0]; if (this.firstElementChild) this.firstElementChild.nodes = this.nodes.slice(1); }
    get innerHTML() { return this.html; }
    set textContent(value) { this.text = value; this.onText?.(value); }
    get textContent() { return this.text || ''; }
    matches(selector) {
        if (selector.startsWith('.')) return (this.className || '').split(' ').includes(selector.slice(1));
        const m = selector.match(/^\[data-([\w-]+)(?:="([^"]*)")?\]$/);
        if (m) { const k = m[1].replace(/-([a-z])/g, (_, c) => c.toUpperCase()); return k in this.dataset && (m[2] === undefined || this.dataset[k] === m[2]); }
        return selector === this.tag;
    }
    querySelectorAll(selector) { return (this.nodes || []).filter(el => selector.split(',').some(s => el.matches(s))); }
    querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
    closest(selector) { return this.matches(selector) ? this : null; }
    addEventListener(name, fn) { (this.listeners[name] ||= []).push(fn); }
    async fire(name, extra = {}) { for (const fn of this.listeners[name] || []) await fn({ target: this, preventDefault() {}, ...extra }); }
    setAttribute(name, value) { this[name] = value; }
    setPointerCapture() {}
    get width() { return this.native.width; } set width(v) { this.native.width = v; }
    get height() { return this.native.height; } set height(v) { this.native.height = v; }
    getContext() { return this.native.getContext('2d'); }
    getBoundingClientRect() { const width = (this.style.width || '').endsWith('px') ? parseFloat(this.style.width) : 360 * (parseFloat(this.style.width || '100') / 100); return { left: 0, top: 0, width, height: width * this.height / this.width }; }
    toBlob(fn) { fn(new Blob([this.native.toBuffer('image/png')], { type: 'image/png' })); }
    click() {}
}

async function editor(sourceUrl, image = null, extra = {}) {
    const f = await fixture(), blobs = new Map(); let serial = 0;
    f.sb.ImageData = native.ImageData;
    f.sb.innerHeight = 10000; // Geometry tests use a large viewport; the mobile fit test overrides it.
    f.sb.Image = class extends native.Image {
        set src(value) { if (blobs.has(value)) void blobs.get(value).arrayBuffer().then(b => { super.src = Buffer.from(b); }); else super.src = value; }
    };
    f.sb.URL = { createObjectURL(blob) { const url = `blob:test-${++serial}`; blobs.set(url, blob); return url; }, revokeObjectURL(url) { blobs.delete(url); } };
    f.sb.document = { createElement: tag => new Element(tag) };
    const host = new Element('div'), saves = [], state = { closed: 0 };
    const controller = f.get('ui/mvImageEditor').mountAssetEditor(host, { sourceUrl, imageUrl: sourceUrl, image, prompt: 'default', defaultPrompt: 'default', onSave: async draft => { saves.push(draft); return true; }, onClose: () => { state.closed++; }, ...extra });
    const root = host.firstElementChild, find = selector => root.querySelector(selector), click = action => root.fire('click', { target: find(`[data-edit="${action}"]`) });
    await controller.ready; return { f, root, controller, saves, state, find, click };
}

async function decode(blob) { const img = new native.Image(); img.src = Buffer.from(await blob.arrayBuffer()); await img.decode(); const c = native.createCanvas(img.width, img.height); c.getContext('2d').drawImage(img, 0, 0); return c; }
export { editor, decode };
