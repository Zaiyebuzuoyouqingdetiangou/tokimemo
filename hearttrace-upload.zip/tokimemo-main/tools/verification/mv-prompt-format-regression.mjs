import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { fixture } from './fixture.mjs';
import { ui } from './mv-ui-fixture.mjs';

const song = { id: 'SONG_format', title: '雪光', lyrics: '[Verse 1]\n看向你\n[Chorus]\n等雪落下\n[End]' };
const plain = value => JSON.parse(JSON.stringify(value));
const cast = { version: 1, cardType: 'multi', selectedIds: ['a', 'b'], people: [
    { id: 'a', name: '方祁洛', sourceRefs: [] }, { id: 'b', name: '纪时卿', sourceRefs: [] },
], appearances: [{ participantId: 'a', tag: 'brown hair, blue eyes', manual: true }, { participantId: 'b', tag: 'silver hair, green eyes', manual: true }] };
const raw = (sectionIndex = 0) => ({
    wardrobe: { era: 'snowy courtyard', characters: [{ participantId: 'a', clothing: 'red cloak' }, { participantId: 'b', clothing: 'black robe' }] },
    motif: { name: 'snowflake', prompt: 'single snowflake, white crystal' },
    stage: { backgrounds: [{ id: 'stage', label: 'main', kind: 'image', prompt: 'empty courtyard, soft light' }] },
    groups: [{ id: 'A', who: 'both', layer: 'full', composition: '两人望雪', scale: 'medium',
        cast: [{ participantId: 'a', visible: 'full', position: 'right', action: 'open palm' }, { participantId: 'b', visible: 'full', position: 'left', action: 'looking at open palm' }],
        characterPrompt: 'two people, subject on the right, open palm, subject on the left, watching',
        diffs: [{ id: 'open', imagePrompt: 'two people, subject on the right, open palm, subject on the left, watching, soft snowfall' }],
        bgs: [{ id: 'street', prompt: 'empty snowy street, soft light' }] }],
    frames: [{ sectionIndex, lyric: sectionIndex ? '等雪落下' : '看向你', group: 'A', diff: 'open', hold: 2 }],
});

async function setup({ provider = 'baibai-image', supportsCharacters = true } = {}) {
    const f = await fixture(), mv = f.get('extras/mv');
    f.host.name2 = '方祁洛'; f.host.name1 = '纪时卿';
    f.get('core/cache').loadSession = () => ({ songs: [song] });
    let currentFormat = 'nai45-tags';
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS, imageGenerationProvider: provider, imageGenerationFallback: false, cgPromptFormat: currentFormat });
    f.get('core/castLooks').readCastLooks = () => ({ manual: true, char: 'brown hair, blue eyes', user: 'silver hair, green eyes' });
    const requests = [], bus = new EventEmitter(); f.host.eventSource = bus;
    f.host.extensionSettings['st-chatu8'] = { scriptEnabled: true, mode: 'novelai', novelaimode: 'nai-diffusion-4-full', AI_use_coords: supportsCharacters };
    bus.on('generate-image-request', request => { requests.push(request); bus.emit('generate-image-response', { id: request.id, success: true, imageData: `/user/images/format-${requests.length}.png` }); });
    f.sb.STBaiBaiImage = { apiVersion: 1, capabilities: { generate: true, saveToGallery: true },
        getBackendStatus: () => ({ configured: true, backend: supportsCharacters ? 'nai' : 'comfyui', supportsCharacters }),
        generate: async request => { requests.push(request); return { path: `/user/images/format-${requests.length}.png` }; } };
    return { ...f, mv, requests, setFormat: value => { currentFormat = value; } };
}

function seed(f, { format = 'nai45-tags', legacy = false, video = false } = {}) {
    const settings = f.mv.normalizeSettings({ output: video ? 'video' : 'tegaki', range: 'full', promptFormat: format, storyType: 'illustration' });
    const input = raw();
    if (legacy) delete input.groups[0].cast;
    const built = video ? { shots: [{ id: 'S1', who: 'user', sectionIndex: 0, imagePrompt: 'open palm, falling snow', ...(legacy ? {} : { cast: input.groups[0].cast }) }] }
        : f.mv.buildShots(f.json(input), f.bank, 2, settings, legacy ? null : f.json(cast));
    const record = { ...built, id: song.id, settings, createdAt: 1, wardrobe: { ...input.wardrobe, char: 'red cloak', user: 'black robe' },
        ...(legacy ? {} : { cast: f.json(cast) }) };
    f.host.chatMetadata[f.mv.MV_KEY] = { songs: { [song.id]: record } };
    return record;
}

test('new storyboard snapshots the selected format once and directs every image field without a second text call', async () => {
    for (const format of ['nai45-tags', 'nai5-natural']) {
        const f = await setup(); let calls = 0, prompt = '';
        f.setFormat(format);
        f.get('generation/client').requestJson = async value => { calls++; prompt = value; f.setFormat(format === 'nai45-tags' ? 'nai5-natural' : 'nai45-tags'); return f.json(raw()); };
        assert.equal((await f.mv.generateStoryboard(song.id, { range: 'full', storyType: 'illustration' }, f.json(cast))).pending, false);
        const record = f.mv.readMv(f.host, song.id);
        assert.equal(record.settings.promptFormat, format); assert.equal(calls, 1);
        for (const field of ['diff.imagePrompt', 'group.characterPrompt', 'stage.backgrounds[].prompt', 'motif.prompt', 'cast[].action', 'wardrobe.era']) assert.ok(prompt.includes(field), field);
        assert.match(prompt, format === 'nai45-tags' ? /NAI 4\.5 · 英文 Tag/ : /NAI 5 · 自然语言/);
        const example = JSON.parse(prompt.split('\n').at(-1));
        assert.equal(example.frames[0].diff, example.frames[1].diff);
        assert.deepEqual(plain(example.frames[0].illustration), plain(example.frames[1].illustration));
    }
});

test('explicit new draft format wins; continue and rewrite retain its snapshot after global changes', async () => {
    const f = await setup(); f.setFormat('nai45-tags'); const prompts = [];
    f.get('generation/client').requestJson = async value => { prompts.push(value); return f.json(prompts.length === 1 ? raw(0) : prompts.length === 2 ? raw(1) : { imagePrompt: 'A quiet person holds one palm open beneath falling snow.' }); };
    await f.mv.generateStoryboard(song.id, { range: 'full', promptFormat: 'nai5-natural' }, f.json(cast));
    f.setFormat('nai45-tags'); await f.mv.continueStoryboard(song.id);
    const record = f.mv.readMv(f.host, song.id); await f.mv.rewriteShot(song.id, record.shots[0].id, 'calm');
    assert.equal(prompts.length, 3);
    for (const prompt of prompts) assert.match(prompt, /NAI 5 · 自然语言/);
    assert.equal(f.mv.readMv(f.host, song.id).settings.promptFormat, 'nai5-natural');
});

test('formatless saved records retain their text and continuation behavior after global format changes', async () => {
    const f = await setup(), record = seed(f, { format: '' });
    assert.equal(Object.hasOwn(f.mv.normalizeSettings(null), 'promptFormat'), false);
    const before = f.mv.assetPrompt(record, 'G1:D1', f.host), saved = plain(record);
    f.setFormat('nai5-natural'); assert.equal(f.mv.assetPrompt(record, 'G1:D1', f.host), before);
    f.setFormat('nai45-tags'); assert.equal(f.mv.assetPrompt(record, 'G1:D1', f.host), before);
    assert.deepEqual(plain(record), saved);
    let prompt = ''; f.get('generation/client').requestJson = async p => { prompt = p; return f.json(raw(1)); };
    await f.mv.continueStoryboard(song.id);
    assert.doesNotMatch(prompt, /本次图像提示格式/);
    assert.equal(Object.hasOwn(f.mv.readMv(f.host, song.id).settings, 'promptFormat'), false);
});

for (const provider of ['chatu8-image', 'baibai-image']) for (const supportsCharacters of [true, false]) test(`tag MV sends one request through ${provider}/${supportsCharacters ? 'native' : 'flat'} with bound positions and no automatic Chinese names`, async () => {
    const f = await setup({ provider, supportsCharacters }), record = seed(f);
    const before = plain(record), preview = f.mv.assetPrompt(record, 'G1:D1', f.host);
    assert.doesNotMatch(preview, /方祁洛|纪时卿/); assert.match(preview, /right,.*red cloak/); assert.match(preview, /left,.*black robe/);
    await f.mv.drawAsset(song.id, 'G1:D1'); assert.equal(f.requests.length, 1);
    const request = f.requests[0]; assert.match(request.prompt, /open palm/); assert.match(request.prompt, /subject on the right/);
    assert.doesNotMatch(request.prompt, /方祁洛|纪时卿|角色外貌|人物外貌/);
    assert.match(JSON.stringify(request), /brown hair/); assert.match(JSON.stringify(request), /silver hair/);
    const saved = f.mv.readMv(f.host, song.id); assert.deepEqual(plain(saved.cast), before.cast); assert.deepEqual(plain(saved.settings), before.settings);
});

test('natural MV keeps sentence descriptions and format transport for modern assets and legacy first frames', async () => {
    for (const legacy of [false, true]) {
        const f = await setup(), record = seed(f, { format: 'nai5-natural', legacy, video: legacy });
        const description = 'Snow drifts past the open palm while soft light falls across the quiet courtyard.';
        if (legacy) record.shots[0].imagePrompt = description; else record.groups[0].diffs[0].imagePrompt = description;
        let options; const send = f.get('generation/cgImageCore').invokeImageGeneration;
        f.get('generation/cgImageCore').invokeImageGeneration = (prompt, context, value) => { options = value; return send(prompt, context, value); };
        if (legacy) await f.mv.drawFrame(song.id, 'S1'); else await f.mv.drawAsset(song.id, 'G1:D1');
        assert.equal(f.requests.length, 1); assert.equal(options.promptMetadata.promptFormat, 'nai5-natural');
        assert.ok(JSON.stringify(f.requests[0]).includes(description));
        if (legacy) { assert.match(JSON.stringify(f.requests[0]), /silver hair/); assert.doesNotMatch(JSON.stringify(f.requests[0]), /brown hair/); }
    }
});

for (const provider of ['chatu8-image', 'baibai-image']) test(`tag MV flat ${provider} binds reversed cast anchors to real preset identities and explicit positions`, async () => {
    const f = await setup({ provider, supportsCharacters: false }), record = seed(f);
    f.host.extensionSettings['st-chatu8'].characterPresets = {
        a: { nameCN: '方祁洛', nameEN: 'Fang', characterTraits: 'black hair, amber eyes' },
        b: { nameCN: '纪时卿', nameEN: 'Ji', characterTraits: 'white hair, violet eyes' },
    };
    f.sb.STBaiBaiImage.capabilities.characterLibrary = true;
    f.sb.STBaiBaiImage.getCharacters = () => ({ apiVersion: 1, characters: [
        { name: '方祁洛', tag: 'black hair, amber eyes' }, { name: '纪时卿', tag: 'white hair, violet eyes' },
    ] });
    record.groups[0].cast = [
        { participantId: 'b', position: 'right', action: 'holding black umbrella', visible: 'full' },
        { participantId: 'a', position: 'left', action: 'offering red ribbon', visible: 'full' },
    ];
    record.groups[0].characterPrompt = 'two people, snowy courtyard';
    record.groups[0].diffs[0].imagePrompt = ''; record.groups[0].diffs[0].change = '';
    const before = plain(record.cast), castApi = f.get('extras/mvCast');
    const names = value => plain(castApi.castMetadata(value, record.groups[0], f.host).castSnapshot.people.map(person => ({ id: person.id, name: person.name })));
    assert.deepEqual(names(record), [{ id: 'b', name: 'person 1' }, { id: 'a', name: 'person 2' }]);
    for (const format of ['', 'nai5-natural']) assert.deepEqual(names({ ...record, settings: { ...record.settings, promptFormat: format } }), [
        { id: 'b', name: '纪时卿' }, { id: 'a', name: '方祁洛' },
    ]);
    await f.mv.drawAsset(song.id, 'G1:D1'); assert.equal(f.requests.length, 1);
    const prompt = f.requests[0].prompt;
    assert.match(prompt, /person 1, right, holding black umbrella, wearing black robe/);
    assert.match(prompt, /person 2, left, offering red ribbon, wearing red cloak/);
    assert.match(prompt, /person 1: white hair, violet eyes/);
    assert.match(prompt, /person 2: black hair, amber eyes/);
    assert.doesNotMatch(prompt, /person 1: black hair|person 2: white hair|brown hair|silver hair/);
    assert.deepEqual(plain(f.mv.readMv(f.host, song.id).cast), before);
});

test('background, stage and motif sends carry the record format and never add actor appearance', async () => {
    const f = await setup(), record = seed(f); const formats = [];
    const send = f.get('generation/cgImageCore').invokeImageGeneration;
    f.get('generation/cgImageCore').invokeImageGeneration = (prompt, context, options) => { formats.push(plain(options.promptMetadata)); return send(prompt, context, options); };
    for (const key of ['G1:B1', 'stage:S1', 'motif']) await f.mv.drawAsset(song.id, key);
    assert.equal(f.requests.length, 3); assert.equal(formats.length, 3);
    for (const metadata of formats) { assert.equal(metadata.promptFormat, 'nai45-tags'); assert.deepEqual(metadata.selectedRoles, []); }
    for (const request of f.requests) assert.doesNotMatch(JSON.stringify(request), /brown hair|silver hair|red cloak|black robe/);
    assert.equal(record.settings.promptFormat, 'nai45-tags');
});

test('complete manual asset prompts bypass format assembly for both draw entry points', async () => {
    for (const format of ['nai45-tags', 'nai5-natural']) {
        const f = await setup(), record = seed(f, { format });
        const literal = '手写构图，保留完整句子。 one still, quiet light'; record.assetPrompts = { 'G1:D1': literal };
        const calls = [];
        f.get('generation/cgImageCore').invokeImageGeneration = async (prompt, context, options) => { calls.push({ prompt, options }); return { url: '/user/images/manual.png' }; };
        assert.equal(f.mv.assetPrompt(record, 'G1:D1', f.host), literal);
        await f.mv.drawAsset(song.id, 'G1:D1'); await f.mv.drawFrame(song.id, record.shots[0].id);
        assert.equal(calls.length, 2);
        for (const call of calls) { assert.equal(call.prompt, literal); assert.equal(call.options.promptMetadata, undefined); }
    }
});

test('tag wrappers keep literal edited actions and wardrobe, and do not invent a position', async () => {
    const f = await setup(), record = seed(f);
    record.groups[0].cast = [{ participantId: 'a', visible: 'full', position: '', action: '抬手触雪' }];
    record.groups[0].diffs[0].imagePrompt = ''; record.groups[0].diffs[0].change = '';
    record.groups[0].characterPrompt = 'one person, open courtyard'; record.groups[0].position = 'center';
    record.wardrobe.characters[0].clothing = '绣着银线的红袍';
    const preview = f.mv.assetPrompt(record, 'G1:D1', f.host);
    assert.match(preview, /抬手触雪/); assert.match(preview, /绣着银线的红袍/); assert.doesNotMatch(preview, /方祁洛|left|right/);
});

test('format directives never block a paid mixed-language result or trigger repair requests', async () => {
    const f = await setup(); let calls = 0;
    f.get('generation/client').requestJson = async () => { calls++; const value = raw(); value.groups[0].diffs[0].imagePrompt = '微微抬手，snowy courtyard'; return f.json(value); };
    assert.equal((await f.mv.generateStoryboard(song.id, { promptFormat: 'nai45-tags' }, f.json(cast))).pending, false);
    await f.mv.drawAsset(song.id, 'G1:D1'); assert.equal(calls, 1); assert.equal(f.requests.length, 1);
    assert.match(f.requests[0].prompt, /微微抬手/);
});

test('MV setup format selection edits only the draft until an explicit storyboard request', async () => {
    const f = await ui(setup); let calls = 0;
    f.get('generation/client').requestJson = async () => { calls++; return f.json(raw()); };
    const generate = f.mv.generateStoryboard; let generation;
    f.mv.generateStoryboard = (...args) => { generation = generate(...args); return generation; };
    f.mvui.openMv({ songId: song.id, page: 'board' });
    assert.match(f.body.innerHTML, /data-rmt-mv-prompt-format/);
    assert.equal(await f.mvui.handleMvChange({ target: { matches: selector => selector === '[data-rmt-mv-prompt-format]', value: 'nai5-natural' } }), true);
    assert.equal(calls, 0); assert.equal(f.mv.readMv(f.host, song.id), null);
    assert.match(f.body.innerHTML, /value="nai5-natural" selected/);
    f.click('setup-generate'); assert.ok(generation); assert.equal((await generation).pending, false);
    assert.equal(calls, 1); assert.equal(f.mv.readMv(f.host, song.id).settings.promptFormat, 'nai5-natural');
});
