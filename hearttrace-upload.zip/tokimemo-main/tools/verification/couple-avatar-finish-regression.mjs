import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';

test('pixel portraits request readable large subjects, not low-resolution sprites', async () => {
    const f = await fixture(), core = f.get('extras/coupleAvatar');
    for (const styleId of ['graphic-8bit', 'graphic-pixel']) {
        const parts = core.couplePromptParts({ styleId });
        const sent = parts.nai.prompt + '\n' + parts.nai.nl;
        assert.doesNotMatch(sent, /very low resolution|sprite portraits|very coarse/i);
        assert.match(sent, /head-and-shoulder|upper-body/i);
        assert.match(sent, /fills? most of/i);
        assert.match(sent, /pixel/);
        assert.match(sent, /connected naturally to the body/i);
    }
});

test('texture stays intentional instead of requiring unfinished faces or uniformly rough marks', async () => {
    const f = await fixture(), styles = f.get('extras/coupleAvatarStyles');
    const traits = { 'art-charcoal': /charcoal/i, 'chibi-crayon': /crayon|wax/i,
        'anime-retro90': /analog|cel/i, 'art-watercolor': /wash|pigment/i,
        'art-risograph': /spot.color|registration/i, 'fantasy-fresco': /mineral|plaster/i };
    for (const [id, trait] of Object.entries(traits)) {
        const style = styles.COUPLE_STYLES.find(s => s.id === id);
        const brief = style.prompt + ' ' + styles.coupleStyleConstruction(style);
        assert.match(brief, trait);
        assert.doesNotMatch(brief, /rough rather than polished|incomplete fills|film softness|lost edges across the face/i);
    }
});

test('all built-in styles receive a shared finish brief without replacing their medium or full-figure proportions', async () => {
    const f = await fixture(), styles = f.get('extras/coupleAvatarStyles'), core = f.get('extras/coupleAvatar');
    for (const style of styles.COUPLE_STYLES) {
        const parts = core.couplePromptParts({ styleId: style.id, direction: '保留我的配色和构图' });
        for (const brief of [parts.prompt, parts.nai.nl]) {
            assert.match(brief, /Finished artwork in the selected medium/);
            assert.match(brief, /background detail quieter/);
            assert.match(brief, /Preserve deliberate simplicity/);
            assert.ok(brief.includes('保留我的配色和构图'));
            assert.doesNotMatch(brief, /fully painted environment|continuous painted background/i);
        }
        if (style.group === 'animal' || (style.group === 'chibi' && style.id !== 'chibi-headshot')) {
            assert.match(parts.nai.nl, /complete stylized figure fills most/);
            assert.doesNotMatch(parts.nai.nl, /Close head-and-shoulder/);
        }
        assert.ok(parts.nai.prompt.includes(style.prompt));
    }
});

test('BaiBai receives the finish brief exactly once without extra calls or overriding provider dimensions/settings', async () => {
    const f = await fixture(), requests = [], core = f.get('extras/coupleAvatar');
    f.host.chatMetadata = {};
    f.sb.STBaiBaiImage = { apiVersion: 1, capabilities: { generate: true, saveToGallery: true },
        getBackendStatus: () => ({ configured: true, backend: 'nai', supportsCharacters: true }),
        generate: async request => { requests.push(request); return { path: '/user/images/finish.png' }; } };
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS, imageGenerationProvider: 'baibai-image', imageGenerationFallback: false });
    f.get('generation/client').requestJson = () => { throw Error('Unexpected text request'); };
    const people = [{ name: 'Left', appearance: '1boy, black hair, high ponytail' }, { name: 'Right', appearance: '1girl, silver hair, red eyes' }];
    for (const styleId of ['graphic-8bit', 'art-watercolor', 'craft-plush', 'animal-cat']) {
        const input = { styleId, people, background: 'USER_BACKGROUND', direction: 'USER_DIRECTION' }, before = JSON.stringify(input);
        await core.generateCouple(input, { context: f.host });
        const sent = requests.at(-1);
        assert.equal((JSON.stringify(sent).match(/Finished artwork/g) || []).length, 1);
        assert.equal(sent.characters.length, 2);
        assert.match(sent.nl, /USER_BACKGROUND/); assert.match(sent.nl, /USER_DIRECTION/);
        assert.equal(sent.size, 'landscape');
        for (const key of ['width', 'height', 'steps', 'quality', 'qualityTags', 'sampler', 'scale']) assert.equal(sent[key], undefined);
        assert.equal(JSON.stringify(input), before);
    }
    assert.equal(requests.length, 4);
});

test('custom styles keep the user brief and are not forced into built-in finishing or framing', async () => {
    const f = await fixture(), core = f.get('extras/coupleAvatar');
    const parts = core.couplePromptParts({ styleId: 'custom', customStyle: 'unfinished rough abstract color study',
        direction: 'wide full-body composition', people: [{ name: '', appearance: '' }, { name: '', appearance: '' }] });
    assert.ok(parts.nai.prompt.includes('unfinished rough abstract color study'));
    assert.ok(parts.nai.nl.includes('wide full-body composition'));
    assert.doesNotMatch(parts.nai.nl, /Finished artwork|fills most|Close head-and-shoulder/);
});
