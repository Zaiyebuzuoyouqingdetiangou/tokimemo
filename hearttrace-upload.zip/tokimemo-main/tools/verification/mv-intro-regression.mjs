// Public MV UI actions with native Canvas pixels; host/storage/recorder are doubles.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { fixture } from './fixture.mjs';
import { ui } from './mv-ui-fixture.mjs';
const require = createRequire(import.meta.url);
const native = require(require.resolve('@napi-rs/canvas', { paths: [process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES || process.cwd()] }));

async function scene(patch = {}, lyrics = '[Intro]\n[Verse 1]\nline\n[End]') {
    const f = await ui(fixture), mv = f.get('extras/mv');
    const song = { id: 'SONG_intro', title: 'TITLE_PROBE', lyrics };
    const art = native.createCanvas(100, 100); art.getContext('2d').fillStyle = '#ff0000'; art.getContext('2d').fillRect(0, 0, 100, 100);
    const url = art.toDataURL(), decodes = [], canvases = [], titles = [];
    f.sb.Image = class extends native.Image { set src(value) { super.src = value; decodes.push(this.decode()); } };
    const canvas = () => {
        const c = native.createCanvas(540, 960), g = c.getContext('2d'), fillText = g.fillText.bind(g);
        g.fillText = (text, ...args) => { if (text === song.title) titles.push(g.globalAlpha); fillText(text, ...args); };
        const track = { canvas: c, stop() {} };
        c.style = {}; c.remove = () => {}; c.captureStream = () => ({ getTracks: () => [track], getVideoTracks: () => [track] }); canvases.push(c); return c;
    };
    const preview = canvas(); f.canvas.getContext = () => preview.getContext('2d');
    const create = f.sb.document.createElement; f.sb.document.createElement = tag => tag === 'canvas' ? canvas() : create(tag);
    let providerCalls = 0;
    f.get('generation/cgImageCore').invokeImageGeneration = async () => { providerCalls++; throw Error('unexpected image generation'); };
    f.get('generation/client').generate = async () => { providerCalls++; throw Error('unexpected generation'); };
    f.get('core/cache').loadSession = () => ({ songs: [song] });
    f.host.chatMetadata[mv.MV_KEY] = { songs: { [song.id]: { id: song.id, version: 2, duration: 100,
        settings: { output: 'tegaki', range: 'full', ratio: '9:16' }, tegaki: { range: 'full', lyric: 'none' },
        groups: [{ id: 'G1', layer: 'full', scale: 'wide', motion: 'still', diffs: [{ id: 'D1', image: { url, split: 'none' } }] }],
        shots: [{ id: 'S1', group: 'G1', diff: 'D1', sectionIndex: 0, lyric: '', motion: 'still', cut: 'cut' }, { id: 'S2', group: 'G1', diff: 'D1', sectionIndex: 1, lyric: 'line', motion: 'still', cut: 'cut' }],
        timing: { taps: { 0: 0, 1: 30 } }, ...patch } } };
    const record = () => mv.readMv(f.host, song.id);
    const open = () => { f.mvui.openMv({ songId: song.id }); f.click('go-tegaki'); };
    open(); await Promise.all(decodes); f.mvui.renderMv();
    const seek = t => {
        titles.length = 0;
        const el = { dataset: { rmtMv: 'seek' }, getBoundingClientRect: () => ({ left: 0, width: mv.shotTimeline(record(), song).total }) };
        f.mvui.handleMvClick({ target: { closest: () => el }, clientX: t, preventDefault() {} });
        return [...titles];
    };
    const setIntro = value => f.mvui.handleMvChange({ target: { value: String(value), matches: s => s === '[data-rmt-mv-intro-seconds]' } });
    const red = c => { const rgb = [...c.getContext('2d').getImageData(5, 5, 1, 1).data]; assert.ok(rgb[0] > rgb[1] + 120 && rgb[0] > rgb[2] + 120, 'the first drawing should be visible: ' + rgb); };
    return { ...f, mv, song, record, open, preview, canvases, titles, seek, setIntro, red, providerCalls: () => providerCalls };
}

test('a thirty-second prelude shows the first drawing after the two-second title', async () => {
    const f = await scene(); try {
        assert.ok(f.seek(.2).length, 'keep the opening cover');
        assert.equal(f.seek(2).length, 0); f.red(f.preview);
        assert.equal(f.seek(28).length, 0); f.red(f.preview);
    } finally { f.mvui.disposeMv(); }
});

test('intro duration is editable, zero disables it, and reopening preserves song, timing and drawings', async () => {
    const f = await scene(); try {
        const before = JSON.stringify({ shots: f.record().shots, groups: f.record().groups, timing: f.record().timing, song: f.song });
        assert.match(f.body.innerHTML, /data-rmt-mv-intro-seconds/);
        assert.equal(f.setIntro(0), true); assert.equal(f.record().tegaki.introSeconds, 0);
        assert.equal(f.seek(0).length, 0); f.red(f.preview);
        f.mvui.disposeMv(); f.open(); assert.equal(f.seek(.2).length, 0);
        assert.equal(before, JSON.stringify({ shots: f.record().shots, groups: f.record().groups, timing: f.record().timing, song: f.song }));
        assert.equal(f.providerCalls(), 0);
    } finally { f.mvui.disposeMv(); }
});

test('a chosen five-second title fades out at five seconds rather than waiting for lyrics', async () => {
    const f = await scene(); try {
        f.setIntro(5); assert.ok(f.seek(4).length); const fade = f.seek(4.75); assert.equal(fade.length, 1); assert.ok(fade[0] > 0 && fade[0] < 1);
        assert.equal(f.seek(5).length, 0); f.red(f.preview);
    } finally { f.mvui.disposeMv(); }
});

test('a short first shot keeps its second half visible even with a longer title setting', async () => {
    const f = await scene({ shots: [
        { id: 'S1', group: 'G1', diff: 'D1', sectionIndex: 0, lyric: '', timingWeight: 1, cut: 'cut' },
        { id: 'S1b', group: 'G1', diff: 'D1', sectionIndex: 0, lyric: '', timingWeight: 14, cut: 'cut' },
        { id: 'S2', group: 'G1', diff: 'D1', sectionIndex: 1, lyric: 'line', cut: 'cut' },
    ] }); try {
        f.setIntro(10); assert.equal(f.mv.shotTimeline(f.record(), f.song).rows[0].end, 2);
        assert.ok(f.seek(.2).length); assert.equal(f.seek(1.2).length, 0); f.red(f.preview);
    } finally { f.mvui.disposeMv(); }
});

test('fractional intro durations work and malformed values do not break playback', async () => {
    const f = await scene(); try {
        f.setIntro(.5); assert.ok(f.seek(.1).length); assert.equal(f.seek(.5).length, 0); f.red(f.preview);
        f.setIntro('not a number'); assert.equal(f.record().tegaki.introSeconds, .5);
        for (const value of [undefined, null, '', 'bad', Infinity, -1]) assert.equal(f.mv.tegakiOptions({ tegaki: { introSeconds: value } }).introSeconds, 2);
        assert.equal(f.mv.tegakiOptions({ tegaki: { introSeconds: 0 } }).introSeconds, 0);
    } finally { f.mvui.disposeMv(); }
});

test('a sung opening has no cover and lyric taps are not delayed by title duration', async () => {
    const f = await scene({ timing: { taps: { 0: 0, 1: 30 }, lineTaps: { '1:0': 1 } } }); try {
        f.setIntro(5); assert.equal(f.seek(1).length, 0); assert.equal(f.record().timing.lineTaps['1:0'], 1);
    } finally { f.mvui.disposeMv(); }
    const sung = await scene({ shots: [{ id: 'S1', group: 'G1', diff: 'D1', sectionIndex: 0, lyric: 'line' }] }, '[Verse 1]\nline\n[End]');
    try { assert.equal(sung.seek(0).length, 0); sung.red(sung.preview); } finally { sung.mvui.disposeMv(); }
});

test('fragment preview times the title from its own start without changing export timing', async () => {
    const f = await scene({ tegaki: { range: 'custom', rangeFrom: 1, rangeTo: 1, lyric: 'none' }, timing: { taps: { 0: 0, 1: 30, 2: 60 } }, shots: [
        { id: 'S1', group: 'G1', diff: 'D1', sectionIndex: 0, lyric: '' },
        { id: 'S2', group: 'G1', diff: 'D1', sectionIndex: 1, lyric: '' },
        { id: 'S3', group: 'G1', diff: 'D1', sectionIndex: 2, lyric: 'line' },
    ] }, '[Intro]\n[Interlude]\n[Verse 1]\nline\n[End]'); try {
        f.setIntro(3); assert.ok(f.seek(30.2).length); assert.equal(f.seek(33).length, 0); f.red(f.preview);
        f.mv.patchRecord(f.song.id, { exportRange: { range: 'custom', rangeFrom: 1, rangeTo: 1 } });
        const exported = f.mv.exportRecord(f.record(), f.song), range = f.mv.playRange(exported, f.song);
        assert.equal(exported.tegaki.introSeconds, 3); assert.equal(range.start, 30); assert.equal(range.end, 60);
    } finally { f.mvui.disposeMv(); }
});

test('recorded video renders the same shortened title as preview without shifting the clock', async () => {
    const f = await scene(); let resolveStarted, resolveScheduled, clock = 1000, exportCanvas;
    const started = new Promise(resolve => { resolveStarted = resolve; });
    const scheduled = new Promise(resolve => { resolveScheduled = resolve; });
    const raf = f.sb.requestAnimationFrame;
    f.sb.requestAnimationFrame = tick => { const id = raf(tick); resolveScheduled(); return id; };
    f.sb.performance.now = () => clock;
    f.sb.MediaStream = class { constructor(tracks) { this.tracks = tracks; } };
    f.sb.AudioContext = class {};
    f.sb.MediaRecorder = class {
        static isTypeSupported() { return true; }
        constructor(stream) { this.state = 'inactive'; exportCanvas = stream.tracks[0].canvas; }
        start() { this.state = 'recording'; resolveStarted(); }
        stop() { this.state = 'inactive'; this.onstop?.(); }
    };
    let timer; try {
        f.click('export-range', 'full'); f.setIntro(3); f.click('export');
        await Promise.race([Promise.all([started, scheduled]), new Promise((_, reject) => { timer = setTimeout(() => reject(Error('export did not start')), 5000); })]);
        // Recording starts at the range start. Advancing the clock must expose the first drawing.
        clock = 5000; for (const [id, tick] of [...f.frames]) { f.frames.delete(id); tick(); }
        f.red(exportCanvas);
        assert.equal(f.mv.shotTimeline(f.record(), f.song).rows[0].end, 30);
        assert.equal(f.providerCalls(), 0);
    } finally { clearTimeout(timer); f.mvui.disposeMv(); }
});
