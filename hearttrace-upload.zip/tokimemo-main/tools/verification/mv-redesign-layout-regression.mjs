// Public production bundle + DOM contract. Does not substitute for iPhone/TT.
import test from 'node:test';
import assert from 'node:assert/strict';
import {ui} from './mv-ui-fixture.mjs';
import {stageSetup} from './mv-stage-fixture.mjs';
async function setup(count=17){
 const f=await ui(stageSetup),shellClasses=new Set(),bodyClasses=new Set();
 const classList=set=>({toggle(k,on){on?set.add(k):set.delete(k)},remove(k){set.delete(k)}});
 f.body.classList=classList(bodyClasses);f.body.closest=()=>({classList:classList(shellClasses)});
 f.sb.document.querySelector=()=>null;
 for(const group of f.record.groups)for(const diff of group.diffs)diff.image={url:'/frame.png'};
 f.record.shots=Array.from({length:count},(_,i)=>({...f.record.shots[0],id:'shot-'+i}));
 let generated=0;
 f.get('generation/client').requestJson=async()=>{generated++;throw Error('unexpected generation')};
 f.get('generation/cgImageCore').invokeImageGeneration=async()=>{generated++;throw Error('unexpected generation')};
 f.mvui.openMv({songId:f.song.id});
 return {...f,shellClasses,bodyClasses,generated:()=>generated,saved:()=>JSON.stringify(f.mv.readMv(f.host,f.song.id))};
}
test('approved workbench replaces duplicate chrome, has a direct return, and releases focus on exit',async()=>{
 const f=await setup();try{
  assert.ok(f.shellClasses.has('rmt-mve-focus'));
  assert.match(f.body.innerHTML, /rmt-mve-head[\s\S]*data-rmt-mv="back"/);
  const h=f.body.innerHTML;
  assert.ok(h.indexOf('rmt-mve-projectbar')>h.indexOf('rmt-mve-transport'));
  assert.equal((h.match(/data-rmt-mv-seek/g)||[]).length,1);
  f.click('go-board');assert.equal(f.shellClasses.has('rmt-mve-focus'),false);
  f.click('go-tegaki');assert.ok(f.shellClasses.has('rmt-mve-focus'));
 }finally{f.mvui.disposeMv()}
 assert.equal(f.shellClasses.has('rmt-mve-focus'),false);
});
test('four visible thumbnails and all-shots view retain all 121 frames without generation or saved-data writes',async()=>{
 const f=await setup(121);try{
  const before=f.saved();
  assert.equal((f.body.innerHTML.match(/data-rmt-mv="select-shot"/g)||[]).length,4);
  f.click('editor-strip','120');assert.match(f.body.innerHTML,/data-rmt-mv-id="shot-120"/);
  f.click('select-shot','shot-120');assert.match(f.body.innerHTML,/第 121 镜/);
  f.click('editor-drawer','shots');
  assert.match(f.body.innerHTML,/全部分镜/);
  assert.match(f.body.innerHTML,/rmt-mve-shot-grid/);
  for(let i=0;i<121;i++)assert.ok(f.body.innerHTML.includes(`data-rmt-mv-id="shot-${i}"`));
  f.click('select-shot','shot-3');assert.doesNotMatch(f.body.innerHTML,/rmt-mve-shot-grid/);
  assert.match(f.body.innerHTML,/第 4 镜/);
  f.click('editor-step','1');assert.match(f.body.innerHTML,/第 5 镜/);
  assert.match(f.body.innerHTML,/data-rmt-mv-id="shot-4"/);
  assert.equal(f.saved(),before);assert.equal(f.generated(),0);
 }finally{f.mvui.disposeMv()}
});
test('mobile uses natural height and one page scroll, preview ratio is preserved, and desktop still has two columns',async()=>{
 const f=await setup();try{
  const css=f.get('ui/mvEditorUi').editorCss('#test');
  assert.doesNotMatch(css,/min-height:(740|670|630)px|--rmt-mve-tools-min/);
  assert.match(css,/rmt-mve-focus>\.rmt-topbar/);
  assert.match(css,/rmt-mve-focus>\.rmt-workspace-tabs/);
  assert.match(css,/rmt-mve-panel-scroll\{[^}]*overflow:visible/);
  assert.match(css,/rmt-mv-canvas-wrap\{[^}]*aspect-ratio:16\/9/);
  assert.match(css,/rmt-mv-canvas-wrap\.portrait\{[^}]*aspect-ratio:9\/16/);
  assert.match(css,/@container\s*\(min-width:780px\)/);
 }finally{f.mvui.disposeMv()}
});
test('image editor next crosses shot 4 to 5 and returns to thumbnails 5 through 8 without saved-data writes',async()=>{
 const f=await setup(9),mounted=[];
 f.body.querySelector=s=>s==='[data-rmt-mv-editor-host]'?{}:null;
 f.get('ui/mvImageEditor').mountAssetEditor=(_host,options)=>{mounted.push(options);return {dispose(){}}};
 const flush=()=>new Promise(resolve=>setImmediate(resolve));
 try{
  f.click('select-shot','shot-3');const before=f.saved();
  f.click('edit-asset','G1:D1');await flush();
  assert.match(mounted.at(-1).title,/第 4 镜/);
  await mounted.at(-1).onNext();await flush();
  assert.match(mounted.at(-1).title,/第 5 镜/);
  mounted.at(-1).onClose();assert.match(f.body.innerHTML,/第 5 镜/);
  for(let i=4;i<8;i++)assert.ok(f.body.innerHTML.includes(`data-rmt-mv-id="shot-${i}"`));
  assert.equal((f.body.innerHTML.match(/data-rmt-mv="select-shot"/g)||[]).length,4);
  assert.equal(f.saved(),before);assert.equal(f.generated(),0);
 }finally{f.mvui.disposeMv()}
});
