import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';
import { stageRaw, song } from './mv-stage-fixture.mjs';
import { scene, native } from './mv-stage-canvas-fixture.mjs';

const plain = v => JSON.parse(JSON.stringify(v));
const pixels = c => Buffer.from(c.getContext('2d').getImageData(0, 0, c.width, c.height).data);
const config = { reveal: 'bloom', seconds: 5, movement: 'local', light: 'focus', particles: 'glints', focusX: .72, focusY: .3, lightX: .8, lightY: .32,
    motionRegions: [{ x: .05, y: .3, w: .45, h: .65, amount: .01, phase: 0 }], protect: [{ x: .3, y: .16, w: .4, h: .38 }] };
const configure = record => {
    record.settings.storyType = 'illustration'; record.tegaki.lyric = 'none'; record.tegaki.introSeconds = 0; record.tegaki.outroSeconds = 0;
    for (const s of record.shots) s.illustration = plain(config);
    for (const g of record.groups) g.motion = 'still';
};

test('illustration prompt chooses sustained integrated hero art without conflicting storyboard rules', async () => {
    const f = await fixture(), mv = f.get('extras/mv'); let prompt = '', calls = 0;
    f.get('core/cache').loadSession = () => ({ songs: [song] });
    f.get('generation/client').requestJson = async p => { prompt = p; calls++; return f.json(stageRaw()); };
    await mv.generateStoryboard(song.id, { storyType: 'illustration', range: 'full' });
    assert.equal(calls, 1); assert.doesNotMatch(prompt, /不是连续相似的精修肖像|不要靠长时间悬停|其余段落尽量用新的构图/);
    assert.match(prompt, /保护区|protect/); assert.match(prompt, /跨多句/);
    const example = JSON.parse(prompt.split('\n').at(-1));
    assert.equal(example.groups[0].layer, 'full'); assert.equal(example.groups[0].motion, 'still');
    assert.equal(example.frames[0].illustration.reveal, 'bloom');
    assert.deepEqual(example.frames[0].illustration, example.frames[1].illustration);
    const built = mv.buildShots(f.json(example), f.bank, 2, mv.normalizeSettings({ storyType: 'illustration' }));
    assert.equal(built.groups[0].layer, 'full'); assert.ok(built.shots[0].illustration.motionRegions.length);
    const rec = { ...built, settings: mv.normalizeSettings({ storyType: 'illustration' }) };
    assert.match(mv.defaultAssetPrompt(rec, 'G1:D1', f.host), /finished key illustration/);
});

test('optional new metadata normalizes without generation gates or invented motion regions', async () => {
    const f = await fixture(), fx = f.get('extras/mvIllustration');
    const cue = fx.normalize({ ...config, focusX: 3, lightY: 'bad', motionRegions: [null, { x: 'bad', y: .1, w: .2, h: .3 }, { x: .8, y: .5, w: .7, h: .9, amount: 8 }] });
    assert.equal(cue.reveal, 'bloom'); assert.equal(cue.focusX, 1); assert.equal(cue.lightY, .25);
    assert.equal(cue.motionRegions.length, 1); assert.ok(cue.motionRegions[0].w <= .2); assert.equal(cue.motionRegions[0].amount, .015);
    assert.deepEqual(plain(fx.normalize({ movement: 'local' }).motionRegions), []);
    assert.deepEqual(plain(fx.normalize()), { reveal: 'ink', light: 'halo', particles: 'dust', movement: 'parallax', seconds: 2.4, color: '' });
});

test('same-art opt-in copies cues while preserving assets, timing and unrelated drawings', async () => {
    const f = await fixture(), mv = f.get('extras/mv'); const settings = mv.normalizeSettings({ storyType: 'illustration' });
    const record = { ...mv.buildShots(f.json(stageRaw()), f.bank, 2, settings), settings, timing: { lineTaps: { '0:1': 3.2 } } };
    f.host.chatMetadata[mv.MV_KEY] = { songs: { [song.id]: record } };
    mv.patchIllustration(song.id, record.shots[0].id, f.json(config), true);
    const saved = mv.readMv(f.host, song.id);
    assert.equal(saved.shots[1].illustration.reveal, 'bloom'); assert.equal(saved.shots[2].illustration.reveal, 'ink');
    assert.deepEqual(plain(saved.groups), plain(record.groups)); assert.deepEqual(plain(saved.timing), plain(record.timing));
    const legacy = { ...record, shots: [{ id: 'a', illustration: { reveal: 'ink' } }, { id: 'b', illustration: { reveal: 'ink' } }] };
    const lf = await fixture(), lm = lf.get('extras/mv');
    lf.host.chatMetadata[lm.MV_KEY] = { songs: { [song.id]: lf.json(legacy) } };
    lm.patchIllustration(song.id, 'a', { reveal: 'bloom' }, true);
    assert.equal(lm.readMv(lf.host, song.id).shots[1].illustration.reveal, 'ink', 'unlinked legacy shots are not the same image');
});

function art(w = 240, h = 200) {
    const c = native.createCanvas(w, h), g = c.getContext('2d');
    g.fillStyle = '#ed3620'; g.fillRect(w * .04, h * .04, w * .92, h * .92);
    for (let x = 12; x < w - 12; x += 8) { g.fillStyle = x % 16 ? '#f6cc7a' : '#441a18'; g.fillRect(x, 12, 2, h - 24); }
    g.fillStyle = '#2233cc'; g.fillRect(w * .35, h * .22, w * .3, h * .2);
    return c;
}

test('black/white graphic emerges from the chosen focus, then restores full source pixels and alpha', async () => {
    const f = await scene();
    try {
        const draw = f.get('ui/mvIllustrationCanvas').drawPicture, src = art(), original = pixels(src), out = native.createCanvas(240, 200), g = out.getContext('2d');
        const cue = { ...config, movement: 'still', focusX: .82, focusY: .25, progress: 0 };
        draw(g, src, [0, 0], cue); const mono = g.getImageData(195, 50, 1, 1).data;
        assert.equal(mono[0], mono[1]); assert.ok(mono[0] < 30 || mono[0] > 230, 'graphic values are stronger than ordinary greyscale');
        g.clearRect(0, 0, 240, 200); draw(g, src, [0, 0], { ...cue, progress: .16 });
        const right = g.getImageData(195, 50, 1, 1).data, left = g.getImageData(30, 50, 1, 1).data;
        assert.ok(right[0] > right[1] * 2, 'right-side selected focus colours first'); assert.equal(left[0], left[1], 'far left remains monochrome, unlike the old wipe');
        assert.equal(g.getImageData(0, 0, 1, 1).data[3], 0);
        g.clearRect(0, 0, 240, 200); draw(g, src, [0, 0], { ...cue, progress: 1 });
        assert.deepEqual(pixels(out), original); assert.deepEqual(pixels(src), original);
    } finally { f.mvui.disposeMv(); }
});

test('local motion changes selected texture while protected face, outside region, and source stay exact', async () => {
    const f = await scene();
    try {
        const draw = f.get('ui/mvIllustrationCanvas').drawPicture, model = f.get('extras/mvIllustration'), src = art(), before = pixels(src), out = native.createCanvas(240, 200), g = out.getContext('2d');
        const cue = { ...plain(model.normalize(config)), reveal: 'none', progress: 1, time: 1.2 };
        draw(g, src, [0, 0], cue); const one = pixels(out);
        g.clearRect(0, 0, 240, 200); draw(g, src, [0, 0], { ...cue, time: 3.7 }); const two = pixels(out);
        assert.notDeepEqual(one, two); assert.deepEqual(pixels(src), before);
        const sg = src.getContext('2d');
        assert.deepEqual(g.getImageData(80, 40, 80, 50).data, sg.getImageData(80, 40, 80, 50).data, 'face stays identical');
        assert.deepEqual(g.getImageData(180, 80, 40, 80).data, sg.getImageData(180, 80, 40, 80).data, 'outside region stays identical');
        g.clearRect(0, 0, 240, 200); draw(g, src, [0, 0], cue); assert.deepEqual(pixels(out), one, 'seeking repeats the exact deformation');
        assert.equal(g.getImageData(0, 0, 1, 1).data[3], 0);
    } finally { f.mvui.disposeMv(); }
});

test('new motion combines with all legacy reveal choices instead of silently losing them', async () => {
    const f = await scene();
    try {
        const draw = f.get('ui/mvIllustrationCanvas').drawPicture, model = f.get('extras/mvIllustration'), src = art(), out = native.createCanvas(240, 200), g = out.getContext('2d');
        for (const reveal of ['ink', 'silhouette']) {
            g.clearRect(0, 0, 240, 200); draw(g, src, [0, 0], { ...plain(model.normalize(config)), reveal, progress: 0, time: 2 });
            const p = [...g.getImageData(140, 140, 1, 1).data];
            if (reveal === 'silhouette') assert.deepEqual(p, [23, 27, 41, 255]); else assert.equal(p[0], p[1]);
        }
    } finally { f.mvui.disposeMv(); }
});

for (const ratio of ['16:9', '9:16']) test(`new player cues ${ratio}: stable seeks and editable regions with no image requests`, async () => {
    const f = await scene({ ratio, opaque: true, imageBackground: true, configure });
    try {
        const saved = JSON.stringify(f.record()); f.seek(2); const before = pixels(f.preview); f.seek(10); f.seek(2);
        assert.deepEqual(pixels(f.preview), before); assert.equal(JSON.stringify(f.record()), saved);
        const shot = f.record().shots[0].id;
        assert.match(f.body.innerHTML, /调整动态位置/); assert.match(f.body.innerHTML, /data-rmt-mv="illustration-region-add"/);
        f.mvui.handleMvChange({ target: { matches: s => s === '[data-rmt-mv-illustration]', dataset: { rmtMvIllustration: 'lightX', percent: '1', shot }, value: '22' } });
        assert.equal(f.record().shots[0].illustration.lightX, .22);
        f.mvui.handleMvChange({ target: { matches: s => s === '[data-rmt-mv-region]', dataset: { rmtMvRegion: 'motionRegions', index: '0', field: 'amount', shot }, value: '.4' } });
        assert.equal(f.record().shots[0].illustration.motionRegions[0].amount, .004);
        f.click('illustration-region-add', JSON.stringify([shot, 'motionRegions'])); assert.equal(f.record().shots[0].illustration.motionRegions.length, 2);
        f.click('illustration-region-remove', JSON.stringify([shot, 'motionRegions', 1])); assert.equal(f.record().shots[0].illustration.motionRegions.length, 1);
        f.click('illustration-share', shot); assert.equal(f.record().shots[1].illustration.lightX, .22);
        assert.equal(f.calls(), 0); assert.deepEqual(f.errors, []);
    } finally { f.mvui.disposeMv(); }
});

test('focused light follows source crop and placement, and accepts the extracted RGB palette', async () => {
    const f = await scene();
    try {
        const fx = f.get('ui/mvIllustrationCanvas'), src = art(), out = native.createCanvas(300, 200), g = out.getContext('2d');
        const cue = { ...config, reveal: 'none', movement: 'still', progress: 1, lightX: .75, lightY: .5, songTime: 0 };
        // Original point (180,100), crop (120,0,120,200), placed at (10,0,200,200) => (110,100).
        fx.drawPicture(g, src, [120, 0, 120, 200, 10, 0, 200, 200], cue);
        g.clearRect(0, 0, 300, 200); fx.drawLight(g, cue, 300, 200, ['#000000', '#333333', 'rgb(255,0,0)']);
        const center = g.getImageData(110, 105, 1, 1).data, wrong = g.getImageData(225, 105, 1, 1).data;
        assert.ok(center[0] > center[1] * 2); assert.ok(center[3] > wrong[3]);
    } finally { f.mvui.disposeMv(); }
});

for (const sharedStage of [true, false]) test(`new effects export the same pixels as preview at song time, stage=${sharedStage}`, async () => {
    const f = await scene({ imageBackground: true, opaque: !sharedStage, configure: record => {
        configure(record); for (const s of record.shots) s.illustration.seconds = 12;
        record.shots[2].diff = record.shots[0].diff; record.shots[2].group = record.shots[0].group;
        if (!sharedStage) { delete record.stage; for (const group of record.groups) group.layer = 'full'; }
    } });
    let clock = 1000, exportCanvas, started, scheduled, timer;
    const ready = new Promise(resolve => { started = resolve; }), playing = new Promise(resolve => { scheduled = resolve; });
    const raf = f.sb.requestAnimationFrame;
    f.sb.requestAnimationFrame = fn => { const id = raf(fn); if (fn.name === 'loop' && exportCanvas) scheduled(); return id; };
    f.sb.performance.now = () => clock;
    f.sb.MediaStream = class { constructor(tracks) { this.tracks = tracks; } };
    f.sb.AudioContext = class {};
    f.sb.MediaRecorder = class {
        static isTypeSupported() { return true; }
        constructor(stream) { this.state = 'inactive'; exportCanvas = stream.tracks[0].canvas; }
        start() { this.state = 'recording'; started(); }
        stop() { this.state = 'inactive'; this.onstop?.(); }
    };
    try {
        f.seek(8.1); const expected = pixels(f.preview); f.click('export-range', '1:1'); f.click('export');
        await Promise.race([Promise.all([ready, playing]), new Promise((_, reject) => { timer = setTimeout(() => reject(Error('export did not start')), 5000); })]);
        clock = 1100; for (const [id, tick] of [...f.frames]) { f.frames.delete(id); tick(); }
        assert.deepEqual(pixels(exportCanvas), expected); assert.equal(f.calls(), 0); assert.deepEqual(f.errors, []);
    } finally { clearTimeout(timer); f.mvui.disposeMv(); }
});

test('fractional motion-region bounds leave no dark mesh cracks in opaque artwork', async () => {
    const f = await scene();
    try {
        const src = native.createCanvas(307, 256), sg = src.getContext('2d'); sg.fillStyle = '#eeeeee'; sg.fillRect(0, 0, 307, 256);
        const out = native.createCanvas(307, 256), g = out.getContext('2d');
        const model = f.get('extras/mvIllustration');
        const cue = { ...plain(model.normalize(config)), reveal: 'none', progress: 1, time: 2.3,
            motionRegions: [{ x: .01, y: .11, w: .3, h: .8, amount: .004, phase: 0 }], protect: [] };
        f.get('ui/mvIllustrationCanvas').drawPicture(g, src, [0, 0], cue);
        const p = pixels(out); let min = 255; for (let i = 3; i < p.length; i += 4) min = Math.min(min, p[i]);
        assert.equal(min, 255, 'integer clip boundaries and overlap keep the mesh fully opaque');
    } finally { f.mvui.disposeMv(); }
});
