import { runIf } from './optional.mjs';
// 缺少条件时明确跳过并说明原因；满足时加载同名 .impl.mjs 里的原测试。
await runIf([
    {
        "env": "BASELINE_ROOT",
        "kind": "dir",
        "inside": "dist/heartbeatMemories.bundle.js",
        "why": "r84.183 对照构建目录（含 dist bundle）"
    }
],
    () => import('./bedtime-regression.impl.mjs'));
