// Compare protected contracts against the exact delivered 1.0.44 ZIP.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const plain = x => JSON.parse(JSON.stringify(x));
const hash = data => crypto.createHash('sha256').update(data).digest('hex');
const directions = ['auto', 'narrative', 'lyrical', 'interaction', 'impact', 'loop', 'illustration', 'expression', 'reveal'];
if (process.argv[2] === '--snapshot') {
    const { fixture } = await import('./fixture.mjs');
    const { stageRaw, song } = await import('./mv-stage-fixture.mjs');
    const { scene } = await import('./mv-stage-canvas-fixture.mjs');
    const out = { protected: {}, video: {}, legacyTiming: {}, expressionPixels: {} };
    for (const direction of directions) {
        for (const output of ['tegaki', 'video']) {
            const f = await fixture(), mv = f.get('extras/mv'); let prompt = '';
            f.get('core/cache').loadSession = () => ({ songs: [song] });
            f.get('generation/client').requestJson = async p => { prompt = p; return f.json(output === 'video'
                ? { shots: [{ sectionIndex: 0, plain: '静望', who: 'char', imagePrompt: 'one still person by a window', motion: 'still' }] }
                : stageRaw()); };
            await mv.generateStoryboard(song.id, { storyType: direction, output, range: 'full' });
            const record = mv.readMv(f.host, song.id);
            if (output === 'video') { out.video[direction] = { prompt, frame: mv.framePrompt(record, record.shots[0], f.host) }; continue; }
            if (['expression', 'illustration'].includes(direction)) {
                const assets = {};
                for (const style of ['keep', 'line', 'water', 'pastel', 'mono']) for (const layer of ['full', 'cutout']) {
                    record.settings.style = style; record.groups.forEach(g => g.layer = layer);
                    for (const key of mv.assetKeys(record, song)) assets[`${style}:${layer}:${key}`] = mv.defaultAssetPrompt(record, key, f.host);
                }
                out.protected[direction] = { prompt, defaults: f.get('extras/mvDirection').directionDefaults(direction), options: mv.tegakiOptions(record), assets };
            }
            // Treat these as existing records: new opt-in markers are absent.
            for (const shot of record.shots) delete shot.authoredTiming;
            record.duration = 16; record.timing = { taps: { 0: 0, 1: 8 }, lineTaps: { '0:1': 3.17 } };
            out.legacyTiming[direction] = {};
            for (const template of ['', 'quick', 'flash', 'slow']) {
                record.tegaki.template = template;
                out.legacyTiming[direction][template] = plain(mv.shotTimeline(record, song).rows.map(({ start, end }) => ({ start, end })));
            }
        }
    }
    for (const ratio of ['16:9', '9:16']) for (const template of ['', 'quick']) {
        const f = await scene({ ratio, configure: record => { record.tegaki.template = template; } });
        try {
            const pixels = {};
            for (const t of [0, 1.2, 4.3, 8.2, 12.4]) {
                f.seek(t); pixels[t] = hash(f.preview.getContext('2d').getImageData(0, 0, f.w, f.h).data);
            }
            assert.equal(f.calls(), 0);
            assert.deepEqual(f.errors, []);
            out.expressionPixels[`${ratio}:${template}`] = pixels;
        } finally { f.mvui.disposeMv(); }
    }
    console.log(JSON.stringify(out));
} else {
    const baseline = process.env.BASELINE_ROOT, candidate = process.env.TEST_ROOT;
    assert.ok(baseline && candidate, 'Set BASELINE_ROOT and TEST_ROOT');
    const snapshot = root => {
        const p = spawnSync(process.execPath, ['--experimental-vm-modules', fileURLToPath(import.meta.url), '--snapshot'], {
            env: { ...process.env, TEST_ROOT: root }, encoding: 'utf8', maxBuffer: 8 * 1024 * 1024,
        });
        assert.equal(p.status, 0, p.stderr); return JSON.parse(p.stdout);
    };
    const before = snapshot(baseline), after = snapshot(candidate);
    assert.deepEqual(after, before, 'Protected prompts, options, old timing and expression pixels must remain exact');
    const allowed = new Set(['extras/mv.js', 'core/selfUpdater.js', 'core/releaseNotes.js']);
    let exact = 0;
    for (const name of fs.readdirSync(path.join(baseline, 'src'), { recursive: true })) {
        const old = path.join(baseline, 'src', name), next = path.join(candidate, 'src', name);
        if (!fs.statSync(old).isFile() || allowed.has(name)) continue;
        assert.deepEqual(fs.readFileSync(next), fs.readFileSync(old), name); exact++;
    }
    for (const name of fs.readdirSync(path.join(candidate, 'src'), { recursive: true })) {
        if (!fs.statSync(path.join(candidate, 'src', name)).isFile()) continue;
        assert.ok(fs.existsSync(path.join(baseline, 'src', name)) || name === 'extras/mvTegakiDirection.js', `Unexpected new source: ${name}`);
    }
    let tools = 0;
    for (const name of fs.readdirSync(path.join(baseline, 'tools'), { recursive: true })) {
        const old = path.join(baseline, 'tools', name), next = path.join(candidate, 'tools', name);
        if (!fs.statSync(old).isFile()) continue;
        assert.deepEqual(fs.readFileSync(next), fs.readFileSync(old), `Existing tool changed: ${name}`); tools++;
    }
    console.log(JSON.stringify({ protectedDirections: ['expression', 'illustration'], videoDirections: 9, legacyTimelineProfiles: 36,
        expressionPixelComparisons: 20, exactOtherSourceFiles: exact, exactExistingTools: tools,
        protectedPromptsDefaultsAssetsAndPixelsEqual: true }));
}
