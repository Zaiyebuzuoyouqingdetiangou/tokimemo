import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture, realClient } from './fixture.mjs';

const song = { id: 'SONG_stream', title: '流式分镜', lyrics: '[Verse]\n窗边的灯\n[Chorus]\n回家的路' };
const raw = { groups: [{ id: 'G1', composition: '窗边', characterPrompt: 'at the window', diffs: [{ id: 'D1', change: 'looks up' }] }], frames: [{ sectionIndex: 0, lyric: '窗边的灯', group: 'G1', diff: 'D1' }] };
async function setup() {
    const f = await fixture(); realClient(f, () => raw);
    f.get('core/cache').loadSession = () => ({ songs: [song] });
    f.mv = f.get('extras/mv'); f.sent = [];
    f.host.ConnectionManagerRequestService.sendRequest = async (...args) => {
        f.sent.push(args);
        return async function* () {
            yield { text: '', state: { reasoning: 'private reasoning' } };
            yield { text: JSON.stringify(raw).slice(0, 20), state: { reasoning: '' } };
            yield { text: JSON.stringify(raw), state: { reasoning: '' } };
        };
    };
    return f;
}

test('MV storyboard and continuation prefer the existing streaming transport with one paid request per click', async () => {
    const f = await setup();
    await f.mv.generateStoryboard(song.id, { output: 'tegaki', range: 'full' });
    assert.equal(f.sent.length, 1); assert.equal(f.sent[0][3].stream, true);
    assert.equal(f.sent[0][2], 120000, 'configured max output is not reduced');
    assert.equal(f.mv.readMv(f.host, song.id).shots.length, 1);
    await f.mv.continueStoryboard(song.id);
    assert.equal(f.sent.length, 2); assert.equal(f.sent[1][3].stream, true);
    const trace = f.get('core/taskTrace').taskTraceSnapshot().at(-1);
    assert.equal(trace.transport.streamRequested, true);
    assert.equal(trace.transport.receivedChunks, 3);
    assert.ok(trace.transport.firstChunkMs >= 0);
    assert.ok(!JSON.stringify(trace).includes('private reasoning'));
});

test('an explicit complete-response preference stays effective; other modes are unchanged', async () => {
    const f = await setup(), settings = f.get('core/settings'), getSettings = settings.getPluginSettings;
    settings.getPluginSettings = () => ({ ...getSettings(), advancedGenerationEnabled: true, advancedStreamMode: 'off' });
    await f.mv.generateStoryboard(song.id, { output: 'tegaki' });
    assert.equal(f.sent[0][3].stream, false);
    settings.getPluginSettings = getSettings;
    await f.get('generation/client').requestJson('test', 'test', { mode: 'album', context: f.host });
    assert.equal(f.sent[1][3].stream, false);
});

test('a non-streaming JSON reply to the same streaming request is accepted without another request', async () => {
    const f = await setup();
    f.host.ConnectionManagerRequestService.sendRequest = async (...args) => { f.sent.push(args); return { choices: [{ message: { content: JSON.stringify(raw) } }] }; };
    await f.mv.generateStoryboard(song.id, { output: 'tegaki' });
    assert.equal(f.sent.length, 1); assert.equal(f.sent[0][3].stream, true);
    assert.equal(f.mv.readMv(f.host, song.id).shots.length, 1);
});

test('524 and 503 still surface honestly, with no automatic reroll or clearing old images and timings', async () => {
    for (const status of [503, 524]) {
        const f = await setup(); await f.mv.generateStoryboard(song.id, { output: 'tegaki' });
        f.mv.writeMv(f.mv.mvScope(f.host), song.id, record => {
            record.groups[0].diffs[0].image = { url: '/old-paid.png' };
            record.tegaki.lyricTimes = { '0:0': 4.5 }; return record;
        });
        const before = JSON.stringify(f.mv.readMv(f.host, song.id));
        f.host.ConnectionManagerRequestService.sendRequest = async (...args) => { f.sent.push(args); const e = new Error('upstream'); e.status = status; throw e; };
        await assert.rejects(() => f.mv.generateStoryboard(song.id, { output: 'tegaki' }), e => e.status === status && e.code === 'RMT_CONNECTION_SERVER');
        assert.equal(f.sent.length, 2); assert.equal(JSON.stringify(f.mv.readMv(f.host, song.id)), before);
        const trace = f.get('core/taskTrace').taskTraceSnapshot().at(-1);
        assert.equal(trace.transport.streamRequested, true); assert.equal(trace.transport.receivedChunks, 0);
        assert.equal(trace.transport.firstChunkMs, null); assert.equal(trace.httpStatus, status);
    }
});

test('manual API uses the same stream preference and preserves an explicit off switch', async () => {
    for (const forceOff of [false, true]) {
        const f = await fixture(), api = f.get('core/independentApiRequest');
        const settings = { ...f.constants.DEFAULT_SETTINGS, manualApiBaseUrl: 'https://example.com/v1', manualApiModel: 'model', manualApiKey: '',
            advancedGenerationEnabled: forceOff, advancedStreamMode: forceOff ? 'off' : 'original' };
        let body, chunks = 0;
        const sse = 'data: ' + JSON.stringify({ choices: [{ delta: { content: JSON.stringify(raw) }, finish_reason: 'stop' }] }) + '\n\n';
        const result = await api.requestManualApiCompletion(settings, f.host, [{ role: 'user', content: 'unchanged prompt' }], 120000, {
            preferStream: true, onProgress: () => { chunks++; },
            fetchImpl: async (_url, options) => { body = JSON.parse(options.body); return new Response(sse, { headers: { 'content-type': 'text/event-stream' } }); },
        });
        assert.equal(body.stream, !forceOff); assert.equal(body.max_tokens, 120000);
        assert.equal(body.messages[0].content, 'unchanged prompt'); assert.ok(chunks > 0);
        assert.deepEqual(JSON.parse(f.get('core/independentApi').assertIndependentResponsePayload(result)), raw);
    }
});

test('a broken stream never saves an incomplete storyboard or sends an automatic second request', async () => {
    const f = await setup(); await f.mv.generateStoryboard(song.id, { output: 'tegaki' });
    const before = JSON.stringify(f.mv.readMv(f.host, song.id));
    f.host.ConnectionManagerRequestService.sendRequest = async (...args) => {
        f.sent.push(args);
        return async function* () { yield { text: '{"groups":[', state: {} }; throw Error('connection lost'); };
    };
    await assert.rejects(() => f.mv.generateStoryboard(song.id, { output: 'tegaki' }));
    assert.equal(f.sent.length, 2); assert.equal(JSON.stringify(f.mv.readMv(f.host, song.id)), before);
});
