"""Run every available regression file, preserving failures and missing fixtures.

Production is never modified by this runner. Unchanged historical tests run on
both delivered 1.0.21 and the candidate; new tests run on the candidate. Each
file has its own Node process and complete TAP, with a 120-second harness cap.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import os
import re
import subprocess
import sys
import time

candidate, baseline, destination = map(lambda v: Path(v).resolve(), sys.argv[1:4])
destination.mkdir(parents=True, exist_ok=True)
tests_dir = candidate / 'tools/verification'
files = sorted(tests_dir.glob('*regression.mjs'))
jobs = []
for file in files:
    old = baseline / 'tools/verification' / file.name
    if old.is_file():
        assert old.read_bytes() == file.read_bytes(), 'Historical test changed: ' + file.name
        jobs.append(('baseline', baseline, file, {}))
    jobs.append(('candidate', candidate, file, {}))
# The existing previous-regression file supports both source and bundle.
for label, root in [('baseline', baseline), ('candidate', candidate)]:
    jobs.append((label, root, tests_dir / 'previous-regression.mjs', {'TEST_BUNDLE': '1'}))

def run(job):
    label, root, file, extra = job
    target = destination / label
    target.mkdir(exist_ok=True)
    suffix = '-bundle' if extra else ''
    command = ['node', '--experimental-vm-modules', '--test', '--test-isolation=none', '--test-reporter=tap', str(file)]
    env = {**os.environ, 'TEST_ROOT': str(root), 'BASELINE_ROOT': str(baseline), **extra}
    env.pop('PREVIOUS_BUILD_ROOT', None)
    if file.name == 'mv-index-regression.mjs':
        # Its one upgrade case requires an actual r84.209 runtime. That file
        # was not supplied. Let the original test report its missing fixture;
        # never substitute a modern runtime or skip the file to turn it green.
        env.pop('BASELINE_ROOT', None)
    started = time.monotonic()
    timeout = False
    try:
        process = subprocess.run(command, cwd=candidate, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=120)
        output, code = process.stdout, process.returncode
    except subprocess.TimeoutExpired as error:
        output, code, timeout = (error.stdout or b'') + b'\n# Harness: file exceeded 120 seconds; remaining cases are not verified.\n', 124, True
    log = target / (file.stem + suffix + '.tap')
    log.write_bytes(output)
    text = output.decode(errors='replace')
    totals = {key: (int(matches[-1]) if (matches := re.findall(r'^# ' + key + r' (\d+)$', text, re.M)) else None)
              for key in ['tests', 'pass', 'fail', 'cancelled', 'skipped', 'todo']}
    result = {'build': label, 'file': file.name, 'variant': 'bundle' if extra else 'default', 'argv': command,
              'test_root': str(root), 'baseline_root': env.get('BASELINE_ROOT'), 'previous_build_root': None,
              'exit_code': code, 'timeout': timeout, 'seconds': round(time.monotonic() - started, 3),
              'totals': totals, 'failures': re.findall(r'^not ok \d+ - (.+)$', text, re.M),
              'log': str(log.relative_to(destination))}
    print(json.dumps({key: result[key] for key in ['build', 'file', 'variant', 'exit_code', 'seconds', 'totals']}, ensure_ascii=False), flush=True)
    return result

results = []
with ThreadPoolExecutor(max_workers=3) as pool:
    for future in as_completed([pool.submit(run, job) for job in jobs]):
        results.append(future.result())
        (destination / 'results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')

index = {(row['build'], row['file'], row['variant']): row for row in results}
new_failures = []
for row in results:
    if row['build'] != 'candidate':
        continue
    previous = index.get(('baseline', row['file'], row['variant']))
    for failure in row['failures']:
        if not previous or failure not in previous['failures']:
            new_failures.append({'file': row['file'], 'test': failure})
summary = {'candidate_files': len(files), 'executions': len(results), 'new_failure_names': new_failures,
           'missing_historical_fixtures': ['r84.209 for one mv-index upgrade test', 'r84.215 for three mv-journal-upgrade tests'],
           'environment': 'Node with simulated host/provider/storage and native Canvas where tests request it; no live Suno/TT/iPhone',
           'bundle_sha256': hashlib.sha256((candidate / 'dist/heartbeatMemories.bundle.js').read_bytes()).hexdigest()}
for label in ['baseline', 'candidate']:
    rows = [row for row in results if row['build'] == label]
    summary[label] = {'reported_totals': {key: sum(row['totals'][key] or 0 for row in rows) for key in ['tests', 'pass', 'fail', 'cancelled', 'skipped', 'todo']},
                      'files_without_totals': [row['file'] for row in rows if row['totals']['tests'] is None],
                      'timed_out_files': [row['file'] for row in rows if row['timeout']],
                      'nonzero_executions': [{'file': row['file'], 'variant': row['variant'], 'exit_code': row['exit_code'], 'failures': row['failures']} for row in rows if row['exit_code']]}
(destination / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
raise SystemExit(1 if any(row['exit_code'] for row in results if row['build'] == 'candidate') else 0)
