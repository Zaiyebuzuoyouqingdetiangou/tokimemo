import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const [base, root, out] = process.argv.slice(2);
const sha = text => crypto.createHash('sha256').update(text).digest('hex');
const allowed = new Set(['__m_extras_mv_js.framePrompt', '__m_extras_mv_js.assetPrompt', '__m_extras_mv_js.storyboardPrompt', '__m_extras_mv_js.tegakiGrammar', '__m_extras_mv_js.rewriteShot', '__m_extras_mv_js.continueStoryboard']);
async function load(dir) {
    let code = fs.readFileSync(path.join(dir, 'dist/heartbeatMemories.bundle.js'), 'utf8');
    code = code.replace(/\n(__m_extras_mv_js\.\w+ = \w+;)/, '\n__m_extras_mv_js.__storyboardPrompt = storyboardPrompt;\n__m_extras_mv_js.__tegakiGrammar = tegakiGrammar;\n$1')
        .replace(/\n(__m_extras_waiting_js\.\w+ = \w+;)/, '\n__m_extras_waiting_js.__waitingPrompt = waitingPrompt;\n$1');
    const names = [...code.matchAll(/^const (__m_\w+) = Object.create\(null\);/gm)].map(x => x[1]);
    const m = new vm.SourceTextModule(code + '\nexport { ' + names.join(',') + ' };', { context: vm.createContext({ console, queueMicrotask, TextEncoder, TextDecoder, URL, URLSearchParams, AbortController, DOMException, structuredClone, setTimeout, clearTimeout, setInterval, clearInterval, crypto: crypto.webcrypto }) });
    await m.link(() => {}); await m.evaluate(); return m.namespace;
}
const [a, b] = await Promise.all([load(base), load(root)]), rows = [];
function record(module, name, before, after) {
    assert.equal(typeof after, 'function', module + '.' + name);
    const x = before?.toString(), y = after.toString(), id = module + '.' + name.replace(/^__/, '');
    if (before && !allowed.has(id)) assert.equal(y, x, 'Unapproved prompt-bearing function change: ' + id);
    rows.push({ module, function: name.replace(/^__/, ''), baseline_sha256: x ? sha(x) : null, current_sha256: sha(y), unchanged: x === y, added: !before, before_chars: x?.length || 0, after_chars: y.length });
}
for (const module of Object.keys(b)) for (const [name, fn] of Object.entries(b[module])) {
    if (typeof fn === 'function' && !name.startsWith('__') && /prompt/i.test(name) && name !== 'assertPromptBudget') record(module, name, a[module]?.[name], fn);
}
for (const [module, name] of [['__m_extras_waiting_js', '__waitingPrompt'], ['__m_extras_mv_js', '__storyboardPrompt'], ['__m_extras_mv_js', '__tegakiGrammar'], ['__m_extras_mv_js', 'rewriteShot'], ['__m_extras_mv_js', 'continueStoryboard']]) record(module, name, a[module][name], b[module][name]);
assert.deepEqual(rows.filter(r => !r.added && !r.unchanged).map(r => r.module + '.' + r.function).sort(), [...allowed].sort());
assert.deepEqual(rows.filter(r => r.added).map(r => r.module + '.' + r.function).sort(), ['__m_extras_mvCast_js.castPrompt', '__m_extras_mvDirection_js.directionPrompt']);
fs.writeFileSync(out, JSON.stringify({ scope: 'Hashes cover full prompt-bearing functions; continuation/rewrite also include request and save control flow. MV changes restore r212/r213 rules plus safe batch continuation. Every other existing prompt function must remain byte-identical.', rows }, null, 2) + '\n');
console.log(JSON.stringify({ checked: rows.length, unchanged: rows.filter(r => r.unchanged).length, changed: rows.filter(r => !r.added && !r.unchanged).length, restored_new_paths: rows.filter(r => r.added).length }));
