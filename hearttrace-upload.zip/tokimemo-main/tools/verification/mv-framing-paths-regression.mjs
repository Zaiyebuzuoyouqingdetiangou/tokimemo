import test from 'node:test';
import assert from 'node:assert/strict';
import { scene, native } from './mv-stage-canvas-fixture.mjs';

// The three square landmarks represent both hands/eyes plus their midpoint.
// Pixel observations are the oracle: a crop that loses either end cannot pass
// merely by reporting a plausible fit rectangle or choosing the right branch.
function landmarkArt({ opaque = false, editMode = 'cutout', background = '#273442' } = {}) {
    const c = native.createCanvas(320, 180), g = c.getContext('2d');
    if (opaque) { g.fillStyle = background; g.fillRect(0, 0, 320, 180); }
    g.fillStyle = '#d99a77'; g.fillRect(8, 72, 304, 36);
    for (const [x, color] of [[20, '#ed314a'], [152, '#375ee8'], [284, '#ffe030']]) {
        g.fillStyle = color; g.fillRect(x, 82, 16, 16);
    }
    return { url: c.toDataURL(), editMode, split: 'none' };
}

function boundsOf(canvas, matches) {
    const { width, height } = canvas;
    const data = canvas.getContext('2d').getImageData(0, 0, width, height).data;
    let minX = width, minY = height, maxX = -1, maxY = -1, count = 0;
    for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
        const i = (y * width + x) * 4;
        if (!matches(data[i], data[i + 1], data[i + 2])) continue;
        minX = Math.min(minX, x); minY = Math.min(minY, y);
        maxX = Math.max(maxX, x); maxY = Math.max(maxY, y); count++;
    }
    return count ? { minX, minY, maxX, maxY, count, width: maxX - minX + 1, height: maxY - minY + 1 } : null;
}

function assertLandmarks(canvas) {
    // Tolerances also permit the existing gentle non-stage colour treatment.
    const markers = [
        boundsOf(canvas, (r, g, b) => r > 180 && g < 95 && b < 130),
        boundsOf(canvas, (r, g, b) => b > 170 && r < 100 && g < 145),
        boundsOf(canvas, (r, g, b) => r > 180 && g > 150 && b < 100),
    ];
    for (const [i, box] of markers.entries()) {
        assert.ok(box && box.count > 100, ['left hand/eye', 'midpoint', 'right hand/eye'][i] + ' must remain visible');
        assert.ok(box.minX > 0 && box.maxX < canvas.width - 1, 'the complete end marker must fit inside the frame');
        assert.ok(Math.abs(box.width - box.height) <= 3, 'a square source landmark must retain its proportions');
        assert.ok(Math.abs((box.minY + box.maxY) / 2 - canvas.height / 2) <= 3, 'a local insert retains its vertical centre instead of being placed as a standing actor');
    }
    assert.ok(markers[0].maxX < markers[1].minX && markers[1].maxX < markers[2].minX, 'source left-to-right order must remain intact');
    assert.ok(Math.abs(markers[0].width - markers[2].width) <= 3, 'both ends must retain the same visible size');
}

function configureDetail(record) {
    const group = record.groups[0];
    group.scale = 'close'; group.composition = '手部特写'; group.motion = 'still';
    record.tegaki.lyric = 'none';
    // These tests concern framing, not transition or decorative overlays.
    for (const shot of record.shots) { shot.cut = 'cut'; shot.motion = 'still'; }
    return group;
}

const paths = [
    { name: 'full group layer', change: (r, g) => { g.layer = 'full'; delete g.diffs[0].image.editMode; } },
    { name: 'asset explicitly kept as a full image', change: (r, g) => { g.diffs[0].image.editMode = 'full'; } },
    { name: 'opaque cutout needing editor fallback', opaque: true, change: () => {} },
    { name: 'per-shot full-image override', change: (r, g) => {
        r.shots[0].image = { ...g.diffs[0].image, editMode: 'full' };
        delete g.diffs[0].image;
    } },
    { name: 'non-expression legacy group without a stage', change: (r, g) => {
        r.settings.storyType = 'narrative'; delete r.stage;
        g.layer = 'full'; g.diffs[0].image.editMode = 'full';
    } },
    { name: 'legacy per-shot image without a stage', change: (r, g) => {
        r.settings.storyType = 'narrative'; delete r.stage;
        r.shots[0].image = { ...g.diffs[0].image, editMode: 'full' };
        delete g.diffs[0].image;
    } },
];

for (const path of paths) test(`detail framing reaches ${path.name}`, async () => {
    const f = await scene({ ratio: '9:16', imageBackground: true,
        createArt: () => landmarkArt({ opaque: path.opaque }),
        configure: r => path.change(r, configureDetail(r)) });
    try {
        const before = JSON.stringify(f.record());
        f.seek(1); assertLandmarks(f.preview);
        f.seek(5); f.seek(1); assertLandmarks(f.preview);
        assert.equal(JSON.stringify(f.record()), before, 'opening and seeking cannot rewrite an old saved asset or layout');
        assert.equal(f.calls(), 0, 'framing an existing image cannot regenerate it');
        assert.deepEqual(f.errors, []);
    } finally { f.mvui.disposeMv(); }
});

for (const ratio of ['16:9', '9:16']) for (const description of ['脸部极度特写', 'legacy characterPrompt']) {
    test(`detail metadata recognizes ${description} in ${ratio}`, async () => {
        const f = await scene({ ratio, imageBackground: true, createArt: () => landmarkArt(), configure: r => {
            const g = configureDetail(r); g.scale = 'medium';
            g.composition = description === 'legacy characterPrompt' ? '构图一' : description;
            g.cast = [];
            g.diffs[0].label = '镜头一'; delete g.diffs[0].imagePrompt;
            if (description === 'legacy characterPrompt') g.characterPrompt = 'hands close-up, two hands holding each other';
        } });
        try {
            const before = JSON.stringify(f.record());
            f.seek(1); assertLandmarks(f.preview);
            assert.equal(JSON.stringify(f.record()), before); assert.equal(f.calls(), 0);
        } finally { f.mvui.disposeMv(); }
    });
}

const legacyMetadata = [
    { name: 'hands-only cast with a medium scale', configure: (r, g) => { g.cast = [{ name: 'Char', visible: 'hands' }, { name: 'User', visible: 'hands' }]; } },
    { name: 'detail cue stored only in diff.change', configure: (r, g) => { g.diffs[0].change = '手部特写'; } },
    { name: 'face close-up stored only in the shot imagePrompt', configure: r => { r.shots[0].imagePrompt = 'face close-up, eyes looking forward'; } },
];

for (const metadata of legacyMetadata) test(`local framing recognizes ${metadata.name}`, async () => {
    const f = await scene({ ratio: '9:16', imageBackground: true, createArt: () => landmarkArt(), configure: r => {
        const g = configureDetail(r); g.scale = 'medium'; g.composition = '构图一'; g.cast = [];
        delete g.characterPrompt; g.diffs[0].label = '镜头一';
        delete g.diffs[0].imagePrompt; delete g.diffs[0].change;
        for (const shot of r.shots) delete shot.imagePrompt;
        metadata.configure(r, g);
    } });
    try {
        const before = JSON.stringify(f.record());
        f.seek(1); assertLandmarks(f.preview);
        assert.equal(JSON.stringify(f.record()), before); assert.equal(f.calls(), 0);
    } finally { f.mvui.disposeMv(); }
});

test('a legacy V1 shot preserves its complete local image', async () => {
    const f = await scene({ ratio: '9:16', createArt: () => landmarkArt({ opaque: true, editMode: 'full' }), configure: r => {
        const g = configureDetail(r); r.version = 1; delete r.stage;
        for (const shot of r.shots) { shot.shot = '牵手特写'; shot.image = { ...g.diffs[0].image }; }
        r.shots[1].shot = '全景'; r.shots[1].image = { split: 'left' };
    } });
    try {
        const before = JSON.stringify(f.record()); assert.equal(f.record().version, 1);
        f.seek(1); assertLandmarks(f.preview);
        f.seek(5); assertLandmarks(f.preview); // Missing next image retains the actual previous picture and its framing.
        f.seek(1); assertLandmarks(f.preview);
        assert.equal(JSON.stringify(f.record()), before); assert.equal(f.calls(), 0);
        assert.deepEqual(f.errors, []);
    } finally { f.mvui.disposeMv(); }
});

test('a non-stage single-shot image retains its original background and does not acquire automatic cutout', async () => {
    const f = await scene({ ratio: '9:16', createArt: () => landmarkArt({ opaque: true, background: '#ffffff' }), configure: r => {
        const g = configureDetail(r); delete r.stage; r.settings.storyType = 'narrative'; g.layer = 'cutout';
        r.shots[0].image = { ...g.diffs[0].image }; delete r.shots[0].image.editMode;
    } });
    try {
        const before = JSON.stringify(f.record()); f.seek(1); assertLandmarks(f.preview);
        assert.deepEqual([...f.preview.getContext('2d').getImageData(f.w / 2, f.h / 2 - 100, 1, 1).data], [255, 255, 255, 255], 'the picture keeps its white background');
        assert.equal(JSON.stringify(f.record()), before); assert.equal(f.calls(), 0);
    } finally { f.mvui.disposeMv(); }
});

test('export waits for the local background exposed by a full detail insert and matches preview pixels', async () => {
    const f = await scene({ ratio: '9:16', imageBackground: true, createArt: () => landmarkArt({ editMode: 'full' }), configure: configureDetail });
    let clock = 1000, exportCanvas, started, scheduled, releaseBackground, timer;
    const ready = new Promise(resolve => { started = resolve; });
    const playing = new Promise(resolve => { scheduled = resolve; });
    const backgroundReady = new Promise(resolve => { releaseBackground = resolve; });
    const raf = f.sb.requestAnimationFrame;
    f.sb.requestAnimationFrame = fn => { const id = raf(fn); if (fn.name === 'loop' && exportCanvas) scheduled(); return id; };
    f.sb.performance.now = () => clock;
    f.sb.MediaStream = class { constructor(tracks) { this.tracks = tracks; } };
    f.sb.AudioContext = class {};
    f.sb.MediaRecorder = class {
        static isTypeSupported() { return true; }
        constructor(stream) { this.state = 'inactive'; exportCanvas = stream.tracks[0].canvas; }
        start() { this.state = 'recording'; started(); }
        stop() { this.state = 'inactive'; this.onstop?.(); }
    };
    try {
        f.seek(.1); assertLandmarks(f.preview);
        const reference = Buffer.from(f.preview.getContext('2d').getImageData(0, 0, f.w, f.h).data);
        const backgroundUrl = f.record().stage.backgrounds[0].image.url;
        f.record().stage.backgrounds[0].image = { local: 'detail-background' };
        let requested = false;
        f.get('extras/mvMedia').getMedia = async key => {
            assert.equal(key, 'detail-background'); requested = true; await backgroundReady;
            return { blob: { dataURL: backgroundUrl } };
        };
        f.sb.URL.createObjectURL = blob => blob.dataURL;
        f.click('export');
        await new Promise(resolve => setImmediate(resolve));
        assert.equal(requested, true, 'the local background must be included in export preload');
        assert.equal(exportCanvas, undefined, 'recording must wait until the background is available');
        releaseBackground();
        await Promise.race([Promise.all([ready, playing]), new Promise((_, reject) => { timer = setTimeout(() => reject(Error('export did not start')), 5000); })]);
        clock = 1100;
        for (const [id, tick] of [...f.frames]) { f.frames.delete(id); tick(); }
        assertLandmarks(exportCanvas);
        assert.deepEqual(Buffer.from(exportCanvas.getContext('2d').getImageData(0, 0, f.w, f.h).data), reference);
        assert.equal(f.calls(), 0); assert.deepEqual(f.errors, []);
    } finally { releaseBackground(); clearTimeout(timer); f.mvui.disposeMv(); }
});

for (const editMode of ['full', 'cutout']) test(`a manually selected right cell retains both ends in ${editMode} mode`, async () => {
    const f = await scene({ ratio: '9:16', imageBackground: true, createArt: () => {
        const c = native.createCanvas(640, 180), g = c.getContext('2d');
        // The left cell must not leak into the selected right cell.
        g.fillStyle = '#e200e2'; g.fillRect(0, 0, 320, 180);
        g.fillStyle = '#d99a77'; g.fillRect(328, 72, 304, 36);
        for (const [x, color] of [[340, '#ed314a'], [472, '#375ee8'], [604, '#ffe030']]) {
            g.fillStyle = color; g.fillRect(x, 82, 16, 16);
        }
        return { url: c.toDataURL(), editMode, split: 'right' };
    }, configure: configureDetail });
    try {
        const before = JSON.stringify(f.record()); f.seek(1); assertLandmarks(f.preview);
        assert.equal(boundsOf(f.preview, (r, g, b) => r > 160 && g < 50 && b > 160), null, 'the unselected cell must remain excluded');
        assert.equal(JSON.stringify(f.record()), before); assert.equal(f.calls(), 0);
        assert.deepEqual(f.errors, []);
    } finally { f.mvui.disposeMv(); }
});

test('an opaque full scene at its original aspect ratio retains its original composition', async () => {
    const f = await scene({ ratio: '16:9', imageBackground: true,
        createArt: () => landmarkArt({ opaque: true, editMode: 'full' }), configure: r => {
            const g = configureDetail(r); g.layer = 'full'; g.scale = 'wide';
            g.composition = '两人牵手，完整河岸场景';
            g.diffs[0].imagePrompt = 'two people by the river, wide shot, full scene';
        } });
    try {
        const before = JSON.stringify(f.record()); f.seek(1); assertLandmarks(f.preview);
        const g = f.preview.getContext('2d');
        for (const [x, y] of [[3, 3], [f.w - 4, f.h - 4]])
            assert.deepEqual([...g.getImageData(x, y, 1, 1).data], [39, 52, 66, 255], 'full-scene corners keep the source background');
        assert.deepEqual([...g.getImageData(84, 270, 1, 1).data], [237, 49, 74, 255], 'the left landmark keeps its original composition');
        assert.deepEqual([...g.getImageData(876, 270, 1, 1).data], [255, 224, 48, 255], 'the right landmark keeps its original composition');
        assert.equal(JSON.stringify(f.record()), before); assert.equal(f.calls(), 0);
    } finally { f.mvui.disposeMv(); }
});

for (const scale of ['full', 'medium']) test(`${scale} stage actor mentioning hands remains a standing actor`, async () => {
    const f = await scene({ imageBackground: true, configure: r => {
        const g = r.groups[0]; g.scale = scale; g.motion = 'still';
        g.composition = scale === 'full' ? '全身站立，双手牵在身前' : '正面半身，双手交叠在身前';
        g.diffs[0].imagePrompt = scale === 'full' ? 'one boy, full body, holding hands, natural pose' : 'one boy, upper body, hands held at chest, face visible';
        r.tegaki.lyric = 'none';
    } });
    try {
        const group = f.record().groups[0];
        assert.equal(f.get('ui/mvStageCanvas').isDetailInsert(group, group.diffs[0]), false);
        f.seek(1);
        const body = boundsOf(f.preview, (r, g, b) => r > 180 && g < 125 && b < 125);
        assert.ok(body, 'the actor remains visible');
        if (scale === 'full') assert.ok(body.maxY > f.h * .90 && body.maxY < f.h * .98, 'full body retains ground contact rather than centering the source cell');
        else assert.ok(body.maxY >= f.h - 2, 'a half-body portrait stays anchored to the bottom edge');
        assert.equal(f.calls(), 0);
    } finally { f.mvui.disposeMv(); }
});
