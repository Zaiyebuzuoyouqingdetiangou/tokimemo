import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { fixture } from './fixture.mjs';

async function setup({ native = false, preset = true } = {}) {
    const f = await fixture(), requests = [];
    f.host.name1 = '小雪'; f.host.name2 = '小林';
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS,
        imageGenerationProvider: 'baibai-image', imageGenerationFallback: false });
    f.sb.STBaiBaiImage = { apiVersion: 1, capabilities: { generate: true, saveToGallery: true, characterLibrary: true },
        getBackendStatus: () => ({ configured: true, backend: 'nai', supportsCharacters: native }),
        getCharacters: () => ({ apiVersion: 1, characters: preset ? [{ name: '小雪', tag: '{{silver hair}}, blue eyes' }] : [] }),
        generate: async request => { requests.push(request); return { path: '/user/images/dialect.png' }; } };
    return { ...f, requests };
}
const metadata = format => ({ promptFormat: format, selectedRoles: ['user'], sceneTags: '1girl, sitting by a window',
    characters: [{ role: 'user', name: '小雪', tag: 'black hair' }] });

for (const preset of [false, true]) test(`NAI 4.5 flat fallback uses literal scene and appearance without generated Chinese labels, preset=${preset}`, async () => {
    const f = await setup({ preset }), meta = metadata('nai45-tags'), scene = meta.sceneTags;
    const preview = f.get('generation/cgImageActions').cgEditorSendPreview(f.constants.MODE.ALBUM, {}, scene, meta, meta.promptFormat, f.host);
    assert.equal(f.requests.length, 0);
    await f.get('generation/cgImageCore').invokeImageGeneration(scene, f.host, { promptMetadata: meta });
    assert.equal(f.requests.length, 1); const sent = f.requests[0];
    assert.equal(sent.prompt, preview.prompt); assert.equal(sent.nl, preview.nl);
    assert.equal(sent.prompt, `${scene}, ${preset ? '{{silver hair}}, blue eyes' : 'black hair'}`);
    assert.doesNotMatch(sent.prompt, /人物外貌|小雪/); assert.equal(sent.characters, undefined);
});

test('tag fallback retains natural-only manually supplied appearance once without adding a name wrapper', async () => {
    const f = await setup({ preset: false });
    const meta = { promptFormat: 'nai45-tags', castSnapshot: { version: 1, people: [{ id: 'a', name: '小雪', sourceRefs: [] }] },
        characters: [{ participantId: 'a', tag: '', nl: '用户手填：银发和蓝眼睛', appearanceOverride: true }] };
    const preview = f.get('generation/baibaiImage').baiBaiSendPreview('solo, window', { promptMetadata: meta, context: f.host });
    assert.equal(preview.prompt, 'solo, window, 用户手填：银发和蓝眼睛');
    assert.equal(preview.nl, preview.prompt);
});

test('existing complete manual prompt and valid weights remain authoritative in both dialects', async () => {
    for (const format of ['nai45-tags', 'nai5-natural']) {
        const f = await setup(), manual = '{{silver hair}}, 用户保留的描述';
        const meta = { ...metadata(format), flatPrompt: manual, flatPromptOverride: true };
        const preview = f.get('generation/baibaiImage').baiBaiSendPreview('scene', { promptMetadata: meta, context: f.host });
        assert.equal(preview.prompt, manual); assert.equal(preview.nl, ''); assert.equal(preview.characters, undefined);
    }
});

test('NAI 5 keeps the full natural main scene and NAI native character separation', async () => {
    const scene = '小雪坐在窗边，手捧茶杯，看向落雪的庭院。';
    for (const native of [false, true]) {
        const f = await setup({ native }), meta = metadata('nai5-natural');
        await f.get('generation/cgImageCore').invokeImageGeneration(scene, f.host, { promptMetadata: meta });
        const sent = f.requests[0]; assert.ok(sent.prompt.startsWith(scene));
        if (native) { assert.equal(sent.prompt, scene); assert.equal(sent.nl, ''); assert.equal(sent.characters[0].tag, '{{silver hair}}, blue eyes'); }
        else assert.ok(sent.prompt.includes('{{silver hair}}, blue eyes'));
    }
});

test('multi-person flat fallback preserves existing positions and both complete literal appearances without inventing positions', async () => {
    const f = await setup({ preset: false });
    const scene = '2people, first person behind second person, holding an umbrella';
    const meta = { promptFormat: 'nai45-tags', characters: [{ role: 'char', name: '小林', tag: 'red hair', resolvedAppearance: true },
        { role: 'user', name: '小雪', tag: '{{silver hair}}, ' + 'fine detail, '.repeat(60) + 'blue eyes', resolvedAppearance: true }] };
    const preview = f.get('generation/baibaiImage').baiBaiSendPreview(scene, { promptMetadata: meta, context: f.host });
    assert.ok(preview.prompt.startsWith(scene)); assert.ok(preview.prompt.endsWith('blue eyes'));
    assert.match(preview.prompt, /red hair/); assert.match(preview.prompt, /\{\{silver hair\}\}/);
    assert.doesNotMatch(preview.prompt, /人物外貌|小林|小雪|left|right/);
});

test('complete flat prompts retain NAI emphasis through the public image boundary without expanding dynamic macros', async () => {
    const f = await setup({ preset: false });
    const prompt = '{{silver hair}}, {{{blue eyes}}}, {{getvar::secret}}, sitting by a window';
    await f.get('generation/cgImageCore').invokeImageGeneration(prompt, f.host, { preservePrompt: true, singlePrompt: true });
    assert.equal(f.requests.length, 1);
    assert.match(f.requests[0].prompt, /\{\{silver hair\}\}/);
    assert.match(f.requests[0].prompt, /\{\{\{blue eyes\}\}\}/);
    assert.doesNotMatch(f.requests[0].prompt, /getvar|secret/);
});

test('avatar dialect parts reach real bundle image and BaiBai boundaries with both weighted identities intact', async () => {
    for (const format of ['nai45-tags', 'nai5-natural']) for (const native of [false, true]) {
        const f = await setup({ native, preset: false });
        const parts = f.get('extras/coupleAvatar').couplePromptParts({ promptFormat: format,
            styleId: 'art-gongbi', interaction: '递出一朵花', people: [
                { name: '甲', appearance: '{{silver hair}}, blue eyes' },
                { name: '乙', appearance: '{{{red hair}}}, green eyes' },
            ] }, null);
        assert.equal(parts.promptFormat, format);
        await f.get('generation/cgImageCore').invokeImageGeneration(parts.prompt, f.host, {
            preservePrompt: true, singlePrompt: true,
            avatarPromptParts: { scene: parts.scene, characters: parts.characters, negative: parts.negative,
                nai: parts.nai, promptFormat: parts.promptFormat },
        });
        assert.equal(f.requests.length, 1); const sent = f.requests[0];
        if (native) {
            assert.match(sent.characters[0].tag, /\{\{silver hair\}\}/);
            assert.match(sent.characters[1].tag, /\{\{\{red hair\}\}\}/);
            assert.doesNotMatch(sent.characters[0].tag, /red hair/);
            assert.doesNotMatch(sent.characters[1].tag, /silver hair/);
            if (format === 'nai45-tags') assert.equal(sent.nl, '');
            else assert.match(sent.nl, /One continuous horizontal paired portrait/);
        } else {
            assert.match(sent.prompt, /\{\{silver hair\}\}/);
            assert.match(sent.prompt, /\{\{\{red hair\}\}\}/);
            if (format === 'nai45-tags') assert.doesNotMatch(sent.prompt, /人物外貌|Rendering style:|LEFT HALF/);
            else assert.match(sent.prompt, /Rendering style:/);
        }
    }
});

test('automatic flat appearance retains explicit named scene bindings independently of character array order', async () => {
    const f = await setup({ preset: false });
    const meta = { promptFormat: 'nai45-tags', characters: [
        { role: 'char', name: 'Beth', tag: 'red hair', resolvedAppearance: true },
        { role: 'user', name: 'Alex', tag: 'blue hair', resolvedAppearance: true },
    ] };
    const scene = 'Alex on the left, Beth on the right';
    const preview = f.get('generation/baibaiImage').baiBaiSendPreview(scene, { promptMetadata: meta, context: f.host });
    assert.ok(preview.prompt.startsWith(scene));
    assert.match(preview.prompt, /Beth: red hair/); assert.match(preview.prompt, /Alex: blue hair/);
    assert.doesNotMatch(preview.prompt, /人物外貌/);
});

test('metadata scene and local manual appearance preserve literal weights in either dialect', async () => {
    for (const format of ['nai45-tags', 'nai5-natural']) {
        const f = await setup({ preset: false });
        const scene = '{{moon}}, lake, {{getvar::secret}}';
        const meta = { promptFormat: format, sceneTags: scene, selectedRoles: ['user'],
            characters: [{ role: 'user', name: '小雪', tag: '{{silver hair}}, {{{blue eyes}}}' }] };
        await f.get('generation/cgImageCore').invokeImageGeneration(scene, f.host, { promptMetadata: meta });
        const prompt = f.requests[0].prompt;
        assert.match(prompt, /\{\{moon\}\}/); assert.match(prompt, /\{\{silver hair\}\}/);
        assert.match(prompt, /\{\{\{blue eyes\}\}\}/); assert.doesNotMatch(prompt, /getvar|secret/);
    }
});

test('flat identity labels require an existing unambiguous full name, while literal Chinese scene names remain bound', async () => {
    const f = await setup({ preset: false }), api = f.get('generation/cgAppearance');
    const make = (scene, names) => api.cgPreparedTagPrompt(scene, { promptFormat: 'nai45-tags', characters: [
        { role: 'char', name: names[0], tag: 'red hair' }, { role: 'user', name: names[1], tag: 'blue hair' },
    ] });
    assert.doesNotMatch(make('Bethany standing in a garden', ['Ann', 'Beth']), /Ann:|Beth:/);
    assert.doesNotMatch(make('Alex on the left', ['Alex', 'alex']), /Alex:|alex:/);
    assert.doesNotMatch(make('Joséphine at the window', ['José', 'Beth']), /José:/);
    assert.doesNotMatch(make('安娜坐在窗边', ['安', '安娜']), /安: red hair/);
    assert.match(make('安娜坐在窗边', ['安', '安娜']), /安娜: blue hair/);
    assert.match(make('小雪坐在窗边，小林站在门口', ['小林', '小雪']), /小林: red hair, 小雪: blue hair/);
});

test('Chatu8 flat transport shares named binding assembly and keeps the same preview plus per-preset negatives', async () => {
    const f = await fixture(), requests = [], source = new EventEmitter();
    f.host.name2 = 'Beth'; f.host.name1 = 'Alex'; f.host.eventSource = source;
    f.host.extensionSettings['st-chatu8'] = { scriptEnabled: true, mode: 'novelai',
        novelaimode: 'nai-diffusion-4-5-full', AI_use_coords: false,
        characterPresets: { beth: { nameEN: 'Beth', characterTraits: '{{red hair}}', negative: 'avoid_beth' },
            alex: { nameEN: 'Alex', characterTraits: '{{blue hair}}', negative: 'avoid_alex' } } };
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS,
        imageGenerationProvider: 'chatu8-image', imageGenerationFallback: false });
    source.on('generate-image-request', request => { requests.push(request);
        source.emit('generate-image-response', { id: request.id, success: true, imageData: '/user/images/dialect.png' }); });
    const scene = 'Alex on the left, Beth on the right';
    const meta = { promptFormat: 'nai45-tags', characters: [
        { role: 'char', name: 'Beth', tag: 'local brown hair' }, { role: 'user', name: 'Alex', tag: 'local black hair' },
    ] };
    const preview = f.get('generation/chatu8Image').chatu8SendPreview(scene, { promptMetadata: meta, context: f.host });
    await f.get('generation/cgImageCore').invokeImageGeneration(scene, f.host, { promptMetadata: meta });
    assert.equal(requests.length, 1); assert.equal(requests[0].prompt, preview.prompt);
    assert.match(requests[0].prompt, /Beth: \{\{red hair\}\}/);
    assert.match(requests[0].prompt, /Alex: \{\{blue hair\}\}/);
    assert.equal(requests[0].negative_prompt, preview.negative_prompt);
    assert.match(requests[0].negative_prompt, /avoid_beth/); assert.match(requests[0].negative_prompt, /avoid_alex/);
});
