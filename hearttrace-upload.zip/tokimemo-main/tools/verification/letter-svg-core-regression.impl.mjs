import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const domModule = process.env.LETTER_SVG_DOM_MODULE || '@xmldom/xmldom';
const { DOMParser } = require(domModule);
globalThis.DOMParser = DOMParser;
const root = path.resolve(process.env.TEST_ROOT || '.');
const source = fs.readFileSync(path.join(root, 'src/core/letterIllustrationV3.js'), 'utf8');
const art = await import(`data:text/javascript;base64,${Buffer.from(source).toString('base64')}`);
const svg = body => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="-20 -10 480 220">${body}</svg>`;
const parse = value => new DOMParser().parseFromString(value, 'image/svg+xml');
const all = (doc, name) => [...doc.getElementsByTagName(name)];

test('new art accepts free scene geometry, colours, aspect ratio and missing metadata', () => {
    const pathData = 'M-12 16 Q64 -9 123 51 C148 82 201 130 333 69';
    const design = art.normalize({ svg: svg(`<path d="${pathData}" fill="none" stroke="#ab2345" stroke-width="2.8"/>`) });
    assert.equal(design.version, 3);
    assert.equal(design.characterName, '');
    assert.equal(design.summary, '');
    const document = parse(design.svg);
    assert.equal(document.documentElement.getAttribute('viewBox'), '-20 -10 480 220');
    assert.equal(all(document, 'path')[0].getAttribute('d'), pathData);
    assert.equal(all(document, 'path')[0].getAttribute('stroke'), '#ab2345');
});

test('model-selected different action geometry survives without template replacement', () => {
    const sitting = art.normalize({ characterName: '方祁洛', summary: '坐在台阶上低头编绳', svg: svg('<path d="M30 20Q45 70 90 80L140 110"/>') });
    const running = art.normalize({ characterName: '方祁洛', summary: '侧身跑过长廊，衣袖扬起', svg: svg('<path d="M90 10L40 65 130 100 180 90"/>') });
    assert.notEqual(sitting.svg, running.svg);
    assert.equal(sitting.summary, '坐在台阶上低头编绳');
    assert.equal(running.summary, '侧身跑过长廊，衣袖扬起');
});

test('gradients, clips, masks, local reuse, filters and text remain drawable', () => {
    const design = art.normalize({ svg: svg(`<defs>
      <linearGradient id="coat"><stop offset="0" stop-color="#d33"/><stop offset="1" stop-color="#312"/></linearGradient>
      <clipPath id="frame"><rect x="0" y="0" width="300" height="200" rx="12"/></clipPath>
      <mask id="shade"><rect width="300" height="200" fill="white"/></mask>
      <filter id="soft"><feGaussianBlur stdDeviation="1.5"/></filter>
      <path id="ribbon" d="M0 0Q30 45 70 0"/>
    </defs><g clip-path="url(#frame)" mask="url('#shade')"><path d="M0 0h200v200H0Z" fill="url(#coat)" filter="url(#soft)"/><use href="#ribbon" x="30" y="50"/><text x="100" y="120" text-anchor="middle">给你的红绳<tspan dy="20">今天也想你</tspan></text></g>`) });
    const document = parse(design.svg);
    assert.equal(all(document, 'linearGradient').length, 1);
    assert.equal(all(document, 'clipPath').length, 1);
    assert.equal(all(document, 'mask').length, 1);
    assert.equal(all(document, 'feGaussianBlur')[0].getAttribute('stdDeviation'), '1.5');
    assert.equal(all(document, 'use')[0].getAttribute('href'), '#ribbon');
    assert.match(all(document, 'text')[0].textContent, /今天也想你/u);
});

test('strips active content, events and external resources but keeps useful geometry', () => {
    const unsafe = svg(`<script>alert('run')</script><foreignObject><div xmlns="http://www.w3.org/1999/xhtml">bad</div></foreignObject>
      <image href="https://example.invalid/leak"/><feImage href="https://example.invalid/filter"/>
      <animate attributeName="href" values="javascript:alert(1)"/>
      <a href="https://example.invalid/link"><circle cx="12" cy="13" r="8" onload="alert(1)"/></a>
      <path d="M0 0h10" style="fill:url(https://example.invalid/paint);stroke:red" onclick="alert(1)"/>
      <use href="//example.invalid/external#shape"/><use href="javascript:alert(1)"/>`);
    const clean = art.normalize({ svg: unsafe }).svg;
    assert.doesNotMatch(clean, /<(?:script|foreignObject|image|feImage|animate|a)\b|\bon\w+=|example\.invalid|javascript:/iu);
    const document = parse(clean);
    assert.equal(all(document, 'circle').length, 1);
    assert.equal(all(document, 'path')[0].getAttribute('style'), 'stroke:red');
    assert.ok(all(document, 'use').every(node => !node.hasAttribute('href')));
});

test('keeps safe stylesheet and inline colour/geometry declarations; strips CSS network paths', () => {
    const design = art.normalize({ svg: svg(`<style>.hair{fill:#232129;stroke:#111}.coat{fill:url(#ink);opacity:.8}.bad{fill:url(https://example.invalid/p);background:url(https://example.invalid/bg)}@font-face{font-family:bad;src:url(https://example.invalid/font)}</style>
      <defs><linearGradient id="ink"><stop stop-color="#a33"/></linearGradient></defs>
      <path class="hair" d="M3 8q20 30 40 0"/>
      <path class="coat" d="M10 80h40" style="stroke:rgb(1, 2, 3);stroke-width:2;transform:rotate(12deg);background-image:url(https://example.invalid/bg)"/>`) });
    assert.match(design.svg, /\.hair\{fill:#232129;stroke:#111\}/u);
    assert.match(design.svg, /\.coat\{fill:url\(#ink\);opacity:\.8\}/u);
    assert.match(design.svg, /stroke:rgb\(1, 2, 3\);stroke-width:2;transform:rotate\(12deg\)/u);
    assert.doesNotMatch(design.svg, /example\.invalid|@font-face|background/iu);
});

test('CSS escapes, comments and encoded URL schemes do not preserve external requests', () => {
    const design = art.normalize({ svg: svg(`<path d="M0 0h20" fill="url(&quot;https://example.invalid/a&quot;)" stroke="url(  '//example.invalid/b' )" style="fill:u\\72l(https://example.invalid/c);stroke:u/**/rl(https://example.invalid/d);color:red"/>`) });
    assert.ok(design);
    assert.doesNotMatch(design.svg, /example\.invalid|u\\72|\/\*\*/u);
    assert.match(design.svg, /style="color:red"/u);
});

test('local xlink references survive once and normalized art remains valid/idempotent', () => {
    const raw = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 10 20"><defs><path id="p" d="M0 0h5"/></defs><use href="#p" xlink:href="#p"/></svg>';
    const first = art.normalize({ svg: raw });
    const next = art.normalize(first);
    assert.equal(next.svg, first.svg);
    const use = all(parse(next.svg), 'use')[0];
    assert.equal(use.getAttribute('href'), '#p');
    assert.equal(use.getAttributeNS('http://www.w3.org/1999/xlink', 'href'), '#p');
});

test('fenced SVG without xmlns or viewBox gains a usable canvas without changing geometry', () => {
    const design = art.normalize({ svg: '```svg\n<svg width="640px" height="200"><path d="M20 30h50"/></svg>\n```' });
    const root = parse(design.svg).documentElement;
    assert.equal(root.getAttribute('viewBox'), '0 0 640 200');
    assert.equal(root.namespaceURI, 'http://www.w3.org/2000/svg');
    assert.equal(all(root.ownerDocument, 'path')[0].getAttribute('d'), 'M20 30h50');
});

test('does not impose new illustration size or node-count gates', () => {
    const parts = Array.from({ length: 2500 }, (_, i) => `<path d="M${i} 0l2 5" stroke="#123456"/>`).join('');
    const design = art.normalize({ svg: svg(parts) });
    assert.ok(design.svg.length > 100000);
    assert.equal(all(parse(design.svg), 'path').length, 2500);
});

test('invalid input, hostile accessors and unavailable DOM never throw', () => {
    for (const input of [null, undefined, [], {}, { svg: '' }, { svg: 'not a drawing' }, { svg: '<!DOCTYPE svg [<!ENTITY x "x">]><svg><text>&x;</text></svg>' }, { svg: '<svg xmlns="urn:wrong"><path d="M0 0h10"/></svg>' }]) {
        assert.equal(art.normalize(input), null);
    }
    assert.equal(art.normalize(Object.defineProperty({}, 'svg', { get() { throw Error('do not invoke'); } })), null);
    const parser = globalThis.DOMParser;
    try { delete globalThis.DOMParser; assert.equal(art.normalize({ svg: svg('<path d="M0 0h10"/>') }), null); }
    finally { globalThis.DOMParser = parser; }
});

test('render uses an inert image document, escaped label and no host-visible SVG IDs', () => {
    const input = { svg: svg('<defs><linearGradient id="shared"><stop stop-color="red"/></linearGradient></defs><path d="M0 0h10" fill="url(#shared)"/>') };
    const html = art.render(input, { idPrefix: 'same', label: '"><img src=x onerror=alert(1)>' });
    assert.match(html, /^<img class="rmt-letter-illustration" data-rmt-letter-illustration-version="3" /u);
    assert.equal((html.match(/<img/g) || []).length, 1);
    assert.doesNotMatch(html, /<svg|\sid="shared"/u);
    assert.equal(parse(html.replace(/>$/u, '/>')).documentElement.hasAttribute('onerror'), false);
    assert.match(html, /alt="&quot;&gt;&lt;img src=x onerror=alert\(1\)&gt;"/u);
    const embedded = decodeURIComponent(html.match(/src="data:image\/svg\+xml;charset=utf-8,([^"]+)"/u)[1].replace(/&#39;/gu, "'"));
    assert.equal(embedded, art.svgSource(input));
});

test('empty/unsafe-only art can fall back independently of successful letter prose', () => {
    assert.equal(art.normalize({ svg: svg('<script>alert(1)</script><image href="https://example.invalid/a"/>') }), null);
    assert.equal(art.render({ svg: 'invalid' }), '');
    assert.equal(art.svgSource({ svg: 'invalid' }), '');
});
