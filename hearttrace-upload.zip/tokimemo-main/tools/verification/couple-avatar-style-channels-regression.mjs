import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';

// 柏宝绘 always prepends the user's selected artist string; this page has no
// stacking mode. Style words are written in full, once, for every style.
const people = [{ id: 'char', name: 'Left', appearance: '1boy, black long hair, golden eyes' },
    { id: 'user', name: 'Right', appearance: '1girl, short silver hair, blue eyes' }];
const plain = value => JSON.parse(JSON.stringify(value));
const count = (text, needle) => text.split(needle).length - 1;

async function setup() {
    const f = await fixture();
    return { ...f, core: f.get('extras/coupleAvatar'), styles: f.get('extras/coupleAvatarStyles') };
}


test('a stored overlayArtist flag from an older build is ignored and changes nothing', async () => {
    const f = await setup();
    assert.equal(Object.hasOwn(f.core.normalizeCoupleSettings({ people, overlayArtist: true }, null), 'overlayArtist'), false);
    for (const id of ['chibi-dumpling', 'anime-flat', 'mood-golden', 'layout-closeup', 'render-toon', 'custom'])
        for (const promptFormat of ['', 'nai5-natural', 'nai45-tags']) {
            const base = { people, styleId: id, customStyle: 'two-head-tall chibi', promptFormat };
            assert.deepEqual(plain(f.core.couplePromptParts({ ...base, overlayArtist: true }, null)), plain(f.core.couplePromptParts(base, null)), `${id} ${promptFormat}`);
        }
    assert.equal(f.styles.coupleStyleBlend, undefined);
    assert.equal(f.styles.coupleOverlayAvailable, undefined);
});

test('Q-version keeps chibi proportions against long realistic appearances (height, build)', async () => {
    const f = await setup();
    const tall = [{ name: 'Left', appearance: 'An 18-year-old male with a height of 183 cm, well-defined bone structure, black high ponytail.' },
        { name: 'Right', appearance: '1girl, 166 cm tall, slender build, slim waist, long straight black hair.' }];
    for (const promptFormat of ['', 'nai5-natural']) {
        const parts = f.core.couplePromptParts({ people: tall, styleId: 'chibi-kemono', promptFormat }, null);
        for (const row of parts.nai.characters) {
            assert.match(row.tag, /chibi/, 'each actor channel carries the proportions');
            assert.match(row.nl, /height, build or adult body-proportion details .* become the selected chibi proportions/);
        }
    }
    const tags = f.core.couplePromptParts({ people: tall, styleId: 'chibi-dumpling', promptFormat: 'nai45-tags' }, null);
    assert.ok(tags.characters.every(row => /chibi, two-head-tall proportions, oversized head/.test(row.tag)));
    const mood = f.core.couplePromptParts({ people: tall, styleId: 'mood-golden' }, null);
    assert.ok(mood.nai.characters.every(row => !/chibi/.test(row.tag)));
});

test('new interactions and random ideas have their own English tag recipes in 4.5', async () => {
    const f = await setup();
    for (const preset of f.styles.INTERACTION_PRESETS) {
        const parts = f.core.couplePromptParts({ people, interaction: preset.label, promptFormat: 'nai45-tags' }, null);
        for (const value of [parts.scene, ...parts.characters.map(row => row.tag)]) assert.doesNotMatch(value, /[^\x20-\x7e\r\n]/u, preset.label);
    }
    let previous = [];
    for (let i = 0; i < 40; i++) {
        const ideas = f.styles.randomCoupleIdeas(previous);
        for (const idea of ideas) {
            const parts = f.core.couplePromptParts({ people, interaction: '自定义互动', interactionDetail: idea, promptFormat: 'nai45-tags' }, null);
            for (const value of [parts.scene, ...parts.characters.map(row => row.tag)]) assert.doesNotMatch(value, /[^\x20-\x7e\r\n]/u, idea);
            const prose = f.core.couplePromptParts({ people, interaction: '自定义互动', interactionDetail: idea }, null);
            assert.doesNotMatch(prose.prompt, /follow the LEFT subject/, idea);
        }
        previous = ideas;
    }
});

test('full-figure layouts get full-figure framing; portrait layouts do not', async () => {
    const f = await setup();
    for (const id of ['layout-fullbody', 'layout-sitting', 'layout-lying', 'layout-dynamic']) {
        assert.match(f.core.couplePromptParts({ people, styleId: id }, null).nai.nl, /complete stylized figure fills most/, id);
    }
    for (const id of ['layout-closeup', 'layout-bust', 'mood-moon']) {
        assert.match(f.core.couplePromptParts({ people, styleId: id }, null).nai.nl, /Close head-and-shoulder/, id);
    }
});

test('styles are weighted in the NAI channels and 3D media lead with 3d tags so the artist string does not override them', async () => {
    const f = await setup();
    for (const id of ['render-toon', 'render-game', 'render-cel3d']) {
        const lead = f.styles.NAI_MEDIUM_LEAD[id];
        const nl = f.core.couplePromptParts({ people, styleId: id, promptFormat: 'nai5-natural' }, null);
        assert.ok(nl.nai.prompt.startsWith(lead), id);
        assert.ok(nl.nai.characters.every(row => row.tag.includes(', 3d, ')), id);
        const tags = f.core.couplePromptParts({ people, styleId: id, promptFormat: 'nai45-tags' }, null);
        assert.ok(tags.nai.prompt.startsWith(lead), id);
        assert.ok(tags.characters.every(row => /, 3d, /.test(row.tag)), id);
        // Weight syntax is NAI-only: the flat provider prompt stays plain.
        assert.doesNotMatch(f.core.couplePromptParts({ people, styleId: id }, null).prompt, /::/, id);
    }
    // Every style is weighted in the NAI channel; only 3D adds the medium lead.
    const anime = f.core.couplePromptParts({ people, styleId: 'anime-clean', promptFormat: 'nai5-natural' }, null);
    assert.ok(anime.nai.prompt.startsWith(`${f.styles.NAI_STYLE_WEIGHT}::${f.styles.COUPLE_STYLES.find(row => row.id === 'anime-clean').prompt}::`));
    assert.doesNotMatch(anime.prompt, /::/);
    const tags = f.core.couplePromptParts({ people, styleId: 'anime-clean', promptFormat: 'nai45-tags' }, null);
    assert.match(tags.nai.prompt, /^1\.3::[^:]+::, /); assert.doesNotMatch(tags.prompt + tags.scene, /::/);
    // Custom text that already carries its own weights is left alone.
    assert.ok(f.core.couplePromptParts({ people, styleId: 'custom', customStyle: '1.2::watercolor::, soft', promptFormat: 'nai5-natural' }, null).nai.prompt.startsWith('1.2::watercolor::, soft, '));
    assert.ok(f.core.couplePromptParts({ people, styleId: 'custom', customStyle: 'watercolor', promptFormat: 'nai5-natural' }, null).nai.prompt.startsWith('1.3::watercolor::, '));
});
