import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { fixture } from './fixture.mjs';

// Exercise the complete production module graph. Only the external provider API
// and event bus are fixtures; image normalization and persistence are never stubbed.
async function setup(provider, href = 'tauri://localhost/') {
    const f = await fixture();
    f.sb.location = { href, protocol: new URL(href).protocol, origin: new URL(href).origin };
    f.host.chatMetadata = {};
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS,
        imageGenerationProvider: provider, imageGenerationFallback: false });
    const requests = [], source = new EventEmitter();
    if (provider === 'baibai-image') {
        f.sb.STBaiBaiImage = { apiVersion: 1, capabilities: { generate: true, saveToGallery: true },
            getBackendStatus: () => ({ configured: true, backend: 'nai', supportsCharacters: true }),
            generate: (request, options) => new Promise((resolve, reject) => {
                requests.push({ request, options, resolve: path => resolve({ path }), reject });
                options.onProgress?.({ phase: 'generating' });
            }) };
    } else {
        f.host.eventSource = source;
        f.host.extensionSettings['st-chatu8'] = { scriptEnabled: true, mode: 'comfyui' };
        source.on('generate-image-request', request => requests.push({ request,
            resolve: imageData => source.emit('generate-image-response', { id: request.id, success: true, imageData }),
            reject: () => source.emit('generate-image-response', { id: request.id, success: false }) }));
    }
    const core = f.get('extras/coupleAvatar'), report = () => f.get('core/diagnosticReport').buildDiagnosticReport();
    const settings = core.defaultCoupleSettings(f.host);
    settings.direction = 'PRIVATE_DIRECTION_MARKER';
    return { ...f, core, settings, requests, report,
        start: options => core.generateCouple(settings, { context: f.host, ...options }) };
}

for (const provider of ['baibai-image', 'chatu8-image']) {
    for (const href of ['https://host.example/', 'tauri://localhost/']) {
        for (const absolute of [false, true]) {
            test(`${provider}: ${href} ${absolute ? 'absolute' : 'relative'} result enters history once`, async () => {
                const f = await setup(provider, href), progress = [], scope = f.core.coupleScope(f.host);
                const existing = await f.core.addCouple(scope, { original: 'data:image/png;base64,b2xk', settings: f.settings });
                await f.core.updateCouple(scope, existing.record.id, { favorite: true, order: [1, 0], crops: [{ zoom: 2, x: 30, y: -10 }] });
                const before = JSON.stringify((await f.core.readCouples(scope)).records[0]);
                const job = f.start({ onProgress: p => progress.push(p.phase) });
                assert.equal(f.requests.length, 1);
                assert.equal(f.report().runtime.coupleAvatarTasks, 1);
                assert.equal(f.report().runtime.hasPendingWork, true);
                const local = '/user/images/pair-success.png';
                f.requests[0].resolve(absolute ? new URL(local, href).href : local);
                const saved = await job;
                assert.equal(saved.record.original.url, local);
                assert.equal(saved.scope, scope);
                assert.equal(f.requests.length, 1);
                const state = await f.core.readCouples(scope);
                assert.equal(state.records.length, 2);
                assert.equal(JSON.stringify(state.records.find(r => r.id === existing.record.id)), before);
                // Node fixture deliberately lacks IDB. The returned image stays
                // available for export/retry instead of disappearing on write failure.
                assert.equal(saved.durable, false);
                assert.ok(state.pendingIds.includes(saved.record.id));
                assert.ok(JSON.parse(await f.core.exportCouples(scope)).records.some(r => r.id === saved.record.id));
                const report = f.report(), trace = report.recentTasks.at(-1);
                assert.equal(report.runtime.coupleAvatarTasks, 0);
                assert.equal(report.runtime.hasPendingWork, false);
                assert.equal(trace.mode, 'coupleAvatar');
                assert.equal(trace.outcome, 'deferred');
                assert.equal(trace.code, 'RMT_COUPLE_STORAGE');
                assert.ok(['request', 'response', 'validate', 'save', 'deferred'].every(stage => trace.stages.some(s => s.startsWith(stage + '@') || s.startsWith(stage + '!@'))));
                assert.ok(progress.includes('saving'));
                assert.doesNotMatch(JSON.stringify(trace), /PRIVATE_DIRECTION_MARKER|pair-success|user\/images/);
            });
        }
    }
    test(`${provider}: safe provider failure is traced, keeps old records and never resends`, async () => {
        const f = await setup(provider), scope = f.core.coupleScope(f.host);
        await f.core.addCouple(scope, { original: '/user/images/old.png', settings: f.settings });
        const before = JSON.stringify((await f.core.readCouples(scope)).records);
        const job = f.start();
        f.requests[0].reject(Object.assign(new Error('PRIVATE_PROVIDER_MESSAGE'), { code: 'backend_error' }));
        const code = provider === 'baibai-image' ? 'BBI_BACKEND_ERROR' : 'CH8_BACKEND_ERROR';
        await assert.rejects(job, error => error.code === code && !error.message.includes('PRIVATE_PROVIDER_MESSAGE'));
        assert.equal(JSON.stringify((await f.core.readCouples(scope)).records), before);
        assert.equal(f.requests.length, 1);
        const report = f.report(), trace = report.recentTasks.at(-1);
        assert.equal(report.runtime.coupleAvatarTasks, 0);
        assert.equal(report.runtime.hasPendingWork, false);
        assert.equal(trace.code, code);
        assert.equal(trace.outcome, 'failed');
        assert.ok(trace.stages.some(s => s.startsWith('request!@')));
        assert.doesNotMatch(JSON.stringify(trace), /PRIVATE_|old\.png/);
    });
    test(`${provider}: four TT requests complete out of order and background result stays in original chat`, async () => {
        const f = await setup(provider), origin = f.core.coupleScope(f.host), controller = new AbortController();
        const tasks = [f.start({ signal: controller.signal }), f.start(), f.start(), f.start()];
        assert.equal(f.requests.length, 4);
        assert.equal(f.report().runtime.coupleAvatarTasks, 4);
        controller.abort();
        f.host.chatId = 'OTHER';
        f.requests.toReversed().forEach((request, i) => request.resolve('/user/images/concurrent-' + i + '.png'));
        const results = await Promise.all(tasks);
        assert.equal(results[0].cancelled, true);
        assert.equal(f.requests.length, 4);
        assert.equal((await f.core.readCouples(origin)).records.length, 4);
        assert.equal((await f.core.readCouples(f.core.coupleScope(f.host))).records.length, 0);
        assert.equal(f.report().runtime.coupleAvatarTasks, 0);
    });
}

test('TT local/imported originals and backups keep their pixels, crops and favorite state', async () => {
    const f = await setup('baibai-image'), scope = f.core.coupleScope(f.host);
    const urls = ['/user/images/local.png', 'tauri://localhost/user/images/absolute.png', 'https://image.example/pair.png', 'data:image/png;base64,YWJj', 'blob:tauri://localhost/image'];
    for (const url of urls) {
        const result = await f.core.addCouple(scope, { original: { url, width: 1800, height: 1200 }, settings: f.settings });
        await f.core.updateCouple(scope, result.record.id, { favorite: true, order: [1, 0], crops: [{ zoom: 1.5, x: 90, y: 20 }] });
    }
    const backup = await f.core.exportCouples(scope), imported = await f.core.importCouples('RESTORED', backup);
    assert.equal(imported.records.length, urls.length);
    for (const record of imported.records) {
        assert.ok(urls.includes(record.original.url));
        assert.equal(record.original.width, 1800);
        assert.equal(record.original.height, 1200);
        assert.equal(record.favorite, true);
        assert.equal(record.order.join(), '1,0');
        assert.equal(record.crops[0].zoom, 1.5);
    }
    const before = (await f.core.readCouples(scope)).records.length;
    for (const url of ['tauri://other/user/images/no.png', 'file:///image.png', 'javascript:alert(1)', 'data:text/html,unsafe']) {
        await assert.rejects(f.core.addCouple(scope, { original: url }), { code: 'RMT_COUPLE_IMAGE' });
    }
    assert.equal((await f.core.readCouples(scope)).records.length, before);
    assert.equal(f.requests.length, 0);
});

test('Chatu8 data image upload accepts TT absolute saved path without another generation', async () => {
    const f = await setup('chatu8-image'), uploads = [];
    f.sb.fetch = async (url, options) => {
        uploads.push({ url, options });
        return new Response(JSON.stringify({ path: 'tauri://localhost/user/images/uploaded.png' }), { status: 200 });
    };
    const job = f.start();
    f.requests[0].resolve('data:image/png;base64,dGVzdA==');
    const saved = await job;
    assert.equal(saved.record.original.url, '/user/images/uploaded.png');
    assert.equal(f.requests.length, 1);
    assert.equal(uploads.length, 1);
    assert.equal(uploads[0].url, '/api/images/upload');
    assert.equal(f.report().runtime.coupleAvatarTasks, 0);
});

test('Chatu8 rejects foreign TT results without saving or resending', async () => {
    const f = await setup('chatu8-image'), scope = f.core.coupleScope(f.host);
    const job = f.start();
    f.requests[0].resolve('tauri://foreign/user/images/foreign.png');
    await assert.rejects(job, { code: 'CH8_BACKEND_ERROR' });
    assert.equal(f.requests.length, 1);
    assert.equal((await f.core.readCouples(scope)).records.length, 0);
    assert.equal(f.report().runtime.coupleAvatarTasks, 0);
});
