// Small synthetic recordings; these are not Suno or user device recordings.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

export function audioSourceFixtures() {
    const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'hearttrace-audio-'));
    const create = (name, sound, extra = []) => {
        const target = path.join(directory, name);
        const args = ['-hide_banner', '-loglevel', 'error', '-nostdin', '-y', '-f', 'lavfi', '-i', 'color=c=black:s=32x32:r=10:d=1'];
        if (sound) args.push('-f', 'lavfi', '-i', 'sine=frequency=440:sample_rate=44100:duration=1');
        args.push('-c:v', 'libx264', '-pix_fmt', 'yuv420p');
        if (sound) args.push('-c:a', 'aac', '-shortest'); else args.push('-an');
        execFileSync('ffmpeg', [...args, ...extra, target], { timeout: 10000 });
        const bytes = fs.readFileSync(target);
        const tracks = JSON.parse(execFileSync('ffprobe', ['-v', 'error', '-show_entries', 'stream=codec_type,codec_name', '-of', 'json', target], { encoding: 'utf8', timeout: 5000 })).streams;
        return { name, target, bytes, type: /\.mov$/.test(name) ? 'video/quicktime' : 'video/mp4', tracks };
    };
    try {
        const mp4 = create('有声录屏.mp4', true), mov = create('有声录屏.mov', true, ['-movflags', '+faststart']);
        const silent = create('无音轨录屏.mp4', false), fragmented = create('分片录屏.mp4', true, ['-movflags', '+frag_keyframe+empty_moov']);
        const emptyTrack = create('空音轨录屏.mp4', true, ['-af', 'atrim=end_sample=0', '-movflags', '+frag_keyframe+empty_moov']);
        const damaged = { ...mp4, name: '损坏录屏.mp4', bytes: mp4.bytes.subarray(0, Math.floor(mp4.bytes.length / 2)) };
        return { directory, mp4, mov, silent, fragmented, emptyTrack, damaged, cleanup: () => fs.rmSync(directory, { recursive: true, force: true }) };
    } catch (error) { fs.rmSync(directory, { recursive: true, force: true }); throw error; }
}
