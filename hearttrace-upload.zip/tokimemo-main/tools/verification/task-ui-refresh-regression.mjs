// Shipped bundle, synthetic host and DOM. These checks do not claim TT/device performance.
import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';

async function setup({ open = false } = {}) {
    const f = await fixture(), g = f.get;
    const node = () => ({ hidden: false, textContent: '', innerHTML: '', scrollTop: 73,
        attributes: {}, setAttribute(key, value) { this.attributes[key] = value; }, classList: { toggle() {} } });
    const panel = node(), badge = node(), strip = node(), button = node(); panel.hidden = !open;
    f.sb.document.querySelector = selector => selector.includes('data-rmt-task-center') ? panel
        : selector.includes('data-rmt-task-count') ? badge : selector.includes('data-rmt-live-tasks') ? strip
            : selector.includes('data-rmt-action="tasks"') ? button : null;
    f.sb.document.querySelectorAll = () => [];
    const reads = { drafts: 0, tasks: 0, pending: 0, unattributed: 0 };
    const rows = { drafts: [], tasks: [], pending: [], unattributed: [], pendingError: null };
    g('core/cache').listGenerationDrafts = () => { reads.drafts++; return rows.drafts; };
    g('core/requestCoordinator').listChatTaskSnapshot = () => { reads.tasks++; return rows.tasks; };
    g('ui/generationStatus').currentPendingRows = () => { reads.pending++; if (rows.pendingError) throw rows.pendingError; return rows.pending; };
    g('ui/generationStatus').currentUnattributedPendingRows = () => { reads.unattributed++; return rows.unattributed; };
    g('archive/repository').getCurrentArchiveImportRecoverySummary = () => null;
    g('archive/repository').getCurrentArchiveProfileRecoverySummary = () => null;
    const ui = g('ui/taskCenter');
    return { ...f, ui, panel, badge, strip, button, rows, reads,
        resetReads() { for (const key of Object.keys(reads)) reads[key] = 0; } };
}

const failedDraft = () => ({ draftId: 'draft-album', pageId: 'album', mode: 'album', createdAt: 1, updatedAt: 2,
    completed: 2, failed: 1, truncated: 0, failureCode: 'RMT_CONNECTION_FAILED', canRetry: true,
    journal: { operation: { kind: 'mode' } } });

for (const open of [false, true]) test(`one refresh shares recovery reads with task panel ${open ? 'open' : 'closed'}`, async () => {
    const f = await setup({ open }); f.rows.drafts = [failedDraft()];
    const before = JSON.stringify(f.rows);
    f.ui.syncTaskCenterChrome({ refreshRecovery: true });
    assert.deepEqual(f.reads, { drafts: 1, tasks: 1, pending: 1, unattributed: 1 });
    assert.equal(f.badge.textContent, '1'); assert.match(f.button.attributes['aria-label'], /1 项未完成/);
    assert.equal(JSON.stringify(f.rows), before, 'painting must not mutate saved rows');
    assert.equal(f.panel.scrollTop, 73);
    if (open) {
        assert.match(f.panel.innerHTML, /已保留 2 个成功分段/);
        assert.match(f.panel.innerHTML, /data-rmt-recovery-mode="album"/);
        assert.match(f.panel.innerHTML, /data-rmt-recovery-draft-id="draft-album"/);
        assert.match(f.panel.innerHTML, /重试未完成部分/);
    } else assert.equal(f.panel.innerHTML, '');
});

test('the next refresh immediately sees a newly saved failure and its later completion', async () => {
    const f = await setup(); f.ui.syncTaskCenterChrome(); assert.equal(f.badge.textContent, '0');
    f.rows.drafts = [failedDraft()]; f.resetReads(); f.ui.syncTaskCenterChrome();
    assert.equal(f.badge.textContent, '1'); assert.equal(f.badge.hidden, false); assert.equal(f.reads.drafts, 1);
    f.rows.drafts = []; f.resetReads(); f.ui.syncTaskCenterChrome();
    assert.equal(f.badge.textContent, '0'); assert.equal(f.badge.hidden, true); assert.equal(f.reads.drafts, 1);
});

test('request phase updates reuse one snapshot and keep cancellation visible', async () => {
    const f = await setup({ open: true });
    f.rows.tasks = [{ id: 'task-1', label: '回忆相簿', running: true, phase: 'request', phaseLabel: '请求中', progressText: '已收到 2 段' }];
    f.ui.syncTaskCenterChrome(); assert.match(f.panel.innerHTML, /data-rmt-action="task-cancel"/);
    f.resetReads(); f.get('core/requestCoordinator').noteChatTaskPhase('validate');
    assert.equal(f.reads.tasks, 1); assert.equal(f.reads.drafts, 1);
    f.rows.tasks = [{ id: 'task-1', label: '回忆相簿', running: false, phase: 'cancelled', outcome: 'cancelled', progressText: '已取消' }];
    f.ui.syncTaskCenterChrome();
    assert.match(f.panel.innerHTML, /data-state="cancelled"/);
    assert.equal(f.badge.textContent, '0'); assert.equal(f.strip.hidden, true);
});

test('one unreadable pending store is observed once and still exposes its existing export action', async () => {
    const f = await setup({ open: true }); f.rows.pendingError = new Error('unreadable');
    f.ui.syncTaskCenterChrome(); assert.equal(f.reads.pending, 1);
    assert.match(f.panel.innerHTML, /读取失败，旧数据保留/);
    assert.match(f.panel.innerHTML, /data-rmt-action="merged-export-legacy"/);
    f.rows.pendingError = null; f.ui.syncTaskCenterChrome();
    assert.doesNotMatch(f.panel.innerHTML, /读取失败，旧数据保留/);
});

test('standalone live strip refresh does not carry a prior refresh snapshot', async () => {
    const f = await setup(); f.ui.syncLiveTaskStrip(); assert.equal(f.strip.hidden, true);
    f.rows.drafts = [failedDraft()]; f.ui.syncLiveTaskStrip(); assert.equal(f.strip.hidden, false);
    f.rows.drafts = []; f.ui.syncLiveTaskStrip(); assert.equal(f.strip.hidden, true);
    assert.equal(f.reads.drafts, 3);
});
