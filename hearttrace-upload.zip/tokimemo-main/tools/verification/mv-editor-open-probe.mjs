// Read-only performance probe of the delivered bundle with real Canvas pixels.
// DOM, storage and audio are host doubles; this is not a device/browser benchmark.
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { performance } from 'node:perf_hooks';
const root = process.env.TEST_ROOT;
const { ui } = await import(pathToFileURL(`${root}/tools/verification/mv-ui-fixture.mjs`));
const { stageSetup } = await import(pathToFileURL(`${root}/tools/verification/mv-stage-fixture.mjs`));
const require = createRequire(import.meta.url);
const native = require(require.resolve('@napi-rs/canvas', { paths: [process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES] }));
const f = await ui(stageSetup), count = Number(process.argv[2] || 4), size = Number(process.argv[3] || 1024);
const page = process.argv[4] || 'default', decodes = [];
const metrics = { count, width: size, height: size * 1.5, page, renders: 0, decodes: 0, prepareCalls: 0, maxWorkingPixels: 0, prepareMs: 0, pngCalls: 0, paidCalls: 0 };
const prepare = f.get('extras/mvImageTools').prepareCharacterPixels;
f.get('extras/mvImageTools').prepareCharacterPixels = (...args) => {
    metrics.prepareCalls++; metrics.maxWorkingPixels = Math.max(metrics.maxWorkingPixels, args[1] * args[2]);
    const start = performance.now();
    try { return prepare(...args); } finally { metrics.prepareMs += performance.now() - start; }
};
let markup = '';
Object.defineProperty(f.body, 'innerHTML', { get: () => markup, set: value => { metrics.renders++; markup = value; } });
const preview = native.createCanvas(960, 540), create = f.sb.document.createElement;
f.sb.document.querySelector = selector => selector === '[data-rmt-mv-canvas]' && markup.includes('data-rmt-mv-canvas') ? preview : null;
f.sb.document.createElement = tag => {
    if (tag !== 'canvas') return create(tag);
    const c = native.createCanvas(8, 8), encode = c.toDataURL.bind(c);
    c.toDataURL = (...args) => { metrics.pngCalls++; return encode(...args); };
    return c;
};
f.sb.Image = class extends native.Image {
    set src(value) { metrics.decodes++; super.src = value; decodes.push(this.decode()); }
};
for (const [module, method] of [['generation/cgImageCore', 'invokeImageGeneration'], ['generation/client', 'requestJson']]) {
    f.get(module)[method] = async () => { metrics.paidCalls++; throw Error('Unexpected generation'); };
}
const group = f.record.groups[0], shot = f.record.shots[0];
f.record.groups = []; f.record.shots = [];
for (let i = 0; i < count; i++) {
    const c = native.createCanvas(size, size * 1.5), g = c.getContext('2d');
    g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height);
    g.fillStyle = `rgb(${35 + i},40,48)`; g.beginPath(); g.ellipse(size * .5, size * .24, size * .13, size * .18, 0, 0, Math.PI * 2); g.fill();
    g.fillRect(size * .34, size * .44, size * .32, size);
    const id = `G${i}`;
    f.record.groups.push({ ...group, id, diffs: [{ ...group.diffs[0], image: { url: c.toDataURL(), split: 'none' } }] });
    f.record.shots.push({ ...shot, id: `S${i}`, group: id });
}
const original = JSON.stringify(f.record), memory = process.memoryUsage().rss, start = performance.now();
f.mvui.openMv({ songId: f.song.id, ...(page === 'board' ? { page } : {}) });
metrics.synchronousOpenMs = Math.round(performance.now() - start);
for (let round = 0; round < 4; round++) {
    await Promise.all(decodes);
    await new Promise(resolve => setTimeout(resolve, 40));
}
metrics.settledMs = Math.round(performance.now() - start);
metrics.prepareMs = Math.round(metrics.prepareMs);
metrics.rssDeltaMiB = Math.round((process.memoryUsage().rss - memory) / 1048576);
metrics.dataPreserved = original === JSON.stringify(f.record);
metrics.editor = markup.includes('rmt-mv-editor');
console.log(JSON.stringify(metrics));
f.mvui.disposeMv();
