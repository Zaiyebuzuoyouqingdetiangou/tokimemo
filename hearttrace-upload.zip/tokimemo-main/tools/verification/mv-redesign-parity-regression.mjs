// Public bundle contracts against the delivered 1.0.27 baseline. This is not a
// browser hit-target/layout test: host, HTTP and media decoding are controlled.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';

const here = fileURLToPath(import.meta.url);
const candidate = path.resolve(process.env.TEST_ROOT || path.join(path.dirname(here), '../..'));
const baseline = path.resolve(process.env.BASELINE_ROOT || '/workspace/scratch/8e568532ca62/candidate-1.0.27/tokimemo-main');
const flush = async () => { for (let i = 0; i < 4; i++) await new Promise(resolve => setImmediate(resolve)); };

// Parse actual rendered HTML once per child, independently of production markup
// construction. Pagination numbers are display windows, not persisted limits.
function parseContracts(snapshots) {
    return JSON.parse(execFileSync('python3', ['-c', String.raw`
import json,sys,re
from lxml import html
out={"contracts":{},"enabled":{},"snapshots":[]}
for snap in json.load(sys.stdin):
    root=html.fragment_fromstring(snap['html'],create_parent='div')
    bucket=snap['bucket']; allc=out['contracts'].setdefault(bucket,set()); enabled=out['enabled'].setdefault(bucket,set())
    for node in root.iter():
        if not isinstance(node.tag,str): continue
        attrs=node.attrib; tokens=[]
        action=attrs.get('data-rmt-mv')
        if action is not None:
            ident=attrs.get('data-rmt-mv-id','')
            if action=='editor-strip': ident='<page>'
            elif action in ['retry-save','clear-pending'] and ident!='all': ident='<pending>'
            tokens.append('action:'+action+':'+ident)
        for key in ['data-edit','data-matte','data-import']:
            if key in attrs: tokens.append(key+':'+attrs[key])
        if node.tag in ['input','select','textarea']:
            identity='|'.join(sorted(k+'='+v for k,v in attrs.items() if k.startswith('data-') and k not in ['data-rmt-mv-id','data-shot']))
            if identity:
                tokens.append('field:'+node.tag+':'+identity)
                for accept in attrs.get('accept','').split(','):
                    if accept.strip(): tokens.append('accept:'+identity+':'+accept.strip())
                if node.tag=='select':
                    tokens.extend('option:'+identity+':'+option.get('value','') for option in node.xpath('.//option'))
        for token in tokens:
            allc.add(token)
            if 'disabled' not in attrs: enabled.add(token)
    out['snapshots'].append({'name':snap['name'],'bucket':bucket,
      'play':len(root.xpath('.//*[@data-rmt-mv="play"]')),
      'seek':len(root.xpath('.//*[@data-rmt-mv-seek]')),
      'music':len(root.xpath('.//*[@data-rmt-mv="editor-drawer" and @data-rmt-mv-id="audio"]')),
      'ids':[n.get('id') for n in root.xpath('.//*[@id]')],
      'enabledActionNames':sorted(set(n.get('data-rmt-mv') for n in root.xpath('.//*[@data-rmt-mv and not(@disabled)]'))),
      'shots':[n.get('data-rmt-mv-id') for n in root.xpath('.//*[@data-rmt-mv="select-shot"]')]})
out['contracts']={k:sorted(v) for k,v in out['contracts'].items()}
out['enabled']={k:sorted(v) for k,v in out['enabled'].items()}
print(json.dumps(out,ensure_ascii=False))
`], { input: JSON.stringify(snapshots), encoding: 'utf8', timeout: 2000, maxBuffer: 4 * 1024 * 1024 }));
}

function eventNode(extra = {}) {
    const listeners = new Map();
    return { listeners,
        addEventListener(type, fn) { const handlers = listeners.get(type) || new Set(); handlers.add(fn); listeners.set(type, handlers); },
        removeEventListener(type, fn) { listeners.get(type)?.delete(fn); },
        emit(type, event) { for (const fn of [...(listeners.get(type) || [])]) fn({ type, ...event }); },
        ...extra };
}

function checkDialog(f) {
    const module = f.get('ui/mvEditorDialog');
    const host = eventNode();
    const siblings = [{ inert: false }, { inert: true }, { inert: false }];
    const shell = { children: [...siblings], closest: selector => selector === 'dialog' ? host : null,
        appendChild(node) { this.children.push(node); node.parentElement = this; } };
    const shade = eventNode({ remove() { shell.children = shell.children.filter(node => node !== this); this.removed = true; } });
    const body = { querySelector: selector => selector === '.rmt-mve-sheet-shade' ? shade : null,
        closest: selector => selector === '.rmt-shell' ? shell : null };
    let dismissed = 0, stopped = 0;
    const panel = module.mountEditorDialog(body, () => { dismissed++; });
    assert.equal(panel?.element, shade);
    assert.deepEqual(siblings.map(node => node.inert), [true, true, true]);
    const e = { preventDefault() {}, stopPropagation() { stopped++; }, stopImmediatePropagation() { stopped++; } };
    shade.emit('click', { ...e, target: {} }); assert.equal(dismissed, 0, 'Clicking a panel control must not dismiss it');
    shade.emit('click', { ...e, target: shade }); assert.equal(dismissed, 1);
    shade.emit('keydown', { ...e, key: 'Enter' }); assert.equal(dismissed, 1);
    shade.emit('keydown', { ...e, key: 'Escape' }); assert.equal(dismissed, 2);
    host.emit('cancel', e); assert.equal(dismissed, 3);
    panel.dispose();
    assert.deepEqual(siblings.map(node => node.inert), [false, true, false], 'Restore each prior inert value, not a blanket false');
    assert.equal(shade.removed, true);
    shade.emit('keydown', { ...e, key: 'Escape' }); host.emit('cancel', e);
    assert.equal(dismissed, 3, 'Disposed listeners must not intercept later editor actions');
    assert.equal(stopped, 3);
    return true;
}

async function collect(root) {
    process.env.TEST_ROOT = root;
    const { ui, recorderHost } = await import(pathToFileURL(path.join(root, 'tools/verification/mv-ui-fixture.mjs')));
    const { stageSetup } = await import(pathToFileURL(path.join(root, 'tools/verification/mv-stage-fixture.mjs')));
    const f = await ui(stageSetup), snapshots = [], errors = [], drawers = new Set();
    f.sb.document.querySelector = () => null;
    f.sb.toastr = { error: value => errors.push(value), success() {}, info() {}, warning() {} };
    let paid = 0;
    const rejectGeneration = async () => { paid++; throw Error('Preview/navigation must not invoke generation'); };
    f.get('generation/cgImageCore').invokeImageGeneration = rejectGeneration;
    f.get('generation/client').requestJson = rejectGeneration;
    f.get('generation/client').generate = rejectGeneration;
    f.get('extras/mvMedia').putMedia = async () => true;
    for (const group of f.record.groups) for (const diff of group.diffs) diff.image = { url: '/saved-' + group.id + '-' + diff.id + '.png', split: 'none' };
    const originals = [...f.record.shots];
    f.record.shots = Array.from({ length: 25 }, (_, index) => ({ ...structuredClone(originals[index % originals.length]),
        id: 'PARITY_' + String(index + 1).padStart(2, '0'), sectionIndex: index < 16 ? 0 : 1, hold: 1 }));
    const saved = () => f.mv.readMv(f.host, f.song.id);
    const capture = (name, bucket = 'editor') => {
        const markup = f.body.innerHTML;
        snapshots.push({ name, bucket, html: markup });
        for (const tag of markup.matchAll(/<button\b[^>]*>/g)) {
            if (!/data-rmt-mv="editor-drawer"/.test(tag[0])) continue;
            const id = tag[0].match(/data-rmt-mv-id="([^"]+)"/)?.[1]; if (id) drawers.add(id);
        }
    };
    const crawlDrawers = prefix => {
        const done = new Set();
        for (let count = 0; count < 20; count++) {
            const id = [...drawers].find(value => !done.has(value)); if (!id) break;
            done.add(id); f.click('editor-drawer', id); capture(prefix + ':drawer:' + id); f.click('editor-drawer');
        }
    };
    try {
        f.mvui.openMv({ songId: f.song.id });
        const beforeNavigation = JSON.stringify(saved());
        for (let index = 0; index < 25; index++) {
            if (index) f.click('editor-step', '1');
            capture('shots:' + (index + 1));
        }
        for (const tab of ['timing', 'look', 'shots']) { f.click('editor-tab', tab); capture('tab:' + tab); }
        f.click('editor-preview'); capture('preview-only'); f.click('editor-preview');
        crawlDrawers('initial');
        assert.equal(JSON.stringify(saved()), beforeNavigation, 'Browsing all shots/tabs/drawers must not alter saved content');
        assert.equal(saved().shots.length, 25, 'A four-shot filmstrip must not truncate stored/generated shots');

        // A blank project still needs its generation controls, with no audio
        // prerequisite. Preserve all existing data after collecting this state.
        const materials = structuredClone(saved());
        const blankGroups = structuredClone(materials.groups);
        for (const group of blankGroups) {
            group.bg = null;
            for (const background of group.bgs || []) background.image = null;
            for (const diff of group.diffs) diff.image = null;
        }
        f.mv.patchRecord(f.song.id, { groups: blankGroups, shots: materials.shots.map(shot => ({ ...shot, image: null })) });
        f.click('select-shot', 'PARITY_01'); capture('empty-assets'); crawlDrawers('empty-assets');
        f.mv.patchRecord(f.song.id, { groups: materials.groups, shots: materials.shots }); f.mvui.renderMv();

        // Both shared and per-shot editing routes must remain available.
        f.mv.patchShot(f.song.id, 'PARITY_01', { image: { url: '/own-frame.png' } });
        f.click('select-shot', 'PARITY_01'); capture('own-frame'); crawlDrawers('own-frame');
        f.mv.patchShot(f.song.id, 'PARITY_01', { image: null }); f.mvui.renderMv(); capture('shared-frame');
        f.click('go-sync'); capture('legacy-sync'); f.click('editor-tab', 'timing');
        f.click('select-section', '0'); capture('timing-section');
        f.click('editor-line', '0:0'); capture('timing-line');
        f.click('editor-tab', 'look');
        f.click('range-pick', 'custom'); capture('custom-preview-range');

        // Real save-conflict journaling, with no paid generation or network call.
        const target = f.mv.captureMvTarget(f.host, f.song.id);
        f.mv.patchShot(f.song.id, 'PARITY_01', { image: { url: '/newer-manual.png' } });
        const pending = await f.mv.saveFrameImage(target, 'PARITY_01', { url: '/older-completed.png' });
        assert.equal(pending.pending, true, 'Fixture must exercise a real recoverable result');
        f.click('editor-drawer', 'more'); capture('more-pending');
        f.click('clear-pending', 'all'); capture('more-clear-confirm');
        f.click('cancel-clear-pending'); f.click('editor-drawer');

        f.click('editor-drawer', 'audio'); capture('audio-empty');
        f.upload(); assert.equal(typeof f.audios.at(-1)?.onloadedmetadata, 'function');
        f.audios.at(-1).onloadedmetadata(); await flush(); capture('audio-loaded');
        const input = { value: 'https://example.test/audio.mp3' };
        f.body.querySelector = selector => selector === '[data-rmt-mv-music-link]' ? input : null;
        f.get('extras/mvMusicLink').readMusicLink = (_value, { signal }) => new Promise((_, reject) => {
            signal.addEventListener('abort', () => reject(new DOMException('cancelled', 'AbortError')), { once: true });
        });
        f.click('audio-link'); await flush(); capture('audio-loading');
        f.click('audio-link-cancel'); await flush(); capture('audio-cancelled');
        f.body.querySelector = () => null;
        f.click('editor-drawer', 'export'); capture('export-unsupported');
        recorderHost(f); f.mvui.renderMv(); capture('export-supported');
        // Start through the public action but keep preload paused at a media
        // boundary; render/stop the real busy state without a recording task.
        const timers = new Map(); let timerId = 0;
        f.sb.setTimeout = fn => { timers.set(++timerId, fn); return timerId; };
        f.sb.clearTimeout = id => timers.delete(id);
        f.click('export'); f.mvui.renderMv(); capture('export-running');
        f.click('export-stop'); await flush(); capture('export-stopped');

        const editor = f.get('ui/mvImageEditorUi');
        snapshots.push({ name: 'image-shared', bucket: 'image', html: editor.imageEditorMarkup({ hasNext: true, showPrompt: true }) });
        snapshots.push({ name: 'image-single-last', bucket: 'image', html: editor.imageEditorMarkup({ hasNext: false, showPrompt: false }) });
        const dialogRestored = checkDialog(f);
        assert.deepEqual(errors, [], 'Public navigation should not emit errors');
        assert.equal(paid, 0);
        return { ...parseContracts(snapshots), paid, dialogRestored, storedShots: saved().shots.length,
            navigationUnchanged: JSON.stringify(saved().shots.map(shot => shot.id)) === JSON.stringify(f.record.shots.map(shot => shot.id)) };
    } finally { f.mvui.disposeMv(); }
}

function collectFrom(root) {
    return JSON.parse(execFileSync(process.execPath, ['--experimental-vm-modules', here, '--collect', root], {
        cwd: root, env: { ...process.env, TEST_ROOT: root, NODE_NO_WARNINGS: '1' },
        encoding: 'utf8', timeout: 8000, maxBuffer: 8 * 1024 * 1024,
    }));
}

function filesUnder(root, relative = '') {
    return fs.readdirSync(path.join(root, relative), { withFileTypes: true }).flatMap(entry => {
        const next = path.join(relative, entry.name);
        return entry.isDirectory() ? filesUnder(root, next) : [next];
    }).sort();
}

if (process.argv[2] === '--collect') {
    const result = await collect(path.resolve(process.argv[3]));
    process.stdout.write(JSON.stringify(result));
} else {
    let evidence;
    const both = () => evidence ||= { old: collectFrom(baseline), next: collectFrom(candidate) };

    test('all baseline editor/image actions, inputs, options and accepted files remain reachable', () => {
        const { old, next } = both();
        assert.ok(old.contracts.editor.length > 100, 'Baseline capture must exercise substantial production controls');
        assert.ok(old.contracts.image.length > 35, 'Baseline capture must include the complete image editor');
        for (const bucket of ['editor', 'image']) {
            const actual = new Set(next.contracts[bucket]);
            // The previous back-to-board button is now an explicit workspace tab.
            if (actual.has('action:workspace-tab:board')) actual.add('action:back:');
            const missing = old.contracts[bucket].filter(contract => !actual.has(contract));
            assert.deepEqual(missing, [], bucket + ': removed action/input/select option/file type');
        }
    });

    test('previously enabled operations receive no new disabled gate', () => {
        const { old, next } = both();
        for (const bucket of ['editor', 'image']) {
            const available = new Set(next.enabled[bucket]);
            if (available.has('action:workspace-tab:board')) available.add('action:back:');
            assert.deepEqual(old.enabled[bucket].filter(contract => !available.has(contract)), [], bucket + ': newly blocked control');
        }
    });

    test('25 existing shots remain navigable without content writes or generation and one player is retained', () => {
        const { next } = both();
        assert.equal(next.paid, 0); assert.equal(next.storedShots, 25); assert.equal(next.navigationUnchanged, true);
        const seen = new Set();
        for (const snapshot of next.snapshots.filter(row => row.name.startsWith('shots:'))) {
            for (const id of snapshot.shots) seen.add(id);
            assert.equal(snapshot.play, 1, snapshot.name + ': duplicate/missing playback button');
            assert.equal(snapshot.seek, 1, snapshot.name + ': duplicate/missing progress bar');
            assert.equal(snapshot.music, 1, snapshot.name + ': duplicate/missing music entry');
            assert.equal(new Set(snapshot.ids).size, snapshot.ids.length, snapshot.name + ': duplicate DOM ids');
        }
        for (let i = 1; i <= 25; i++) assert.ok(seen.has('PARITY_' + String(i).padStart(2, '0')), 'Unreachable shot ' + i);
    });

    test('the approved compact strip shows at most four shots and its gallery reaches all 25', () => {
        const { next } = both();
        const first = next.snapshots.find(row => row.name === 'shots:1');
        assert.ok(first.shots.length > 0 && first.shots.length <= 4, 'Build must contain the approved four-shot preview window');
        const gallery = next.snapshots.find(row => row.name === 'initial:drawer:shots');
        assert.ok(gallery, 'The all-shots drawer must be reachable from a rendered control');
        const all = new Set(gallery.shots);
        for (let i = 1; i <= 25; i++) assert.ok(all.has('PARITY_' + String(i).padStart(2, '0')), 'Gallery omits shot ' + i);
    });

    test('no music and no existing images do not disable the real draw action', () => {
        const { old, next } = both();
        for (const [label, value] of [['baseline', old], ['candidate', next]]) {
            const enabled = new Set(value.snapshots.filter(row => row.name.startsWith('empty-assets')).flatMap(row => row.enabledActionNames));
            assert.ok(enabled.has('draw'), label + ': drawing must remain possible before importing music or generating images');
        }
    });

    test('drawer disposal restores previous inert states and removes click/Escape/native-cancel listeners', () => {
        const { old, next } = both(); assert.equal(old.dialogRestored, true); assert.equal(next.dialogRestored, true);
    });

    test('generation, prompts, streaming, storage and every non-UI source stay byte-identical except release metadata', () => {
        const before = path.join(baseline, 'src'), after = path.join(candidate, 'src');
        const include = file => !file.startsWith('ui' + path.sep) && file !== path.join('core', 'releaseNotes.js');
        const oldFiles = filesUnder(before).filter(include), newFiles = filesUnder(after).filter(include);
        assert.deepEqual(newFiles, oldFiles, 'No non-UI source may be added or removed');
        assert.ok(oldFiles.length > 150, 'Fingerprint must include the real generation/persistence tree');
        const normalize = (file, value) => file === path.join('core', 'selfUpdater.js')
            ? value.replace(/^(export const INSTALLED_BUILD = )'[^']+';/m, "$1'<release-version>';") : value;
        const changed = oldFiles.filter(file => {
            const oldText = normalize(file, fs.readFileSync(path.join(before, file), 'utf8'));
            const newText = normalize(file, fs.readFileSync(path.join(after, file), 'utf8'));
            return createHash('sha256').update(oldText).digest('hex') !== createHash('sha256').update(newText).digest('hex');
        });
        assert.deepEqual(changed, [], 'Changed non-UI source could alter generation or persistence constraints');
    });
}
