// Public actions against the shipped bundle; no browser/device claims.
import test from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { ui } from './mv-ui-fixture.mjs';
import { stageSetup } from './mv-stage-fixture.mjs';
const plain = x => JSON.parse(JSON.stringify(x));
const flush = () => new Promise(resolve => setImmediate(resolve));
async function setup(change = () => {}) {
    const f = await ui(stageSetup), errors = [];
    f.sb.document.querySelector = () => null;
    f.sb.toastr = { error: value => errors.push(value), success() {}, info() {} };
    for (const group of f.record.groups) for (const diff of group.diffs) diff.image = { url: `/user/images/${group.id}-${diff.id}.png`, split: 'none' };
    change(f.record);
    let paid = 0;
    f.get('generation/cgImageCore').invokeImageGeneration = async () => { paid++; throw Error('unexpected image call'); };
    f.get('generation/client').requestJson = async () => { paid++; throw Error('unexpected text call'); };
    const saved = () => f.mv.readMv(f.host, f.song.id);
    const input = (selector, value, rest = {}) => f.mvui.handleMvChange({ target: { matches: s => s === selector, value: String(value), ...rest } });
    f.mvui.openMv({ songId: f.song.id });
    return { ...f, errors, saved, input, paid: () => paid };
}

test('completed old story opens directly into the responsive editor with no saved-data writes or generation', async () => {
    const f = await setup(); try {
        const before = JSON.stringify(f.saved());
        assert.match(f.body.innerHTML, /rmt-mve-workspace/);
        for (const id of ['shots', 'timing', 'look']) assert.match(f.body.innerHTML, new RegExp(`data-rmt-mv="editor-tab"[^>]*data-rmt-mv-id="${id}"`));
        for (const id of ['timing', 'look', 'shots']) f.click('editor-tab', id);
        f.mvui.disposeMv(); f.mvui.openMv({ songId: f.song.id });
        assert.equal(JSON.stringify(f.saved()), before); assert.equal(f.paid(), 0); assert.deepEqual(f.errors, []);
    } finally { f.mvui.disposeMv(); }
});

test('material groups stay folded and perform no character processing until explicitly inspected', async () => {
    const f = await setup(); let cuts = 0;
    f.get('extras/mvImageTools').prepareCharacterPixels = () => { cuts++; throw Error('hidden image processed'); };
    try {
        f.mvui.openMv({ songId: f.song.id, page: 'board' });
        assert.match(f.body.innerHTML, /rmt-mve-group-fold/); assert.doesNotMatch(f.body.innerHTML, /data-rmt-mv-anchor="G1:D1"|rmt-mv-inspect-row/);
        f.click('group-open', 'G1'); assert.match(f.body.innerHTML, /data-rmt-mv-anchor="G1:D1"/);
        assert.doesNotMatch(f.body.innerHTML, /rmt-mv-inspect-row/);
        f.click('group-open', 'G1'); assert.doesNotMatch(f.body.innerHTML, /data-rmt-mv-anchor="G1:D1"/);
        assert.equal(cuts, 0); assert.equal(f.paid(), 0);
    } finally { f.mvui.disposeMv(); }
});

test('filmstrip windows are navigation only and preserve all 40 saved/generated shots', async () => {
    const f = await setup(r => { r.shots = Array.from({ length: 40 }, (_, i) => ({ ...r.shots[0], id: 'S' + i })); });
    try {
        const before = JSON.stringify(f.saved());
        assert.equal((f.body.innerHTML.match(/data-rmt-mv="select-shot"/g) || []).length, 4);
        f.click('editor-strip', '36'); assert.match(f.body.innerHTML, /data-rmt-mv-id="S39"/);
        f.click('select-shot', 'S39'); assert.match(f.body.innerHTML, /第 40 镜/);
        assert.equal(JSON.stringify(f.saved()), before); assert.equal(f.saved().shots.length, 40);
    } finally { f.mvui.disposeMv(); }
});

test('image editing and one-click cutout open the existing full-featured editor with original references', async () => {
    const f = await setup(); let options;
    f.body.querySelector = s => s === '[data-rmt-mv-editor-host]' ? {} : null;
    f.get('ui/mvImageEditor').mountAssetEditor = (_host, o) => { options = o; return { dispose() {} }; };
    try {
        const before = JSON.stringify(f.saved());
        assert.match(f.body.innerHTML, /图片编辑 · 选单格 · 修边/);
        f.click('edit-asset', 'G1:D1'); await flush();
        assert.equal(options.imageUrl, '/user/images/G1-D1.png'); assert.equal(options.sourceUrl, options.imageUrl);
        assert.equal(options.autoCutout, false); options.onClose();
        assert.match(f.body.innerHTML, /rmt-mve-workspace/);
        f.click('cutout-asset', 'G1:D1'); await flush(); assert.equal(options.autoCutout, true); options.onClose();
        assert.equal(JSON.stringify(f.saved()), before); assert.equal(f.paid(), 0);
    } finally { f.mvui.disposeMv(); }
});

test('a per-shot imported picture is not mislabeled as editing a different shared material', async () => {
    const f = await setup(r => { r.shots[0].image = { url: '/import.png' }; });
    try {
        assert.doesNotMatch(f.body.innerHTML, /data-rmt-mv="edit-asset"/);
        assert.match(f.body.innerHTML, /data-rmt-mv="use-group-image"/);
        f.click('use-group-image', f.saved().shots[0].id); assert.match(f.body.innerHTML, /data-rmt-mv="edit-asset"/);
        assert.equal(f.saved().groups[0].diffs[0].image.url, '/user/images/G1-D1.png');
    } finally { f.mvui.disposeMv(); }
});

test('look tab retains title/outro timing, fonts, templates, range, stage lyrics and both overlay switches', async () => {
    const f = await setup(); try {
        const before = JSON.stringify({ shots: f.saved().shots, groups: f.saved().groups, timing: f.saved().timing });
        f.click('editor-tab', 'look');
        for (const name of ['intro-seconds', 'outro-seconds', 'overlay="motif"', 'overlay="keyword"']) assert.ok(f.body.innerHTML.includes('data-rmt-mv-' + name));
        for (const action of ['tegaki-font', 'tegaki-preset', 'tegaki-rhythm', 'range-pick', 'tegaki-lyric', 'editor-ratio']) assert.ok(f.body.innerHTML.includes(`data-rmt-mv="${action}"`));
        f.input('[data-rmt-mv-intro-seconds]', 1.5); f.input('[data-rmt-mv-outro-seconds]', 0);
        f.click('editor-ratio', '9:16'); f.mvui.openMv({ songId: f.song.id }); f.click('editor-tab', 'look');
        assert.equal(f.saved().tegaki.introSeconds, 1.5); assert.equal(f.saved().tegaki.outroSeconds, 0); assert.equal(f.saved().settings.ratio, '9:16');
        assert.equal(JSON.stringify({ shots: f.saved().shots, groups: f.saved().groups, timing: f.saved().timing }), before);
    } finally { f.mvui.disposeMv(); }
});

test('timing shares one player, and selecting a section or line neither seeks nor writes', async () => {
    const f = await setup(); try {
        f.input('[data-rmt-mv-seek]', 3.5); const before = JSON.stringify(f.saved());
        f.click('editor-tab', 'timing'); f.click('select-section', '1'); f.click('editor-line', '0:1');
        assert.equal((f.body.innerHTML.match(/<canvas /g) || []).length, 1);
        assert.match(f.body.innerHTML, /data-rmt-mv-seek/); assert.match(f.body.innerHTML, /正在定句/);
        assert.match(f.body.innerHTML, /value="3.5" data-rmt-mv-seek/); assert.equal(JSON.stringify(f.saved()), before);
    } finally { f.mvui.disposeMv(); }
});

test('zero-second section and line marks work, automatic advance and exact undo share one history', async () => {
    const f = await setup(r => { r.timing = { taps: {}, lineTaps: {}, shift: 0 }; });
    try {
        f.click('editor-tab', 'timing'); f.click('select-section', '0'); f.input('[data-rmt-mv-seek]', 0); f.click('editor-mark');
        assert.equal(f.saved().timing.taps[0], 0); assert.match(f.body.innerHTML, /正在定句/);
        f.click('editor-mark'); assert.equal(f.saved().timing.lineTaps['0:0'], 0);
        f.input('[data-rmt-mv-seek]', 2.4); f.click('editor-mark'); assert.equal(f.saved().timing.lineTaps['0:1'], 2.4);
        f.click('editor-undo'); assert.equal(f.saved().timing.lineTaps['0:1'], undefined); assert.equal(f.saved().timing.lineTaps['0:0'], 0);
        f.click('editor-undo'); assert.deepEqual(plain(f.saved().timing.lineTaps), {}); assert.equal(f.saved().timing.taps[0], 0);
        f.click('editor-undo'); assert.deepEqual(plain(f.saved().timing), { taps: {}, lineTaps: {}, shift: 0 });
    } finally { f.mvui.disposeMv(); }
});

test('line correction, tenths nudging and reset undo restore previous saved timing rather than deleting it', async () => {
    const f = await setup(); try {
        const original = plain(f.saved().timing);
        f.click('editor-tab', 'timing'); f.click('editor-line', '0:1'); f.click('editor-nudge', '0.1');
        assert.equal(f.saved().timing.lineTaps['0:1'], 4.1); f.click('editor-undo'); assert.deepEqual(plain(f.saved().timing), original);
        f.click('editor-line', '0:1'); f.input('[data-rmt-mv-editor-time]', 3.7); assert.equal(f.saved().timing.lineTaps['0:1'], 3.7);
        f.click('editor-undo'); assert.deepEqual(plain(f.saved().timing), original);
        f.click('tap-line-reset'); assert.deepEqual(plain(f.saved().timing.taps), original.taps); f.click('editor-undo'); assert.deepEqual(plain(f.saved().timing), original);
        f.click('tap-reset'); assert.deepEqual(plain(f.saved().timing.taps), {}); f.click('editor-undo'); assert.deepEqual(plain(f.saved().timing), original);
    } finally { f.mvui.disposeMv(); }
});

test('manual section correction respects the old global shift and stays selected with auto-next off', async () => {
    const f = await setup(r => { r.timing.shift = 1; }); try {
        f.click('editor-tab', 'timing'); f.click('select-section', '1'); f.input('[data-rmt-mv-editor-next]', '', { checked: false });
        f.input('[data-rmt-mv-editor-time]', 9.5); assert.equal(f.saved().timing.taps[1], 8.5);
        assert.match(f.body.innerHTML, /正在定段 · 副歌/); f.click('editor-nudge', '0.1'); assert.equal(f.saved().timing.taps[1], 8.6);
        f.input('[data-rmt-mv-editor-time]', -2); f.input('[data-rmt-mv-editor-time]', ''); f.input('[data-rmt-mv-editor-time]', 'NaN'); assert.equal(f.saved().timing.taps[1], 8.6);
    } finally { f.mvui.disposeMv(); }
});

test('the old timing route also permits selecting and marking a line without resetting to section mode', async () => {
    const f = await setup(); try {
        f.click('go-sync'); f.click('editor-line', '0:1'); f.input('[data-rmt-mv-editor-time]', 3.2);
        assert.equal(f.saved().timing.lineTaps['0:1'], 3.2); assert.match(f.body.innerHTML, /正在定句/);
        f.mvui.openMv({ songId: f.song.id }); f.click('editor-tab', 'timing'); assert.equal(f.saved().timing.lineTaps['0:1'], 3.2);
    } finally { f.mvui.disposeMv(); }
});

test('finished timing can reopen for correction, and null marks are never counted as zero', async () => {
    const f = await setup(); try {
        f.click('editor-tab', 'timing'); assert.match(f.body.innerHTML, /全部句子已对齐/);
        f.click('editor-line', '0:0'); f.input('[data-rmt-mv-editor-time]', 0); assert.equal(f.saved().timing.lineTaps['0:0'], 0);
        f.mv.patchRecord(f.song.id, { timing: { taps: {}, lineTaps: { '0:0': null } } }); f.mvui.openMv({ songId: f.song.id }); f.click('editor-tab', 'timing');
        assert.match(f.body.innerHTML, /0 段 · 0 \/ 3 句/); assert.doesNotMatch(f.body.innerHTML, /全部句子已对齐/);
    } finally { f.mvui.disposeMv(); }
});

test('more panel preserves material library, subtitle/time-table download and recovery backup', async () => {
    const f = await setup(); try {
        f.click('editor-drawer', 'more');
        for (const action of ['go-board', 'download-table', 'download-srt', 'export-recovery']) assert.ok(f.body.innerHTML.includes(`data-rmt-mv="${action}"`));
        assert.match(f.body.innerHTML, /role="dialog" aria-modal="true"/); f.click('editor-drawer'); assert.doesNotMatch(f.body.innerHTML, /role="dialog"/);
        f.click('go-board'); assert.match(f.body.innerHTML, /构图卡片/); f.click('go-tegaki'); assert.match(f.body.innerHTML, /rmt-mve-workspace/);
    } finally { f.mvui.disposeMv(); }
});

test('WebView capability fallback retains recording and local audio import without new platform APIs', async () => {
    const f = await setup(); try {
        for (const key of ['Worker', 'OffscreenCanvas', 'IntersectionObserver', 'MediaRecorder', 'AudioContext', 'webkitAudioContext']) delete f.sb[key];
        f.click('editor-drawer', 'export'); assert.match(f.body.innerHTML, /不支持直接导出视频/); assert.match(f.body.innerHTML, /data-rmt-mv="record-mode"/);
        f.click('editor-drawer', 'audio'); assert.match(f.body.innerHTML, /data-rmt-mv-audio/);
        f.upload(); f.audios.at(-1).onloadedmetadata(); assert.match(f.body.innerHTML, /manual.wav/);
        assert.equal(f.paid(), 0); assert.deepEqual(f.errors, []);
    } finally { f.mvui.disposeMv(); }
});

test('queued image completion is cancelled on close and cannot redraw an old song', async () => {
    const f = await setup(); const callbacks = new Map(); let serial = 0, reads = 0, release;
    f.sb.setTimeout = callback => { callbacks.set(++serial, callback); return serial; };
    f.sb.clearTimeout = id => callbacks.delete(id);
    f.get('extras/mvMedia').getMedia = () => { reads++; return new Promise(resolve => { release = resolve; }); };
    try {
        f.mv.patchRecord(f.song.id, { shots: f.saved().shots.map(s => ({ ...s, image: { local: 'delayed-blob' } })) });
        f.mvui.renderMv(); const before = f.body.innerHTML; assert.equal(reads, 1);
        f.mvui.disposeMv(); release({ blob: new Blob(['test']) }); await flush();
        for (const callback of callbacks.values()) callback();
        assert.equal(f.body.innerHTML, before); assert.equal(callbacks.size, 0);
    } finally { f.mvui.disposeMv(); }
});

test('light/dark colors, container/mobile fallbacks and native range keyboard input remain in editor CSS', async () => {
    const f = await setup(); try {
        const css = f.get('ui/mvEditorUi').editorCss('#plugin');
        assert.match(css, /var\(--rmt-theme-text/); assert.match(css, /var\(--rmt-theme-surface-solid/);
        assert.match(css, /@media\(min-width:960px\)/); assert.match(css, /@container \(min-width:780px\)/);
        assert.match(css, /min-height:4[0248]px/); assert.match(f.body.innerHTML, /type="range"[^>]*data-rmt-mv-seek/);
        f.input('[data-rmt-mv-seek]', 7.5); f.click('editor-tab', 'timing'); assert.match(f.body.innerHTML, /value="7.5" data-rmt-mv-seek/);
    } finally { f.mvui.disposeMv(); }
});

test('desktop keyboard switches tabs and closes a dialog without invoking the outer back action', async () => {
    const f = await setup(), listeners = new Map(); let focused = '', prevented = 0, stopped = 0;
    const root = { addEventListener: (name, fn) => listeners.set(name, fn), querySelector: () => null };
    f.body.querySelector = selector => selector === '.rmt-mv-editor' ? root : { focus: () => { focused = selector; } };
    try {
        f.mvui.renderMv();
        listeners.get('keydown')({ key: 'ArrowRight', target: { closest: () => ({ dataset: { rmtMvId: 'shots' } }) }, preventDefault: () => prevented++ });
        assert.match(f.body.innerHTML, /data-editor-tab="timing"/); assert.match(focused, /timing/);
        f.click('editor-drawer', 'more');
        listeners.get('keydown')({ key: 'Escape', target: {}, preventDefault: () => prevented++, stopPropagation: () => stopped++ });
        assert.doesNotMatch(f.body.innerHTML, /role="dialog"/); assert.match(f.body.innerHTML, /rmt-mve-workspace/);
        assert.match(focused, /data-rmt-mv-id="more"/); assert.equal(prevented, 2); assert.equal(stopped, 1);
    } finally { f.mvui.disposeMv(); }
});

test('native large-image cold open prepares only the visible frame and never encodes whole-image PNG previews', () => {
    const result = execFileSync(process.execPath, ['--experimental-vm-modules', new URL('./mv-editor-open-probe.mjs', import.meta.url).pathname, '6', '1024'], { encoding: 'utf8', timeout: 15000 });
    const metrics = JSON.parse(result.trim());
    assert.equal(metrics.editor, true); assert.equal(metrics.prepareCalls, 1); assert.equal(metrics.decodes, 1);
    assert.ok(metrics.maxWorkingPixels <= 960 * 960); assert.equal(metrics.renders, 1); assert.equal(metrics.pngCalls, 0);
    assert.equal(metrics.dataPreserved, true); assert.equal(metrics.paidCalls, 0);
});
