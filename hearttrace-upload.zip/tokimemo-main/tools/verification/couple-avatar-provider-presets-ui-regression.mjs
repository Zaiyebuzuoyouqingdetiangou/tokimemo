import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const root = process.env.TEST_ROOT || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const plain = value => JSON.parse(JSON.stringify(value));

async function setup({ provider = 'chatu8-image', backend = 'nai', supportsCharacters = true } = {}) {
    const context = { name2: 'Original', name1: 'Partner', imageProvider: provider, extensionSettings: { 'st-chatu8': {
        characterPresets: { new: { nameEN: 'Newperson', characterTraits: 'blonde hair, pale skin', facialFeatures: 'green eyes' } },
    } } };
    const requests = [], library = [{ id: 'new', name: 'Newperson', tag: 'silver hair, blue eyes' }];
    const environment = vm.createContext({ URL, console, setTimeout, clearTimeout, AbortController });
    let adapter;
    environment.STBaiBaiImage = {
        apiVersion: 1, capabilities: { generate: true, saveToGallery: true, characterLibrary: true },
        getCharacters: () => ({ apiVersion: 1, characters: library }),
        getBackendStatus: () => ({ configured: true, backend, supportsCharacters }),
        generate: async request => { requests.push(plain(request)); return { path: '/user/images/couple.png' }; },
    };
    const stubs = {
        'core/context': { getContext: () => context, currentCharacterGuard: () => context, chatScopeKey: () => 'test-scope' },
        'core/castLooks': { readCastLooks: () => ({ char: 'black hair', user: 'brown hair', manual: true }), lookFromDescription: value => value || '' },
        'core/settings': { getPluginSettings: ctx => ({ imageGenerationProvider: ctx.imageProvider }) },
        'core/text': {
            normalizeText: (value, limit = 20000) => String(value ?? '').replace(/\r\n?/g, '\n').replace(/\u0000/g, '').trim().slice(0, limit),
            safeUserError: (message, code) => Object.assign(new Error(message), { code, safeToDisplay: true }),
        },
        'generation/cgImageCore': { normalizeCgImageUrl: url => url, invokeImageGeneration: async (prompt, ctx, options) => {
            if (ctx.imageProvider === 'baibai-image') return adapter.generateBaiBaiImage(prompt, options);
            requests.push({ prompt, options }); return { url: '/user/images/couple.png' };
        } },
        'generation/cgAppearance': { normalizeCgPromptMetadata: () => null, scopeCgPromptMetadata: () => null,
            resolveCgAppearanceMetadata: () => null, formattedCgProviderPrompts: () => null, cgFlatPromptWithNaturalLooks: value => value },
        'core/cgImagePatch': { imageResourceBase: () => 'https://example.test/', isSameImageHost: () => true, savedLocalImagePath: value => value },
        'core/taskTrace': { startTaskTrace: () => ({}), beginStage() {}, markStage() {}, endTaskTrace() {} },
        'core/state': { state: { activeCoupleAvatarTasks: new Map() } },
    };
    const cache = new Map();
    async function load(id) {
        if (cache.has(id)) return cache.get(id);
        const stub = stubs[id];
        const loaded = stub
            ? new vm.SyntheticModule(Object.keys(stub), function () { for (const [key, value] of Object.entries(stub)) this.setExport(key, value); }, { context: environment, identifier: id })
            : new vm.SourceTextModule(await fs.readFile(path.join(root, 'src', id + '.js'), 'utf8'), { context: environment, identifier: id });
        cache.set(id, loaded);
        await loaded.link((specifier, parent) => load(path.posix.normalize(path.posix.join(path.posix.dirname(parent.identifier), specifier)).replace(/\.js$/, '')));
        return loaded;
    }
    const loaded = await load('extras/coupleAvatar'); await loaded.evaluate();
    const adapterModule = await load('generation/baibaiImage'); await adapterModule.evaluate(); adapter = adapterModule.namespace;
    const core = loaded.namespace;
    // Execute the UI's real draft function and real resolver with a small input
    // surface. No copied draft algorithm or browser event timing is assumed.
    const source = await fs.readFile(path.join(root, 'src/ui/coupleAvatarView.js'), 'utf8');
    const draftSource = source.slice(source.indexOf('function draft(view)'), source.indexOf('function queueDraft(view)'));
    const draft = Function('couple', 'settingFields', 'structuredClone', draftSource + '; return draft;')(
        core, ['interaction', 'interactionDetail', 'clothing', 'background', 'direction', 'customStyle'], structuredClone);
    const settings = core.defaultCoupleSettings(context), inputs = new Map();
    for (let i = 0; i < 2; i++) for (const key of ['name', 'appearance']) inputs.set(`[data-pair-person="${i}"][data-pair-key="${key}"]`, { value: settings.people[i][key] });
    const field = (index, key) => inputs.get(`[data-pair-person="${index}"][data-pair-key="${key}"]`);
    const view = { settings, context, root: { querySelector: key => inputs.get(key) } };
    return { core, context, requests, library, draft: () => draft(view), field, view };
}

for (const provider of ['chatu8-image', 'baibai-image']) test(`${provider}: name-only edits and repeated submit preserve the new preset, own fallback and saved identity`, async () => {
    const f = await setup({ provider }), preset = provider === 'chatu8-image' ? 'blonde hair, pale skin, green eyes' : 'silver hair, blue eyes';
    f.field(0, 'name').value = 'Newperson';
    assert.equal(f.draft().people[0].appearance, preset);
    assert.equal(f.field(0, 'appearance').value, preset, 'the form must show the resolved appearance before its next read');
    const submitted = f.draft();
    assert.equal(submitted.people[0].appearanceOverride, undefined);
    assert.equal(submitted.people[0].fallbackAppearance, 'black hair');
    const saved = await f.core.generateCouple(submitted, { context: f.context });
    assert.equal(f.requests.length, 1);
    assert.equal(saved.record.settings.people[0].appearance, preset);
    assert.equal(saved.record.settings.people[1].appearance, 'brown hair');
    const payload = JSON.stringify(f.requests[0]);
    assert.match(payload, provider === 'chatu8-image' ? /blonde hair/ : /silver hair/);
    assert.doesNotMatch(payload, /black hair/);
    f.field(0, 'name').value = 'Missing';
    assert.equal(f.draft().people[0].appearance, 'black hair');
    assert.equal(f.field(0, 'appearance').value, 'black hair');
    assert.equal(f.draft().people[0].appearanceOverride, undefined);
    const before = f.requests.length;
    await f.core.retryCoupleSave(saved.scope, saved.record.id);
    assert.equal(f.requests.length, before, 'save-only recovery never draws again');
});

test('an actual appearance edit or clearing is authoritative even when the name changes next', async () => {
    for (const appearance of ['purple hair, hazel eyes', '']) {
        const f = await setup();
        f.field(0, 'appearance').value = appearance;
        assert.equal(f.draft().people[0].appearanceOverride, true);
        f.field(0, 'name').value = 'Newperson';
        const submitted = f.draft();
        assert.equal(submitted.people[0].appearance, appearance);
        assert.equal(submitted.people[0].appearanceOverride, true);
        assert.equal(f.draft().people[0].appearance, appearance);
        await f.core.generateCouple(submitted, { context: f.context });
        assert.doesNotMatch(f.requests[0].prompt, /blonde hair|green eyes/);
        if (appearance) assert.match(f.requests[0].prompt, /purple hair, hazel eyes/);
    }
});

for (const [backend, supportsCharacters] of [['nai', true], ['nai', false], ['comfyui', false]]) test(`BaiBai ${backend}/${supportsCharacters}: the real adapter receives own presets in native or flat animal portraits`, async () => {
    const f = await setup({ provider: 'baibai-image', backend, supportsCharacters });
    f.field(0, 'name').value = 'Newperson'; f.draft();
    const settings = { ...f.draft(), styleId: 'animal-cat', direction: 'keep this gentle reaction', customStyle: 'custom text remains' };
    const saved = await f.core.generateCouple(settings, { context: f.context });
    assert.equal(f.requests.length, 1);
    const payload = JSON.stringify(f.requests[0]);
    assert.match(payload, /silver fur markings/); assert.match(payload, /blue eyes/);
    assert.match(payload, /brown fur markings/); assert.match(payload, /keep this gentle reaction/);
    assert.doesNotMatch(payload, /blonde|green eyes|black hair|silver hair/);
    if (backend === 'nai' && supportsCharacters) {
        assert.equal(f.requests[0].characters.length, 2);
        assert.match(f.requests[0].characters[0].tag, /silver fur markings/);
        assert.doesNotMatch(f.requests[0].characters[1].tag, /silver/);
    } else assert.equal(f.requests[0].characters, undefined);
    const snapshot = plain(saved.record.settings);
    f.library[0].tag = 'red hair';
    assert.deepEqual(plain(f.core.normalizeCoupleSettings(snapshot, null)), snapshot);
});

test('BaiBai missing and ambiguous names fall back independently; changing the provider restores its own preset', async () => {
    const f = await setup({ provider: 'baibai-image' });
    f.field(0, 'name').value = 'Newperson';
    const baiBai = f.draft();
    assert.equal(baiBai.people[0].appearance, 'silver hair, blue eyes');
    f.library.push({ id: 'other', name: 'Newperson', tag: 'red hair' });
    assert.equal(f.draft().people[0].appearance, 'black hair');
    f.context.imageProvider = 'chatu8-image';
    assert.equal(f.draft().people[0].appearance, 'blonde hair, pale skin, green eyes');
    assert.equal(f.draft().people[1].appearance, 'brown hair');
    assert.equal(f.requests.length, 0);
});
