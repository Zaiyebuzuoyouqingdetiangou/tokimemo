import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';

const plain = value => JSON.parse(JSON.stringify(value));
const roles = [
    { role: 'char', name: 'Raphael', tag: 'dark brown hair' },
    { role: 'user', name: 'Kamael', tag: 'short blonde hair' },
];
test('explicit per-image cast excludes the other appearance without deleting stored tags', async () => {
    const f = await fixture(), api = f.get('generation/cgAppearance');
    const raw = f.json({ characters: roles, selectedRoles: ['user'] });
    assert.equal(typeof api.scopeCgPromptMetadata, 'function');
    const scoped = api.scopeCgPromptMetadata('Kamael wearing a ruby ring', raw);
    assert.deepEqual(plain(scoped.characters.map(row => row.name)), ['Kamael']);
    assert.equal(raw.characters[0].tag, 'dark brown hair');
    assert.doesNotMatch(api.cgPreparedVisualPrompt('Kamael wearing a ruby ring', scoped), /Raphael|dark brown hair/);
});
test('a name mention and 1boy never silently choose a character; explicit empty cast is valid', async () => {
    const f = await fixture(), api = f.get('generation/cgAppearance');
    for (const scene of ['1boy, holding Kamael photo', 'Kamael wearing a ruby ring', 'solo, holding a photo of Raphael']) {
        assert.equal(api.scopeCgPromptMetadata(scene, f.json({ characters: roles })).characters.length, 2);
    }
    const empty = api.scopeCgPromptMetadata('snowflakes, no humans', f.json({ characters: roles, selectedRoles: [] }));
    assert.deepEqual(plain(empty.characters), []);
    assert.deepEqual(plain(empty.selectedRoles), []);
});
test('manual per-person and complete-prompt overrides survive normalization and scene edit', async () => {
    const f = await fixture(), api = f.get('generation/cgAppearance');
    const raw = f.json({ characters: [{ ...roles[1], appearanceOverride: true }], selectedRoles: ['user'],
        flatPrompt: 'exact user-authored complete prompt', flatPromptOverride: true });
    const normalized = api.normalizeCgPromptMetadata(raw);
    assert.equal(normalized.characters[0].appearanceOverride, true);
    assert.equal(normalized.flatPromptOverride, true);
    const edited = api.metadataAfterSceneEdit(normalized);
    assert.equal(edited.flatPrompt, raw.flatPrompt);
    assert.deepEqual(plain(edited.selectedRoles), ['user']);
    const cleared = api.normalizeCgPromptMetadata(f.json({ characters: [{ ...roles[1], tag: '', appearanceOverride: true }] }));
    assert.equal(cleared.characters[0].tag, '');
    assert.equal(cleared.characters[0].appearanceOverride, true);
});
test('legacy editor serializer uses the visible checked cast and retains manual tag edits', async () => {
    const f = await fixture(), editor = f.get('ui/cgPromptEditor');
    const fields = new Map([
        ['[data-rmt-cg-scene-tags]', { value: '' }], ['[data-rmt-cg-flat-prompt]', { value: '' }],
        ['[data-rmt-cg-tag-input="char"]', { value: 'dark brown hair' }],
        ['[data-rmt-cg-tag-input="user"]', { value: 'short blonde hair' }],
        ['[data-rmt-cg-role-selected="char"]', { checked: false }],
        ['[data-rmt-cg-role-selected="user"]', { checked: true }],
    ]);
    const metadata = editor.cgEditorPromptMetadata({ multi: false, characterNames: { char: 'Raphael', user: 'Kamael' },
        appearanceEdited: { user: true }, element: { querySelector: selector => fields.get(selector) } });
    assert.deepEqual(plain(metadata.selectedRoles), ['user']);
    assert.deepEqual(plain(metadata.characters.map(row => row.name)), ['Kamael']);
    assert.equal(metadata.characters[0].appearanceOverride, true);
    assert.equal(fields.get('[data-rmt-cg-tag-input="char"]').value, 'dark brown hair');
});
test('legacy defaults prefer Chatu8 presets per person and fallback without rewriting saved looks', async () => {
    const f = await fixture(), api = f.get('generation/cgAppearance');
    f.get('core/settings').getPluginSettings = () => ({ imageGenerationProvider: 'chatu8-image' });
    f.get('core/castLooks').readCastLooks = () => ({ manual: true, char: 'old brown hair', user: 'own blue eyes' });
    f.get('generation/chatu8Presets').chatu8PresetAppearance = (_context, name) => name === 'Char' ? { tag: 'golden hair', source: 'chatu8', presetKey: 'a' } : null;
    const metadata = api.initialCgAppearanceMetadata({}, f.host);
    assert.equal(metadata.characters.find(row => row.role === 'char').tag, 'golden hair');
    assert.equal(metadata.characters.find(row => row.role === 'user').tag, 'own blue eyes');
    const evidence = api.captureCgAppearanceEvidence(f.host);
    assert.equal(evidence.characters.find(row => row.role === 'char').knownTag, 'golden hair');
    assert.equal(evidence.characters.find(row => row.role === 'user').knownTag, 'own blue eyes');
});
test('non-Chatu8 defaults and existing image metadata are not rewritten', async () => {
    const f = await fixture(), api = f.get('generation/cgAppearance');
    f.get('core/settings').getPluginSettings = () => ({ imageGenerationProvider: 'baibai-image' });
    f.get('core/castLooks').readCastLooks = () => ({ manual: true, char: 'old brown hair', user: 'own blue eyes' });
    f.get('generation/chatu8Presets').chatu8PresetAppearance = () => { throw Error('must not read this provider'); };
    assert.equal(api.initialCgAppearanceMetadata({}, f.host).characters[0].tag, 'old brown hair');
    const saved = f.json({ characters: [roles[1]], flatPrompt: 'keep saved image prompt' });
    assert.deepEqual(plain(api.initialCgAppearanceMetadata({ cgImage: { promptMetadata: saved } }, f.host)), { sceneTags: '', ...plain(saved), characters: [{ ...roles[1], nl: '' }] });
});
test('multi defaults fill missing preset looks, keep independent fallback and avoid same-name guesses', async () => {
    const f = await fixture(), api = f.get('generation/cgAppearance');
    f.get('core/settings').getPluginSettings = () => ({ imageGenerationProvider: 'chatu8-image' });
    const people = [{ id: 'a', name: 'Char', sourceRefs: [] }, { id: 'b', name: 'User', sourceRefs: [] }];
    f.get('core/cache').readParticipantRoster = () => f.json({ version: 1, cardType: 'multi', revision: '', people, selectedIds: ['a', 'b'] });
    f.get('core/castLooks').readParticipantLooks = () => ({ characters: [{ participantId: 'b', tag: 'own blue eyes' }] });
    f.get('generation/chatu8Presets').chatu8PresetAppearance = (_context, name) => name === 'Char' ? { tag: 'golden hair', source: 'chatu8', presetKey: 'a' } : null;
    const metadata = api.initialCgAppearanceMetadata({}, f.host);
    assert.equal(metadata.characters.find(row => row.participantId === 'a').tag, 'golden hair');
    assert.equal(metadata.characters.find(row => row.participantId === 'b').tag, 'own blue eyes');
    const evidence = api.captureCgAppearanceEvidence(f.host, { castSnapshot: metadata.castSnapshot });
    assert.equal(evidence.characters[0].knownTag, 'golden hair');
    people[1].name = 'ＣＨＡＲ';
    const ambiguous = api.initialCgAppearanceMetadata({}, f.host);
    assert.equal(ambiguous.characters.some(row => row.tag === 'golden hair'), false);
    assert.equal(ambiguous.characters.find(row => row.participantId === 'b').tag, 'own blue eyes');
});
test('explicit cast stays scoped while reconceiving and manual override survives extraction', async () => {
    const f = await fixture(), api = f.get('generation/cgAppearance');
    f.host.getCharacterCardFields = () => ({ description: 'brown hair', persona: 'blonde hair' });
    const evidence = api.appearanceEvidenceWithDraft(api.captureCgAppearanceEvidence(f.host, { selectedRoles: ['user'] }),
        { user: { tag: 'short blonde hair', appearanceOverride: true } }, f.host);
    assert.deepEqual(plain(evidence.characters.map(row => row.role)), ['user']);
    const prepared = api.normalizeCgPreparedPrompt({ imagePrompt: 'User wears a ring', sceneTags: 'solo, ring',
        flatPrompt: 'User with short blonde hair wears a ring', characters: [{ role: 'user', tag: 'short blonde hair' }] }, evidence);
    assert.deepEqual(plain(prepared.selectedRoles), ['user']);
    assert.equal(prepared.characters[0].appearanceOverride, true);
    assert.deepEqual(plain(prepared.missingRoles), []);
});
test('preset changes discard dependent generated flat prompt and leave other-provider library unread', async () => {
    const f = await fixture(), api = f.get('generation/cgAppearance');
    f.get('core/settings').getPluginSettings = () => ({ imageGenerationProvider: 'chatu8-image' });
    // This scenario has one Char preset; returning it for every name would
    // instead simulate two distinct people claiming the same preset identity.
    f.get('generation/chatu8Presets').chatu8PresetAppearance = (_ctx, name) => name === 'Char'
        ? { tag: 'golden hair', source: 'chatu8', presetKey: 'a' } : null;
    f.get('core/castLooks').readCastLooks = () => null;
    const authored = { schemaVersion: 1, characters: [{ role: 'char', tag: 'brown hair' }], sceneTags: 'solo, ring', flatPrompt: 'brown-haired Char wearing a ring' };
    f.get('core/cgVisualRules').normalizeGeneratedCgDraft = () => authored;
    const metadata = api.initialCgAppearanceMetadata({ cgPromptDraft: authored }, f.host);
    assert.equal(metadata.characters[0].tag, 'golden hair');
    assert.equal(metadata.flatPrompt, undefined);
    let reads = 0;
    api.captureCgAppearanceEvidence(f.host, { api: { apiVersion: 1, capabilities: { characterLibrary: true }, getCharacters() { reads++; return { apiVersion: 1, characters: [] }; } } });
    assert.equal(reads, 0);
});
test('preset provenance retains the own fallback and full long preset through metadata and reconceive', async () => {
    const f = await fixture(), api = f.get('generation/cgAppearance');
    const long = 'golden hair, '.repeat(46) + '<lora:identity:1>';
    f.get('core/settings').getPluginSettings = () => ({ imageGenerationProvider: 'chatu8-image' });
    f.get('core/castLooks').readCastLooks = () => ({ manual: true, char: 'own brown hair', user: 'own blue eyes' });
    f.get('generation/chatu8Presets').chatu8PresetAppearance = (_ctx, name) => name === 'Char' ? { tag: long, source: 'chatu8', presetKey: 'a' } : null;
    const metadata = api.initialCgAppearanceMetadata({}, f.host);
    const row = metadata.characters.find(row => row.role === 'char');
    assert.equal(row.tag, long);
    assert.equal(row.presetAppearance, true);
    assert.equal(row.fallbackTag, 'own brown hair');
    assert.equal(api.normalizeCgPromptMetadata(metadata).characters[0].tag, long);
    const evidence = api.appearanceEvidenceWithDraft(api.captureCgAppearanceEvidence(f.host, { selectedRoles: ['char'] }), { char: row }, f.host);
    assert.equal(evidence.characters[0].knownTag, long);
    const prepared = api.normalizeCgPreparedPrompt({ imagePrompt: 'Char wearing a ring', sceneTags: 'solo, ring',
        flatPrompt: 'Char wearing a ring', characters: [] }, evidence);
    assert.equal(prepared.characters[0].tag, long);
    assert.equal(prepared.characters[0].fallbackTag, 'own brown hair');
    f.get('generation/chatu8Presets').chatu8PresetAppearance = () => null;
    const fallback = api.appearanceEvidenceWithDraft(api.captureCgAppearanceEvidence(f.host, { selectedRoles: ['char'] }), { char: row }, f.host);
    assert.equal(fallback.characters[0].knownTag, 'own brown hair');
    assert.equal(fallback.characters[0].presetAppearance, undefined);
    const overridden = api.appearanceEvidenceWithDraft(fallback, { char: { ...row, tag: long + ', edited', appearanceOverride: true } }, f.host);
    assert.equal(overridden.characters[0].knownTag, long + ', edited');
    assert.equal(overridden.characters[0].appearanceOverride, true);
});
test('explicit scope drops stale generated flat/scene tags, but preserves manual complete prompt', async () => {
    const f = await fixture(), api = f.get('generation/cgAppearance');
    const raw = { characters: roles, selectedRoles: ['user'], sceneTags: '2boys', flatPrompt: 'Raphael brown hair and Kamael blonde hair' };
    const scoped = api.scopeCgPromptMetadata('Kamael wearing a ring', raw);
    assert.equal(scoped.flatPrompt, '');
    assert.equal(scoped.sceneTags, '');
    assert.equal(api.scopeCgPromptMetadata('Kamael wearing a ring', { ...raw, flatPromptOverride: true }).flatPrompt, raw.flatPrompt);
});
test('locally resolved cropped MV metadata and preset-prefilled editor values do not truncate at 400', async () => {
    const f = await fixture(), api = f.get('generation/cgAppearance'), editor = f.get('ui/cgPromptEditor');
    const tag = 'pale hands, '.repeat(50).trim();
    const normalized = api.normalizeCgPromptMetadata({ characters: [{ ...roles[1], tag, resolvedAppearance: true, appearanceOverride: true }] });
    assert.equal(normalized.characters[0].tag, tag);
    assert.equal(normalized.characters[0].resolvedAppearance, true);
    const fields = new Map([
        ['[data-rmt-cg-scene-tags]', { value: '' }], ['[data-rmt-cg-flat-prompt]', { value: '' }],
        ['[data-rmt-cg-tag-input="user"]', { value: tag }],
        ['[data-rmt-cg-role-selected="char"]', { checked: false }], ['[data-rmt-cg-role-selected="user"]', { checked: true }],
    ]);
    const metadata = editor.cgEditorPromptMetadata({ multi: false, characterNames: { user: 'Kamael' },
        appearanceSources: { user: { presetAppearance: true, fallbackTag: 'own golden hair', fallbackNl: '' } },
        element: { querySelector: selector => fields.get(selector) } });
    assert.equal(metadata.characters[0].tag, tag);
    assert.equal(metadata.characters[0].fallbackTag, 'own golden hair');
    assert.equal(metadata.characters[0].presetAppearance, true);
});
