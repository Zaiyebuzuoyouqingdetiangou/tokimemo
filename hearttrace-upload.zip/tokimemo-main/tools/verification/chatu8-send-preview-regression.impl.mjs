import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { EventEmitter } from 'node:events';
import { fixture } from './fixture.mjs';

async function setup(backend = 'novelai', model = 'nai-diffusion-4-5-full') {
    const f = await fixture(), requests = [], source = new EventEmitter();
    f.host.name2 = 'Raphael'; f.host.name1 = 'Kamael'; f.host.eventSource = source;
    f.host.extensionSettings['st-chatu8'] = { scriptEnabled: true, mode: backend, novelaimode: model, AI_use_coords: true,
        characterPresets: { r: { nameEN: 'Raphael', characterTraits: 'dark brown hair', facialFeatures: 'brown eyes' },
            k: { nameEN: 'Kamael', characterTraits: 'short blonde hair', facialFeatures: 'green eyes' } } };
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS,
        imageGenerationProvider: 'chatu8-image', imageGenerationFallback: false });
    f.sb.STBaiBaiImage = { apiVersion: 1, capabilities: { generate: true, saveToGallery: true },
        getBackendStatus: () => ({ configured: true, backend: 'nai', supportsCharacters: true }),
        generate: async () => { throw Error('wrong provider'); } };
    source.on('generate-image-request', request => { requests.push(request); source.emit('generate-image-response',
        { id: request.id, success: true, imageData: '/user/images/test.png' }); });
    return { ...f, requests, adapter: f.get('generation/chatu8Image'), actions: f.get('generation/cgImageActions') };
}
const metadata = () => ({ characters: [
    { role: 'char', name: 'Raphael', tag: 'OLD_R_HAIR' }, { role: 'user', name: 'Kamael', tag: 'OLD_K_HAIR' },
] });
const scene = "Raphael offers a ring to Kamael, two people under a spotlight";

for (const backend of ['novelai', 'sd', 'comfyui', 'banana', 'runninghub']) {
    test(`${backend}: preview equals actual event despite BaiBai installed, per-person presets replace old looks`, async () => {
        const f = await setup(backend), before = JSON.stringify(f.host.extensionSettings);
        for (const promptFormat of ['', 'nai45-tags', 'nai5-natural']) {
            const meta = { ...metadata(), sceneTags: scene, flatPrompt: 'OLD_GENERATED_FLAT', promptFormat };
            const sent = f.actions.cgEditorSendPreview(f.constants.MODE.ALBUM, {}, scene, meta, promptFormat, f.host);
            assert.equal(f.requests.length, ['', 'nai45-tags', 'nai5-natural'].indexOf(promptFormat), 'preview never generates');
            await f.get('generation/cgImageCore').invokeImageGeneration(scene, f.host, { promptMetadata: meta });
            assert.equal(f.requests.at(-1).prompt, sent.prompt);
            assert.match(sent.prompt, /short blonde hair/); assert.match(sent.prompt, /dark brown hair/);
            assert.doesNotMatch(sent.prompt, /OLD_|\$[^$]+\$/);
        }
        assert.equal(JSON.stringify(f.host.extensionSettings), before);
    });
}
test('missing or duplicate preset falls back only that person; no enabled-list guess', async () => {
    const f = await setup();
    const bag = f.host.extensionSettings['st-chatu8'];
    bag.characterPresets.k2 = { nameEN: 'Kamael', characterTraits: 'WRONG_RED_HAIR' };
    bag.characterEnablePresetId = 'active'; bag.characterEnablePresets = { active: { characters: ['k2'] } };
    let result = f.adapter.chatu8SendPreview(scene, { promptMetadata: metadata(), context: f.host }).prompt;
    assert.match(result, /dark brown hair/); assert.match(result, /OLD_K_HAIR/); assert.doesNotMatch(result, /blonde|WRONG_RED/);
    delete bag.characterPresets.k; delete bag.characterPresets.k2;
    result = f.adapter.chatu8SendPreview(scene, { promptMetadata: metadata(), context: f.host }).prompt;
    assert.match(result, /OLD_K_HAIR/); assert.match(result, /dark brown hair/);
});
test('explicit single-person selection cannot carry the other person or old generated flat prompt', async () => {
    const f = await setup(), meta = { ...metadata(), selectedRoles: ['user'], flatPrompt: 'OLD_R_HAIR, OLD_K_HAIR' };
    const result = f.adapter.chatu8SendPreview('Kamael, solo, wearing a ruby ring', { promptMetadata: meta, context: f.host }).prompt;
    assert.match(result, /short blonde hair/); assert.doesNotMatch(result, /Raphael|brown hair|OLD_R_HAIR|Character 2/);
});
test('explicit hand-edited tag and complete prompt remain authoritative', async () => {
    const f = await setup(), meta = metadata(); meta.characters[1].appearanceOverride = true;
    let result = f.adapter.chatu8SendPreview(scene, { promptMetadata: meta, context: f.host }).prompt;
    assert.match(result, /OLD_K_HAIR/); assert.doesNotMatch(result, /blonde/);
    meta.flatPrompt = 'hand-authored complete scene, KEEP EXACT'; meta.flatPromptOverride = true;
    result = f.adapter.chatu8SendPreview(scene, { promptMetadata: meta, context: f.host }).prompt;
    assert.equal(result, meta.flatPrompt);
    assert.equal(f.adapter.chatu8SendPreview('complete custom image', { context: f.host, preservePrompt: true }).prompt, 'complete custom image');
});
test('resolved long preset is not chopped at legacy appearance editor length', async () => {
    const f = await setup('comfyui');
    f.host.extensionSettings['st-chatu8'].characterPresets.k.characterTraits = 'stable visible feature, '.repeat(25) + 'END_IDENTITY_MARKER';
    const result = f.adapter.chatu8SendPreview(scene, { promptMetadata: metadata(), context: f.host }).prompt;
    assert.match(result, /END_IDENTITY_MARKER/);
});
test('same-name distinct participants use their own bound looks, not a name-matched preset', async () => {
    const f = await setup();
    const meta = { castSnapshot: { version: 1, people: [ { id: 'a', name: 'Kamael', sourceRefs: [] }, { id: 'b', name: 'Kamael', sourceRefs: [] } ] },
        characters: [{ participantId: 'a', tag: 'UNIQUE_A' }, { participantId: 'b', tag: 'UNIQUE_B' }] };
    const result = f.adapter.chatu8SendPreview('two different people', { promptMetadata: meta, context: f.host }).prompt;
    assert.match(result, /UNIQUE_A/); assert.match(result, /UNIQUE_B/); assert.doesNotMatch(result, /blonde/);
});
test('actual upstream NAI builder accepts one and two native character fields', async () => {
    // Reuse the existing contract test's upstream harness unchanged, not an
    // imitation parser. Network, queue and configuration are intercepted there.
    const helper = fs.readFileSync(new URL('./couple-avatar-provider-contract-regression.impl.mjs', import.meta.url), 'utf8');
    const start = helper.indexOf('const upstreamPath ='), end = helper.indexOf('\nasync function setup(');
    const sandbox = vm.createContext({ fs, vm, assert, process, AbortController, Date });
    vm.runInContext(helper.slice(start, end) + '\nglobalThis.runNative = nativeRequest;', sandbox);
    for (const selectedRoles of [['user'], ['char', 'user']]) {
        const f = await setup();
        const sent = f.adapter.chatu8SendPreview(scene, { promptMetadata: { ...metadata(), selectedRoles }, context: f.host });
        const actual = await sandbox.runNative(sent, { automaticCoordinates: true });
        const captions = actual.parameters.v4_prompt.caption.char_captions;
        assert.equal(captions.length, selectedRoles.length);
        assert.match(captions.at(-1).char_caption, /short blonde hair/);
        if (captions.length === 2) {
            assert.match(captions[0].char_caption, /dark brown hair/);
            assert.doesNotMatch(captions[0].char_caption, /blonde/);
            assert.doesNotMatch(captions[1].char_caption, /brown hair/);
        }
    }
});
test('manual-coordinate NAI configuration falls back locally without invented or empty centers', async () => {
    const f = await setup(); f.host.extensionSettings['st-chatu8'].AI_use_coords = false;
    await f.get('generation/cgImageCore').invokeImageGeneration(scene, f.host, { promptMetadata: metadata() });
    assert.equal(f.requests.length, 1);
    assert.doesNotMatch(f.requests[0].prompt, /Scene Composition:|centers:/);
    assert.match(f.requests[0].prompt, /Kamael：short blonde hair/);
});
test('prefilled preset fields cannot preserve a stale generated flat appearance', async () => {
    const f = await setup('comfyui');
    const meta = { characters: [{ role: 'user', name: 'Kamael', tag: 'short blonde hair, green eyes' }],
        flatPrompt: 'Kamael, brown hair, OLD_GENERATED_APPEARANCE' };
    const sent = f.adapter.chatu8SendPreview('Kamael wearing a ruby ring', { promptMetadata: meta, context: f.host });
    assert.match(sent.prompt, /short blonde hair/); assert.doesNotMatch(sent.prompt, /brown hair|OLD_GENERATED/);
});
test('removing a preset during editing restores original local tags without rewriting manual edits', async () => {
    const f = await setup('comfyui');
    const meta = { characters: [{ role: 'user', name: 'Kamael', tag: 'OLD_PRESET_BLOND',
        presetAppearance: true, fallbackTag: 'LOCAL_BLACK_HAIR', fallbackNl: '' }] };
    f.host.extensionSettings['st-chatu8'].characterPresets = {};
    const sent = f.adapter.chatu8SendPreview('Kamael wearing a ruby ring', { promptMetadata: meta, context: f.host });
    assert.match(sent.prompt, /LOCAL_BLACK_HAIR/); assert.doesNotMatch(sent.prompt, /OLD_PRESET_BLOND/);
});
test('explicit selection also drops an old generated flat channel without any presets', async () => {
    const f = await setup('comfyui'); f.host.extensionSettings['st-chatu8'].characterPresets = {};
    const meta = { ...metadata(), selectedRoles: ['user'], flatPrompt: 'Raphael OLD_R_HAIR and Kamael OLD_K_HAIR' };
    const sent = f.adapter.chatu8SendPreview('Kamael, solo', { promptMetadata: meta, context: f.host });
    assert.match(sent.prompt, /OLD_K_HAIR/); assert.doesNotMatch(sent.prompt, /OLD_R_HAIR|Raphael/);
});
test('partial appearance data never turns a two-person cast into a single native character slot', async () => {
    const f = await setup(); f.host.extensionSettings['st-chatu8'].characterPresets = {};
    const meta = { castSnapshot: { version: 1, people: [{ id: 'a', name: 'Known', sourceRefs: [] }, { id: 'b', name: 'Unknown', sourceRefs: [] }] },
        characters: [{ participantId: 'a', tag: 'black hair' }] };
    const sent = f.adapter.chatu8SendPreview('Known and Unknown, two people share tea', { promptMetadata: meta, context: f.host });
    assert.doesNotMatch(sent.prompt, /Scene Composition:/);
    assert.match(sent.prompt, /two people/); assert.match(sent.prompt, /black hair/);
});
