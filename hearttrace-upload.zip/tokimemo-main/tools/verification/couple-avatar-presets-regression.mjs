import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const root = process.env.TEST_ROOT || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const plain = value => JSON.parse(JSON.stringify(value));
const input = { people: [{ id: 'char', name: 'Kamael', appearance: 'LOCAL_LEFT' }, { id: 'user', name: 'Raphael', appearance: 'LOCAL_RIGHT' }] };
async function setup() {
    const context = { name2: 'Kamael', name1: 'Raphael', imageProvider: 'chatu8-image', extensionSettings: { 'st-chatu8': {
        characterPresets: { k: { nameEN: 'Kamael', characterTraits: '1boy, blonde hair, pale skin', facialFeatures: 'gold eyes' } },
    } } };
    const requests = [], environment = vm.createContext({ URL, console, setTimeout, clearTimeout });
    const stubs = {
        'core/context': { currentCharacterGuard: () => context, chatScopeKey: () => 'test-scope' },
        'core/castLooks': { readCastLooks: () => ({ char: 'LOCAL_LEFT', user: 'LOCAL_RIGHT', manual: true }), lookFromDescription: v => v || '' },
        'core/settings': { getPluginSettings: ctx => ({ imageGenerationProvider: ctx.imageProvider }) },
        'core/text': { safeUserError: (message, code) => Object.assign(new Error(message), { code, safeToDisplay: true }) },
        'generation/cgImageCore': { normalizeCgImageUrl: url => url, invokeImageGeneration: async (prompt, ctx, options) => {
            requests.push({ prompt, options }); return { url: 'https://example.test/image.png' };
        } },
        'core/cgImagePatch': { imageResourceBase: () => 'https://example.test/', isSameImageHost: () => true },
        'core/taskTrace': { startTaskTrace: () => ({}), beginStage() {}, markStage() {}, endTaskTrace() {} },
        'core/state': { state: { activeCoupleAvatarTasks: new Map() } },
    };
    const cache = new Map();
    async function load(id) {
        if (cache.has(id)) return cache.get(id);
        const stub = stubs[id];
        const loaded = stub
            ? new vm.SyntheticModule(Object.keys(stub), function () { for (const [key, value] of Object.entries(stub)) this.setExport(key, value); }, { context: environment, identifier: id })
            : new vm.SourceTextModule(await fs.readFile(path.join(root, 'src', id + '.js'), 'utf8'), { context: environment, identifier: id });
        cache.set(id, loaded);
        await loaded.link((specifier, parent) => load(path.posix.normalize(path.posix.join(path.posix.dirname(parent.identifier), specifier)).replace(/\.js$/, '')));
        return loaded;
    }
    const loaded = await load('extras/coupleAvatar'); await loaded.evaluate();
    return { core: loaded.namespace, context, requests };
}

test('default and normalized form use each matching preset and preserve the independent local fallback', async () => {
    const f = await setup(), before = JSON.stringify(input);
    const defaults = f.core.defaultCoupleSettings(f.context);
    assert.equal(defaults.people[0].appearance, '1boy, blonde hair, pale skin, gold eyes');
    assert.equal(defaults.people[0].fallbackAppearance, 'LOCAL_LEFT');
    assert.equal(defaults.people[1].appearance, 'LOCAL_RIGHT');
    const normalized = f.core.normalizeCoupleSettings(input, f.context);
    assert.deepEqual(plain(normalized.people), plain(defaults.people));
    assert.deepEqual(plain(f.core.normalizeCoupleSettings(normalized, f.context)), plain(normalized));
    assert.equal(JSON.stringify(input), before); assert.equal(f.requests.length, 0);
});

test('missing preset or selecting BaiBai restores local fallback without erasing it', async () => {
    const f = await setup(), normalized = f.core.normalizeCoupleSettings(input, f.context);
    f.context.imageProvider = 'baibai-image';
    const baibai = f.core.normalizeCoupleSettings(normalized, f.context);
    assert.deepEqual(plain(baibai.people), input.people);
    f.context.imageProvider = 'chatu8-image';
    delete f.context.extensionSettings['st-chatu8'].characterPresets.k;
    const missing = f.core.normalizeCoupleSettings(normalized, f.context);
    assert.deepEqual(plain(missing.people), input.people);
    assert.deepEqual(plain(f.core.normalizeCoupleSettings(missing, f.context)), plain(missing));
});

test('editing a displayed preset appearance is an explicit local override and survives normalization', async () => {
    const f = await setup(), normalized = f.core.normalizeCoupleSettings(input, f.context);
    normalized.people[0].appearance = 'MANUALLY_EDITED_WHITE_HAIR';
    const edited = f.core.normalizeCoupleSettings(normalized, f.context);
    assert.equal(edited.people[0].appearance, 'MANUALLY_EDITED_WHITE_HAIR');
    assert.equal(edited.people[0].appearanceOverride, true);
    assert.deepEqual(plain(f.core.normalizeCoupleSettings(edited, f.context)), plain(edited));
    assert.match(f.core.couplePrompt(edited, f.context), /MANUALLY_EDITED_WHITE_HAIR/);
    assert.doesNotMatch(f.core.couplePrompt(edited, f.context), /blonde hair/);
});

test('two same-name people never collapse into one provider preset even with normalized name variants', async () => {
    const f = await setup(), duplicate = { people: [input.people[0], { ...input.people[1], name: ' ＫＡＭＡＥＬ ' }] };
    const settings = f.core.normalizeCoupleSettings(duplicate, f.context);
    assert.equal(settings.people[0].appearance, 'LOCAL_LEFT');
    assert.equal(settings.people[1].appearance, 'LOCAL_RIGHT');
    assert.doesNotMatch(f.core.couplePrompt(duplicate, f.context), /blonde hair/);
});

test('preset identity is converted before animal or crafted style rendering; explicit direction stays', async () => {
    const f = await setup();
    const animal = f.core.couplePromptParts({ ...input, styleId: 'animal-cat', direction: 'keep my camera angle' }, f.context);
    assert.match(animal.prompt, /blonde fur markings/);
    assert.match(animal.prompt, /gold eyes/);
    assert.doesNotMatch(animal.prompt, /blonde hair|pale skin|LOCAL_LEFT|\b1boy\b/);
    assert.match(animal.prompt, /LOCAL_RIGHT|keep my camera angle/);
    assert.doesNotMatch(animal.nai.characters[0].tag, /blonde hair|\b1boy\b/);
    const clay = f.core.couplePromptParts({ ...input, styleId: 'craft-clay' }, f.context);
    assert.match(clay.prompt, /blonde hair/); assert.match(clay.prompt, /male crafted figure/);
    assert.doesNotMatch(clay.prompt, /\b1boy\b/);
    const custom = f.core.couplePrompt({ ...input, styleId: 'custom', customStyle: 'MY_STYLE', direction: 'MY_DIRECTION' }, f.context);
    assert.match(custom, /MY_STYLE/); assert.match(custom, /MY_DIRECTION/);
});

test('generation and preview share resolved tags; one request preserves aspect ratio and original input', async () => {
    const f = await setup(), before = JSON.stringify(input);
    const preview = f.core.couplePrompt(input, f.context);
    const saved = await f.core.generateCouple(input, { context: f.context });
    assert.equal(f.requests.length, 1); assert.equal(f.requests[0].prompt, preview);
    assert.equal(f.requests[0].options.aspectRatio, '2:1'); assert.equal(f.requests[0].options.preservePrompt, true);
    assert.match(f.requests[0].options.avatarPromptParts.nai.characters[0].tag, /blonde hair/);
    assert.doesNotMatch(f.requests[0].options.avatarPromptParts.nai.characters[1].tag, /blonde hair/);
    assert.equal(saved.record.settings.people[0].fallbackAppearance, 'LOCAL_LEFT');
    assert.equal(JSON.stringify(input), before);
});

test('contextless storage/history normalization preserves the frozen identity without re-reading a changed preset', async () => {
    const f = await setup(), saved = f.core.normalizeCoupleSettings(input, f.context);
    const before = JSON.stringify(saved);
    f.context.extensionSettings['st-chatu8'].characterPresets.k.characterTraits = 'purple hair';
    assert.equal(JSON.stringify(f.core.normalizeCoupleSettings(saved, null)), before);
    assert.match(f.core.couplePrompt(saved, null), /blonde hair/);
    assert.doesNotMatch(f.core.couplePrompt(saved, null), /purple hair/);
    assert.equal(f.requests.length, 0);
});

test('BaiBai and unavailable presets retain existing literal appearance including explicit blanks', async () => {
    const f = await setup(); f.context.imageProvider = 'baibai-image';
    assert.deepEqual(plain(f.core.normalizeCoupleSettings(input, f.context).people), input.people);
    f.context.imageProvider = 'chatu8-image'; f.context.extensionSettings = {};
    assert.deepEqual(plain(f.core.normalizeCoupleSettings(input, f.context).people), input.people);
    const blanks = { people: [{ name: '', appearance: '' }, { name: '', appearance: '' }] };
    const normalized = f.core.normalizeCoupleSettings(blanks, f.context);
    assert.ok(normalized.people.every(row => row.appearance === ''));
    await f.core.generateCouple(blanks, { context: f.context }); assert.equal(f.requests.length, 1);
});
