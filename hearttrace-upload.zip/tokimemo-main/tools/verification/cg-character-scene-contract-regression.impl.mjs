import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { EventEmitter } from 'node:events';
import { createHash } from 'node:crypto';
import { fixture } from './fixture.mjs';

// Use real provider parameter builders already captured for earlier contracts.
// Only configuration/storage and the network boundary are isolated. These tests
// prove transmitted data and persistence, not stochastic generated image quality.
const root = path.resolve(process.env.TEST_ROOT || '.');
const plain = value => JSON.parse(JSON.stringify(value));
async function contractHarness(filename, boundary, exportName) {
    let source = fs.readFileSync(path.join(root, 'tools/verification', filename), 'utf8');
    const end = source.indexOf(boundary);
    assert.ok(end > 0, 'existing upstream contract boundary is present');
    source = source.slice(0, end) + `\nexport { ${exportName} };`;
    const context = vm.createContext({ console, process, URL, AbortController, setTimeout, clearTimeout, Buffer, structuredClone });
    const module = new vm.SourceTextModule(source, { context, identifier: filename });
    await module.link(async specifier => {
        const values = specifier === './fixture.mjs' ? { fixture } : await import(specifier);
        return new vm.SyntheticModule(Object.keys(values), function () {
            for (const [key, value] of Object.entries(values)) this.setExport(key, value);
        }, { context });
    });
    await module.evaluate();
    return module.namespace[exportName];
}
const nativeChatu8Request = await contractHarness('chatu8-nai45-negatives-contract-regression.impl.mjs', "test('actual upstream", 'nativeRequest');
const nativeBaiBaiProvider = await contractHarness('couple-avatar-baibai-regression.impl.mjs', 'const people =', 'provider');

const sceneFor = format => format === 'nai45-tags' ? '2people, garden, standing, hugging' : 'Alex hugs Beth from behind in the garden.';
const actorRows = () => [
    { role: 'char', name: 'Alex', tag: '{{brown hair}}, brown eyes', nl: '',
        sceneTag: 'source#hug, standing behind partner, black coat',
        sceneNl: 'Standing behind the other person, hugging them, wearing a black coat.' },
    { role: 'user', name: 'Beth', tag: '{{blonde hair}}, green eyes', nl: '',
        sceneTag: 'target#hug, standing in front of partner, white robe',
        sceneNl: 'Standing in front of the other person, receiving their hug, wearing a white robe.' },
];
const metadataFor = format => ({ promptFormat: format, selectedRoles: ['char', 'user'], sceneTags: sceneFor(format), characters: actorRows() });
const presetsFor = () => ({
    alex: { nameEN: 'Alex', characterTraits: '{{silver hair}}', facialFeatures: 'blue eyes', negative: 'brown hair, brown eyes' },
    beth: { nameEN: 'Beth', characterTraits: '{{red hair}}', facialFeatures: 'violet eyes', negative: 'blonde hair, green eyes' },
});

async function setup(provider, format, { native = true, presets = true } = {}) {
    const f = await fixture(), requests = [], eventSource = new EventEmitter();
    const model = format === 'nai45-tags' ? 'nai-diffusion-4-5-full' : 'nai-diffusion-5-full';
    f.host.name2 = 'Alex'; f.host.name1 = 'Beth'; f.host.eventSource = eventSource;
    f.host.extensionSettings['st-chatu8'] = { scriptEnabled: true, mode: 'novelai', novelaimode: model,
        AI_use_coords: native, client: 'api', characterPresets: presets ? presetsFor() : {} };
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS,
        imageGenerationProvider: provider, imageGenerationFallback: false, cgPromptFormat: format });
    let paidTextCalls = 0;
    f.get('generation/client').requestJson = () => { paidTextCalls++; throw Error('Unexpected paid text request'); };
    const upstream = provider === 'baibai-image' ? await nativeBaiBaiProvider(model) : null;
    let library = presets ? [ { name: 'Alex', tag: '{{silver hair}}, blue eyes' }, { name: 'Beth', tag: '{{red hair}}, violet eyes' } ] : [];
    if (upstream) {
        f.sb.STBaiBaiImage = { ...upstream.api,
            capabilities: { ...upstream.api.capabilities, characterLibrary: true },
            getBackendStatus: () => ({ ...upstream.api.getBackendStatus(), supportsCharacters: native }),
            getCharacters: () => ({ apiVersion: 1, characters: library }),
            generate: (request, options) => { requests.push(plain(request)); return upstream.api.generate(request, options); },
        };
    } else {
        eventSource.on('generate-image-request', request => {
            requests.push(plain(request));
            eventSource.emit('generate-image-response', { id: request.id, success: true, imageData: '/user/images/cg-scene-contract.png' });
        });
    }
    return { ...f, requests, nativeParameters: () => upstream ? plain(upstream.actual()) : null, library: value => { library = value; }, async send(metadata, scene = sceneFor(format)) {
        const count = requests.length;
        const preview = f.get('generation/cgImageActions').cgEditorSendPreview(f.constants.MODE.ALBUM, {}, scene, metadata, format, f.host);
        assert.equal(requests.length, count, 'preview is read-only');
        await f.get('generation/cgImageCore').invokeImageGeneration(scene, f.host, { promptMetadata: metadata });
        assert.equal(requests.length, count + 1, 'one image action sends one image request');
        assert.equal(paidTextCalls, 0, 'per-character actions require no extra text call');
        const event = requests.at(-1);
        for (const key of provider === 'chatu8-image' ? ['prompt', 'negative_prompt'] : ['prompt', 'nl', 'characters', 'negative']) {
            assert.deepEqual(event[key], plain(preview)[key], 'preview/send channel: ' + key);
        }
        const actual = upstream ? plain(upstream.actual()) : (await nativeChatu8Request(event, {
            model, automaticCoordinates: native, presets: f.host.extensionSettings['st-chatu8'].characterPresets,
        })).parameters;
        return { request: event, actual, captions: actual.v4_prompt.caption.char_captions.map(row => row.char_caption) };
    } };
}

function assertActorBindings(captions, format, { preset = true } = {}) {
    assert.equal(captions.length, 2);
    assert.match(captions[0], preset ? /silver hair/ : /brown hair/);
    assert.match(captions[1], preset ? /red hair/ : /blonde hair/);
    assert.match(captions[0], /black coat/); assert.doesNotMatch(captions[0], /white robe|target#hug|receiving their hug/);
    assert.match(captions[1], /white robe/); assert.doesNotMatch(captions[1], /black coat|source#hug|hugging them/);
    if (format === 'nai45-tags') {
        assert.match(captions[0], /source#hug/); assert.match(captions[1], /target#hug/);
        assert.doesNotMatch(captions.join(' '), /Standing behind the other person|receiving their hug/);
    } else {
        assert.match(captions[0], /Standing behind the other person, hugging them/);
        assert.match(captions[1], /Standing in front of the other person, receiving their hug/);
        assert.doesNotMatch(captions.join(' '), /source#hug|target#hug/);
    }
}

for (const provider of ['chatu8-image', 'baibai-image']) for (const format of ['nai45-tags', 'nai5-natural']) {
    test(`${provider}/${format}: actual native captions preserve role-owned actions when presets replace appearances and input order is reversed`, async () => {
        const f = await setup(provider, format), metadata = metadataFor(format);
        metadata.characters.reverse();
        const before = JSON.stringify(metadata), beforeSettings = JSON.stringify(f.host.extensionSettings);
        const sent = await f.send(metadata);
        assertActorBindings(sent.captions, format);
        if (provider === 'baibai-image' && format === 'nai45-tags') {
            assert.equal(sent.request.nl, '');
            assert.ok(sent.request.characters.every(row => !row.nl), 'tag format never emits natural action prose');
        }
        if (provider === 'chatu8-image') {
            assert.deepEqual(plain(sent.actual.v4_negative_prompt.caption.char_captions.map(row => row.char_caption)),
                ['brown hair, brown eyes', 'blonde hair, green eyes']);
        }
        assert.equal(JSON.stringify(metadata), before, 'sending cannot rewrite saved per-image actions');
        assert.equal(JSON.stringify(f.host.extensionSettings), beforeSettings, 'sending cannot alter provider settings');
    });

    test(`${provider}/${format}: manually authored identity and action literals override presets without leaking the other person`, async () => {
        const f = await setup(provider, format), metadata = metadataFor(format);
        metadata.characters.forEach(row => { row.appearanceOverride = true; });
        const sent = await f.send(metadata);
        assertActorBindings(sent.captions, format, { preset: false });
        assert.match(sent.captions[0], /\{\{brown hair\}\}/);
        assert.doesNotMatch(sent.captions.join(' '), /silver hair|red hair|violet eyes/);
        if (provider === 'chatu8-image') assert.ok(sent.actual.v4_negative_prompt.caption.char_captions.every(row => !row.char_caption));
    });

    test(`${provider}/${format}: unsupported native separation keeps each person's appearance and action together on its own flat line`, async () => {
        const f = await setup(provider, format, { native: false }), metadata = metadataFor(format);
        metadata.characters[0].name = '小林'; metadata.characters[1].name = '小雪';
        // These are intentionally local identities: the provider names no
        // longer match and must not infer a replacement from array position.
        const scene = format === 'nai45-tags' ? sceneFor(format) : '两人在花园里拥抱。';
        const sent = await f.send(metadata, scene);
        const lines = sent.request.prompt.split('\n').filter(Boolean);
        const first = lines.find(line => /brown hair/.test(line));
        const second = lines.find(line => /blonde hair/.test(line));
        assert.ok(first && second && first !== second, 'flat prompt has one separately bound line per person');
        assert.match(first, /black coat/); assert.doesNotMatch(first, /blonde hair|white robe/);
        assert.match(second, /white robe/); assert.doesNotMatch(second, /brown hair|black coat/);
        if (format === 'nai45-tags') {
            assert.doesNotMatch(sent.request.prompt, /小林|小雪|人物外貌|Scene Composition:|Character \d+ Prompt:/);
            assert.match(first, /source#hug/); assert.match(second, /target#hug/);
        } else { assert.match(first, /小林/); assert.match(second, /小雪/); }
        assert.equal(sent.actual.v4_prompt.caption.char_captions.length, 0);
    });
}

test('metadata, image persistence and reopen retain optional action fields without making them stable appearance', async () => {
    const f = await fixture(), api = f.get('generation/cgAppearance'), raw = metadataFor('nai5-natural');
    const normalized = api.normalizeCgPromptMetadata(raw);
    assert.deepEqual(plain(normalized.characters), actorRows());
    const image = f.get('generation/cgImageCore').normalizeCgImageRecord({
        url: '/user/images/scene.png', prompt: sceneFor('nai5-natural'), provider: 'chatu8-image', promptMetadata: normalized,
    });
    assert.ok(image, 'valid local image record survives');
    const reopened = api.initialCgAppearanceMetadata({ cgImage: plain(image) }, f.host);
    assert.deepEqual(plain(reopened.characters), actorRows());
    const legacy = { sceneTags: 'solo, garden', characters: [{ role: 'char', name: 'Alex', tag: 'brown hair', nl: '' }] };
    assert.deepEqual(plain(api.normalizeCgPromptMetadata(legacy)), legacy, 'legacy signatures gain no empty scene fields');
});

test('reconceive accepts optional per-person actions with known presets, and still accepts old drafts with no scene fields', async () => {
    const f = await fixture(), api = f.get('generation/cgAppearance');
    const evidence = { characters: actorRows().map(row => ({ role: row.role, name: row.name,
        knownTag: row.tag, knownNl: '', presetAppearance: true, negative: row.role === 'char' ? 'red hair' : 'brown hair' })) };
    const raw = { imagePrompt: sceneFor('nai5-natural'), sceneTags: sceneFor('nai45-tags'), flatPrompt: 'Two people embracing in a garden.', characters: actorRows() };
    const prepared = api.normalizeCgPreparedPrompt(raw, evidence);
    for (let i = 0; i < 2; i++) {
        assert.equal(prepared.characters[i].sceneTag, raw.characters[i].sceneTag);
        assert.equal(prepared.characters[i].sceneNl, raw.characters[i].sceneNl);
        assert.equal(prepared.characters[i].tag, evidence.characters[i].knownTag);
        assert.equal(prepared.characters[i].negative, evidence.characters[i].negative);
    }
    raw.characters = raw.characters.map(({ sceneTag, sceneNl, ...row }) => row);
    const old = api.normalizeCgPreparedPrompt(raw, evidence);
    assert.equal(old.characters.length, 2);
    assert.ok(old.characters.every(row => !Object.hasOwn(row, 'sceneTag') && !Object.hasOwn(row, 'sceneNl')));
});

for (const schemaVersion of [1, 2]) test(`generated draft schema ${schemaVersion} retains per-picture actions through source normalization`, async () => {
    const f = await fixture(), key = schemaVersion === 1 ? 'role' : 'participantId';
    const actors = actorRows().map((row, i) => ({ [key]: schemaVersion === 1 ? row.role : 'person-' + i,
        tag: row.tag.replaceAll('{', '').replaceAll('}', ''), nl: '', sceneTag: row.sceneTag, sceneNl: row.sceneNl }));
    const raw = { schemaVersion, sceneTags: sceneFor('nai45-tags'), flatPrompt: 'Two people hug in the garden.', characters: actors };
    const normalized = f.get('core/cgVisualRules').normalizeGeneratedCgDraft(f.json(raw));
    assert.ok(normalized);
    assert.deepEqual(plain(normalized.characters), actors);
    const without = { ...raw, characters: actors.map(({ sceneTag, sceneNl, ...row }) => row) };
    assert.deepEqual(plain(f.get('core/cgVisualRules').normalizeGeneratedCgDraft(f.json(without))), without,
        'optional actions do not change old generated drafts');
});

for (const provider of ['chatu8-image', 'baibai-image']) test(`${provider}: same-name people remain ID-bound even when action input order is reversed`, async () => {
    const f = await setup(provider, 'nai45-tags');
    const metadata = { promptFormat: 'nai45-tags', castSnapshot: { version: 1, people: [
        { id: 'id-a', name: 'Alex', sourceRefs: [] }, { id: 'id-b', name: 'Alex', sourceRefs: [] },
    ] }, characters: actorRows().map((row, i) => ({ participantId: i === 0 ? 'id-a' : 'id-b',
        tag: row.tag, nl: '', sceneTag: row.sceneTag, sceneNl: row.sceneNl })).reverse() };
    const sent = await f.send(metadata);
    assertActorBindings(sent.captions, 'nai45-tags', { preset: false });
    assert.doesNotMatch(sent.captions.join(' '), /silver hair|red hair/);
});

test('current Chatu8 preset positive/negative updates cannot erase a saved action, and removal restores appearance only', async () => {
    const f = await setup('chatu8-image', 'nai45-tags'), api = f.get('generation/cgAppearance');
    const frozen = api.resolveCgAppearanceMetadata(f.host, metadataFor('nai45-tags'));
    const preset = f.host.extensionSettings['st-chatu8'].characterPresets.alex;
    preset.characterTraits = '{{golden hair}}'; preset.negative = 'purple eyes';
    let sent = await f.send(frozen);
    assert.match(sent.captions[0], /golden hair.*source#hug.*black coat/);
    assert.equal(sent.actual.v4_negative_prompt.caption.char_captions[0].char_caption, 'purple eyes');
    delete f.host.extensionSettings['st-chatu8'].characterPresets.alex;
    sent = await f.send(frozen);
    assert.match(sent.captions[0], /brown hair.*source#hug.*black coat/);
    assert.doesNotMatch(sent.captions[0], /silver hair|golden hair/);
    assert.equal(sent.actual.v4_negative_prompt.caption.char_captions[0].char_caption, '');
});

test('NAI5 action fallback accepts a legacy tag-only action without forcing conversion or requesting a model', async () => {
    for (const provider of ['chatu8-image', 'baibai-image']) {
        const f = await setup(provider, 'nai5-natural'), metadata = metadataFor('nai5-natural');
        metadata.characters.forEach(row => { delete row.sceneNl; });
        const sent = await f.send(metadata);
        assert.match(sent.captions[0], /source#hug.*black coat/);
        assert.match(sent.captions[1], /target#hug.*white robe/);
    }
});

for (const multi of [false, true]) for (const format of ['nai45-tags', 'nai5-natural']) {
    test(`${multi ? 'participant' : 'legacy'} editor/${format}: explicit per-picture action edit preserves identity/preset provenance and emits the selected dialect`, async () => {
        const f = await fixture(), fields = new Map(), literal = format === 'nai45-tags'
            ? '{{source#hug}}, standing behind partner, black coat'
            : '手填：站在对方身后，双臂环抱对方，穿黑色外套。';
        f.get('core/settings').getPluginSettings = () => ({ imageGenerationProvider: 'chatu8-image' });
        fields.set('[data-rmt-cg-scene-tags]', { value: '2people, garden' });
        fields.set('[data-rmt-cg-flat-prompt]', { value: '' });
        fields.set('[data-rmt-cg-role-selected="char"]', { checked: true });
        fields.set('[data-rmt-cg-role-selected="user"]', { checked: false });
        fields.set('[data-rmt-cg-tag-input="char"]', { value: '{{silver hair}}' });
        fields.set('[data-rmt-cg-scene-action="char"]', { value: literal });
        fields.set('[data-rmt-cg-scene-action="0"]', { value: literal });
        fields.set('[data-rmt-cg-person-selected="0"]', { checked: true });
        fields.set('[data-rmt-cg-person-name="0"]', { value: 'Alex' });
        fields.set('[data-rmt-cg-person-tag="0"]', { value: '{{silver hair}}' });
        fields.set('[data-rmt-cg-person-nl="0"]', { value: '' });
        const key = multi ? 'id-a' : 'char';
        const current = { multi, promptFormat: format, characterNames: { char: 'Alex', user: 'Beth' }, appearanceEdited: {},
            appearanceSources: { [key]: { presetAppearance: true, negative: 'brown hair', fallbackTag: '{{brown hair}}' } },
            people: [{ id: 'id-a', name: 'Alex', sourceRefs: [], selected: true, tag: '{{silver hair}}', nl: '' }],
            element: { querySelector: selector => fields.get(selector) || null },
        };
        const result = f.get('ui/cgPromptEditor').cgEditorPromptMetadata(current), row = result.characters[0];
        assert.equal(row[format === 'nai45-tags' ? 'sceneTag' : 'sceneNl'], literal);
        assert.equal(row.tag, '{{silver hair}}'); assert.equal(row.negative, 'brown hair');
        assert.equal(row.presetAppearance, true); assert.equal(row.appearanceOverride, undefined);
        assert.equal(result.characters.length, 1);
    });
}

for (const provider of ['chatu8-image', 'baibai-image']) test(`${provider}: a known per-picture action is kept when that actor has no appearance evidence`, async () => {
    const f = await setup(provider, 'nai45-tags', { presets: false }), metadata = metadataFor('nai45-tags');
    metadata.characters[0].tag = ''; metadata.characters[0].nl = '';
    const normalized = f.get('generation/cgAppearance').normalizeCgPromptMetadata(metadata);
    assert.equal(normalized.characters.length, 2, 'missing appearance does not erase an evidenced picture action');
    assert.equal(normalized.characters[0].tag, '');
    assert.equal(normalized.characters[0].sceneTag, actorRows()[0].sceneTag);
    const sent = await f.send(metadata);
    const all = [sent.actual.v4_prompt.caption.base_caption, ...sent.captions].join('\n');
    assert.match(all, /source#hug.*black coat/s); assert.match(all, /target#hug.*white robe/s);
    assert.doesNotMatch(all, /silver hair|red hair|brown hair/, 'unknown features are not inferred');
});

test('main scene editing can clear stale per-character actions while a format-only change preserves literal drafts', async () => {
    const f = await fixture(), api = f.get('generation/cgAppearance'), metadata = metadataFor('nai45-tags');
    const retained = api.metadataAfterSceneEdit(metadata);
    assert.equal(retained.characters[0].sceneTag, metadata.characters[0].sceneTag);
    assert.equal(retained.characters[0].sceneNl, metadata.characters[0].sceneNl);
    const cleared = api.metadataAfterSceneEdit(metadata, { clearCharacterScene: true });
    assert.equal(cleared.characters[0].tag, metadata.characters[0].tag);
    assert.ok(cleared.characters.every(row => !row.sceneTag && !row.sceneNl));
    assert.ok(!cleared.flatPrompt, 'stale composed prompt cannot reinject the old actions');
});

const journalPeople = [ { participantId: 'id-a', name: 'Alex', tag: 'brown hair', nl: '' },
    { participantId: 'id-b', name: 'Beth', tag: 'blonde hair', nl: '' } ];
const journalLooks = 'Alex: brown hair\nBeth: blonde hair';
// Independently captured from the delivered 1.0.53 bundle before changing this
// suite. Old resumed requests must keep these hashes, not gain new instructions.
const oldJournalHashes = {
    'r84166/nai45-tags': '7fb13c7f60717e0fc3c4fb8f35c5234dd4f51c84264a32e8e2e08aad79d356fc',
    'r84166/nai5-natural': '33c9925658d4cce2dd287ef2284f3eb37601004053e60781d9a25d90761fa73b',
    'r84168/nai45-tags': '8e4e5494c3099dde9f8f74d4da01dd877c696531aebd1625691e271f197b526d',
    'r84168/nai5-natural': 'e808c68c643a1d77b57ab2ed6f4b0735e53836b3dcf0cc9c0f3ddecff470e945',
};
test('new ordinary and participant generation journals opt into the action recipe without extra requests', async () => {
    const f = await fixture(), policy = f.get('generation/cgPromptPolicy');
    for (const participant of [false, true]) for (const format of ['nai45-tags', 'nai5-natural']) {
        const operation = policy.cgRecoveryOperation('album', { kind: 'mode' }, null, format, journalLooks,
            participant ? journalPeople : null);
        assert.equal(operation.cgPromptDialect, participant ? 'r84168-actions' : 'r84166-actions');
        assert.equal(operation.cgPromptFormat, format);
        const origin = {};
        policy.bindCgPromptFormat(origin, format, operation.cgPromptDialect, operation.cgCastLooks, operation.cgParticipantLooks);
        const prompt = policy.cgPromptForSegment('BASELINE_SCENE_PROMPT', { origin, mode: 'album', taskKey: 'contract:album' });
        assert.match(prompt, /CG_CHARACTER_SCENE_V1/);
        assert.match(prompt, /sceneTag[\s\S]*sceneNl/);
        assert.match(prompt, /source#hug[\s\S]*target#hug/);
        assert.equal((prompt.match(/CG_CHARACTER_SCENE_V1/g) || []).length, 1);
        assert.equal(policy.cgPromptForSegment('UNRELATED', { origin, mode: 'room', taskKey: 'contract:room' }), 'UNRELATED');
    }
});

test('resumed r84166/r84168 journals keep 1.0.53 prompt hashes and never pick up new action instructions', async () => {
    const f = await fixture(), policy = f.get('generation/cgPromptPolicy');
    for (const dialect of ['r84166', 'r84168']) for (const format of ['nai45-tags', 'nai5-natural']) {
        const original = { kind: 'mode', cgPromptFormat: format, cgPromptDialect: dialect,
            ...(dialect === 'r84166' ? { cgCastLooks: journalLooks } : { cgParticipantLooks: journalPeople }) };
        const resumed = policy.cgRecoveryOperation('album', { kind: 'mode' }, { operation: original },
            format === 'nai45-tags' ? 'nai5-natural' : 'nai45-tags', 'CHANGED CURRENT APPEARANCE', []);
        assert.deepEqual(plain(resumed), original);
        const origin = {};
        policy.bindCgPromptFormat(origin, resumed.cgPromptFormat, resumed.cgPromptDialect, resumed.cgCastLooks, resumed.cgParticipantLooks);
        const prompt = policy.cgPromptForSegment('BASELINE_SCENE_PROMPT', { origin, mode: 'album', taskKey: 'contract:album' });
        assert.doesNotMatch(prompt, /CG_CHARACTER_SCENE_V1/);
        assert.equal(createHash('sha256').update(prompt).digest('hex'), oldJournalHashes[`${dialect}/${format}`]);
    }
});

test('BaiBai formatless compatible native path retains per-character actions in actual upstream captions', async () => {
    const f = await setup('baibai-image', '', { presets: false });
    const metadata = { sceneTags: sceneFor('nai45-tags'), characters: actorRows() };
    const preview = f.get('generation/baibaiImage').baiBaiSendPreview(sceneFor('nai5-natural'), { promptMetadata: metadata, context: f.host });
    assert.equal(f.requests.length, 0);
    await f.sb.STBaiBaiImage.generate(preview);
    assert.equal(f.requests.length, 1);
    assertActorBindings(f.nativeParameters().v4_prompt.caption.char_captions.map(row => row.char_caption), 'nai5-natural', { preset: false });
});

for (const provider of ['chatu8-image', 'baibai-image']) test(`${provider}: differently gendered manually supplied appearances retain independent actions in both NAI formats`, async () => {
    for (const format of ['nai45-tags', 'nai5-natural']) {
        const f = await setup(provider, format), metadata = metadataFor(format);
        metadata.characters[0].tag = '1boy, ' + metadata.characters[0].tag;
        metadata.characters[1].tag = '1girl, ' + metadata.characters[1].tag;
        metadata.characters.forEach(row => { row.appearanceOverride = true; });
        const sent = await f.send(metadata);
        assertActorBindings(sent.captions, format, { preset: false });
        // BaiBai removes the redundant count prefix in each individual NAI
        // caption; either upstream spelling still identifies the right person.
        assert.match(sent.captions[0], /\b(?:1)?boy\b/); assert.doesNotMatch(sent.captions[0], /\b(?:1)?girl\b/);
        assert.match(sent.captions[1], /\b(?:1)?girl\b/); assert.doesNotMatch(sent.captions[1], /\b(?:1)?boy\b/);
    }
});
