import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';
import { fixture } from './fixture.mjs';

const root = path.resolve(process.env.TEST_ROOT || '.');
const plain = value => JSON.parse(JSON.stringify(value));
const png = index => 'data:image/png;base64,' + [
    'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Wl6tZkAAAAASUVORK5CYII=',
    'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=',
][index];

class Element {
    constructor(kind = 'div') { this.kind = kind; this.children = []; this.events = new Map(); this.nodes = new Map(); this.dataset = {}; this.value = ''; this.disabled = false; this.isConnected = true; }
    set innerHTML(value) {
        this.html = value; this.nodes.clear();
        if (value.includes('rmt-pair-sheet-body')) this.nodes.set('.rmt-pair-sheet-body', new Element());
        for (const marker of ['close', 'avatar-apply', 'avatar-swap', 'avatar-restore', 'avatar-status', 'reimport']) {
            if (value.includes('data-pair-' + marker)) this.nodes.set(`[data-pair-${marker}]`, new Element('button'));
        }
        this.selectors = [...value.matchAll(/<select data-pair-avatar-role="([01])"[^>]*>([\s\S]*?)<\/select>/g)].map(match => {
            const node = new Element('select'); node.dataset.pairAvatarRole = match[1];
            node.value = /<option value="(char|user)" selected/.exec(match[2])?.[1] || ''; return node;
        });
    }
    get innerHTML() { return this.html || ''; }
    querySelector(selector) { return this.nodes.get(selector) || null; }
    querySelectorAll(selector) { return selector === '[data-pair-avatar-role]' ? this.selectors || [] : []; }
    addEventListener(type, fn) { const list = this.events.get(type) || []; list.push(fn); this.events.set(type, list); }
    removeEventListener() {}
    async emit(type) { for (const fn of this.events.get(type) || []) await fn({ target: this, preventDefault() {}, stopPropagation() {} }); }
    append(node) { this.children.push(node); }
    closest() { return null; }
    focus() {}
    remove() { this.isConnected = false; }
}

async function setup({ realStore = false } = {}) {
    const f = await fixture();
    f.sb.atob = globalThis.atob;
    const calls = { crop: [], saved: [], cleared: [], image: 0, text: 0, load: 0 };
    let snapshot = null, loadHook = null, clearHook = null;
    const scope = context => JSON.stringify([context.chatId, context.characterId, context.name2, context.name1, context.userAvatar || '']);
    const store = {
        chatAvatarScope: scope,
        readChatAvatarSnapshot: () => snapshot,
        loadChatAvatarSnapshot: async context => { calls.load++; if (loadHook) await loadHook(); return snapshot; },
        saveChatAvatarPair: async (pair, { context, expectedScope }) => {
            assert.equal(scope(f.host), expectedScope); assert.equal(scope(context), expectedScope);
            calls.saved.push(plain(pair)); snapshot = { version: 1, scope: expectedScope, revision: '1', ...plain(pair) }; return snapshot;
        },
        clearChatAvatarPair: async ({ context, expectedScope }) => {
            assert.equal(scope(f.host), expectedScope); assert.equal(scope(context), expectedScope);
            if (clearHook) await clearHook();
            calls.cleared.push(expectedScope); snapshot = null; return null;
        },
    };
    const shell = new Element(), notices = [{ textContent: '' }];
    f.sb.document.createElement = kind => {
        if (kind !== 'canvas') return new Element(kind);
        let half;
        return { getContext: () => ({ drawImage: (...args) => { calls.crop.push(args.slice(1)); half = args[1] >= 100 ? 1 : 0; } }), toDataURL: () => png(half) };
    };
    f.get('generation/cgImageCore').invokeImageGeneration = () => { calls.image++; throw Error('not allowed'); };
    f.get('generation/client').requestJson = () => { calls.text++; throw Error('not allowed'); };
    f.sb.confirm = () => true;
    const modules = new Map();
    async function load(id) {
        if (modules.has(id)) return modules.get(id);
        const fresh = ['extras/coupleAvatarApply', 'ui/coupleAvatarView'].includes(id) || realStore && id === 'core/chatAvatarStore';
        let module;
        if (fresh) {
            let source = await fs.readFile(path.join(root, 'src', id + '.js'), 'utf8');
            if (id === 'ui/coupleAvatarView') source += '\nexport { showApplyChatAvatars, restoreChatAvatars, handleAction, renderPreview }; export function activateForTest(view) { active = view; } export function dialogForTest() { return modal; }';
            module = new vm.SourceTextModule(source, { context: vm.createContext(f.sb), identifier: id });
        } else {
            const exports = id === 'core/chatAvatarStore' ? store : f.get(id);
            assert.ok(exports, id);
            module = new vm.SyntheticModule(Object.keys(exports), function () { for (const [key, value] of Object.entries(exports)) this.setExport(key, value); }, { context: vm.createContext(f.sb), identifier: id });
        }
        modules.set(id, module);
        await module.link((specifier, parent) => load(path.posix.normalize(path.posix.join(path.posix.dirname(parent.identifier), specifier)).replace(/\.js$/, '')));
        return module;
    }
    const helper = await load('extras/coupleAvatarApply'); await helper.evaluate();
    const ui = await load('ui/coupleAvatarView'); await ui.evaluate();
    const record = { id: 'pair', original: { url: '/original.png', width: 200, height: 100 }, order: [1, 0], crops: [{ zoom: 1, x: 0, y: 0 }, { zoom: 1, x: 0, y: 0 }],
        settings: { people: [{ id: 'char', name: 'Char', appearance: 'black hair' }, { id: 'user', name: 'User', appearance: 'blonde hair' }] } };
    const loaded = { image: {}, croppable: true, width: 200, height: 100 };
    const view = { currentId: 'pair', records: [record], settings: plain(record.settings), context: f.host, scope: f.get('extras/coupleAvatar').coupleScope(f.host),
        root: { isConnected: true, closest: () => shell, querySelector: () => null, querySelectorAll: () => notices }, host: { hidden: false }, images: new Map([['/original.png', Promise.resolve(loaded)]]), pending: new Set() };
    f.get('core/state').state.activeMode = 'coupleAvatar'; ui.namespace.activateForTest(view);
    const settle = async () => { for (let i = 0; i < 5; i++) await new Promise(resolve => setImmediate(resolve)); };
    return { ...f, helper: helper.namespace, ui: ui.namespace, store: realStore ? modules.get('core/chatAvatarStore').namespace : store, calls, record, loaded, view, notices, settle,
        setSnapshot: value => { snapshot = value; }, setLoadHook: value => { loadHook = value; },
        setClearHook: value => { clearHook = value; } };
}

test('crop mapping follows source halfIndex and person id despite reversed display order', async () => {
    const f = await setup(), before = plain(f.record);
    const prepared = f.helper.prepareCoupleAvatarApplication(f.record, f.loaded, f.host);
    assert.deepEqual(plain(prepared.images.map(image => image.halfIndex)), [1, 0]);
    assert.deepEqual(plain(prepared.mapping), { char: 0, user: 1 });
    assert.equal(f.calls.crop.length, 2);
    await f.helper.applyPreparedCoupleAvatars(prepared, prepared.mapping, { context: f.host });
    assert.deepEqual(f.calls.saved, [{ char: { name: 'Char', url: png(0) }, user: { name: 'User', url: png(1) } }]);
    assert.deepEqual(plain(f.record), before); assert.equal(f.calls.image + f.calls.text, 0);
});

test('custom identities need explicit mapping; selected swap changes only applied roles', async () => {
    const f = await setup();
    f.record.settings.people[0].name = 'Custom A'; f.record.settings.people[1].id = 'custom-id';
    const prepared = f.helper.prepareCoupleAvatarApplication(f.record, f.loaded, f.host);
    assert.deepEqual(plain(prepared.mapping), { char: null, user: null });
    await assert.rejects(f.helper.applyPreparedCoupleAvatars(prepared, prepared.mapping, { context: f.host }), { code: 'RMT_PAIR_AVATAR_MAPPING' });
    await f.helper.applyPreparedCoupleAvatars(prepared, { char: 1, user: 0 }, { context: f.host });
    assert.equal(f.calls.saved[0].char.url, png(1)); assert.equal(f.calls.saved[0].user.url, png(0));
});

test('one-side crop failure or a changed chat prevents any pair write', async () => {
    const f = await setup();
    let exported = 0;
    f.sb.document.createElement = () => ({ getContext: () => ({ drawImage() {} }), toDataURL: () => { if (++exported === 2) throw Object.assign(Error('tainted'), { name: 'SecurityError' }); return png(0); } });
    assert.throws(() => f.helper.prepareCoupleAvatarApplication(f.record, f.loaded, f.host), { code: 'PAIR_IMAGE_CORS' });
    assert.equal(f.calls.saved.length, 0);
    const prepared = { scope: f.store.chatAvatarScope(f.host), names: { char: 'Char', user: 'User' }, images: [{ halfIndex: 0, url: png(0) }, { halfIndex: 1, url: png(1) }] };
    f.host.chatId = 'OTHER';
    await assert.rejects(f.helper.applyPreparedCoupleAvatars(prepared, { char: 0, user: 1 }, { context: f.host }), { code: 'RMT_PAIR_AVATAR_SCOPE' });
    assert.equal(f.calls.saved.length, 0);
});

test('opening then cancelling the mapping dialog does not apply or generate anything', async () => {
    const f = await setup();
    await f.ui.handleAction(f.view, 'apply-chat-avatar', { dataset: {} });
    const m = f.ui.dialogForTest();
    assert.match(m.body.innerHTML, /角色 · Char/); assert.match(m.body.innerHTML, /我 · User/);
    assert.equal(f.calls.load, 1); assert.equal(f.calls.saved.length, 0);
    f.ui.closeCoupleDialog();
    assert.equal(f.calls.saved.length + f.calls.image + f.calls.text, 0);
});

test('dialog confirms both existing crops atomically and prevents a double click', async () => {
    const f = await setup(), hostBefore = plain({ character: f.host.characters[0], metadata: f.host.chatMetadata }), recordBefore = plain(f.record);
    await f.ui.showApplyChatAvatars(f.view, f.record);
    const m = f.ui.dialogForTest(), apply = m.body.querySelector('[data-pair-avatar-apply]');
    assert.equal(apply.disabled, false);
    await apply.emit('click'); await apply.emit('click'); await f.settle();
    assert.equal(f.calls.saved.length, 1); assert.equal(f.calls.saved[0].char.url, png(0));
    assert.deepEqual(plain(f.record), recordBefore);
    assert.deepEqual(plain({ character: f.host.characters[0], metadata: f.host.chatMetadata }), hostBefore);
    assert.equal(f.calls.image + f.calls.text, 0); assert.match(f.notices[0].textContent, /已应用/);
});

test('custom-name dialog requires choosing both roles and can swap their assignment', async () => {
    const f = await setup(); f.record.settings.people.forEach((person, i) => { person.name = 'Custom ' + i; });
    await f.ui.showApplyChatAvatars(f.view, f.record);
    const m = f.ui.dialogForTest(), selectors = m.body.querySelectorAll('[data-pair-avatar-role]'), apply = m.body.querySelector('[data-pair-avatar-apply]');
    assert.equal(apply.disabled, true);
    selectors[0].value = 'char'; selectors[1].value = 'user'; await selectors[1].emit('change');
    assert.equal(apply.disabled, false);
    await m.body.querySelector('[data-pair-avatar-swap]').emit('click');
    await apply.emit('click'); await f.settle();
    assert.equal(f.calls.saved[0].char.url, png(0)); assert.equal(f.calls.saved[0].user.url, png(1));
});

test('chat switching during loading or before confirmation cannot apply the old chat pair', async () => {
    for (const phase of ['load', 'apply']) {
        const f = await setup();
        let resume;
        if (phase === 'load') f.setLoadHook(() => new Promise(resolve => { resume = resolve; }));
        const pending = f.ui.showApplyChatAvatars(f.view, f.record);
        if (phase === 'load') { f.host.chatId = 'B'; resume(); }
        await pending;
        if (phase === 'apply') { const apply = f.ui.dialogForTest().body.querySelector('[data-pair-avatar-apply]'); f.host.chatId = 'B'; await apply.emit('click'); await f.settle(); }
        assert.equal(f.calls.saved.length, 0);
    }
});

test('cross-origin crop failure preserves old applied pair and offers existing local-import flow', async () => {
    const f = await setup(); f.loaded.croppable = false; f.loaded.error = '请导入本地原图后再裁切。';
    f.setSnapshot({ version: 1, char: { url: png(0) }, user: { url: png(1) } });
    await f.ui.showApplyChatAvatars(f.view, f.record);
    const m = f.ui.dialogForTest();
    assert.match(m.body.innerHTML, /导入本地原图/); assert.equal(f.calls.saved.length + f.calls.cleared.length, 0);
});

test('restore requires confirmation, is scoped, and never deletes pair history or changes generation settings', async () => {
    const f = await setup(), before = plain(f.view.records), settings = plain(f.view.settings);
    f.setSnapshot({ version: 1, char: { url: png(0) }, user: { url: png(1) } });
    f.sb.confirm = () => false; await f.ui.restoreChatAvatars(f.view); assert.equal(f.calls.cleared.length, 0);
    let confirm;
    f.sb.confirm = () => new Promise(resolve => { confirm = resolve; });
    const pending = f.ui.restoreChatAvatars(f.view); await f.settle(); f.host.chatId = 'B'; confirm(true); await pending;
    assert.equal(f.calls.cleared.length, 0);
    f.host.chatId = 'A'; f.sb.confirm = () => true; await f.ui.restoreChatAvatars(f.view);
    assert.equal(f.calls.cleared.length, 1); assert.deepEqual(plain(f.view.records), before); assert.deepEqual(plain(f.view.settings), settings);
    assert.equal(f.calls.image + f.calls.text, 0);
});

test('closing a loading dialog or switching Persona before apply cannot publish an old pair', async () => {
    const loading = await setup();
    let resume;
    loading.setLoadHook(() => new Promise(resolve => { resume = resolve; }));
    const pending = loading.ui.showApplyChatAvatars(loading.view, loading.record);
    loading.ui.closeCoupleDialog(); resume(); await pending;
    assert.equal(loading.calls.crop.length, 0); assert.equal(loading.calls.saved.length, 0);
    const persona = await setup();
    await persona.ui.showApplyChatAvatars(persona.view, persona.record);
    const apply = persona.ui.dialogForTest().body.querySelector('[data-pair-avatar-apply]');
    persona.host.userAvatar = 'another-persona.png';
    await apply.emit('click'); await persona.settle();
    assert.equal(persona.calls.saved.length, 0);
});

test('actual crop/helper/UI/store integration saves both PNGs durably and restores without changing host identity or history', async () => {
    const f = await setup({ realStore: true });
    const hostBefore = plain({ character: f.host.characters[0], metadata: f.host.chatMetadata, settings: f.host.extensionSettings });
    const recordBefore = plain(f.record);
    await f.ui.showApplyChatAvatars(f.view, f.record);
    await f.ui.dialogForTest().body.querySelector('[data-pair-avatar-apply]').emit('click'); await f.settle();
    const saved = await f.store.loadChatAvatarSnapshot(f.host);
    assert.equal(saved.char.url, png(0)); assert.equal(saved.user.url, png(1));
    assert.ok([...f.disk.values()].some(raw => raw.includes(png(0)) && raw.includes(png(1))));
    assert.deepEqual(plain(f.record), recordBefore);
    assert.deepEqual(plain({ character: f.host.characters[0], metadata: f.host.chatMetadata, settings: f.host.extensionSettings }), hostBefore);
    await f.ui.restoreChatAvatars(f.view);
    assert.equal(await f.store.loadChatAvatarSnapshot(f.host), null);
    assert.deepEqual(plain(f.record), recordBefore); assert.equal(f.calls.image + f.calls.text, 0);
});

test('closing or replacing the originating restore modal cancels pending load and confirmation', async () => {
    for (const phase of ['load', 'confirm']) for (const replace of [false, true]) {
        const f = await setup();
        f.setSnapshot({ version: 1, char: { url: png(0) }, user: { url: png(1) } });
        await f.ui.showApplyChatAvatars(f.view, f.record);
        let resume, confirms = 0;
        if (phase === 'load') f.setLoadHook(() => new Promise(resolve => { resume = resolve; }));
        f.sb.confirm = () => {
            confirms++;
            return phase === 'confirm' ? new Promise(resolve => { resume = resolve; }) : true;
        };
        const pending = f.ui.restoreChatAvatars(f.view); await f.settle();
        f.ui.closeCoupleDialog(); f.setLoadHook(null);
        if (replace) await f.ui.showApplyChatAvatars(f.view, f.record);
        const replacement = f.ui.dialogForTest();
        resume(true); await pending;
        assert.equal(confirms, phase === 'load' ? 0 : 1, 'closing must not trigger a later confirmation');
        assert.equal(f.calls.cleared.length, 0, 'a dismissed restore cannot clear the pair');
        assert.equal(f.ui.dialogForTest() === replacement, true, 'a newer modal remains open');
    }
});

test('a confirmed restore does not close a newer modal and main-page restore works without a modal', async () => {
    const f = await setup();
    const snapshot = { version: 1, char: { url: png(0) }, user: { url: png(1) } };
    f.setSnapshot(snapshot); await f.ui.showApplyChatAvatars(f.view, f.record);
    let complete;
    f.setClearHook(() => new Promise(resolve => { complete = resolve; }));
    const pending = f.ui.restoreChatAvatars(f.view); await f.settle();
    f.ui.closeCoupleDialog(); await f.ui.showApplyChatAvatars(f.view, f.record);
    const replacement = f.ui.dialogForTest(); complete(); await pending;
    assert.equal(f.calls.cleared.length, 1, 'an already confirmed write may finish');
    assert.equal(f.ui.dialogForTest() === replacement, true, 'completion must not dismiss the newer modal');
    f.ui.closeCoupleDialog(); f.setClearHook(null); f.setSnapshot(snapshot);
    await f.ui.handleAction(f.view, 'restore-chat-avatar', { dataset: {} });
    assert.equal(f.calls.cleared.length, 2); assert.equal(f.ui.dialogForTest(), null);
    assert.match(f.notices[0].textContent, /已恢复/); assert.equal(f.calls.image + f.calls.text, 0);
});
