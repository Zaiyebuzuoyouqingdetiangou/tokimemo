import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { fixture } from './fixture.mjs';

const song = { id: 'SONG_preset_uc', title: 'Preset negatives', lyrics: '[Verse 1]\n看向你\n[End]' };
const plain = value => JSON.parse(JSON.stringify(value));
const cast = { version: 1, cardType: 'multi', selectedIds: ['r', 'k'], people: [
    { id: 'r', name: 'Raphael', sourceRefs: [] }, { id: 'k', name: 'Kamael', sourceRefs: [] },
], appearances: [{ participantId: 'r', tag: 'brown hair, brown eyes', manual: true },
    { participantId: 'k', tag: 'black hair, amber eyes, slender fingers', manual: true }] };
const rNegative = 'raphael_avoid_marker, red hair';
const kNegative = 'kamael_avoid_marker, brown hair';

async function setup({ provider = 'chatu8-image', legacy = false, automaticCoordinates = true } = {}) {
    const f = await fixture(), mv = f.get('extras/mv'), castApi = f.get('extras/mvCast');
    f.host.name2 = 'Raphael'; f.host.name1 = 'Kamael';
    f.get('core/cache').loadSession = () => ({ songs: [song] });
    f.get('core/castLooks').readCastLooks = () => ({ manual: true, char: 'brown hair, brown eyes', user: 'black hair, amber eyes, slender fingers' });
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS, imageGenerationProvider: provider, imageGenerationFallback: false });
    const raw = { groups: [{ id: 'A', who: 'user', layer: 'full', composition: 'looking at snow',
        cast: [{ participantId: 'r', visible: 'full' }, { participantId: 'k', visible: 'full' }],
        diffs: [{ id: 'open', imagePrompt: 'looking at snow' }], bgs: [{ id: 'street', prompt: 'empty snowy street' }] }],
        frames: [{ sectionIndex: 0, lyric: '看向你', group: 'A', diff: 'open' }] };
    if (legacy) delete raw.groups[0].cast;
    const settings = mv.normalizeSettings({ output: 'tegaki', storyType: 'interaction', range: 'full', appear: 'face' });
    const built = mv.buildShots(f.json(raw), f.bank, 1, settings, legacy ? null : f.json(cast));
    const record = { ...built, settings, id: song.id, createdAt: 1, ...(legacy ? {} : { cast: f.json(cast) }) };
    f.host.chatMetadata[mv.MV_KEY] = { songs: { [song.id]: record } };
    const requests = [], baibai = [], captured = [];
    const source = new EventEmitter(); f.host.eventSource = source;
    const presets = {
        r: { nameEN: 'Raphael', characterTraits: 'brown hair, pale skin', facialFeatures: 'brown eyes', negative: rNegative },
        k: { nameEN: 'Kamael', nameCN: '卡玛尔', characterTraits: 'blonde hair, pale skin, long fingers', facialFeatures: 'green eyes', negative: kNegative },
    };
    f.host.extensionSettings['st-chatu8'] = { scriptEnabled: true, mode: 'novelai', novelaimode: 'nai-diffusion-4-full', AI_use_coords: automaticCoordinates, characterPresets: presets };
    source.on('generate-image-request', request => {
        requests.push(request);
        source.emit('generate-image-response', { id: request.id, success: true, imageData: `/user/images/uc-${requests.length}.png` });
    });
    f.sb.STBaiBaiImage = { apiVersion: 1, capabilities: { generate: true, saveToGallery: true, characterLibrary: true },
        getCharacters: () => ({ apiVersion: 1, characters: [{ name: 'Kamael', tag: 'silver hair' }] }),
        getBackendStatus: () => ({ configured: true, backend: 'nai', supportsCharacters: true }),
        generate: async request => { baibai.push(request); return { path: '/user/images/baibai.png' }; } };
    const core = f.get('generation/cgImageCore'), invoke = core.invokeImageGeneration;
    core.invokeImageGeneration = async (prompt, context, options) => {
        captured.push({ prompt, options }); return invoke(prompt, context, options);
    };
    return { ...f, mv, castApi, record, requests, baibai, captured, presets };
}

test('MV modern metadata keeps per-person preset negatives with the corresponding native character slot', async () => {
    const f = await setup(), before = plain(f.record.cast);
    f.record.groups[0].cast.reverse();
    const metadata = f.castApi.castMetadata(f.record, f.record.groups[0], f.host);
    assert.deepEqual(plain(metadata.characters.map(row => [row.participantId, row.negative])), [['k', kNegative], ['r', rNegative]]);
    assert.doesNotMatch(f.mv.assetPrompt(f.record, 'G1:D1', f.host), /avoid_marker/);
    assert.equal((await f.mv.drawAsset(song.id, 'G1:D1')).pending, false);
    assert.equal(f.requests.length, 1);
    assert.match(f.requests[0].prompt, /Character 1 UC: kamael_avoid_marker, brown hair;/);
    assert.match(f.requests[0].prompt, /Character 2 UC: raphael_avoid_marker, red hair;/);
    assert.deepEqual(plain(f.mv.readMv(f.host, song.id).cast), before);
});

for (const kind of ['asset', 'frame']) test(`legacy MV ${kind} carries only the visible role's preset negative`, async () => {
    const f = await setup({ legacy: true });
    if (kind === 'frame') {
        f.record.version = 1; delete f.record.groups;
        f.record.shots = [{ id: 'legacy-frame', who: 'user', imagePrompt: 'one person gazing at snow', sectionIndex: 0 }];
    }
    const result = kind === 'frame' ? await f.mv.drawFrame(song.id, 'legacy-frame') : await f.mv.drawAsset(song.id, 'G1:D1');
    assert.equal(result.pending, false); assert.equal(f.requests.length, 1);
    const rows = f.captured[0].options.promptMetadata.characters;
    assert.equal(rows.length, 1); assert.equal(rows[0].role, 'user'); assert.equal(rows[0].negative, kNegative);
    assert.match(f.requests[0].prompt, /Character 1 UC: kamael_avoid_marker, brown hair;/);
    assert.doesNotMatch(f.requests[0].prompt, /raphael_avoid_marker/);
});

test('MV flat coordinates route carries negatives in the documented extra-negative event field', async () => {
    const f = await setup({ automaticCoordinates: false });
    await f.mv.drawAsset(song.id, 'G1:D1');
    assert.equal(f.requests.length, 1);
    assert.doesNotMatch(f.requests[0].prompt, /avoid_marker|Character \d+ UC/);
    assert.match(f.requests[0].negative_prompt, /raphael_avoid_marker/);
    assert.match(f.requests[0].negative_prompt, /kamael_avoid_marker/);
});

test('MV matched hand and back presets keep their negatives without re-expanding positive faces; silhouette has neither', async () => {
    for (const visible of ['hands', 'back', 'silhouette']) {
        const f = await setup(); f.record.groups[0].cast = [{ participantId: 'k', visible }];
        const row = f.castApi.castMetadata(f.record, f.record.groups[0], f.host).characters[0];
        assert.equal(row.negative, visible === 'silhouette' ? undefined : kNegative);
        assert.doesNotMatch(row.tag, /green eyes/);
        if (visible !== 'back') assert.doesNotMatch(row.tag, /blonde hair/);
        await f.mv.drawAsset(song.id, 'G1:D1');
        assert.equal(f.requests.length, 1);
        if (visible === 'silhouette') assert.doesNotMatch(JSON.stringify(f.requests[0]), /avoid_marker/);
        else assert.match(f.requests[0].prompt, /Character 1 UC: kamael_avoid_marker, brown hair;/);
    }
});

test('MV lost or colliding presets remove their negatives on the next click while keeping local fallback tags', async () => {
    for (const kind of ['lost', 'duplicate', 'roster-alias']) {
        const f = await setup(); await f.mv.drawAsset(song.id, 'G1:D1');
        if (kind === 'lost') delete f.presets.k;
        if (kind === 'duplicate') f.presets.other = { ...f.presets.k };
        if (kind === 'roster-alias') f.mv.writeMv(f.mv.mvScope(f.host), song.id, value => {
            value.cast.people[0].name = '卡玛尔'; return value;
        });
        await f.mv.drawAsset(song.id, 'G1:D1'); assert.equal(f.requests.length, 2);
        const row = f.captured.at(-1).options.promptMetadata.characters.find(value => value.participantId === 'k');
        assert.equal(row.negative, undefined); assert.match(row.tag, /black hair/);
        assert.doesNotMatch(JSON.stringify(f.requests.at(-1)), /kamael_avoid_marker/);
    }
});

test('MV negatives are not persisted into local appearance fallback, added to empty assets, or injected into a full manual prompt', async () => {
    const f = await setup();
    const legacy = f.castApi.legacyMvLooks(f.host, { user: 'full' });
    assert.equal(legacy.presetNegatives.user, kNegative); assert.equal(legacy.presetNegatives.char, undefined);
    delete f.presets.k;
    assert.equal(f.castApi.legacyMvLooks(f.host, { user: 'full' })?.presetNegatives?.user, undefined);
    f.record.groups[0].cast = []; f.record.motif = { name: '雪', prompt: 'small snowflake', image: null };
    for (const key of ['G1:D1', 'G1:bg', 'motif']) {
        await f.mv.drawAsset(song.id, key); assert.doesNotMatch(JSON.stringify(f.requests.at(-1)), /avoid_marker/);
    }
    f.mv.writeMv(f.mv.mvScope(f.host), song.id, value => ({ ...value, assetPrompts: { 'G1:D1': 'my exact complete snowy landscape' } }));
    await f.mv.drawAsset(song.id, 'G1:D1');
    assert.equal(f.requests.at(-1).prompt, 'my exact complete snowy landscape');
    assert.equal(f.requests.at(-1).negative_prompt, undefined);
});

test('MV selected BaiBai never receives installed Chatu8 per-character negatives', async () => {
    const f = await setup({ provider: 'baibai-image' });
    assert.ok(f.castApi.castMetadata(f.record, f.record.groups[0], f.host).characters.every(row => row.negative === undefined));
    await f.mv.drawAsset(song.id, 'G1:D1');
    assert.equal(f.requests.length, 0); assert.equal(f.baibai.length, 1);
    assert.doesNotMatch(JSON.stringify(f.baibai[0]), /avoid_marker/);
});
