import test from 'node:test';
import assert from 'node:assert/strict';
import { scene, native } from './mv-stage-canvas-fixture.mjs';
import { ui } from './mv-ui-fixture.mjs';
import { stageSetup } from './mv-stage-fixture.mjs';

function picture({ transparent = false, split = false } = {}) {
    const c = native.createCanvas(split ? 1600 : 800, 540), g = c.getContext('2d');
    const start = split ? 800 : 0;
    if (!transparent) { g.fillStyle = '#c6844c'; g.fillRect(0, 0, c.width, c.height); }
    if (split) { g.fillStyle = '#1458bb'; g.fillRect(0, 0, 800, 540); }
    g.fillStyle = '#f523a4'; g.fillRect(start + 10, 250, 40, 40);
    g.fillStyle = '#235bf4'; g.fillRect(start + 750, 250, 40, 40);
    return { url: c.toDataURL(), editMode: transparent ? 'cutout' : 'full', split: split ? 'right' : 'none' };
}

function configure(r) {
    delete r.stage; r.settings.storyType = 'narrative';
    for (const g of r.groups) { g.scale = 'close'; g.layer = 'full'; g.motion = 'still'; }
    r.tegaki.lyric = 'none';
    for (const s of r.shots) { s.cut = 'cut'; s.motion = 'still'; }
}

const pixel = (c, x, y) => [...c.getContext('2d').getImageData(Math.floor(x), Math.floor(y), 1, 1).data];
function warmCorners(c) {
    for (const [x, y] of [[2, 2], [c.width - 3, 2], [2, c.height - 3], [c.width - 3, c.height - 3]]) {
        const [r, g, b, a] = pixel(c, x, y);
        assert.ok(r > 160 && g > 85 && g < 180 && b < 120 && a === 255,
            'unused frame area must continue the picture colours, not expose an unrelated dark matte');
    }
}

for (const ratio of ['16:9', '9:16']) test(`${ratio}: old full detail images keep both ends and fill empty frame area locally`, async () => {
    const f = await scene({ ratio, createArt: () => picture(), configure });
    try {
        const saved = JSON.stringify(f.record()); f.seek(1); warmCorners(f.preview);
        // Independently located original landmarks: 800x540 fitted in the output.
        const positions = ratio === '16:9' ? [[110, 270], [850, 270]] : [[20.25, 480], [519.75, 480]];
        assert.deepEqual(pixel(f.preview, ...positions[0]), [245, 35, 164, 255]);
        assert.deepEqual(pixel(f.preview, ...positions[1]), [35, 91, 244, 255]);
        const canvases = f.canvases.length;
        for (let i = 0; i < 20; i++) f.seek(1 + i / 100);
        assert.equal(f.canvases.length, canvases, 'playback reuses a tiny derived background');
        assert.equal(JSON.stringify(f.record()), saved); assert.equal(f.calls(), 0); assert.deepEqual(f.errors, []);
    } finally { f.mvui.disposeMv(); }
});

test('manual right-cell selection supplies both the foreground and its soft background', async () => {
    const f = await scene({ createArt: () => picture({ split: true }), configure });
    try { f.seek(1); warmCorners(f.preview); assert.deepEqual(pixel(f.preview, 110, 270), [245, 35, 164, 255]); }
    finally { f.mvui.disposeMv(); }
});

test('V1 replacement images use the same soft background without editing the original record', async () => {
    const f = await scene({ createArt: () => picture(), configure: r => {
        configure(r); r.version = 1;
        for (const s of r.shots) { s.shot = '牵手特写'; s.image = { ...r.groups[0].diffs[0].image }; }
    } });
    try { const saved = JSON.stringify(f.record()); f.seek(1); warmCorners(f.preview); assert.equal(JSON.stringify(f.record()), saved); }
    finally { f.mvui.disposeMv(); }
});

test('a chosen stage background remains visible around full detail images', async () => {
    const f = await scene({ imageBackground: true, createArt: () => picture(), configure: r => {
        r.groups[0].scale = 'close'; r.groups[0].layer = 'full'; r.groups[0].motion = 'still';
        r.tegaki.lyric = 'none'; for (const s of r.shots) { s.cut = 'cut'; s.motion = 'still'; }
    } });
    try { f.seek(1); assert.deepEqual(pixel(f.preview, 2, 270), [22, 114, 69, 255]); }
    finally { f.mvui.disposeMv(); }
});

test('transparent pictures retain their transparent margins instead of acquiring a duplicate backdrop', async () => {
    const f = await scene({ createArt: () => picture({ transparent: true }), configure });
    try { f.seek(1); assert.deepEqual(pixel(f.preview, 2, 270), [47, 58, 69, 255]); }
    finally { f.mvui.disposeMv(); }
});

test('soft padding uses the same pixels in preview and export', async () => {
    const f = await scene({ createArt: () => picture(), configure });
    let clock = 1000, exported, started, timer;
    const ready = new Promise(resolve => { started = resolve; });
    f.sb.performance.now = () => clock;
    f.sb.MediaStream = class { constructor(tracks) { this.tracks = tracks; } };
    f.sb.AudioContext = class {};
    f.sb.MediaRecorder = class {
        static isTypeSupported() { return true; }
        constructor(stream) { exported = stream.tracks[0].canvas; this.state = 'inactive'; }
        start() { this.state = 'recording'; started(); }
        stop() { this.state = 'inactive'; this.onstop?.(); }
    };
    try {
        f.seek(.1); warmCorners(f.preview);
        const reference = Buffer.from(f.preview.getContext('2d').getImageData(0, 0, f.w, f.h).data);
        f.click('export');
        await Promise.race([ready, new Promise((_, reject) => { timer = setTimeout(() => reject(Error('export did not start')), 5000); })]);
        await new Promise(resolve => setImmediate(resolve)); clock = 1100;
        for (const [id, tick] of [...f.frames]) { f.frames.delete(id); tick(); }
        warmCorners(exported);
        assert.deepEqual(Buffer.from(exported.getContext('2d').getImageData(0, 0, f.w, f.h).data), reference);
        assert.equal(f.calls(), 0); assert.deepEqual(f.errors, []);
    } finally { clearTimeout(timer); f.mvui.disposeMv(); }
});

// Stylesheet contract only: actual Safari/TT geometry is a separate acceptance layer.
test('the editor gives the preview its film ratio and does not stretch it to the remaining row height', async () => {
    const f = await ui(stageSetup);
    try {
        const css = f.get('ui/mvEditorUi').editorCss('#test');
        assert.match(css, /\.rmt-mve-preview \.rmt-mv-canvas-wrap\{[^}]*aspect-ratio:16\/9[^}]*flex:0 0 auto/);
        assert.match(css, /\.rmt-mve-preview \.rmt-mv-canvas-wrap\.portrait\{[^}]*aspect-ratio:9\/16/);
        assert.match(css, /grid-template-rows:auto auto/);
        assert.doesNotMatch(css, /\.rmt-mve-workspace\[data-preview-only=true\] \.rmt-mv-canvas-wrap\{flex:1/);
    } finally { f.mvui.disposeMv(); }
});
