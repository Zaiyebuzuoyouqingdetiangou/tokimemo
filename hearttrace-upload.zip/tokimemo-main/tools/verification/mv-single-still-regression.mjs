import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';

const song = { id: 'SONG_stills', title: '抬眼', lyrics: '[Verse 1]\n看着我\n[Chorus]\n再看着我\n[End]' };
const cast = { version: 1, cardType: 'multi', revision: '', selectedIds: ['a'],
    people: [{ id: 'a', name: '方祁洛', sourceRefs: [] }],
    appearances: [{ participantId: 'a', tag: 'black hair, high ponytail', manual: true }] };
const first = 'close-up face of 方祁洛, eyes wide in surprise, mouth slightly open, warm sunlight';
const second = 'close-up face of 方祁洛, narrowed eyes, closed mouth with a confident smirk, warm sunlight';
function raw(complete = true) {
    return { groups: [{ id: 'G1', composition: '脸部特写', scale: 'close',
        characterPrompt: "english: close up on 1boy's face, eyes slightly widened in surprise, warm sunlight, intense gaze",
        cast: [{ participantId: 'a', position: 'center', visible: 'face', action: '瞳孔微缩，脑子里飞速盘算，表情从呆愣转为认真' }],
        bgs: [{ id: 'B1', prompt: 'english: blurred street background' }], diffs: [
            { id: 'D1', label: '惊讶', change: 'eyes wide in surprise', ...(complete ? { imagePrompt: first } : {}) },
            { id: 'D2', label: '笃定', change: 'english: boy slightly furrowing his brows, calculating, a hint of a confident smirk starting to form', ...(complete ? { imagePrompt: second } : {}) },
        ] }], frames: [
        { sectionIndex: 0, lyric: '看着我', group: 'G1', diff: 'D1', bg: 'B1', hold: 1 },
        { sectionIndex: 0, lyric: '看着我', group: 'G1', diff: 'D2', bg: 'B1', hold: 0.5 },
        { sectionIndex: 1, lyric: '再看着我', group: 'G1', diff: 'D1', bg: 'B1', hold: 1 },
    ] };
}
async function setup(complete = true, roster = cast) {
    const f = await fixture(), mv = f.get('extras/mv');
    f.get('core/cache').loadSession = () => ({ songs: [song] });
    const settings = mv.normalizeSettings({ output: 'tegaki', ratio: '16:9', range: 'full', storyType: 'expression' });
    const data = raw(complete), built = mv.buildShots(f.json(data), f.bank, 2, settings, roster && f.json(roster));
    const record = { ...built, id: song.id, createdAt: 1, updatedAt: 1, settings, wardrobe: { era: '架空武侠江湖' }, ...(roster ? { cast: f.json(roster) } : {}) };
    f.host.chatMetadata[mv.MV_KEY] = { songs: { [song.id]: record } };
    return { ...f, mv, record };
}
function provider(f, backend = 'nai', supportsCharacters = true) {
    const requests = [];
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS, imageGenerationProvider: 'baibai-image', imageGenerationFallback: false });
    f.sb.STBaiBaiImage = { apiVersion: 1, capabilities: { generate: true, saveToGallery: true },
        getBackendStatus: () => ({ configured: true, backend, supportsCharacters }),
        generate: async value => { requests.push(value); return { path: `/user/images/still-${requests.length}.png` }; } };
    return requests;
}

test('reported legacy solo prompt replaces the old expression and omits the cast transition', async () => {
    const f = await setup(false), before = JSON.stringify(f.record);
    const prompt = f.mv.assetPrompt(f.record, 'G1:D2', f.host);
    assert.doesNotMatch(prompt, /widened in surprise|intense gaze|从呆愣转为认真|english:|current moment:/);
    assert.match(prompt, /close up on 1boy's face/); assert.match(prompt, /warm sunlight/);
    assert.match(prompt, /confident smirk/); assert.match(prompt, /black hair/);
    assert.equal(JSON.stringify(f.record), before);
});

test('a complete still supersedes all group and change poses while preserving names and looks', async () => {
    const f = await setup(), prompt = f.mv.assetPrompt(f.record, 'G1:D2', f.host);
    assert.ok(prompt.includes(second));
    assert.doesNotMatch(prompt, /surprise|furrowing|starting to form|从呆愣|current moment/);
    assert.equal(prompt.split('confident smirk').length - 1, 1);
    assert.equal(prompt.split('black hair').length - 1, 1);
    assert.match(prompt, /方祁洛/); assert.match(prompt, /blurred street background/);
});

test('two expressions produce separate images and the repeated beat reuses the first paid asset', async () => {
    const f = await setup(), requests = provider(f), keys = f.mv.assetKeys(f.record, song);
    assert.deepEqual(Array.from(keys), ['G1:D1', 'G1:D2']);
    for (const key of keys) assert.equal((await f.mv.drawAsset(song.id, key)).pending, false);
    assert.equal(requests.length, 2);
    assert.match(requests[0].prompt, /eyes wide in surprise/); assert.doesNotMatch(requests[0].prompt, /confident smirk/);
    assert.match(requests[1].prompt, /confident smirk/); assert.doesNotMatch(requests[1].prompt, /surprise/);
    const saved = f.mv.readMv(f.host, song.id);
    assert.equal(f.mv.shotImage(saved, saved.shots[0]).url, '/user/images/still-1.png');
    assert.equal(f.mv.shotImage(saved, saved.shots[1]).url, '/user/images/still-2.png');
    assert.equal(f.mv.shotImage(saved, saved.shots[2]).url, '/user/images/still-1.png');
    assert.equal(saved.shots[1].timingWeight, 0.5);
});

test('MV NAI submits the scene once and preserves its separate appearance channel', async () => {
    const f = await setup(), requests = provider(f);
    await f.mv.drawAsset(song.id, 'G1:D2');
    assert.equal(requests.length, 1); assert.equal(requests[0].nl, '');
    assert.doesNotMatch(requests[0].prompt, /black hair/);
    assert.equal(requests[0].characters[0].tag, 'black hair, high ponytail');
});

test('other modules keep the existing NAI transport contract', async () => {
    const f = await setup(), requests = provider(f);
    await f.get('generation/cgImageCore').invokeImageGeneration('existing scene', f.host);
    assert.equal(requests[0].prompt, 'existing scene'); assert.equal(requests[0].nl, 'existing scene');
});

test('ComfyUI and flat backends retain complete prompt channels and named looks', async () => {
    for (const [backend, supportsCharacters] of [['comfyui', true], ['comfyui', false], ['nai', false]]) {
        const f = await setup(), requests = provider(f, backend, supportsCharacters);
        await f.mv.drawAsset(song.id, 'G1:D2');
        assert.match(requests[0].nl, /confident smirk/);
        if (!supportsCharacters) assert.match(requests[0].prompt, /方祁洛.*black hair/);
    }
});

test('player redraw and asset editor use the same chosen still', async () => {
    const f = await setup(), requests = provider(f), shot = f.record.shots[1];
    assert.equal(f.mv.framePrompt(f.record, shot, f.host), f.mv.assetPrompt(f.record, 'G1:D2', f.host));
    await f.mv.drawFrame(song.id, shot.id);
    assert.equal(requests.length, 1); assert.ok(requests[0].prompt.includes(second));
    assert.doesNotMatch(requests[0].prompt, /surprise|从呆愣/);
});

test('manual complete prompts pass through both redraw routes without hidden character text', async () => {
    const f = await setup(), requests = provider(f), custom = 'My independently edited still: eyes closed.';
    f.mv.writeMv(f.mv.mvScope(f.host), song.id, record => ({ ...record, assetPrompts: { 'G1:D2': custom } }));
    await f.mv.drawAsset(song.id, 'G1:D2'); await f.mv.drawFrame(song.id, f.record.shots[1].id);
    assert.equal(requests.length, 2);
    for (const request of requests) { assert.equal(request.prompt, custom); assert.equal(request.characters, undefined); assert.equal(request.nl, ''); }
});

test('a player redraw arriving after an asset prompt edit is preserved as pending', async () => {
    const f = await setup(); let resolve;
    f.get('generation/cgImageCore').invokeImageGeneration = () => new Promise(done => { resolve = done; });
    const drawing = f.mv.drawFrame(song.id, f.record.shots[1].id);
    f.mv.writeMv(f.mv.mvScope(f.host), song.id, record => ({ ...record, assetPrompts: { 'G1:D2': 'new manual expression' } }));
    resolve('/user/images/late-still.png');
    const result = await drawing;
    assert.equal(result.pending, true);
    assert.equal(f.mv.readMv(f.host, song.id).shots[1].image, null);
    assert.match(f.mv.exportMvRecovery(result.scope), /late-still.png/);
});

test('missing optional per-still text and legacy records remain drawable', async () => {
    const f = await setup(false, null);
    f.get('core/castLooks').readCastLooks = () => ({ manual: true, char: 'black hair', user: '' });
    const requests = provider(f);
    assert.equal((await f.mv.drawAsset(song.id, 'G1:D2')).pending, false);
    assert.equal(requests.length, 1);
    assert.equal(requests[0].characters[0].tag, 'black hair');
    assert.doesNotMatch(requests[0].prompt, /fixed appearance/);
});

test('unbound multi-person legacy actions are retained instead of guessing whose expression changed', async () => {
    const f = await setup(false), g = f.record.groups[0];
    f.record.cast.people.push({ id: 'b', name: '乙', sourceRefs: [] });
    g.cast.push({ participantId: 'b', position: 'right', action: 'offers a cup', visible: 'full' });
    assert.match(f.mv.assetPrompt(f.record, 'G1:D2', f.host), /乙: right; offers a cup/);
});

test('omitted group cast can still resolve a named person from the new per-still field', async () => {
    const f = await setup(), roster = structuredClone(cast), data = raw();
    roster.people.push({ id: 'b', name: '另一个人', sourceRefs: [] }); roster.selectedIds.push('b');
    delete data.groups[0].cast;
    data.groups[0].characterPrompt = 'close-up, warm sunlight';
    const built = f.mv.buildShots(f.json(data), f.bank, 2, f.record.settings, f.json(roster));
    assert.deepEqual(Array.from(built.groups[0].cast, person => person.participantId), ['a']);
    data.groups[0].cast = [];
    assert.equal(f.mv.buildShots(f.json(data), f.bank, 2, f.record.settings, f.json(roster)).groups[0].cast.length, 0);
});

test('expression storyboard request includes separate stills, sustained poses and a shared stage', async () => {
    const f = await setup(); let request = '', count = 0;
    f.get('generation/client').requestJson = async prompt => { request = prompt; count++; return f.json(raw()); };
    assert.equal((await f.mv.generateStoryboard(song.id, f.record.settings, f.json(cast))).pending, false);
    assert.equal(count, 1); assert.match(request, /替代基础描述/); assert.match(request, /每个 diff 会分别请求并保存一张图片/);
    const example = JSON.parse(request.split('\n').at(-1));
    assert.equal(example.groups[0].diffs.length, 2);
    assert.ok(example.groups.every(g => g.diffs.every(d => d.imagePrompt)));
    assert.equal(example.frames[0].diff, example.frames.at(-1).diff);
    assert.equal(example.frames[0].group, example.frames.at(-1).group);
    assert.equal(example.frames[2].group, 'G2');
    assert.equal(example.groups[1].cast[0].visible, 'full');
    assert.equal(example.stage.backgrounds.length, 1);
    assert.equal(example.groups[0].stageBackground, example.groups[1].stageBackground);
    assert.equal(example.frames[0].diff, example.frames[1].diff);
    assert.notEqual(example.frames[0].stage.layout, example.frames[1].stage.layout);
});
