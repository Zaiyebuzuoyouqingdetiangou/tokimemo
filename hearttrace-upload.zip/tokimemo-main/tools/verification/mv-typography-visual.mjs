// Optional diagnostic font is external to the production tree and never packaged.
import fs from 'node:fs';
import path from 'node:path';
import { scene, native } from './mv-stage-canvas-fixture.mjs';
const [fontFile, output] = process.argv.slice(2);
if (!fontFile || !output) throw Error('Provide a verification-only Chinese font and output PNG path');
native.GlobalFonts.registerFromPath(fontFile, 'Noto Sans SC');
const lyric = '你总是冷着脸\n像隔绝人间的封锁';
const board = native.createCanvas(1120, 1040), g = board.getContext('2d');
g.fillStyle = '#ebedf0'; g.fillRect(0, 0, 1120, 1040);
for (const [i, type] of [{}, { textScale: 1.12, textTracking: .08, textLeading: 1.15 }].entries()) {
    const f = await scene({ ratio: '9:16', configure: r => { r.tegaki.lyric = 'big'; r.shots[0].lyric = lyric; Object.assign(r.tegaki, type); } });
    try {
        f.seek(2); g.drawImage(f.preview, 10 + i * 560, 55);
        g.fillStyle = '#27374a'; g.font = '600 24px "Noto Sans SC"'; g.textAlign = 'left';
        g.fillText(i ? '轻疏排版' : '默认排版', 24 + i * 560, 36);
    } finally { f.mvui.disposeMv(); }
}
fs.mkdirSync(path.dirname(path.resolve(output)), { recursive: true }); fs.writeFileSync(output, board.toBuffer('image/png'));
console.log(JSON.stringify({ output, productionFontFilesAdded: 0 }));
