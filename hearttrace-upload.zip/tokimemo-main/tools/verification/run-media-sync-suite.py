"""Run unchanged test files in separate processes, with complete per-test TAP.

The current sandboxed Node child runner only reports file-level outcomes.
--test-isolation=none inside one process per file preserves isolation and names.
"""
from pathlib import Path
import concurrent.futures
import re
import subprocess
import sys

files = sys.argv[1:]
def check(file):
    p = subprocess.run(['node', '--experimental-vm-modules', '--test', '--test-isolation=none',
                        '--test-reporter=tap', file], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=45)
    return file, p.returncode, p.stdout.decode(errors='replace')

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results = list(pool.map(check, files))
print('TAP version 13')
total = dict.fromkeys(['tests', 'suites', 'pass', 'fail', 'cancelled', 'skipped', 'todo'], 0)
index = 0
failed = False
for file, code, output in results:
    print('# Test file: ' + str(Path(file).name))
    failed |= code != 0
    for key in total:
        count = re.search(r'^# ' + key + r' (\d+)$', output, re.M)
        if not count:
            print(output); raise SystemExit('Missing test totals: ' + file)
        total[key] += int(count[1])
    for line in output.splitlines():
        if re.match(r'^(?:TAP version |1\.\.\d+$|# (?:tests|suites|pass|fail|cancelled|skipped|todo|duration_ms) )', line): continue
        if re.match(r'^(not ok|ok) \d+ - ', line):
            index += 1
            line = re.sub(r'^((?:not )?ok) \d+ - ', lambda m: m[1] + ' ' + str(index) + ' - ', line)
        print(line)
print('1..' + str(index))
for key, count in total.items(): print('# ' + key + ' ' + str(count))
raise SystemExit(int(failed))
