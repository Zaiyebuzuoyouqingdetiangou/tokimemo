import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { fixture } from './fixture.mjs';

const song = { id: 'SONG_bbi_preset', title: 'Preset cast', lyrics: '[Verse 1]\n看向你\n[End]' };
const plain = value => JSON.parse(JSON.stringify(value));
const cast = { version: 1, cardType: 'multi', selectedIds: ['r', 'k'], people: [
    { id: 'r', name: 'Raphael', sourceRefs: [] }, { id: 'k', name: 'Kamael', sourceRefs: [] },
], appearances: [{ participantId: 'r', tag: 'brown hair, brown eyes', manual: true },
    { participantId: 'k', tag: 'black hair, amber eyes, slender fingers', manual: true }] };

async function setup({ provider = 'baibai-image', backend = 'nai', supportsCharacters = true, legacy = false, who = 'both' } = {}) {
    const f = await fixture(), mv = f.get('extras/mv'), castApi = f.get('extras/mvCast');
    f.host.name2 = 'Raphael'; f.host.name1 = 'Kamael';
    f.get('core/cache').loadSession = () => ({ songs: [song] });
    f.get('core/castLooks').readCastLooks = () => ({ manual: true, char: 'brown hair, brown eyes', user: 'black hair, amber eyes, slender fingers' });
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS, imageGenerationProvider: provider, imageGenerationFallback: false });
    const raw = { groups: [{ id: 'A', who, layer: 'full', composition: 'looking at snow',
        cast: [{ participantId: 'r', visible: 'full' }, { participantId: 'k', visible: 'full' }],
        diffs: [{ id: 'open', imagePrompt: 'looking at snow' }], bgs: [{ id: 'street', prompt: 'empty snowy street' }] }],
        frames: [{ sectionIndex: 0, lyric: '看向你', group: 'A', diff: 'open' }] };
    if (legacy) delete raw.groups[0].cast;
    const settings = mv.normalizeSettings({ output: 'tegaki', storyType: 'interaction', range: 'full', appear: 'face' });
    const built = mv.buildShots(f.json(raw), f.bank, 1, settings, legacy ? null : f.json(cast));
    const record = { ...built, settings, id: song.id, createdAt: 1,
        ...(legacy ? {} : { cast: f.json(cast) }), wardrobe: { characters: [{ participantId: 'k', clothing: 'blue cloak' }] } };
    f.host.chatMetadata[mv.MV_KEY] = { songs: { [song.id]: record } };
    const requests = [], chatu8 = [], library = [{ name: 'Kamael', tag: 'silver hair, pale skin, long fingers, violet eyes', nl: '' }];
    const source = new EventEmitter(); f.host.eventSource = source;
    f.host.extensionSettings['st-chatu8'] = { scriptEnabled: true, mode: 'novelai', novelaimode: 'nai-diffusion-4-full', characterPresets: {
        gold: { nameEN: 'Kamael', nameCN: '卡玛尔', characterTraits: 'blonde hair, pale skin', facialFeatures: 'green eyes' },
    } };
    source.on('generate-image-request', request => {
        chatu8.push(request);
        source.emit('generate-image-response', { id: request.id, success: true, imageData: `/user/images/chatu8-${chatu8.length}.png` });
    });
    f.sb.STBaiBaiImage = { apiVersion: 1, capabilities: { generate: true, saveToGallery: true, characterLibrary: true },
        getCharacters: () => ({ apiVersion: 1, characters: library }),
        getBackendStatus: () => ({ configured: true, backend, supportsCharacters }),
        generate: async request => { requests.push(request); return { path: `/user/images/baibai-${requests.length}.png` }; } };
    return { ...f, mv, castApi, record, requests, chatu8, library };
}

for (const [backend, supportsCharacters] of [['nai', true], ['comfyui', false]]) test(`MV selected BaiBai ${backend} resolves each actor before preview and one-request sends`, async () => {
    const f = await setup({ backend, supportsCharacters }), before = plain(f.record.cast), libraryBefore = plain(f.library);
    const preview = f.mv.assetPrompt(f.record, 'G1:D1', f.host);
    assert.match(preview, /Raphael.*brown hair/); assert.match(preview, /Kamael.*silver hair/);
    assert.doesNotMatch(preview, /black hair|amber eyes|blonde hair/); assert.match(preview, /blue cloak/);
    await f.mv.drawAsset(song.id, 'G1:D1'); await f.mv.drawFrame(song.id, f.record.shots[0].id);
    assert.equal(f.requests.length, 2); assert.equal(f.chatu8.length, 0);
    for (const request of f.requests) {
        const payload = JSON.stringify(request);
        assert.match(payload, /brown hair/); assert.match(payload, /silver hair/);
        assert.doesNotMatch(payload, /black hair|amber eyes|blonde hair/);
    }
    assert.deepEqual(plain(f.mv.readMv(f.host, song.id).cast), before);
    assert.deepEqual(plain(f.library), libraryBefore);
});

test('MV missing, duplicate and unavailable BaiBai libraries fall back locally without another provider request', async () => {
    for (const kind of ['missing', 'duplicate', 'unsupported', 'throws']) {
        const f = await setup();
        if (kind === 'missing') f.library.length = 0;
        if (kind === 'duplicate') f.library.push({ name: 'Kamael', tag: 'red hair' });
        if (kind === 'unsupported') f.sb.STBaiBaiImage.capabilities.characterLibrary = false;
        if (kind === 'throws') f.sb.STBaiBaiImage.getCharacters = () => { throw Error('library unavailable'); };
        const preview = f.mv.assetPrompt(f.record, 'G1:D1', f.host);
        assert.match(preview, /black hair/); assert.doesNotMatch(preview, /silver hair|red hair|blonde hair/);
        assert.equal((await f.mv.drawAsset(song.id, 'G1:D1')).pending, false);
        assert.equal(f.requests.length, 1); assert.equal(f.chatu8.length, 0);
        assert.match(JSON.stringify(f.requests[0]), /black hair/);
    }
});

test('MV selected Chatu8 never borrows a matching BaiBai preset', async () => {
    const f = await setup({ provider: 'chatu8-image' });
    const preview = f.mv.assetPrompt(f.record, 'G1:D1', f.host);
    assert.match(preview, /blonde hair/); assert.doesNotMatch(preview, /silver hair/);
    await f.mv.drawAsset(song.id, 'G1:D1');
    assert.equal(f.requests.length, 0); assert.equal(f.chatu8.length, 1);
    assert.match(f.chatu8[0].prompt, /blonde hair/); assert.doesNotMatch(f.chatu8[0].prompt, /silver hair/);
});

test('MV BaiBai natural-language-only appearance is usable without writing over local tags', async () => {
    const f = await setup(), before = plain(f.record.cast);
    f.library[0] = { name: 'Kamael', tag: '', nl: 'silver hair and pale skin' };
    assert.match(f.mv.assetPrompt(f.record, 'G1:D1', f.host), /silver hair and pale skin/);
    assert.equal((await f.mv.drawAsset(song.id, 'G1:D1')).pending, false);
    assert.equal(f.requests.length, 1); assert.match(JSON.stringify(f.requests[0]), /silver hair and pale skin/);
    assert.deepEqual(plain(f.mv.readMv(f.host, song.id).cast), before);
});

test('MV two names resolving to one provider preset fall back even when only one identity is on screen', async () => {
    const f = await setup({ provider: 'chatu8-image' });
    f.record.cast.people[0].name = '卡玛尔';
    f.record.groups[0].cast = [{ participantId: 'k', visible: 'full' }];
    const preview = f.mv.assetPrompt(f.record, 'G1:D1', f.host);
    assert.match(preview, /black hair/); assert.doesNotMatch(preview, /blonde hair|brown hair/);
    await f.mv.drawAsset(song.id, 'G1:D1');
    assert.equal(f.chatu8.length, 1); assert.doesNotMatch(f.chatu8[0].prompt, /blonde hair|brown hair/);
});

test('MV BaiBai same-name roster identities retain independent local appearances', async () => {
    const f = await setup(); f.record.cast.people[0].name = 'Kamael';
    const preview = f.mv.assetPrompt(f.record, 'G1:D1', f.host);
    assert.match(preview, /brown hair/); assert.match(preview, /black hair/); assert.doesNotMatch(preview, /silver hair/);
    await f.mv.drawAsset(song.id, 'G1:D1');
    assert.equal(f.requests.length, 1); assert.doesNotMatch(JSON.stringify(f.requests[0]), /silver hair/);
});

test('MV BaiBai presets preserve hands, back and silhouette crops through the actual adapter', async () => {
    for (const visible of ['hands', 'back', 'silhouette']) {
        const f = await setup(); f.record.groups[0].cast = [{ participantId: 'k', visible }];
        const preview = f.mv.assetPrompt(f.record, 'G1:D1', f.host);
        await f.mv.drawAsset(song.id, 'G1:D1');
        assert.equal(f.requests.length, 1);
        for (const value of [preview, JSON.stringify(f.requests[0])]) {
            assert.doesNotMatch(value, /violet eyes|amber eyes|blonde hair/);
            if (visible === 'back') assert.match(value, /silver hair/);
            else assert.doesNotMatch(value, /silver hair/);
            if (visible === 'hands') { assert.match(value, /pale skin|long fingers/); assert.doesNotMatch(value, /blue cloak/); }
            if (visible === 'silhouette') assert.doesNotMatch(value, /pale skin|long fingers/);
        }
    }
});

for (const kind of ['legacy-asset', 'legacy-frame']) test(`MV BaiBai ${kind} uses only visible roles and preserves long preset tags`, async () => {
    const f = await setup({ legacy: true, who: 'user' });
    const tag = 'silver hair, ' + 'delicate freckles, '.repeat(125) + 'small scar on left wrist';
    f.library[0].tag = tag;
    if (kind === 'legacy-frame') {
        f.record.version = 1; delete f.record.groups;
        f.record.shots = [{ id: 'legacy-frame', who: 'user', imagePrompt: 'one person gazing at snow', sectionIndex: 0 }];
    }
    const preview = kind === 'legacy-frame' ? f.mv.framePrompt(f.record, f.record.shots[0], f.host) : f.mv.assetPrompt(f.record, 'G1:D1', f.host);
    assert.ok(preview.includes(tag)); assert.doesNotMatch(preview, /brown hair|black hair|blonde hair/);
    const result = kind === 'legacy-frame' ? await f.mv.drawFrame(song.id, 'legacy-frame') : await f.mv.drawAsset(song.id, 'G1:D1');
    assert.equal(result.pending, false); assert.equal(f.requests.length, 1);
    assert.equal(f.requests[0].characters.length, 1); assert.equal(f.requests[0].characters[0].tag, tag);
    assert.doesNotMatch(JSON.stringify(f.requests[0]), /brown hair|black hair|blonde hair/);
});

test('MV BaiBai preset availability does not override a saved complete manual prompt or populate empty assets', async () => {
    const f = await setup(); f.record.groups[0].cast = [];
    f.record.motif = { name: '雪', prompt: 'small snowflake', image: null };
    for (const key of ['G1:D1', 'G1:bg', 'motif']) {
        assert.equal((await f.mv.drawAsset(song.id, key)).pending, false);
        assert.doesNotMatch(JSON.stringify(f.requests.at(-1)), /silver hair|brown hair|black hair|blonde hair/);
    }
    f.mv.writeMv(f.mv.mvScope(f.host), song.id, value => ({ ...value, assetPrompts: { 'G1:D1': 'my exact complete snowy landscape' } }));
    await f.mv.drawAsset(song.id, 'G1:D1');
    assert.equal(f.requests.at(-1).prompt, 'my exact complete snowy landscape');
    assert.equal(f.requests.at(-1).characters, undefined);
});
