import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';

const people = [
    { id: 'char', name: '方祁洛', appearance: '1boy, black hair, high ponytail, messy hair, amber eyes', appearanceOverride: true },
    { id: 'user', name: '纪时卿', appearance: '1girl, black hair, pink eyes, blunt bangs, white blindfold', appearanceOverride: true },
];
const plain = value => JSON.parse(JSON.stringify(value));

async function setup() {
    const f = await fixture(), requests = [];
    f.host.chatMetadata = {};
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS,
        imageGenerationProvider: 'baibai-image', imageGenerationFallback: false, cgPromptFormat: 'nai5-natural' });
    f.sb.STBaiBaiImage = { apiVersion: 1, capabilities: { generate: true, saveToGallery: true, characterLibrary: true },
        getCharacters: () => ({ apiVersion: 1, characters: [] }),
        getBackendStatus: () => ({ configured: true, backend: 'nai', supportsCharacters: true }),
        generate: async request => { requests.push(plain(request)); return { path: '/user/images/style-identity.png' }; } };
    f.get('generation/client').requestJson = () => { throw Error('No extra text generation is allowed'); };
    return { ...f, requests, core: f.get('extras/coupleAvatar'), styles: f.get('extras/coupleAvatarStyles') };
}

test('NAI5 dot-eye identity guidance reaches each actual actor without flattening the two appearances', async () => {
    const f = await setup(), settings = { styleId: 'chibi-doodle', people, interaction: '半颗爱心' };
    const before = plain(settings);
    await f.core.generateCouple(settings, { context: f.host });
    assert.equal(f.requests.length, 1);
    const sent = f.requests[0];
    assert.equal(sent.characters.length, 2);
    for (const [index, row] of sent.characters.entries()) {
        assert.ok(row.tag.includes(people[index].appearance), 'literal identity stays with its own actor');
        assert.match(row.nl, /when visible/i);
        assert.match(row.nl, /tiny solid (?:eye )?dots/i);
        assert.match(row.nl, /supplied eye colou?r.*tint.*dots/i);
        assert.match(row.nl, /shared traits.*shared/i);
        assert.match(row.nl, /(?:not|never).*transfer.*other subject/i);
    }
    assert.match(sent.characters[0].nl, /On the left/);
    assert.match(sent.characters[1].nl, /On the right/);
    assert.doesNotMatch(sent.characters[0].tag, /pink eyes|blunt bangs|white blindfold/);
    assert.doesNotMatch(sent.characters[1].tag, /high ponytail|amber eyes/);
    assert.ok(sent.characters.every(row => row.tag.includes('black hair')));
    assert.deepEqual(plain(settings), before);
});

test('every built-in NAI5 medium preserves only supplied identity, while scene and actors receive the rule', async () => {
    const f = await setup();
    assert.equal(f.styles.COUPLE_STYLES.length, 72);
    for (const style of f.styles.COUPLE_STYLES) {
        const guidance = f.styles.coupleStyleIdentityRendering(style);
        assert.match(guidance, /supplied identity/i, style.id);
        assert.match(guidance, /shared traits.*shared/i, style.id);
        assert.match(guidance, /(?:not|never).*invent differences/i, style.id);
        const parts = f.core.couplePromptParts({ styleId: style.id, people }, f.host);
        assert.ok(parts.scene.includes(guidance), style.id);
        assert.ok(parts.nai.characters.every(row => row.nl.includes(guidance)), style.id);
        assert.doesNotMatch(guidance, /artist|masterpiece|best quality|ultra.detailed|silver hair|blue eyes/i, style.id);
    }
    assert.equal(f.requests.length, 0);
});

test('chibi identity guidance keeps selected proportions without imposing dot eyes or full-body framing on other styles', async () => {
    const f = await setup();
    for (const id of ['chibi-dumpling', 'chibi-three-head', 'chibi-headshot', 'chibi-meme']) {
        const style = f.styles.COUPLE_STYLES.find(row => row.id === id);
        const guidance = f.styles.coupleStyleIdentityRendering(style);
        assert.match(guidance, /selected.*proportions.*framing/i);
        assert.doesNotMatch(guidance, /tiny solid dots|two.head.tall|three.head.tall|full.body/i);
        const parts = f.core.couplePromptParts({ styleId: id, people }, f.host);
        if (id === 'chibi-headshot') assert.doesNotMatch(parts.nai.nl, /complete stylized figure fills most/);
        if (id === 'chibi-meme') assert.match(parts.nai.nl, /exaggerated mouth and eyebrow/);
    }
});

test('animal and crafted identity guidance stays inside the selected form', async () => {
    const f = await setup();
    for (const style of f.styles.COUPLE_STYLES.filter(row => row.group === 'animal')) {
        const guidance = f.styles.coupleStyleIdentityRendering(style);
        assert.match(guidance, /animal.*markings|markings.*animal/i, style.id);
        assert.doesNotMatch(guidance, /hair silhouette|human facial|human hair/i, style.id);
    }
    for (const id of ['craft-plush', 'craft-crochet', 'craft-origami', 'fantasy-enamel', 'fantasy-shadow']) {
        const style = f.styles.COUPLE_STYLES.find(row => row.id === id);
        const guidance = f.styles.coupleStyleIdentityRendering(style);
        assert.match(guidance, /material.built/i, id);
        assert.doesNotMatch(guidance, /real skin|realistic eyes|human facial/i, id);
    }
});

test('custom and unknown styles do not acquire built-in identity-rendering constraints', async () => {
    const f = await setup();
    for (const style of [undefined, null, {}, { id: 'custom', group: 'chibi' }, { id: 'not-a-style', group: 'animal' }]) {
        assert.equal(f.styles.coupleStyleIdentityRendering(style), '');
    }
    const parts = f.core.couplePromptParts({ styleId: 'custom', customStyle: 'USER_LITERAL_STYLE',
        direction: 'USER_LITERAL_DIRECTION', people }, f.host);
    assert.ok(parts.prompt.includes('USER_LITERAL_STYLE'));
    assert.ok(parts.nai.nl.includes('USER_LITERAL_DIRECTION'));
    assert.ok(parts.nai.characters.every(row => !/tiny solid dots|supplied identity|selected.*proportions/.test(row.nl)));
});

test('BaiBai NAI identity guidance does not override provider global artists, negatives, or image settings', async () => {
    const f = await setup();
    const providerSettings = Object.freeze({ artistPrompt: 'USER_ARTISTS_UNCHANGED', negativePrompt: 'chibi, undetailed_eyes, USER_UC_UNCHANGED' });
    f.host.extensionSettings.userImageFixture = providerSettings;
    const before = plain(f.host.extensionSettings);
    await f.core.generateCouple({ styleId: 'chibi-doodle', people }, { context: f.host });
    assert.equal(f.requests.length, 1);
    const sent = f.requests[0];
    for (const key of ['negative', 'negativePrompt', 'uc', 'artistPrompt', 'qualityTags', 'width', 'height', 'steps', 'sampler', 'scale']) {
        assert.equal(sent[key], undefined, key);
    }
    for (const row of sent.characters) for (const key of ['negative', 'negativePrompt', 'uc']) assert.equal(row[key], undefined, key);
    assert.deepEqual(plain(f.host.extensionSettings), before);
    assert.doesNotMatch(JSON.stringify(sent), /USER_ARTISTS_UNCHANGED|USER_UC_UNCHANGED/);
});
