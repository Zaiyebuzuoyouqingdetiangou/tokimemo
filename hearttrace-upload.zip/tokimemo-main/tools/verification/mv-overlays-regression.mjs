// Public UI actions and native Canvas; browser host, storage and recorder are doubles.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { fixture } from './fixture.mjs';
import { ui } from './mv-ui-fixture.mjs';
const require = createRequire(import.meta.url);
const native = require(require.resolve('@napi-rs/canvas', { paths: [process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES || process.cwd()] }));

async function scene(change = () => ({})) {
    const f = await ui(fixture), mv = f.get('extras/mv');
    const song = { id: 'SONG_overlays', title: 'TITLE_PROBE', lyrics: '[Verse 1]\nlong\nshort\n[Verse 2]\none\n[Chorus]\ntwo\n[Verse 3]\nlast long\nlast short\n[End]' };
    const art = (color, size = 100) => {
        const c = native.createCanvas(size, size), g = c.getContext('2d');
        const margin = size === 13 ? 3 : 0; // The motif fixture has genuine transparent padding.
        g.fillStyle = color; g.fillRect(margin, margin, size - margin * 2, size - margin * 2); return { url: c.toDataURL(), split: 'none' };
    };
    const red = art('#ff0000'), blue = art('#0000ff'), motif = art('#00ff00', 13);
    const decodes = [], draws = [];
    f.sb.Image = class extends native.Image { set src(value) { super.src = value; decodes.push(this.decode()); } };
    const canvas = () => {
        const c = native.createCanvas(540, 960), g = c.getContext('2d');
        const fillText = g.fillText.bind(g), drawImage = g.drawImage.bind(g);
        g.fillText = (text, ...args) => { draws.push({ canvas: c, text, alpha: g.globalAlpha }); fillText(text, ...args); };
        g.drawImage = (img, ...args) => { if (img.naturalWidth === 13) draws.push({ canvas: c, motif: true }); drawImage(img, ...args); };
        const track = { canvas: c, stop() {} };
        c.style = {}; c.remove = () => {}; c.captureStream = () => ({ getTracks: () => [track], getVideoTracks: () => [track] }); return c;
    };
    const preview = canvas(); f.canvas.getContext = () => preview.getContext('2d');
    const create = f.sb.document.createElement; f.sb.document.createElement = tag => tag === 'canvas' ? canvas() : create(tag);
    let providerCalls = 0;
    f.get('generation/cgImageCore').invokeImageGeneration = async () => { providerCalls++; throw Error('unexpected image request'); };
    f.get('generation/client').generate = async () => { providerCalls++; throw Error('unexpected text request'); };
    f.get('core/cache').loadSession = () => ({ songs: [song] });
    const shots = ['long', 'one', 'two', 'last long'].map((lyric, i) => ({ id: 'S' + i, group: 'R', diff: 'D', image: red, sectionIndex: i, lyric, motion: 'still', cut: 'cut' }));
    const initial = { id: song.id, version: 2, duration: 120,
        settings: { output: 'tegaki', range: 'full', ratio: '9:16' },
        tegaki: { range: 'full', lyric: 'none', introSeconds: 0 }, keyword: 'KEYWORD_PROBE',
        groups: [{ id: 'R', layer: 'full', motion: 'still', diffs: [{ id: 'D', image: red }] },
            { id: 'B', layer: 'full', motion: 'still', diffs: [{ id: 'D', image: blue }] }],
        shots, timing: { taps: { 0: 0, 1: 30, 2: 60, 3: 90 } }, ...change({ shots, red, blue, motif }) };
    f.host.chatMetadata[mv.MV_KEY] = { songs: { [song.id]: initial } };
    const record = () => mv.readMv(f.host, song.id);
    const open = () => { f.mvui.openMv({ songId: song.id }); f.click('go-tegaki'); };
    open(); await Promise.all(decodes); f.mvui.renderMv(); await Promise.all(decodes);
    const seek = t => {
        draws.length = 0;
        const el = { dataset: { rmtMv: 'seek' }, getBoundingClientRect: () => ({ left: 0, width: mv.shotTimeline(record(), song).total }) };
        f.mvui.handleMvClick({ target: { closest: () => el }, clientX: t, preventDefault() {} });
        return draws.filter(d => d.canvas === preview);
    };
    const setOutro = value => f.mvui.handleMvChange({ target: { value: String(value), matches: s => s === '[data-rmt-mv-outro-seconds]' } });
    const toggle = (key, checked) => f.mvui.handleMvChange({ target: { checked, dataset: { rmtMvOverlay: key }, matches: s => s === '[data-rmt-mv-overlay]' } });
    const pixel = (c = preview) => [...c.getContext('2d').getImageData(5, 5, 1, 1).data];
    const expectRed = (c = preview) => { const p = pixel(c); assert.ok(p[0] > 200 && p[1] < 40 && p[2] < 40, 'drawing must be clear: ' + p); };
    const title = rows => rows.filter(d => d.text === song.title);
    // Preview loads images lazily on first use; await each real decode before pixel assertions.
    for (const row of mv.shotTimeline(record(), song).rows) { seek((row.start + row.end) / 2); await Promise.all(decodes); }
    seek(0);
    return { ...f, mv, song, initial, record, open, seek, preview, setOutro, toggle, draws, pixel, expectRed, title, providerCalls: () => providerCalls };
}

test('outro appears only inside the selected ending interval, never over later or earlier shots', async () => {
    const f = await scene(() => ({ tegaki: { range: 'custom', rangeFrom: 1, rangeTo: 2, introSeconds: 0, lyric: 'none' } }));
    try {
        assert.equal(f.mv.playRange(f.record(), f.song).end, 90);
        for (const t of [0, 29, 30, 85, 90.001, 100, 110]) {
            assert.equal(f.title(f.seek(t)).length, 0, 'no ending card at ' + t); f.expectRed();
        }
        assert.equal(f.title(f.seek(89)).length, 1);
        assert.equal(f.title(f.seek(90)).length, 1);
    } finally { f.mvui.disposeMv(); }
});

test('outro control persists, accepts fractional seconds and zero, preserving drawings and timing', async () => {
    const f = await scene(); try {
        f.click('editor-tab', 'look');
        const original = JSON.stringify({ shots: f.record().shots, groups: f.record().groups, timing: f.record().timing, song: f.song });
        assert.match(f.body.innerHTML, /data-rmt-mv-outro-seconds/);
        assert.equal(f.setOutro(.5), true); assert.equal(f.record().tegaki.outroSeconds, .5);
        assert.equal(f.title(f.seek(119)).length, 0); assert.equal(f.title(f.seek(119.8)).length, 1);
        f.setOutro('bad'); f.setOutro(-1); f.setOutro(''); assert.equal(f.record().tegaki.outroSeconds, .5);
        f.setOutro(0); assert.equal(f.title(f.seek(119.99)).length, 0); f.expectRed();
        f.mvui.disposeMv(); f.open(); assert.equal(f.record().tegaki.outroSeconds, 0);
        assert.equal(original, JSON.stringify({ shots: f.record().shots, groups: f.record().groups, timing: f.record().timing, song: f.song }));
        for (const value of [undefined, null, '', 'bad', -1, Infinity]) assert.equal(f.mv.tegakiOptions({ tegaki: { outroSeconds: value } }).outroSeconds, 2.5);
        assert.equal(f.providerCalls(), 0);
    } finally { f.mvui.disposeMv(); }
});

test('a short final shot keeps its first half free of the outro', async () => {
    const f = await scene(({ shots }) => ({ shots: [...shots, { ...shots[3], id: 'S4', lyric: 'last short' }],
        timing: { taps: { 0: 0, 1: 30, 2: 60, 3: 90 }, lineTaps: { '3:1': 119.8 } } }));
    try {
        const row = f.mv.shotTimeline(f.record(), f.song).rows.at(-1); assert.equal(row.start, 119.8);
        assert.equal(f.title(f.seek(119.84)).length, 0); f.expectRed();
        const fade = f.title(f.seek(119.925)); assert.equal(fade.length, 1); assert.ok(fade[0].alpha > 0 && fade[0].alpha < 1);
        assert.equal(f.title(f.seek(119.98)).length, 1);
    } finally { f.mvui.disposeMv(); }
});

for (const version of [1, 2]) for (const cut of ['fade', 'flash']) {
    test(`v${version} ${cut} leaves most of a 0.2 second shot clear without removing the transition`, async () => {
        const f = await scene(({ shots, blue }) => ({ version,
            tegaki: { range: 'full', lyric: 'none', introSeconds: 0, outroSeconds: 0 },
            shots: [{ ...shots[0], group: 'B', image: blue, cut }, { ...shots[0], id: 'short', lyric: 'short' }, ...shots.slice(1)],
            timing: { taps: { 0: 0, 1: 30, 2: 60, 3: 90 }, lineTaps: { '0:1': 29.8 } } }));
        try {
            const row = f.mv.shotTimeline(f.record(), f.song).rows[1]; assert.equal(row.start, 29.8); assert.equal(row.end, 30);
            f.seek(29.82); assert.ok(f.pixel()[2] > 40, 'transition is still visible at its beginning');
            f.seek(29.88); f.expectRed();
            f.seek(29.98); f.expectRed();
        } finally { f.mvui.disposeMv(); }
    });
}

test('normal-length shots retain their existing fade', async () => {
    const f = await scene(({ shots, blue }) => ({ shots: [{ ...shots[0], group: 'B', image: blue, cut: 'fade' }, ...shots.slice(1)] }));
    try { f.seek(30.2); assert.ok(f.pixel()[2] > 40); f.seek(30.36); f.expectRed(); }
    finally { f.mvui.disposeMv(); }
});

test('hiding lyrics also hides the chorus keyword and restoring lyrics keeps the choice', async () => {
    const f = await scene(); try {
        f.click('tegaki-lyric', 'subtitle'); assert.ok(f.seek(70).some(d => d.text === 'KEYWORD_PROBE'));
        f.click('tegaki-lyric', 'none'); assert.ok(!f.seek(70).some(d => d.text === 'KEYWORD_PROBE'));
        f.click('tegaki-lyric', 'subtitle'); assert.ok(f.seek(70).some(d => d.text === 'KEYWORD_PROBE'));
        f.toggle('keyword', false); const result = f.seek(70);
        assert.ok(!result.some(d => d.text === 'KEYWORD_PROBE')); assert.ok(result.some(d => d.text === 'two'), 'lyrics stay enabled');
        f.click('tegaki-preset', 'slow'); assert.equal(f.record().tegaki.showKeyword, false);
        f.mvui.disposeMv(); f.open(); assert.ok(!f.seek(70).some(d => d.text === 'KEYWORD_PROBE'));
    } finally { f.mvui.disposeMv(); }
});

test('motif and keyword controls are independent and preserve generated assets', async () => {
    const f = await scene(({ motif }) => ({ motif: { image: motif }, tegaki: { range: 'full', lyric: 'subtitle', introSeconds: 0 } }));
    try {
        f.click('editor-tab', 'look');
        assert.match(f.body.innerHTML, /data-rmt-mv-overlay="keyword"/); assert.match(f.body.innerHTML, /data-rmt-mv-overlay="motif"/);
        const original = JSON.stringify({ shots: f.record().shots, groups: f.record().groups, motif: f.record().motif });
        assert.ok(f.seek(70).some(d => d.motif));
        f.toggle('motif', false); let result = f.seek(70);
        assert.ok(!result.some(d => d.motif)); assert.ok(result.some(d => d.text === 'KEYWORD_PROBE'));
        f.toggle('keyword', false); f.toggle('motif', true); result = f.seek(70);
        assert.ok(result.some(d => d.motif)); assert.ok(!result.some(d => d.text === 'KEYWORD_PROBE'));
        f.mvui.disposeMv(); f.open(); assert.equal(f.record().tegaki.showMotif, true); assert.equal(f.record().tegaki.showKeyword, false);
        assert.equal(original, JSON.stringify({ shots: f.record().shots, groups: f.record().groups, motif: f.record().motif }));
        assert.equal(f.providerCalls(), 0);
    } finally { f.mvui.disposeMv(); }
});

test('fragment export preserves overlay choices without changing the original timeline', async () => {
    const f = await scene(); try {
        f.setOutro(0); f.toggle('keyword', false); f.toggle('motif', false);
        const before = JSON.stringify(f.mv.shotTimeline(f.record(), f.song));
        f.mv.patchRecord(f.song.id, { exportRange: { range: 'custom', rangeFrom: 1, rangeTo: 2 } });
        const copy = f.mv.exportRecord(f.record(), f.song);
        assert.equal(copy.tegaki.outroSeconds, 0); assert.equal(copy.tegaki.showKeyword, false); assert.equal(copy.tegaki.showMotif, false);
        assert.equal(f.mv.playRange(copy, f.song).start, 30); assert.equal(f.mv.playRange(copy, f.song).end, 90);
        assert.equal(before, JSON.stringify(f.mv.shotTimeline(f.record(), f.song)));
    } finally { f.mvui.disposeMv(); }
});

test('video export uses the saved overlay snapshot and the same clear ending as preview', async () => {
    const f = await scene(({ motif }) => ({ motif: { image: motif }, tegaki: { range: 'custom', rangeFrom: 2, rangeTo: 2, lyric: 'subtitle', introSeconds: 0 } }));
    let clock = 1000, exportCanvas, resolveStarted, resolveScheduled, timer;
    const started = new Promise(resolve => { resolveStarted = resolve; }), scheduled = new Promise(resolve => { resolveScheduled = resolve; });
    const raf = f.sb.requestAnimationFrame; f.sb.requestAnimationFrame = tick => { const id = raf(tick); resolveScheduled(); return id; };
    f.sb.performance.now = () => clock;
    f.sb.MediaStream = class { constructor(tracks) { this.tracks = tracks; } };
    f.sb.AudioContext = class {};
    f.sb.MediaRecorder = class {
        static isTypeSupported() { return true; }
        constructor(stream) { this.state = 'inactive'; exportCanvas = stream.tracks[0].canvas; }
        start() { this.state = 'recording'; resolveStarted(); }
        stop() { this.state = 'inactive'; this.onstop?.(); }
    };
    try {
        f.setOutro(0); f.toggle('keyword', false); f.toggle('motif', false);
        f.mv.patchRecord(f.song.id, { exportRange: { range: 'custom', rangeFrom: 2, rangeTo: 2 } });
        const expected = f.seek(89); f.expectRed();
        assert.ok(!expected.some(d => d.motif || d.text === 'KEYWORD_PROBE' || d.text === f.song.title));
        f.click('export');
        await Promise.race([Promise.all([started, scheduled]), new Promise((_, reject) => { timer = setTimeout(() => reject(Error('export not started')), 5000); })]);
        // A settings change during recording affects the editor, not this in-flight export.
        f.mv.patchTegaki(f.song.id, { outroSeconds: 2.5, showKeyword: true, showMotif: true });
        f.draws.length = 0; clock = 30000;
        for (const [id, tick] of [...f.frames]) { f.frames.delete(id); tick(); }
        f.expectRed(exportCanvas);
        const result = f.draws.filter(d => d.canvas === exportCanvas);
        assert.ok(result.some(d => d.text === 'two'));
        assert.ok(!result.some(d => d.motif || d.text === 'KEYWORD_PROBE' || d.text === f.song.title));
        assert.equal(f.providerCalls(), 0);
    } finally { clearTimeout(timer); f.mvui.disposeMv(); }
});
