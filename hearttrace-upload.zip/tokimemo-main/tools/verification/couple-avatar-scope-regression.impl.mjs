import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(process.env.TEST_ROOT || path.join(path.dirname(fileURLToPath(import.meta.url)), '../..'));
const base = path.resolve(process.env.BASELINE_ROOT || '/workspace/scratch/8e568532ca62/candidate-1.0.40/tokimemo-main');
function files(dir, prefix = '') {
    return fs.readdirSync(path.join(dir, prefix), { withFileTypes: true }).flatMap(entry => {
        const name = prefix ? prefix + '/' + entry.name : entry.name;
        return entry.isDirectory() ? files(dir, name) : [name];
    }).sort();
}
test('only avatar prompts, BaiBai adapter and release metadata change from 1.0.40', () => {
    const before = path.join(base, 'src'), after = path.join(root, 'src'), names = files(before);
    assert.deepEqual(files(after), names, 'No source module removed or unexpectedly added');
    const allowed = new Set(['extras/coupleAvatar.js', 'extras/coupleAvatarStyles.js', 'generation/baibaiImage.js', 'core/releaseNotes.js']);
    let checked = 0;
    for (const file of names) {
        if (allowed.has(file)) continue;
        const normalize = value => file === 'core/selfUpdater.js' ? value.replace(/^(export const INSTALLED_BUILD = )'[^']+';/m, "$1'<release>';") : value;
        assert.equal(normalize(fs.readFileSync(path.join(after, file), 'utf8')), normalize(fs.readFileSync(path.join(before, file), 'utf8')), file);
        checked++;
    }
    assert.ok(checked > 330, 'UI, crop math, dynamic illustration, MV, mail and storage modules remain frozen');
});
