import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { audioSourceFixtures } from './mv-audio-source-fixtures.mjs';

const root = path.resolve(process.env.TEST_ROOT || '.');
const moduleUrl = 'data:text/javascript;base64,' + fs.readFileSync(path.join(root, 'src/extras/mvAudioSource.js')).toString('base64');
const { isVideoAudioSource, inspectVideoAudioSource } = await import(moduleUrl);
const fixtures = audioSourceFixtures();
test.after(() => fixtures.cleanup());

for (const kind of ['mp4', 'mov', 'fragmented']) test(`${kind}: identify a real AAC track without reading movie payload`, async () => {
    const row = fixtures[kind], blob = new Blob([row.bytes], { type: row.type });
    assert.ok(row.tracks.some(track => track.codec_type === 'audio' && track.codec_name === 'aac'), 'independent ffprobe confirms AAC');
    let bytes = 0, largest = 0;
    const sliced = { size: blob.size, slice(start, end) { bytes += end - start; largest = Math.max(largest, end - start); return blob.slice(start, end); } };
    assert.deepEqual(await inspectVideoAudioSource(sliced), { kind: 'video', hasAudio: true });
    assert.ok(bytes < blob.size / 2, `${bytes} metadata bytes vs ${blob.size} container bytes`);
    assert.ok(largest <= 8, 'no full movie or whole metadata tree is buffered');
});
test('a playable video without an audio track is rejected', async () => {
    assert.ok(fixtures.silent.tracks.every(track => track.codec_type !== 'audio'));
    await assert.rejects(inspectVideoAudioSource(new Blob([fixtures.silent.bytes])), { code: 'RMT_MV_VIDEO_SILENT' });
});
test('an audio track declared in fragmented metadata but containing no samples is rejected', async () => {
    assert.ok(fixtures.emptyTrack.tracks.some(track => track.codec_type === 'audio'), 'ffprobe sees the declared audio track');
    await assert.rejects(inspectVideoAudioSource(new Blob([fixtures.emptyTrack.bytes])), { code: 'RMT_MV_VIDEO_SILENT' });
});
test('truncated container and arbitrary renamed files are rejected', async () => {
    for (const bytes of [fixtures.damaged.bytes, Buffer.from('this is not a movie'), Buffer.alloc(0)]) await assert.rejects(inspectVideoAudioSource(new Blob([bytes])), /不完整|无法读取/);
});
test('file selection recognizes video MIME and MP4/MOV names without misclassifying ordinary audio', () => {
    assert.equal(isVideoAudioSource({ type: 'video/quicktime' }, 'recording'), true);
    assert.equal(isVideoAudioSource({ type: '' }, 'SCREEN.MOV'), true);
    assert.equal(isVideoAudioSource({ type: '' }, 'screen.mp4'), true);
    assert.equal(isVideoAudioSource({ type: 'audio/mp4' }, 'song.m4a'), false);
    assert.equal(isVideoAudioSource({ type: 'audio/wav' }, 'song.wav'), false);
});
test('cancellation stops metadata inspection without reading more data', async () => {
    const controller = new AbortController(); controller.abort();
    let reads = 0;
    await assert.rejects(inspectVideoAudioSource({ size: 100, slice() { reads++; throw Error('must not read'); } }, { signal: controller.signal }), { name: 'AbortError' });
    assert.equal(reads, 0);
});
