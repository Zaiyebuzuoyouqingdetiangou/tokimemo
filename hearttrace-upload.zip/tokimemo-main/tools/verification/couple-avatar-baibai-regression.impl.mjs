import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { stripTypeScriptTypes } from 'node:module';
import { fixture } from './fixture.mjs';

// Execute the real BaiBai public normalizer and NAI parameter builder, not a
// locally reimplemented request contract. No provider network calls are made.
const upstreamRoot = process.env.BAIBAI_SOURCE_ROOT || '/workspace/scratch/8e568532ca62/inspection';
async function provider(model = 'nai-diffusion-4-5-full') {
    const context = vm.createContext({ console, Error, structuredClone });
    const source = name => stripTypeScriptTypes(fs.readFileSync(`${upstreamRoot}/baibai-${name}-current.ts`, 'utf8'), { mode: 'transform' });
    const stub = values => new vm.SyntheticModule(Object.keys(values), function () {
        for (const [name, value] of Object.entries(values)) this.setExport(name, value);
    }, { context });
    const noop = () => { throw Error('Unexpected provider network/helper call'); };
    const size = new vm.SourceTextModule(source('size'), { context });
    const nai = new vm.SourceTextModule(source('nai'), { context });
    const imports = {
        fflate: stub({ unzipSync: noop }), '@/randomUuid': stub({ randomUuid: noop }),
        '@/backends/naiRateLimit': stub({ parseRetryAfter: noop, runNaiWithRetry: noop }),
        '@/backends/size': size, '@/backends/vibeStore': stub({ clampVibeStrength: noop, loadVibeData: noop }),
    };
    await nai.link(name => { assert.ok(imports[name], name); return imports[name]; }); await nai.evaluate();
    const config = { model, landscapeSize: '1216×832', portraitSize: '832×1216', seed: 0,
        activeArtistId: 'fixture', artistPresets: [{ id: 'fixture', prompt: 'USER_ARTIST_PRESET', quality: '', negative: '' }],
        qualityTags: 'USER_QUALITY', undesiredContent: 'USER_NEGATIVE', sampler: 'k_euler_ancestral', scale: 5,
        steps: 28, cfgRescale: 0, noiseSchedule: 'karras', varietyBoost: false, normalizeRefStrength: false };
    let actual, calls = 0;
    const status = { backend: 'nai', configured: true, model, supportsCharacters: true };
    const modules = {
        '@/backends/size': size, '@/backends/nai': nai, '@/backends/comfyui': stub({ ComfyUIError: class extends Error {} }),
        '@/generate': stub({ backendStatus: () => status, decideSeed: (_, seed) => seed || 17,
            generateImage: async input => {
                calls++; actual = nai.namespace.buildNaiParameters(config, input);
                return { seed: input.seed, backend: 'nai', charactersApplied: true,
                    result: { url: 'data:image/png;base64,TEST', format: 'png', revoke: () => {} } };
            } }),
        '@/floor/storage': stub({ saveExternalImage: async () => '/user/images/native-baibai.png' }),
        '@/st/context': stub({ getContext: () => ({ name2: 'fixture' }) }),
        '@/st/imageTagRegex': stub({ serializeImageTag: JSON.stringify }),
        '@/state/charTags': stub({ buildEntryTag: noop, charTagLib: { entries: [] }, charTagsBeforeFloor: noop, lockedCharTagNames: () => new Set() }),
        '@/version': stub({ PLUGIN_VERSION: 'upstream-test' }), './types': stub({ PUBLIC_API_VERSION: 1 }),
    };
    const api = new vm.SourceTextModule(source('public'), { context });
    await api.link(name => { assert.ok(modules[name], name); return modules[name]; }); await api.evaluate();
    return { api: { apiVersion: 1, capabilities: { generate: true, saveToGallery: true },
        getBackendStatus: api.namespace.getBackendStatus, generate: api.namespace.generate },
        config, actual: () => actual, calls: () => calls };
}
const people = [{ name: '方祁洛', appearance: '1boy, black hair, high ponytail, messy hair, intense expression' },
    { name: '纪时卿', appearance: '1girl, black hair, pink eyes' }];
async function setup(model) {
    const f = await fixture(), p = await provider(model), requests = [];
    f.sb.STBaiBaiImage = { ...p.api, generate: (request, options) => { requests.push(request); return p.api.generate(request, options); } };
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS, imageGenerationProvider: 'baibai-image', imageGenerationFallback: false });
    f.get('generation/client').requestJson = async () => { throw Error('No paid text request'); };
    return { ...f, p, requests, core: f.get('extras/coupleAvatar'), styles: f.get('extras/coupleAvatarStyles') };
}

test('BaiBai actual NAI payload: literal identities start the character tags and concrete roles use nl', async () => {
    for (const model of ['nai-diffusion-4-5-full', 'nai-diffusion-5-full']) {
        const f = await setup(model), before = JSON.stringify(f.p.config);
        await f.core.generateCouple({ styleId: 'art-gongbi', interaction: '星星递给你', people }, { context: f.host });
        const sent = f.requests[0], native = f.p.actual(), captions = native.v4_prompt.caption.char_captions;
        assert.ok(sent.characters[0].tag.startsWith(people[0].appearance));
        assert.ok(sent.characters[1].tag.startsWith(people[1].appearance));
        assert.match(sent.characters[0].nl, /left.*offer a small glowing star toward the right/i);
        assert.match(sent.characters[1].nl, /right.*reach inward toward the offered star/i);
        assert.match(captions[0].char_caption, /^boy, black hair, high ponytail/);
        assert.match(captions[1].char_caption, /^girl, black hair, pink eyes/);
        assert.doesNotMatch(captions[1].char_caption, /high ponytail|intense expression/);
        assert.doesNotMatch(native.v4_prompt.caption.base_caption, /black hair|pink eyes|high ponytail/);
        assert.match(native.v4_prompt.caption.base_caption, /^USER_ARTIST_PRESET, Chinese gongbi/);
        assert.match(native.v4_prompt.caption.base_caption, /USER_QUALITY/);
        assert.equal(native.negative_prompt, 'USER_NEGATIVE');
        assert.equal(native.width, 1216); assert.equal(native.height, 832);
        assert.equal(JSON.stringify(f.p.config), before);
        assert.equal(f.p.calls(), 1);
    }
});

test('Gongbi, oil and line-art use a compact style brief without repeating the full construction in both captions', async () => {
    for (const [styleId, term] of [['art-gongbi', 'hair-fine ink'], ['art-oil', 'impasto'], ['graphic-line', 'economical contour']]) {
        const f = await setup(); await f.core.generateCouple({ styleId, interaction: '星星递给你', people }, { context: f.host });
        const sent = f.requests[0];
        assert.ok(sent.nl); assert.match(sent.prompt, new RegExp(styleId === 'graphic-line' ? 'line-art' : styleId === 'art-oil' ? 'oil' : 'gongbi'));
        assert.ok((sent.prompt + sent.nl).includes(term));
        assert.doesNotMatch(JSON.stringify(sent), /Style construction:|Rendering style:|Action roles:|square crops|circular crop|rounded cards|frame or divider/);
        assert.ok(sent.characters.every(c => !c.tag.includes('Action:') && !c.tag.includes('Continuous hair-fine')));
    }
});

test('the exact pasted fireworks inspiration assigns different concrete actions and reactions locally', async () => {
    const f = await setup(); const detail = '左边指着远处的烟花，右边偷偷看左边；一个好奇、一个耐心陪伴。同一束柔光落在两边。';
    const settings = { people, styleId: 'graphic-line', interaction: '自定义互动', interactionDetail: detail };
    const saved = await f.core.generateCouple(settings, { context: f.host }); const sent = f.requests[0];
    assert.match(sent.characters[0].nl, /point.*fireworks/);
    assert.match(sent.characters[1].nl, /glance.*left/);
    assert.doesNotMatch(sent.characters[1].nl, /point.*fireworks/);
    assert.match(sent.characters[0].nl, /curious/); assert.match(sent.characters[1].nl, /patient/);
    assert.doesNotMatch(sent.characters[0].nl + sent.characters[1].nl, /perform only/);
    assert.equal(saved.record.settings.interactionDetail, detail);
    assert.equal(f.p.calls(), 1);
});

test('all locally generated inspirations reach concrete individual captions and avoid suggesting an empty border', async () => {
    const f = await setup();
    for (let i = 0; i < 20; i++) {
        for (const detail of f.styles.randomCoupleIdeas([], () => i / 20)) {
            const parts = f.core.couplePromptParts({ people, interaction: '自定义互动', interactionDetail: detail });
            assert.doesNotMatch(detail, /背景留白/);
            assert.doesNotMatch(parts.characters.map(c => c.tag).join(' '), /perform only/);
            assert.notEqual(parts.nai.characters[0].nl, parts.nai.characters[1].nl);
        }
    }
    assert.equal(f.p.calls(), 0);
});

test('custom style, long user instructions and empty optional appearance survive without paid calls or new gates', async () => {
    const f = await setup(), detail = '左边拿着纸船，右边在看海。' + '自定义细节。'.repeat(300);
    const input = { people: [{ name: '', appearance: '' }, { name: '', appearance: '' }], styleId: 'custom',
        customStyle: 'CUSTOM_STYLE', interaction: '自定义互动', interactionDetail: detail, direction: 'DIRECTION_END' };
    const before = JSON.stringify(input);
    await f.core.generateCouple(input, { context: f.host }); const sent = f.requests[0];
    assert.ok(sent.nl.includes(detail)); assert.ok(sent.characters.every(c => c.nl.includes(detail)));
    assert.match(sent.nl, /DIRECTION_END/); assert.match(sent.prompt, /CUSTOM_STYLE/);
    assert.equal(JSON.stringify(input), before); assert.equal(f.p.calls(), 1);
});

test('an edited inspiration is treated as literal user text, never partially replaced by a matching template', async () => {
    const f = await setup();
    const detail = f.styles.randomCoupleIdeas([], () => .6)[0] + '但右边现在转过身，不伸手。';
    const parts = f.core.couplePromptParts({ people, interaction: '自定义互动', interactionDetail: detail });
    assert.ok(parts.nai.nl.includes(detail));
    assert.ok(parts.nai.characters.every(c => c.nl.includes(detail)));
    assert.equal(f.p.calls(), 0);
});

test('legacy optional parts still work; malformed new briefs fall back rather than block a generation', async () => {
    const f = await setup();
    const parts = { scene: 'legacy scene', characters: [{name:'left',tag:'black hair'},{name:'right',tag:'silver hair'}],
        nai: { prompt: '', nl: null, characters: [] } };
    await f.get('generation/cgImageCore').invokeImageGeneration('complete fallback', f.host,
        { preservePrompt: true, singlePrompt: true, avatarPromptParts: parts });
    assert.equal(f.requests[0].prompt, 'legacy scene'); assert.equal(f.requests[0].nl, '');
    assert.equal(f.requests[0].characters.length, 2);
    assert.equal(f.p.calls(), 1);
});
