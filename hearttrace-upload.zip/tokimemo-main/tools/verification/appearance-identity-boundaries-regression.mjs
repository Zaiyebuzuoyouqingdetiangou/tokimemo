import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';

const plain = value => JSON.parse(JSON.stringify(value));
async function setup(format = 'nai5-natural') {
    const f = await fixture(), library = [], requests = [];
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS,
        imageGenerationProvider: 'baibai-image', cgPromptFormat: format, imageGenerationFallback: false });
    let textCalls = 0;
    f.get('generation/client').requestJson = async () => { textCalls++; throw Error('No implicit extraction'); };
    f.sb.STBaiBaiImage = { apiVersion: 1, capabilities: { characterLibrary: true, generate: true, saveToGallery: true },
        getCharacters: () => ({ apiVersion: 1, characters: library }),
        getBackendStatus: () => ({ configured: true, backend: 'nai', supportsCharacters: true }),
        generate: async value => { requests.push(plain(value)); return { path: '/user/images/identity-boundary.png' }; } };
    f.host.getCharacterCardFields = () => ({ description: 'black hair, eyebrow scar', persona: 'silver hair, green eyes' });
    return { ...f, library, requests, textCalls: () => textCalls,
        looks: f.get('core/castLooks'), couple: f.get('extras/coupleAvatar') };
}

for (const format of ['nai5-natural', 'nai45-tags']) test(`${format}: underscore identity and exact weighting reach the provider without clothes or actions`, async () => {
    const f = await setup(format);
    const traits = ['1girl', '1.2::black_hair::', 'long_hair', 'blue_eyes', 'mole_under_eye', 'white_blindfold', 'dimples'];
    f.library.push({ name: 'User', tag: [...traits, 'blue_shirt', 'waving_hands', 'full_body', 'closed_eyes'].join(', ') });
    const before = plain(f.library), settings = f.couple.defaultCoupleSettings(f.host);
    assert.equal(settings.people[1].appearance, traits.join(', '));
    await f.couple.generateCouple({ ...settings, styleId: 'chibi-headshot' }, { context: f.host });
    assert.equal(f.requests.length, 1); assert.equal(f.textCalls(), 0);
    const actor = f.requests[0].characters[1];
    for (const trait of traits) assert.ok(actor.tag.includes(trait), trait);
    assert.doesNotMatch(actor.tag, /blue_shirt|waving_hands|full_body|closed_eyes|silver hair/);
    assert.match(JSON.stringify(actor), /(?:covered eyes|eyes concealed|specified covering)/);
    assert.deepEqual(plain(f.library), before);
});

test('fixed scars survive history wording in default, ordinary CG and MV automatic appearance paths', async () => {
    const f = await setup(), scar = '曾经受伤留下的眉骨疤痕';
    f.host.getCharacterCardFields = () => ({ description: '黑色短发，' + scar, persona: '银色长发' });
    assert.match(f.couple.defaultCoupleSettings(f.host).people[0].appearance, /眉骨.*疤/);
    f.host.chatMetadata[f.looks.CAST_LOOKS_KEY] = { chatId: 'A', char: '黑色短发，' + scar, user: '银色长发', manual: false };
    assert.match(f.get('generation/cgAppearance').initialCgAppearanceMetadata({}, f.host).characters[0].tag, /眉骨.*疤/);
    assert.match(f.get('extras/mvCast').initialMvCast(f.host).appearances.find(row => row.participantId === 'mv-char').tag, /眉骨.*疤/);
    f.library.push({ name: 'Char', tag: '1boy，黑发，' + scar });
    assert.match(f.couple.defaultCoupleSettings(f.host).people[0].appearance, /眉骨.*疤/);
    for (const history of ['曾经留着金色长发', '后来戴上警帽', '曾经留下的疤痕已经消失', '血糊了半边脸']) {
        assert.equal(f.looks.lookFromDescription(history), '', history);
    }
});

test('standalone natural-language gender is explicit evidence while names and pronouns alone are not', async () => {
    const f = await setup();
    for (const [source, expected] of [
        ['一位成年女性', '成年女性'], ['她是一名成年女性', '成年女性'], ['他是成年男性', '成年男性'],
        ['Female.', 'Female'], ['She is an adult woman.', 'adult woman'], ['An adult man.', 'adult man'],
        ['Gender: female.', 'female'], ['non-binary', 'non-binary'],
    ]) assert.ok(f.looks.lookFromDescription(source).includes(expected), source);
    for (const source of ['她负责片区', '他做事认真', '女友是警察', '我的朋友是女性', '性格温柔', '名字：小月']) {
        assert.equal(f.looks.lookFromDescription(source), '', source);
    }
});

test('Chinese and English eye coverings, dimples and facial landmarks survive both automatic sources', async () => {
    const f = await setup();
    for (const traits of [
        ['white blindfold', 'black eyepatch', 'dimples', 'hooked nose', 'tear mole'],
        ['白色眼罩', '左颊一个深深的酒窝', '右眼下的泪痣', '鼻梁微拱'],
    ]) {
        const source = traits.join(', ');
        for (const trait of traits) assert.ok(f.looks.lookFromDescription(source).includes(trait), trait);
        f.library.splice(0, f.library.length, { name: 'User', tag: source });
        for (const trait of traits) assert.ok(f.couple.defaultCoupleSettings(f.host).people[1].appearance.includes(trait), trait);
    }
});

test('the current subject owns named clauses and comma continuations, including English full stops', async () => {
    const f = await setup();
    const card = { description: 'Char：男性，黑色短发。User：银色长发，右眼泪痣。Char：眉骨有旧疤。朋友留着红色长发，绿色眼睛。Char：鼻梁微拱。',
        persona: 'User is an adult woman. User has silver hair. Char has black hair, a facial scar. User has a tear mole.' };
    f.host.getCharacterCardFields = () => card;
    const before = plain(card), settings = f.couple.defaultCoupleSettings(f.host);
    for (const trait of ['男性', '黑色短发', '眉骨有旧疤', '鼻梁微拱']) assert.ok(settings.people[0].appearance.includes(trait), trait);
    assert.doesNotMatch(settings.people[0].appearance, /银色|泪痣|红色|绿色/);
    for (const trait of ['adult woman', 'silver hair', 'tear mole']) assert.ok(settings.people[1].appearance.includes(trait), trait);
    assert.doesNotMatch(settings.people[1].appearance, /black hair|facial scar/);
    const captured = f.looks.ensureCastLooks(f.host);
    assert.doesNotMatch(captured.char, /银色|泪痣|红色|绿色/);
    assert.doesNotMatch(captured.user, /black hair|facial scar/);
    const legacyRead = f.get('extras/coupleAvatarAppearance').readCoupleAppearance(settings, 0, f.host);
    assert.doesNotMatch(legacyRead.person.appearance, /银色|泪痣|红色|绿色/);
    await f.couple.generateCouple(settings, { context: f.host });
    assert.doesNotMatch(f.requests[0].characters[0].tag, /银色|泪痣|红色|绿色/);
    assert.doesNotMatch(f.requests[0].characters[1].tag, /black hair|facial scar/);
    assert.equal(f.textCalls(), 0); assert.deepEqual(plain(card), before);
});

test('role labels and literal special-character names do not turn another person into the source owner', async () => {
    const f = await setup();
    f.host.name2 = 'A[1]'; f.host.name1 = 'B+';
    f.host.getCharacterCardFields = () => ({ description: '{{char}}：black hair。{{user}}：silver hair，blue eyes。A[1]：eyebrow scar。',
        persona: 'B+：silver hair。A[1]：black hair，eyebrow scar。B+：tear mole。' });
    const settings = f.couple.defaultCoupleSettings(f.host);
    assert.match(settings.people[0].appearance, /black hair.*eyebrow scar/);
    assert.doesNotMatch(settings.people[0].appearance, /silver hair|blue eyes|\{\{/);
    assert.match(settings.people[1].appearance, /silver hair.*tear mole/);
    assert.doesNotMatch(settings.people[1].appearance, /black hair|eyebrow scar|\{\{/);
});

test('named natural preset paragraphs cannot import the other member of the pair', async () => {
    const f = await setup();
    f.library.push({ name: 'User', nl: 'User has silver hair. Char has black hair, thick eyebrows. User has a tear mole.' });
    const appearance = f.couple.defaultCoupleSettings(f.host).people[1].appearance;
    assert.match(appearance, /silver hair.*tear mole/);
    assert.doesNotMatch(appearance, /black hair|thick eyebrows/);
});

test('unlisted named subjects stay separate, including old automatic summaries reused by CG and MV', async () => {
    const f = await setup();
    const char = 'Char：黑色短发。姓名：路人。Robin has red hair, green eyes. 王强有银发，泪痣。Char：眉骨旧疤。';
    f.host.getCharacterCardFields = () => ({ description: char, persona: 'User：皮肤很白，身上有雀斑，眼睛是蓝色' });
    const settings = f.couple.defaultCoupleSettings(f.host);
    assert.match(settings.people[0].appearance, /黑色短发.*眉骨旧疤/);
    assert.doesNotMatch(settings.people[0].appearance, /red hair|green eyes|银发|泪痣/);
    assert.match(settings.people[1].appearance, /皮肤很白.*雀斑.*眼睛/);
    f.host.chatMetadata[f.looks.CAST_LOOKS_KEY] = { chatId: 'A', char, user: 'silver hair', manual: false };
    const cg = f.get('generation/cgAppearance').initialCgAppearanceMetadata({}, f.host);
    const mv = f.get('extras/mvCast').initialMvCast(f.host);
    assert.doesNotMatch(cg.characters[0].tag, /red hair|green eyes|银发|泪痣/);
    assert.doesNotMatch(mv.appearances.find(row => row.participantId === 'mv-char').tag, /red hair|green eyes|银发|泪痣/);
});

test('retained underscore anatomy still respects back and hands visibility for both providers', async () => {
    const f = await setup(), resolve = f.get('generation/imageAppearancePresets').resolveImageAppearancePresets;
    const tag = '1girl, black_hair, blue_eyes, cheek_dimples, pale_skin, slender_fingers';
    f.library.push({ name: 'User', tag });
    f.host.extensionSettings['st-chatu8'] = { characterPresets: { user: { nameEN: 'User', characterTraits: tag } } };
    for (const provider of ['baibai-image', 'chatu8-image']) {
        const read = visible => resolve(f.host, [{ id: 'user', name: 'User', visible }], { provider }).get('user')?.tag;
        assert.match(read('back'), /black_hair/); assert.doesNotMatch(read('back'), /blue_eyes|cheek_dimples/);
        assert.equal(read('hands'), 'pale_skin, slender_fingers');
    }
});

test('literal overrides and historical appearances stay unchanged and sparse valid inputs still generate', async () => {
    const f = await setup(), appearance = 'User有银发，朋友有蓝眼睛，曾经留过疤';
    const settings = { people: [{ id: 'char', name: 'Char', appearance, appearanceOverride: true },
        { id: 'user', name: 'User', appearance: '', appearanceOverride: true }] };
    f.library.push({ name: 'Char', tag: '1boy, blond hair' }, { name: 'User', tag: '1girl' });
    assert.deepEqual(plain(f.couple.normalizeCoupleSettings(settings, f.host).people), settings.people);
    assert.deepEqual(plain(f.couple.normalizeCoupleSettings(settings, null).people), settings.people);
    await f.couple.generateCouple(settings, { context: f.host });
    await f.couple.generateCouple({ people: [{ appearance: '' }, { appearance: '' }] }, { context: f.host });
    assert.equal(f.requests.length, 2); assert.equal(f.textCalls(), 0);
    assert.ok(f.requests[0].characters[0].tag.includes(appearance));
});
