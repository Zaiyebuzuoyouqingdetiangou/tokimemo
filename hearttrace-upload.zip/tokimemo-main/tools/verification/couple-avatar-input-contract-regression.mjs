import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { EventEmitter } from 'node:events';
import { fixture } from './fixture.mjs';

const root = path.resolve(process.env.TEST_ROOT || '.');
const plain = value => JSON.parse(JSON.stringify(value));
const names = ['方祁洛', '纪时卿'];
const ownLooks = ['1boy, black hair, high ponytail', '1girl, black hair, 双眼系纯白轻纱'];

// Reuse existing independent provider-contract harnesses, not their test cases.
// Both execute the downloaded upstream parser/parameter builder and replace
// only storage, configuration and network boundaries. No request leaves Node.
async function contractHarness(filename, boundary, exportName) {
    let source = fs.readFileSync(path.join(root, 'tools/verification', filename), 'utf8');
    const end = source.indexOf(boundary);
    assert.ok(end > 0, 'existing contract harness boundary is present');
    source = source.slice(0, end) + `\nexport { ${exportName} };`;
    const context = vm.createContext({ console, process, URL, AbortController, setTimeout, clearTimeout, Buffer, structuredClone });
    const module = new vm.SourceTextModule(source, { context, identifier: filename });
    await module.link(async specifier => {
        const values = specifier === './fixture.mjs' ? { fixture } : await import(specifier);
        return new vm.SyntheticModule(Object.keys(values), function () {
            for (const [key, value] of Object.entries(values)) this.setExport(key, value);
        }, { context });
    });
    await module.evaluate();
    return module.namespace[exportName];
}

const nativeChatu8Request = await contractHarness('couple-avatar-provider-contract-regression.mjs', 'async function setup(', 'nativeRequest');
const nativeBaiBaiProvider = await contractHarness('couple-avatar-baibai-regression.mjs', 'const people =', 'provider');

async function freshCouple(f) {
    const context = vm.createContext(f.sb), modules = new Map();
    async function load(id) {
        if (modules.has(id)) return modules.get(id);
        const sourceFile = path.join(root, 'src', id + '.js');
        // Read changed avatar authoring modules directly. A stale bundle must
        // not make this input-contract test silently exercise the old writer.
        const fresh = id.startsWith('extras/coupleAvatar');
        const values = fresh ? null : f.get(id);
        assert.ok(fresh || values, 'module boundary exists: ' + id);
        const module = fresh
            ? new vm.SourceTextModule(fs.readFileSync(sourceFile, 'utf8'), { context, identifier: id })
            : new vm.SyntheticModule(Object.keys(values), function () {
                for (const [key, value] of Object.entries(values)) this.setExport(key, value);
            }, { context, identifier: id });
        modules.set(id, module);
        await module.link((specifier, parent) => load(path.posix.normalize(path.posix.join(path.posix.dirname(parent.identifier), specifier)).replace(/\.js$/, '')));
        return module;
    }
    const module = await load('extras/coupleAvatar'); await module.evaluate();
    return module.namespace;
}

async function setup(provider, { styleId = 'chibi-sleepy', interaction = '隔空对望', clothing = '', appearances = ownLooks, promptFormat = 'nai5-natural' } = {}) {
    const f = await fixture(), requests = [], eventSource = new EventEmitter();
    const model = promptFormat === 'nai45-tags' ? 'nai-diffusion-4-5-full' : 'nai-diffusion-5-full';
    f.host.name2 = names[0]; f.host.name1 = names[1]; f.host.chatMetadata = {};
    f.host.eventSource = eventSource;
    f.host.extensionSettings['st-chatu8'] = {
        scriptEnabled: true, mode: 'novelai', novelaimode: model,
        novelai_width: 1216, novelai_height: 832,
        characterPresets: {
            left: { nameCN: names[0], characterTraits: '1boy, red hair, high ponytail' },
            right: { nameCN: names[1], characterTraits: '1girl, blue hair, high ponytail' },
        },
    };
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS,
        imageGenerationProvider: provider, imageGenerationFallback: false, cgPromptFormat: promptFormat });
    let paidTextCalls = 0;
    f.get('generation/client').requestJson = () => { paidTextCalls++; throw Error('No text model call is allowed'); };
    let upstream;
    if (provider === 'baibai-image') {
        upstream = await nativeBaiBaiProvider(model);
        f.sb.STBaiBaiImage = { ...upstream.api,
            capabilities: { ...upstream.api.capabilities, characterLibrary: true },
            getCharacters: () => ({ apiVersion: 1, characters: [
                { id: 'left', name: names[0], tag: '1boy, red hair, high ponytail' },
                { id: 'right', name: names[1], tag: '1girl, blue hair, high ponytail' },
            ] }),
            generate: (request, options) => { requests.push(plain(request)); return upstream.api.generate(request, options); },
        };
    } else {
        eventSource.on('generate-image-request', request => {
            requests.push(plain(request));
            eventSource.emit('generate-image-response', { id: request.id, success: true, imageData: '/user/images/input-contract.png' });
        });
    }
    const core = await freshCouple(f), initial = core.defaultCoupleSettings(f.host), inputs = new Map();
    assert.match(initial.people[1].appearance, /blue hair/, 'the fixture must actually start with a conflicting provider preset');
    for (let i = 0; i < 2; i++) for (const key of ['name', 'appearance']) {
        inputs.set(`[data-pair-person="${i}"][data-pair-key="${key}"]`, { value: key === 'appearance' ? appearances[i] : names[i] });
    }
    inputs.set('[data-pair-field="clothing"]', { value: clothing });
    const view = { settings: { ...initial, styleId, interaction }, context: f.host, root: { querySelector: selector => inputs.get(selector) } };
    const uiSource = fs.readFileSync(path.join(root, 'src/ui/coupleAvatarView.js'), 'utf8');
    const draftSource = uiSource.slice(uiSource.indexOf('function draft(view)'), uiSource.indexOf('function queueDraft(view)'));
    const draft = Function('couple', 'settingFields', 'structuredClone', draftSource + ';return draft;')(
        core, ['interaction', 'interactionDetail', 'clothing', 'background', 'direction', 'customStyle'], structuredClone);
    return { ...f, core, view, draft: () => draft(view), requests, async send() {
        const submitted = draft(view), result = await core.generateCouple(submitted, { context: f.host });
        assert.equal(requests.length, 1); assert.equal(paidTextCalls, 0);
        const actual = upstream ? upstream.actual() : (await nativeChatu8Request(requests[0], { model })).parameters;
        assert.equal(actual.v4_prompt.caption.char_captions.length, 2);
        return { submitted, saved: result.record.settings, request: requests[0], actual,
            left: actual.v4_prompt.caption.char_captions[0].char_caption,
            right: actual.v4_prompt.caption.char_captions[1].char_caption,
            scene: actual.v4_prompt.caption.base_caption };
    } };
}

for (const provider of ['baibai-image', 'chatu8-image']) {
    test(`${provider}: real UI manual appearance survives old presets, repeated draft reads, saving and native NAI5 captions`, async () => {
        const f = await setup(provider, { clothing: '同款不同色的卫衣' });
        for (let i = 0; i < 2; i++) {
            const value = f.draft();
            assert.deepEqual(plain(value.people.map(row => row.appearance)), ownLooks);
            assert.ok(value.people.every(row => row.appearanceOverride === true));
        }
        const sent = await f.send();
        assert.deepEqual(plain(sent.saved.people.map(row => row.appearance)), ownLooks);
        assert.equal(sent.saved.clothing, '同款不同色的卫衣');
        assert.match(sent.left, /black hair.*high ponytail/s); assert.doesNotMatch(sent.left, /双眼系纯白轻纱|blue hair|red hair/);
        assert.match(sent.right, /black hair.*双眼系纯白轻纱/s); assert.doesNotMatch(sent.right, /high ponytail|blue hair|red hair/);
        assert.match(JSON.stringify(sent.request), /同款不同色的卫衣/);
    });

    test(`${provider}: covered sleepy eyes use mouth, head or posture without forcing visible eyes or gaze`, async () => {
        const f = await setup(provider), sent = await f.send();
        assert.match(sent.right, /双眼系纯白轻纱/);
        assert.doesNotMatch(sent.right, /half[- ]closed eyes|return (?:the )?gaze|eye contact/i);
        assert.match(sent.right, /(?:sleep|drowsy)[\s\S]*(?:mouth|head|posture)|(?:mouth|head|posture)[\s\S]*(?:sleep|drowsy)/i);
        assert.match(sent.left, /half[- ]closed eyes/i, 'the unoccluded subject retains the selected sleepy style');
        assert.match(sent.left, /(?:turn|fac|lean)[^.]*right/i);
        assert.match(sent.right, /(?:turn|fac|lean)[^.]*left/i);
    });

    test(`${provider}: dot-eye styling cannot draw through a supplied full eye covering`, async () => {
        const f = await setup(provider, { styleId: 'chibi-doodle', interaction: '半颗爱心' }), sent = await f.send();
        assert.match(sent.left, /dot eyes|tiny solid dots/i);
        assert.match(sent.right, /双眼系纯白轻纱/);
        // A conditional "when visible" identity rule is compatible with a
        // retained covering; the bare style tag must not force visible eyes.
        assert.doesNotMatch(sent.right, /dot eyes|readable eyes/i);
        assert.match(sent.right, /cover|conceal|遮|蒙/i);
    });

    for (const clothing of ['左边穿黑色汉服；右边穿白色宽袖长袍', '方祁洛穿黑色汉服；纪时卿穿白色宽袖长袍']) {
        test(`${provider}: explicit side/name clothing is bound to its own subject (${clothing.startsWith('左边') ? 'side' : 'name'})`, async () => {
            const f = await setup(provider, { clothing }), sent = await f.send();
            assert.equal(sent.saved.clothing, clothing, 'the user field remains untouched');
            assert.match(sent.left, /黑色汉服/); assert.doesNotMatch(sent.left, /白色宽袖长袍/);
            assert.match(sent.right, /白色宽袖长袍/); assert.doesNotMatch(sent.right, /黑色汉服/);
        });
    }

    test(`${provider}: shared clothing remains shared without adding unsupplied differences`, async () => {
        const f = await setup(provider, { clothing: '同款灰色卫衣' }), sent = await f.send();
        assert.match(sent.left, /同款灰色卫衣/); assert.match(sent.right, /同款灰色卫衣/);
        assert.equal(sent.saved.clothing, '同款灰色卫衣');
    });

    test(`${provider}: visibility adaptation never deletes literal user-authored appearance words`, async () => {
        const appearances = [ownLooks[0], '1girl, black hair, blindfold, half-closed eyes'];
        const f = await setup(provider, { appearances }), sent = await f.send();
        assert.deepEqual(plain(sent.saved.people.map(row => row.appearance)), appearances);
        assert.match(sent.right, /black hair, blindfold, half-closed eyes/);
        assert.doesNotMatch(sent.right, /high ponytail/);
    });

    test(`${provider}: explicit NAI4.5 keeps tag channels while binding covering and side-specific clothing`, async () => {
        const f = await setup(provider, { promptFormat: 'nai45-tags', clothing: 'left black hanfu; right white robe' }), sent = await f.send();
        assert.match(sent.right, /双眼系纯白轻纱/); assert.doesNotMatch(sent.right, /half[- ]closed eyes|high ponytail/i);
        assert.match(sent.left, /half[- ]closed eyes/i);
        assert.doesNotMatch(sent.left, /covered eyes|retained eye covering|eye coverings? retained/i,
            'a subject with visible eyes must not receive positive covering tags');
        assert.match(sent.left, /black hanfu/); assert.doesNotMatch(sent.left, /white robe/);
        assert.match(sent.right, /white robe/); assert.doesNotMatch(sent.right, /black hanfu/);
        assert.equal(sent.saved.promptFormat, 'nai45-tags');
        if (provider === 'baibai-image') {
            assert.equal(sent.request.nl, '');
            assert.ok(sent.request.characters.every(row => row.nl === '' || row.nl === undefined));
        }
    });
}
