import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';

// Exercise the public editor and real chat-look storage with a small event host.
// This intentionally does not claim browser rendering or provider generation.
class Element {
    constructor(tag, attrs = '') {
        this.tag = tag; this.dataset = {}; this.value = ''; this.checked = false;
        this.isConnected = true; this.nodes = []; this.listeners = {};
        for (const [, name, value] of attrs.matchAll(/([\w-]+)(?:="([^"]*)")?/g)) {
            if (name.startsWith('data-')) this.dataset[name.slice(5).replace(/-([a-z])/g, (_, c) => c.toUpperCase())] = value || '';
            if (name === 'class') this.className = value;
        }
    }
    set innerHTML(value) { this.nodes = [...value.matchAll(/<([a-z]+)([^>]*)>/g)].map(([, tag, attrs]) => new Element(tag, attrs)); }
    matches(selector) {
        selector = selector.trim();
        if (selector.startsWith('.')) return (this.className || '').split(' ').includes(selector.slice(1));
        const match = selector.match(/^\[data-([\w-]+)(?:="([^"]*)")?\]$/);
        if (!match) return selector === this.tag;
        const key = match[1].replace(/-([a-z])/g, (_, c) => c.toUpperCase());
        return key in this.dataset && (match[2] === undefined || this.dataset[key] === match[2]);
    }
    querySelectorAll(selector) { return this.nodes.filter(el => selector.split(',').some(part => el.matches(part))); }
    querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
    addEventListener(name, callback) { (this.listeners[name] ||= []).push(callback); }
    removeEventListener() {}
    setAttribute(name, value) { this[name] = value; }
    removeAttribute(name) { delete this[name]; }
    appendChild(child) { this.child = child; }
    focus() {}
    remove() { this.isConnected = false; }
    async fire(name) { for (const callback of this.listeners[name] || []) await callback({ target: this, stopPropagation() {} }); }
}

async function editorFixture(item, { saved = null, preset = false } = {}) {
    const f = await fixture(), get = f.get, looks = get('core/castLooks');
    const images = get('generation/imageGeneration'), editor = get('ui/cgPromptEditor');
    get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS,
        cgPromptFormat: 'nai45-tags', imageGenerationProvider: preset ? 'chatu8-image' : 'baibai-image' });
    if (preset) f.host.extensionSettings['st-chatu8'] = { characterPresets: { Char: { nameEN: 'Char', characterTraits: 'golden hair' } } };
    f.host.getCharacterCardFields = () => ({ description: 'brown hair', persona: 'green eyes' });
    if (saved) looks.writeCastLooks(f.host, saved);
    const target = { mode: f.constants.MODE.CG, session: {}, itemId: 'one',
        origin: get('core/context').captureTaskOrigin(f.host, 'r1') };
    Object.assign(images, { selectedCgTarget: () => target, captureCgImageTarget: () => target,
        assertCgImageTargetCurrent() {}, cgItemInSession: () => item, normalizeCgImageRecord: row => row || null,
        isCgImageDrawing: () => false, hasPendingCgImage: () => false,
        cgImagePromptForItem: () => 'Char and User walk together', cgEditorSendPreview: () => null });
    get('archive/library').requireWritableArchiveAction = () => true;
    const host = new Element('div'), shell = new Element('div');
    host.querySelector = () => shell;
    f.sb.document = { getElementById: () => host, createElement: tag => new Element(tag) };
    f.sb.toastr = { error: message => assert.fail(message) };
    get('ui/overlay').confirmExplicitAction = () => true;
    let args;
    images.reconceiveCgImagePrompt = async (_target, options) => {
        args = options;
        return { imagePrompt: 'test', sceneTags: 'two people walking', flatPrompt: 'test', characters: [], selectedRoles: options.selectedRoles };
    };
    editor.openCgPromptEditor();
    assert.ok(shell.child, 'editor opened');
    return { f, looks, editor, root: shell.child, args: () => args,
        field: (kind, role) => shell.child.querySelector(`[data-rmt-cg-${kind}="${role}"]`) };
}

test('public legacy editor keeps a person with no appearance selected for reconceiving', async () => {
    const e = await editorFixture({ id: 'one', title: 'two-person scene' }, { preset: true });
    assert.equal(e.field('role-selected', 'char').checked, true);
    assert.equal(e.field('role-selected', 'user').checked, true);
    await e.editor.handleCgPromptEditorAction('reconceive');
    assert.deepEqual([...e.args().selectedRoles], ['char', 'user']);
    const evidence = e.f.get('generation/cgAppearance').captureCgAppearanceEvidence(e.f.host, e.args());
    assert.equal(evidence.characters.find(row => row.role === 'user').description, 'green eyes');
});

const solo = () => ({ id: 'one', title: 'solo', cgImage: { url: '/saved.png', promptMetadata: {
    selectedRoles: ['user'], characters: [{ role: 'user', name: 'User', tag: 'blue eyes' }],
} } });
const saved = { char: 'brown hair', user: 'blue eyes', manual: true };

test('reopening a scoped solo image then saving preserves the unchecked stored look', async () => {
    const e = await editorFixture(solo(), { saved });
    assert.equal(e.field('role-selected', 'char').checked, false);
    assert.equal(e.field('tag-input', 'char').value, '');
    await e.editor.handleCgPromptEditorAction('save-looks');
    assert.equal(e.looks.readCastLooks(e.f.host).char, 'brown hair');
    assert.equal(e.looks.readCastLooks(e.f.host).user, 'blue eyes');
});

test('an untouched missing look stays saved, while an explicitly edited empty field clears it', async () => {
    const e = await editorFixture(solo(), { saved });
    e.field('role-selected', 'char').checked = true;
    await e.editor.handleCgPromptEditorAction('save-looks');
    assert.equal(e.looks.readCastLooks(e.f.host).char, 'brown hair');
    e.field('tag-input', 'char').value = '';
    await e.field('tag-input', 'char').fire('input');
    await e.editor.handleCgPromptEditorAction('save-looks');
    assert.equal(e.looks.readCastLooks(e.f.host).char, '');
    assert.equal(e.looks.readCastLooks(e.f.host).user, 'blue eyes');
});

test('portrait defaults remain explicitly solo despite missing appearance', async () => {
    const e = await editorFixture({ id: 'one', title: 'portrait', cgPortrait: true });
    assert.equal(e.field('role-selected', 'char').checked, true);
    assert.equal(e.field('role-selected', 'user').checked, false);
});

test('late presets resolve every explicit role and participant, even without previous appearance rows', async () => {
    const f = await fixture(), api = f.get('generation/cgAppearance');
    f.host.extensionSettings['st-chatu8'] = { characterPresets: {} };
    const legacy = { selectedRoles: ['char', 'user'], characters: [{ role: 'char', name: 'Char', tag: 'own brown hair' }] };
    const multi = { castSnapshot: { version: 1, people: [{ id: 'a', name: 'Char', sourceRefs: [] }, { id: 'b', name: 'User', sourceRefs: [] }] }, characters: [] };
    assert.equal(api.resolveCgAppearanceMetadata(f.host, legacy, { provider: 'chatu8-image' }).characters.length, 1);
    f.host.extensionSettings['st-chatu8'].characterPresets.User = { nameEN: 'User', characterTraits: 'green eyes' };
    assert.equal(api.resolveCgAppearanceMetadata(f.host, legacy, { provider: 'chatu8-image' }).characters.find(row => row.role === 'user').tag, 'green eyes');
    assert.equal(api.resolveCgAppearanceMetadata(f.host, multi, { provider: 'chatu8-image' }).characters.find(row => row.participantId === 'b').tag, 'green eyes');
});

test('selected-provider resolution preserves manual appearance, complete prompt and own fallback', async () => {
    const f = await fixture(), api = f.get('generation/cgAppearance');
    f.host.extensionSettings['st-chatu8'] = { characterPresets: { Char: { characterTraits: 'golden hair' } } };
    const raw = { selectedRoles: ['char'], sceneTags: 'solo, walking', flatPrompt: 'old brown-haired Char walking',
        characters: [{ role: 'char', name: 'Char', tag: 'brown hair' }] };
    const resolved = api.resolveCgAppearanceMetadata(f.host, raw, { provider: 'chatu8-image' });
    assert.equal(resolved.characters[0].tag, 'golden hair');
    assert.equal(resolved.characters[0].fallbackTag, 'brown hair');
    assert.equal(resolved.sceneTags, raw.sceneTags);
    assert.equal(resolved.flatPrompt, undefined);
    f.host.extensionSettings['st-chatu8'].characterPresets = {};
    const fallback = api.resolveCgAppearanceMetadata(f.host, resolved, { provider: 'chatu8-image' });
    assert.equal(fallback.characters[0].tag, 'brown hair');
    assert.equal(fallback.characters[0].resolvedAppearance, true);
    f.host.extensionSettings['st-chatu8'].characterPresets = { Char: { characterTraits: 'golden hair' } };
    const manual = api.resolveCgAppearanceMetadata(f.host, { ...raw,
        characters: [{ ...raw.characters[0], tag: '', appearanceOverride: true }] }, { provider: 'chatu8-image' });
    assert.equal(manual.characters[0].tag, '');
    const complete = api.resolveCgAppearanceMetadata(f.host, { ...raw, flatPromptOverride: true }, { provider: 'chatu8-image' });
    assert.equal(complete.flatPrompt, raw.flatPrompt);
    assert.equal(complete.characters[0].tag, 'brown hair');
});

test('BaiBai presets precede saved appearance without losing long resolved tags on a flat backend', async () => {
    const f = await fixture(), appearance = f.get('generation/cgAppearance');
    f.get('core/settings').getPluginSettings = () => ({ imageGenerationProvider: 'baibai-image' });
    f.get('core/castLooks').readCastLooks = () => ({ manual: true, char: 'brown hair', user: 'blue eyes' });
    const tag = 'silver hair, '.repeat(320).trim().replace(/,$/, '');
    f.sb.STBaiBaiImage = { apiVersion: 1, capabilities: { characterLibrary: true },
        getCharacters: () => ({ apiVersion: 1, characters: [{ name: 'Char', tag }] }) };
    const metadata = appearance.initialCgAppearanceMetadata({}, f.host);
    assert.equal(metadata.characters.find(row => row.role === 'char').tag, tag);
    assert.equal(metadata.characters.find(row => row.role === 'user').tag, 'blue eyes');
    const send = appearance.formattedCgProviderPrompts('walking together', { ...metadata, promptFormat: 'nai45-tags' }, false);
    assert.ok(send.prompt.includes(tag));
    const evidence = appearance.captureCgAppearanceEvidence(f.host);
    assert.equal(evidence.characters.find(row => row.role === 'char').knownTag, tag);
});

test('manual complete prompt keeps NAI weights while removing actual unresolved templates', async () => {
    const f = await fixture(), api = f.get('generation/cgAppearance');
    const prompt = 'my full prompt, {{blue hair}}, {{{green eyes}}}, {{1.5::pale skin::}}, KEEP EXACT';
    const metadata = api.normalizeCgPromptMetadata({ flatPrompt: prompt, flatPromptOverride: true });
    assert.equal(metadata.flatPrompt, prompt);
    assert.equal(api.metadataAfterSceneEdit(metadata).flatPrompt, prompt);
    const dynamic = api.normalizeCgPromptMetadata({ flatPrompt: '{{char}}, {{getvar::look}}, {{blue hair}}', flatPromptOverride: true });
    assert.doesNotMatch(dynamic.flatPrompt, /char|getvar/);
    assert.ok(dynamic.flatPrompt.includes('{{blue hair}}'));
});

test('reconceiving uses a newly available preset ahead of untouched draft appearance', async () => {
    const f = await fixture(), api = f.get('generation/cgAppearance');
    f.get('core/settings').getPluginSettings = () => ({ imageGenerationProvider: 'chatu8-image' });
    f.host.extensionSettings['st-chatu8'] = { characterPresets: { Char: { characterTraits: 'golden hair' } } };
    const fresh = api.captureCgAppearanceEvidence(f.host, { selectedRoles: ['char'] });
    const untouched = api.appearanceEvidenceWithDraft(fresh, { char: { tag: 'own brown hair', appearanceOverride: false } }, f.host);
    assert.equal(untouched.characters[0].knownTag, 'golden hair');
    assert.equal(untouched.characters[0].fallbackTag, 'own brown hair');
    const edited = api.appearanceEvidenceWithDraft(fresh, { char: { tag: 'my red hair', appearanceOverride: true } }, f.host);
    assert.equal(edited.characters[0].knownTag, 'my red hair');
    assert.equal(edited.characters[0].appearanceOverride, true);
});

test('solo legacy selection cannot hide a known same-name or same-preset identity collision', async () => {
    for (const userName of ['ＣＨＡＲ', 'Alias']) {
        const f = await fixture(), api = f.get('generation/cgAppearance');
        f.host.name1 = userName;
        f.get('core/settings').getPluginSettings = () => ({ imageGenerationProvider: 'chatu8-image' });
        f.host.extensionSettings['st-chatu8'] = { characterPresets: {
            one: { nameEN: 'Char|Alias', characterTraits: 'golden hair' },
        } };
        const metadata = { selectedRoles: ['char'], characters: [{ role: 'char', name: 'Char', tag: 'own brown hair' }] };
        assert.equal(api.resolveCgAppearanceMetadata(f.host, metadata).characters[0].tag, 'own brown hair');
        const evidence = api.captureCgAppearanceEvidence(f.host, { selectedRoles: ['char'] });
        assert.equal(evidence.characters[0].presetAppearance, undefined);
    }
});

test('snapshot collision checks include known unselected IDs without replacing saved picture names', async () => {
    const f = await fixture(), api = f.get('generation/cgAppearance');
    f.get('core/settings').getPluginSettings = () => ({ imageGenerationProvider: 'chatu8-image' });
    f.host.extensionSettings['st-chatu8'] = { characterPresets: { one: { nameEN: 'Char|Alias', characterTraits: 'golden hair' } } };
    f.get('core/cache').readParticipantRoster = () => ({ people: [{ id: 'a', name: 'Changed display name' }, { id: 'b', name: 'Alias' }] });
    const metadata = { castSnapshot: { version: 1, people: [{ id: 'a', name: 'Char', sourceRefs: [] }] },
        characters: [{ participantId: 'a', tag: 'own brown hair' }] };
    const resolved = api.resolveCgAppearanceMetadata(f.host, metadata);
    assert.equal(resolved.characters[0].name, 'Char');
    assert.equal(resolved.characters[0].tag, 'own brown hair');
});
