// Read-only static/source scope and actual regression-result checks for 1.0.17.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const [candidate, baseline, beforeLog, afterLog] = process.argv.slice(2).map(x => path.resolve(x));
function files(root, rel = '') {
    return fs.readdirSync(path.join(root, rel), { withFileTypes: true }).flatMap(entry => {
        const name = path.join(rel, entry.name); assert.equal(entry.isSymbolicLink(), false);
        return entry.isDirectory() ? files(root, name) : [name];
    });
}
const sha = p => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const oldFiles = files(baseline), newFiles = files(candidate), changed = [];
for (const file of oldFiles) {
    assert.ok(newFiles.includes(file), 'No baseline file may disappear: ' + file);
    if (sha(path.join(candidate, file)) !== sha(path.join(baseline, file))) changed.push(file);
}
const added = newFiles.filter(file => !oldFiles.includes(file));
assert.deepEqual(changed.filter(x => x.startsWith('src/')), ['src/ui/mvView.js']);
assert.deepEqual(added.filter(x => x.startsWith('src/')), ['src/ui/mvEditorUi.js']);
let imports = 0;
for (const file of newFiles.filter(x => x.startsWith('src/') && x.endsWith('.js'))) {
    for (const [, rel] of fs.readFileSync(path.join(candidate, file), 'utf8').matchAll(/^import\s+.*?from\s+['"]([^'"]+)/gm)) {
        assert.ok(fs.statSync(path.resolve(candidate, path.dirname(file), rel)).isFile(), file + ':' + rel); imports++;
    }
}
for (const root of [candidate, baseline]) {
    const manifest = JSON.parse(fs.readFileSync(path.join(root, 'manifest.json'))), index = fs.readFileSync(path.join(root, 'index.js'), 'utf8');
    const version = index.match(/^const VERSION = '([^']+)';/m)[1], build = index.match(/^const BUILD = '([^']+)';/m)[1];
    assert.equal(manifest.version, version); assert.equal(manifest.js, 'index.js?heartbeat=' + build);
}
const previous = fs.readFileSync(beforeLog, 'utf8'), current = fs.readFileSync(afterLog, 'utf8');
const failures = log => Object.fromEntries([...log.matchAll(/^not ok \d+ - (.+)\n([\s\S]+?)^  \.\.\.$/gm)].map(([, name, body]) => [name, (body.match(/  error: ([\s\S]+?)  stack:/)?.[1] || body).replace(/\bF(\d+)_[a-z0-9]+\b/g, 'F$1_<generated-clock>')]));
const oldFailures = failures(previous), newFailures = failures(current);
const expected = ['frame cast is the exact intersection of shot people and appearance preference', 'revision drift journals paid result and survives a fresh runtime'];
assert.deepEqual(Object.keys(newFailures).sort(), expected);
for (const name of expected) assert.equal(newFailures[name], oldFailures[name], 'Historical failure payload changed: ' + name);
assert.doesNotMatch(current, /^# (?:cancelled|skipped|todo) [1-9]/m);
assert.equal(Object.keys(oldFailures).length, 3);
console.log(JSON.stringify({ imports, baselineFiles: oldFiles.length, candidateFiles: newFiles.length, changed, added,
    bundleSha256: sha(path.join(candidate, 'dist/heartbeatMemories.bundle.js')), tests: Number(current.match(/^# tests (\d+)/m)[1]),
    pass: Number(current.match(/^# pass (\d+)/m)[1]), knownFailures: expected, unchangedFailurePayloads: true,
    fixedHistoricalFailure: 'a verse-only export does not preload a motif that is only rendered in the chorus' }, null, 2));
