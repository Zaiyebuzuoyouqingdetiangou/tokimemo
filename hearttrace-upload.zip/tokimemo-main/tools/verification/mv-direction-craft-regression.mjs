import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';

const directions = ['auto', 'narrative', 'lyrical', 'interaction', 'impact', 'loop', 'reveal'];
const song = { id: 'SONG_craft', title: '回声', bpm: 120, lyrics: '[Verse 1]\n第一句\n第二句\n[Chorus]\n回应\n[End]' };
const raw = { groups: [{ id: 'A', who: 'char', composition: '主图', diffs: [{ id: 'a', imagePrompt: 'one still figure' }, { id: 'b', imagePrompt: 'one still figure, gaze to the left' }] }],
    frames: [...[1, 1, 8].map((hold, i) => ({ sectionIndex: 0, lyric: '第一句', group: 'A', diff: i === 1 ? 'b' : 'a', hold })),
        { sectionIndex: 1, lyric: '回应', group: 'A', diff: 'a', hold: 1 }] };
const plain = x => JSON.parse(JSON.stringify(x));
async function setup(direction = 'impact') {
    const f = await fixture(), mv = f.get('extras/mv');
    f.get('core/cache').loadSession = () => ({ songs: [song] });
    const settings = mv.normalizeSettings({ output: 'tegaki', storyType: direction, range: 'full' });
    const record = { ...mv.buildShots(f.json(raw), f.bank, 2, settings), settings, duration: 12,
        timing: { taps: { 0: 0, 1: 10 } }, tegaki: { template: 'quick' } };
    return { ...f, mv, settings, record };
}

test('new category plans retain a deliberate 1:1:8 pause under the quick preset', async () => {
    for (const direction of directions) {
        const { mv, record } = await setup(direction);
        assert.deepEqual(plain(mv.shotTimeline(record, song).rows.slice(0, 3).map(r => r.end - r.start)), [1, 1, 8], direction);
    }
});

test('legacy quick timing and expression remain unchanged, even with an authored flag', async () => {
    for (const direction of ['impact', 'expression', 'illustration']) {
        const { mv, record } = await setup(direction);
        if (direction === 'impact') for (const shot of record.shots) delete shot.authoredTiming;
        else for (const shot of record.shots) shot.authoredTiming = true;
        assert.deepEqual(plain(mv.shotTimeline(record, song).rows.slice(0, 3).map(r => r.start)), [0, 3.5, 6.5], direction);
    }
});

test('explicit lyric marks keep exact non-beat time for new plans', async () => {
    const { mv, record } = await setup();
    record.shots[1].lyric = '第二句'; record.shots[2].lyric = '第二句';
    record.timing.lineTaps = { '0:1': 1.37 };
    assert.equal(mv.shotTimeline(record, song).rows[1].start, 1.37);
});

test('timing without a supplied hold uses legacy quick fallback and adds no marker', async () => {
    const { mv, record, settings, json, bank } = await setup();
    const input = plain(raw); input.frames.forEach(f => delete f.hold);
    const built = mv.buildShots(json(input), bank, 2, settings);
    assert.ok(built.shots.every(s => s.authoredTiming === undefined));
    assert.deepEqual(plain(mv.shotTimeline({ ...record, ...built }, song).rows.slice(0, 3).map(r => r.start)), [0, 3.5, 6.5]);
});

test('each category delivers a distinct executable example with valid original section and asset references', async () => {
    const examples = [];
    for (const direction of directions) {
        const f = await setup(direction); let prompt = '';
        f.get('generation/client').requestJson = async p => { prompt = p; return f.json(raw); };
        await f.mv.generateStoryboard(song.id, f.settings);
        assert.doesNotMatch(prompt, /其余段落尽量用新的构图|motif：歌词里一个可以漂浮的意象/);
        const example = JSON.parse(prompt.split('\n').at(-1));
        assert.ok(example.frames.length > 1, direction);
        for (const frame of example.frames) {
            assert.ok([0, 1].includes(frame.sectionIndex));
            assert.ok(example.groups.find(g => g.id === frame.group)?.diffs.some(d => d.id === frame.diff));
            assert.ok(frame.hold > 0);
        }
        const cast = f.mv.readMv(f.host, song.id).cast;
        const parsed = f.mv.buildShots(f.json(example), f.bank, 2, f.settings, cast);
        assert.equal(parsed.shots.length, example.frames.length);
        assert.ok(parsed.groups.every(g => g.layer === 'full'), 'these types still use complete stills');
        for (const group of parsed.groups.filter(g => Array.isArray(g.cast) && !g.cast.length)) {
            const prompt = f.mv.assetPrompt({ ...parsed, settings: f.settings, cast }, `${group.id}:D1`, f.host);
            assert.match(prompt, /no humans/);
            assert.doesNotMatch(prompt, /solo, single figure/);
        }
        if (direction === 'loop') {
            const pairs = example.frames.map(frame => `${frame.group}:${frame.diff}`);
            assert.ok(new Set(pairs).size < pairs.length, 'reuse must use the same asset ID');
            assert.equal(f.mv.assetKeys({ ...parsed, settings: f.settings }, song).length, new Set(pairs).size);
        }
        examples.push(JSON.stringify(example));
    }
    assert.equal(new Set(examples).size, directions.length);
});

test('category examples bind selected people to their corresponding reactions', async () => {
    const f = await setup('interaction'), roster = { version: 1, cardType: 'multi', selectedIds: ['a', 'b'], people: [
        { id: 'a', name: '甲', sourceRefs: [] }, { id: 'b', name: '乙', sourceRefs: [] }], appearances: [] };
    let prompt = '';
    f.get('generation/client').requestJson = async p => { prompt = p; return f.json(raw); };
    await f.mv.generateStoryboard(song.id, f.settings, f.json(roster));
    const example = JSON.parse(prompt.split('\n').at(-1));
    const ids = new Set(example.groups.flatMap(g => g.cast.map(p => p.participantId)));
    assert.deepEqual([...ids], ['a', 'b']);
    assert.match(example.groups[0].diffs[0].imagePrompt, /甲/);
    assert.match(example.groups[1].diffs[0].imagePrompt, /乙/);
});

test('craft finish follows the chosen medium without forcing portrait features into silhouettes or hands', async () => {
    const f = await setup();
    for (const [style, expected] of [['line', /line weight/], ['water', /watercolor edges/], ['pastel', /painterly forms/], ['mono', /negative space/], ['keep', /chosen art style/]]) {
        f.record.settings.style = style;
        const prompt = f.mv.defaultAssetPrompt(f.record, 'G1:D1', f.host);
        assert.match(prompt, expected);
        assert.doesNotMatch(prompt, /8k|masterpiece|photorealistic/);
    }
});

test('a manual complete image prompt remains exact', async () => {
    const f = await setup();
    // Use the public editor so this checks the actual override contract.
    f.host.chatMetadata[f.mv.MV_KEY] = { songs: { [song.id]: f.record } };
    await f.mv.saveAssetEdit(f.mv.captureAssetEdit(song.id, 'G1:D1'), { prompt: 'CUSTOM exact' });
    assert.equal(f.mv.assetPrompt(f.mv.readMv(f.host, song.id), 'G1:D1', f.host), 'CUSTOM exact');
});
