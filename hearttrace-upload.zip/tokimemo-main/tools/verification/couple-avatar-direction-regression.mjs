import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = process.env.TEST_ROOT || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const sourceModule = async file => import('data:text/javascript;base64,' + Buffer.from(await fs.readFile(path.join(root, 'src/extras', file), 'utf8')).toString('base64'));
const { coupleInteractionDirection } = await sourceModule('coupleAvatarInteractionDirection.js');
const { INTERACTION_PRESETS } = await sourceModule('coupleAvatarStyles.js');
const plain = value => JSON.parse(JSON.stringify(value));

test('direction helper: half-heart explicitly turns the left head right and the right head left', () => {
    const result = coupleInteractionDirection({ interaction: '半颗爱心' });
    assert.match(result.scene, /inward head angles/);
    assert.match(result.roles[0], /head toward the right/);
    assert.match(result.roles[1], /head toward the left/);
    assert.match(result.roles[1], /answer.*warmly/);
    assert.match(result.tags.roles[0], /head angled right toward partner/);
    assert.match(result.tags.roles[1], /head angled left toward partner/);
});

test('direction helper: every built-in has a concrete response in both dialects and no visibility demand', () => {
    assert.equal(INTERACTION_PRESETS.length, 48);
    for (const preset of INTERACTION_PRESETS) {
        const result = coupleInteractionDirection({ interaction: preset.label });
        assert.doesNotMatch(result.scene, /^Follow the supplied interaction/, preset.label);
        assert.equal(result.roles.length, 2);
        assert.notEqual(result.roles[0], result.roles[1], preset.label);
        assert.match(result.scene, /Retain supplied eye coverings/, preset.label);
        assert.match(result.scene, /specified closed-eye expression/, preset.label);
        for (const sentence of [result.scene, ...result.roles]) {
            assert.doesNotMatch(sentence, /open (?:the |both |their )?eyes|remove.*(?:blindfold|covering)|visible irises|eye contact required/i, preset.label);
        }
        for (const tags of [result.tags.scene, ...result.tags.roles]) {
            assert.doesNotMatch(tags, /[^\x20-\x7e]|[.;\n]/, preset.label);
            assert.ok(tags.split(',').every(tag => tag.trim().split(/\s+/).length <= 12), preset.label);
            assert.doesNotMatch(tags, /blindfold|eye coverings|closed.eye expression|eyes (?:open|closed)/i, preset.label);
        }
    }
});

test('direction helper: fireworks, books, snowflakes, fireflies and breeze keep their selected focus', () => {
    for (const [interaction, shared] of [
        ['一起看烟花', /same distant fireworks/], ['一起读一本书', /same open page/],
        ['一起捧雪花', /each snowflake/], ['夏夜捕萤', /fireflies as the focus/], ['同一阵风', /same breeze/],
    ]) {
        const result = coupleInteractionDirection({ interaction });
        assert.match(result.scene, shared);
        assert.doesNotMatch(result.roles.join(' '), /head toward the (?:right|left), toward the partner/);
        assert.doesNotMatch(JSON.stringify(result), /mutual gaze|looking at each other|eye contact required/);
    }
    const front = coupleInteractionDirection({ interaction: '同款不同色' });
    assert.ok(front.roles.every(role => role.includes('mostly front-facing')));
    const shy = coupleInteractionDirection({ interaction: '一边偷看一边躲' });
    assert.match(shy.roles[1], /bashfully averted head angle/);
});

test('direction helper: custom back-to-back, unknown values and explicit user direction are never reoriented', () => {
    const values = [
        { interaction: '自定义互动', interactionDetail: '两人背靠背，不对视，保留眼罩' },
        { interaction: '背靠背' }, { interaction: 'constructor' }, { interaction: '__proto__' },
        { interaction: '半颗爱心', direction: '背靠背，一人低头，一人仰头' },
        { interaction: '交给灵感' }, { interaction: '' }, null,
    ];
    for (const settings of values) {
        const before = plain(settings);
        const result = coupleInteractionDirection(settings);
        assert.match(result.scene, /back-to-back or averted orientation/);
        assert.match(result.scene, /Explicit user direction takes precedence/);
        assert.doesNotMatch(result.roles.join(' '), /head toward the (?:right|left)|head angled (?:right|left)/);
        assert.ok(result.tags.roles.every(role => role.includes('user-directed orientation retained')));
        assert.deepEqual(plain(settings), before);
    }
});

test('direction helper: independent results and literal identities remain unchanged', () => {
    const input = Object.freeze({ interaction: '半颗爱心', people: Object.freeze([
        Object.freeze({ name: 'A', appearance: 'black hair, white blindfold' }),
        Object.freeze({ name: 'B', appearance: 'black hair, pink eyes' }),
    ]) });
    const before = plain(input), first = coupleInteractionDirection(input);
    first.roles[0] = 'CHANGED'; first.tags.roles[0] = 'CHANGED';
    const second = coupleInteractionDirection(input);
    assert.match(second.roles[0], /head toward the right/);
    assert.doesNotMatch(JSON.stringify(second), /CHANGED|black hair|pink eyes|artist|quality|human hands/);
    assert.deepEqual(plain(input), before);
});

test('actual prompt parts: NAI5 actor roles and NAI4.5 tags carry directions without another request', async () => {
    const { fixture } = await import('./fixture.mjs');
    const f = await fixture(), requests = [];
    f.host.chatMetadata = {};
    let format = 'nai5-natural';
    f.get('core/settings').getPluginSettings = () => ({ ...f.constants.DEFAULT_SETTINGS,
        imageGenerationProvider: 'baibai-image', imageGenerationFallback: false, cgPromptFormat: format });
    f.sb.STBaiBaiImage = { apiVersion: 1, capabilities: { generate: true, saveToGallery: true },
        getBackendStatus: () => ({ configured: true, backend: 'nai', supportsCharacters: true }),
        generate: async request => { requests.push(plain(request)); return { path: '/user/images/direction.png' }; } };
    f.get('generation/client').requestJson = () => { throw Error('No extra model request allowed'); };
    const core = f.get('extras/coupleAvatar');
    const settings = { styleId: 'anime-clean', interaction: '半颗爱心', people: [
        { name: 'A', appearance: 'black hair, white blindfold', appearanceOverride: true },
        { name: 'B', appearance: 'black hair, pink eyes', appearanceOverride: true },
    ] };
    const natural = core.couplePromptParts(settings, f.host);
    assert.match(natural.scene, /inward head angles/);
    assert.match(natural.nai.characters[0].nl, /head toward the right/);
    assert.match(natural.nai.characters[1].nl, /head toward the left/);
    await core.generateCouple(settings, { context: f.host });
    assert.equal(requests.length, 1);
    assert.match(requests[0].characters[0].nl, /head toward the right/);
    assert.match(requests[0].characters[1].nl, /head toward the left/);
    assert.match(requests[0].characters[0].tag, /white blindfold/);
    assert.doesNotMatch(requests[0].characters[1].tag, /white blindfold/);
    format = 'nai45-tags';
    const tagged = core.couplePromptParts(settings, f.host);
    assert.match(tagged.scene, /reciprocal inward head angles/);
    assert.equal(tagged.nai.nl, '');
    assert.equal(tagged.nai.characters[0].nl, '');
    assert.match(tagged.nai.characters[0].tag, /head angled right toward partner/);
    assert.match(tagged.nai.characters[1].tag, /head angled left toward partner/);
    assert.doesNotMatch(tagged.scene, /Retain supplied|Explicit user direction|Angle the head/);
    assert.equal(requests.length, 1);
});
