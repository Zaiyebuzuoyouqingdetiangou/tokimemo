import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fixture } from './fixture.mjs';

const root=path.resolve(process.env.TEST_ROOT||'.');
const readme=fs.readFileSync(path.join(root,'README.md'),'utf8');
const sample='# 心迹回廊 1.0.28\n\n## 更新日志模块\n\n新增了更新日志板块，感谢@nancyindaeyo的更新。\n\n## 本次变动\n\n- 只显示这次的说明。\n- 不修改已有图片。\n\n## 旧版本\n\n- 旧内容不显示。\n';

test('installed notes come from the exact bundled README, without network or old remote history',async()=>{
 const f=await fixture();let requests=0;
 const result=await f.get('core/selfUpdater').loadHearttraceChangelog({fetcher:async()=>{requests++;throw Error('offline')}});
 assert.equal(requests,0);assert.equal(result.ok,true);assert.equal(result.source,'readme');
 assert.equal(f.get('core/releaseNotes').RELEASE_README,readme);
 assert.equal(result.sections.length,1);
 assert.deepEqual(Array.from(result.sections[0].groups,g=>g.title),['更新日志模块','本次变动']);
 assert.equal(result.sections[0].version,JSON.parse(fs.readFileSync(path.join(root,'manifest.json'),'utf8')).version);
 const expected=readme.split(/\r?\n/).filter(s=>s.trim()&&!s.startsWith('#')).map(s=>s.replace(/^- /,''));
 assert.deepEqual(Array.from(result.sections[0].items),expected);
});

test('README parser retains credit and current changes, never adds older sections',async()=>{
 const f=await fixture(),rows=f.get('core/selfUpdater').parseHearttraceReadme(sample);
 assert.equal(rows.length,1);assert.equal(rows[0].version,'1.0.28');
 assert.deepEqual(Array.from(rows[0].items),['新增了更新日志板块，感谢@nancyindaeyo的更新。','只显示这次的说明。','不修改已有图片。']);
});

test('remote update preview reads the selected branch README, never CHANGELOG or main',async()=>{
 const f=await fixture(),urls=[];
 const result=await f.get('core/selfUpdater').loadHearttraceChangelog({source:'remote',remoteUrl:'https://github.com/Zaiyebuzuoyouqingdetiangou/tokimemo',remoteBranch:'from-nancy-test',fetcher:async url=>{urls.push(String(url));return new Response(sample)}});
 assert.equal(result.ok,true);assert.equal(result.sections[0].version,'1.0.28');
 assert.ok(urls.length);assert.ok(urls.every(u=>u.includes('README.md')&&u.includes('from-nancy-test')&&!u.includes('CHANGELOG')&&!u.includes('/main/')));
});

test('failed remote README does not silently substitute installed notes or old history',async()=>{
 const f=await fixture();const result=await f.get('core/selfUpdater').loadHearttraceChangelog({source:'remote',fetcher:async()=>new Response('Not found',{status:404})});
 assert.equal(result.ok,false);assert.equal(result.sections.length,0);
});

test('README parser handles CRLF, wrapped paragraphs and hostile strings as plain data',async()=>{
 const f=await fixture(),parse=f.get('core/selfUpdater').parseHearttraceReadme;
 const notes=sample.replace('只显示这次的说明。','<img src=x onerror=alert(1)>').replaceAll('\n','\r\n');
 const rows=parse('\ufeff'+notes);assert.equal(rows[0].items[1],'<img src=x onerror=alert(1)>');
 assert.equal(parse('<html>error page</html>').length,0);
 assert.equal(parse('# 1.0.28\n- no supported section').length,0);
});

test('current UI consumes README groups and chooses installed vs remote notes explicitly',()=>{
 const ui=fs.readFileSync(path.join(root,'src/ui/homeView.js'),'utf8');
 assert.match(ui,/source: updateMode \? 'remote' : 'installed'/);
 assert.match(ui,/section\.groups/);assert.match(ui,/label\.textContent = group\.title/);
 assert.match(ui,/li\.textContent = item/);
});
