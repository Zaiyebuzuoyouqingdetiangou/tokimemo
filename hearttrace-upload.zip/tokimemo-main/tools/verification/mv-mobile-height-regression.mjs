// Recording-driven regression: recovery and paging must not consume the editing
// viewport. These are production-bundle/stylesheet checks, not browser geometry.
import test from 'node:test';
import assert from 'node:assert/strict';
import { ui } from './mv-ui-fixture.mjs';
import { stageSetup } from './mv-stage-fixture.mjs';

async function setup() {
    const f = await ui(stageSetup);
    f.sb.document.querySelector = () => null;
    for (const g of f.record.groups) for (const d of g.diffs) d.image = { url: '/frame.png' };
    return f;
}

test('three pending results have one compact editor entry and every save-only action remains in its drawer', async () => {
    const f = await setup();
    const rows = Array.from({ length: 3 }, (_, i) => ({ id: `pending-${i}`, song: { title: `另一首歌 ${i}` }, reason: '原聊天、档案或歌曲已变化' }));
    f.get('extras/mv').pendingMv = () => rows;
    try {
        f.mvui.openMv({ songId: f.song.id });
        assert.match(f.body.innerHTML, /data-rmt-mv-pending="3"/);
        assert.doesNotMatch(f.body.innerHTML, /另一首歌|data-rmt-mv="retry-save"/);
        f.click('editor-drawer', 'more');
        assert.equal((f.body.innerHTML.match(/data-rmt-mv="retry-save"/g) || []).length, 3);
        assert.match(f.body.innerHTML, /data-rmt-mv="export-recovery"/);
        for (const row of rows) assert.ok(f.body.innerHTML.includes(row.id));
        f.click('editor-drawer'); f.click('go-board');
        assert.equal((f.body.innerHTML.match(/data-rmt-mv="retry-save"/g) || []).length, 3);
    } finally { f.mvui.disposeMv(); }
});

test('a short filmstrip has no disabled page row while long projects keep every page reachable', async () => {
    const f = await setup();
    try {
        f.mvui.openMv({ songId: f.song.id });
        assert.doesNotMatch(f.body.innerHTML, /class="rmt-mve-strip-nav"/);
        const sample = f.record.shots[0];
        f.record.shots = Array.from({ length: 29 }, (_, i) => ({ ...sample, id: `SHOT_${i}`, sectionIndex: 0 }));
        f.mvui.openMv({ songId: f.song.id });
        assert.match(f.body.innerHTML, /class="rmt-mve-strip-nav"/);
        f.click('editor-strip', '28');
        assert.match(f.body.innerHTML, /data-rmt-mv="select-shot" data-rmt-mv-id="SHOT_28"/);
        assert.match(f.body.innerHTML, /data-rmt-mv="editor-strip" data-rmt-mv-id="24"/);
    } finally { f.mvui.disposeMv(); }
});

test('small host viewports have a scroll escape and a non-collapsing canvas instead of a forty-pixel minimum', async () => {
    const f = await setup();
    const css = f.get('ui/mvEditorUi').editorCss('#test');
    assert.match(css, /\.rmt-body\.rmt-mve-body[^}]*overflow:auto!important/);
    assert.match(css, /\.rmt-x-page\.rmt-mv-editor\{[^}]*min-height:0/);
    assert.doesNotMatch(css, /min-height:(740|670|630)px/);
    // Width plus film ratio replaces the old 160px floor: that floor could
    // still leave a wide phone preview with a much smaller canvas inside it.
    assert.match(css, /\.rmt-mve-preview \.rmt-mv-canvas-wrap\{[^}]*aspect-ratio:16\/9[^}]*flex:0 0 auto/);
    assert.match(css, /\.rmt-mve-preview \.rmt-mv-canvas-wrap\.portrait\{[^}]*aspect-ratio:9\/16/);
    assert.doesNotMatch(css, /\.rmt-mv-canvas-wrap\.portrait\{[^}]*min-height:40px/);
    assert.match(css, /\.rmt-mve-head h2\{[^}]*font-size:17px!important/);
    assert.match(css, /\.rmt-mve-preview-head button[^}]*font-size:12px!important/);
    const imageCss = f.get('ui/mvImageEditorUi').imageEditorCss('#test');
    // The recording showed chrome consuming the canvas. Image editing now uses
    // its own focus surface, not a 680px page inside that already shrunken body.
    assert.match(imageCss, /\.rmt-shell\.rmt-mvi-focus>\.rmt-workspace-tabs/);
    assert.match(imageCss, /\.rmt-mve-image-page\{[^}]*flex:1 1 0;min-height:0/);
    assert.match(imageCss, /\.rmt-mvi-layout\{[^}]*grid-template-rows:minmax\(0,1fr\) auto/);
    assert.match(imageCss, /\.rmt-mv-editor-viewport\{[^}]*min-height:0/);
    assert.match(imageCss, /::-webkit-slider-runnable-track\{height:6px!important/);
    assert.match(imageCss, /\.rmt-mvi-workbench button\{[^}]*min-height:44px/);
});

test('image focus opens with an immediate return action and releases the shell on back or disposal', async () => {
    const f = await setup(), classes = new Set(), bodyClasses = new Set();
    const classList = set => ({ toggle(name, on) { if (on) set.add(name); else set.delete(name); }, remove(name) { set.delete(name); } });
    f.body.classList = classList(bodyClasses);
    f.body.closest = selector => selector === '.rmt-shell' ? { classList: classList(classes) } : null;
    try {
        f.mvui.openMv({ songId: f.song.id });
        f.click('edit-asset', 'G1:D1');
        assert.equal(classes.has('rmt-mvi-focus'), true);
        assert.match(f.body.innerHTML, /data-rmt-mv="back"/);
        f.click('back'); assert.equal(classes.has('rmt-mvi-focus'), false);
        f.click('edit-asset', 'G1:D1'); assert.equal(classes.has('rmt-mvi-focus'), true);
    } finally { f.mvui.disposeMv(); }
    assert.equal(classes.has('rmt-mvi-focus'), false);
});

test('pending results do not take image canvas space and remain reachable after returning', async () => {
    const f = await setup();
    f.get('extras/mv').pendingMv = () => [{ id: 'kept-pending', song: { title: '待保存作品' }, reason: '等待保存' }];
    try {
        f.mvui.openMv({ songId: f.song.id });
        f.click('edit-asset', 'G1:D1');
        assert.doesNotMatch(f.body.innerHTML, /rmt-mve-recovery|kept-pending/);
        assert.match(f.body.innerHTML, /data-rmt-mv="back"/);
        f.click('back'); f.click('editor-drawer', 'more');
        assert.match(f.body.innerHTML, /kept-pending/);
        assert.match(f.body.innerHTML, /data-rmt-mv="retry-save"/);
        assert.match(f.body.innerHTML, /data-rmt-mv="clear-pending"/);
    } finally { f.mvui.disposeMv(); }
});
