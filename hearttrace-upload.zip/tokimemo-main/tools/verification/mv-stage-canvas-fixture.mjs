import { createRequire } from 'node:module';
import { ui } from './mv-ui-fixture.mjs';
import { stageSetup } from './mv-stage-fixture.mjs';
const require = createRequire(import.meta.url);
export const native = require(require.resolve('@napi-rs/canvas', { paths: [process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES || process.cwd()] }));

export async function scene({ ratio = '16:9', opaque = false, matte = '', unconfirmed = false, imageBackground = false } = {}) {
    const f = await ui(stageSetup), w = ratio === '16:9' ? 960 : 540, h = ratio === '16:9' ? 540 : 960;
    f.record.settings.ratio = ratio;
    const decodes = [], draws = [], errors = [], canvases = [];
    f.sb.toastr = { error: e => errors.push(e), success() {}, info() {} };
    f.sb.Image = class extends native.Image { set src(value) { this.inputValue = value; super.src = value; decodes.push(this.decode()); } get src() { return this.inputValue; } };
    const canvas = () => {
        const c = native.createCanvas(w, h), g = c.getContext('2d'), fill = g.fillText.bind(g), image = g.drawImage.bind(g);
        g.fillText = (text, ...args) => { draws.push({ canvas: c, text }); fill(text, ...args); };
        g.drawImage = (img, ...args) => { draws.push({ canvas: c, image: img.src, transform: g.getTransform() }); image(img, ...args); };
        const track = { canvas: c, stop() {} };
        c.style = {}; c.remove = () => {}; c.captureStream = () => ({ getTracks: () => [track], getVideoTracks: () => [track] });
        canvases.push(c); return c;
    };
    const preview = canvas(); f.canvas.width = w; f.canvas.height = h; f.canvas.getContext = () => preview.getContext('2d');
    const create = f.sb.document.createElement; f.sb.document.createElement = tag => tag === 'canvas' ? canvas() : create(tag);
    const art = (crossed, color) => {
        const c = native.createCanvas(160, 240), g = c.getContext('2d');
        if (opaque || matte) { g.fillStyle = matte || '#00ff00'; g.fillRect(0, 0, 160, 240); }
        g.fillStyle = color; g.beginPath(); g.arc(80, 56, 34, 0, Math.PI * 2); g.fill();
        g.fillRect(48, 92, 64, 146); g.lineCap = 'round'; g.lineWidth = 18; g.strokeStyle = color;
        g.beginPath(); g.moveTo(55, 110); g.lineTo(crossed ? 108 : 18, crossed ? 151 : 159);
        g.moveTo(105, 110); g.lineTo(crossed ? 51 : 142, crossed ? 151 : 159); g.stroke();
        g.fillStyle = '#17202b'; g.fillRect(64, 51, 8, 7); g.fillRect(89, 51, 8, 7);
        return { url: c.toDataURL(), ...(!unconfirmed ? { editMode: opaque ? 'full' : 'cutout' } : {}), split: 'none' };
    };
    const art1 = art(false, '#ee5555'), art2 = art(true, '#5599ee');
    f.record.groups[0].diffs[0].image = art1; f.record.groups[1].diffs[0].image = art2;
    if (imageBackground) {
        const c = native.createCanvas(w, h), g = c.getContext('2d'); g.fillStyle = '#167245'; g.fillRect(0, 0, w, h);
        Object.assign(f.record.stage.backgrounds[0], { kind: 'image', motion: 'still', image: { url: c.toDataURL() } });
    }
    let calls = 0;
    f.get('generation/cgImageCore').invokeImageGeneration = async () => { calls++; throw Error('unexpected paid call'); };
    f.get('generation/client').requestJson = async () => { calls++; throw Error('unexpected paid call'); };
    const record = () => f.mv.readMv(f.host, f.song.id);
    const open = () => { f.mvui.openMv({ songId: f.song.id }); f.click('go-tegaki'); };
    const seek = t => {
        draws.length = 0;
        const el = { dataset: { rmtMv: 'seek' }, getBoundingClientRect: () => ({ left: 0, width: f.mv.shotTimeline(record(), f.song).total }) };
        f.mvui.handleMvClick({ target: { closest: () => el }, clientX: t, preventDefault() {} });
        return draws.filter(d => d.canvas === preview);
    };
    open(); await Promise.all(decodes); f.mvui.renderMv();
    for (const t of [0, 5, 9, 13]) { seek(t); await Promise.all(decodes); }
    seek(0);
    return { ...f, record, open, seek, preview, art1, art2, w, h, draws, canvases, errors, calls: () => calls };
}
