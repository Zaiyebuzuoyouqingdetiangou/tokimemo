import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';
import { createHash } from 'node:crypto';
import { EventEmitter } from 'node:events';
import { fileURLToPath } from 'node:url';

const root = process.env.TEST_ROOT || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const plain = value => JSON.parse(JSON.stringify(value));
const input = { styleId: 'art-gongbi', interaction: '递出一朵花', people: [
    { id: 'char', name: 'Alex', appearance: 'blonde hair, green eyes' },
    { id: 'user', name: 'Beth', appearance: 'silver hair, violet eyes' },
] };

async function setup({ format = 'nai45-tags', provider = 'chatu8-image', backend = 'novelai', supportsCharacters = true } = {}) {
    const requests = [], invocations = [], context = {
        name2: 'Alex', name1: 'Beth', format, imageProvider: provider, eventSource: new EventEmitter(),
        extensionSettings: { 'st-chatu8': { scriptEnabled: true, mode: backend, novelaimode: 'nai-diffusion-4-5-full' } },
    };
    const realm = vm.createContext({ URL, console, setTimeout, clearTimeout, AbortController });
    const library = [];
    realm.STBaiBaiImage = {
        apiVersion: 1, capabilities: { generate: true, saveToGallery: true, characterLibrary: true },
        getCharacters: () => ({ apiVersion: 1, characters: library }),
        getBackendStatus: () => ({ configured: true, backend: backend === 'novelai' ? 'nai' : backend, supportsCharacters }),
        generate: async request => { requests.push(plain(request)); return { path: '/user/images/pair.png' }; },
    };
    context.eventSource.on('generate-image-request', request => {
        requests.push(plain(request));
        context.eventSource.emit('generate-image-response', { id: request.id, success: true, imageData: '/user/images/pair.png' });
    });
    let adapters;
    const stubs = {
        'core/context': { getContext: () => context, currentCharacterGuard: () => context, chatScopeKey: () => 'pair-scope' },
        'core/castLooks': { readCastLooks: () => ({ char: 'blonde hair, green eyes', user: 'silver hair, violet eyes', manual: true }), lookFromDescription: value => value || '' },
        'core/settings': { getPluginSettings: ctx => ({ imageGenerationProvider: ctx.imageProvider, cgPromptFormat: ctx.format }) },
        'core/text': {
            normalizeText: (value, limit = 20000) => String(value ?? '').replace(/\r\n?/g, '\n').replace(/\u0000/g, '').trim().slice(0, limit),
            safeUserError: (message, code) => Object.assign(new Error(message), { code, safeToDisplay: true }),
        },
        'generation/cgImageCore': { normalizeCgImageUrl: url => url, invokeImageGeneration: async (prompt, ctx, options) => {
            invocations.push({ prompt, options });
            return ctx.imageProvider === 'chatu8-image'
                ? adapters.chatu8.generateChatu8Image(prompt, { ...options, context: ctx })
                : adapters.baibai.generateBaiBaiImage(prompt, { ...options, context: ctx });
        } },
        'generation/cgAppearance': { normalizeCgPromptMetadata: () => null, scopeCgPromptMetadata: () => null,
            resolveCgAppearanceMetadata: () => null, formattedCgProviderPrompts: () => null, cgFlatPromptWithNaturalLooks: value => value },
        'core/cgImagePatch': { imageResourceBase: () => 'https://example.test/', isSameImageHost: () => true, savedLocalImagePath: value => value },
        'core/taskTrace': { startTaskTrace: () => ({}), beginStage() {}, markStage() {}, endTaskTrace() {} },
        'core/state': { state: { activeCoupleAvatarTasks: new Map() } },
    };
    const cache = new Map();
    async function load(id) {
        if (cache.has(id)) return cache.get(id);
        const stub = stubs[id];
        const module = stub
            ? new vm.SyntheticModule(Object.keys(stub), function () { for (const [key, value] of Object.entries(stub)) this.setExport(key, value); }, { context: realm, identifier: id })
            : new vm.SourceTextModule(await fs.readFile(path.join(root, 'src', id + '.js'), 'utf8'), { context: realm, identifier: id });
        cache.set(id, module);
        await module.link((specifier, parent) => load(path.posix.normalize(path.posix.join(path.posix.dirname(parent.identifier), specifier)).replace(/\.js$/, '')));
        return module;
    }
    const module = await load('extras/coupleAvatar'); await module.evaluate();
    const baibai = await load('generation/baibaiImage'); await baibai.evaluate();
    const chatu8 = await load('generation/chatu8Image'); await chatu8.evaluate();
    adapters = { baibai: baibai.namespace, chatu8: chatu8.namespace };
    return { core: module.namespace, styles: cache.get('extras/coupleAvatarStyles').namespace,
        context, library, requests, invocations };
}

function assertOwnedTags(value) {
    assert.ok(value.trim());
    assert.doesNotMatch(value, /[^\x20-\x7e\r\n]/u);
    assert.doesNotMatch(value, /Rendering style:|Style construction:|LEFT HALF|RIGHT HALF|Action:|The selected|One continuous|Each complete|Each subject|\.(?:\s|$)|;/u);
    assert.ok(value.split(/[,\n]/u).every(part => part.trim().split(/\s+/u).length <= 16), 'owned recipes remain short tag phrases');
}

test('fresh forms and requests use the current global choice even when saved settings carry the other dialect', async () => {
    const f = await setup();
    assert.equal(f.core.defaultCoupleSettings(f.context).promptFormat, 'nai45-tags');
    const naturalSaved = f.core.normalizeCoupleSettings({ ...input, promptFormat: 'nai5-natural' }, f.context);
    assert.equal(naturalSaved.promptFormat, 'nai45-tags');
    // Run the existing UI draft boundary, including a still-open form whose
    // saved format predates a global setting change.
    const source = await fs.readFile(path.join(root, 'src/ui/coupleAvatarView.js'), 'utf8');
    const draftSource = source.slice(source.indexOf('function draft(view)'), source.indexOf('function queueDraft(view)'));
    const draft = Function('couple', 'settingFields', 'structuredClone', draftSource + '; return draft;')(
        f.core, ['interaction', 'interactionDetail', 'clothing', 'background', 'direction', 'customStyle'], structuredClone);
    const view = { context: f.context, settings: { ...naturalSaved, promptFormat: 'nai5-natural' },
        root: { querySelector: () => null } };
    const submitted = draft(view);
    assert.equal(submitted.promptFormat, 'nai45-tags');
    let result = await f.core.generateCouple(submitted, { context: f.context });
    assert.equal(result.record.settings.promptFormat, 'nai45-tags');
    assert.equal(f.invocations[0].options.avatarPromptParts.promptFormat, 'nai45-tags');
    assert.equal(f.invocations[0].options.avatarPromptParts.nai.nl, '');
    f.context.format = 'nai5-natural';
    assert.equal(draft(view).promptFormat, 'nai5-natural');
    // Even a captured draft must use the choice current at the request boundary.
    result = await f.core.generateCouple(naturalSaved, { context: f.context });
    assert.equal(result.record.settings.promptFormat, 'nai5-natural');
    assert.equal(f.invocations[1].options.avatarPromptParts.promptFormat, 'nai5-natural');
    assert.match(f.invocations[1].options.avatarPromptParts.nai.nl, /One continuous horizontal paired portrait/);
    assert.equal(f.requests.length, 2);
    await f.core.retryCoupleSave(result.scope, result.record.id);
    assert.equal(f.requests.length, 2);
});

test('all built-in styles and interactions have actual 4.5 tag scene and separate actor channels', async () => {
    const f = await setup();
    for (const style of f.styles.COUPLE_STYLES) {
        const parts = f.core.couplePromptParts({ ...input, styleId: style.id }, f.context);
        assert.equal(parts.promptFormat, 'nai45-tags', style.id);
        for (const value of [parts.prompt, parts.scene, parts.nai.prompt, ...parts.characters.map(row => row.tag), ...parts.nai.characters.map(row => row.tag)]) assertOwnedTags(value);
        assert.equal(parts.nai.nl, '');
        assert.ok(parts.nai.characters.every(row => row.nl === ''));
        assert.equal(parts.characters.length, 2);
        assert.doesNotMatch(parts.characters[0].tag, /silver hair|violet eyes/);
        assert.doesNotMatch(parts.characters[1].tag, /blonde hair|green eyes/);
    }
    for (const interaction of f.styles.INTERACTION_PRESETS) {
        const parts = f.core.couplePromptParts({ ...input, interaction: interaction.label }, f.context);
        for (const value of [parts.scene, ...parts.characters.map(row => row.tag)]) assertOwnedTags(value);
        assert.notEqual(parts.characters[0].tag, parts.characters[1].tag, interaction.label);
        assert.doesNotMatch(JSON.stringify(parts), /follow the LEFT|follow the RIGHT|choose a fresh individual/);
    }
});

test('representative 4.5 recipes keep medium construction, body proportions and both sides of an interaction', async () => {
    const f = await setup();
    const flower = f.core.couplePromptParts(input, f.context);
    assert.match(flower.scene, /gongbi|fine.*ink|fine.*line/i);
    assert.match(flower.characters[0].tag, /flower/); assert.match(flower.characters[0].tag, /offer|giving|holding out/i);
    assert.match(flower.characters[1].tag, /flower/); assert.match(flower.characters[1].tag, /receiv|reaching|accept/i);
    for (const [styleId, medium] of [['craft-crochet', /crochet|yarn/], ['graphic-pixel', /pixel/], ['fantasy-glass', /glass/], ['art-charcoal', /charcoal/]]) {
        const parts = f.core.couplePromptParts({ ...input, styleId }, f.context);
        assert.match(parts.scene, medium); assert.match(parts.characters[0].tag, medium);
    }
    const animal = f.core.couplePromptParts({ ...input, styleId: 'animal-cat' }, f.context);
    assert.match(animal.scene, /cat|feline/); assert.match(animal.characters[0].tag, /blonde fur markings/);
    assert.doesNotMatch(animal.characters[0].tag, /blonde hair/);
    const complete = f.core.couplePromptParts({ ...input, styleId: 'chibi-dumpling' }, f.context);
    assert.match(complete.scene, /full.*body|complete.*figure/);
    const headshot = f.core.couplePromptParts({ ...input, styleId: 'chibi-headshot' }, f.context);
    assert.match(headshot.scene, /head|shoulder|upper.*body/);
});

test('the actual inspiration and use-idea UI branches send generated ideas as separate 4.5 role tags', async () => {
    const f = await setup();
    const source = await fs.readFile(path.join(root, 'src/ui/coupleAvatarView.js'), 'utf8');
    const draftSource = source.slice(source.indexOf('function draft(view)'), source.indexOf('function queueDraft(view)'));
    const fields = ['interaction', 'interactionDetail', 'clothing', 'background', 'direction', 'customStyle'];
    const draft = Function('couple', 'settingFields', 'structuredClone', draftSource + '; return draft;')(f.core, fields, structuredClone);
    const inputs = new Map(fields.map(key => [`[data-pair-field="${key}"]`, { value: input[key] || '' }]));
    inputs.set('[data-pair-ideas]', { hidden: true, innerHTML: '' });
    const view = { context: f.context, settings: f.core.normalizeCoupleSettings(input, f.context), ideas: [], root: { querySelector: key => inputs.get(key) } };
    const paint = current => { for (const key of fields) inputs.get(`[data-pair-field="${key}"]`).value = current.settings[key]; };
    paint(view);
    const actionSource = source.slice(source.indexOf("    if (action === 'inspiration')"), source.indexOf("    if (action === 'custom-style')"));
    const action = Function('draft', 'presets', 'paintSettings', 'queueDraft', 'button', 'esc',
        `return (view, action, target) => { ${actionSource} };`)(draft,
        { randomCoupleIdeas: previous => f.styles.randomCoupleIdeas(previous, () => 0.87) }, paint, draft, () => '', value => value);
    const target = { textContent: '', dataset: { pairIdea: '0' } };
    action(view, 'inspiration', target);
    assert.equal(view.ideas.length, 3); assert.equal(target.textContent, '换一组灵感');
    action(view, 'use-idea', target);
    assert.equal(view.settings.interaction, '自定义互动');
    assert.equal(view.settings.interactionDetail, view.ideas[0]);
    assert.equal(f.requests.length, 0);
    await f.core.generateCouple(draft(view), { context: f.context });
    assert.equal(f.requests.length, 1);
    const parts = f.invocations[0].options.avatarPromptParts;
    for (const value of [parts.scene, ...parts.characters.map(row => row.tag)]) assertOwnedTags(value);
    assert.ok(parts.characters.every(row => !row.tag.includes(view.ideas[0])));
});

test('every exact native inspiration template retains its action, mood and scene; edited text stays literal', async () => {
    const f = await setup();
    const source = await fs.readFile(path.join(root, 'src/extras/coupleAvatarStyles.js'), 'utf8');
    const catalogSource = source.slice(source.indexOf('const IDEA_MOMENTS'), source.indexOf('export function coupleInteraction'));
    const { IDEA_MOMENTS: moments, IDEA_MOODS: moods, IDEA_SCENES: scenes } = Function(catalogSource + '; return { IDEA_MOMENTS, IDEA_MOODS, IDEA_SCENES };')();
    const sceneChecks = [/solid.color|solid background/, /soft light/, /pale.*color|pale.*background/, /window/, /petals/];
    const moodChecks = [[/serious/, /amused/], [/shy/, /gentle|warm/], [/proud/, /unimpressed/], [/curious/, /patient/], [/sleepy/, /energetic/], [/surprised/, /delighted/]];
    for (const moment of moments) for (const [moodIndex, mood] of moods.entries()) for (const [sceneIndex, scene] of [...scenes, ['背景留白，重点放在动作和表情']].entries()) {
        const raw = `${moment[0]}；${mood[0]}。${scene[0]}。`;
        const parts = f.core.couplePromptParts({ ...input, interaction: '自定义互动', interactionDetail: raw }, f.context);
        for (const value of [parts.scene, ...parts.characters.map(row => row.tag)]) assertOwnedTags(value);
        assert.match(parts.scene, sceneChecks[sceneIndex % 5]);
        for (const side of [0, 1]) assert.match(parts.characters[side].tag, moodChecks[moodIndex][side]);
    }
    const raw = '左边指着远处的烟花，右边偷偷看左边；一个认真、一个忍不住笑。共享一个小小的窗边场景。';
    const parts = f.core.couplePromptParts({ ...input, interaction: '自定义互动', interactionDetail: raw }, f.context);
    assert.match(parts.characters[0].tag, /point.*fireworks/);
    assert.match(parts.characters[1].tag, /glanc.*left|looking.*left/);
    assert.doesNotMatch(parts.characters[1].tag, /point.*fireworks/);
    assert.doesNotMatch(parts.characters[0].tag, /glanc.*left|looking.*left/);
    for (const edited of [raw + '再加一只纸鹤。', raw.replace('偷偷看', '低头看'), raw.replace('；', '，')]) {
        const custom = f.core.couplePromptParts({ ...input, interaction: '自定义互动', interactionDetail: edited }, f.context);
        assert.ok(custom.scene.includes(edited));
        assert.ok(custom.characters.every(row => row.tag.includes(edited)));
    }
    assert.equal(f.requests.length, 0);
});

test('explicit custom appearance, style, direction, clothing, background and interaction remain literal in both dialects', async () => {
    for (const format of ['nai45-tags', 'nai5-natural']) {
        const f = await setup({ format });
        const custom = { ...input, styleId: 'custom', customStyle: '像旧绘本；保留手绘毛边', direction: '左边忍住笑；右边假装生气',
            clothing: '蓝色外套；米色围巾', background: '窗外细雨；室内暖灯', interaction: '自定义互动', interactionDetail: '左边递来纸鹤，右边伸手接住。',
            people: [{ id: 'char', name: '左边人', appearance: '{{金色头发}}, (blue eyes:1.2)', appearanceOverride: true }, input.people[1]] };
        const parts = f.core.couplePromptParts(custom, f.context);
        for (const value of [custom.customStyle, custom.direction, custom.clothing, custom.background, custom.interactionDetail, custom.people[0].appearance]) assert.ok(parts.prompt.includes(value), value);
        assert.ok(parts.characters[0].tag.includes(custom.people[0].appearance));
        assert.equal(f.requests.length, 0);
    }
});

for (const provider of ['chatu8-image', 'baibai-image']) for (const backend of ['novelai', 'comfyui']) test(`${provider}/${backend}: actual adapter receives tag or natural channels with one image call`, async () => {
    const f = await setup({ provider, backend, supportsCharacters: backend === 'novelai' });
    const weighted = { ...input, people: [{ ...input.people[0], appearance: '{{blonde hair}}, (green eyes:1.2)', appearanceOverride: true }, input.people[1]] };
    const tagResult = await f.core.generateCouple(weighted, { context: f.context });
    assert.equal(f.requests.length, 1); assert.equal(f.invocations.length, 1);
    assert.equal(tagResult.record.settings.promptFormat, 'nai45-tags');
    assert.match(JSON.stringify(f.requests[0]), /\{\{blonde hair\}\}/);
    assert.doesNotMatch(JSON.stringify(f.requests[0]), /Rendering style:|Style construction:|LEFT HALF|Action:|One continuous horizontal paired portrait/);
    if (provider === 'chatu8-image' && backend === 'novelai') {
        assert.match(f.requests[0].prompt, /Character 1 Prompt:/); assert.match(f.requests[0].prompt, /Character 2 Prompt:/);
        assert.match(f.requests[0].prompt, /centers:\{0.25,0.5\}/); assert.match(f.requests[0].prompt, /centers:\{0.75,0.5\}/);
    }
    if (provider === 'baibai-image' && backend === 'novelai') {
        assert.equal(f.requests[0].nl, ''); assert.equal(f.requests[0].characters.length, 2);
        assert.ok(f.requests[0].characters.every(row => row.nl === '' || row.nl === undefined));
    }
    f.context.format = 'nai5-natural';
    await f.core.generateCouple(weighted, { context: f.context });
    assert.equal(f.requests.length, 2);
    assert.match(JSON.stringify(f.requests[1]), /One continuous horizontal paired portrait/);
});

test('preset identity and negative stay attached to their actor in 4.5 parts and actual Chatu8 request', async () => {
    const f = await setup();
    f.context.extensionSettings['st-chatu8'].characterPresets = { a: { nameEN: 'Alex', characterTraits: '{{red hair}}', negative: 'green hair' }, b: { nameEN: 'Beth', characterTraits: 'blue hair', negative: 'purple hair' } };
    await f.core.generateCouple(input, { context: f.context });
    const parts = f.invocations[0].options.avatarPromptParts;
    assert.equal(parts.characters[0].negative, 'green hair'); assert.equal(parts.characters[1].negative, 'purple hair');
    assert.match(parts.characters[0].tag, /\{\{red hair\}\}/); assert.doesNotMatch(parts.characters[1].tag, /red hair/);
    assert.match(f.requests[0].prompt, /Character 1 UC: green hair;/); assert.match(f.requests[0].prompt, /Character 2 UC: purple hair;/);
    assert.equal(f.requests.length, 1);
});

test('context-null history keeps the saved dialect and all formatless 1.0.48 prompt strings', async () => {
    const f = await setup();
    const legacy = f.styles.COUPLE_STYLES.map(style => f.core.couplePromptParts({ ...input, styleId: style.id }, null));
    const hash = createHash('sha256').update(JSON.stringify(plain(legacy))).digest('hex');
    assert.equal(hash, '853383c41cac861c880613b34f6ad17e198eeb4d0fde355ba09d2abb456a19ea');
    const saved = f.core.normalizeCoupleSettings(input, f.context);
    const before = plain(saved), beforeParts = plain(f.core.couplePromptParts(saved, null));
    f.context.format = 'nai5-natural';
    assert.deepEqual(plain(f.core.normalizeCoupleSettings(saved, null)), before);
    assert.deepEqual(plain(f.core.couplePromptParts(saved, null)), beforeParts);
    assert.equal(f.core.normalizeCoupleSettings(saved, f.context).promptFormat, 'nai5-natural');
});
