import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './fixture.mjs';
import { ui } from './mv-ui-fixture.mjs';
const plain = value => JSON.parse(JSON.stringify(value));
const entry = (extra = {}) => ({ id:'E1', title:'纸墨', preview:'纸墨备选，细纸留给短笺。', detail:'挑细纸，不买洇墨的那一种。', fields:[{label:'用途',value:'写短笺'},{label:'类别',value:'文具'}], basis:'记忆', sourceMemoryIds:['M001'], sourceMemoryAnchor:'事件', sourceMemoryEvidence:'普通相处', ...extra });
const app = (extra = {}) => ({ id:'A1',label:'金匮账',kind:'finance',summary:'自己的收支簿',entries:[entry()],...extra });
function normalized(f, row=entry(), kind='finance', options={}) {
 const plan=app({kind,entries:[{id:row.id,title:row.title}]});
 return f.get('modes/phoneData').normalizePhoneDraftApp({app:{...plan,entries:[row]}},plan,f.bank,'neutral',null,{allowPartial:true,...options});
}
const song = {id:'SONG_shortcut',title:'面具之后',voice:'char',subject:'character',subjectTitle:'Char',singer:'Char',language:'zh',styleDescription:'戏谑暗黑流行，明亮节奏与假笑的反差',stylePrompt:'dark pop, theatrical, 110 BPM',vocalDescription:'男声',lyrics:'[Verse]\n面具里藏着眼泪\n[Chorus]\n摆出笑脸\n[End]'};
const board=()=>({groups:[{id:'G1',composition:'正面半身',cast:[],characterPrompt:'empty graphic stage',diffs:[{id:'D1',label:'收敛',change:'quiet graphic'},{id:'D2',label:'反差',change:'bright graphic'}]}],frames:[{group:'G1',diff:'D1',sectionIndex:0,lyric:'面具里藏着眼泪'},{group:'G1',diff:'D2',sectionIndex:1,lyric:'摆出笑脸'},{group:'G1',diff:'D1',sectionIndex:1,lyric:'摆出笑脸'}]});

test('ordinary ledger is retained even when provider labels it memory and uses no timing keywords',async()=>{
 const f=await fixture(), data=normalized(f).entries[0];
 assert.equal(data.title,'纸墨');assert.equal(data.detail,entry().detail);assert.equal(data.preview,entry().preview);
 assert.deepEqual(plain(data.fields),entry().fields);assert.equal(data.basis,'推演');
 assert.deepEqual(plain(data.sourceMemoryIds),[]);assert.equal(data.sourceMemoryEvidence,'');
});
test('all ordinary app kinds accept persona content without memory quotes or new mandatory fields',async()=>{
 const f=await fixture();
 for(const kind of ['notes','finance','store','work','study','reading','books','research','files','creative','tools','music','gallery']){
  const row=entry({basis:'设定',fields:[],sourceMemoryIds:[],sourceMemoryAnchor:'',sourceMemoryEvidence:''});
  assert.equal(normalized(f,row,kind).entries[0].detail,row.detail,kind);
 }
});
test('the final phone normalizer does not turn a validated ledger back into source excerpts',async()=>{
 const f=await fixture(), first=normalized(f);
 const data=f.get('modes/phoneData').normalizePhone({deviceKind:'neutral',apps:[first]},f.bank);
 assert.equal(data.apps[0].entries[0].detail,entry().detail);assert.equal(data.apps[0].entries[0].fields.length,2);
});
test('actual joint history still needs evidence and is never downgraded into ordinary life',async()=>{
 const f=await fixture(), row=entry({preview:'我和User曾经一起去过京都。',detail:'我和User曾经一起去过京都。',sourceMemoryEvidence:'伪造的旅行',fields:[]});
 assert.throws(()=>normalized(f,row),/没有可保存|详情不完整/);
});
test('known contact can use name and a present note without a telephone or address',async()=>{
 const f=await fixture(), row=entry({title:'常来往的人',contactName:'',preview:'向阿宁请教修书。',detail:'问问旧书如何补页。',basis:'设定',fields:[{label:'姓名',value:'阿宁'},{label:'备注',value:'请教补书方法'}],sourceSettingEvidence:'阿宁是修书匠。'});
 const result=normalized(f,row,'contacts',{controlledEvidence:'阿宁是修书匠。'}).entries[0];
 assert.equal(result.contactName,'阿宁');assert.equal(result.fields.length,2);
});
test('unknown contacts and invented private fields remain rejected',async()=>{
 const f=await fixture();
 for(const fields of [[{label:'姓名',value:'陌生人'}],[{label:'姓名',value:'阿宁'},{label:'电话',value:'123456789'}]]) {
 const row=entry({contactName:fields[0].value,title:fields[0].value,basis:'设定',fields,sourceSettingEvidence:'阿宁是修书匠。'});
 assert.throws(()=>normalized(f,row,'contacts',{controlledEvidence:'阿宁是修书匠。'}));
 }
});
test('terminal prompt supplies contact identity and app-shaped records without UI disclaimers',async()=>{
 const f=await fixture(), p=f.get('modes/phonePrompts').phoneAppPrompt(f.host,f.bank,{deviceKind:'neutral'},app({kind:'contacts'}));
 assert.match(p,/chat\/contacts 对象实际姓名/);assert.doesNotMatch(p,/非 chat 可空/);
 assert.match(p,/只有姓名明确时/);assert.match(p,/内容以该应用主人的口吻与用途组织/);
 assert.match(p,/字段不足时仍可保留完整正文/);assert.match(p,/来源只放 basis\/source 字段/);
});
test('old recap repair is offered without mutating or dropping saved rows',async()=>{
 const f=await fixture(), m=f.get('modes/phoneData'), session={apps:[app({entries:[entry({title:'剧情摘录 1'}),entry({id:'E2',title:'保留账目'})]})]};
 const before=JSON.stringify(session);assert.equal(m.phoneHasMissingEntries(session),true);
 assert.equal(m.phoneCompletionSummary(session).repairItems,1);
 assert.equal(m.phoneCompletionSummary(session).readableItems,2);assert.equal(JSON.stringify(session),before);
 const failed=m.mergePhoneMissingEntries(session.apps[0],{entries:[{id:'E1',sourceStatus:'unavailable'}]});
 assert.deepEqual(plain(failed),session.apps[0]);
 const result=m.mergePhoneMissingEntries(session.apps[0],{entries:[entry({title:'新的纸墨账'}),entry({id:'E2',title:'越界替换'})]});
 assert.equal(result.entries[0].title,'新的纸墨账');assert.equal(result.entries[1].title,'保留账目');
});
test('explicit repair requests only recap or missing slots and persists the successful replacement',async()=>{
 const f=await fixture(), previous={deviceKind:'neutral',apps:[app({entries:[entry({title:'剧情摘录 1'}),entry({id:'E2',title:'现有记录'})]})]};
 let requests=0,saved;f.get('generation/client').requestValidatedSegment=async(prompt,label,options,validate)=>{
 requests++;assert.doesNotMatch(prompt,/现有记录|剧情摘录 1/);return validate({app:app()});};
 const result=await f.get('modes/phoneGeneration').generatePhoneMissingWithRepair(f.host,f.bank,{},'repair-test',previous,{savePartial:async s=>{saved=plain(s);return true;}});
 assert.equal(requests,1);assert.equal(result.apps[0].entries[0].title,'纸墨');assert.equal(result.apps[0].entries[1].title,'现有记录');assert.equal(saved.apps[0].entries[0].title,'纸墨');assert.equal(previous.apps[0].entries[0].title,'剧情摘录 1');
});
test('repair errors and failed saves never mutate the previous session',async()=>{
 const f=await fixture(), previous={deviceKind:'neutral',apps:[app({entries:[entry({title:'剧情摘录 1'})]})]}, before=JSON.stringify(previous);
 f.get('generation/client').requestValidatedSegment=async()=>{throw Error('offline');};
 await assert.rejects(f.get('modes/phoneGeneration').generatePhoneMissingWithRepair(f.host,f.bank,{},'repair',previous),/offline/);
 assert.equal(JSON.stringify(previous),before);
 f.get('generation/client').requestValidatedSegment=async(p,l,o,v)=>v({app:app()});
 await assert.rejects(f.get('modes/phoneGeneration').generatePhoneMissingWithRepair(f.host,f.bank,{},'repair',previous,{savePartial:async()=>false}),/保存/);assert.equal(JSON.stringify(previous),before);
});
test('historical chat and contact records are not rewritten by the ordinary app repair',async()=>{
 const f=await fixture(), m=f.get('modes/phoneData');
 for(const kind of ['chat','contacts']){const value={apps:[app({kind,entries:[entry({title:'剧情摘录 1'})]})]};assert.equal(m.phoneHasMissingEntries(value),false);assert.equal(m.phoneCompletionSummary(value).repairItems,0);}
});
test('app lists expose ledger fields and named contact cards, escaping model text',async()=>{
 const f=await fixture(), v=f.get('ui/phoneView');
 const ledger=v.renderPhoneAppList(app({entries:[entry({title:'<script>bad</script>'})]}));
 assert.match(ledger,/rmt-phone-ledger-fields/);assert.match(ledger,/收支簿/);assert.match(ledger,/写短笺/);assert.doesNotMatch(ledger,/<script>/);
 const contacts=v.renderPhoneAppList(app({kind:'contacts',entries:[entry({contactName:'阿宁'})]}));assert.match(contacts,/名帖/);assert.match(contacts,/阿宁/);assert.match(contacts,/1 位/);
});
test('legacy recap labels are absent in list and detail while source data remains unchanged',async()=>{
 const f=await fixture(), v=f.get('ui/phoneView'), old=app({entries:[entry({title:'剧情摘录 1'})]}), before=JSON.stringify(old);
 assert.doesNotMatch(v.renderPhoneAppList(old),/剧情摘录|人设推演|非真实记录/);
 assert.doesNotMatch(v.renderPhoneEntryDetail(old.entries[0],old),/剧情摘录|人设推演|非真实记录/);assert.equal(JSON.stringify(old),before);
});
test('empty app has a working generation action and read-only app has no paid action',async()=>{
 const f=await fixture(), v=f.get('ui/phoneView'), empty=app({kind:'contacts',entries:[{id:'E1',sourceStatus:'unavailable'}]});
 assert.match(v.renderPhoneAppList(empty),/data-rmt-action="phone-fill-missing"/);
 assert.doesNotMatch(v.renderPhoneAppList(empty),/暂无可读内容|未通过校验/);
 assert.doesNotMatch(v.renderPhoneAppList(empty,false),/phone-fill-missing/);
});
test('new expression direction is available manually, recommended by fit, and does not force unrelated songs',async()=>{
 const f=await fixture(), d=f.get('extras/mvDirection'), m=f.get('extras/mv');
 assert.equal(d.directionOf('expression').name,'表情卡拍');assert.equal(m.normalizeSettings({storyType:'expression'}).storyType,'expression');
 assert.equal(d.recommendDirections(song)[0].id,'expression');assert.equal(d.recommendDirections({stylePrompt:'quiet acoustic folk ballad',bpm:76})[0].id,'lyrical');assert.equal(d.recommendDirections({})[0].id,'auto');
 assert.match(d.directionPrompt('expression',song),/重复乐句/);assert.match(d.directionPrompt('expression',song),/单张单格/);assert.match(d.directionPrompt('expression',song),/生图不写歌词/);
 assert.doesNotMatch(d.directionPrompt('lyrical',song),/单张单格|表情卡拍/);
});
test('expression storyboard uses the existing one-request schema, saves type, and reuses assets',async()=>{
 const f=await fixture(), mv=f.get('extras/mv');f.get('core/cache').loadSession=()=>({songs:[song]});let calls=0;
 f.get('generation/client').requestJson=async p=>{calls++;assert.match(p,/分镜类型：表情卡拍/);return board();};
 const result=await mv.generateStoryboard(song.id,{storyType:'expression'});assert.equal(result.pending,false);assert.equal(calls,1);
 const record=mv.readMv(f.host,song.id);assert.equal(record.settings.storyType,'expression');assert.equal(record.shots.length,3);assert.equal(mv.assetKeys(record).length,2);
});
test('expression selector remains reachable for existing storyboards without requesting generation',async()=>{
 const f=await ui(fixture);f.get('core/cache').loadSession=()=>({songs:[song]});const mv=f.get('extras/mv');let calls=0;
 f.get('generation/client').requestJson=async()=>{calls++;return board();};await mv.generateStoryboard(song.id,{storyType:'loop'});
 mv.writeMv(mv.mvScope(f.host),song.id,r=>{r.groups[0].diffs[0].image={url:'/kept.png'};return r;});
 f.mvui.openMv({songId:song.id});assert.match(f.body.innerHTML,/表情卡拍/);
 f.mvui.handleMvChange({target:{matches:s=>s==='[data-rmt-mv-story-type]',dataset:{rmtMvScope:'record'},value:'expression'}});
 assert.equal(calls,1);assert.equal(mv.readMv(f.host,song.id).groups[0].diffs[0].image.url,'/kept.png');assert.equal(mv.readMv(f.host,song.id).settings.storyType,'expression');f.mvui.disposeMv();
});
async function songUI(){
 const f=await ui(fixture),state=f.get('core/state').state;state.activeMode='themeSong';state.activeSession={kind:'themeSong',songs:[plain(song)],selectedId:song.id};
 f.get('archive/repository').getImportedMemory=()=>f.bank;f.get('core/cache').getCache=()=>({});f.get('ui/recoveryView').recoveryBannerHtml=()=>'';
 f.get('ui/expandedCgView').expandedCgHtml=()=>'';f.get('core/generationOptions').readSongOptions=()=>({});
 return {...f,state,view:f.get('ui/themeSongView')};
}
test('MV shortcut is above composer, song list and cover, keeps the selected song ID and sends no requests',async()=>{
 const f=await songUI();let calls=0;f.get('generation/client').requestJson=async()=>{calls++;throw Error('unexpected');};
 f.view.renderThemeSongs();const html=f.body.innerHTML, pos=html.indexOf('data-rmt-mv="open"');
 assert.ok(pos>=0&&pos<html.indexOf('rmt-song-composer')&&pos<html.indexOf('rmt-song-cover'));
 assert.match(html.slice(pos,pos+150),/SONG_shortcut/);assert.equal(calls,0);
 f.state.activeSession.songs.push({...song,id:'SONG_second'});f.state.activeSession.selectedId='SONG_second';f.view.renderThemeSongs();assert.match(f.body.innerHTML.slice(0,f.body.innerHTML.indexOf('rmt-song-composer')),/data-rmt-mv-id="SONG_second"/);
});
test('MV shortcut stays hidden for incomplete, absent or read-only songs',async()=>{
 const f=await songUI();f.state.activeSession.songs[0].generationIncomplete=true;f.view.renderThemeSongs();assert.doesNotMatch(f.body.innerHTML,/data-rmt-mv="open"/);
 f.state.activeSession.songs[0].generationIncomplete=false;f.state.activeArchiveSnapshot={memory:f.bank,cache:{},backupOnly:true};f.view.renderThemeSongs();assert.doesNotMatch(f.body.innerHTML,/data-rmt-mv="open"/);
 f.state.activeArchiveSnapshot=null;f.state.activeSession.songs=[];f.view.renderThemeSongs();assert.doesNotMatch(f.body.innerHTML,/data-rmt-mv="open"/);
});

test('a completely empty legacy app can be filled instead of exposing a no-op button',async()=>{
 const f=await fixture(), previous={deviceKind:'neutral',apps:[app({entries:[]})]}, m=f.get('modes/phoneData');let calls=0;
 assert.equal(m.phoneHasMissingEntries(previous),true);assert.equal(m.phoneCompletionSummary(previous).missingItems,1);
 f.get('generation/client').requestValidatedSegment=async(p,l,o,v)=>{calls++;return v({app:app({entries:[entry({id:'A1_E01'})]})});};
 const result=await f.get('modes/phoneGeneration').generatePhoneMissingWithRepair(f.host,f.bank,{},'empty',previous);
 assert.equal(calls,1);assert.equal(result.apps[0].entries[0].id,'A1_E01');assert.equal(previous.apps[0].entries.length,0);
});
test('unusable replacement is not presented as a completed recap repair',async()=>{
 const f=await fixture(), previous={deviceKind:'neutral',apps:[app({entries:[entry({title:'剧情摘录 1'})]})]}, before=JSON.stringify(previous);
 f.get('generation/client').requestValidatedSegment=async()=>app({entries:[entry({title:'剧情摘录 1'})]});
 await assert.rejects(f.get('modes/phoneGeneration').generatePhoneMissingWithRepair(f.host,f.bank,{},'no-change',previous),/没有收到新的应用内容/);assert.equal(JSON.stringify(previous),before);
});
test('saved terminal directory continuation preserves completed apps and requests the pending app only',async()=>{
 const f=await fixture(), data=f.get('modes/phoneData'), complete=normalized(f), pending=app({id:'A2',kind:'notes',label:'随手记',entries:[{id:'E2',title:'补书'}]});
 const plan={deviceKind:'neutral',apps:[{...complete,entries:[{id:'E1',title:'纸墨'}]},pending]}, snapshots=[];
 f.get('core/cache').loadSession=()=>null;f.get('core/cache').loadPhoneGenerationDraft=()=>({plan,completedApps:[complete]});
 f.get('core/cache').savePhoneGenerationDraft=async(c,b,p,apps)=>{snapshots.push(plain(apps));return true;};
 f.get('core/requestCoordinator').noteSecondStepOffer=()=>{};let calls=0;
 f.get('generation/client').requestValidatedSegment=async(p,l,o,v)=>{calls++;assert.match(p,/随手记/);assert.doesNotMatch(p,/"id": "A1"/);return v({app:{...pending,entries:[entry({id:'E2',title:'补书'})]}});};
 const result=await f.get('modes/phoneGeneration').generatePhoneWithRepair(f.host,f.bank,{},'continue',{continueDraft:true});
 assert.equal(calls,1);assert.deepEqual(plain(result.apps[0].entries),plain(complete.entries));assert.equal(result.apps[1].entries[0].id,'E2');assert.equal(snapshots.at(-1).length,2);
});
test('one bad contact never hides a valid sibling, and malformed optional fields do not throw a TypeError',async()=>{
 const f=await fixture(), good=entry({id:'E1',title:'阿宁',contactName:'阿宁',basis:'设定',fields:[{label:'姓名',value:'阿宁'},{label:'备注',value:'问补书方法'}],sourceSettingEvidence:'阿宁是修书匠。'}), bad={...good,id:'E2',contactName:'不认识的人'};
 const plan=app({kind:'contacts',entries:[{id:'E1',title:'阿宁'},{id:'E2',title:'不认识的人'}]});
 const result=f.get('modes/phoneData').normalizePhoneDraftApp({app:{...plan,entries:[good,bad]}},plan,f.bank,'neutral',null,{allowPartial:true,controlledEvidence:'阿宁是修书匠。'});
 assert.equal(result.entries[0].contactName,'阿宁');assert.equal(result.entries[1].sourceStatus,'unavailable');
 assert.doesNotThrow(()=>f.get('modes/phoneEvidence').inferPhoneContactName({title:'阿宁',fields:'invalid'},f.bank));
});
test('new top MV button opens the selected song through the existing event handler without generating',async()=>{
 const f=await songUI();f.get('core/cache').loadSession=()=>({songs:[song]});let calls=0;f.get('generation/client').requestJson=async()=>{calls++;throw Error('unexpected');};
 f.view.renderThemeSongs();const id=f.body.innerHTML.match(/data-rmt-mv="open" data-rmt-mv-id="([^"]+)"/)[1];
 assert.equal(f.click('open',id),true);assert.equal(f.state.activeMode,'songMv');assert.match(f.body.innerHTML,/面具之后/);assert.equal(calls,0);f.mvui.disposeMv();
});
