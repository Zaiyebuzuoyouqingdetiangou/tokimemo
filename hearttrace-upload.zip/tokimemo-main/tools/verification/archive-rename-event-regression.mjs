import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fixture } from './fixture.mjs';

const root = path.resolve(process.env.TEST_ROOT || '.');
async function setup({ failClaim = false, claimErrorCode = '' } = {}) {
    const f = await fixture(), context = vm.createContext(f.sb), modules = new Map();
    const callbacks = new Map(), calls = [], warnings = [];
    f.host.chatId = 'new title'; f.bank.chatId = 'old title';
    f.host.eventTypes = { CHAT_RENAMED: 'chat_renamed', CHAT_CHANGED: 'chat_id_changed', CHAT_LOADED: 'chatLoaded' };
    f.host.eventSource = {
        on(type, fn) { if (!callbacks.has(type)) callbacks.set(type, new Set()); callbacks.get(type).add(fn); },
        off(type, fn) { callbacks.get(type)?.delete(fn); },
        async emit(type, value) { for (const fn of callbacks.get(type) || []) await fn(value); },
    };
    f.get('archive/repository').claimMismatchedArchive = async host => {
        if (failClaim) throw Object.assign(Error('storage unavailable'), { code: claimErrorCode });
        calls.push(host); host.chatMetadata[f.constants.MEMORY_KEY].chatId = host.chatId;
        return { memoryCount: 1, previousChatId: 'old title' };
    };
    f.get('archive/repository').flushDeferredCommitsForCurrentChat = async () => {};
    f.get('ui/settingsPanel').refreshSettingsMemoryStatus = () => {};
    f.sb.toastr = { warning: message => warnings.push(message) };
    f.sb.console = { ...console, warn() {} };
    async function load(id) {
        if (modules.has(id)) return modules.get(id);
        const fresh = ['ui/archiveRename', 'ui/archivePortal'].includes(id);
        const values = fresh ? null : f.get(id);
        assert.ok(fresh || values, id);
        const module = fresh ? new vm.SourceTextModule(fs.readFileSync(path.join(root, 'src', id + '.js'), 'utf8'), { context, identifier: id })
            : new vm.SyntheticModule(Object.keys(values), function () { for (const [key, value] of Object.entries(values)) this.setExport(key, value); }, { context, identifier: id });
        modules.set(id, module);
        await module.link((specifier, parent) => load(path.posix.normalize(path.posix.join(path.posix.dirname(parent.identifier), specifier)).replace(/\.js$/, '')));
        return module;
    }
    const module = await load('ui/archivePortal'); await module.evaluate();
    return { f, calls, warnings, callbacks, portal: module.namespace, rename: modules.get('ui/archiveRename').namespace,
        event: { avatarId: 'char.png', groupId: undefined, oldFileName: 'old title.jsonl', newFileName: 'new title.jsonl' } };
}

test('official rename event binds only the exact active card and old/new chat identities', async () => {
    const x = await setup();
    const result = await x.rename.handleArchiveChatRename(x.event);
    assert.equal(result.memoryCount, 1); assert.equal(x.calls.length, 1);
    assert.equal(x.f.bank.chatId, 'new title');
    assert.equal(await x.rename.handleArchiveChatRename(x.event), null);
    assert.equal(x.calls.length, 1, 'duplicate event cannot reapply migration');
});

test('other avatars, inactive chats, group chats, missing identity and copies are not auto-claimed', async () => {
    for (const patch of [{ avatarId: 'other.png' }, { newFileName: 'inactive.jsonl' }, { oldFileName: 'unrelated.jsonl' },
        { groupId: 'group-1' }, { avatarId: '' }, { oldFileName: '' }, { newFileName: '' }, { oldFileName: 'new title.jsonl' }]) {
        const x = await setup();
        assert.equal(await x.rename.handleArchiveChatRename({ ...x.event, ...patch }), null);
        assert.equal(x.calls.length, 0); assert.equal(x.f.bank.chatId, 'old title');
    }
    const x = await setup();
    assert.equal(await x.rename.handleArchiveChatRename(null), null);
    x.f.host.groupId = 'group-1';
    assert.equal(await x.rename.handleArchiveChatRename(x.event), null);
    assert.equal(x.calls.length, 0);
});

test('runtime subscribes to the official event once and unsubscribes on cleanup', async () => {
    const x = await setup();
    x.portal.bindChatStateEvents(); x.portal.bindChatStateEvents();
    assert.equal(x.callbacks.get('chat_renamed').size, 1);
    await x.f.host.eventSource.emit('chat_renamed', x.event);
    assert.equal(x.calls.length, 1);
    x.f.sb.__heartbeatMemoriesEventCleanup();
    assert.equal(x.callbacks.get('chat_renamed').size, 0);
    assert.equal(x.callbacks.get('chat_id_changed').size, 0);
});

test('migration failure does not bubble into SillyTavern reporting that the host rename failed', async () => {
    const x = await setup({ failClaim: true });
    x.portal.bindChatStateEvents();
    await assert.doesNotReject(x.f.host.eventSource.emit('chat_renamed', x.event));
    assert.equal(x.warnings.length, 1);
    assert.equal(x.f.bank.chatId, 'old title');
    x.f.sb.__heartbeatMemoriesEventCleanup();
});

test('hosts without CHAT_RENAMED keep normal navigation listeners and do not claim from a guessed name', async () => {
    const x = await setup(); delete x.f.host.eventTypes.CHAT_RENAMED;
    x.portal.bindChatStateEvents();
    assert.equal(x.callbacks.has('chat_renamed'), false);
    assert.equal(x.callbacks.get('chat_id_changed').size, 1);
    assert.equal(x.calls.length, 0);
    x.f.sb.__heartbeatMemoriesEventCleanup();
});

test('leaving the renamed chat during migration does not show a stale retry warning in another chat', async () => {
    const x = await setup({ failClaim: true, claimErrorCode: 'RMT_RECOVERY_ORIGIN_CHANGED' });
    x.portal.bindChatStateEvents();
    await assert.doesNotReject(x.f.host.eventSource.emit('chat_renamed', x.event));
    assert.equal(x.warnings.length, 0);
    assert.equal(x.f.bank.chatId, 'old title');
    x.f.sb.__heartbeatMemoriesEventCleanup();
});
