// HTML structure and bounded controller checks; this is not a rendered browser test.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';

const root = path.resolve(process.env.TEST_ROOT || '.');
const html = fs.readFileSync(path.join(root, 'preview/hearttrace-editor-preview.html'), 'utf8');
const script = html.match(/<script>([\s\S]*?)<\/script>/)[1];
const helpers = script.slice(script.indexOf('function musicSheet(){'), script.indexOf('function sheetTemplate(kind){'));
const importer = script.slice(script.indexOf('async function importSound(file){'), script.indexOf('\nfunction bindTabs'));
function setup() {
    const nodes = new Map();
    const $ = id => { if (!nodes.has(id)) nodes.set(id, { textContent: '', value: '', setAttribute(name, value) { this[name] = value; } }); return nodes.get(id); };
    let serial = 0, paused = 0, videoChecks = 0;
    const revoked = [], sound = { src: '', removeAttribute() { this.src = ''; }, load() {} };
    class Audio { constructor() { this.duration = 19; } set src(value) { this.source = value; queueMicrotask(() => this.oncanplay?.()); } removeAttribute() {} load() {} }
    const context = vm.createContext({ $, Audio, AbortController, setTimeout, clearTimeout, Error,
        URL: { createObjectURL: () => 'blob:' + (++serial), revokeObjectURL: u => revoked.push(u) },
        audioSource: { isVideoAudioSource: file => file.type === 'video/mp4', inspectVideoAudioSource: async file => { videoChecks++; if (file.invalid) throw Error('无音轨'); } },
        sound, mediaReady: false, mediaToken: 0, mediaUrl: '', mediaName: '', mediaKind: '', mediaImport: null,
        activeSheet: 'audio', total: 40, marks: { 0: 0, 1: 5 }, shots: [{ image: 'saved.png' }],
        pause() { paused++; }, drawStage() {}, say() {}, setTime() {}, renderStrip() {}, renderShot() {}, renderTiming() {},
        fmt: String, esc: s => String(s).replaceAll('<', '&lt;').replaceAll('>', '&gt;') });
    vm.runInContext(helpers + '\n' + importer, context);
    return { context, nodes, $, sound, revoked, paused: () => paused, videoChecks: () => videoChecks };
}

test('HTML has one music entry, one player, all image controls and the same export/recovery entries', () => {
    assert.equal((html.match(/data-sheet="audio"/g) || []).length, 1);
    assert.equal((html.match(/id="play"/g) || []).length, 1);
    assert.equal((html.match(/id="seek"/g) || []).length, 1);
    for (const id of ['open-editor', 'edit-tab-grid', 'edit-tab-crop', 'edit-tab-brush', 'auto-cutout', 'undo-image', 'save-image', 'save-next', 'mark', 'undo-mark']) assert.ok(html.includes(`id="${id}"`), id);
    for (const id of ['import-image', 'import-transparent', 'restore-image', 'download-image', 'save-prompt', 'download-srt', 'download-times', 'save-draft', 'restore-draft', 'backup']) assert.ok(script.includes(`id="${id}"`), id);
    assert.ok(html.includes('data-grid="4:1"'));
    new vm.Script(script);
});

test('local recording uses the one shared sound element and current filename', async () => {
    const f = setup();
    await f.context.importSound({ name: '我的录屏.mp4', type: 'video/mp4' });
    assert.equal(f.videoChecks(), 1); assert.equal(f.sound.src, 'blob:1');
    assert.equal(f.$('#source-pill').textContent, '我的录屏.mp4');
    assert.equal(f.context.total, 19); assert.equal(f.context.mediaReady, true);
    assert.match(f.context.musicSheet()[1], /移除当前音乐/);
});

test('failed new recording retains the loaded music and timing', async () => {
    const f = setup();
    await f.context.importSound({ name: '原音乐.wav', type: 'audio/wav' });
    await f.context.importSound({ name: '无音轨.mp4', type: 'video/mp4', invalid: true });
    assert.equal(f.sound.src, 'blob:1'); assert.equal(f.$('#source-pill').textContent, '原音乐.wav');
    assert.equal(JSON.stringify(f.context.marks), '{"0":0,"1":5}');
    assert.match(f.$('#audio-dialog-status').textContent, /原有音源未替换/);
});

test('remove switches the same entry back to import without clearing pictures or marks', async () => {
    const f = setup(); await f.context.importSound({ name: '原音乐.wav', type: 'audio/wav' });
    const before = JSON.stringify({ marks: f.context.marks, shots: f.context.shots });
    f.context.removeMusic();
    assert.equal(f.context.mediaReady, false); assert.equal(f.sound.src, '');
    assert.equal(f.$('#source-pill').textContent, '导入音乐');
    assert.equal(JSON.stringify({ marks: f.context.marks, shots: f.context.shots }), before);
    assert.ok(f.revoked.includes('blob:1'));
});
