import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { webcrypto } from 'node:crypto';
const root=path.resolve(process.env.TEST_ROOT || 'candidate-r84185/tokimemo-main');
const source=fs.readFileSync(path.join(root,'dist/heartbeatMemories.bundle.js'),'utf8');
async function fixture() {
 const sb={console,TextEncoder,TextDecoder,URL,URLSearchParams,AbortController,DOMException,structuredClone,queueMicrotask,setTimeout,clearTimeout,setInterval,clearInterval,crypto:webcrypto,Response,Headers,
 document:{getElementById:()=>null,querySelector:()=>null}};
 const names=[...source.matchAll(/^const (__m_\w+) = Object.create\(null\);/gm)].map(x=>x[1]);
 const m=new vm.SourceTextModule(source+'\nexport { '+names.join(',')+' };',{context:vm.createContext(sb)});await m.link(()=>{});await m.evaluate();
 const get=p=>m.namespace['__m_'+(p+'.js').replace(/[^a-zA-Z0-9]/g,'_')];
 const constants=get('core/constants');
 const bank={version:3,archiveRevision:'r1',chatId:'A',characterName:'Char',userName:'User',memories:[{id:'M001',title:'事件',summary:'普通相处',anchors:['事件']}]};
 const host={characterId:0,characters:[{name:'Char',avatar:'char.png',data:{description:'test'}}],name1:'User',name2:'Char',chat:[],chatId:'A',getCurrentChatId(){return this.chatId},chatMetadata:{[constants.MEMORY_KEY]:bank},extensionSettings:{},getTokenCountAsync:async()=>1,saveMetadataDebounced:()=>{}};
 let live=host;sb.SillyTavern={getContext:()=>live};
 const disk=new Map();sb.localStorage={getItem:k=>disk.get(k)??null,setItem:(k,v)=>disk.set(k,v)};
 get('archive/repository').requireArchive=(c=live)=>{const b=c.chatMetadata[constants.MEMORY_KEY];if(!b)throw Error('missing archive');return b;};
 return {get,sb,host,bank,disk,switchTo:c=>{live=c},constants};
}
const waitingRaw=()=>({points:[{id:'P1',name:'书桌',state:'想念',detail:'台历上 9 月 17 日',voice:'回来吧'}],locked:[],letter:{title:'信',body:'等你'},roomNode:{text:'灯还亮着'}});
function realClient(f, onRequest) {
 const {get,host,constants}=f;
 host.ConnectionManagerRequestService={validateProfile:()=>({selected:'openai',source:'openai'}),sendRequest:async()=>({choices:[{message:{content:JSON.stringify(await onRequest())}}]})};
 get('core/settings').getPluginSettings=()=>({...constants.DEFAULT_SETTINGS,apiConnectionMode:'profile',connectionProfileId:'TEST',maxTokens:120000});
 get('core/settings').prepareManualCredential=async()=>{};
 get('core/independentApi').assertConnectionManagerProfileSupport=()=>{};
 get('core/settings').rawConnectionProfile=()=>({id:'TEST',api:'openai'});
 get('core/settings').resolvedProfileTransportFingerprint=async()=> 'TEST';
 get('core/cache').buildControlledContextEnvelope=async()=>'';
 get('core/requestCoordinator').refreshConcurrentTaskUi=()=>{};
}
test('all production module exports initialize',async()=>{const f=await fixture();let count=0;for(const p of [...source.matchAll(/^\/\/ MODULE: (.+)\.js$/gm)].map(x=>x[1]))for(const [k,v]of Object.entries(f.get(p))){assert.notEqual(v,undefined,p+':'+k);count++;}assert.ok(count>1000);});
test('input user budget preserves positive integers; actual tokens decide instead of chars',async()=>{
 const f=await fixture(),b=f.get('core/outputBudget');for(const n of [1,7999,60000,200001,1000000,Number.MAX_SAFE_INTEGER])assert.equal(b.normalizeInputBudgetTokens(n),n);
 for(const n of [-1,0,1.5,Infinity,'oops'])assert.equal(b.isValidInputBudgetTokens(n),false);
 let calls=0;f.host.getTokenCountAsync=async()=>{calls++;return 1};f.get('core/settings').getPluginSettings=()=>({inputBudgetTokens:60000});
 await f.get('generation/generationContext').assertPromptBudget(f.host,'a'.repeat(600001));assert.equal(calls,1);
 f.host.getTokenCountAsync=async()=>60001;await assert.rejects(f.get('generation/generationContext').assertPromptBudget(f.host,'x'),e=>e.code==='RMT_INPUT_BUDGET');
 f.host.getTokenCountAsync=async()=>{throw Error('offline tokenizer')};assert.equal((await f.get('generation/generationContext').assertPromptBudget(f.host,'a'.repeat(600001))).tokensKnown,false);
});
test('JSON and profile streaming preserve responses beyond 600k chars and 4MB',async()=>{
 const f=await fixture(),raw=JSON.stringify({text:'长'.repeat(1400000)});assert.equal(f.get('generation/jsonParser').extractJson(raw).text.length,1400000);
 const r=await f.get('core/independentApiConfig').readProfileCompletion(async function*(){yield{text:raw,state:{reasoning:''}};});
 assert.ok(JSON.stringify(r).includes('长'.repeat(100)));assert.equal(await f.get('core/independentApiConfig').boundedResponseText(new Response(raw)),raw);
});
test('cumulative drama and extras retain every existing record past former caps',async()=>{
 const f=await fixture(),old=Array.from({length:300},(_,i)=>({id:'D'+i,title:'old'+i,setting:'s'+i})),before=JSON.stringify(old);
 const result=f.get('modes/heartData').appendHeartDramaItem(structuredClone(old),{id:'NEW',title:'new',setting:'new'},'voice','D');assert.equal(result.added,1);assert.equal(result.list.length,301);assert.equal(JSON.stringify(result.list.slice(0,300)),before);
 const out=f.get('extras/store').normalizeExtras({intel:old,waiting:{records:old}});assert.equal(out.intel.length,300);assert.equal(out.waiting.records.length,300);
});
test('CG incremental generation retains paid item 241 and matching coverage',async()=>{
 const f=await fixture(),g=f.get;f.bank.memories=Array.from({length:241},(_,i)=>({id:'M'+String(i+1).padStart(3,'0'),title:'事件'+i,summary:'普通相处',anchors:['事件'+i]}));
 const old={kind:'album',entries:Array.from({length:240},(_,i)=>({id:'CG'+i,unlocked:true,sourceMemoryIds:[f.bank.memories[i].id],sourceMemoryAnchor:'事件'+i,title:'旧'+i,desc:'旧剧情'})),generationMeta:{parts:{mode:{coveredMemoryIds:f.bank.memories.slice(0,240).map(x=>x.id),archiveRevision:'r0'}}}};
 const before=JSON.stringify(old);let calls=0;g('core/cache').loadSession=()=>old;g('core/settings').getPluginSettings=()=>({autoSecondPass:false});g('core/requestCoordinator').noteSecondStepOffer=()=>{};g('generation/prompts').promptSafetyBoundary=()=>'';
 g('generation/client').requestValidatedSegment=async(p,l,o,validate)=>{calls++;return validate({entries:[{id:'CGNEW',unlocked:true,sourceMemoryIds:['M241'],sourceMemoryAnchor:'事件240',title:'新作品',desc:'事件240发生的新场景',visualSeed:['门','灯','树','路']}]})};
 const result=await g('modes/album').generateAlbumWithRepair(f.host,f.bank,{},'TEST');assert.equal(calls,1);assert.equal(result.entries.length,241);assert.ok(result.entries.some(x=>x.id==='CGNEW'));assert.equal(JSON.stringify(old),before);assert.ok(result.generationMeta.parts.mode.coveredMemoryIds.includes('M241'));
 const scan=JSON.parse(g('modes/album').albumRelationshipArchiveSlice(f.bank));assert.equal(scan.memories.length,241);assert.ok(JSON.stringify(scan).includes('M241'));
});
test('real waiting request pipeline holds revision drift and does not commit stale output',async()=>{
 const f=await fixture();let calls=0;realClient(f,()=>{calls++;f.bank.archiveRevision='r2';return waitingRaw()});
 const result=await f.get('extras/waiting').generateWaiting();assert.equal(calls,1);assert.equal(result.pending,true);assert.equal(f.get('extras/store').readExtras(f.host).waiting.records.length,0);
 const rows=f.get('extras/store').pendingExtras(result.scope);assert.equal(rows.length,1);assert.equal(rows[0].origin.archiveRevision,'r1');assert.ok(rows[0].raw.points);
 const retry=await f.get('extras/store').retryExtraSave(result.scope,rows[0].id);assert.equal(retry.pending,true);assert.equal(calls,1);
});
test('switch + quota failure retains paid output; save-only retry restores old and new without another request',async()=>{
 const f=await fixture(),s=f.get('extras/store');f.host.chatMetadata[s.EXTRAS_KEY]={intel:[{id:'old',person:'Friend',createdAt:1}],waiting:{records:[{id:'Wold',createdAt:1}]}};let calls=0;
 const other={...f.host,chatId:'B',chatMetadata:{[f.constants.MEMORY_KEY]:{...f.bank,chatId:'B'}}};
 realClient(f,()=>{calls++;f.switchTo(other);f.sb.localStorage.setItem=()=>{throw Error('quota')};return waitingRaw()});
 const result=await f.get('extras/waiting').generateWaiting();assert.equal(result.pending,true);assert.equal(result.durable,false);assert.equal(other.chatMetadata[s.EXTRAS_KEY],undefined);
 f.switchTo(f.host);assert.equal(JSON.parse(s.exportExtras(f.host)).pending.length,1);f.sb.localStorage.setItem=(k,v)=>f.disk.set(k,v);
 const saved=await s.retryExtraSave(result.scope,result.record.id);assert.equal(saved.pending,false);assert.equal(calls,1);assert.equal(s.readExtras(f.host).waiting.records.length,2);assert.equal(s.readExtras(f.host).intel[0].id,'old');assert.equal(s.pendingExtras(result.scope).length,0);
 await s.retryExtraSave(result.scope,result.record.id);assert.equal(s.readExtras(f.host).waiting.records.length,2);
});
test('missing or silent localStorage never reports durable save; rejection handled and export available',async()=>{
 const f=await fixture();delete f.sb.localStorage;f.host.saveMetadataDebounced=async()=>{throw Error('disk')};realClient(f,waitingRaw);
 const result=await f.get('extras/waiting').generateWaiting();assert.equal(result.pending,true);assert.equal(result.durable,false);assert.ok(f.get('extras/store').exportExtras(f.host).includes('台历'));
 f.sb.localStorage={getItem:()=>null,setItem:()=>{}};assert.equal((await f.get('extras/store').retryExtraSave(result.scope,result.record.id)).pending,true);
});
test('durable pending journal survives runtime reload and requires original revision',async()=>{
 const a=await fixture();realClient(a,()=>{a.bank.archiveRevision='r2';return waitingRaw()});const result=await a.get('extras/waiting').generateWaiting();assert.equal(result.durable,true);
 const b=await fixture();for(const[k,v]of a.disk)b.disk.set(k,v);b.bank.archiveRevision='r2';const s=b.get('extras/store');assert.equal(s.pendingExtras(result.scope).length,1);assert.equal((await s.retryExtraSave(result.scope,result.record.id)).pending,true);
 b.bank.archiveRevision='r1';assert.equal((await s.retryExtraSave(result.scope,result.record.id)).pending,false);assert.equal(s.readExtras(b.host).waiting.records.length,1);
});
test('invalid paid body remains exportable rather than triggering another request',async()=>{
 const f=await fixture();let calls=0;realClient(f,()=>{calls++;return {unexpected:'paid raw marker'}});
 const r=await f.get('extras/waiting').generateWaiting();assert.equal(r.pending,true);assert.equal(calls,1);assert.ok(f.get('extras/store').exportExtras(f.host).includes('paid raw marker'));
});
test('real intel request saves normally and releases running state',async()=>{
 const f=await fixture();let calls=0;f.get('core/cache').loadSession=()=>({relationships:[{name:'Friend',relation:'朋友'}]});f.get('modes/relations').relationsViewIdentity=()=>({profile:null});realClient(f,()=>{calls++;return{scene:'花园',sections:[{kind:'mention',text:'他说你很好',sourceMemoryIds:['M001']}]}});
 const r=await f.get('extras/intel').askIntel('Friend');assert.equal(calls,1);assert.equal(r.pending,false);assert.equal(f.get('extras/store').readExtras(f.host).intel.length,1);assert.equal(f.get('extras/intel').isIntelRunning(r.scope,'friend'),false);
});
test('manual JSON and SSE transport retain >4MB while preserving requested output budget',async()=>{
 const f=await fixture(),text='长'.repeat(1400000),raw=JSON.stringify({text}),settings={manualApiBaseUrl:'https://example.test/v1',manualApiModel:'model',manualApiKey:'',temperature:0.7};
 for(const streaming of [false,true]){
  let sent;
  const payload=streaming ? 'data: '+JSON.stringify({choices:[{delta:{content:raw},finish_reason:null}]})+'\n\ndata: '+JSON.stringify({choices:[{delta:{},finish_reason:'stop'}]})+'\n\ndata: [DONE]\n\n' : JSON.stringify({choices:[{message:{content:raw}}]});
  const out=await f.get('core/independentApiRequest').requestManualApiCompletion({...settings,manualApiStreaming:streaming},f.host,[{role:'user',content:'test'}],1000000,{fetchImpl:async(url,options)=>{sent=JSON.parse(options.body);return new Response(payload,{headers:{'content-type':streaming?'text/event-stream':'application/json'}})}});
  assert.equal(sent.max_tokens,1000000);const final=streaming?f.get('core/independentApiConfig').extractIndependentResponseContent(out):out;assert.ok(final === raw, "complete manual response preserved");
 }
});
test('archive deletion and character switch never write held results into the new target',async()=>{
 const f=await fixture();realClient(f,()=>{delete f.host.chatMetadata[f.constants.MEMORY_KEY];return waitingRaw()});const r=await f.get('extras/waiting').generateWaiting();assert.equal(r.pending,true);assert.equal(f.get('extras/store').readExtras(f.host).waiting.records.length,0);
 f.host.characterId=1;f.host.characters.push({name:'Other',avatar:'other.png'});f.host.chatMetadata[f.constants.MEMORY_KEY]=f.bank;assert.equal((await f.get('extras/store').retryExtraSave(r.scope,r.record.id)).pending,true);
});
test('confirmed local results remain recoverable despite rejected metadata persistence',async()=>{
 const f=await fixture();f.host.saveMetadataDebounced=async()=>{throw Error('metadata disk')};realClient(f,waitingRaw);const r=await f.get('extras/waiting').generateWaiting();assert.equal(r.pending,false);
 const b=await fixture();for(const[k,v]of f.disk)b.disk.set(k,v);assert.equal(b.get('extras/store').readExtras(b.host).waiting.records.length,1);
});
test('HTTP/LAN hosts without crypto.randomUUID can retain paid results with distinct ids',async()=>{
 const f=await fixture();f.sb.crypto={};realClient(f,waitingRaw);const a=await f.get('extras/waiting').generateWaiting(),b=await f.get('extras/waiting').generateWaiting();assert.equal(a.pending,false);assert.equal(b.pending,false);assert.notEqual(a.record.id,b.record.id);assert.equal(f.get('extras/store').readExtras(f.host).waiting.records.length,2);
});
