// Offline byte/AST comparison against the delivered r84.179 ZIP; evidence can stay outside the installer.
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { spawnSync } from 'node:child_process';
const root = path.resolve(new URL('..', import.meta.url).pathname), baseline = path.resolve(process.argv[2] || '');
if (!process.argv[2] || baseline === root) throw new Error('Provide a separate extracted baseline directory');
const out = process.env.HEARTTRACE_AUDIT_OUTPUT ? path.resolve(process.env.HEARTTRACE_AUDIT_OUTPUT) : path.join(root, 'verification', 'r84180-audit'); fs.mkdirSync(out, { recursive: true });
const sha = value => createHash('sha256').update(value).digest('hex');
const walk = dir => fs.readdirSync(dir, { withFileTypes: true }).flatMap(row => row.isDirectory()
    ? walk(path.join(dir, row.name)) : [path.join(dir, row.name)]);
const files = dir => new Map(walk(dir).map(file => [path.relative(dir, file).replaceAll(path.sep, '/'), fs.readFileSync(file)]));
const old = files(baseline), next = files(root), unchanged = [], changed = [], added = [], deleted = [];
for (const [file, bytes] of old) {
    if (!next.has(file)) deleted.push(file);
    else if (bytes.equals(next.get(file))) unchanged.push({ file, sha256: sha(bytes) });
    else changed.push({ file, before: sha(bytes), after: sha(next.get(file)) });
}
for (const [file, bytes] of next) if (!old.has(file) && !file.startsWith('verification/r84180-audit/')) added.push({ file, sha256: sha(bytes) });
const require = createRequire(import.meta.url), acorn = require(process.env.ACORN_PATH || 'acorn');
function promptDeclarations(table) {
    const values = new Map();
    for (const [file, bytes] of table) {
        if (!file.startsWith('src/') || !file.endsWith('.js')) continue;
        const source = bytes.toString('utf8'), counts = new Map();
        const ast = acorn.parse(source, { sourceType: 'module', ecmaVersion: 'latest' });
        function visit(node) {
            if (!node || typeof node !== 'object') return;
            const name = ['FunctionDeclaration', 'FunctionExpression', 'VariableDeclarator'].includes(node.type) ? node.id?.name : null;
            if (name && /prompt/i.test(name)) {
                const id = node.type + ':' + name, count = counts.get(id) || 0; counts.set(id, count + 1);
                values.set(file + ':' + id + ':' + count, sha(source.slice(node.start, node.end)));
            }
            for (const value of Object.values(node)) if (Array.isArray(value)) value.forEach(visit);
            else if (value && typeof value === 'object') visit(value);
        }
        visit(ast);
    }
    return values;
}
const beforePrompts = promptDeclarations(old), afterPrompts = promptDeclarations(next);
const promptChanges = [...beforePrompts].filter(([key, hash]) => afterPrompts.get(key) !== hash).map(([key]) => key);
const promptAdditions = [...afterPrompts.keys()].filter(key => !beforePrompts.has(key));
const approvedRuntimeFiles = new Set([
    'src/archive/coverageRanges.js', 'src/core/cacheCommit.js', 'src/core/cacheArchiveMemory.js',
    'src/core/outputBudget.js', 'src/ui/autoMemoryWizard.js', 'src/ui/settingsPanelParts.js',
    'src/generation/jsonParser.js', 'src/generation/generationRequest.js', 'src/generation/recoverySegments.js',
    'src/generation/partialProgress.js', 'src/generation/recovery.js', 'src/core/independentApiConfig.js', 'src/modes/cabinet.js',
]);
const protectedFiles = [...old.keys()].filter(file => file.startsWith('src/') && !approvedRuntimeFiles.has(file)
    || /^tools\/test-.*\.mjs$/.test(file));
const protectedChanges = protectedFiles.filter(file => !next.get(file)?.equals(old.get(file)));
const summary = { baseline: 'r84.179', candidate: 'r84.180', changed, added, deleted,
    unchangedCount: unchanged.length, oldTestsUnchanged: protectedFiles.filter(p => p.startsWith('tools/test-')).length,
    promptDeclarationsCompared: beforePrompts.size, promptChanges, promptAdditions, protectedChanges,
    projectDiffExcludedPrefixes: ['verification/r84180-'],
    limitations: ['Static named-prompt declarations, unchanged files and explicitly scoped source diffs are compared; this is not a real model test.',
        'Project diff includes new source files and changed build/tool/docs; per-round evidence is supplied separately, not diffed against itself.'] };
fs.writeFileSync(path.join(out, 'file-comparison.json'), JSON.stringify(summary, null, 2) + '\n');
fs.writeFileSync(path.join(out, 'unchanged-sha256.json'), JSON.stringify(unchanged, null, 2) + '\n');
const promptRows = [...beforePrompts].sort(([a], [b]) => a.localeCompare(b)).map(([name, hash]) => ({ name, baselineSha256: hash, candidateSha256: afterPrompts.get(name) || null }));
const promptProof = { compared: promptRows.length, changed: promptChanges, added: promptAdditions,
    baselineAggregateSha256: sha(JSON.stringify(promptRows.map(row => [row.name, row.baselineSha256]))),
    candidateAggregateSha256: sha(JSON.stringify(promptRows.map(row => [row.name, row.candidateSha256]))), rows: promptRows };
fs.writeFileSync(path.join(out, 'prompt-zero-change.json'), JSON.stringify(promptProof, null, 2) + '\n');
let patch = '', projectPatch = '';
for (const row of [...changed, ...added].filter(row => !row.file.startsWith('verification/r84180-'))) {
    const oldPath = old.has(row.file) ? path.join(baseline, row.file) : '/dev/null';
    const result = spawnSync('git', ['diff', '--no-index', '--no-color', '--', oldPath, path.join(root, row.file)], { encoding: 'utf8', maxBuffer: 32 * 1024 * 1024 });
    if (![0, 1].includes(result.status)) throw new Error(result.stderr || 'Diff failed');
    const section = result.stdout.replaceAll(baseline + '/', 'r84.179/').replaceAll(root + '/', 'r84.180/');
    projectPatch += section;
    if (row.file.startsWith('src/') || ['index.js', 'manifest.json'].includes(row.file)) patch += section;
}
fs.writeFileSync(path.join(out, 'runtime-diff.patch'), patch);
fs.writeFileSync(path.join(out, 'complete-project-diff.patch'), projectPatch);
console.log(JSON.stringify({ changed: changed.map(row => row.file), added: added.map(row => row.file), deleted,
    unchanged: unchanged.length, oldTestsUnchanged: summary.oldTestsUnchanged,
    promptDeclarationsCompared: beforePrompts.size, promptChanges, promptAdditions, protectedChanges }));
if (deleted.length || promptChanges.length || promptAdditions.length || protectedChanges.length) process.exitCode = 1;
