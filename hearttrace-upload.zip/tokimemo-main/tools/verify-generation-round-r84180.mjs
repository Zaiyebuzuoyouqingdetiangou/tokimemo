// r84.180 finite, offline release gate; captures real stdout/stderr and preserves the
// baseline interactive test artifact after its generating test has run.
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
const root = path.resolve(new URL('..', import.meta.url).pathname);
const round = process.argv[2] || 'round1';
const part = process.argv[3] || 'all';
if (!/^round[123]$/.test(round)) throw new Error('Use round1, round2 or round3');
if (!/^(all|tests-[1-6]|build|runtime|names|guard|dom|finalize)$/.test(part)) throw new Error('Unknown verification part');
const out = process.env.HEARTTRACE_VERIFICATION_OUTPUT ? path.resolve(process.env.HEARTTRACE_VERIFICATION_OUTPUT, round) : path.join(root, 'verification', 'r84180-' + round); fs.mkdirSync(out, { recursive: true });
const resultFile = path.join(out, 'result.json');
const result = part !== 'all' && fs.existsSync(resultFile) ? JSON.parse(fs.readFileSync(resultFile, 'utf8'))
    : { round, startedAt: new Date().toISOString(), root, checks: [], nativeBrowser: false, realProvider: false };
if (result.root !== root || result.round !== round) throw new Error('Verification identity changed');
const record = () => fs.writeFileSync(path.join(out, 'result.json'), JSON.stringify(result, null, 2) + '\n');
const run = (label, args) => {
    const started = Date.now(), proc = spawnSync(process.execPath, args, { cwd: root, encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 });
    fs.writeFileSync(path.join(out, label + '.log'), (proc.stdout || '') + (proc.stderr || ''));
    result.checks.push({ label, argv: [process.execPath, ...args], exitCode: proc.status, signal: proc.signal, durationMs: Date.now() - started }); record();
    console.log(JSON.stringify(result.checks.at(-1)));
    if (proc.error || proc.status !== 0) throw proc.error || new Error(label + ' failed: see log');
};
record();
try {
    const runtimeFiles = dir => fs.readdirSync(dir, { withFileTypes: true }).flatMap(row => row.isDirectory()
        ? runtimeFiles(path.join(dir, row.name)) : [path.join(dir, row.name)]).sort();
    const runtimeHash = createHash('sha256');
    for (const file of [...runtimeFiles(path.join(root, 'src')), path.join(root, 'index.js'), path.join(root, 'manifest.json')]) {
        runtimeHash.update(path.relative(root, file)); runtimeHash.update(fs.readFileSync(file));
    }
    const sourceSha256 = runtimeHash.digest('hex');
    if (result.sourceSha256 && result.sourceSha256 !== sourceSha256) throw new Error('Runtime source changed during this round');
    result.sourceSha256 = sourceSha256;
    const tests = fs.readdirSync(path.join(root, 'tools')).filter(name => /^test-.*\.mjs$/.test(name)).sort().map(name => 'tools/' + name);
    const inventory = tests.map(file => ({ file, sha256: createHash('sha256').update(fs.readFileSync(path.join(root, file))).digest('hex') }));
    if (result.testInventory && JSON.stringify(result.testInventory) !== JSON.stringify(inventory)) throw new Error('Test inventory changed during this round');
    result.testInventory = inventory;
    result.status = 'in-progress';
    const fixturePath = path.join(root, 'tools', 'phone-journal-r8483-interactive.html');
    const fixtureBefore = fs.existsSync(fixturePath) ? fs.readFileSync(fixturePath) : null;
    try {
        if (part === 'all') run('all-tests', ['--experimental-vm-modules', '--test', '--test-concurrency=4', ...tests]);
        else if (part.startsWith('tests-')) {
            const index = Number(part.slice(6)) - 1;
            const selected = tests.filter((_file, i) => i % 6 === index);
            run(part, ['--experimental-vm-modules', '--test', '--test-concurrency=4', ...selected]);
        }
    }
    finally { if (fixtureBefore) fs.writeFileSync(fixturePath, fixtureBefore); }
    if (part === 'all' || part === 'build') {
    run('build-1', ['tools/build-runtime-bundle.mjs', '.']);
    const bundle = path.join(root, 'dist', 'heartbeatMemories.bundle.js'), first = fs.readFileSync(bundle);
    run('build-2', ['tools/build-runtime-bundle.mjs', '.']);
    if (!first.equals(fs.readFileSync(bundle))) throw new Error('Repeated build differs');
    result.bundleSha256 = createHash('sha256').update(first).digest('hex'); record();
    }
    if (part === 'all' || part === 'runtime') run('runtime-syntax', ['--experimental-vm-modules', 'tools/verify-runtime.mjs']);
    if (part === 'all' || part === 'names') run('undefined-names', ['tools/check-undefined-names.mjs']);
    if (part === 'all' || part === 'guard') run('refactor-guard', ['--experimental-vm-modules', 'tools/refactor-guard.mjs', 'check']);
    if (part === 'all' || part === 'dom') {
    if (process.env.HAPPY_DOM_PATH) run('simulated-dom', ['--experimental-vm-modules', 'tools/check-relay-dom-r84179.mjs']);
    else result.simulatedDom = 'not run; HAPPY_DOM_PATH unavailable';
    }
    if (part === 'all' || part === 'finalize') {
        const needed = [part === 'all' ? 'all-tests' : null, ...part === 'finalize' ? [1,2,3,4,5,6].map(n => 'tests-' + n) : [],
            'build-1', 'build-2', 'runtime-syntax', 'undefined-names', 'refactor-guard', 'simulated-dom'].filter(Boolean);
        if (needed.some(label => !result.checks.some(row => row.label === label && row.exitCode === 0))
            || result.checks.some(row => row.exitCode !== 0)) throw new Error('Missing or failed verification parts');
        const testLogs = (part === 'all' ? ['all-tests'] : [1,2,3,4,5,6].map(n => 'tests-' + n))
            .map(label => fs.readFileSync(path.join(out, label + '.log'), 'utf8'));
        result.tests = Object.fromEntries(['tests', 'pass', 'fail', 'cancelled', 'skipped', 'todo'].map(key => [key,
            testLogs.reduce((sum, log) => {
                const match = log.match(new RegExp('(?:# |ℹ )' + key + ' (\\d+)'));
                if (!match) throw new Error('Missing test summary: ' + key);
                return sum + Number(match[1]);
            }, 0)]));
        result.status = 'passed';
    }
} catch (error) { result.status = 'failed'; result.error = String(error.message); process.exitCode = 1; }
finally { result.finishedAt = new Date().toISOString(); record(); console.log(JSON.stringify({ round, status: result.status, error: result.error || null })); }
