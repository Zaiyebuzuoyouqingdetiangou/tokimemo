import test from 'node:test';
import assert from 'node:assert/strict';
import { harness } from './runtime-harness.mjs';

const plain = value => JSON.parse(JSON.stringify(value));
const oldMemory = () => ({ version: 3, chatId: 'A', archiveRevision: 'revision-A', createdAt: 1, updatedAt: 2,
    characterName: 'Char', userName: 'User', archiveName: '旧档案', archiveSummary: '一起散步。', archiveKeywords: [],
    sourceMessageCount: 1, usedMessageCount: 1, usedCharacterCount: 20, sourceFingerprint: 'old-A:none',
    fullSourceFingerprint: 'full-A', externalMemoryFingerprint: 'none', externalMemoryRecordCount: 0,
    chatReadRange: { mode: 'all', includeHidden: false }, coverageMode: 'batched-complete',
    memories: [{ id: 'M100', title: '旧散步', summary: '一起散步。', anchors: ['散步'], sourceKind: 'chat', messageStart: 1, messageEnd: 1 }] });

async function fixture() {
    const h = await harness({ messages: 1, failAfter: 100, bundle: false });
    const ctx = h.module('core/context.js'), cache = h.module('core/cache.js');
    const backup = h.module('archive/backupStore.js'), policy = h.module('core/archiveRelayPolicy.js');
    const relay = h.module('archive/relayPreparation.js'), constants = h.module('core/constants.js');
    const fences = new Map();
    h.module('archive/sourceLedger.js').setMemorySourceLedgerBackendForTests({ read: async () => null, write: async () => true, delete: async () => true });
    backup.setArchiveBackupBackendForTests({
        read: async entry => h.copy(h.backups.get(ctx.archiveIndexEntryId(entry)) || null),
        readRelay: async entry => h.copy(fences.get(policy.relayMemberKey(entry)) || null),
        put: async (record, expected, options) => {
            options?.stillCurrent?.();
            const previous = h.backups.get(record.entryId);
            if (expected?.present === true && previous) assert.equal(previous.archiveRevision, expected.revision);
            if (expected?.present === false) assert.ok(!previous || previous.deleted);
            h.backups.set(record.entryId, h.copy(record)); return true;
        },
        delete: async () => {},
    });
    const entry = chatId => h.copy({ avatar: 'char.png', characterIndexHint: 0, chatId });
    const setFence = (chatId, holder = chatId, epoch = 1) => {
        const members = ['A', 'B'].map(entry), member = entry(chatId);
        const value = h.copy({ kind: 'archive-relay-member', version: 1, lineageId: 'lineage-1', epoch,
            entryId: policy.relayMemberKey(member), holderKey: policy.relayMemberKey(entry(holder)), members });
        fences.set(policy.relayMemberKey(member), value);
    };
    const mount = ({ memory, cache: stored = {} }, { registered = true, holder = memory.chatId, epoch = 1 } = {}) => {
        h.host.chatId = memory.chatId;
        h.host.chatMetadata = h.copy({ [constants.MEMORY_KEY]: memory, [constants.CACHE_KEY]: stored });
        if (registered) setFence(memory.chatId, holder, epoch);
        const currentEntry = cache.archiveBackupEntryForContext(h.host, memory);
        const record = backup.prepareArchiveBackupRecord(currentEntry, memory, stored);
        h.backups.set(record.entryId, h.copy(record));
    };
    const moved = () => {
        const result = relay.prepareArchiveRelay(h.copy({ memory: oldMemory(), cache: {
            chatId: 'A', archiveRevision: 'revision-A', album: { kind: 'album', chatId: 'A', archiveRevision: 'revision-A', selectedId: 'AL1',
                entries: [{ id: 'AL1', title: '旧照片', desc: '散步', sourceMemoryIds: ['M100'], cgImage: { url: '/images/kept.png', generatedAt: 1 }, comments: [{ text: '保留评论' }] }] },
        } }), { chatId: 'B', revision: 'relay-B', now: 3 });
        result.memory.archiveRelayV1 = h.copy({ version: 1, lineageId: 'lineage-1', epoch: 1 });
        return result;
    };
    return { h, ctx, cache, backup, policy, relay, constants, fences, mount, moved, setFence };
}

test('真实导入：首次 B 从自己的第 1 楼续编，保留 A 编号、来源和生成缓存；之后仍校验 B 前缀', async () => {
    const f = await fixture(), transferred = f.moved(); f.mount(transferred);
    const checkpoints = plain(transferred.memory.relaySourceCheckpointsV1);
    assert.equal((await f.h.repo.importCurrentChatMemory()).status, 'committed', JSON.stringify(f.h.events));
    const bank = f.h.repo.getImportedMemory(f.h.host);
    assert.deepEqual([...bank.memories.map(row => row.id)], ['M100', 'M101']);
    assert.equal(bank.memories[0].sourceChatId, 'A');
    assert.equal(bank.memories[1].sourceChatId, 'B');
    assert.equal(bank.memories[1].messageStart, 1);
    assert.deepEqual(plain(bank.archiveRelayV1), { version: 1, lineageId: 'lineage-1', epoch: 1 });
    assert.deepEqual(plain(bank.relaySourceCheckpointsV1), checkpoints);
    assert.equal(f.relay.relayHasUnreadCurrentSource(bank), false);
    assert.equal(bank.sourceMessageCount, 1);
    const album = f.cache.loadSession('album', { cache: f.cache.getCache(f.h.host), memoryBank: bank, chatId: 'B' });
    assert.equal(album.entries[0].cgImage.url, '/images/kept.png');
    assert.equal(album.entries[0].comments[0].text, '保留评论');
    f.h.host.chat.push({ name: 'Char', is_user: false, mes: '后来一起回家，又散步。' });
    assert.equal((await f.h.repo.importCurrentChatMemory()).status, 'committed', JSON.stringify(f.h.events));
    const appended = f.h.repo.getImportedMemory(f.h.host);
    assert.deepEqual([...appended.memories.map(row => row.id)], ['M100', 'M101', 'M102']);
    assert.equal(appended.memories[2].sourceChatId, 'B');
    assert.equal(appended.memories[2].messageStart, 2);
    assert.equal(appended.sourceMessageCount, 2);
    assert.deepEqual(plain(appended.relaySourceCheckpointsV1), checkpoints);
    const paid = f.h.providerCalls.length;
    f.h.host.chat[0].mes = '改掉 B 原来那一楼。';
    await assert.rejects(f.h.repo.importCurrentChatMemory(), { code: 'RMT_ARCHIVE_PREFIX_CHANGED' });
    assert.equal(f.h.providerCalls.length, paid, '非空 B 不再享有空前缀例外');
    assert.equal(f.h.repo.getImportedMemory(f.h.host).archiveRevision, appended.archiveRevision);
});

test('普通空前缀、错误成员检查点、已读过的 B 均不能冒用首次接力例外', async () => {
    for (const variant of ['ordinary', 'wrong-checkpoint', 'read-B']) {
        const f = await fixture(), transferred = f.moved();
        if (variant === 'ordinary') delete transferred.memory.archiveRelayV1;
        if (variant === 'wrong-checkpoint') transferred.memory.relaySourceCheckpointsV1.chats.B.sourceMessageCount = 1;
        if (variant === 'read-B') transferred.memory.sourceMessageCount = 1;
        f.mount(transferred, { registered: variant !== 'ordinary' });
        await assert.rejects(f.h.repo.importCurrentChatMemory(), { code: 'RMT_ARCHIVE_PREFIX_CHANGED' }, variant);
        assert.equal(f.h.providerCalls.length, 0, variant);
        assert.deepEqual(plain(f.h.repo.getImportedMemory(f.h.host).memories), plain(transferred.memory.memories));
    }
});

test('只读 A 在付费导入之前被拒绝，包括主聊天镜像尚无接力标记的情况', async () => {
    for (const markerPresent of [true, false]) {
        const f = await fixture(), memory = f.h.copy(oldMemory());
        if (markerPresent) memory.archiveRelayV1 = f.h.copy({ version: 1, lineageId: 'lineage-1', epoch: 1 });
        f.mount({ memory, cache: {} }, { holder: 'B' });
        const before = plain(f.h.host.chatMetadata);
        await assert.rejects(f.h.repo.importCurrentChatMemory(), { code: 'RMT_RELAY_READ_ONLY' });
        assert.equal(f.h.providerCalls.length, 0);
        assert.deepEqual(plain(f.h.host.chatMetadata), before);
    }
});

test('未接力建档原流程可提交，不添加任何接力标记或检查点', async () => {
    const f = await fixture();
    const result = await f.h.repo.importCurrentChatMemory();
    assert.equal(result.status, 'committed', JSON.stringify(f.h.events));
    const bank = f.h.repo.getImportedMemory(f.h.host);
    assert.ok(bank.memories.length > 0);
    assert.equal(bank.archiveRelayV1, undefined);
    assert.equal(bank.relaySourceCheckpointsV1, undefined);
});

test('B 追加后接回 A，只处理 A 新楼层，A 原检查点与 B 的记忆均保留', async () => {
    const f = await fixture(); f.h.host.chatId = 'A';
    const originalChat = f.h.copy(f.h.host.chat), snapshot = await f.ctx.buildChatSnapshot(f.h.host,
        { completeSource: true, readRange: f.h.module('core/settings.js').getPluginSettings(f.h.host).chatReadRange });
    const original = f.h.copy({ ...oldMemory(), sourceFingerprint: `${snapshot.fingerprint}:none`,
        fullSourceFingerprint: snapshot.fullFingerprint, sourceMessageCount: snapshot.totalMessages,
        chatReadRange: snapshot.readRange, usedMessageCount: snapshot.usedMessages, usedCharacterCount: snapshot.usedChars });
    const toB = f.relay.prepareArchiveRelay(f.h.copy({ memory: original, cache: {} }), { chatId: 'B', revision: 'relay-B', now: 3 });
    toB.memory.archiveRelayV1 = f.h.copy({ version: 1, lineageId: 'lineage-1', epoch: 1 });
    f.mount(toB);
    assert.equal((await f.h.repo.importCurrentChatMemory()).status, 'committed', JSON.stringify(f.h.events));
    const inB = f.h.repo.getImportedMemory(f.h.host);
    const toA = f.relay.prepareArchiveRelay(f.h.copy({ memory: inB, cache: f.cache.getCache(f.h.host) }),
        { chatId: 'A', revision: 'relay-A-2', now: 4, previousMemberMemory: original });
    toA.memory.archiveRelayV1.epoch = 2;
    f.h.host.chat = [...originalChat, { name: 'Char', is_user: false, mes: '回到 A 后继续散步。' }];
    f.mount(toA, { epoch: 2 });
    assert.equal(toA.memory.sourceFingerprint, original.sourceFingerprint);
    assert.equal((await f.h.repo.importCurrentChatMemory()).status, 'committed', JSON.stringify(f.h.events));
    const back = f.h.repo.getImportedMemory(f.h.host);
    assert.deepEqual([...back.memories.map(row => [row.id, row.sourceChatId])], [['M100', 'A'], ['M101', 'B'], ['M102', 'A']]);
    assert.equal(back.memories[2].messageStart, 2);
    assert.equal(back.sourceMessageCount, 2);
    assert.equal(back.relaySourceCheckpointsV1.chats.B.sourceMessageCount, 1);
    assert.equal(back.archiveRelayV1.epoch, 2);
});

test('明确完全重建也保留当前接力归属，不把成员变成未登记档案', async () => {
    const f = await fixture(), transferred = f.moved(); f.mount(transferred);
    assert.equal((await f.h.repo.importCurrentChatMemory({ fullRebuild: true })).status, 'committed', JSON.stringify(f.h.events));
    const bank = f.h.repo.getImportedMemory(f.h.host);
    assert.deepEqual(plain(bank.archiveRelayV1), plain(transferred.memory.archiveRelayV1));
    assert.deepEqual(plain(bank.relaySourceCheckpointsV1), plain(transferred.memory.relaySourceCheckpointsV1));
});
