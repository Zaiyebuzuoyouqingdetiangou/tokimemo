import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';
const root = process.env.HEARTTRACE_TEST_ROOT || fileURLToPath(new URL('..', import.meta.url));
const { roundReadingHtml, incrementalProjection } = await import(pathToFileURL(path.join(root, 'src/autoMemory/incrementalView.js')));
const event = (id, extra = {}) => ({ id, title: '长街听闻与无声抚慰', date: '九月二十八日',
    cgDesc: '长街尽头，两人在檐下等雨停。', sourceMemoryIds: ['M002'], ...extra });

test('letter ADV shows the saved date, scene and every paragraph in reading order without the main-window picker', () => {
    const session = { kind: 'adv', events: [event('E1', { adv: { paragraphs: ['我把伞递过去。', '\n雨慢慢停了。'] } })] };
    const before = JSON.stringify(session), html = roundReadingHtml(session);
    for (const text of ['长街听闻与无声抚慰', '九月二十八日', '长街尽头，两人在檐下等雨停。', '我把伞递过去。', '雨慢慢停了。']) assert.ok(html.includes(text), text);
    assert.ok(html.indexOf('我把伞递过去。') < html.indexOf('雨慢慢停了。'));
    assert.doesNotMatch(html, /rmt-adv-mobile-picker|rmt-event-items|data-rmt-action|data-rmt-generate-mode/);
    assert.equal(JSON.stringify(session), before);
});

test('an index-only saved event remains readable with its scene and an honest missing-prose status', () => {
    const session = { kind: 'adv', events: [event('E1', { adv: null })] };
    const before = JSON.stringify(session), html = roundReadingHtml(session);
    assert.ok(html.includes(session.events[0].cgDesc));
    assert.ok(html.includes('正文尚未生成'));
    assert.doesNotMatch(html, /data-rmt-action|data-rmt-generate-mode|onclick=/);
    assert.equal(JSON.stringify(session), before);
});

test('partial and finished events keep their existing prose and distinguish the unfinished event', () => {
    const html = roundReadingHtml({ kind: 'adv', events: [
        event('E1', { adv: { paragraphs: ['这段已经保存。'] }, progressPending: ['ADV 正文'] }),
        event('E2', { title: '回家', adv: { paragraphs: ['完整的第一段。', '完整的第二段。'] } }),
    ] });
    assert.ok(html.includes('这段已经保存。'));
    assert.ok(html.includes('完整的第一段。') && html.includes('完整的第二段。'));
    assert.equal((html.match(/正文尚未完成/g) || []).length, 1);
    assert.doesNotMatch(html, /正文尚未生成/);
});

test('the letter still projects only its own memory and escapes all saved event text', () => {
    const session = { kind: 'adv', events: [event('old', { title: '旧轮次不可混入', sourceMemoryIds: ['M001'] }),
        event('current', { title: '<img src=x onerror=bad()>', cgDesc: '<script>bad()</script>',
            adv: { paragraphs: ['<b>原样显示 & 不执行</b>'] } })] };
    const before = JSON.stringify(session), result = incrementalProjection(session, { sourceMemoryIds: ['M002'] });
    const html = roundReadingHtml(result.session);
    assert.equal(result.session.events.length, 1);
    assert.doesNotMatch(html, /旧轮次不可混入|<img|<script>|<b>原样显示/);
    assert.match(html, /&lt;img src=x onerror=bad\(\)&gt;/);
    assert.match(html, /&lt;b&gt;原样显示 &amp; 不执行&lt;\/b&gt;/);
    assert.equal(JSON.stringify(session), before);
});

test('long titles and large existing prose are not truncated; repeated opening stays read-only', () => {
    const title = '这是完整保留的长事件标题'.repeat(30);
    const paragraphs = Array.from({ length: 300 }, (_, i) => `第${i + 1}段：${'已经保存的正文，不丢弃。'.repeat(25)}`);
    const session = { kind: 'adv', events: [event('E1', { title, adv: { paragraphs } })] };
    const before = JSON.stringify(session), first = roundReadingHtml(session);
    assert.ok(first.includes(title));
    for (const paragraph of paragraphs) assert.ok(first.includes(paragraph));
    assert.equal(roundReadingHtml(session), first);
    assert.equal(JSON.stringify(session), before);
});
