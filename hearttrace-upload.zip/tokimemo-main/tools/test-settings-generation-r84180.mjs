import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { preparationFixture } from './preparation-harness-r8481.mjs';

// Execute the shipped event handlers and real settings/request modules. Only DOM,
// time and fetch are fixtures; no model service or user credential is contacted.
const wizardSource = await readFile(new URL('../src/ui/autoMemoryWizard.js', import.meta.url), 'utf8');
function functionSource(name, next) {
    const start = wizardSource.search(new RegExp(`(?:async )?function ${name}\\(`));
    const end = wizardSource.indexOf(`\n${next}`, start);
    assert.ok(start >= 0 && end > start, `live ${name} boundary exists`);
    return wizardSource.slice(start, end);
}
async function wizardFixture({ base = 'https://new.example/v1', key = '', currentKey = 'fixture-old-key', secretOnly = false } = {}) {
    const f = await preparationFixture();
    Object.assign(f.sandbox, { Response, Uint8Array, ArrayBuffer });
    const settings = await f.api('core/settings.js');
    const parts = await f.api('ui/settingsPanelParts.js');
    const text = await f.api('core/text.js');
    settings.updatePluginSettings({ manualApiBaseUrl: 'https://old.example/v1', manualApiModel: 'fixture-model', manualApiKey: currentKey,
        manualApiSecretRef: 'credential:11111111-1111-1111-1111-111111111111' });
    if (secretOnly) {
        const credentials = await f.api('core/manualCredentialStore.js');
        const ref = await credentials.saveManualCredential('https://old.example/v1', currentKey);
        settings.updatePluginSettings({ manualApiKey: '', manualApiSecretRef: ref });
    }
    const nodes = new Map([
        ['[data-rmt-manual-api-base]', { value: base }],
        ['[data-rmt-manual-api-key]', { value: key, placeholder: '' }],
        ['[data-rmt-manual-api-model]', { value: 'fixture-model' }],
        ['[data-rmt-manual-save-status]', { textContent: '' }],
    ]);
    const root = { dataset: {}, querySelector: selector => nodes.get(selector) || null };
    const requests = [], statuses = [], timers = new Map();
    let clock = 0;
    f.sandbox.fetch = async (url, options) => {
        requests.push({ url, body: JSON.parse(options.body) });
        return new Response(JSON.stringify({ data: [{ id: 'fixture-model' }] }), { headers: { 'content-type': 'application/json' } });
    };
    const ui = vm.createContext({ core_settings: settings, core_text: text, settings_parts: parts, manualSaveTimer: 0, manualModels: [],
        sameChat: () => true, liveContext: () => f.host, status: message => statuses.push(message), render: () => {},
        setTimeout: callback => { timers.set(++clock, callback); return clock; }, clearTimeout: id => timers.delete(id) });
    vm.runInContext([
        functionSource('onManualInput', 'async function importOneClick('),
        functionSource('refreshWizardManualModels', 'function onChange('),
        functionSource('onClick', 'export function openAutoMemoryWizard('),
        'var lastRequest; const liveRefresh = refreshWizardManualModels; refreshWizardManualModels = (...args) => (lastRequest = liveRefresh(...args));',
    ].join('\n'), ui);
    const event = attribute => ({ target: { closest: selector => selector === '[data-rmt-auto-memory-root]' ? root : selector === attribute ? { dataset: {} } : null,
        matches: selector => selector.split(',').includes(attribute) } });
    return { f, settings, parts, root, nodes, requests, statuses,
        async clickRefresh() { ui.onClick(event('[data-rmt-auto-api-manual-refresh]')); await ui.lastRequest; },
        input() { ui.onManualInput(event('[data-rmt-manual-api-base]')); },
        async autosave() { const pending = [...timers.values()]; timers.clear(); for (const fn of pending) fn(); await Promise.resolve(); },
    };
}
function credential(request) { return JSON.parse(request.body.custom_include_headers || '{}').Authorization || ''; }

test('wizard URL edit before autosave never borrows the old key or secret reference', async () => {
    const f = await wizardFixture();
    f.input();
    await f.clickRefresh();
    assert.equal(f.requests.length, 1);
    assert.equal(f.requests[0].body.custom_url, 'https://new.example/v1');
    assert.equal(credential(f.requests[0]), '');
    assert.equal(f.settings.getPluginSettings().manualApiBaseUrl, 'https://old.example/v1');
});

test('wizard changed URL with an explicitly entered key uses that key', async () => {
    const f = await wizardFixture({ key: 'fixture-new-key' });
    await f.clickRefresh();
    assert.equal(f.requests.length, 1);
    assert.equal(f.requests[0].body.custom_url, 'https://new.example/v1');
    assert.equal(credential(f.requests[0]), 'Bearer fixture-new-key');
});

test('wizard same normalized URL retains its in-memory credential', async () => {
    const f = await wizardFixture({ base: 'https://old.example/v1/' });
    await f.clickRefresh();
    assert.equal(f.requests.length, 1);
    assert.equal(f.requests[0].body.custom_url, 'https://old.example/v1');
    assert.equal(credential(f.requests[0]), 'Bearer fixture-old-key');
});

test('wizard same URL can read its own encrypted credential after a reload', async () => {
    const f = await wizardFixture({ base: 'https://old.example/v1', secretOnly: true });
    await f.clickRefresh();
    assert.equal(f.requests.length, 1);
    assert.equal(credential(f.requests[0]), 'Bearer fixture-old-key');
});

test('wizard URL edit with only a saved secret reference does not read that old secret', async () => {
    const f = await wizardFixture({ secretOnly: true });
    await f.clickRefresh();
    assert.equal(f.requests.length, 1, 'a keyless endpoint is still allowed');
    assert.equal(f.requests[0].body.custom_url, 'https://new.example/v1');
    assert.equal(credential(f.requests[0]), '');
});

test('wizard blank URL cannot silently fall back to the old provider', async () => {
    const f = await wizardFixture({ base: '' });
    await f.clickRefresh();
    assert.equal(f.requests.length, 0);
    assert.equal(f.statuses.length, 1);
});

test('wizard autosave then refresh keeps the new keyless URL without old credentials', async () => {
    const f = await wizardFixture();
    f.input();
    await f.autosave();
    await f.clickRefresh();
    assert.equal(f.settings.getPluginSettings().manualApiBaseUrl, 'https://new.example/v1');
    assert.equal(f.settings.getPluginSettings().manualApiKey, '');
    assert.equal(f.settings.getPluginSettings().manualApiSecretRef, '');
    assert.equal(f.requests.length, 1);
    assert.equal(credential(f.requests[0]), '');
});

test('all valid persisted input budgets survive reads, saves and simulated reloads', async () => {
    const f = await preparationFixture();
    const settings = await f.api('core/settings.js');
    for (const value of [8000, 31999, 32000, '32000', 32001, 60000, 200000]) {
        f.host.extensionSettings.heartbeatMemories = { inputBudgetTokens: value };
        assert.equal(settings.getPluginSettings().inputBudgetTokens, Number(value), `existing ${value}`);
        settings.updatePluginSettings({ inputBudgetTokens: value });
        assert.equal(settings.getPluginSettings().inputBudgetTokens, Number(value), `saved ${value}`);
        f.host.extensionSettings = JSON.parse(JSON.stringify(f.host.extensionSettings));
        assert.equal(settings.getPluginSettings().inputBudgetTokens, Number(value), `reloaded ${value}`);
    }
});

test('a new explicit 32000 replaces the default while unset and invalid input budgets still default', async () => {
    const f = await preparationFixture();
    const settings = await f.api('core/settings.js');
    assert.equal(settings.getPluginSettings().inputBudgetTokens, 60000);
    assert.equal(settings.updatePluginSettings({ inputBudgetTokens: 32000 }).inputBudgetTokens, 32000);
    settings.updatePluginSettings({ temperature: 0.7 });
    assert.equal(settings.getPluginSettings().inputBudgetTokens, 32000);
    for (const value of [undefined, '', null, 0, 7999, 200001, 'invalid']) {
        f.host.extensionSettings.heartbeatMemories = { inputBudgetTokens: value };
        assert.equal(settings.getPluginSettings().inputBudgetTokens, 60000);
    }
});
