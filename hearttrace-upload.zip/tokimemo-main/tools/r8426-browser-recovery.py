"""Real Chromium DOM + actual old/new bundles; only synthetic host/provider/storage.
Cross-version fixture packages are supplied explicitly, never downloaded or modified.
Native IndexedDB must be tested separately: this harness does NOT prove native IDB.
"""
import argparse, json, pathlib, re, sys, time
from playwright.sync_api import sync_playwright
p=argparse.ArgumentParser();p.add_argument('--root');p.add_argument('--baseline',required=True);p.add_argument('--legacy',required=True);p.add_argument('--out',required=True)
a=p.parse_args();root=pathlib.Path(a.root).resolve() if a.root else pathlib.Path(__file__).resolve().parent.parent
base=pathlib.Path(a.baseline).resolve();legacy=pathlib.Path(a.legacy).resolve();out=pathlib.Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True)
result={'environment':'Real Chromium and bundled production DOM/event handlers. Synthetic host, provider, localStorage and IndexedDB backend. No real user data, credentials, network model calls or native IndexedDB transactions.','root':str(root),'baseline':str(base),'legacy':str(legacy),'cases':[],'pageErrors':[]}
def good(name,**data):
 result['cases'].append({'name':name,'pass':True,**data})
 (out/'progress.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
def bundle_host(r):
 b=re.sub(r'^export const .*;$','',(r/'dist/heartbeatMemories.bundle.js').read_text(),flags=re.M)
 h=(root/'tools/r8422-browser-host.mjs').read_text()
 h=re.sub(r"^import \* as (\w+) from '../src/([^']+)';$",lambda m:'const '+m[1]+' = __m_'+re.sub(r'[^A-Za-z0-9_$]','_',m[2])+';',h,flags=re.M)
 h=h.replace("import { state } from '../src/core/state.js';",'const state=__m_core_state_js.state;')
 h=h.replace("useCurrentChatExternalMemory: false, useActivatedWorldInfo: false","chatReadRange:{mode:'all'}, useCurrentChatExternalMemory: false, useActivatedWorldInfo: false")
 h=h.replace('const clone = value => structuredClone(value);', '''const clone = value => structuredClone(value);
const store=window.__fixtureStore;
backup.setArchiveBackupBackendForTests({read:async entry=>clone(store.backup[entry.entryId||context.archiveIndexEntryId(entry)]||null),put:async(record,expected,options={})=>{if(options.stillCurrent?.()===false)throw new DOMException('Changed','AbortError');const old=store.backup[record.entryId];if(expected?.present===true&&old&&old.archiveRevision!==expected.revision)throw new Error('Synthetic CAS');store.backup[record.entryId]=clone(record);return true;},delete:async()=>{throw new Error('No archive deletion');}});
ledger.setMemorySourceLedgerBackendForTests({read:async scope=>clone(store.ledger[scope.key]||null),write:async row=>{store.ledger[row.scope.key]=clone(row);return true;},delete:async()=>{throw new Error('No source deletion');}});
if(typeof __m_core_localRecoveryStore_js!=='undefined')__m_core_localRecoveryStore_js.setLocalRecoveryBackendForTests({read:async key=>{window.readCount=(window.readCount||0)+1;if(window.pauseReads)await new Promise(resolve=>(window.readReleases||=[]).push(resolve));if(window.failReads)throw new Error('Synthetic inaccessible storage');return clone(store.drafts[key]||null);},compare:async(key,revision,payload)=>{if(window.failWrites)throw new DOMException('Synthetic write failure','QuotaExceededError');window.writeCount=(window.writeCount||0)+1;const old=store.drafts[key];if((old?.revision||0)!==revision)throw new Error('Synthetic CAS');store.drafts[key]=clone({key,revision:revision+1,payload});return revision+1;}});
''')
 start=h.index("            const marker = 'EXTERNAL_MEMORY_JSON:")
 end=h.index('\n        },\n    },\n};',start)
 h=h[:start]+'''            const marker='UNTRUSTED_CHAT_JSON:\\n',pos=prompt.lastIndexOf(marker);
            const rows=pos>=0?JSON.parse(prompt.slice(pos+marker.length)):[];
            const kind=pos>=0?'chat':'profile';
            fixture.requests.push({kind,indices:rows.map(row=>row.messageIndex),chars:prompt.length,responseLength});
            localStorage.setItem('r8422-fixture-calls',JSON.stringify(fixture.requests));
            if(fixture.failRequestAt===fixture.requests.length)throw Object.assign(new Error('Synthetic failure'),{code:'RMT_JSON_INVALID'});
            if(kind==='profile')throw Object.assign(new Error('Synthetic profile failure kept separate from extraction'),{code:'RMT_JSON_INVALID'});
            return {content:JSON.stringify({memories:rows.slice(0,1).map(row=>({title:'庭院记录'+row.messageIndex,summary:'林舟与小月一起照看花草。'+row.text.slice(0,60),anchors:[row.text.slice(0,12)],participants:['林舟','小月'],messageStart:row.messageIndex,messageEnd:row.messageIndex}))})};''' +h[end:]
 # No external ledger sources. Preserve the one-floor seed bank; the other 1999
 # floors are genuinely new input. Stable deterministic raw text across bundles.
 start=h.index('        const rows = Array.from({ length: 610 }')
 end=h.index('        ctx.saveMetadataDebounced();',start)
 h=h[:start]+h[end:]
 h=h.replace('    overlay.openOverlay(); overlay.showChooser();', '''    ctx.chat.push(...Array.from({length:1999},(_,i)=>({is_user:i%2===0,name:i%2===0?ctx.name1:ctx.name2,mes:('第'+String(i+2).padStart(4,'0')+'次庭院记录：林舟与小月一起照看花草。'+'合成共同经历。'.repeat(100)).slice(0,600)})));
    overlay.openOverlay(); overlay.showChooser();''')
 h=h.replace('fixture.ctx = ctx; fixture.state = state;', '''fixture.ctx=ctx;fixture.state=state;
fixture.getRecovery=()=>R.getCurrentArchiveImportRecoverySummary(ctx);
fixture.currentBank=()=>R.getImportedMemory(ctx);
fixture.exportDraft=()=>R.exportCurrentArchiveImportProgress(ctx);
fixture.modules={R,D:__m_archive_importRecovery_js,overlay,context,workspace:__m_ui_workspaceState_js.workspace};
''')
 return b+'\n(async()=>{'+h+'})().catch(e=>window.fixtureError=String(e.stack))'
compiled={str(r):bundle_host(r) for r in [root,base,legacy]}
try:
 with sync_playwright() as pw:
  browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);result['browser']=browser.version
  bc=browser.new_context(viewport={'width':390,'height':844},accept_downloads=True);bc.route('**/*',lambda r:r.abort())
  def load(r,data=None,opts=None):
   page=bc.new_page();page.on('pageerror',lambda e:result['pageErrors'].append(str(e)))
   page.set_content('<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head><body></body></html>')
   page.evaluate('''([data,opts])=>{window.__fixtureStore=data;Object.assign(window,opts);Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>data.local[k]??null,setItem:(k,v)=>data.local[k]=String(v),removeItem:k=>delete data.local[k]}});}''',[data or {'local':{},'backup':{},'ledger':{},'drafts':{}},opts or {}])
   page.add_script_tag(type='module',content=compiled[str(r)])
   page.wait_for_function('window.fixture?.ready||window.fixtureError',timeout=30000)
   assert not page.evaluate('window.fixtureError||fixture.errors.join("\\n")'),page.evaluate('window.fixtureError||fixture.errors')
   return page
  def archive(page):
   page.locator('[data-rmt-workspace-tab="archive"]').first.click()
   if page.locator('[data-rmt-archive-recoveries]').count() and not page.evaluate('window.pauseReads||false'):
    page.wait_for_function('document.querySelector("[data-rmt-archive-recoveries]")?.getAttribute("aria-busy")==="false"',timeout=12000)
  def stage41(r):
   page=load(r);globals()['page']=page;archive(page);assert page.evaluate('fixture.ctx.chat.length')==2000
   page.evaluate('fixture.failRequestAt=42')
   page.locator('[data-rmt-action="current-archive-import"],[data-rmt-action="import-memory"]').first.click()
   page.wait_for_function('!fixture.state.busy && (fixture.requests.length>0 || fixture.notices.some(n=>n.kind==="error"))',timeout=90000)
   assert page.evaluate('fixture.getRecovery()?.completed')==41,page.evaluate('({notices:fixture.notices,summary:fixture.getRecovery(),calls:fixture.requests.length})')
   detail=page.evaluate('({summary:fixture.getRecovery(),calls:fixture.requests,plan:fixture.exportDraft().pageDrafts,bank:fixture.currentBank()})')
   assert len(detail['calls'])==42,detail['calls'][-3:]
   # Only brief structural counts in evidence; even synthetic full prompts stay out.
   plans=page.evaluate('fixture.exportDraft().pageDrafts.map(e=>({segments:Object.keys(e.journal.segments).length,inputKeys:Object.keys(e.inputs||{})}))')
   good('actual '+r.parent.name+' UI on 2000 floors -> 41 successes then explicit synthetic failure',completed=41,requests=42,pageOnly=detail['summary']['pageOnly'],plans=plans)
   return page
  # r84.25 persisted records -> new module/page: opening itself must display 41.
  page=stage41(base);saved=page.evaluate('__fixtureStore');bankBefore=page.evaluate('JSON.stringify(fixture.currentBank())');export25=page.evaluate('fixture.exportDraft()');page.close()
  page=load(root,saved);archive(page)
  banner=page.locator('[data-rmt-archive-recoveries]');assert '41 个成功分段' in banner.inner_text(),banner.inner_text()
  assert page.evaluate('fixture.requests.length')==42
  assert page.evaluate('JSON.stringify(fixture.currentBank())')==bankBefore
  good('r84.25 -> candidate fresh page: visible 41 immediately on archive open, zero new requests and unchanged formal bank')
  with page.expect_download() as download:
   page.locator('[data-rmt-archive-export-pending]').first.click()
  path=out/'synthetic-export.json';download.value.save_as(path);exported=json.loads(path.read_text());assert len(exported['pageDrafts'])>=1
  assert page.evaluate('fixture.requests.length')==42;good('actual export button reads restored draft and creates nonempty downloadable file')
  page.locator('[data-rmt-archive-read-drafts]').first.click();page.wait_for_timeout(100)
  assert page.evaluate('fixture.requests.length')==42;good('explicit read button does not spend generation requests')
  for width,theme in [(320,'default'),(375,'night'),(390,'night'),(430,'default'),(1280,'default')]:
   page.set_viewport_size({'width':width,'height':900 if width>500 else 844});page.evaluate('(mode)=>fixture.theme(mode)',theme);archive(page)
   box=page.locator('[data-rmt-archive-recoveries]').bounding_box();assert box and box['x']>=-1 and box['x']+box['width']<=width+1,(width,box)
   button=page.locator('[data-rmt-archive-recovery="import"]').first;button.scroll_into_view_if_needed();assert button.bounding_box()['height']>=42
   if width in (390,1280):page.screenshot(path=str(out/('mobile-dark.png' if width==390 else 'desktop-light.png')))
   good('recovered draft controls no horizontal overflow '+str(width)+'/'+theme)
  before=page.evaluate('fixture.requests.length');page.locator('[data-rmt-archive-recovery="import"]').first.click()
  page.wait_for_function('!fixture.state.busy && fixture.currentBank().memories.length===64',timeout=90000)
  calls=page.evaluate('fixture.requests');new=calls[before:];newchat=[c for c in new if c['kind']=='chat'];first41={tuple(c['indices']) for c in calls[:41]}
  assert len(newchat)==22,(len(newchat),new)
  assert not any(tuple(c['indices']) in first41 for c in newchat)
  allsuccess=calls[:41]+newchat;indices=[i for c in allsuccess for i in c['indices']];assert len(indices)==1999 and len(set(indices))==1999 and min(indices)==2 and max(indices)==2000,(len(indices),min(indices),max(indices))
  assert page.evaluate('fixture.currentBank().memories[0].id')=='M001'
  good('actual resume button: original plan 63, reuses 41, sends only remaining22, no tail missing; separate profile attempt',remainingExtraction=len(newchat),profileAttempts=sum(c['kind']=='profile' for c in new),formalMemories=64,coveredNewFloors=len(indices))
  page.close()
  # r84.24 page-only -> actual old export -> actual import file chooser.
  old=stage41(legacy);oldExport=old.evaluate('fixture.exportDraft()');oldStore=old.evaluate('__fixtureStore');old.close()
  page=load(root,oldStore);archive(page);assert not page.evaluate('fixture.getRecovery()');assert page.evaluate('fixture.requests.length')==42
  good('r84.24 lost RAM with no persisted record is NOT falsely presented as recoverable')
  with page.expect_file_chooser() as chooser:page.locator('[data-rmt-archive-import-draft]').first.click()
  chooser.value.set_files({'name':'hearttrace-unarchived-results.json','mimeType':'application/json','buffer':json.dumps(oldExport,ensure_ascii=False).encode()})
  page.wait_for_function('fixture.getRecovery()?.completed===41',timeout=15000)
  assert page.evaluate('fixture.requests.length')==42
  store=page.evaluate('__fixtureStore');page.close();page=load(root,store);archive(page)
  assert '41 个成功分段' in page.locator('[data-rmt-archive-recoveries]').inner_text()
  good('r84.24 real exported draft -> actual file import -> new page opens visible41, no model request')
  before=page.evaluate('fixture.requests.length');page.locator('[data-rmt-archive-recovery="import"]').first.click()
  page.wait_for_function('!fixture.state.busy && fixture.currentBank().memories.length===64',timeout=90000)
  new=page.evaluate('fixture.requests')[before:];assert len([x for x in new if x['kind']=='chat'])==22
  good('legacy imported source/request checks pass on original sources; only22 missing fragments requested')
  page.close()
  # Actual failed import save leaves page successes available for export/save.
  page=load(root,oldStore,{'failWrites':True});archive(page)
  with page.expect_file_chooser() as chooser:page.locator('[data-rmt-archive-import-draft]').first.click()
  chooser.value.set_files({'name':'hearttrace-unarchived-results.json','mimeType':'application/json','buffer':json.dumps(oldExport,ensure_ascii=False).encode()})
  page.wait_for_function('fixture.notices.some(n=>n.kind==="error")',timeout=15000)
  page.locator('[data-rmt-archive-read-drafts]').first.click()
  page.wait_for_function('fixture.getRecovery()?.completed===41 && document.querySelector("[data-rmt-archive-save-draft]")')
  assert page.evaluate('fixture.getRecovery().pageOnly')
  with page.expect_download() as download:page.locator('[data-rmt-archive-export-pending]').first.click()
  download.value.save_as(out/'synthetic-page-only-export.json')
  assert json.loads((out/'synthetic-page-only-export.json').read_text())['pageDrafts']
  assert page.evaluate('fixture.requests.length')==42
  good('actual failed import save retains41 in page; actual export button still works without model')
  page.evaluate('window.failWrites=false');page.locator('[data-rmt-archive-save-draft]').first.click()
  page.wait_for_function('fixture.getRecovery()?.pageOnly===false',timeout=15000)
  recoveredStore=page.evaluate('__fixtureStore');page.close();page=load(root,recoveredStore);archive(page)
  assert '41 个成功分段' in page.locator('[data-rmt-archive-recoveries]').inner_text()
  assert page.evaluate('fixture.requests.length')==42;good('actual save-page-draft button -> store acknowledgement -> fresh page displays41, zero model calls');page.close()
  # Same record, failed storage read must preserve and retry with no generation.
  page=load(root,saved,{'failReads':True});archive(page);assert '本机草稿读取未完成' in page.locator('[data-rmt-archive-recoveries]').inner_text()
  assert page.evaluate('__fixtureStore.drafts')==saved['drafts'];page.evaluate('window.failReads=false');page.locator('[data-rmt-archive-read-drafts]').first.click()
  page.wait_for_function('document.querySelector("[data-rmt-archive-recoveries]")?.textContent.includes("41 个成功分段")')
  assert page.evaluate('fixture.requests.length')==42;good('storage read error visible; real retry restores41 without deleting records or generating');page.close()
  # Late read must not replace settings after navigating away.
  page=load(root,saved,{'pauseReads':True});page.locator('[data-rmt-workspace-tab="archive"]').first.click();page.locator('[data-rmt-workspace-tab="settings"]').first.click()
  page.evaluate('window.pauseReads=false; for(const resolve of window.readReleases||[])resolve();');page.wait_for_timeout(150)
  assert page.locator('[data-rmt-settings-section="api"]').count()>0
  assert page.locator('[data-rmt-archive-recoveries]').count()==0
  assert page.evaluate('fixture.requests.length')==42;good('late stored-draft read cannot replace settings after real navigation');page.close()
  assert not result['pageErrors'],result['pageErrors'];good('no unhandled browser errors')
  browser.close();result.update(passed=len(result['cases']),failed=0)
except Exception as e:
 result.update(failed=1,error=str(e))
 try:page.screenshot(path=str(out/'failure.png'));(out/'failure.html').write_text(page.content());result['state']=page.evaluate('({notices:fixture.notices,errors:fixture.errors,calls:fixture.requests.map(x=>({kind:x.kind,start:x.indices?.[0],end:x.indices?.at(-1)})),draft:fixture.getRecovery()})')
 except Exception:pass
 raise
finally:
 (out/'browser-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
