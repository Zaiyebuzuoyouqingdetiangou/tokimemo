"""Real Chromium + bundled UI. Synthetic ST, provider, durable storage only.
Uses the supplied prior bundle to CREATE failed/partially successful tasks, then
loads the candidate in a fresh page. Canonical storage and metadata are carried
across. Optional legacy target omissions are separately labelled mutation probes.
Never reads user data or contacts model endpoints.
"""
import argparse,json,pathlib,re
from playwright.sync_api import sync_playwright
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--baseline',required=True);p.add_argument('--out',required=True);a=p.parse_args()
root=pathlib.Path(a.root).resolve();base=pathlib.Path(a.baseline).resolve();out=pathlib.Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True)
result={'root':str(root),'baseline':str(base),'environment':'Actual Chromium and bundles; synthetic host, provider and storage. NO native TT/IndexedDB or paid requests.','cases':[],'pageErrors':[]}
def good(name,**details):result['cases'].append({'name':name,'pass':True,**details})
def source(folder):
 bundle=re.sub(r'^export const .*;$','',(folder/'dist/heartbeatMemories.bundle.js').read_text(),flags=re.M)
 host=(folder/'tools/r8422-browser-host.mjs').read_text()
 host=re.sub(r"^import \* as (\w+) from '../src/([^']+)';$",lambda m:'const '+m[1]+' = __m_'+re.sub(r'[^A-Za-z0-9_$]','_',m[2])+';',host,flags=re.M)
 host=host.replace("import { state } from '../src/core/state.js';",'const state=__m_core_state_js.state;')
 host=host.replace('const clone = value => structuredClone(value);', '''const clone = value => structuredClone(value);
const store=window.__fixtureStore;
backup.setArchiveBackupBackendForTests({read:async entry=>clone(store.backup[entry.entryId||context.archiveIndexEntryId(entry)]||null),
put:async(record,expected,options={})=>{if(options.stillCurrent?.()===false)throw new DOMException('Changed','AbortError');const old=store.backup[record.entryId];if(expected?.present===true&&old&&old.archiveRevision!==expected.revision)throw new Error('synthetic CAS');store.backup[record.entryId]=clone(record);return true;},delete:async()=>{throw new Error('No archive deletion');}});
ledger.setMemorySourceLedgerBackendForTests({read:async scope=>clone(store.ledger[scope.key]||null),write:async row=>{store.ledger[row.scope.key]=clone(row);return true;},delete:async()=>{throw new Error('No source deletion');}});
__m_core_localRecoveryStore_js.setLocalRecoveryBackendForTests({read:async key=>clone(store.drafts[key]||null),compare:async(key,revision,payload)=>{const old=store.drafts[key];if((old?.revision||0)!==revision)throw new Error('synthetic CAS');store.drafts[key]=clone({key,revision:revision+1,payload});return revision+1;}});
''')
 start=host.index("            const marker = 'EXTERNAL_MEMORY_JSON:")
 end=host.index('\n        },\n    },\n};',start)
 host=host[:start]+'''            let kind='unknown',value={};
            if(prompt.includes('LOCAL_MAIL_PLAN:')){
              kind='inbox';const plan=JSON.parse(prompt.split('LOCAL_MAIL_PLAN:\\n').pop().split('\\nUNTRUSTED_RELATIONSHIP_ARCHIVE:')[0]);
              value={letters:plan.map(x=>({slot:x.slot,title:'窗边的花',greeting:'小月：',body:'窗边的花开得正好。我想在忙完之后沿着小路散步，看看今晚的风会把花香带向哪里。',closing:'林舟'}))};
            }else if(prompt.includes('Voice Drama')) {kind='voice';value={voiceDramas:[{id:'VO',kind:'spring',title:'窗边的花',setting:'日常模拟',script:fixture.script()}]};}
            else if(prompt.includes('Scenario Drama')){kind='scenario';value={scenarioDramas:[{id:'SC',season:'spring',title:'小院子',setting:'日常模拟',script:fixture.script()}]};}
            else {kind='language';value={relationshipState:'自然相处',relationshipSummary:'彼此倾听',greetings:{morning:['早安，窗边的花开了。']}};}
            fixture.requests.push({kind,chars:prompt.length,responseLength});localStorage.setItem('r8422-fixture-calls',JSON.stringify(fixture.requests));
            if(fixture.failKinds?.includes(kind)) throw Object.assign(new Error('synthetic request refusal'),{code:'RMT_MANUAL_HTTP',status:400});
            return {content:JSON.stringify(value)};''' + host[end:]
 start=host.index('        const rows = Array.from(');end=host.index('        ctx.saveMetadataDebounced();',start)
 host=host[:start]+host[end:]
 host=host.replace('fixture.ctx = ctx; fixture.state = state;', '''fixture.ctx = ctx; fixture.state = state;
fixture.script=()=>Array.from({length:8},()=>({speaker:'char',text:'我把手里的书放回原处，接着走向窗边。此刻想与你说说院子里新开的花，也想听你慢慢说今天的小事。'.repeat(3)}));
fixture.open=async mode=>{await overlay.openCachedOrGenerate(mode);};
fixture.openLanguage=async()=>{await overlay.openCachedOrGenerate('heart',{workspaceRoute:'language'});__m_ui_languageView_js.renderLanguage();};
fixture.openHeart=async()=>{await overlay.openCachedOrGenerate('heart');__m_ui_heartView_js.renderHeart();};
fixture.engine={R,G:__m_generation_recovery_js,client:__m_generation_client_js,cache:__m_core_cache_js,context,settings};
fixture.journal=mode=>__m_core_cache_js.loadGenerationRecovery(mode,ctx);
fixture.bank=()=>R.getImportedMemory(ctx);
fixture.summary=()=>({bank:fixture.bank(),inbox:__m_core_cache_js.loadSession('inbox',{context:ctx,memoryBank:fixture.bank(),chatId:ctx.chatId,clone:true}),heart:__m_core_cache_js.loadSession('heart',{context:ctx,memoryBank:fixture.bank(),chatId:ctx.chatId,clone:true}),requests:fixture.requests,notices:fixture.notices,trace:trace.taskTraceSnapshot()});
fixture.legacyTarget=async mode=>{const journal=fixture.journal(mode),bank=fixture.bank();if(!journal)throw new Error('No journal');journal.identity.archiveTargetEntryId='';delete journal.inputSnapshotVersion;const origin=context.captureTaskOrigin(ctx,bank.archiveRevision);const saved=await __m_core_cache_js.saveGenerationRecovery(ctx,bank,mode,journal,origin);if(!saved)throw new Error('No acknowledgement');return journal;};
''')
 return bundle+'\n(async()=>{'+host+'})().catch(e=>window.fixtureError=String(e.stack))'
def idle(page):
 page.wait_for_function('!fixture.state.busy && fixture.state.activeModeBuildScopes.size===0',timeout=20000)
try:
 with sync_playwright() as pw:
  browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);result['browser']=browser.version
  bc=browser.new_context(viewport={'width':390,'height':844},accept_downloads=True);bc.route('**/*',lambda route:route.abort())
  def load(folder,data=None):
   page=bc.new_page();page.on('pageerror',lambda e:result['pageErrors'].append(str(e)))
   page.set_content('<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head><body></body></html>')
   page.evaluate('''data=>{window.__fixtureStore=data;Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>data.local[k]??null,setItem:(k,v)=>{data.local[k]=String(v)},removeItem:k=>{delete data.local[k]}}});}''',data or {'local':{},'backup':{},'ledger':{},'drafts':{}})
   page.add_script_tag(type='module',content=source(folder));page.wait_for_function('window.fixture?.ready||window.fixtureError',timeout=25000)
   assert not page.evaluate('window.fixtureError||fixture.errors.join("\\n")'),page.evaluate('window.fixtureError||fixture.errors')
   return page
  def clickWait(page,selector):
   n=page.evaluate('fixture.requests.length');page.locator(selector).first.click();page.wait_for_timeout(180);idle(page);return n
  # Baseline genuinely creates the journal from the real inbox receive button.
  old=load(base);old.evaluate("fixture.failKinds=['inbox']");old.evaluate("fixture.open('inbox')")
  clickWait(old,'[data-rmt-inbox="receive"]');j=old.evaluate("fixture.journal('inbox')");assert j and j['segments'] and not any(x['state']=='complete' for x in j['segments']);bank=old.evaluate('fixture.bank()')
  good('supplied prior bundle creates a retry journal through actual inbox Receive button',requests=old.evaluate('fixture.requests.length'))
  normal=old.evaluate('window.__fixtureStore');new=load(root,normal);n=new.evaluate('fixture.requests.length');new.evaluate("fixture.open('inbox')");assert new.evaluate('fixture.requests.length')==n
  clickWait(new,'[data-rmt-inbox="receive"]');s=new.evaluate('fixture.summary()');assert s['inbox']['letters'] and s['bank']==bank and len(s['requests'])==n+1
  good('unmodified old inbox journal -> candidate actual Receive -> request and commit, same archive',additionalRequests=1)
  new.close()
  old.evaluate("fixture.legacyTarget('inbox')");legacy=old.evaluate('window.__fixtureStore');n=old.evaluate('fixture.requests.length');old.close()
  probe=load(base,legacy);probe.evaluate("fixture.open('inbox')");clickWait(probe,'[data-rmt-inbox="receive"]');snap=probe.evaluate('fixture.summary()');assert len(snap['requests'])==n and snap['trace'][-1]['code']=='RMT_RECOVERY_INPUT_CHANGED'
  good('separately labelled schema-valid optional-field omission reproduces baseline zero-request rejection')
  probe.close();new=load(root,legacy);new.evaluate("fixture.open('inbox')");clickWait(new,'[data-rmt-inbox="receive"]');s=new.evaluate('fixture.summary()');assert len(s['requests'])==n+1 and s['inbox']['letters'] and s['bank']==bank
  good('same canonical legacy record -> candidate Receive accepts missing optional target without dropping guards',additionalRequests=1)
  new.close()
  # Real basic-language entry rather than direct lower-level recovery calls.
  old=load(base);old.evaluate("fixture.openLanguage()");old.evaluate("fixture.failKinds=['language']");clickWait(old,'[data-rmt-action="heart-add-language"]');assert old.evaluate("!!fixture.journal('heart')")
  old.evaluate("fixture.legacyTarget('heart')");data=old.evaluate('window.__fixtureStore');n=old.evaluate('fixture.requests.length');old.close()
  new=load(root,data);new.evaluate('fixture.openLanguage()');clickWait(new,'[data-rmt-action="heart-add-language"]');s=new.evaluate('fixture.summary()');assert s['heart']['greetings']['morning'] and len(s['requests'])==n+1
  good('basic language actual Generate Current Category -> old journal -> candidate button -> validated commit')
  new.close()
  # Two independently committed seasonal siblings: actual old button -> one
  # success/one failure -> fresh candidate -> only the missing sibling is sent.
  old=load(base);old.evaluate("fixture.openHeart()");old.evaluate("fixture.failKinds=['scenario']")
  clickWait(old,'[data-rmt-action="heart-generate-season"]');before=old.evaluate('fixture.summary()');j=old.evaluate("fixture.journal('heart')")
  assert j and j['operation']['kind']=='heart-season' and len(before['heart']['voiceDramas'])==1 and len(before['heart']['scenarioDramas'])==0, before
  old.evaluate("fixture.legacyTarget('heart')");data=old.evaluate('window.__fixtureStore');n=old.evaluate('fixture.requests.length');old.close()
  new=load(root,data);new.evaluate('fixture.openHeart()');clickWait(new,'[data-rmt-action="heart-generate-season"]');after=new.evaluate('fixture.summary()')
  assert len(after['requests'])==n+1 and after['requests'][-1]['kind']=='scenario' and after['heart']['voiceDramas']==before['heart']['voiceDramas'] and len(after['heart']['scenarioDramas'])==1, after
  good('actual old seasonal button -> voice saved/scenario failed -> upgraded button sends only scenario; voice unchanged',additionalRequests=1)
  new.close()
  # Explicit source change must preserve the old journal and block before charging.
  old=load(base);old.evaluate("fixture.open('inbox')");old.evaluate("fixture.failKinds=['inbox']");clickWait(old,'[data-rmt-inbox="receive"]');data=old.evaluate('window.__fixtureStore');old.close()
  new=load(root,data);new.evaluate("fixture.ctx.powerUserSettings.persona_description+='新的明确设定';fixture.open('inbox')")
  prior=new.evaluate("fixture.journal('inbox')");n=clickWait(new,'[data-rmt-inbox="receive"]');s=new.evaluate('fixture.summary()');assert len(s['requests'])==n and s['trace'][-1]['recovery']=={'phase':'source','category':'persona'}
  assert new.evaluate("fixture.journal('inbox')")==prior;assert any('Persona' in x['message'] for x in s['notices'])
  good('true Persona change is categorized before any request; prior journal preserved')
  # Real download button after user navigates to the archive, no model activity.
  new.evaluate('fixture.reopen()');new.locator('[data-rmt-workspace-tab="archive"]').first.click();new.wait_for_timeout(180)
  export=new.locator('[data-rmt-recovery-export="inbox"]').first;assert export.count()==1
  with new.expect_download() as info:export.click()
  download=info.value;dest=out/'synthetic-module-recovery.json';download.save_as(str(dest));ej=json.loads(dest.read_text());assert ej['journal']['identity']['mode']=='inbox';assert new.evaluate('fixture.requests.length')==n
  good('actual module-draft export download retains old recipe, performs zero requests',filename=download.suggested_filename)
  new.evaluate("fixture.theme('night')");new.locator('[data-rmt-workspace-tab=\"archive\"]').first.click();new.wait_for_timeout(120)
  assert new.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
  new.screenshot(path=str(out/'mobile-dark.png'));new.set_viewport_size({'width':1280,'height':900});new.screenshot(path=str(out/'desktop-light.png'));good('real mobile/desktop DOM recovery controls render and export remains actionable')
  new.close();browser.close()
 assert not result['pageErrors'],result['pageErrors'];result['passed']=len(result['cases'])
except Exception as error:
 result['error']=str(error);raise
finally:(out/'browser-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False,indent=2))
