import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { preparationFixture } from './preparation-harness-r8481.mjs';
import { relayIndexedDB } from './relay-idb-fixture.mjs';

const plain = value => JSON.parse(JSON.stringify(value));
async function setup({ legacy = false } = {}) {
    const f = await preparationFixture({ hostOverrides: { chatId: 'A', saveMetadataDebounced: async () => {} } });
    f.sandbox.Blob = Blob; f.sandbox.indexedDB = relayIndexedDB();
    vm.runInContext('structuredClone = v => v === undefined ? undefined : JSON.parse(JSON.stringify(v))', f.sandbox);
    const backup = await f.api('archive/backupStore.js'); backup.setArchiveBackupBackendForTests(null);
    const cache = await f.api('core/cache.js'), groups = await f.api('archive/groups.js');
    const relay = await f.api('archive/relay.js'), policy = await f.api('core/archiveRelayPolicy.js');
    const constants = await f.api('core/constants.js'), records = await f.api('core/cacheRecords.js');
    const memory = { version: 3, chatId: 'A', archiveRevision: 'ra', characterName: '岚', userName: '阿宁',
        sourceMessageCount: 1, sourceFingerprint: 'prefix-A',
        memories: [{ id: 'M100', title: '书页', summary: '一起读书', anchors: ['书'], messageStart: 1, messageEnd: 1 }] };
    const aCache = { chatId: 'A', archiveRevision: 'ra', updatedAt: 1,
        album: { kind: 'album', chatId: 'A', archiveRevision: 'ra', entries: [{ id: 'AL1', title: '书页', desc: '一起读书', cgImage: { url: '/user/images/kept.png' } }] },
        __archiveVersionsV1: { version: 1, records: [] } };
    f.host.chatMetadata[constants.MEMORY_KEY] = memory;
    f.host.chatMetadata[constants.CACHE_KEY] = aCache;
    groups.upsertArchiveIndex(f.host, memory);
    const aEntry = groups.getArchiveIndex(f.host).find(row => row.chatId === 'A');
    const durableA = { ...aEntry, ...(legacy ? { entryId: 'legacy-A' } : {}) };
    await backup.seedArchiveBackup(durableA, memory, aCache);
    const mirrors = { A: f.host.chatMetadata };
    const switchTo = (chatId, metadata = mirrors[chatId] || {}) => {
        f.host.chatId = chatId; f.host.chatMetadata = metadata; mirrors[chatId] = metadata;
        f.state.runtimeSessionCache.clear(); f.state.pendingCompressedCacheWrites.clear();
    };
    const loadSnapshot = async entry => {
        const stored = await backup.readArchiveBackupState(entry);
        return { ...entry, memory: stored.record.memory, cache: stored.record.cache, backupOnly: false };
    };
    switchTo('B');
    return { f, backup, cache, groups, relay, policy, constants, records, memory, aCache, aEntry, mirrors, switchTo, loadSnapshot };
}

test('public preview/commit preserves actual readers; handback works with versions and a failed host mirror', async () => {
    const x = await setup();
    const preview = await x.relay.previewArchiveRelay(x.aEntry.entryId, { loadSnapshot: x.loadSnapshot });
    assert.equal(preview.occupied, false);
    x.f.host.saveMetadataDebounced = async () => { throw new Error('Host mirror unavailable'); };
    const result = await x.relay.commitArchiveRelay(preview);
    assert.equal(result.status, 'committed'); assert.equal(result.mirrorQueued, false);
    const b = x.f.host.chatMetadata[x.constants.MEMORY_KEY];
    assert.equal(b.chatId, 'B'); assert.equal(b.memories[0].id, 'M100');
    assert.equal(x.cache.loadSession('album').entries[0].cgImage.url, '/user/images/kept.png');
    const bEntry = x.cache.archiveBackupEntryForContext(x.f.host, b);
    const bCache = await x.records.hydrateBackupCacheValue(result.record.cache, 'B', b.archiveRevision);
    bCache.extraReadingState = 'holder can save'; x.cache.stampCacheCommit(bCache, 'test-B');
    await x.backup.updateArchiveBackupCache(bEntry, b, bCache);
    x.switchTo('A');
    await x.cache.ensureCurrentArchiveBackup(x.f.host);
    assert.equal(x.policy.relayReadOnly(x.aEntry), true);
    // Frozen source opening must not run the normal version/draft reconciliation writer.
    assert.equal(x.cache.loadSession('album').entries[0].id, 'AL1');
    const back = await x.relay.previewArchiveRelay(bEntry.entryId, { loadSnapshot: async () => { throw new Error('Must use committed local holder'); } });
    assert.equal(back.returning, true); assert.equal(back.occupied, false);
    await x.relay.commitArchiveRelay(back);
    assert.equal(x.policy.relayReadOnly(x.aEntry), false);
    assert.equal(x.f.host.chatMetadata[x.constants.MEMORY_KEY].memories[0].id, 'M100');
    assert.equal(x.f.providerCalls, 0);
});

test('legacy durable key is resolved through the public preview before atomic handoff', async () => {
    const x = await setup({ legacy: true });
    const preview = await x.relay.previewArchiveRelay(x.aEntry.entryId, { loadSnapshot: x.loadSnapshot });
    assert.equal(preview.sourceEntry.entryId, 'legacy-A');
    await x.relay.commitArchiveRelay(preview);
    assert.equal((await x.backup.readArchiveBackupState(x.aEntry)).record.entryId, 'legacy-A');
    assert.equal(x.f.host.chatMetadata[x.constants.MEMORY_KEY].chatId, 'B');
});

test('preview is invalidated by target edits or chat switching without altering either archive', async () => {
    for (const switchChat of [false, true]) {
        const x = await setup(), preview = await x.relay.previewArchiveRelay(x.aEntry.entryId, { loadSnapshot: x.loadSnapshot });
        const before = plain([...x.f.sandbox.indexedDB.rows]);
        if (switchChat) x.switchTo('C');
        else x.f.host.chatMetadata[x.constants.CACHE_KEY] = { kept: 'new target content' };
        await assert.rejects(x.relay.commitArchiveRelay(preview), /变化|切换/);
        assert.deepEqual(plain([...x.f.sandbox.indexedDB.rows]), before);
    }
});

test('target with its own archive stays intact until explicit replacement; checkpoint keeps both versions', async () => {
    const x = await setup();
    const oldB = { ...plain(x.memory), chatId: 'B', archiveRevision: 'own-B', memories: [{ id: 'M001', title: 'B自己的', summary: '保留' }] };
    x.f.host.chatMetadata[x.constants.MEMORY_KEY] = oldB;
    const preview = await x.relay.previewArchiveRelay(x.aEntry.entryId, { loadSnapshot: x.loadSnapshot });
    assert.equal(preview.occupied, true);
    await assert.rejects(x.relay.commitArchiveRelay(preview), /先导出/);
    assert.deepEqual(plain(x.f.host.chatMetadata[x.constants.MEMORY_KEY]), oldB);
    const result = await x.relay.commitArchiveRelay(preview, { replaceTarget: true });
    const stored = await (await x.f.api('archive/relayStore.js')).readRelayCheckpoint(result.transferId);
    assert.equal(stored.before.memory.memories[0].id, 'M100');
    assert.equal(stored.targetBefore.memory.memories[0].title, 'B自己的');
});

test('committed holder can be found and recovered even if host index or mirror was not saved', async () => {
    const x = await setup();
    const preview = await x.relay.previewArchiveRelay(x.aEntry.entryId, { loadSnapshot: x.loadSnapshot });
    const result = await x.relay.commitArchiveRelay(preview);
    x.groups.setArchiveIndex(x.f.host, x.groups.getArchiveIndex(x.f.host).filter(row => row.chatId === 'A'));
    x.switchTo('A');
    const candidates = await x.relay.relayCandidates();
    assert.equal(candidates[0].chatId, 'B');
    const back = await x.relay.previewArchiveRelay(candidates[0].entryId, { loadSnapshot: async () => { throw new Error('Host absent'); } });
    assert.equal(back.source.memory.archiveRevision, result.record.archiveRevision);
    x.switchTo('B', {});
    await x.cache.ensureCurrentArchiveBackup(x.f.host);
    assert.equal(x.f.host.chatMetadata[x.constants.MEMORY_KEY].archiveRevision, result.record.archiveRevision);
    assert.equal(x.cache.loadSession('album').entries[0].id, 'AL1');
});
