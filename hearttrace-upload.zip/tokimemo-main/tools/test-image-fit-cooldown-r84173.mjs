// r84.173 · 图片完整显示（不裁、不留大白边）；历史版本切换放到图片下面、变小；
// 兔子菜单在包图的框外、紧贴图片右下；心跳四格和相簿卡片也收进兔子；自动留忆加冷却。
import test from 'node:test';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { preparationFixture } from './preparation-harness-r8481.mjs';

const read = file => readFile(new URL(file, import.meta.url), 'utf8');

test('冷却：上一轮刚抽到的模块这一轮不抽；只剩它一个时照常抽', async () => {
    const f = await preparationFixture();
    const draw = await f.api('autoMemory/draw.js');
    const copy = value => vm.runInContext(`JSON.parse(${JSON.stringify(JSON.stringify(value))})`, f.sandbox);
    const tickets = copy([{ selectedModuleId: 'album', candidates: [{ id: 'album' }, { id: 'pastLives' }] },
        { selectedModuleId: 'pastLives', candidates: [{ id: 'album' }, { id: 'pastLives' }] }]);
    const weighted = draw.weightCandidates(copy(['album', 'pastLives']), tickets);
    assert.ok(weighted.every(item => item.weight >= 1), '记录里的权重仍 ≥1');
    const cooled = draw.cooledCandidates(weighted, tickets);
    assert.deepEqual([...cooled.map(item => item.id)], ['album']);
    for (const roll of [0, 0.5, 0.99]) assert.equal(draw.pickWeighted(cooled, () => roll), 'album');
    const only = draw.cooledCandidates(draw.weightCandidates(copy(['pastLives']), tickets), tickets);
    assert.deepEqual([...only.map(item => item.id)], ['pastLives']);
    const withNoop = copy([...JSON.parse(JSON.stringify(tickets)), { selectedModuleId: '', candidates: [] }]);
    assert.deepEqual([...draw.cooledCandidates(weighted, withNoop).map(item => item.id)], ['album'], '空轮不打断冷却');
    const gate = await read('../src/autoMemory/incrementalGate.js');
    assert.match(gate, /pickWeighted\(auto_memory_draw\.cooledCandidates\(weighted, snapshot\.drawTickets\)/);
});

test('久未抽到的加权从上次抽中之后算，抽中后清零', async () => {
    const f = await preparationFixture();
    const draw = await f.api('autoMemory/draw.js');
    const copy = value => vm.runInContext(`JSON.parse(${JSON.stringify(JSON.stringify(value))})`, f.sandbox);
    const both = [{ id: 'album' }, { id: 'pastLives' }];
    const tickets = copy([...Array(6)].map(() => ({ selectedModuleId: 'album', candidates: both }))
        .concat([{ selectedModuleId: 'pastLives', candidates: both }, { selectedModuleId: 'album', candidates: both }]));
    const pastLives = draw.weightCandidates(copy(['pastLives']), tickets)[0];
    assert.equal(pastLives.weight, 100 / 2 + 25, '只算上次抽中之后错过的 1 轮');
});

test('图片完整显示：图框跟着图片的比例，不裁切；历史切换在图片下面、变小', async () => {
    const menu = await read('../src/ui/imageMenu.js');
    assert.match(menu, /\.rmt-body \.rmt-expanded-cg \.rmt-thumb\{aspect-ratio:auto;height:auto;max-height:none/);
    assert.match(menu, /\.rmt-expanded-cg \.rmt-thumb \.rmt-cg-real\{position:relative;inset:auto;display:block;width:100%;height:auto;max-height:80vh/);
    const ws = await read('../src/ui/workspaceStyles.js');
    assert.match(ws, /\.rmt-cg-history-controls\{position:relative;inset:auto;/);
    assert.equal(/\.rmt-cg-history-controls\{position:absolute/.test(ws), false);
    assert.match(ws, /\.rmt-cg-history-controls button\{[^}]*min-height:32px/);
});

test('兔子在包图的框外：睡前故事只把图片包进绘本页；光栅卡的兔子紧贴图片下方', async () => {
    const bed = await read('../src/ui/bedtimeView.js');
    assert.match(bed, /bedtimePlate\(expanded_cg_view\.expandedCgImageHtml\(/);
    assert.match(bed, /expanded_cg_view\.expandedCgHtml\(session, \{kind:'bedtime-chapter'[^)]*\}, locked, \{ showImage: false/);
    const card = await read('../src/ui/pastLivesCard.js');
    assert.ok(card.indexOf('image_menu.imageMenuHtml(') < card.indexOf('<figcaption>'), '兔子在滑杆和说明文字之前');
});

test('心跳四格和相簿卡片的图片操作也收进兔子', async () => {
    const heart = await read('../src/ui/heartView.js');
    assert.match(heart, /image_menu\.imageMenuHtml\(`\$\{image \? '<button type="button" class="rmt-btn" data-rmt-action="view-heart-cg">查看完整原图<\/button>'/);
    assert.equal(heart.includes('<div class="rmt-heart-strip-actions">'), false);
    const album = await read('../src/ui/albumView.js');
    assert.match(album, /rmt-album-card-actions/);
    assert.match(album, /image_menu\.imageMenuHtml\(`<button type="button" class="rmt-btn" data-rmt-album-prompt=/);
});
