// r84.174 · 手帐第一包：一次一页翻看、按月份 / 收藏筛选、便签、装饰；不常用的收进 ⋯。
// 收藏和便签是可选字段：旧页、旧备份照常读；导入备份时只按内容判断是不是同一页。
import vm from 'node:vm';
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { preparationFixture } from './preparation-harness-r8481.mjs';

function fakeIndexedDB() {
    let saved;
    return { open() { const request = {}; queueMicrotask(() => { request.result = { objectStoreNames: { contains: () => true }, close() {}, transaction() { const tx = { objectStore() { return { get() { const r = {}; setTimeout(() => { r.result = saved; r.onsuccess(); setTimeout(() => tx.oncomplete?.(), 0); }, 0); return r; }, put(value) { saved = JSON.parse(JSON.stringify(value)); } }; }, abort() { tx.onabort?.(); } }; return tx; } }; request.onsuccess(); }); return request; } };
}

test('收藏、便签可存可删，改标题和配色不丢；旧页没有这两个字段', async () => {
    const f = await preparationFixture();
    const j = await f.api('core/handJournal.js');
    const store = j.createJournalStore({ indexedDB: fakeIndexedDB(), currentScope: () => 'chat' });
    await store.append('chat', [j.createJournalPage({ id: 'p1', createdAt: 1, title: '雨夜', entries: [] })]);
    await store.favorite('chat', 'p1', true);
    await store.notes('chat', 'p1', [{ id: 'n1', text: '那天的篝火好暖。' }, { id: 'n2', text: '   ' }]);
    await store.rename('chat', 'p1', '庙檐下');
    await store.palette('chat', 'p1', { id: 'sky', paper: '#e1eefa', ink: '#234567', accent: '#89abcd' });
    let page = (await store.read('chat'))[0];
    assert.equal(page.favorite, true);
    assert.deepEqual(JSON.parse(JSON.stringify(page.notes)), [{ id: 'n1', text: '那天的篝火好暖。' }], '空便签不保存');
    assert.equal(page.title, '庙檐下');
    await store.favorite('chat', 'p1', false);
    await store.notes('chat', 'p1', []);
    page = (await store.read('chat'))[0];
    assert.equal('favorite' in page, false);
    assert.equal('notes' in page, false);
    const old = j.createJournalPage({ id: 'old', createdAt: 1, title: '旧页', entries: [] });
    assert.equal('favorite' in old || 'notes' in old, false);
});

test('导出再导入：收藏和便签跟着走；本机已收藏的页再导入旧备份不报冲突', async () => {
    const f = await preparationFixture();
    const j = await f.api('core/handJournal.js');
    const page = j.createJournalPage({ id: 'p1', createdAt: 1, title: '雨夜', entries: [], favorite: true, notes: [{ id: 'n', text: '便签' }] });
    const back = j.importJournal(j.exportJournal([page]))[0];
    assert.equal(back.favorite, true);
    assert.equal(back.notes[0].text, '便签');
    const store = j.createJournalStore({ indexedDB: fakeIndexedDB(), currentScope: () => 'chat' });
    await store.append('chat', [j.createJournalPage({ id: 'p1', createdAt: 1, title: '雨夜', entries: [] })]);
    await store.favorite('chat', 'p1', true);
    await store.append('chat', j.importJournal(j.exportJournal([j.createJournalPage({ id: 'p1', createdAt: 1, title: '雨夜', entries: [] })])));
    assert.equal((await store.read('chat'))[0].favorite, true, '保留本机的收藏');
});

test('页面：一次一页 + 翻页 + 筛选 + 每页 ⋯；导出导入收进右上 ⋯；添一页收成按钮', async () => {
    const src = await readFile(new URL('../src/ui/handJournalView.js', import.meta.url), 'utf8');
    for (const needle of ['data-journal-filters', 'data-journal-prev', 'data-journal-next', 'data-journal-count', 'rmt-journal-more', 'rmt-journal-add', 'data-journal-fav=', 'data-journal-note-open=', 'data-journal-note-remove=', 'rmt-journal-tape', 'rmt-journal-stamp', 'rmt-journal-photo'])
        assert.ok(src.includes(needle), needle);
    assert.match(src, /finally\{setBusy\(false\);syncPager\(\);\}/, '保存后重新对翻页按钮');
    const f = await preparationFixture();
    const view = await f.api('ui/handJournalView.js');
    const j = await f.api('core/handJournal.js');
    const copy = value => vm.runInContext(`JSON.parse(${JSON.stringify(JSON.stringify(value))})`, f.sandbox);
    const html = view.journalPageHtml(j.createJournalPage(copy({ id: 'p', createdAt: Date.UTC(2026, 8, 18), title: '雨夜', favorite: true, notes: [{ id: 'n', text: '<b>便签</b>' }],
        entries: [{ id: 'e', title: '一起', source: { mode: 'bedtime', id: 's', title: '' }, blocks: [{ type: 'image', url: '/user/images/a.png' }] }] })), 0, { editable: true });
    assert.match(html, /rmt-journal-stamp/);
    assert.match(html, /&lt;b&gt;便签&lt;\/b&gt;/, '便签按文字显示，不当 HTML');
    assert.match(html, /data-journal-note-remove="n"/);
    assert.equal(view.journalPageHtml(j.createJournalPage(copy({ id: 'p', createdAt: 1, title: 't', entries: [], notes: [{ id: 'n', text: 'x' }] }))).includes('data-journal-note-remove'), false, '预览里没有撕便签按钮');
});
