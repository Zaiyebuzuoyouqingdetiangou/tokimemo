"""Actual bundled runtime and real Chromium DOM, synthetic host/API/storage.
Native IndexedDB navigation was separately blocked by administrator policy.
No real credentials, prompt data or remote endpoints. No security-policy bypass.
"""
import argparse,json,pathlib,re,time
from playwright.sync_api import sync_playwright
p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--root');a=p.parse_args()
root=pathlib.Path(a.root).resolve() if a.root else pathlib.Path(__file__).resolve().parent.parent
out=pathlib.Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True)
bundle=re.sub(r'^export const .*;$','',(root/'dist/heartbeatMemories.bundle.js').read_text(),flags=re.M)
host=(root/'tools/r8422-browser-host.mjs').read_text()
host=re.sub(r"^import \* as (\w+) from '../src/([^']+)';$",lambda m:'const '+m[1]+' = __m_'+re.sub(r'[^A-Za-z0-9_$]','_',m[2])+';',host,flags=re.M)
host=host.replace("import { state } from '../src/core/state.js';",'const state=__m_core_state_js.state;')
host=host.replace("getRequestHeaders: () => ({}), saveSettingsDebounced() {},", "getRequestHeaders: () => ({}), saveSettingsDebounced() {localStorage.setItem('r8425-fixture-settings',JSON.stringify(this.extensionSettings[C.EXTENSION_SETTINGS_KEY]));},")
host=host.replace('globalThis.SillyTavern = { getContext: () => ctx };', "if(localStorage.getItem('r8425-fixture-settings'))ctx.extensionSettings[C.EXTENSION_SETTINGS_KEY]=JSON.parse(localStorage.getItem('r8425-fixture-settings'));\nglobalThis.SillyTavern = { getContext: () => ctx };")
host=host.replace('length: 610','length: 8').replace("'春'.repeat(1000)","'春'.repeat(6000)").replace('.slice(0, 993)','.slice(0, 5993)')
host=host.replace("if (fixture.pauseNext)","if (fixture.responseKind==='heart') return {content:JSON.stringify({relationshipState:'自然相处',relationshipSummary:'彼此倾听',greetings:{morning:['早安，窗边的花开了。']}})};\n            if (fixture.pauseNext)")
host=host.replace('fixture.ctx = ctx; fixture.state = state;', '''fixture.ctx = ctx; fixture.state = state;
fixture.getSettings=()=>{const value=clone(settings.getPluginSettings(ctx));delete value.manualApiKey;return value;};
fixture.nativeAvailable=()=>({indexedDB:typeof indexedDB.open==='function',secureContext:isSecureContext,crypto:!!crypto.subtle});
fixture.engine={R,D:__m_archive_importRecovery_js,G:__m_generation_recovery_js,settings,context,cache:__m_core_cache_js,A:__m_core_independentApi_js};
fixture.getRecovery=()=>R.getCurrentArchiveImportRecoverySummary(ctx);
fixture.openLanguage=async()=>{await overlay.openCachedOrGenerate('heart',{workspaceRoute:'language'});__m_ui_languageView_js.renderLanguage();};
fixture.abortLocalWrite=()=>{const put=IDBObjectStore.prototype.put;IDBObjectStore.prototype.put=function(value,...args){const result=put.call(this,value,...args);if(this.transaction.db.name==='heartbeat_memories_local_recovery_v1'){IDBObjectStore.prototype.put=put;this.transaction.abort();}return result;};};
ctx.getWorldInfoNames=async()=>Array.from({length:500},(_,i)=>'合成世界书'+String(i).padStart(3,'0'));
ctx.loadWorldInfo=async name=>({entries:{1:{uid:1,comment:name,key:['庭院'],content:'合成世界观，不是用户资料。'}}});
''')
host=host.replace('const clone = value => structuredClone(value);', "const clone = value => structuredClone(value);\nconst store=window.__fixtureStore;\nbackup.setArchiveBackupBackendForTests({read:async entry=>clone(store.backup[entry.entryId||context.archiveIndexEntryId(entry)]||null),\nput:async(record,expected,options={})=>{if(options.stillCurrent?.()===false)throw new DOMException('Changed','AbortError');const old=store.backup[record.entryId];if(expected?.present===true&&old&&old.archiveRevision!==expected.revision)throw new Error('synthetic CAS');store.backup[record.entryId]=clone(record);return true;},delete:async()=>{throw new Error('No archive deletion');}});\nledger.setMemorySourceLedgerBackendForTests({read:async scope=>clone(store.ledger[scope.key]||null),write:async row=>{store.ledger[row.scope.key]=clone(row);return true;},delete:async()=>{throw new Error('No source deletion');}});\n__m_core_localRecoveryStore_js.setLocalRecoveryBackendForTests({read:async key=>clone(store.drafts[key]||null),compare:async(key,revision,payload)=>{const old=store.drafts[key];if((old?.revision||0)!==revision)throw new Error('synthetic CAS');store.drafts[key]=clone({key,revision:revision+1,payload});return revision+1;}});\n")
result={'root':str(root),'environment':'Actual candidate bundle and Chromium DOM. ST, provider, source, IndexedDB backends and localStorage are synthetic. Native IndexedDB navigation blocked by policy; browser WebCrypto not available in opaque origin. Node WebCrypto separately tested. NO real ST/TT/phone/model calls.','cases':[],'pageErrors':[]}
def good(name,**details):result['cases'].append({'name':name,'pass':True,**details})
def section(page,key):
 if not page.locator('[data-rmt-settings-section="'+key+'"]').count():page.locator('[data-rmt-workspace-tab="settings"]').first.click()
 el=page.locator('[data-rmt-settings-section="'+key+'"]').first
 for ancestor in el.locator('xpath=ancestor::details').all():
  if ancestor.get_attribute('open') is None:ancestor.locator(':scope > summary').first.click()
 if el.get_attribute('open') is None:el.locator(':scope > summary').first.click()
 return el
try:
 with sync_playwright() as pw:
  browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);result['browser']=browser.version
  bc=browser.new_context(viewport={'width':390,'height':844})
  def route(r):
   if r.request.url=='http://localhost:8765/hearttrace-fixture':r.fulfill(status=200,content_type='text/html',body='<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head><body></body></html>')
   else:r.abort()
  bc.route('**/*',route)
  persisted={'local':{},'backup':{},'ledger':{},'drafts':{}}
  def load(page,reload=False):
   if reload:
    data=page.evaluate('window.__fixtureStore');page.close();page=bc.new_page()
   else:data=persisted
   page.on('pageerror',lambda e:result['pageErrors'].append(str(e)))
   page.set_content('<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head><body></body></html>')
   page.evaluate("""(data)=>{window.__fixtureStore=data;Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>data.local[k]??null,setItem:(k,v)=>{data.local[k]=String(v)},removeItem:k=>{delete data.local[k]}}});}""",data)
   page.add_script_tag(type='module',content=bundle+'\n(async()=>{'+host+'})().catch(e=>window.fixtureError=String(e.stack))')
   page.wait_for_function('window.fixture?.ready||window.fixtureError',timeout=30000)
   assert not page.evaluate('window.fixtureError || fixture.errors.join("\\n")'),page.evaluate('window.fixtureError || fixture.errors')
   return page
  page=load(bc.new_page())
  native=page.evaluate('fixture.nativeAvailable()');result['capabilities']=native
  good('actual bundle loads on real DOM with explicitly simulated storage backends')
  # Real button creates a simulated durable draft with one successful chunk.
  (out/"initial.html").write_text(page.content());page.screenshot(path=str(out/"initial.png"))
  page.evaluate('fixture.failRequestAt=fixture.requests.length+2')
  page.locator('[data-rmt-workspace-tab="archive"]').first.click();page.locator('[data-rmt-action="current-archive-import"], [data-rmt-action="import-memory"]').first.click()
  page.wait_for_function('!fixture.state.busy && fixture.getRecovery()?.completed>=1',timeout=20000)
  before=page.evaluate('({draft:fixture.getRecovery(),requests:fixture.requests.length,archive:JSON.stringify(fixture.ctx.chatMetadata.heartbeatMemoriesArchiveV3)})')
  assert not before['draft']['pageOnly'];good('actual import button -> successful partial chunk -> simulated durable-store acknowledgement',completed=before['draft']['completed'])
  page=load(page,True);assert page.evaluate('fixture.requests.length')==before['requests'];good('fresh page/module teardown makes no automatic model request')
  page.locator('[data-rmt-workspace-tab="archive"]').first.click();page.locator('[data-rmt-action="current-archive-import"], [data-rmt-action="import-memory"]').first.click()
  page.wait_for_function('!fixture.state.busy && fixture.ctx.chatMetadata.heartbeatMemoriesArchiveV3.memories.length>1',timeout=20000)
  calls=page.evaluate('fixture.requests');first_success=calls[0]['ids'];assert not any(row['ids']==first_success for row in calls[before['requests']:] if row['ids'])
  good('actual click after fresh-page restore reuses successful extraction; only unfinished requests sent')
  # All 41 validated segments persist across a fresh page/module teardown, never formal Mxxx.
  page.evaluate('''async()=>{const {D,G}=fixture.engine;const origin={characterKey:'native-41',characterId:'41',characterAvatar:'native41.png',chatId:'native-41-chat',archiveRevision:'fixed-bank'};
const ticket=await D.beginArchiveRecovery({origin,sourceIdentity:'synthetic',sourceFragments:['stable'],settingsIdentity:'same'});
for(let i=0;i<41;i++)await G.withRecoverySegment('fragment'+i,{origin:ticket.origin,taskKey:'n'+i,mode:'archive-import'},x=>x,async(_p,_o,accepted)=>{await accepted({index:i});return {index:i};});D.releaseArchiveRecovery(ticket);await D.flushArchiveRecovery(origin);localStorage.setItem('native41-origin',JSON.stringify(origin));}''')
  page=load(page,True)
  resumed=page.evaluate('''async()=>{const {D,G}=fixture.engine,origin=JSON.parse(localStorage.getItem('native41-origin'));await D.hydrateArchiveRecovery(origin);const summary=D.archiveRecoverySummary(origin);let requests=0;const ticket=await D.beginArchiveRecovery({origin,sourceIdentity:'synthetic',sourceFragments:['stable'],settingsIdentity:'same',continueApproved:true});for(let i=0;i<42;i++)await G.withRecoverySegment('fragment'+i,{origin:ticket.origin,taskKey:'n'+i,mode:'archive-import'},x=>x,async(_p,_o,accepted)=>{requests++;await accepted({index:i});return {index:i};});D.releaseArchiveRecovery(ticket);await D.flushArchiveRecovery(origin);await D.clearArchiveRecoveryDurably(origin);return {saved:summary.completed,requests};}''')
  assert resumed=={'saved':41,'requests':1};good('41 successes across fresh page/module teardown, only42nd is requested',**resumed)
  # Actual settings controls. No plaintext is ever exported in the report.
  section(page,'api');page.locator('[data-rmt-api-manual]').click() if page.locator('[data-rmt-api-manual]').count() else page.get_by_role('button',name='手动配置',exact=False).first.click()
  page.locator('[data-rmt-manual-api-base]').fill('https://synthetic.invalid/v1');page.locator('[data-rmt-manual-api-model]').fill('synthetic-model');page.locator('[data-rmt-manual-api-model]').press('Tab')
  page.wait_for_function('document.querySelector("[data-rmt-manual-save-status]").textContent.includes("连接信息已保存")',timeout=12000)
  page.locator('[data-rmt-manual-api-save]').click();page.wait_for_function('fixture.getSettings().apiConnectionMode==="manual"')
  good('actual URL/model fields auto-save without requiring another button')
  page=load(page,True);section(page,'api')
  assert page.locator('[data-rmt-manual-api-key]').input_value()==''
  assert page.locator('[data-rmt-manual-api-model]').input_value()=='synthetic-model'
  good('manual connection fields restored after fresh-page/module teardown')
  # This environment lacks native browser WebCrypto. Exercise truthful failure,
  # not a fake encryption implementation. Real Node AES-GCM tested separately.
  page.locator('[data-rmt-manual-api-key]').fill('synthetic-browser-test-secret');page.locator('[data-rmt-manual-api-key]').press('Tab')
  page.wait_for_function('document.querySelector("[data-rmt-manual-save-status]").textContent.includes("未能保存")',timeout=12000)
  assert page.locator('[data-rmt-manual-api-key]').input_value()=='synthetic-browser-test-secret'
  assert page.evaluate('!JSON.stringify(fixture.ctx.extensionSettings).includes("synthetic-browser-test-secret")')
  assert not page.evaluate('fixture.getSettings().manualApiSecretRef');good('unavailable browser crypto gives visible unsaved status; key not silently cleared or stored plaintext')
  page.locator('[data-rmt-manual-api-key-clear]').click();page.wait_for_function('!document.querySelector("[data-rmt-manual-api-key]").value')
  section(page,'advanced-generation');assert not page.locator('[data-rmt-advanced-enabled]').is_checked();page.locator('[data-rmt-advanced-common]').click();assert page.locator('[data-rmt-advanced-exclude]:checked').count()==4;assert page.evaluate('fixture.getSettings().advancedExcludedParams.length')==0
  page.locator('[data-rmt-advanced-enabled]').check();page.locator('[data-rmt-advanced-stream]').select_option('on');page.locator('[data-rmt-advanced-json]').fill('{"enable_thinking":false}');page.locator('[data-rmt-advanced-save]').click()
  assert page.evaluate('fixture.getSettings().advancedGenerationEnabled');assert len(page.evaluate('fixture.getSettings().advancedExcludedParams'))==4;good('advanced checkbox/common four/stream/JSON/save real DOM -> persisted settings')
  page.locator('[data-rmt-advanced-none]').click();page.locator('[data-rmt-advanced-revert]').click();assert page.locator('[data-rmt-advanced-exclude]:checked').count()==4;good('advanced draft editing and revert do not silently change active settings')
  previous=page.evaluate('fixture.getSettings().advancedExtraParams');page.locator('[data-rmt-advanced-json]').fill('{"messages":[]}');page.locator('[data-rmt-advanced-save]').click();assert page.evaluate('fixture.getSettings().advancedExtraParams')==previous;good('actual UI rejects protected overrides without overwriting saved configuration')
  page.locator('[data-rmt-advanced-revert]').click()
  for width,theme in [(320,'default'),(375,'night'),(390,'night'),(430,'default'),(1280,'default')]:
   page.set_viewport_size({'width':width,'height':900 if width>500 else 844});page.evaluate('(mode)=>fixture.theme(mode)',theme);el=section(page,'advanced-generation');page.locator('[data-rmt-advanced-save]').scroll_into_view_if_needed();box=el.bounding_box();assert box['x']>=-1 and box['x']+box['width']<=width+1,(width,box)
   assert page.locator('[data-rmt-advanced-save]').bounding_box()['height']>=42
   if width in [390,1280]:page.screenshot(path=str(out/('mobile-dark.png' if width==390 else 'desktop-light.png')))
   good('advanced UI no horizontal overflow '+str(width)+'/'+theme)
  page.locator('[data-rmt-advanced-reset]').click();assert not page.evaluate('fixture.getSettings().advancedGenerationEnabled');assert page.evaluate('fixture.getSettings().manualApiModel')=='synthetic-model';good('reset affects only optional advanced parameters, not connection/model')
  section(page,'api');page.locator('[data-rmt-manual-api-key-clear]').click();page.wait_for_function('!fixture.getSettings().manualApiSecretRef');page=load(page,True);assert not page.evaluate('fixture.getSettings().manualApiSecretRef');good('clear credential followed by page reload retains no active reference')
  assert not result['pageErrors'],result['pageErrors'];assert not page.evaluate('fixture.errors'),page.evaluate('fixture.errors');good('no unexpected browser errors')
  browser.close();result['passed']=len(result['cases']);result['failed']=0
except Exception as error:
 result['failed']=1;result['error']=str(error)
 try:page.screenshot(path=str(out/'failure.png'));(out/'failure.html').write_text(page.content())
 except Exception:pass
 raise
finally:(out/'browser-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
