// r84.176 · 手帐「存成长图」：Canvas 一笔一笔画，不靠网页截图（iPhone / TT 的 WebKit 不允许把网页截图导出）。
// 画面在真实浏览器里的检查见 tools/check-journal-image-browser.py；这里只检查接线和不越界的约定。
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const read = file => readFile(new URL(file, import.meta.url), 'utf8');

test('长图：Canvas 绘制、读不到的图画说明框、超大时整体缩小不截断', async () => {
    const src = await read('../src/ui/journalImage.js');
    assert.equal(/foreignObject|html2canvas|toDataURL\(/.test(src), false, '不用网页截图');
    assert.match(src, /canvas\.toBlob\(/);
    assert.match(src, /const MAX_AREA = 16_000_000/);
    assert.match(src, /Math\.min\(1, Math\.sqrt\(MAX_AREA \/ \(WIDTH \* plan\.height\)\)\)/);
    assert.match(src, /这张图片存在别的网站上，没能导出/);
    assert.match(src, /journal\.safeJournalImageUrl\(url\)/, '只读手帐允许的图片地址');
    assert.equal(/generateConfiguredJson|fetch\(['"`]https?:/.test(src), false, '不发请求、不上传');
});

test('界面：每页 ⋯ 里有存成长图；预览可长按保存、下载、分享；换页时收起', async () => {
    const view = await read('../src/ui/handJournalView.js');
    for (const needle of ['data-journal-image=', 'data-journal-image-close', 'data-journal-image-share', 'download="${esc(exportView.name)}"', '长按图片可以存到相册'])
        assert.ok(view.includes(needle), needle);
    assert.match(view, /noteFor='';closeExport\(\);drawPages\(\)/);
    assert.match(view, /URL\.revokeObjectURL\(exportView\.url\)/);
});
