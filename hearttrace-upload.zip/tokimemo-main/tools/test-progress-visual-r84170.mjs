// r84.170 · 任务续写或完成时，保留按位置存的本地图片（卷宗、睡前故事章节、蝴蝶节点、结局、萤火虫）。
// 以前只保留 cgImage：在「未完成」阶段给前世卷宗画的图，下一步续写或完成时被整份覆盖，重启后就没了。
import test from 'node:test';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import { preparationFixture } from './preparation-harness-r8481.mjs';

// 与 test-lenticular-r84169.mjs 的 cardFixture 相同（复制过来，避免导入时把那边的测试再跑一遍）。
function cardFixture() {
    return { kind: 'pastLives', version: 1, title: '前世今生', presentation: 'neutral', chatId: 'preparation-check', archiveRevision: 'rev1', characterName: '岚', userName: '阿宁',
        episodes: [{ id: 'PL01', title: '灯下', fiction: true, presentation: 'neutral', opening: { title: '信', motif: '旧信', text: '灯下展开旧信。', sourceMemoryIds: ['M001'], sourceMemoryAnchor: '一起读书' },
            dossiers: [{ id: 'D01', title: '前世', synopsis: '灯下研墨。', clues: [] }], annotations: [], echoes: [{ id: 'E01', title: '回响', text: '一起读书', kind: 'memory', sourceMemoryIds: ['M023'], sourceMemoryAnchor: '一起读书' }], closing: { text: '回到此刻' } }],
        selectedId: 'PL01', selectedEntryId: 'D01', view: 'dossier' };
}

const pic = name => ({ cgImage: { url: `/user/images/${name}.png`, generatedAt: 1 }, sourceHash: 'h-' + name });

test('前世卷宗的图在续写 / 完成时不被覆盖', async () => {
    const f = await preparationFixture();
    const copy = value => vm.runInContext(`JSON.parse(${JSON.stringify(JSON.stringify(value))})`, f.sandbox);
    f.sandbox.structuredClone = copy;
    const drafts = await f.api('core/cacheGenerationDrafts.js');
    const saved = copy(cardFixture());
    saved.episodes[0].dossiers[0].visual = copy(pic('past'));
    const incoming = copy(cardFixture());
    incoming.episodes[0].echoes.push(copy({ id: 'E02', title: '新回响', text: '续写出来的', kind: 'possibility', sourceMemoryIds: [] }));
    const next = drafts.preserveProgressLocalState(incoming, saved);
    assert.equal(next.episodes[0].dossiers[0].visual?.cgImage?.url, '/user/images/past.png');
    assert.equal(next.episodes[0].echoes.length, incoming.episodes[0].echoes.length, '续写内容仍以新结果为准');
});

test('睡前故事章节、结局分镜和萤火虫的图同样保留', async () => {
    const f = await preparationFixture();
    const copy = value => vm.runInContext(`JSON.parse(${JSON.stringify(JSON.stringify(value))})`, f.sandbox);
    f.sandbox.structuredClone = copy;
    const drafts = await f.api('core/cacheGenerationDrafts.js');
    const saved = copy({ kind: 'bedtime', stories: [{ id: 'S1', chapters: [{ id: 'C1', text: 'a', visual: pic('bed') }] }],
        endings: [{ id: 'EN1', visuals: { epilogue: pic('epi') }, previousCgVisuals: [pic('old')] }], fireflyVisual: pic('fly') });
    const incoming = copy({ kind: 'bedtime', stories: [{ id: 'S1', chapters: [{ id: 'C1', text: 'a' }, { id: 'C2', text: 'b' }] }],
        endings: [{ id: 'EN1' }] });
    const next = drafts.preserveProgressLocalState(incoming, saved);
    assert.equal(next.stories[0].chapters[0].visual?.cgImage?.url, '/user/images/bed.png');
    assert.equal(next.stories[0].chapters.length, 2);
    assert.equal(next.endings[0].visuals?.epilogue?.cgImage?.url, '/user/images/epi.png');
    assert.equal(next.endings[0].previousCgVisuals?.[0]?.cgImage?.url, '/user/images/old.png');
    assert.equal(next.fireflyVisual?.cgImage?.url, '/user/images/fly.png');
});
