"""Real Chromium and actual candidate bundle/UI. Host, model, storage are synthetic.
No real service, keys, chat, source or network is used. No security policy bypass.
"""
import argparse,json,pathlib,re,time
from playwright.sync_api import sync_playwright
p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--root');a=p.parse_args()
root=pathlib.Path(a.root).resolve() if a.root else pathlib.Path(__file__).resolve().parent.parent
out=pathlib.Path(a.out);out.mkdir(parents=True,exist_ok=True)
bundle=re.sub(r'^export const .*;$','',(root/'dist/heartbeatMemories.bundle.js').read_text(),flags=re.M)
host=(root/'tools/r8422-browser-host.mjs').read_text()
host=re.sub(r"^import \* as (\w+) from '../src/([^']+)';$",lambda m:'const '+m[1]+' = __m_'+re.sub(r'[^A-Za-z0-9_$]','_',m[2])+';',host,flags=re.M)
host=host.replace("import { state } from '../src/core/state.js';",'const state=__m_core_state_js.state;')
host=host.replace('const clone = value => structuredClone(value);','''const clone = value => structuredClone(value);
const store=window.__fixtureStore;
backup.setArchiveBackupBackendForTests({read:async entry=>clone(store.backup[entry.entryId||context.archiveIndexEntryId(entry)]||null),
put:async (record,expected,options={})=>{if(options.stillCurrent?.()===false)throw new DOMException('Changed','AbortError');
const old=store.backup[record.entryId];if(expected?.present===true&&old&&old.archiveRevision!==expected.revision)throw new Error('fixture CAS');store.backup[record.entryId]=clone(record);return true;},delete:async()=>{throw new Error('No deletion');}});
ledger.setMemorySourceLedgerBackendForTests({read:async scope=>clone(store.ledger[scope.key]||null),write:async row=>{store.ledger[row.scope.key]=clone(row);return true;},delete:async()=>{throw new Error('No source deletion');}});
''')
host=host.replace('length: 610','length: 2').replace("`尾${String(index).padStart(6, '0')}`", "`尾${String(index).padStart(6, '0')}<thinking>OMIT_SENTINEL</thinking><keep>共同庭院保留</keep>`")
host=host.replace("const prompt = messages.map(row => row.content).join('\\n');", "const prompt = messages.map(row => row.content).join('\\n');fixture.lastPrompt=prompt;")
host=host.replace('fixture.ctx = ctx; fixture.state = state;', '''fixture.ctx = ctx; fixture.state = state;
fixture.getSettings=()=>clone(settings.getPluginSettings(ctx));
fixture.request=()=>__m_generation_client_js.generateConfiguredJson('合成指令\\nDATA:'+JSON.stringify({source:'外部<thinking>OMIT_SENTINEL</thinking><keep>共同庭院保留</keep><extra>EXTRA_SENTINEL</extra>'}),{context:ctx,contextEnvelope:''});
fixture.getWorldSelection=()=>R.getMemoryWorldInfoSelection(ctx);
ctx.getWorldInfoNames=async()=>Array.from({length:500},(_,i)=>'世界书'+String(i).padStart(3,'0')+'·完整名称');
ctx.loadWorldInfo=async name=>({entries:Object.fromEntries(Array.from({length:100},(_,i)=>[i,{uid:i,comment:name+'条目'+i,key:['合成关键词'],content:'世界设定，只是合成测试。'}]))});
''')
bootstrap='''()=>{window.__fixtureStore={local:{},backup:{},ledger:{}};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>window.__fixtureStore.local[k]??null,setItem:(k,v)=>{window.__fixtureStore.local[k]=String(v)},removeItem:k=>{delete window.__fixtureStore.local[k]}}});}'''
result={'environment':'Real Chromium DOM and candidate dist; mocked ST/provider/tokenizer/backup/ledger/localStorage. NOT physical phone, live ST/TT/model or native IDB success.','root':str(root),'cases':[]}
def good(name,**details):result['cases'].append({'name':name,'pass':True,**details})
def section(page,key):
    if not page.locator('[data-rmt-settings-section="'+key+'"]').count():
        page.locator('[data-rmt-workspace-tab="settings"]').first.click()
    el=page.locator('[data-rmt-settings-section="'+key+'"]').first
    for ancestor in el.locator('xpath=ancestor::details').all():
        if ancestor.get_attribute('open') is None: ancestor.locator(':scope > summary').first.click()
    if el.get_attribute('open') is None:el.locator(':scope > summary').first.click()
    return el
try:
 with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);result['browser']=browser.version
    bc=browser.new_context(viewport={'width':1280,'height':900});bc.route('**/*',lambda r:r.abort())
    def newpage():
        page=bc.new_page();page.set_content('<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head><body></body></html>')
        page.evaluate(bootstrap);page.on('pageerror',lambda e:result.setdefault('pageErrors',[]).append(str(e)))
        page.add_script_tag(type='module',content=bundle+'\n(async()=>{'+host+'})().catch(e=>window.fixtureError=String(e.stack))')
        page.wait_for_function('window.fixture?.ready||window.fixtureError',timeout=30000)
        assert not page.evaluate('window.fixtureError||fixture.errors'),page.evaluate('window.fixtureError||fixture.errors')
        return page
    page=newpage();section(page,'api');field=page.locator('[data-rmt-api-max-tokens]')
    assert field.get_attribute('max') is None
    for value in ['120000','60001','1','240000']:
        field.fill(value);field.press('Tab');page.wait_for_function('(n)=>fixture.getSettings().maxTokens===n',arg=int(value))
        page.evaluate('fixture.request()');assert page.evaluate('fixture.requests.at(-1).responseLength')==int(value)
        good('actual max-output input -> save -> actual profile-send '+value)
    for invalid in ['0','-1','1.5']:
        field.fill(invalid);field.press('Tab');assert page.evaluate('fixture.getSettings().maxTokens')==240000
    good('invalid/noninteger UI input preserves previous setting without clamping')
    field.fill('');field.press('Tab');assert page.evaluate('fixture.getSettings().maxTokens')==60000
    good('blank restores 60000 default, not a ceiling')
    # Synthetic chat for the tag catalog; actual existing archive not rewritten.
    page.evaluate("""()=>{fixture.originalChat=structuredClone(fixture.ctx.chat);fixture.originalArchive=JSON.stringify(fixture.ctx.chatMetadata);fixture.ctx.chat=[{mes:'<thinking>不选</thinking><keep>选择</keep>'},...Array.from({length:520},(_,i)=>({mes:'<tag'+i+'>合成</tag'+i+'>'})),{mes:'常'.repeat(280000)+'<tail>最后标签</tail>'}];}""")
    section(page,'filter');page.locator('[data-rmt-tag-scan]').click();page.wait_for_function("document.querySelector('[data-rmt-tag-status]').textContent.includes('已扫描')")
    choices=page.locator('[data-rmt-tag-name]');assert choices.count()==523
    assert page.locator('[data-rmt-tag-name="tail"]').count()==1
    assert not page.locator('[data-rmt-tag-name="thinking"]').is_checked()
    assert page.evaluate('fixture.getSettings().contextTagMode') is None
    good('actual scan >500 messages / >256k chars / 523 tags; legacy excludes retained until explicit save')
    page.locator('[data-rmt-tag-all]').click();assert page.locator('[data-rmt-tag-name]:checked').count()==523
    page.locator('[data-rmt-tag-save]').click();assert len(page.evaluate('fixture.getSettings().retainedContextTags'))==523
    good('select-all and explicit save retain all523, not first32 or100')
    page.locator('[data-rmt-tag-invert]').click();assert page.locator('[data-rmt-tag-name]:checked').count()==0
    assert len(page.evaluate('fixture.getSettings().retainedContextTags'))==523
    page.locator('[data-rmt-tag-cancel]').click();assert page.locator('[data-rmt-tag-name]:checked').count()==523
    good('invert is draft-only, cancel restores complete saved choice')
    page.locator('[data-rmt-tag-invert]').click();page.locator('[data-rmt-tag-name="keep"]').check();page.locator('[data-rmt-tag-save]').click()
    assert page.evaluate('fixture.getSettings().retainedContextTags')==['keep']
    page.evaluate('fixture.request()');prompt=page.evaluate('fixture.lastPrompt')
    assert '共同庭院保留' in prompt and 'OMIT_SENTINEL' not in prompt and 'EXTRA_SENTINEL' not in prompt
    assert page.evaluate('JSON.stringify(fixture.ctx.chatMetadata)===fixture.originalArchive')
    good('actual checkboxes -> save -> request filters unselected tags; original archive bytes unchanged')
    # Reopen settings panel: it must reconstruct saved checks independently of old DOM.
    page.locator('[data-rmt-workspace-tab="archive"]').first.click();section(page,'filter')
    assert page.locator('[data-rmt-tag-name="keep"]').is_checked();assert page.locator('[data-rmt-tag-name]:checked').count()==1
    good('settings DOM destruction/reopen retains selected labels')
    for width,theme in [(320,'default'),(375,'night'),(390,'night'),(430,'default'),(1280,'default')]:
        page.set_viewport_size({'width':width,'height':900 if width>500 else 844});page.evaluate('(m)=>fixture.theme(m)',theme);section(page,'filter')
        box=page.locator('[data-rmt-settings-section="filter"]').bounding_box();assert box and box['x']>=-1 and box['x']+box['width']<=width+1,(width,box)
        page.locator('[data-rmt-tag-save]').scroll_into_view_if_needed()
        assert page.locator('[data-rmt-tag-save]').bounding_box()['height']>=42
        if width in [390,1280]:page.screenshot(path=str(out/f'tags-{width}-{theme}.png'),full_page=True)
        good(f'tag settings viewport {width}/{theme} no horizontal overflow',box=box)
    # Fresh fixture for actual source dialog and archive import, not altered scan-chat.
    page.close();page=newpage();page.locator('[data-rmt-action="library-home"]').first.click()
    section(page,'filter');page.locator('[data-rmt-tag-draft]').fill('keep');page.locator('[data-rmt-tag-save]').click()
    section(page,'api');field=page.locator('[data-rmt-api-max-tokens]');field.fill('120000');field.press('Tab')
    page.locator('[data-rmt-workspace-tab="archive"]').first.click()
    page.locator('[data-rmt-action="current-archive-import"], [data-rmt-action="import-memory"]').first.click()
    page.wait_for_function('!fixture.state.busy&&fixture.ctx.chatMetadata.heartbeatMemoriesArchiveV3?.archiveImportProgress?.nextBatch===1',timeout=12000)
    snap=page.evaluate('fixture.snapshot()');assert snap['cursor']==snap['backupCursor']==1;assert snap['requests'][-1]['responseLength']==120000
    assert 'OMIT_SENTINEL' not in page.evaluate('fixture.lastPrompt');assert '共同庭院保留' in page.evaluate('fixture.lastPrompt')
    good('actual archive button + saved tag preference +120000 -> canonical and backup checkpoint',snapshot=snap)
    for width,theme in [(320,'default'),(375,'night'),(390,'night'),(430,'default'),(1280,'default')]:
        page.set_viewport_size({'width':width,'height':900 if width>500 else 844});page.evaluate('(m)=>fixture.theme(m)',theme)
        # world book picker is an actual archive/source control
        if not page.locator('[data-rmt-action="memory-worldinfo-picker"]').count():
            page.locator('[data-rmt-action="library-home"]').first.click()
        control=page.locator('[data-rmt-action="memory-worldinfo-picker"]').first
        for ancestor in control.locator('xpath=ancestor::details').all():
            if ancestor.get_attribute('open') is None:ancestor.locator(':scope > summary').first.click()
        control.click();page.wait_for_selector('.rmt-memory-wi-picker')
        assert page.locator('.rmt-memory-wi-book').count()==500
        head=page.locator('.rmt-memory-wi-picker-head');before=head.bounding_box()
        scroll=page.locator('.rmt-memory-wi-picker-scroll');scroll.evaluate('(el)=>{el.scrollTop=el.scrollHeight}')
        page.wait_for_timeout(30);after=head.bounding_box()
        assert abs(before['y']-after['y'])<1 and after['y']>=0,(before,after)
        assert after['x']>=-1 and after['x']+after['width']<=width+1
        last=page.locator('[data-rmt-memory-wi-all]').last;last.check()
        selected=page.evaluate('fixture.getWorldSelection()');assert selected['books'][-1]['name']=='世界书499·完整名称'
        close=page.locator('[data-rmt-action="memory-worldinfo-close"]');cb=close.bounding_box()
        assert cb['height']>=44 and cb['y']>=0 and cb['y']+cb['height']<844
        if width in [390,1280]:page.screenshot(path=str(out/f'world-books-{width}-{theme}.png'),full_page=True)
        close.click();assert page.locator('.rmt-memory-wi-picker').count()==0
        assert page.evaluate('fixture.getWorldSelection().books.at(-1).name')=='世界书499·完整名称'
        good(f'500-world-book scroll-to-bottom / fixed close / selection persisted {width}/{theme}',header=after,close=cb)
    result['nativeIndexedDB']=page.evaluate("""()=>new Promise(resolve=>{try{const req=indexedDB.open('r8424-synthetic-probe',1);req.onerror=()=>resolve({executed:false,reason:req.error.name});req.onsuccess=()=>{req.result.close();resolve({executed:true,note:'primitive open only; not archive persistence validation'})}}catch(e){resolve({executed:false,reason:e.name})}})""")
    assert not page.evaluate('fixture.errors'),page.evaluate('fixture.errors')
    assert not result.get('pageErrors'),result.get('pageErrors')
    page.close();bc.close();browser.close()
except Exception as e:
    result['error']=str(e)
    try:
        (out/'failure-page.html').write_text(page.content());page.screenshot(path=str(out/'failure.png'),full_page=True)
        result['failureState']=page.evaluate('({notices:window.fixture?.notices,errors:window.fixture?.errors})')
    except Exception:pass
    raise
finally:
    (out/'browser-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({'cases':len(result['cases']),'passed':sum(c['pass'] for c in result['cases'])}))
