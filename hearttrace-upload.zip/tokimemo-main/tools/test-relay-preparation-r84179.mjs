import test from 'node:test';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import { preparationFixture } from './preparation-harness-r8481.mjs';

async function fixture() {
    const f = await preparationFixture();
    f.copy = value => vm.runInContext(`JSON.parse(${JSON.stringify(JSON.stringify(value))})`, f.sandbox);
    f.sandbox.structuredClone = f.copy;
    f.relay = await f.api('archive/relayPreparation.js');
    f.cards = await f.api('core/lenticularCards.js');
    f.cacheApi = await f.api('core/cache.js');
    return f;
}
const plain = value => JSON.parse(JSON.stringify(value));
const memory = () => ({ version: 3, chatId: 'A', archiveRevision: 'ra', createdAt: 11, updatedAt: 12,
    characterName: '岚', userName: '阿宁', archiveName: '共同的书', sourceMessageCount: 30,
    usedMessageCount: 20, usedCharacterCount: 300, sourceFingerprint: 'aaa:ext-A', fullSourceFingerprint: 'full-A',
    externalMemoryFingerprint: 'ext-A', chatReadRange: { mode: 'range', start: 3, end: 30 },
    coveredRanges: [{ start: 3, end: 30, revision: 'ra', kind: 'full' }], coverageMode: 'selected-floors',
    memories: [{ id: 'M100', title: '书页', summary: '一起读书', anchors: ['一起读书'], sourceKind: 'chat', messageStart: 3, messageEnd: 4 }],
    coldArchive: [{ id: 'M001', title: '旧信', summary: '拆信', sourceChatId: 'older', messageStart: 1, messageEnd: 2 }] });
const photo = url => ({ url: '/user/images/' + url + '.png', generatedAt: 1 });
const album = (chatId = 'A', archiveRevision = 'ra', id = 'AL1') => ({ kind: 'album', chatId, archiveRevision,
    selectedId: id, entries: [{ id, title: '书页', desc: '灯下看书', sourceMemoryIds: ['M100'],
        sourceMemoryAnchor: '一起读书', cgImage: photo(id), comments: [{ text: '记得那天。' }] }] });

test('接力只移动身份：旧 M 编号、正文、证据、实图、评论和阅读位置原样保留', async () => {
    const f = await fixture(), snapshot = f.copy({ memory: memory(), cache: { chatId: 'A', archiveRevision: 'ra', album: album(),
        heart: { kind: 'heart', chatId: 'A', archiveRevision: 'ra', dailyStrips: [], selectedSeason: 'winter' } } });
    const before = plain(snapshot), moved = f.relay.prepareArchiveRelay(snapshot, { chatId: 'B', revision: 'rb', now: 22 });
    assert.deepEqual(plain(snapshot), before, '输入与原始备份不可变');
    assert.equal(moved.memory.createdAt, 11);
    assert.equal(moved.memory.chatId, 'B'); assert.equal(moved.memory.archiveRevision, 'rb');
    assert.deepEqual(plain(moved.memory.memories[0]), { ...before.memory.memories[0], sourceChatId: 'A' });
    assert.deepEqual(plain(moved.memory.coldArchive), before.memory.coldArchive);
    assert.deepEqual(plain(moved.cache.album.entries), before.cache.album.entries);
    assert.equal(moved.cache.album.selectedId, 'AL1');
    assert.equal(moved.cache.heart.selectedSeason, 'winter');
    assert.ok(f.cacheApi.loadSession('album', { cache: moved.cache, memoryBank: moved.memory, chatId: 'B' }), '真实会话读取器可读');
    assert.equal(f.providerCalls, 0);
});

test('B 从空覆盖起步；回 A 恢复 A 的前缀和楼层范围，不挪用 B 的范围', async () => {
    const f = await fixture(), original = f.copy(memory());
    original.archiveImportProgress = f.copy({ version: 1, archiveRevision: 'ra', batches: [], taskInputV1: { exact: 'A-only' } });
    original.archivePartialDraft = f.copy({ revision: 'ra', draftId: 'A-task', sourceHash: 'exact', slots: [{ slot: 'chat:0', rawHash: 'saved' }] });
    const b = f.relay.prepareArchiveRelay(f.copy({ memory: original, cache: {} }), { chatId: 'B', revision: 'rb', now: 20 });
    assert.equal(b.memory.sourceMessageCount, 0); assert.equal(b.memory.sourceFingerprint, '');
    assert.deepEqual(plain(b.memory.coveredRanges), []); assert.equal(b.memory.archiveImportProgress, undefined);
    assert.deepEqual(plain(b.memory.relaySourceCheckpointsV1.chats.A.archiveImportProgress), plain(original.archiveImportProgress));
    b.memory.sourceMessageCount = 5; b.memory.sourceFingerprint = 'bbb:ext-B';
    b.memory.coveredRanges = f.copy([{ start: 1, end: 5, revision: 'rb', kind: 'incremental' }]);
    b.memory.memories.push(f.copy({ id: 'M101', title: '散步', summary: '一起走', sourceChatId: 'B' }));
    const a = f.relay.prepareArchiveRelay(b, { chatId: 'A', revision: 'ra2', now: 30, previousMemberMemory: original });
    assert.equal(a.memory.sourceMessageCount, 30); assert.equal(a.memory.sourceFingerprint, 'aaa:ext-A');
    assert.deepEqual(plain(a.memory.coveredRanges), plain(original.coveredRanges));
    assert.equal(a.memory.archiveImportProgress.archiveRevision, 'ra2');
    assert.deepEqual(plain(a.memory.archiveImportProgress.taskInputV1), plain(original.archiveImportProgress.taskInputV1));
    assert.equal(a.memory.archivePartialDraft.revision, 'ra2');
    assert.deepEqual(plain(a.memory.relaySourceCheckpointsV1.chats.A.archiveImportProgress), plain(original.archiveImportProgress));
    assert.deepEqual(plain(a.memory.relaySourceCheckpointsV1.chats.A.archivePartialDraft), plain(original.archivePartialDraft));
    assert.equal(a.memory.relaySourceCheckpointsV1.chats.B.sourceMessageCount, 5);
    assert.deepEqual([...a.memory.memories.map(row => row.id)], ['M100', 'M101']);
});

test('空前缀例外只认正式接力且尚未读过的当前成员，不放过普通档案或已入档的 B', async () => {
    const f = await fixture();
    const b = f.relay.prepareArchiveRelay(f.copy({ memory: memory(), cache: {} }), { chatId: 'B', revision: 'rb', now: 20 });
    assert.equal(f.relay.relayHasUnreadCurrentSource(b.memory), false, '准备阶段还不是已提交接力');
    b.memory.archiveRelayV1 = f.copy({ version: 1, lineageId: 'lineage-1', epoch: 1 });
    assert.equal(f.relay.relayHasUnreadCurrentSource(b.memory), true);
    for (const patch of [{ sourceMessageCount: 1 }, { usedMessageCount: 1 }, { sourceFingerprint: 'new:source' },
        { externalMemoryRecordCount: 1 }, { coverageMode: 'incremental-append' }, { coveredRanges: [{ start: 1, end: 1 }] }, { chatId: 'C' }]) {
        assert.equal(f.relay.relayHasUnreadCurrentSource({ ...b.memory, ...patch }), false, JSON.stringify(patch));
    }
    const ordinary = { ...b.memory }; delete ordinary.archiveRelayV1;
    assert.equal(f.relay.relayHasUnreadCurrentSource(ordinary), false);
    const corrupt = f.copy(b.memory); corrupt.relaySourceCheckpointsV1.chats.B.sourceMessageCount = 1;
    assert.equal(f.relay.relayHasUnreadCurrentSource(corrupt), false);
});

test('当前、草稿和旧版本中的选图引用随接力继续解析，原图与 sourceHash 不变', async () => {
    const f = await fixture();
    const cache = f.copy({ chatId: 'A', archiveRevision: 'ra', album: album(),
        __generationDraftsV2: { version: 1, records: { draft1: { status: 'open', journal: { identity: { chatId: 'A', archiveRevision: 'ra' }, frozenInputs: { exact: 'original' } },
            result: { mode: 'album', sourceMemory: memory(), session: album('A', 'ra', 'AL2') } } } },
        __archiveVersionsV1: [{ version: 1, versionId: 'old1', chatId: 'A', archiveRevision: 'older', memory: { ...memory(), archiveRevision: 'older' },
            cache: { chatId: 'A', archiveRevision: 'older', album: album('A', 'older', 'AL3') } }] });
    const refs = f.cards.cardImageCatalog(cache, f.copy({ chatId: 'A' })).map(row => row.reference);
    assert.equal(refs.length, 3);
    cache.pastLives = f.copy({ kind: 'pastLives', chatId: 'A', archiveRevision: 'ra', lenticularCardsV1: refs.map((reference, index) =>
        ({ targetId: 'target' + index, sourceHash: 'unchanged-' + index, editRevision: 2, reference })) });
    const b = f.relay.prepareArchiveRelay(f.copy({ memory: memory(), cache }), { chatId: 'B', revision: 'rb', now: 20 });
    for (const [index, row] of b.cache.pastLives.lenticularCardsV1.entries()) {
        assert.equal(row.sourceHash, 'unchanged-' + index);
        assert.equal(row.reference.chatId, 'B');
        assert.ok(f.cards.resolveCardReference(b.cache, f.copy({ chatId: 'B' }), row.reference), row.reference.source);
    }
    assert.equal(f.cards.cardImageCatalog(b.cache, f.copy({ chatId: 'B' })).length, 3);
    assert.equal(b.cache.__archiveVersionsV1[0].archiveRevision, 'older', '历史版本不冒充新 revision');
});

test('旧恢复请求保持字节相同并可导出，不把 A 的付费任务伪装成 B 的任务', async () => {
    const f = await fixture(), journal = { identity: { chatId: 'A', archiveRevision: 'ra', mode: 'album' },
        contentSnapshot: { memoryBank: memory() }, frozenInputs: { prompt: '原请求逐字保存' }, segments: [{ slot: '1', value: '成功段' }] };
    const cache = f.copy({ chatId: 'A', archiveRevision: 'ra', __generationRecoveryV1: { album: journal },
        phoneGenerationDraftV1: { kind: 'phone-draft', chatId: 'A', archiveRevision: 'ra', completedApps: [{ id: 'notes', text: '成功内容' }] },
        __generationDraftsV2: { version: 1, records: { task1: { status: 'open', journal } } } });
    const b = f.relay.prepareArchiveRelay(f.copy({ memory: memory(), cache }), { chatId: 'B', revision: 'rb', now: 20 });
    assert.equal(b.cache.__generationRecoveryV1, undefined); assert.equal(b.cache.phoneGenerationDraftV1, undefined);
    assert.deepEqual(plain(b.cache.__generationDraftsV2.records.task1.journal), journal);
    const saved = f.relay.relayPreservedDraftRows(b.cache);
    assert.deepEqual(plain(saved.find(row => row.key === '__generationRecoveryV1').value), { album: journal });
    assert.equal(saved.find(row => row.key === 'phoneGenerationDraftV1').value.completedApps[0].text, '成功内容');
    assert.equal(saved[0].originChatId, 'A');
    const a = f.relay.prepareArchiveRelay(b, { chatId: 'A', revision: 'ra2', now: 30 });
    assert.deepEqual(plain(a.cache.__generationRecoveryV1.album), journal, '回 A 后可按现有 frozen-source 机制显式继续');
    assert.equal(a.cache.phoneGenerationDraftV1, undefined, '严格 revision 绑定的旧电话草稿只读保留，不硬绑新版本');
    delete a.cache.__generationRecoveryV1;
    for (const row of Object.values(a.cache.__generationDraftsV2.records)) row.status = 'complete';
    const b2 = f.relay.prepareArchiveRelay(a, { chatId: 'B', revision: 'rb2', now: 40 });
    const a2 = f.relay.prepareArchiveRelay(b2, { chatId: 'A', revision: 'ra3', now: 50 });
    assert.equal(a2.cache.__generationRecoveryV1, undefined, '后来完成的旧任务不会从交接备份复活');
    assert.equal(f.providerCalls, 0);
});

test('旧页面的冻结证据只迁阅读身份，原 sourceIdentity 与 Mxxx 依据不变', async () => {
    const f = await fixture(), sourceMemory = { ...memory(), archiveRevision: 'old-evidence' };
    const snapshot = f.copy({ memory: memory(), cache: { album: { ...album(), generationSources: { album: {
        sourceMemory, sourceIdentity: { chatId: 'A', archiveRevision: 'old-evidence' } } } } } });
    const b = f.relay.prepareArchiveRelay(snapshot, { chatId: 'B', revision: 'rb', now: 20 });
    const read = f.cacheApi.generationPageReadingSource(b.cache.album, 'album', b.memory);
    assert.equal(read.session.chatId, 'B'); assert.equal(read.memoryBank.chatId, 'B');
    assert.equal(read.memoryBank.archiveRevision, 'old-evidence');
    assert.deepEqual(plain(read.source.sourceIdentity), { chatId: 'A', archiveRevision: 'old-evidence' });
    assert.equal(read.memoryBank.memories[0].sourceChatId, 'A');
});

test('来源、目标或缓存归属不一致时拒绝准备，原对象不变', async () => {
    const f = await fixture(), snapshot = f.copy({ memory: memory(), cache: { chatId: 'unrelated', archiveRevision: 'ra' } });
    const before = plain(snapshot);
    assert.throws(() => f.relay.prepareArchiveRelay(snapshot, { chatId: 'B', revision: 'rb' }));
    assert.deepEqual(plain(snapshot), before);
    assert.throws(() => f.relay.prepareArchiveRelay(f.copy({ memory: memory(), cache: {} }), { chatId: 'A', revision: 'ra2' }));
    assert.throws(() => f.relay.prepareArchiveRelay(f.copy({ memory: memory(), cache: {} }), { chatId: 'B', revision: 'rb', previousMemberMemory: memory() }));
});

test('内存里的结果与请求快照共用对象，也不能改动原付费请求身份', async () => {
    const f = await fixture();
    f.sandbox.structuredClone = structuredClone;
    const bank = memory(), journal = { identity: { chatId: 'A', archiveRevision: 'ra' }, contentSnapshot: { memoryBank: bank } };
    const snapshot = { memory: bank, cache: { __generationDraftsV2: { version: 1, records: {
        one: { status: 'open', journal, result: { mode: 'album', sourceMemory: bank, session: album() } },
    } } } };
    const b = f.relay.prepareArchiveRelay(snapshot, { chatId: 'B', revision: 'rb' });
    assert.equal(b.cache.__generationDraftsV2.records.one.result.sourceMemory.chatId, 'B');
    assert.equal(b.cache.__generationDraftsV2.records.one.journal.contentSnapshot.memoryBank.chatId, 'A');
    assert.equal(snapshot.memory.chatId, 'A');
});
