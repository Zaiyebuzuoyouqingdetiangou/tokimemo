// Scan src/ for names that are used but never defined / imported, or defined twice
// (dev tool). A verbatim split that forgets an import only fails at call time, which
// refactor-guard cannot see; TypeScript's checker can. Needs the typescript package
// (Claude sandbox global npm, or set TYPESCRIPT_PATH).
import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const tsc = [process.env.TYPESCRIPT_PATH && path.join(process.env.TYPESCRIPT_PATH, 'bin/tsc'),
    '/home/claude/.npm-global/lib/node_modules/typescript/bin/tsc'].filter(Boolean).find(file => fs.existsSync(file));
if (!tsc) throw new Error('typescript not found; set TYPESCRIPT_PATH');
const files = [];
(function walk(dir) { for (const entry of fs.readdirSync(dir, { withFileTypes: true })) { const full = path.join(dir, entry.name); if (entry.isDirectory()) walk(full); else if (full.endsWith('.js')) files.push(path.relative(root, full)); } })(path.join(root, 'src'));
let output = '';
try { execFileSync(process.execPath, [tsc, '--allowJs', '--checkJs', '--noEmit', '--target', 'es2022', '--module', 'es2022', '--moduleResolution', 'bundler', '--lib', 'es2022,dom', '--skipLibCheck', ...files], { cwd: root, encoding: 'utf8', maxBuffer: 1 << 28 }); }
catch (error) { output = String(error.stdout || ''); }
// 2304/2552 cannot find name, 2448/2454 used before declaration, 2300/2451 duplicate, 2305/2724/2614 missing export.
const problems = output.split('\n').filter(line => /error TS(2304|2552|2448|2454|2300|2451|2305|2724|2614|2306):/.test(line));
console.log(JSON.stringify({ ok: problems.length === 0, files: files.length, problems }, null, 2));
if (problems.length) process.exitCode = 1;
