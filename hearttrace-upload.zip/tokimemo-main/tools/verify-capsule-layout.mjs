// Real browser UI: index.js -> shipped dist, public host/provider boundaries,
// native IndexedDB. No production source modules or UI hooks are imported.
// Authored without execution; run after building dist. All text/image replies
// are synthetic and every non-local request is blocked.
// Env: CG_PARTICIPANTS_OUTPUT_DIR, PLAYWRIGHT_CHROMIUM_EXECUTABLE,
// CG_PARTICIPANTS_CASES=natural,tags, CG_PARTICIPANTS_WIDTHS=390,1280.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import http from 'node:http';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const repoRoot = path.resolve(process.env.LAYOUT_REPO_ROOT || path.join(path.dirname(fileURLToPath(import.meta.url)), '..'));
const outputDir = path.resolve(process.env.LAYOUT_OUTPUT_DIR || path.join(repoRoot, 'artifacts', 'capsule-layout'));
const prefix = '/scripts/extensions/third-party/hearttrace/';
const sha256 = value => createHash('sha256').update(value).digest('hex');
const artifactNames = ['index.js', 'dist/heartbeatMemories.bundle.js'];
const artifactHashes = {};
const cardName = '刀剑神域—沙盒';
const userName = '小月';
const people = [
    { id: 'person-left', name: '同名', sourceRefs: [{ world: '合住', uid: '11', title: '左侧人物', content: 'LEFT_SOURCE：黑发绿眼。' }] },
    { id: 'person-middle', name: '同名', sourceRefs: [{ world: '合住', uid: '12', title: '中间人物', content: 'MIDDLE_SOURCE：黑发蓝眼。' }] },
    { id: 'person-right', name: '同名', sourceRefs: [{ world: '合住', uid: '13', title: '右侧人物', content: 'RIGHT_SOURCE：黑发棕眼。' }] },
];
const tags = ['(black hair:1.25), green eyes', '(black hair:1.25), blue eyes', '(black hair:1.25), brown eyes'];
const customName = '只在本图出现';
const customTag = '(blond hair:1.15), golden eyes';
const originalScene = '三个人在庭院不同位置照料花苗。保留手写重复：雨声，雨声。';
const naturalScene = '左侧同名拿着花苗，右侧同名浇水，只在本图出现的人在中间整理土壤。';
const tagScene = '3people, courtyard, left holding seedling, right watering, center digging';
const unchangedImage = { url: '/user/images/fixture/unchanged.png', prompt: 'OTHER_IMAGE_PROMPT_KEEP', provider: 'baibai-image', generatedAt: 1 };
const changedRoster = { version: 1, cardType: 'multi', revision: 'new-canonical-roster',
    people: [{ id: 'replacement-resident', name: '档案后来加入的人', sourceRefs: [] }], selectedIds: ['replacement-resident'] };
const scenarios = { natural: { id: 'natural', format: 'nai5-natural', finalScene: naturalScene,
    replyFlat: 'Three people in the courtyard: the green-eyed person holds seedlings, the brown-eyed person waters, and a blond person digs.' },
tags: { id: 'tags', format: 'nai45-tags', finalScene: tagScene,
    replyFlat: '3people, courtyard, green eyes, holding seedling, brown eyes, watering, blond hair, digging' } };
const requestedCases = (process.env.CG_PARTICIPANTS_CASES || 'natural,tags').split(',').filter(Boolean);
const viewports = (process.env.LAYOUT_WIDTHS || '320,390,768,1280').split(',').filter(Boolean).map(Number);
const selectors = {
    menu: '#heartbeat_memories_menu_item', content: '.rmt-workspace-tabs [data-rmt-workspace-tab="content"]',
    memoryGroup: '[data-rmt-workspace-group="memory"]', album: '[data-rmt-workspace-route="album"]',
    settings: '[data-rmt-album-prompt="visual"]', dialog: '.rmt-cg-prompt-dialog', format: '[data-rmt-cg-editor-format]',
    scene: '[data-rmt-cg-prompt-input]', sceneTags: '[data-rmt-cg-scene-tags]', flat: '[data-rmt-cg-flat-prompt]',
    rows: '[data-rmt-cg-person]', preview: '[data-rmt-cg-send-preview]', status: '[data-rmt-cg-prompt-status]',
    draw: '[data-rmt-cg-prompt-action="draw"]', close: '[data-rmt-cg-prompt-action="close"]',
    reconceive: '[data-rmt-cg-prompt-action="reconceive"]', saveLooks: '[data-rmt-cg-prompt-action="save-looks"]',
    addPerson: '[data-rmt-cg-prompt-action="add-person"]', addUser: '[data-rmt-cg-prompt-action="add-user"]',
};
const personSelector = (kind, index) => `[data-rmt-cg-person-${kind}="${index}"]`;

function makeSeed(scenario, width) {
    const chatId = `cg-participants-${scenario.id}-${width}`;
    const roster = { version: 1, cardType: 'multi', revision: 'original-roster', people, selectedIds: people.map(person => person.id) };
    const bank = { version: 3, chatId, archiveRevision: `${chatId}-revision`, characterName: cardName, userName,
        participantsV1: roster, archiveName: '合成多人旧档案', archiveSummary: '仅用于本地浏览器验收。', createdAt: 1, updatedAt: 1,
        memories: [{ id: 'M001', title: '庭院栽花', summary: '三位住户在庭院照料花苗。', anchors: ['庭院'] }] };
    const item = { id: 'visual', title: '庭院照片', date: '2008/05/10', desc: '原相册正文  不得改变。', cgDesc: originalScene,
        imagePrompt: originalScene, unlocked: true, category: '日常', visualSeed: ['花苗'] };
    const cache = { chatId, archiveRevision: bank.archiveRevision, participantsV1: roster,
        album: { kind: 'album', chatId, archiveRevision: bank.archiveRevision, title: '旧相册',
            entries: [item, { ...item, id: 'untouched', title: '另一张旧图', cgImage: unchangedImage }],
            selectedId: 'visual', page: 1, pageSize: 6, category: '全部' },
        cabinet: { kind: 'cabinet', chatId, archiveRevision: bank.archiveRevision, items: [{ id: 'keep', text: 'OTHER_MODE_KEEP' }] } };
    const v1 = { chatId, char: '(old black hair:1.3), old blue eyes', user: 'white hair, green eyes', manual: true, updatedAt: 1,
        identity: JSON.stringify([chatId, '0', 'fixture.png', cardName, userName]) };
    return { scenario, width, chatId, cardName, userName, customName, customTag, tags, bank, cache, v1, changedRoster,
        newPath: `/user/images/fixture/generated-${scenario.id}-${width}.png`,
        metadata: { heartbeatMemoriesArchiveV3: bank, heartbeatMemoriesTheaterV3: cache, heartbeatMemoriesCastLooksV1: v1 } };
}

function hostPage(seed, build) {
    return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<style>*{box-sizing:border-box}html,body{margin:0;width:100%;font-family:sans-serif;background:#eee}#extensions_settings2,#extensionsMenu{padding:8px}.list-group-item{display:flex;gap:8px;padding:8px}.menu_button{font:inherit}</style>
</head><body><div id="extensions_settings2"><details><summary>其他扩展</summary></details></div><div id="extensionsMenu"></div><script>
const seed=${JSON.stringify(seed).replace(/</g, '\\u003c')};
const copy=value=>value==null?value:JSON.parse(JSON.stringify(value));
const metadataKey='cg-participants-host-metadata',settingsKey='cg-participants-host-settings';
const calls={images:[],texts:[],metadataSave:0,settingsSave:0,notices:[]};
const pending=new Map(),listeners=new Map();
const profile={id:'cg-participants-fixture',name:'Synthetic profile',mode:'cc',api:'openai',model:'fixture-model','secret-id':'synthetic-only'};
const context={characterId:0,groupId:null,chatId:seed.chatId,name1:seed.userName,name2:seed.cardName,
 characters:[{name:seed.cardName,avatar:'fixture.png',data:{name:seed.cardName,description:'SINGLE_CARD_SENTINEL。合成沙盒卡。',personality:'按人物条目行动。'}}],
 chat:[{is_user:true,name:seed.userName,mes:'三位住户在庭院照料花苗。'}],powerUserSettings:{persona_description:'USER_PERSONA_SENTINEL。合成用户资料。'},
 chatMetadata:JSON.parse(localStorage.getItem(metadataKey)||JSON.stringify(seed.metadata)),
 extensionSettings:JSON.parse(localStorage.getItem(settingsKey)||JSON.stringify({heartbeatMemories:{apiConnectionMode:'profile',connectionProfileId:profile.id,
  useCurrentChatExternalMemory:false,useActivatedWorldInfo:false,cgPromptFormat:'nai5-natural',maxTokens:12000},connectionManager:{profiles:[profile]}})),
 getCurrentChatId(){return this.chatId},getCharacterCardFields(){return copy(this.characters[0].data)},
 getRequestHeaders:()=>({'Content-Type':'application/json'}),getTokenCountAsync:async()=>100,
 saveMetadataDebounced(){calls.metadataSave++;localStorage.setItem(metadataKey,JSON.stringify(context.chatMetadata))},
 getWorldInfoNames:()=>[],loadWorldInfo:async()=>({entries:{}}),
 saveSettingsDebounced(){calls.settingsSave++;localStorage.setItem(settingsKey,JSON.stringify(context.extensionSettings))},
 eventTypes:{},eventSource:{on:(key,fn)=>listeners.set(key,fn),off:key=>listeners.delete(key)},
 ConnectionManagerRequestService:{validateProfile:()=>({selected:'openai',source:'openai'}),
  async sendRequest(profileId,messages,outputTokens,options,overridePayload){
   const payload={secret_id:profile['secret-id'],model:profile.model,...overridePayload};
   if(profileId!==profile.id||payload.secret_id!=='synthetic-only')throw new Error('Unexpected synthetic profile route');
   const prompt=messages.map(message=>String(message.content||'')).join('\\n');
   const marker='UNTRUSTED_CG_APPEARANCE_JSON:\\n';
   if(!prompt.includes(marker))throw new Error('Expected one CG appearance request');
   const appearance=JSON.parse(prompt.slice(prompt.indexOf(marker)+marker.length).split('\\n')[0]);
   calls.texts.push({profileId,messages:copy(messages),outputTokens,payload:copy(payload),appearance:copy(appearance),hasSignal:options?.signal instanceof AbortSignal});
   if(calls.texts.length!==1)throw new Error('An explicit reconceive must send exactly one text request');
   const tagById={'person-left':seed.tags[0],'person-right':seed.tags[2]};
   return {content:JSON.stringify({imagePrompt:seed.scenario.finalScene,sceneTags:${JSON.stringify(tagScene)},flatPrompt:seed.scenario.replyFlat,
    characters:appearance.map(person=>({participantId:person.participantId,tag:tagById[person.participantId]||seed.customTag,nl:''}))})};
  }},
};
globalThis.SillyTavern={getContext:()=>context};
globalThis.toastr=Object.fromEntries(['error','warning','info','success'].map(level=>[level,(...args)=>calls.notices.push({level,message:args.map(String).join(' ')})]));
globalThis.STBaiBaiImage={apiVersion:1,capabilities:{generate:true,saveToGallery:true},
 getBackendStatus:()=>({configured:true,backend:'nai',supportsCharacters:true}),
 generate(request,options){const id=calls.images.length+1;calls.images.push({id,request:copy(request),hasAbortSignal:options?.signal instanceof AbortSignal});
  return new Promise((resolve,reject)=>pending.set(id,{resolve,reject}));}};
async function decodeCache(stored){return stored?.format==='gzip-base64-v1'
 ?JSON.parse(await new Response(new Blob([Uint8Array.from(atob(stored.data),ch=>ch.charCodeAt(0))]).stream().pipeThrough(new DecompressionStream('gzip'))).text()):copy(stored)}
async function snapshot(metadata=context.chatMetadata){const cache=await decodeCache(metadata.heartbeatMemoriesTheaterV3);return {bank:copy(metadata.heartbeatMemoriesArchiveV3),cache,
 image:copy(cache?.album?.entries?.find(item=>item.id==='visual')?.cgImage||null),v1:copy(metadata.heartbeatMemoriesCastLooksV1),looks:copy(metadata.heartbeatMemoriesParticipantLooksV1)}}
function nativeDb(){return new Promise((resolve,reject)=>{const request=indexedDB.open('heartbeatMemoriesArchiveBackupsV1');
 request.onerror=()=>reject(request.error);request.onupgradeneeded=()=>{request.transaction.abort();reject(new Error('The real plugin has not created its canonical database'))};request.onsuccess=()=>resolve(request.result)})}
async function nativeRecord(){const db=await nativeDb();try{return await new Promise((resolve,reject)=>{const transaction=db.transaction('archives','readonly');const request=transaction.objectStore('archives').getAll();
 request.onerror=()=>reject(request.error);request.onsuccess=()=>{const rows=request.result.filter(row=>row.chatId===seed.chatId&&!row.deleted);if(rows.length!==1)reject(new Error('Expected exactly one canonical fixture archive'));else resolve(copy(rows[0]))}})}finally{db.close()}}
async function canonical(){const record=await nativeRecord();const cache=await decodeCache(record.cache);return {entryId:record.entryId,bank:copy(record.memory),cache,image:copy(cache?.album?.entries?.find(item=>item.id==='visual')?.cgImage||null)}}
// Test fixture mutation of an external storage boundary, after the UI flow has
// finished. This is not an application hook and invokes no production helper.
async function replaceCanonicalRoster(){const record=await nativeRecord();const cache=await decodeCache(record.cache);
 cache.participantsV1=copy(seed.changedRoster);record.memory.participantsV1=copy(seed.changedRoster);record.cache=cache;record.updatedAt=Date.now();
 const db=await nativeDb();try{await new Promise((resolve,reject)=>{const transaction=db.transaction('archives','readwrite');transaction.objectStore('archives').put(record);
 transaction.oncomplete=resolve;transaction.onerror=()=>reject(transaction.error);transaction.onabort=()=>reject(transaction.error||new Error('Synthetic roster mutation aborted'))})}finally{db.close()}
 context.chatMetadata.heartbeatMemoriesArchiveV3=copy(record.memory);context.chatMetadata.heartbeatMemoriesTheaterV3=copy(cache);context.saveMetadataDebounced();return canonical()}
globalThis.__fixture={calls,snapshot,saved:()=>snapshot(JSON.parse(localStorage.getItem(metadataKey)||'null')||seed.metadata),canonical,replaceCanonicalRoster,
 settle(id){const task=pending.get(id);if(!task)throw new Error('No pending synthetic image '+id);pending.delete(id);task.resolve({path:seed.newPath})}};
</script><script type="module" src="${prefix}${build}"></script></body></html>`;
}

const routes = { runtime: [], sourceModules: [], api: [], external: [], unexpected: [] };
let activeSeed, build;
const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aH9sAAAAASUVORK5CYII=', 'base64');
const server = http.createServer(async (request, response) => {
    const url = new URL(request.url || '/', 'http://127.0.0.1');
    response.setHeader('Cache-Control', 'no-store');
    if (url.pathname.startsWith(prefix)) {
        const relative = decodeURIComponent(url.pathname.slice(prefix.length)), target = path.resolve(repoRoot, relative);
        if (!target.startsWith(repoRoot + path.sep)) { response.writeHead(403); response.end(); return; }
        if (relative.startsWith('src/')) { routes.sourceModules.push(relative); response.writeHead(403); response.end(); return; }
        try {
            const bytes = await readFile(target);
            if (relative === 'dist/heartbeatMemories.bundle.js') routes.runtime.push(request.url);
            response.setHeader('Content-Type', target.endsWith('.json') ? 'application/json' : 'text/javascript; charset=utf-8'); response.end(bytes);
        } catch { routes.unexpected.push(url.pathname); response.writeHead(404); response.end(); }
        return;
    }
    if (url.pathname.startsWith('/api/')) {
        let body = ''; for await (const chunk of request) body += chunk;
        routes.api.push({ path: url.pathname, method: request.method, body });
        response.writeHead(500, { 'Content-Type': 'application/json' }); response.end(JSON.stringify({ error: 'No real host API is allowed' })); return;
    }
    if (url.pathname.startsWith('/user/images/fixture/') || url.pathname === '/thumbnail' || url.pathname === '/characters/fixture.png') {
        response.setHeader('Content-Type', 'image/png'); response.end(png); return;
    }
    if (url.pathname === '/favicon.ico') { response.writeHead(204); response.end(); return; }
    if (url.pathname !== '/' || !activeSeed) { routes.unexpected.push(url.pathname); response.writeHead(404); response.end(); return; }
    response.setHeader('Content-Type', 'text/html; charset=utf-8'); response.end(hostPage(activeSeed, build));
});

async function openAlbum(page) {
    await page.locator(selectors.menu).waitFor({ state: 'visible' }); await page.locator(selectors.menu).click();
    await page.locator(selectors.content).click(); await page.locator(selectors.memoryGroup).click(); await page.locator(selectors.album).click();
    await page.locator(selectors.settings).waitFor({ state: 'visible' });
}
async function openEditor(page) { await page.locator(selectors.settings).click(); await page.locator(selectors.dialog).waitFor({ state: 'visible' }); }
async function rows(page) {
    return page.locator(selectors.rows).evaluateAll(nodes => nodes.map(node => ({
        selected: node.querySelector('[data-rmt-cg-person-selected]').checked,
        name: node.querySelector('[data-rmt-cg-person-name]').value, tag: node.querySelector('[data-rmt-cg-person-tag]').value,
        source: node.querySelector('small')?.textContent || '',
    })));
}
async function calls(page) { return page.evaluate(() => __fixture.calls); }
function assertUnchanged(value, seed, { image = false, roster = false } = {}) {
    assert.deepEqual(value.bank, roster ? { ...seed.bank, participantsV1: changedRoster } : seed.bank, 'archive text and all unrelated facts stay unchanged');
    assert.deepEqual(value.cache.cabinet, seed.cache.cabinet, 'other module remains unchanged');
    assert.deepEqual(value.cache.album.entries[1], seed.cache.album.entries[1], 'other saved image remains unchanged');
    assert.deepEqual(value.cache.participantsV1, roster ? changedRoster : seed.bank.participantsV1, 'editing picture cast does not edit archive participants');
    const omitImage = item => Object.fromEntries(Object.entries(item).filter(([key]) => key !== 'cgImage'));
    assert.deepEqual(omitImage(value.cache.album.entries[0]), seed.cache.album.entries[0], 'original album prose and authored prompt stay unchanged');
    if (!image) assert.equal(value.image, null, 'no image is persisted before the public API completes');
    if (Object.hasOwn(value, 'v1')) assert.deepEqual(value.v1, seed.v1, 'legacy char/user V1 bytes remain unchanged');
}
function expectedPayload(scenario) {
    return { prompt: scenario.finalScene, nl: '', size: 'landscape', save: true, character: cardName,
        characters: [{ name: '同名', tag: tags[0] }, { name: '同名', tag: tags[2] }, { name: customName, tag: customTag }] };
}
function expectedPreview(scenario) {
    return `prompt:\n${scenario.finalScene}\n\n人物标签：\n同名: ${tags[0]}\n同名: ${tags[2]}\n${customName}: ${customTag}`;
}
function expectedMetadata(scenario, customId) {
    return { sceneTags: tagScene, characters: [
        { participantId: people[0].id, name: people[0].name, tag: tags[0], nl: '' },
        { participantId: people[2].id, name: people[2].name, tag: tags[2], nl: '' },
        { participantId: customId, name: customName, tag: customTag, nl: '' },
    ], castSnapshot: { version: 1, people: [people[0], people[2], { id: customId, name: customName, sourceRefs: [] }] }, promptFormat: scenario.format };
}


const results = [], report = {ok:false, artifactHashes, results, note:'Synthetic host, real index and dist. Gallery uses real recovery renderer with action-group samples; empty modules are navigation checks, not generated content acceptance.'};
const groups = ['rmt-actions','rmt-mode-actions','rmt-filter','rmt-cg-card-actions','rmt-cg-prompt-actions','rmt-manage-actions','rmt-mail-actions','rmt-heart-top-actions','rmt-room-heading-actions','rmt-travel-dialogue-actions','rmt-ending-confession-actions','rmt-current-archive-actions'];
let browser;
await mkdir(outputDir,{recursive:true});
build=JSON.parse(await readFile(path.join(repoRoot,'manifest.json'),'utf8')).js;
for(const name of artifactNames) artifactHashes[name]=sha256(await readFile(path.join(repoRoot,name)));
const {archiveRecoveryHtml}=await import(new URL('../src/ui/recoveryView.js', 'file:///'+repoRoot.replaceAll('\\','/')+'/tools/run.mjs'));
const recovery=archiveRecoveryHtml({completed:2,notice:'已写好的内容已保留，可以继续生成或导出。',drafts:[{draftId:'draft-1'}]});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const baseUrl=`http://127.0.0.1:${server.address().port}`;
try {
 const {chromium}=require('playwright'); browser=await chromium.launch({headless:true,executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || chromium.executablePath()});
 for(const width of viewports){
  activeSeed=makeSeed(scenarios.natural,width);
  const ctx=await browser.newContext({viewport:{width,height:900}}), page=await ctx.newPage();
  page.setDefaultTimeout(12000);
  const row={width,ok:false,pages:[],errors:[],violations:[]};results.push(row);
  page.on('pageerror',e=>row.errors.push(e.message));page.on('dialog',d=>d.dismiss());
  await page.route('**/*',r=>new URL(r.request().url()).origin===baseUrl?r.continue():r.abort());
  async function inspect(name,shot=false){
   const values=await page.locator('#heartbeat_memories_overlay').evaluate(root=>{
    const visible=n=>n.getClientRects().length && getComputedStyle(n).visibility!=='hidden';
    const bounds=root.getBoundingClientRect();
    return [...root.querySelectorAll('.rmt-btn,.rmt-workspace-tabs button,.rmt-workspace-groups button')].filter(visible).map(b=>{
     const r=b.getBoundingClientRect(),style=getComputedStyle(b);return {text:b.textContent.trim(),width:r.width,height:r.height,overflow:b.scrollWidth>b.clientWidth+2,outside:r.left<bounds.left-2||r.right>bounds.right+2,font:style.fontSize};
    });
   });
   row.pages.push({name,buttons:values});
   row.violations.push(...values.filter(v=>v.overflow||v.outside).map(v=>({page:name,...v})));
   if(shot)await page.screenshot({path:path.join(outputDir,`${width}-${name}.png`)});
  }
  try{
   await page.goto(baseUrl);await openAlbum(page);await inspect('album',true);
   await openEditor(page);await inspect('cg-editor',true);await page.locator(selectors.close).click();
   for(const tab of ['settings','archive','content']){
    await page.locator(`.rmt-workspace-tabs [data-rmt-workspace-tab="${tab}"]`).click();await inspect(tab,true);
   }
   for(const group of ['memory','life','interaction','stories']){
    await page.locator(selectors.content).click();await page.locator(`[data-rmt-workspace-group="${group}"]`).click();
    const routesHere=await page.locator('.rmt-workspace-portals [data-rmt-workspace-route]').evaluateAll(nodes=>[...new Set(nodes.map(n=>n.dataset.rmtWorkspaceRoute))]);
    for(const routeName of routesHere){
     await page.locator(selectors.content).click();await page.locator(`[data-rmt-workspace-group="${group}"]`).click();
     await page.locator(`.rmt-workspace-portals [data-rmt-workspace-route="${routeName}"]`).first().click();await inspect('route-'+routeName);
    }
   }
   await page.evaluate(({recovery,groups})=>{
    const body=document.querySelector('#heartbeat_memories_overlay .rmt-body');
    body.innerHTML='<section class="rmt-workspace-page"><h2>操作区排版校验</h2>'+recovery+groups.map(c=>'<section style="margin:20px 0"><h3>'+c+'</h3><div class="'+c+'"><button class="rmt-btn">继续生成</button><button class="rmt-btn">导出已生成的图文内容</button><button class="rmt-btn">为这张图片重新选择人物外貌来源</button></div></section>').join('')+'</section>';
   },{recovery,groups});
   await inspect('gallery',true);
   row.wrapFailures=await page.locator('.rmt-recovery-status button').evaluateAll(nodes=>nodes.filter(n=>n.getBoundingClientRect().height>50).map(n=>({text:n.textContent,height:n.getBoundingClientRect().height})));
   const gapFailures=await page.locator('.rmt-recovery-status button').evaluateAll(nodes=>{
    const boxes=nodes.map(n=>({text:n.textContent,rect:n.getBoundingClientRect()})),fail=[];
    for(let a=0;a<boxes.length;a++)for(let b=a+1;b<boxes.length;b++){
     const x=boxes[a].rect,y=boxes[b].rect,dx=Math.max(x.left-y.right,y.left-x.right,0),dy=Math.max(x.top-y.bottom,y.top-x.bottom,0);
     if(dx<7&&dy<7)fail.push([boxes[a].text,boxes[b].text,dx,dy]);
    }return fail;
   });row.gapFailures=gapFailures;
   await page.addStyleTag({content:'#heartbeat_memories_overlay.rmt-workspace[data-rmt-theme-mode] .rmt-body button.rmt-btn{font-size:22.5px!important}'});
   await inspect('gallery-large-text',true);
   assert.deepEqual(gapFailures,[],'recovery buttons require a visible gap');
   assert.deepEqual(row.wrapFailures,[],'sample recovery labels fit on one line at normal font size');
   assert.deepEqual(row.violations,[],'capsules must fit without clipped labels');
   assert.deepEqual(row.errors,[]);const c=await calls(page);assert.equal(c.texts.length,0);assert.equal(c.images.length,0);row.ok=true;
  }catch(e){row.error=e.message;await page.screenshot({path:path.join(outputDir,`${width}-failure.png`)});}finally{await ctx.close();}
 }
 report.ok=results.every(r=>r.ok);if(!report.ok)process.exitCode=1;
}finally{await browser?.close();await new Promise(r=>server.close(r));await writeFile(path.join(outputDir,'report.json'),JSON.stringify(report,null,2));console.log(JSON.stringify({ok:report.ok,results:results.map(r=>({width:r.width,ok:r.ok,error:r.error,violations:r.violations.length,pages:r.pages.length}))}));}
