"""Offline real-DOM fallback, not native IndexedDB. No URLs are navigated.
Uses the actual distribution bundle and production UI handler, with explicitly
simulated storage/host/provider. Playwright injects source into about:blank;
Chromium's managed URL restrictions are neither changed nor bypassed.
"""
import argparse, json, pathlib, re, time
from playwright.sync_api import sync_playwright
p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args()
root=pathlib.Path(__file__).resolve().parent.parent;out=pathlib.Path(a.out);out.mkdir(parents=True,exist_ok=True)
bundle=(root/'dist/heartbeatMemories.bundle.js').read_text()
bundle=re.sub(r'^export const .*;$','',bundle,flags=re.M)
host=(root/'tools/r8422-browser-host.mjs').read_text()
host=re.sub(r"^import \* as (\w+) from '../src/([^']+)';$", lambda m:'const '+m[1]+' = __m_'+re.sub(r'[^A-Za-z0-9_$]','_',m[2])+';',host,flags=re.M)
host=host.replace("import { state } from '../src/core/state.js';",'const state=__m_core_state_js.state;')
# Injection affects the TEST harness only, not production modules or bundle.
host=host.replace('const clone = value => structuredClone(value);', '''const clone = value => structuredClone(value);
const store=window.__fixtureStore;
backup.setArchiveBackupBackendForTests({read:async entry=>clone(store.backup[entry.entryId||context.archiveIndexEntryId(entry)]||null),
put:async (record,expected,options={})=>{if(options.stillCurrent?.()===false)throw new DOMException('Changed','AbortError');
const old=store.backup[record.entryId];if(expected?.present===true&&old&&old.archiveRevision!==expected.revision)throw new Error('fixture CAS');
store.backup[record.entryId]=clone(record);return true;},delete:async()=>{throw new Error('Deletion is not authorized');}});
ledger.setMemorySourceLedgerBackendForTests({read:async scope=>clone(store.ledger[scope.key]||null),write:async row=>{store.ledger[row.scope.key]=clone(row);return true;},delete:async()=>{throw new Error('Source deletion not authorized');}});
''')
results={'environment':'Real Chromium DOM and dist bundle; simulated host, provider, tokenizer, localStorage and IDB backend. NO native IndexedDB or live host/model.', 'cases':[]}
bootstrap='''(saved)=>{window.__fixtureStore=saved||{local:{},backup:{},ledger:{}};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>window.__fixtureStore.local[k]??null,setItem:(k,v)=>{window.__fixtureStore.local[k]=String(v)},removeItem:k=>{delete window.__fixtureStore.local[k]}}});}'''
try:
 with sync_playwright() as pw:
  browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);results['browser']=browser.version
  context=browser.new_context(viewport={'width':1280,'height':900});context.route('**/*',lambda r:r.abort())
  saved=None;selector='[data-rmt-action="current-archive-import"], [data-rmt-action="import-memory"]'
  for batch in range(1,4):
   page=context.new_page();page.set_content('<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head><body></body></html>')
   page.evaluate(bootstrap,saved)
   page.on('pageerror',lambda e:results.setdefault('pageErrors',[]).append(str(e)))
   page.add_script_tag(type='module',content=bundle+'\n(async()=>{'+host+'})().catch(e=>{window.fixtureError=String(e.stack)})')
   page.wait_for_function('window.fixture?.ready || window.fixtureError',timeout=30000)
   err=page.evaluate('window.fixtureError||fixture.errors');assert not err,err
   if batch==1:
    page.locator('[data-rmt-action="library-home"]').first.click()
    page.wait_for_selector('[data-rmt-action="current-archive-import"]')
   (out/f'batch-{batch}-initial.html').write_text(page.content())
   assert page.locator(selector).count(),'Production button not rendered'
   started=time.perf_counter()
   control='[data-rmt-archive-recovery="import"]' if batch==3 else selector
   page.locator(control).first.click()
   try:
    page.wait_for_function('(n)=>!fixture.state.busy&&fixture.ctx.chatMetadata.heartbeatMemoriesArchiveV3?.archiveImportProgress?.nextBatch===n',arg=batch,timeout=12000)
   except Exception:
    results['failureSnapshot']=page.evaluate('fixture.snapshot()');(out/'failed-page.html').write_text(page.content());raise
   snap=page.evaluate('fixture.snapshot()');assert snap['cursor']==snap['backupCursor']==batch,snap
   assert not snap['errors'],snap['errors']
   results['cases'].append({'name':f'real-DOM-button / simulated durable backend / page replacement / batch-{batch}','pass':True,'ms':round((time.perf_counter()-started)*1000),'snapshot':snap})
   if batch==1:
    for width,height,theme,label in [(1280,900,'default','desktop-light'),(1280,900,'night','desktop-dark'),(390,844,'default','mobile-light'),(390,844,'night','mobile-dark')]:
     page.set_viewport_size({'width':width,'height':height});page.evaluate('(x)=>fixture.theme(x)',theme)
     banner=page.locator('.rmt-recovery-status').first;banner.scroll_into_view_if_needed();box=banner.bounding_box()
     assert box and box['width']>100 and box['x']>=-1 and box['x']+box['width']<=width+1,(label,box)
     page.screenshot(path=str(out/(label+'.png')),full_page=True)
     results['cases'].append({'name':label+' (viewport simulation, NOT physical device)','pass':True,'box':box})
   count=len(snap['requests']);page.wait_for_timeout(100);assert page.evaluate('fixture.requests.length')==count
   saved=page.evaluate('__fixtureStore');page.close()
  sent=[i for r in snap['requests'] for i in r['ids']];assert len(sent)==len(set(sent))==610,(len(sent),len(set(sent)))
  assert all(r['responseLength']==12000 for r in snap['requests'])
  results['cases'].append({'name':'610 unique sources / three clicks / full page destruction / output unchanged','pass':True})
  context.close();browser.close()
except Exception as e:
 results['error']=str(e)
 raise
finally:
 (out/'browser-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print(json.dumps({'cases':len(results['cases']),'passed':sum(c['pass'] for c in results['cases'])}))
