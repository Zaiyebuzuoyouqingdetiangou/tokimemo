# 手帐页真实浏览器检查（r84.174）：需要 Python playwright + Chromium。在仓库根目录运行：python3 tools/check-journal-browser.py
import http.server,threading,os,json,sys
from playwright.sync_api import sync_playwright
root=os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
class H(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a):pass
    def translate_path(self,path):
        if path.startswith('/page.html'): return os.path.join(os.path.dirname(os.path.abspath(__file__)), 'check-journal-browser.html')
        return os.path.join(root,path.lstrip('/').split('?')[0])
srv=http.server.ThreadingHTTPServer(('127.0.0.1',8766),H);threading.Thread(target=srv.serve_forever,daemon=True).start()
out={}
def ready(pg):
    pg.goto('http://127.0.0.1:8766/page.html');pg.wait_for_function('window.__done',timeout=20000)
    pg.wait_for_function('!document.querySelector(".rmt-journal-add").hidden',timeout=10000)
with sync_playwright() as p:
    b=p.chromium.launch();ctx=b.new_context(viewport={'width':390,'height':900});pg=ctx.new_page()
    errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    ready(pg)
    pg.click('.rmt-journal-add>summary')
    pg.fill('[data-journal-title]','庙檐下躲雨的那晚'); pg.click('[data-journal-whole]'); pg.click('[data-journal-save]')
    pg.wait_for_function('document.querySelector(".rmt-journal-status").textContent.includes("已保存")')
    pg.click('.rmt-journal-add>summary'); pg.fill('[data-journal-title]','第二页'); pg.click('[data-journal-whole]'); pg.click('[data-journal-save]')
    pg.wait_for_function('document.querySelectorAll("[data-journal-filter]").length>0 && document.querySelector("[data-journal-count]").textContent==="2 / 2"')
    out['after_two']=pg.evaluate('({count:document.querySelector("[data-journal-count]").textContent,title:document.querySelector(".rmt-journal-page h3").textContent,addOpen:document.querySelector(".rmt-journal-add").open})')
    pg.click('[data-journal-prev]'); out['prev']=pg.evaluate('document.querySelector(".rmt-journal-page h3").textContent')
    # swipe left -> next
    box=pg.query_selector('.rmt-journal-page').bounding_box(); y=box['y']+box['height']/2
    pg.mouse.move(box['x']+300,y); pg.mouse.down(); pg.mouse.move(box['x']+120,y,steps=5); pg.mouse.up()
    out['swipe']=pg.evaluate('document.querySelector(".rmt-journal-page h3").textContent')
    pg.click('[data-journal-fav]'); pg.wait_for_function('document.querySelector("[data-journal-fav]").getAttribute("aria-pressed")==="true"')
    pg.click('.rmt-journal-page-more>summary'); pg.click('[data-journal-note-open]'); pg.fill('[data-journal-note-text]','那天的篝火好暖。'); pg.click('[data-journal-note-save]')
    pg.wait_for_function('document.querySelector(".rmt-journal-note")')
    pg.click('[data-journal-filter="fav"]'); out['fav_filter']=pg.evaluate('({count:document.querySelector("[data-journal-count]").textContent,pager:document.querySelector("[data-journal-pager]").hidden,title:document.querySelector(".rmt-journal-page h3").textContent})')
    pg.screenshot(path='journal-phone.png',full_page=True)
    # reload persistence
    ready(pg); pg.wait_for_function('document.querySelector(".rmt-journal-page")')
    out['reload']=pg.evaluate('({pages:document.querySelector("[data-journal-filter=\\"all\\"]").textContent,note:document.querySelector(".rmt-journal-note p")?.textContent||"",fav:!!document.querySelector("[data-journal-filter=\\"fav\\"]")})')
    pg.click('.rmt-journal-note-remove'); pg.wait_for_function('!document.querySelector(".rmt-journal-note")'); out['note_removed']=True
    pg.click('.rmt-journal-more>summary'); pg.wait_for_timeout(100); out['more_open']=pg.evaluate('document.querySelector(".rmt-journal-more").open')
    # r84.175：从聊天摘一句、换版式、夹进手帐
    pg.click('.rmt-journal-add>summary'); pg.select_option('[data-journal-source]','chat-quote')
    pg.fill('[data-journal-quote-text]','差一点就把发绳泡烂了。'); pg.fill('[data-journal-title]','摘句页'); pg.click('[data-journal-quote-preview]'); pg.click('[data-journal-save]')
    pg.wait_for_function('document.querySelector(".rmt-journal-page h3")?.textContent==="摘句页"')
    out['quote']=pg.evaluate('document.querySelector(".rmt-journal-prose").textContent')
    pg.click('.rmt-journal-page-more>summary'); pg.select_option('[data-journal-layout]','timeline')
    pg.wait_for_function('document.querySelector(".rmt-journal-page").classList.contains("rmt-journal-layout-timeline")'); out['layout']='timeline'
    ok=pg.evaluate("import('/src/ui/journalClip.js').then(m=>m.clipToJournal(JSON.stringify({mode:'album',id:'x',title:'雨夜合照',url:'/user/images/a.png',text:''})))")
    ready(pg); pg.wait_for_function('document.querySelector(".rmt-journal-page")')
    out['clip']={'ok':ok,'title':pg.evaluate('document.querySelector(".rmt-journal-page h3").textContent'),'count':pg.evaluate('document.querySelector("[data-journal-filter=\\"all\\"]").textContent')}
    out['errors']=errs
    b.close()
srv.shutdown()
print(json.dumps(out,ensure_ascii=False))
