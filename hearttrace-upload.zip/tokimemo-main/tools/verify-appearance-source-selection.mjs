// Actual index -> bundled runtime; synthetic host/provider and native IndexedDB; no real paid request.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import http from 'node:http';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const { chromium } = createRequire(import.meta.url)('playwright');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const output = path.resolve(process.env.APPEARANCE_OUTPUT_DIR || path.join(root, 'artifacts', 'appearance-source-selection'));
const prefix = '/scripts/extensions/third-party/hearttrace/';
const build = JSON.parse(await readFile(path.join(root, 'manifest.json'), 'utf8')).js;
const sha = value => createHash('sha256').update(value).digest('hex');
const hashes = Object.fromEntries(await Promise.all(['index.js', 'dist/heartbeatMemories.bundle.js'].map(async file => [file, sha(await readFile(path.join(root, file)))])));
const widths = (process.env.APPEARANCE_WIDTHS || '390,1280').split(',').map(Number);
const oldImages = (process.env.APPEARANCE_OLD_IMAGES || 'false,true').split(',').map(value => value === 'true');
function seed(width, oldImage) {
    const chatId = `appearance-source-${width}-${oldImage}`;
    const person = { id: 'npc-a', name: '同名', sourceRefs: [{ world: '人物书', uid: '8', title: '同名', content: '<character_information character="同名">OLD_SOURCE 棕色短发。</character_information>' }] };
    const bank = { version: 3, chatId, archiveRevision: chatId + '-A', characterName: '多人沙盒', userName: '同名',
        archiveName: '人物来源测试', archiveSummary: '雨棚下的共同回忆。', createdAt: 1, updatedAt: 1,
        memories: [{ id: 'M001', title: '雨棚', summary: '几人在雨棚下聊天。', anchors: ['雨棚'], participants: ['同名'] }],
        participantsV1: {version: 1, cardType: 'multi', revision: 'cast-1', people: [person], selectedIds: [person.id]} };
    const image = {url: '/user/images/fixture/old.png', prompt: 'OLD_SAVED_PROMPT', provider: 'baibai-image', generatedAt: 1,
        promptMetadata: {promptFormat: 'nai5-natural', castSnapshot: {version:1,people:[{...person,sourceRefs:[]}]}, characters:[], sceneTags:'old rain'}};
    const item = {id:'CG01',title:'雨棚回忆',desc:'雨棚下的几人。',cgDesc:'雨棚下的几人。',imagePrompt:'雨棚下的几人。',unlocked:true,comments:['看这张照片。'],
        sourceMemoryIds:['M001'],sourceMemoryAnchor:'雨棚',...(oldImage?{cgImage:image}:{})};
    const cache = {chatId,archiveRevision:bank.archiveRevision,participantsV1:structuredClone(bank.participantsV1),
        album:{kind:'album',chatId,archiveRevision:bank.archiveRevision,category:'全部',page:1,pageSize:6,selectedId:item.id,entries:[item]}};
    return {mode:'appearance',group:'memory',width,oldImage,bank,cache,book:{entries:{
        8:{uid:8,comment:'同名',key:[],content:'<character_information character="同名">RESELECTED_SOURCE 棕色短发，小麦色皮肤。</character_information>'},
        9:{uid:9,comment:'另一人物',key:[],content:'<character_information>CANCELLED_SOURCE 红色卷发。</character_information>'}
    }}};
}
function hostPage(data) {
    return `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0;font-family:sans-serif}*{box-sizing:border-box}#extensionsMenu,#extensions_settings2{padding:8px}</style><div id="extensions_settings2"></div><div id="extensionsMenu"></div><script>
const seed=${JSON.stringify(data).replace(/</g, '\\u003c')};
const copy=x=>x==null?x:JSON.parse(JSON.stringify(x));
const metadataKey='partial-fixture-metadata',settingsKey='partial-fixture-settings',callKey='partial-fixture-calls';
if(!localStorage.getItem('heartbeatMemoriesWorkspaceUiV1'))localStorage.setItem('heartbeatMemoriesWorkspaceUiV1',JSON.stringify({expanded:true,startup:'content',restore:false,group:seed.group||'memory'}));
const calls=JSON.parse(localStorage.getItem(callKey)||'[]'),notices=[];
let phase=localStorage.getItem('partial-phase')||'prefix',releaseWait=null;
const profile={id:'partial-profile',name:'Synthetic profile',mode:'cc',api:'openai',model:'fixture-model','secret-id':'synthetic-only'};
const context={characterId:0,groupId:null,chatId:seed.bank.chatId,name1:seed.bank.userName,name2:seed.bank.characterName,
 characters:[{name:'林舟',avatar:'fixture.png',data:{name:'林舟',description:'现代都市，日常使用手机。认真整理书架，常用木盒、铅笔与便签。',personality:'认真克制。'}}],chat:[{is_user:true,name:'小月',mes:'林舟和小月在庭院共同栽花。'}],
 chatMetadata:JSON.parse(localStorage.getItem(metadataKey)||JSON.stringify({heartbeatMemoriesArchiveV3:seed.bank,heartbeatMemoriesTheaterV3:seed.cache})),
 powerUserSettings:{persona_description:'<user_profile>USER_PERSONA_SOURCE 银色长发，紫眼睛。</user_profile>'},extensionSettings:JSON.parse(localStorage.getItem(settingsKey)||JSON.stringify({heartbeatMemories:{apiConnectionMode:'profile',connectionProfileId:profile.id,useActivatedWorldInfo:false,useCurrentChatExternalMemory:false,maxTokens:12000,contextTagMode:'keep',retainedContextTags:['content']},connectionManager:{profiles:[profile]}})),
 getCurrentChatId(){return this.chatId},getCharacterCardFields(){return copy(this.characters[0].data)},getRequestHeaders:()=>({'Content-Type':'application/json'}),getTokenCountAsync:async()=>100,
 getWorldInfoNames:()=>['人物书'],loadWorldInfo:async()=>copy(seed.book),saveMetadataDebounced(){localStorage.setItem(metadataKey,JSON.stringify(context.chatMetadata))},saveSettingsDebounced(){localStorage.setItem(settingsKey,JSON.stringify(context.extensionSettings))},eventTypes:{},eventSource:{on(){},off(){}},
 ConnectionManagerRequestService:{validateProfile:()=>({selected:'openai',source:'openai'}),async sendRequest(profileId,messages,outputTokens,options,overridePayload){
  const payload={secret_id:profile['secret-id'],model:profile.model,...overridePayload};if(profileId!==profile.id||payload.secret_id!=='synthetic-only')throw new Error('Unexpected route');
  const text=messages.map(item=>item.content||'').join('\\n');calls.push({messages:copy(messages),outputTokens,phase,hasSignal:options?.signal instanceof AbortSignal});localStorage.setItem(callKey,JSON.stringify(calls));
  const encoded=text.split('UNTRUSTED_CG_APPEARANCE_JSON:\\n')[1];
  const rows=JSON.parse(encoded.split('\\n\\n')[0]);
  return {content:JSON.stringify({imagePrompt:'雨棚下的人物。',sceneTags:'rain, canopy',flatPrompt:'雨棚下的人物。',characters:rows.filter(row=>row.description||row.knownTag||row.knownNl).map(row=>({participantId:row.participantId,tag:row.knownTag||'',nl:row.description.includes('USER_PERSONA_SOURCE')?'银色长发，紫眼睛。':'棕色短发，小麦色皮肤。'}))})};
 }}};
const imageCalls=[];
globalThis.STBaiBaiImage={apiVersion:1,capabilities:{generate:true,saveToGallery:true},getBackendStatus:()=>({configured:true,backend:'nai',supportsCharacters:true}),async generate(request){imageCalls.push(copy(request));return {path:'/user/images/fixture/appearance.png'}}};
globalThis.SillyTavern={getContext:()=>context};globalThis.toastr=Object.fromEntries(['info','success','warning','error'].map(level=>[level,(...args)=>notices.push({level,message:args.map(String).join(' ')})]));
async function decode(value){if(value?.format!=='gzip-base64-v1')return copy(value);return JSON.parse(await new Response(new Blob([Uint8Array.from(atob(value.data),x=>x.charCodeAt(0))]).stream().pipeThrough(new DecompressionStream('gzip'))).text())}
async function snapshot(){return {bank:copy(context.chatMetadata.heartbeatMemoriesArchiveV3),cache:await decode(context.chatMetadata.heartbeatMemoriesTheaterV3),calls:copy(calls),notices:copy(notices)}}
async function canonical(){if(!(await indexedDB.databases()).some(row=>row.name==='heartbeatMemoriesArchiveBackupsV1'))return [];const db=await new Promise((resolve,reject)=>{const r=indexedDB.open('heartbeatMemoriesArchiveBackupsV1');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)});try{const rows=await new Promise((resolve,reject)=>{const r=db.transaction('archives','readonly').objectStore('archives').getAll();r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)});return await Promise.all(rows.map(async row=>({...row,cache:await decode(row.cache)})))}finally{db.close()}}
globalThis.__fixture={snapshot,canonical,imageCalls};
</script><script type="module" src="${prefix}${build}"></script>`;
}
let activeSeed;
const routes = { bundle: [], sourceBlocked: [], external: [], unexpected: [] };
const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://127.0.0.1'); res.setHeader('Cache-Control', 'no-store');
    if (url.pathname.startsWith(prefix)) {
        const relative = decodeURIComponent(url.pathname.slice(prefix.length)); const target = path.resolve(root, relative);
        if (!target.startsWith(root + path.sep) || relative.startsWith('src/')) { routes.sourceBlocked.push(relative); res.writeHead(403); return res.end(); }
        try { const bytes = await readFile(target); if (relative.startsWith('dist/')) routes.bundle.push(relative); res.setHeader('Content-Type', relative.endsWith('.json') ? 'application/json' : 'text/javascript; charset=utf-8'); return res.end(bytes); }
        catch { routes.unexpected.push(url.pathname); res.writeHead(404); return res.end(); }
    }
    if (url.pathname === '/favicon.ico') { res.writeHead(204); return res.end(); }
    if (url.pathname === '/thumbnail' || url.pathname.startsWith('/characters/') || url.pathname.startsWith('/user/images/fixture/')) { res.setHeader('Content-Type', 'image/svg+xml'); return res.end('<svg xmlns="http://www.w3.org/2000/svg" width="1" height="1"/>'); }
    if (url.pathname !== '/') { routes.unexpected.push(url.pathname); res.writeHead(500); return res.end('Unexpected host request'); }
    res.setHeader('Content-Type', 'text/html; charset=utf-8'); res.end(hostPage(activeSeed));
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const origin = `http://127.0.0.1:${server.address().port}`;
await mkdir(output, { recursive: true });
const browser = await chromium.launch({ headless: true, ...(process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE ? { executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE } : {}) });
const report = { hashes, evidence: 'index.js -> dist UI; synthetic provider; native IndexedDB', unverified: ['real SillyTavern/TT host', 'real provider/model', 'mobile operating-system background suspension'], matrix: [], routes };
async function waitCanonical(page, predicate, label, timeout = 20000) {
    // Some bundled browser runners resolve async waitForFunction predicates to
    // false without polling. Await the native IDB read explicitly in Node, then
    // test the resolved records; a journal alone is never a readable result.
    const deadline = Date.now() + timeout;
    let rows = [];
    do {
        rows = await page.evaluate(() => __fixture.canonical());
        if (predicate(rows) === true) return rows;
        await new Promise(resolve => setTimeout(resolve, 100));
    } while (Date.now() < deadline);
    assert.fail(`Timed out waiting for ${label}; durable draft states: ${JSON.stringify(rows.flatMap(row => Object.entries(row.cache?.__generationDraftsV2?.records || {}).map(([id,record]) => ({id,status:record.status,mode:record.result?.mode,pageId:record.result?.pageId,hasResult:!!record.result}))))}`);
}

async function openEditor(page) {
    await page.locator('#heartbeat_memories_menu_item').waitFor();
    await page.locator('#heartbeat_memories_menu_item').click();
    await page.locator('.rmt-workspace-tabs [data-rmt-workspace-tab="content"]').click();
    await page.locator('[data-rmt-workspace-group="memory"]').click();
    await page.locator('[data-rmt-workspace-route="album"]').click();
    await page.locator('[data-rmt-album-prompt="CG01"]').click();
    await page.locator('[data-rmt-cg-prompt-input]').waitFor();
}
async function sourcePicker(page) {
    await page.locator('[data-rmt-cg-prompt-action="select-sources"]').click();
    await page.locator('[data-rmt-participant-book]').selectOption('人物书');
    await page.locator('[data-rmt-participant-entry="1"]').waitFor();
}
try {
 for (const width of widths) for (const oldImage of oldImages) {
  activeSeed=seed(width,oldImage);
  const ctx=await browser.newContext({viewport:{width,height:900}});
  await ctx.route('**/*',route=>route.request().url().startsWith(origin+'/')?route.continue():(routes.external.push(route.request().url()),route.abort()));
  const page=await ctx.newPage();page.on('dialog',dialog=>dialog.accept());
  const result={width,oldImage,status:'running',errors:[]};report.matrix.push(result);
  page.on('pageerror',error=>result.errors.push(String(error)));
  try {
   await page.goto(origin);await openEditor(page);
   assert.equal(await page.locator('[data-rmt-cg-person-selected]').count(),2,'NPC and explicit user candidate are both visible');
   assert.equal(await page.locator('[data-rmt-cg-person-selected="1"]').isChecked(),false,'user candidate is not forced into the image');
   const previous=await page.evaluate(()=>__fixture.snapshot());
   const scene=await page.locator('[data-rmt-cg-prompt-input]').inputValue();
   await sourcePicker(page);
   const priorChecked=await page.locator('[data-rmt-participant-entry="0"]').isChecked();
   await page.locator('[data-rmt-participant-link="1"]').selectOption('0');
   await page.locator('[data-rmt-participant-close]').click();
   assert.equal(await page.locator('[data-rmt-cg-prompt-input]').inputValue(),scene);
   await sourcePicker(page);
   assert.equal(await page.locator('[data-rmt-participant-entry="0"]').isChecked(),priorChecked);
   assert.equal(await page.locator('[data-rmt-participant-entry="1"]').isChecked(),false,'cancel did not alter sources');
   await page.locator('[data-rmt-participant-link="0"]').selectOption('0');
   await page.locator('[data-rmt-participant-confirm]').click();
   await page.locator('[data-rmt-participant-book]').waitFor({state:'detached'});
   await page.locator('[data-rmt-cg-person-selected="1"]').check();
   const selected=await page.evaluate(()=>__fixture.snapshot());
   assert.equal(selected.calls.length,0);assert.deepEqual(selected.bank,previous.bank);
   assert.deepEqual(selected.cache.album,previous.cache.album,'source selection cannot overwrite saved CG or prompt');
   await page.locator('[data-rmt-cg-prompt-action="reconceive"]').click();
   await page.waitForFunction(()=>document.querySelector('[data-rmt-cg-person-nl="1"]')?.value==='银色长发，紫眼睛。');
   const request=await page.evaluate(()=>__fixture.snapshot());assert.equal(request.calls.length,1);
   const sent=request.calls[0].messages.map(row=>row.content).join('\n');
   assert.match(sent,/RESELECTED_SOURCE/);assert.match(sent,/USER_PERSONA_SOURCE/);assert.doesNotMatch(sent,/CANCELLED_SOURCE|OLD_SOURCE/);
   assert.equal(await page.locator('[data-rmt-cg-person-nl="0"]').inputValue(),'棕色短发，小麦色皮肤。');
   await page.locator('[data-rmt-cg-prompt-action="save-looks"]').click();
   await page.waitForFunction(()=>document.querySelector('[data-rmt-cg-prompt-status]')?.textContent.includes('外貌已保存'));
   await page.screenshot({path:path.join(output,`sources-${width}-${oldImage}.png`),fullPage:true});
   await page.locator('[data-rmt-cg-prompt-action="draw"]').click();
   await waitCanonical(page,rows=>rows.some(row=>row.cache?.album?.entries?.[0]?.cgImage?.url==='/user/images/fixture/appearance.png'),'CG with selected sources');
   const after=await page.evaluate(()=>__fixture.snapshot());assert.equal(after.calls.length,1);
   assert.equal(await page.evaluate(()=>__fixture.imageCalls.length),1);
   const saved=after.cache.album.entries[0].cgImage.promptMetadata;
   assert.equal(saved.castSnapshot.people[1].identity,'user');
   assert.match(saved.castSnapshot.people[0].sourceRefs[0].content,/RESELECTED_SOURCE/);
   assert.match(saved.castSnapshot.people[1].sourceRefs[0].content,/USER_PERSONA_SOURCE/);
   assert.deepEqual(after.bank,previous.bank);
   await page.reload();await openEditor(page);
   assert.equal(await page.locator('[data-rmt-cg-person-selected]').count(),2,'reopening cannot duplicate the user');
   assert.equal(await page.locator('[data-rmt-cg-person-selected="1"]').isChecked(),true);
   assert.equal(await page.locator('[data-rmt-cg-person-nl="1"]').inputValue(),'银色长发，紫眼睛。');
   assert.equal((await page.evaluate(()=>__fixture.snapshot())).calls.length,1);
   assert.deepEqual(result.errors,[]);Object.assign(result,{status:'passed',textRequests:1,imageRequests:1,requestSha256:sha(sent),cancelPreserved:true,oldImagePreservedUntilDraw:true,nativeIndexedDB:true});
  } catch(error) {result.status='failed';result.error=String(error.stack||error);result.state=await page.evaluate(()=>__fixture.snapshot()).catch(()=>null);result.html=await page.content().catch(()=>'');await page.screenshot({path:path.join(output,`failure-${width}-${oldImage}.png`),fullPage:true}).catch(()=>{});}
  finally {await ctx.close();await writeFile(path.join(output,'report.json'),JSON.stringify(report,null,2));}
 }
 assert.ok(routes.bundle.length);assert.deepEqual(routes.sourceBlocked,[]);assert.deepEqual(routes.external,[]);
 assert.ok(report.matrix.every(row=>row.status==='passed'),'appearance source browser checks failed; see report.json');
} finally {await writeFile(path.join(output,'report.json'),JSON.stringify(report,null,2));await browser.close();await new Promise(resolve=>server.close(resolve));}
console.log(JSON.stringify({passed:report.matrix.length,output,hashes}));
