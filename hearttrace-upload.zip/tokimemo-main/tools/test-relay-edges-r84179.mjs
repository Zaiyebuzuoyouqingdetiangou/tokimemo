import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { preparationFixture } from './preparation-harness-r8481.mjs';
import { relayIndexedDB } from './relay-idb-fixture.mjs';

test('unlinked preparation keeps its old flow when storage is unavailable; known relay and actual writes still refuse', async () => {
    const f = await preparationFixture();
    const backup = await f.api('archive/backupStore.js');
    backup.setArchiveBackupBackendForTests(null);
    const ordinary = { version: 3, chatId: 'A', archiveRevision: 'rev-A', memories: [] };
    assert.equal(await backup.assertArchiveRelayWritable(entry('A'), ordinary), null);
    const marked = { ...ordinary, archiveRelayV1: { version: 1, lineageId: 'known', epoch: 1 } };
    await assert.rejects(backup.assertArchiveRelayWritable(entry('A'), marked), error => error.code === 'RMT_BACKUP_UNAVAILABLE');
    await assert.rejects(backup.replaceArchiveBackup(entry('A'), ordinary, null, { present: false }));
    assert.equal(f.providerCalls, 0);
});

const entry = chatId => ({ entryId: `edge-${chatId}`, chatId, avatar: 'preparation-check.png', characterKey: 'card', characterName: '岚', characterIndexHint: 0 });
const memory = chatId => ({ version: 3, chatId, archiveRevision: `rev-${chatId}`, characterName: '岚', memories: [{ id: 'M100', summary: '必须保留的成功内容' }] });

// Faults occur after a queued native-shaped request, not before transaction
// creation. This specifically exercises reconnect/replay behavior at the new
// relay boundary. The underlying fixture still owns atomic commit and rollback.
function faultIndexedDB() {
    const base = relayIndexedDB();
    const stats = { opens: 0, closes: 0, failures: 0 };
    const fault = { where: '', name: 'UnknownError', remaining: 0 };
    function wrapRequest(inner, tx, where) {
        const outer = {};
        inner.onsuccess = () => {
            if (fault.where === where && fault.remaining > 0) {
                fault.remaining--; stats.failures++;
                outer.error = tx.error = new DOMException('Simulated IndexedDB connection loss', fault.name);
                outer.onerror?.();
                tx.abort();
            } else {
                outer.result = inner.result;
                outer.onsuccess?.();
            }
        };
        inner.onerror = () => { outer.error = inner.error; outer.onerror?.(); };
        return outer;
    }
    return { rows: base.rows, stats, fault, open() {
        stats.opens++;
        const outer = {}, inner = base.open();
        inner.onsuccess = () => {
            const db = inner.result;
            outer.result = { ...db,
                close() { stats.closes++; db.close(); },
                transaction(name, mode) {
                    const tx = db.transaction(name, mode), objectStore = tx.objectStore;
                    tx.objectStore = storeName => {
                        const store = objectStore(storeName);
                        return { ...store,
                            get(key) {
                                const request = store.get(key);
                                return mode === 'readonly' && String(key).startsWith('relay-member:')
                                    ? wrapRequest(request, tx, 'readonly-fence') : request;
                            },
                            put(row) { return wrapRequest(store.put(row), tx, 'readwrite-put'); },
                        };
                    };
                    return tx;
                },
            };
            outer.onsuccess?.();
        };
        return outer;
    } };
}

async function fixture(idb = faultIndexedDB()) {
    const f = await preparationFixture();
    f.sandbox.Blob = Blob; f.sandbox.indexedDB = idb;
    vm.runInContext('structuredClone = value => value === undefined ? undefined : JSON.parse(JSON.stringify(value))', f.sandbox);
    const backup = await f.api('archive/backupStore.js');
    const relay = await f.api('archive/relayStore.js');
    const policy = await f.api('core/archiveRelayPolicy.js');
    backup.setArchiveBackupBackendForTests(null);
    await backup.replaceArchiveBackup(entry('A'), memory('A'), null, { present: false });
    return { f, idb, backup, relay, policy };
}

async function handoffInput(x) {
    const source = await x.backup.readArchiveBackupState(entry('A'));
    const target = await x.backup.readArchiveBackupState(entry('B'));
    return { sourceEntry: entry('A'), targetEntry: entry('B'), sourceExpected: source.record, targetExpected: target.record,
        sourceFence: source.relay, targetFence: target.relay, memory: { ...memory('A'), chatId: 'B', archiveRevision: 'relay-revision' },
        cache: null, transferId: 'edge-transfer', stillCurrent: () => true };
}

async function missingRegistration() {
    const x = await fixture();
    await x.relay.handoffArchiveBackup(await handoffInput(x));
    x.idb.rows.delete(x.policy.relayMemberKey(entry('A')));
    return x;
}

test('missing local registration cannot delete a relay-marked exact archive', async () => {
    const x = await missingRegistration(), before = JSON.stringify([...x.idb.rows]);
    const marked = (await x.backup.readArchiveBackupState(entry('A'))).record;
    await assert.rejects(x.backup.updateArchiveBackupCache(entry('A'), marked.memory, null), error => error.code === 'RMT_RELAY_LOCAL_ONLY');
    await assert.rejects(x.backup.deleteArchiveBackup(entry('A')), error => error.code === 'RMT_RELAY_LOCAL_ONLY');
    assert.equal(JSON.stringify([...x.idb.rows]), before);
    assert.equal((await x.backup.readArchiveBackup(entry('A'))).memory.memories[0].id, 'M100');
    assert.equal(x.f.providerCalls, 0);
});

test('missing registration also fences a legacy alias and rolls back a group deletion', async () => {
    const x = await missingRegistration();
    await x.backup.replaceArchiveBackup(entry('C'), memory('C'), null, { present: false });
    const alias = { ...entry('A'), entryId: 'new-index-key-for-A' };
    assert.equal((await x.backup.readArchiveBackup(alias)).entryId, entry('A').entryId);
    const before = JSON.stringify([...x.idb.rows]);
    await assert.rejects(x.backup.deleteArchiveBackup([entry('C'), alias]), error => error.code === 'RMT_RELAY_LOCAL_ONLY');
    assert.equal(JSON.stringify([...x.idb.rows]), before);
    assert.equal((await x.backup.readArchiveBackupState(entry('C'))).deleted, false);
});

test('ordinary unlinked deletion and explicit current-holder deletion still work', async () => {
    const ordinary = await fixture();
    await ordinary.backup.deleteArchiveBackup(entry('A'));
    assert.equal((await ordinary.backup.readArchiveBackupState(entry('A'))).deleted, true);
    const linked = await fixture();
    await linked.relay.handoffArchiveBackup(await handoffInput(linked));
    await linked.backup.deleteArchiveBackup(entry('B'));
    assert.equal((await linked.backup.readArchiveBackupState(entry('B'))).deleted, true);
    assert.equal((await linked.backup.readArchiveBackupState(entry('A'))).deleted, false);
});

test('unlinked archive fence reads reconnect once after either supported lost-connection error', async () => {
    for (const name of ['UnknownError', 'InvalidStateError']) {
        const x = await fixture(), before = JSON.stringify([...x.idb.rows]), opens = x.idb.stats.opens;
        Object.assign(x.idb.fault, { where: 'readonly-fence', name, remaining: 1 });
        const saved = await x.backup.readArchiveBackupState(entry('A'));
        assert.equal(saved.record.memory.memories[0].id, 'M100', name);
        assert.equal(saved.relay, null, name);
        assert.equal(x.idb.stats.opens, opens + 1, name);
        assert.equal(x.idb.stats.closes, 1, name);
        assert.equal(x.idb.stats.failures, 1, name);
        assert.equal(JSON.stringify([...x.idb.rows]), before, name);
        assert.equal(x.f.providerCalls, 0, name);
    }
});

test('readonly retry is bounded and a later explicit read can recover', async () => {
    const x = await fixture(), opens = x.idb.stats.opens;
    Object.assign(x.idb.fault, { where: 'readonly-fence', name: 'UnknownError', remaining: 2 });
    await assert.rejects(x.backup.readArchiveBackupState(entry('A')), error => error.code === 'RMT_BACKUP_TRANSACTION' && error.backupStage === 'read');
    assert.equal(x.idb.stats.failures, 2);
    assert.equal(x.idb.stats.opens, opens + 1);
    assert.equal(x.idb.stats.closes, 2);
    assert.equal((await x.backup.readArchiveBackupState(entry('A'))).record.archiveRevision, 'rev-A');
    assert.equal(x.idb.stats.opens, opens + 2);
});

test('a lost handoff write is never replayed; its rollback and explicit retry preserve content', async () => {
    const x = await fixture(), input = await handoffInput(x);
    const before = JSON.stringify([...x.idb.rows]), opens = x.idb.stats.opens;
    Object.assign(x.idb.fault, { where: 'readwrite-put', name: 'UnknownError', remaining: 1 });
    await assert.rejects(x.relay.handoffArchiveBackup(input), error => error.name === 'UnknownError');
    assert.equal(x.idb.stats.opens, opens, 'no automatic replay of the uncertain write');
    assert.equal(x.idb.stats.failures, 1);
    assert.equal(x.idb.stats.closes, 1);
    assert.equal(JSON.stringify([...x.idb.rows]), before);
    assert.equal((await x.backup.readArchiveBackupState(entry('A'))).record.archiveRevision, 'rev-A');
    assert.equal(x.idb.stats.opens, opens + 1, 'next explicit operation reconnects');
    const result = await x.relay.handoffArchiveBackup(await handoffInput(x));
    assert.equal(result.status, 'committed');
    assert.equal((await x.backup.readArchiveBackup(entry('B'))).memory.memories[0].summary, '必须保留的成功内容');
    assert.equal([...x.idb.rows.values()].filter(row => row.kind === 'archive-relay-checkpoint').length, 1);
    assert.equal(x.f.providerCalls, 0);
});
