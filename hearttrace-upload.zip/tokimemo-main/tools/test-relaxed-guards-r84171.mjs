// r84.171 · 前世今生 / 时空信笺：文字检查不再让整步生成失败。
// 命中的句子去掉；单条回响、旁批不合规只丢那一条；认不出的线索类型按旁记收下；不再按篇数拒绝写新篇。
import test from 'node:test';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { preparationFixture } from './preparation-harness-r8481.mjs';

async function api() {
    const f = await preparationFixture();
    const copy = value => vm.runInContext(`JSON.parse(${JSON.stringify(JSON.stringify(value))})`, f.sandbox);
    f.sandbox.structuredClone = copy;
    return { f, copy, pl: await f.api('modes/pastLives.js'), contract: await f.api('core/pastLivesContract.js'), ts: await f.api('core/timeStoriesContract.js') };
}
const memory = { userName: '阿宁', characterName: '岚', memories: [
    { id: 'M001', title: '读书', summary: '我们今天一起读完了窗边的书。', anchors: ['一起读完了窗边的书'] }] };

test('结尾部分：坏的一条回响、坏的一句话都不再让整步失败', async () => {
    const { f, copy, pl } = await api();
    const dossiers = copy([{ id: 'D01', clues: [{ id: 'D01-C01' }] }]);
    const out = pl.normalizePastLivesFinale(copy({
        echoes: [
            { kind: 'memory', text: '我们一起去看了海。', sourceMemoryIds: ['M001'], sourceMemoryAnchor: '一起读完了窗边的书' },
            { kind: 'possibility', title: '明天', text: '明天我们会去旅行。' },
            { kind: 'possibility', title: '也许', text: '也许有一天，我们会再一起读一本书。' },
            { kind: 'weird', text: '无法识别的回响。' },
        ],
        annotations: [{ afterClueIds: ['D01-C01', 'D09-C99'], text: '卷中的灯一直亮着。' }],
        closing: { text: '我们今生注定是恋人。窗外的雨停了。', signature: '岚' },
    }), copy(memory), dossiers);
    assert.equal(out.echoes.length, 1, '只留下合规的那条未来回响');
    assert.equal(out.echoes[0].kind, 'possibility');
    assert.deepEqual([...out.annotations[0].afterClueIds], ['D01-C01'], '不存在的线索引用被去掉');
    assert.equal(out.closing.text.includes('注定是恋人'), false, '命中的那句被去掉');
    assert.match(out.closing.text, /窗外的雨停了/);
    assert.equal(f.providerCalls, 0);
});

test('认不出的线索类型按旁记收下', async () => {
    const { copy, pl } = await api();
    const dossier = pl.normalizePastLivesDossier(copy({ title: '前世', era: '长安', synopsis: '灯下研墨。',
        clues: [{ kind: 'photo', title: '一张旧照', text: '照片上的人在笑。' }] }), copy(memory));
    assert.equal(dossier.clues[0].kind, 'note');
});

test('不再按篇数拒绝写新篇', async () => {
    const { contract, ts } = await api();
    assert.ok(contract.PAST_LIVES_LIMITS.episodes > 10000);
    assert.ok(ts.TIME_STORY_LIMITS.episodes > 10000);
    for (const file of ['../src/modes/pastLives.js', '../src/modes/timeStories.js']) {
        const src = await readFile(new URL(file, import.meta.url), 'utf8');
        assert.equal(/episodes\??\.length >= L\.episodes/.test(src), false, file);
    }
});

test('时空信笺：媒介不在列表里时改用默认媒介；关系检查只去掉命中的句子', async () => {
    const src = await readFile(new URL('../src/modes/timeStories.js', import.meta.url), 'utf8');
    assert.match(src, /allowed\.includes\(raw\.medium\?\.kind\) \? raw\.medium\.kind : allowed\[0\]/);
    assert.equal(src.includes("throw fail('WORLD'"), false);
    assert.equal(src.includes("throw fail('RELATIONSHIP'"), false);
});

test('模型多写了几条时只收前面的，不让整步失败', async () => {
    const { copy, contract, ts } = await api();
    assert.equal(contract.pastLivesArray(copy([1, 2, 3, 4]), 2).length, 2);
    assert.equal(ts.timeStoryArray(copy([1, 2, 3]), 2).length, 2);
    assert.throws(() => contract.pastLivesArray(null, 2));
});
