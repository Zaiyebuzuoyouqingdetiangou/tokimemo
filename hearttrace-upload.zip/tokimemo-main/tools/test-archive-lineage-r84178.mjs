// r84.178 · 跨聊天连续档案第一步：记忆记下来源聊天；登记表的交接 / 解绑规则（尚未接到界面）。
import vm from 'node:vm';
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { preparationFixture } from './preparation-harness-r8481.mjs';

async function api() {
    const f = await preparationFixture();
    const copy = value => vm.runInContext(`JSON.parse(${JSON.stringify(JSON.stringify(value))})`, f.sandbox);
    f.sandbox.structuredClone = copy;
    return { copy, lineage: await f.api('core/archiveLineage.js'), capacity: await f.api('archive/capacity.js'), external: await f.api('archive/externalMemory.js') };
}
const memo = (extra = {}) => ({ title: '雨夜', summary: '躲雨', anchors: ['雨'], sourceKind: 'chat', messageStart: 3, messageEnd: 4, ...extra });

test('本聊天的档案：标了来源或没标，去重和编号都和以前一样', async () => {
    const { copy, capacity, external } = await api();
    assert.equal(external.importedMemoryStableKey(copy(memo({ sourceChatId: 'A' })), 'A'), external.importedMemoryStableKey(copy(memo())));
    const admitted = capacity.admitArchiveMemories(copy([{ id: 'M001', ...memo() }]), copy([memo({ sourceChatId: 'A' })]), [], { homeChatId: 'A' });
    assert.equal(admitted.memories.length, 1, '同一聊天同一片段仍算重复');
});

test('来自另一个聊天：楼层号相同也不算重复，编号接着往后排', async () => {
    const { copy, capacity } = await api();
    const admitted = capacity.admitArchiveMemories(copy([{ id: 'M100', ...memo({ sourceChatId: 'A' }) }]), copy([memo({ sourceChatId: 'B' })]), [], { homeChatId: 'B' });
    assert.deepEqual([...admitted.memories.map(item => item.id)], ['M100', 'M101']);
    assert.equal(admitted.memories[1].sourceChatId, 'B');
});

test('建档时给新记忆标上来源聊天', async () => {
    const src = await readFile(new URL('../src/archive/importOperation.js', import.meta.url), 'utf8');
    assert.match(src, /const sourceChatId = core_context\.comparableChatId\(preparation\.origin\.chatId\);/);
    assert.match(src, /\{ homeChatId: sourceChatId \}/);
});

test('登记表：建立、交接（CAS）、解绑交还，不出现两个持有者', async () => {
    const { lineage } = await api();
    let reg = lineage.createLineage(lineage.emptyLineageRegistry(), { id: 'L1', homeChatId: 'A', revision: 'r1', now: 1 });
    assert.throws(() => lineage.createLineage(reg, { id: 'L2', homeChatId: 'A', revision: 'r1' }), /另一份连续档案/);
    reg = lineage.handOverLineage(reg, { id: 'L1', from: 'A', to: 'B', expectedRevision: 'r1', nextRevision: 'r2', now: 2 });
    assert.equal(lineage.lineageForChat(reg, 'B').holder, true);
    assert.equal(lineage.lineageForChat(reg, 'A').holder, false);
    assert.throws(() => lineage.handOverLineage(reg, { id: 'L1', from: 'A', to: 'C', expectedRevision: 'r1', nextRevision: 'r3' }), error => error.code === 'RMT_LINEAGE_CAS', '旧持有者 / 旧版本不能再交接');
    reg = lineage.handOverLineage(reg, { id: 'L1', from: 'B', to: 'C', expectedRevision: 'r2', nextRevision: 'r3', now: 3 });
    assert.deepEqual([...reg.lineages.L1.members.map(member => member.chatId)], ['A', 'B', 'C']);
    assert.throws(() => lineage.detachFromLineage(reg, { id: 'L1', chatId: 'C', backTo: 'Z', expectedRevision: 'r3' }), /仍在这份连续档案里/);
    reg = lineage.detachFromLineage(reg, { id: 'L1', chatId: 'C', backTo: 'B', expectedRevision: 'r3', nextRevision: 'r4', now: 4 });
    assert.equal(reg.lineages.L1.holder, 'B');
    assert.equal(lineage.lineageForChat(reg, 'C'), null, '解绑后 C 回到独立聊天');
    assert.equal(lineage.lineageForChat(reg, 'D'), null, '没登记的聊天不共享');
});

test('登记表读入时丢掉坏数据（持有者不在成员里、缺版本）', async () => {
    const { copy, lineage } = await api();
    const reg = lineage.normalizeLineageRegistry(copy({ version: 1, lineages: { ok: { members: [{ chatId: 'A' }], holder: 'A', revision: 'r' }, bad: { members: [{ chatId: 'A' }], holder: 'B', revision: 'r' }, nov: { members: [{ chatId: 'C' }], holder: 'C' } } }));
    assert.deepEqual(Object.keys(reg.lineages), ['ok']);
});
