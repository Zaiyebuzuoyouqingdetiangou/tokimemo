// Real Chromium IndexedDB and page reload; source archive/recovery modules.
// Synthetic requests only. Shipped-bundle UI coverage is run separately.
import assert from 'node:assert/strict';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
const { chromium } = createRequire(import.meta.url)('playwright');
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const out=path.resolve(process.env.RECOVERY_OUTPUT_DIR || path.join(root,'artifacts/recovery-capacity'));
const server=http.createServer(async(req,res)=>{
    res.setHeader('Cache-Control','no-store');
    const pathname=new URL(req.url,'http://localhost').pathname;
    if(pathname==='/'){res.setHeader('Content-Type','text/html');res.end('<!doctype html><meta charset="utf-8"><title>Recovery verification</title>');return;}
    const file=path.resolve(root,'.'+pathname);
    if(!file.startsWith(root+path.sep)){res.writeHead(403);res.end();return;}
    try{res.setHeader('Content-Type','text/javascript');res.end(await readFile(file));}catch{res.writeHead(404);res.end();}
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const url=`http://127.0.0.1:${server.address().port}`;
let browser;
try{
    await mkdir(out,{recursive:true});
    browser=await chromium.launch({headless:true,executablePath:process.env.EDGE_PATH || 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'});
    const page=await browser.newPage();let external=0;
    await page.route('**/*',route=>{if(new URL(route.request().url()).origin!==url){external++;return route.abort();}return route.continue();});
    const run=async(phase)=>page.evaluate(async phase=>{
        const r=await import('/src/generation/recovery.js'), a=await import('/src/archive/importRecovery.js');
        const origin={characterKey:'browser-capacity',characterId:'0',characterAvatar:'fixture.png',chatId:'browser-capacity',archiveRevision:'old'};
        const background='原背景🙂'.repeat(23000), prompt=i=>`第${i}段：${'原材料'.repeat(4000)}`;
        const actual=i=>background+'\n'+prompt(i)+'\n补充';
        const ensure=(condition,message)=>{if(!condition)throw Error(message);};
        const hash=async text=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text))),n=>n.toString(16).padStart(2,'0')).join('');
        const inputs={taskInputV1:{data:{source:'original source'},version:1}};
        await a.hydrateArchiveRecovery(origin);
        const before=a.exportArchiveRecovery(origin);
        if(phase==='resume')ensure(r.generationRecoverySummary(before[0].journal).completed===8,'eight persisted segments missing after reload');
        const ticket=await a.beginArchiveRecovery({origin,sourceIdentity:{original:true},sourceFragments:['original source'],
            settingsIdentity:phase==='start'?'original API':'changed API',inputs,continueApproved:phase==='resume'});
        const calls=[], hashes=[];
        for(let i=0;i<9;i++){
            try{
                const value=await r.withRecoverySegment(phase==='start'?prompt(i):'changed current input',
                    {origin:ticket.origin,taskKey:`browser:${i}`,contextEnvelope:phase==='start'?background:'new chat'},x=>x,
                    async(restored,options,accepted)=>{
                        ensure(restored===prompt(i),'original request changed');
                        const frozen=await r.freezeRecoveryRequestPayload(options,{actualPrompt:phase==='start'?actual(i):'changed current prompt',contentSettings:{}});
                        ensure(frozen.actualPrompt===actual(i),'frozen final prompt changed');
                        calls.push(i);
                        if(phase==='start'&&i===8)throw Object.assign(Error('synthetic temporary error'),{code:'RMT_MANUAL_HTTP'});
                        const result={number:i,text:'原生成正文 '+i,ids:['M001'],image:'https://example.invalid/old.png'};
                        await accepted(result);return result;
                    });
                ensure(value.number===i,'saved result changed');
            }catch(error){if(!(phase==='start'&&i===8&&error.message==='synthetic temporary error'))throw error;}
            const row=r.generationRecoverySnapshot(ticket.handle).segments[i];
            hashes.push(await hash(row.requestRecipe.actualPrompt));
        }
        a.releaseArchiveRecovery(ticket);await a.flushArchiveRecovery(origin);
        const exported=a.exportArchiveRecovery(origin), expanded=r.generationRecoverySnapshot(ticket.handle);
        if(phase==='resume'){
            // Decode before comparing so a storage representation change is not mistaken for a text change.
            const oldOrigin={...before[0].journal.identity};
            const oldHandle=await r.createGenerationRecovery({origin:oldOrigin,mode:oldOrigin.mode,settingsIdentity:'any',existing:before[0].journal,continueRequested:true,save:async()=>true});
            ensure(JSON.stringify(r.generationRecoverySnapshot(oldHandle).segments.slice(0,8))===JSON.stringify(expanded.segments.slice(0,8)),'completed segments changed');
        }
        return {phase,calls,hashes,completed:r.generationRecoverySummary(exported[0].journal).completed,
            storedChars:JSON.stringify(exported[0].journal).length,expandedChars:JSON.stringify(expanded).length,
            literalArchivePrompts:exported[0].journal.segments.every(s=>typeof s.requestRecipe.identity.prompt==='string')};
    },phase);
    await page.goto(url);const start=await run('start');
    await page.reload();const resumed=await run('resume');
    assert.equal(start.completed,8);assert.equal(resumed.completed,9);assert.deepEqual(resumed.calls,[8]);
    assert.deepEqual(start.hashes,resumed.hashes);assert.ok(resumed.expandedChars>1800000);assert.ok(resumed.storedChars<1800000);
    assert.ok(start.literalArchivePrompts&&resumed.literalArchivePrompts);assert.equal(external,0);
    const report={passed:true,start,resumed,externalNetworkAttempts:external,boundary:'Real Edge, archive draft persistence, IndexedDB, page reload; simulated provider. This script imports source modules; shipped bundle UI verified separately.'};
    await writeFile(path.join(out,'report.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report));
}finally{await browser?.close();await new Promise(resolve=>server.close(resolve));}
