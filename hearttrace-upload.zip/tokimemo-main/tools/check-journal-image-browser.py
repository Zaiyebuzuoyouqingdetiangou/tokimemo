# 手帐「存成长图」真实浏览器检查（r84.176）：需要 Python playwright + Chromium。在仓库根目录运行：python3 tools/check-journal-image-browser.py
import http.server,threading,os,json,base64
from playwright.sync_api import sync_playwright
root=os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
SVG=b"<svg xmlns='http://www.w3.org/2000/svg' width='1216' height='832'><rect width='1216' height='832' fill='#c9b89a'/><circle cx='600' cy='380' r='190' fill='#8a3b2e'/></svg>"
class H(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a):pass
    def do_GET(self):
        if self.path.startswith('/user/images/'):
            self.send_response(200);self.send_header('Content-Type','image/svg+xml');self.end_headers();self.wfile.write(SVG);return
        return super().do_GET()
    def translate_path(self,path):
        if path.startswith('/page.html'): return os.path.join(os.path.dirname(os.path.abspath(__file__)), 'check-journal-browser.html')
        return os.path.join(root,path.lstrip('/').split('?')[0])
srv=http.server.ThreadingHTTPServer(('127.0.0.1',8769),H);threading.Thread(target=srv.serve_forever,daemon=True).start()
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page(viewport={'width':390,'height':1000});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://127.0.0.1:8769/page.html');pg.wait_for_function('window.__done')
    pg.evaluate("""async()=>{const j=await import('/src/core/handJournal.js');const c=await import('/src/core/context.js');const scope=c.chatScopeKey(c.currentCharacterGuard());const s=j.createJournalStore({currentScope:()=>scope});
      await s.append(scope,[j.createJournalPage({id:'demo',createdAt:Date.now(),title:'庙檐下躲雨的那晚',entries:[{id:'e1',title:'睡前故事 · 第 1 章',source:{mode:'bedtime',id:'s',title:''},blocks:[{type:'image',url:'/user/images/demo.png'},{type:'image',url:'https://example.invalid/x.png'}]},{id:'e2',title:'摘自 方祁洛 · 第 83 楼',source:{mode:'chat',id:'82',title:''},blocks:[{type:'text',speaker:'方祁洛',text:'差一点就把我新编的发绳给泡烂了。'.repeat(6)}]}],notes:[{id:'n',text:'那天的篝火好暖。'}],favorite:true,annotation:{text:'下次下雨，我把外衫让给你。别嫌湿。',at:1,by:'方祁洛'}})]);}""")
    pg.reload();pg.wait_for_function('window.__done');pg.wait_for_function('document.querySelector(".rmt-journal-page")')
    pg.click('.rmt-journal-page-more>summary');pg.click('[data-journal-image]')
    pg.wait_for_function('document.querySelector(".rmt-journal-export img")?.complete',timeout=15000);pg.wait_for_timeout(300)
    info=pg.evaluate('({w:document.querySelector(".rmt-journal-export img").naturalWidth,h:document.querySelector(".rmt-journal-export img").naturalHeight,text:document.querySelector(".rmt-journal-export p").textContent,dl:document.querySelector(".rmt-journal-export a").getAttribute("download")})')
    data=pg.evaluate('fetch(document.querySelector(".rmt-journal-export img").src).then(r=>r.arrayBuffer()).then(b=>{let s="";const u=new Uint8Array(b);for(let i=0;i<u.length;i++)s+=String.fromCharCode(u[i]);return btoa(s)})')
    open('journal-long.png','wb').write(base64.b64decode(data))
    pg.click('[data-journal-image-close]');info['closed']=pg.evaluate('!document.querySelector(".rmt-journal-export")');info['errors']=errs
    print(json.dumps(info,ensure_ascii=False));b.close()
srv.shutdown()
