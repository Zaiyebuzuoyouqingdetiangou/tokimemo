import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const root = path.resolve(process.argv[2] || '.');
const sources = new Map(), order = [], active = new Set();
const ns = file => '__m_' + file.replace(/[^a-zA-Z0-9]/g, '_');
const init = file => '__init_' + file.replace(/[^a-zA-Z0-9]/g, '_');
const importRe = /^import\s+(\*\s+as\s+(\w+)|\{([^}]+)\})\s+from\s+['"]([^'"]+)['"];?\s*$/gm;
function visit(file) {
    if (active.has(file)) return;
    active.add(file);
    const source = fs.readFileSync(path.join(root, 'src', file), 'utf8');
    const imports = [...source.matchAll(importRe)].map(match => ({match, file:path.posix.normalize(path.posix.join(path.posix.dirname(file),match[4]))}));
    for (const row of imports) visit(row.file);
    sources.set(file,{source,imports}); order.push(file);
}
visit('heartbeatMemories.js');
// Preserve the published runtime's cycle initialization order. New pure helpers
// initialize after their dependencies; reject accidental omissions.
const pinnedOrder = JSON.parse(fs.readFileSync(path.join(root, 'tools/runtime-module-order.json'), 'utf8'));
if (pinnedOrder.length !== sources.size || new Set(pinnedOrder).size !== sources.size || pinnedOrder.some(file => !sources.has(file))) throw new Error('Update the reviewed module initialization order');
order.splice(0, order.length, ...pinnedOrder);
const sorted = [...sources.keys()].sort();
const hash = crypto.createHash('sha256');
for(const file of sorted) hash.update(file+'\0'+sources.get(file).source+'\0');
const blocks = order.map(file => {
    const {source,imports} = sources.get(file);
    const bindings = [];
    for (const {match,file:dep} of imports.filter(row=>row.match[2])) bindings.push(`const ${match[2]} = ${ns(dep)};`);
    for (const {match,file:dep} of imports.filter(row=>!row.match[2])) {
        for(const name of match[3].split(',')) {const [key,alias] = name.trim().split(/\s+as\s+/);bindings.push(`const ${alias||key} = ${ns(dep)}.${key};`);}
    }
    let body = source.replace(importRe,'');
    const names=[];
    for(const pattern of [/export async function\s+(\w+)/g,/export function\s+(\w+)/g,/export const\s+(\w+)/g]) for(const m of body.matchAll(pattern)) names.push(m[1]);
    body=body.replace(/\bexport (?=(?:async )?function |const )/g,'');
    if(/^import |^export /m.test(body)) throw new Error('Unsupported module syntax: '+file);
    return `function ${init(file)}() {\n// MODULE: ${file}\n${bindings.length?bindings.join('\n')+'\n':''}${body.trimEnd()}\n\n${names.map(name=>`${ns(file)}.${name} = ${name};`).join('\n')}\n}`;
});
const exports=['openArchiveLibrary','openSettingsHome','isGenerationBusy','initMemoryTheater','destroyMemoryTheater'];
const result=`// GENERATED FILE. Do not edit by hand.\n// Source modules: ${sources.size}\n// Source SHA-256: ${hash.digest('hex')}\n// Build: node tools/build-runtime-bundle.mjs\n\n${sorted.map(file=>`const ${ns(file)} = Object.create(null);`).join('\n')}\n\n${blocks.join('\n\n')}\n\n${order.map(file=>`${init(file)}();`).join('\n')}\n\n${exports.map(name=>`export const ${name} = ${ns('heartbeatMemories.js')}.${name};`).join('\n')}\n`;
fs.mkdirSync(path.join(root,'dist'),{recursive:true});
fs.writeFileSync(path.join(root,'dist/heartbeatMemories.bundle.js'),result);
console.log(JSON.stringify({modules:sources.size,bytes:Buffer.byteLength(result),sha256:crypto.createHash('sha256').update(result).digest('hex')}));
