import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { preparationFixture } from './preparation-harness-r8481.mjs';
import { extractJson, parseInboxRecoveryObject } from '../src/generation/jsonParser.js';
import { assertIndependentResponsePayload } from '../src/core/independentApiConfig.js';

const date = '2026-09-26T12:00:00Z';
const stage = { slot: 'stage', title: '阶段原信', greeting: '你好', body: '和好之后，一起在窗边读书。', closing: '岚' };
const daily = { slot: 'daily', title: '日常原信', greeting: '你好', body: '今天路过书店，想起你喜欢的故事。', closing: '岚' };
const corrupt = letter => JSON.stringify(letter).slice(0, -1) + ',"letterIllustration":{"scene":{"kind":"write","evidence":"写信"错误解释}}}';
const damaged = `{"letters":[${corrupt(stage)}${JSON.stringify(daily)}]}`;
const truncated = `{"letters":[${JSON.stringify(stage)},{"slot":"daily","title":"未完","body":"半封`;
const slots = rows => Array.from(rows || [], value => value.slot || value.type);

async function fixture(replies, { failPaidSave = false, mode = 'inbox', validate = null } = {}) {
    let calls = 0, stored, automaticContinuations = 0;
    const requests = [];
    const profile = { id: 'fixture', mode: 'cc', api: 'custom', model: 'fixture', 'api-url': 'https://example.invalid/v1', 'secret-id': '' };
    const f = await preparationFixture({ hostOverrides: {
        extensionSettings: { heartbeatMemories: { apiConnectionMode: 'profile', connectionProfileId: 'fixture', useActivatedWorldInfo: false }, connectionManager: { profiles: [profile] } },
        ConnectionManagerRequestService: { validateProfile: () => ({ selected: 'openai', source: 'custom' }),
            sendRequest: async (_id, messages, _max, _options, overridePayload) => {
                const carrier = { secret_id: profile['secret-id'], model: profile.model, ...overridePayload };
                assert.equal(carrier.model, 'fixture'); requests.push(messages[0].content);
                assert.ok(calls < replies.length, 'no unrequested extra provider call');
                return { choices: [{ message: { content: replies[calls++] } }] };
            } },
    } });
    f.sandbox.Blob = Blob;
    vm.runInContext('structuredClone = value => value === undefined ? undefined : JSON.parse(JSON.stringify(value))', f.sandbox);
    const copy = value => vm.runInContext('(' + JSON.stringify(value) + ')', f.sandbox);
    const bank = copy({ version: 3, chatId: f.host.chatId, archiveRevision: 'r1', characterName: '岚', userName: '阿宁',
        memories: [{ id: 'M001', title: '争执后和好', summary: '和好后一起读书。', anchors: ['和好'] }] });
    const inbox = await f.api('modes/inbox.js'), recovery = await f.api('generation/recovery.js');
    const request = await f.api('generation/generationRequest.js'), progress = await f.api('generation/partialProgress.js');
    recovery.setTruncationContinueHandler(() => { automaticContinuations++; });
    const origin = (await f.api('core/context.js')).captureTaskOrigin(f.host, bank.archiveRevision);
    const plan = inbox.inboxPlan(bank, null, new Date(date));
    assert.deepEqual(slots(plan), ['stage', 'daily']);
    const snapshot = copy({ memoryBank: bank, fields: { characterId: 0, name1: '阿宁', name2: '岚', chatId: bank.chatId }, cardFields: {}, contentInputs: { previousSession: null } });
    const create = async (existing = null) => {
        const h = await recovery.createGenerationRecovery({ origin, mode, settingsIdentity: 'same', draftId: 'mail-fixture', pageId: mode,
            contentSnapshot: snapshot, existing, continueRequested: !!existing,
            save: async value => { if (failPaidSave && calls && value.segments.some(row => row.partial || row.rawJson)) return false; stored = copy(value); return true; } });
        h.journal.operation = copy({ kind: 'mode', mode, inboxDate: date, inboxPlanVersion: 2 });
        recovery.attachGenerationRecovery(origin, h); return h;
    };
    let handle = await create();
    const run = () => request.requestValidatedSegment('fixture inbox prompt', 'fixture',
        { origin, context: f.host, contextEnvelope: 'fixture context', mode, taskKey: 'mail:fixture', background: true },
        validate || (raw => inbox.normalizeInboxLetters(raw, bank, plan, new Date(date))));
    return { ...f, copy, run, progress, requests, origin, recovery, get automaticContinuations() { return automaticContinuations; }, get calls() { return calls; }, get stored() { return stored; },
        get handle() { return handle; }, resume: async () => { recovery.detachGenerationRecovery(origin); handle = await create(stored); } };
}

test('real request retains the complete first letter and raw truncation, then accepts only missing daily and replays without paying again', async () => {
    const f = await fixture([truncated, JSON.stringify({ letters: [daily] })]);
    await assert.rejects(f.run(), { code: 'RMT_INBOX_INCOMPLETE' });
    assert.equal(f.calls, 1);
    assert.equal(f.automaticContinuations, 0);
    assert.equal(f.stored.segments[0].partial, truncated);
    assert.equal(f.stored.segments[0].state, 'truncated');
    const shown = await f.progress.projectGenerationProgress(f.stored, { context: f.host });
    assert.deepEqual(slots(shown.letters), ['stage']);
    assert.equal(shown.letters[0].body, stage.body);
    await f.resume();
    const completed = await f.run();
    assert.deepEqual(slots(completed.letters), ['stage', 'daily']);
    assert.equal(completed.letters[0].body, stage.body);
    assert.equal(completed.letters[1].body, daily.body);
    assert.equal(f.calls, 2);
    assert.match(f.requests[1], /阶段原信/);
    await f.resume();
    assert.deepEqual(slots((await f.run()).letters), ['stage', 'daily']);
    assert.equal(f.calls, 2);
});

test('real request selects damaged final inbox after earlier valid JSON example; recovery makes the identical selection', async () => {
    const raw = 'Example format: {"letters":[]}\nFinal answer:\n' + damaged;
    const f = await fixture([raw]);
    assert.deepEqual(slots((await f.run()).letters), ['stage', 'daily']);
    assert.deepEqual(slots(parseInboxRecoveryObject(raw).items('/letters')), ['stage', 'daily']);
    assert.equal(f.calls, 1);
});

test('closed reasoning is discarded before the real response check, even if it contains fake JSON', async () => {
    const raw = '<think>{"letters":[{"slot":"stage","title":"示例","body":"思考不是答案"}]}</think>\n' + damaged;
    const f = await fixture([raw]);
    const result = await f.run();
    assert.equal(result.letters[0].body, stage.body);
    assert.deepEqual(slots(result.letters), ['stage', 'daily']);
    assert.equal(f.calls, 1);
});

test('example and final payloads are never pooled to fill different mail slots', async () => {
    const raw = 'Example:\n' + JSON.stringify({ letters: [stage] }) + '\nFinal:\n{"letters":[' + corrupt(daily) + ']}';
    const f = await fixture([raw]);
    await assert.rejects(f.run(), { code: 'RMT_INBOX_INCOMPLETE' });
    const shown = await f.progress.projectGenerationProgress(f.stored, { context: f.host });
    assert.deepEqual(slots(shown.letters), ['daily']);
    assert.equal(f.calls, 1);
});

test('thinking only and unclosed thinking never supply final JSON; markup pages and attributes stay rejected', () => {
    for (const raw of ['<think>' + JSON.stringify({ letters: [stage, daily] }) + '</think>', '<think>' + JSON.stringify({ letters: [stage, daily] })])
        assert.throws(() => assertIndependentResponsePayload(raw), error => /^RMT_JSON_EMPTY_FINAL/.test(error.code));
    for (const raw of ['<html>' + damaged + '</html>', '<think>work</think><div>' + damaged + '</div>', '<think data-x="1">work</think>' + damaged, damaged + '<script>alert(1)</script>'])
        assert.throws(() => assertIndependentResponsePayload(raw), { code: 'RMT_RESPONSE_HTML' });
    const raw = JSON.stringify({ letters: [{ ...daily, body: '<span>作为文字保存</span> <think>也是字面内容</think>' }] });
    assert.equal(assertIndependentResponsePayload(raw), raw);
    assert.deepEqual(extractJson(raw), JSON.parse(raw));
});

test('resume never conceals extra slots, duplicate slots, or a missing body behind retained letters', async () => {
    for (const letters of [[daily, { ...stage, slot: 'other' }], [daily, daily], [{ slot: 'daily', title: '缺正文' }]]) {
        const f = await fixture([truncated, JSON.stringify({ letters })]);
        await assert.rejects(f.run());
        await f.resume();
        await assert.rejects(f.run());
        assert.notEqual(f.stored.segments[0].state, 'complete');
        assert.equal(f.calls, 2);
        const shown = await f.progress.projectGenerationProgress(f.stored, { context: f.host });
        assert.ok(shown.letters.some(letter => letter.body === stage.body));
    }
});


test('received incomplete mail survives an actual failed durable save in page memory without publishing success or requesting again', async () => {
    const f = await fixture([truncated], { failPaidSave: true });
    let failure;
    await assert.rejects(f.run(), error => { failure = error; return error.code === 'RMT_RECOVERY_STORAGE'; });
    assert.equal(f.calls, 1);
    assert.equal(f.automaticContinuations, 0);
    assert.equal(f.handle.journal.segments[0].partial, truncated);
    assert.notEqual(f.stored.segments[0].state, 'complete');
    assert.equal(f.recovery.generationRecoveryHeldReplies(f.origin, 'inbox')[0].rawJson, truncated);
    assert.ok(!JSON.stringify(failure).includes(stage.body));
});

test('valid original full answer remains unchanged through the real request, including literal markup strings', async () => {
    const full = { letters: [{ ...stage, body: '<span>读书</span> ' + stage.body }, daily] };
    const f = await fixture([JSON.stringify(full)]);
    const result = await f.run();
    assert.equal(result.letters[0].body, full.letters[0].body);
    assert.equal(result.letters[1].body, daily.body);
    assert.equal(f.stored.segments[0].state, 'complete');
    assert.equal(f.calls, 1);
});

test('reasoning-only reply does not start an extra paid attempt', async () => {
    const f = await fixture(['<think>' + JSON.stringify({ letters: [stage, daily] }) + '</think>']);
    await assert.rejects(f.run(), { code: 'RMT_JSON_EMPTY_FINAL_WITH_REASONING' });
    assert.equal(f.calls, 1);
    assert.equal(f.requests.length, 1);
});

test('broken optional top-level illustration before letters does not hide the final letters in real request or recovery', async () => {
    const raw = '{"illustration":{"scene":{"evidence":"写信"错误解释}},"letters":[' + JSON.stringify(stage) + ',' + JSON.stringify(daily) + ']}';
    for (const prefix of ['', 'Example: {"letters":[]}\nFinal:\n']) {
        const f = await fixture([prefix + raw]);
        const result = await f.run();
        assert.deepEqual(slots(result.letters), ['stage', 'daily']);
        assert.equal(result.letters[0].body, stage.body);
        assert.equal(result.letters[1].body, daily.body);
        assert.deepEqual(slots(parseInboxRecoveryObject(prefix + raw).items('/letters')), ['stage', 'daily']);
        assert.equal(f.calls, 1);
    }
});

test('broken leading optional metadata cannot borrow a missing letter from an earlier example', async () => {
    const raw = 'Example: ' + JSON.stringify({ letters: [stage] }) + '\nFinal:\n'
        + '{"illustration":{"scene":{"evidence":"写信"错误解释}},"letters":[' + JSON.stringify(daily) + ']}';
    const f = await fixture([raw]);
    await assert.rejects(f.run(), { code: 'RMT_INBOX_INCOMPLETE' });
    const shown = await f.progress.projectGenerationProgress(f.stored, { context: f.host });
    assert.deepEqual(slots(shown.letters), ['daily']);
    assert.deepEqual(slots(parseInboxRecoveryObject(raw).items('/letters')), ['daily']);
    assert.equal(f.calls, 1);
});

test('non-mail trailing brace and unmatched prose brace before an independent JSON fence cannot replace a complete mailbox', async () => {
    const a = { slot: 'stage', title: '节点', body: '看书' }, b = { slot: 'daily', title: '日常', body: '你好' };
    const broken = '{"letters":[' + JSON.stringify(a).slice(0, -1) + ',"letterIllustration":{"evidence":"书"文字}},' + JSON.stringify(b) + ']}';
    for (const raw of [broken + '\n注：{', '说明 {\n```json\n' + broken + '\n```']) {
        const f = await fixture([raw]);
        const result = await f.run();
        assert.deepEqual(slots(result.letters), ['stage', 'daily']);
        assert.deepEqual(Array.from(result.letters, row => row.body), ['看书', '你好']);
        assert.deepEqual(slots(parseInboxRecoveryObject(raw).items('/letters')), ['stage', 'daily']);
        assert.equal(f.calls, 1);
    }
});

test('the later unfinished mailbox still wins over a prior complete example even with independent fences', async () => {
    const raw = '```json\n' + JSON.stringify({ letters: [stage, daily] }) + '\n```\nFinal:\n'
        + '{"letters":[{"slot":"daily","title":"最终信","body":"最终收到的正文。"},{"slot":"stage","body":"尚未完成';
    const f = await fixture([raw]);
    await assert.rejects(f.run(), { code: 'RMT_INBOX_INCOMPLETE' });
    const shown = await f.progress.projectGenerationProgress(f.stored, { context: f.host });
    assert.deepEqual(slots(shown.letters), ['daily']);
    assert.equal(shown.letters[0].body, '最终收到的正文。');
    assert.deepEqual(slots(parseInboxRecoveryObject(raw).items('/letters')), ['daily']);
    assert.equal(f.calls, 1);
});


test('an answer that has only started its letters field never falls back to the earlier example or adds an automatic request', async () => {
    for (const final of ['{"letters":', '{"letters":[']) {
        const raw = 'Example: ' + JSON.stringify({ letters: [stage, daily] }) + '\nFinal:\n' + final;
        const f = await fixture([raw, JSON.stringify({ letters: [stage, daily] })]);
        let failure;
        await assert.rejects(f.run(), error => { failure = error; return error.code === 'RMT_JSON_TRUNCATED'; });
        assert.equal(f.calls, 1);
        assert.equal(f.automaticContinuations, 0);
        assert.equal(f.stored.segments[0].partial, raw);
        assert.deepEqual(slots(parseInboxRecoveryObject(raw).items('/letters')), []);
        assert.doesNotMatch(failure.safeUserMessage, /会自动/);
        await f.resume();
        assert.deepEqual(slots((await f.run()).letters), ['stage', 'daily']);
        assert.equal(f.calls, 2);
    }
});

test('an ordinary existing truncation keeps its established continuation handler behavior', async () => {
    const f = await fixture(['{"letters":[']);
    await assert.rejects(f.run(), { code: 'RMT_JSON_TRUNCATED' });
    assert.equal(f.calls, 1);
    assert.equal(f.automaticContinuations, 1);
});


test('a real non-mail request keeps a later legal non-mail answer ahead of an earlier mailbox example', async () => {
    const raw = 'Example:\n{"letters":[]}\nFinal:\n{"items":[{"id":"new","name":"书签"}]}';
    const f = await fixture([raw], { mode: 'cabinet', validate: value => { assert.equal(value.items?.[0]?.name, '书签'); return value; } });
    const result = await f.run();
    assert.equal(result.items[0].id, 'new');
    assert.equal(result.letters, undefined);
    assert.equal(extractJson(raw).items[0].name, '书签');
    assert.equal(f.calls, 1);
});

test('inbox validation and recovery reject a later legal non-mail answer without adopting a preceding complete mailbox example', async () => {
    const raw = 'Example:\n' + JSON.stringify({ letters: [stage, daily] }) + '\nFinal:\n{"items":[{"id":"new","name":"书签"}]}';
    const f = await fixture([raw]);
    await assert.rejects(f.run(), { code: 'RMT_INBOX_INCOMPLETE' });
    assert.deepEqual(slots(parseInboxRecoveryObject(raw).items('/letters')), []);
    assert.equal(await f.progress.projectGenerationProgress(f.stored, { context: f.host }), null);
    assert.equal(f.calls, 1);
});

test('rejecting a non-mail example before the actual unfinished mailbox does not add automatic paid continuation', async () => {
    const raw = 'Example: {"items":[]}\nFinal:\n{"letters":';
    const f = await fixture([raw, JSON.stringify({ letters: [stage, daily] })]);
    await assert.rejects(f.run(), { code: 'RMT_JSON_TRUNCATED' });
    assert.equal(f.calls, 1);
    assert.equal(f.automaticContinuations, 0);
    assert.equal(f.stored.segments[0].partial, raw);
    await f.resume();
    assert.deepEqual(slots((await f.run()).letters), ['stage', 'daily']);
    assert.equal(f.calls, 2);
});
