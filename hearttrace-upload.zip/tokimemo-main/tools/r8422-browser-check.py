"""Run real Chromium UI + native IDB tests; no external network/model calls.
Usage: python tools/r8422-browser-check.py --out /absolute/evidence/folder
Requires installed Python Playwright and Chromium. Does not install dependencies.
"""
import argparse, contextlib, functools, http.server, json, pathlib, threading, time
from playwright.sync_api import sync_playwright

parser = argparse.ArgumentParser()
parser.add_argument('--out', required=True)
args = parser.parse_args()
root = pathlib.Path(__file__).resolve().parent.parent
out = pathlib.Path(args.out); out.mkdir(parents=True, exist_ok=True)
class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *args): pass
handler = functools.partial(QuietHandler, directory=str(root))
server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), handler)
threading.Thread(target=server.serve_forever, daemon=True).start()
url = f'http://127.0.0.1:{server.server_port}/tools/r8422-browser.html'
results = {'environment': 'Chromium, real DOM/native IndexedDB; synthetic host/provider/tokenizer', 'cases': [], 'browser': ''}
try:
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
        results['browser'] = browser.version
        context = browser.new_context(viewport={'width': 1280, 'height': 900}, device_scale_factor=1)
        # Any accidental external service traffic is prohibited in this fixture.
        context.route('**/*', lambda route: route.continue_() if route.request.url.startswith('http://127.0.0.1:') or route.request.url.startswith('data:') else route.abort())
        page = context.new_page()
        page.goto(url); page.wait_for_function('window.fixture?.ready', timeout=30000)
        errors = page.evaluate('fixture.errors'); assert not errors, errors
        before = page.evaluate('fixture.snapshot()')
        assert before['cursor'] is None and before['memoryCount'] == 1
        selector = '[data-rmt-action="current-archive-import"], [data-rmt-action="import-memory"]'
        assert page.locator(selector).count() > 0, 'Actual production import button absent'
        for batch in range(1, 4):
            started = time.perf_counter()
            page.locator(selector).first.click()
            page.wait_for_function('(n)=>!fixture.state.busy && fixture.ctx.chatMetadata.heartbeatMemoriesArchiveV3?.archiveImportProgress?.nextBatch===n', arg=batch, timeout=45000)
            snap = page.evaluate('fixture.snapshot()')
            assert snap['cursor'] == snap['backupCursor'] == batch, snap
            assert snap['canonicalRevision'] == snap['backupRevision']
            assert not snap['errors'], snap['errors']
            results['cases'].append({'name': f'actual-click/native-save/reopen-batch-{batch}', 'pass': True, 'ms': round((time.perf_counter()-started)*1000), 'snapshot': snap})
            if batch == 1:
                for width, height, theme, label in [(1280,900,'default','desktop-light'),(1280,900,'night','desktop-dark'),(390,844,'default','mobile-light'),(390,844,'night','mobile-dark')]:
                    page.set_viewport_size({'width':width,'height':height}); page.evaluate('(mode)=>fixture.theme(mode)',theme)
                    banner=page.locator('.rmt-recovery-status').first
                    banner.scroll_into_view_if_needed()
                    bbox=banner.bounding_box(); assert bbox and bbox['width']>100
                    assert bbox['x'] >= -1 and bbox['x']+bbox['width'] <= width+1, (label,bbox)
                    page.screenshot(path=str(out/f'{label}.png'), full_page=True)
                    results['cases'].append({'name':f'{label} banner/control layout (viewport simulation)', 'pass':True, 'box':bbox})
                page.set_viewport_size({'width':1280,'height':900})
            calls = len(snap['requests']); time.sleep(.1)
            assert page.evaluate('fixture.requests.length') == calls, 'Unexpected automatic next batch'
            if batch<3:
                page.close(); page=context.new_page(); page.goto(url); page.wait_for_function('window.fixture?.ready')
                reopened=page.evaluate('fixture.snapshot()'); assert reopened['cursor']==batch and len(reopened['requests'])==calls
        sent=page.evaluate('fixture.requests.flatMap(r=>r.ids)')
        assert len(sent)==610 and len(set(sent))==610, (len(sent),len(set(sent)))
        assert page.evaluate('fixture.requests.every(r=>r.responseLength===12000)')
        results['cases'].append({'name':'610 sources / 610k UTF16 characters / three batches / no repeated sources / original output unchanged','pass':True})
        context.close()
        # A separate browser storage partition: abort a REAL IDB write, close the page,
        # reopen and click the real button. The retry must not call the provider again.
        context=browser.new_context(viewport={'width':1280,'height':900})
        context.route('**/*', lambda route: route.continue_() if route.request.url.startswith('http://127.0.0.1:') else route.abort())
        page=context.new_page(); page.goto(url); page.wait_for_function('fixture?.ready')
        page.evaluate('fixture.abortOneNativeWrite()'); page.locator(selector).first.click()
        page.wait_for_function('!fixture.state.busy && fixture.requests.length>0',timeout=45000)
        failed=page.evaluate('fixture.snapshot()')
        assert failed['cursor'] is None and failed['backupCursor'] is None and failed['pendingSave'],failed
        calls=len(failed['requests'])
        page.close();page=context.new_page();page.goto(url);page.wait_for_function('fixture?.ready')
        reloaded=page.evaluate('fixture.snapshot()');assert reloaded['pendingSave'],reloaded
        page.locator(selector).first.click();page.wait_for_function('!fixture.state.busy && fixture.ctx.chatMetadata.heartbeatMemoriesArchiveV3?.archiveImportProgress?.nextBatch===1',timeout=45000)
        saved=page.evaluate('fixture.snapshot()')
        assert len(saved['requests'])==calls and saved['cursor']==saved['backupCursor']==1,saved
        results['cases'].append({'name':'native IDB transaction abort / page destroyed / durable retry save-only', 'pass':True,'failed':failed,'saved':saved})
        context.close();browser.close()
except Exception as exc:
    results['error']=str(exc)
    raise
finally:
    server.shutdown()
    (out/'browser-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'cases':len(results['cases']),'passed':sum(x['pass'] for x in results['cases']),'browser':results['browser']},ensure_ascii=False))
