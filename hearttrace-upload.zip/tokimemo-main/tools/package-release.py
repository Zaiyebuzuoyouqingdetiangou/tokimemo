"""Build the upload artifact and run the repository's actual ZIP import locally.

No remote git operation. The import is isolated in a fresh temporary git repo.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import textwrap
import zipfile

source = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2]).resolve()
output.mkdir(parents=True, exist_ok=True)
archive = output / 'hearttrace-upload.zip'
if archive.exists():
    raise SystemExit('Refusing to overwrite an existing release artifact')
paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=source).decode().split('\0')
payload = sorted(set(name for name in paths if name and not set(Path(name).parts) & {'.git', '.github'} and not name.endswith('.zip')))
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name in payload:
        original = source / name
        if not original.is_file() or original.is_symlink():
            raise ValueError(f'Unexpected release path: {name}')
        bundle.write(original, 'tokimemo-main/' + name)
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    bundle.extractall(output / 'extracted')

workflow_path = Path('.github/workflows/import-hearttrace-zip.yml')
workflow = (source / workflow_path).read_text()
script = textwrap.dedent(workflow.split('        run: |\n', 1)[1].split('\n      - name:', 1)[0])
checkout = Path(tempfile.mkdtemp(prefix='hearttrace-import-', dir=output))
(checkout / workflow_path).parent.mkdir(parents=True)
shutil.copy2(source / workflow_path, checkout / workflow_path)
shutil.copy2(archive, checkout / archive.name)
def git(*args):
    return subprocess.run(['git', *args], cwd=checkout, check=True, capture_output=True, text=True)
git('init', '-q')
git('add', '--', '.github', archive.name)
git('-c', 'user.name=Local validation', '-c', 'user.email=local@example.invalid', 'commit', '-qm', 'Seed isolated ZIP import')
result = subprocess.run([sys.executable, '-c', script], cwd=checkout,
    env={**os.environ, 'EXPECTED_REPOSITORY': 'Zaiyebuzuoyouqingdetiangou/tokimemo', 'TARGET_BRANCH': '测试'},
    capture_output=True, text=True)
if result.returncode:
    print(result.stdout)
    print(result.stderr)
    raise SystemExit(result.returncode)
assert not (checkout / archive.name).exists()
assert (checkout / workflow_path).read_bytes() == (source / workflow_path).read_bytes()
for name in ['index.js', 'manifest.json', 'dist/heartbeatMemories.bundle.js', *[file for file in payload if file.startswith('src/')]]:
    assert (checkout / name).read_bytes() == (source / name).read_bytes(), name
report = {'archive': str(archive), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
          'bytes': archive.stat().st_size, 'entries': len(payload), 'workflowImportExit': result.returncode,
          'workflowPreserved': True, 'transportZipRemoved': True, 'productionBytesMatch': True,
          'extractedRoot': str(output / 'extracted/tokimemo-main'), 'localImportRoot': str(checkout)}
(output / 'package-check.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
