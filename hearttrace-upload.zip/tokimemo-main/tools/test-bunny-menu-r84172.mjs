// r84.172 · 图片操作收进图片外右下角的小兔子菜单；前世今生里光栅卡和图片按钮并成一个菜单；
// 去掉阅读页里出戏的说明文字（虚构、真实来源、Mxxx 编号、额度提示）。
import test from 'node:test';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { preparationFixture } from './preparation-harness-r8481.mjs';

async function render() {
    const f = await preparationFixture();
    const copy = value => vm.runInContext(`JSON.parse(${JSON.stringify(JSON.stringify(value))})`, f.sandbox);
    f.sandbox.structuredClone = copy;
    const session = copy({ kind: 'pastLives', version: 1, title: '前世今生', presentation: 'neutral', chatId: 'preparation-check', archiveRevision: 'rev1', characterName: '岚', userName: '阿宁',
        episodes: [{ id: 'PL01', title: '灯下', fiction: true, presentation: 'neutral', opening: { title: '信', motif: '旧信', text: '灯下展开旧信。', sourceMemoryIds: ['M001'], sourceMemoryAnchor: '一起读' },
            dossiers: [{ id: 'D01', title: '前世', era: '长安', synopsis: '灯下研墨。', clues: [{ id: 'D01-C01', kind: 'object', title: '砚', text: '一方旧砚。' }] }], annotations: [],
            echoes: [{ id: 'E01', title: '回响', text: '一起读书', kind: 'memory', sourceMemoryIds: ['M023'], sourceMemoryAnchor: '读书' }] }],
        selectedId: 'PL01', selectedEntryId: 'D01', selectedKey: 'D01-C01', view: 'dossier' });
    return { f, copy, session, view: await f.api('ui/pastLivesView.js'), targets: await f.api('core/cgTargets.js') };
}

test('前世卷宗：一个兔子菜单，里面有图片操作和挑今生；没有另起一排按钮', async () => {
    const { copy, session, view, targets } = await render();
    targets.cgTargetInSession('pastLives', session, 'rmtcg2:past-life-dossier:PL01:dossier%3AD01').cgImage = copy({ url: '/user/images/p.png', generatedAt: 1 });
    const html = view.pastLivesHtml(session);
    assert.equal((html.match(/class="rmt-cg-menu"/g) || []).length, 1);
    const menu = html.slice(html.indexOf('class="rmt-cg-menu-list"'));
    for (const label of ['查看大图', '编辑画面 / 再画一张', '挑一张今生']) assert.ok(menu.includes(label), label);
    assert.equal(html.includes('rmt-cg-card-actions'), false);
    assert.equal(html.includes('rmt-lenticular-actions'), false);
});

test('去掉出戏的说明：虚构、真实来源、Mxxx 编号', async () => {
    const { session, view } = await render();
    const html = view.pastLivesHtml(session);
    assert.equal(/虚构|真实来源|番外推演|生成额度/.test(html), false);
    session.view = 'echoes';
    const echoes = view.pastLivesHtml(session);
    assert.equal(/M023|记忆来源|今生真实记忆/.test(echoes), false);
    session.view = 'draw'; session.pastLivesDrawn = true;
    assert.equal(/M001|引子的今生来源/.test(view.pastLivesHtml(session)), false);
});

test('其他模块的图：有图时兔子菜单，没图时只留一个带兔子的设置按钮；样式和收起已接上', async () => {
    const src = await readFile(new URL('../src/ui/expandedCgView.js', import.meta.url), 'utf8');
    assert.match(src, /image_menu\.imageMenuHtml\(expandedCgButtonsHtml\(/);
    assert.match(src, /image_menu\.imageSetupHtml\(/);
    assert.equal(src.includes('<div class="rmt-cg-card-actions">'), false);
    const styles = await readFile(new URL('../src/ui/styles.js', import.meta.url), 'utf8');
    assert.match(styles, /ui_imageMenu\.imageMenuCss\(/);
    assert.match(styles, /ui_imageMenu\.installImageMenuDismiss\(document\)/);
    const bed = await readFile(new URL('../src/ui/bedtimeView.js', import.meta.url), 'utf8');
    assert.equal(bed.includes('虚构作品'), false);
});
