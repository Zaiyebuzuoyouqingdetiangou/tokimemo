// r84.175 · 手帐第二包：版式、从聊天摘句、夹进手帐、角色批注（一次批注多页 + 搭自动留忆的便车）。
import vm from 'node:vm';
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { preparationFixture } from './preparation-harness-r8481.mjs';

const read = file => readFile(new URL(file, import.meta.url), 'utf8');
function fakeIndexedDB() {
    let saved;
    return { open() { const request = {}; queueMicrotask(() => { request.result = { objectStoreNames: { contains: () => true }, close() {}, transaction() { const tx = { objectStore() { return { get() { const r = {}; setTimeout(() => { r.result = saved; r.onsuccess(); setTimeout(() => tx.oncomplete?.(), 0); }, 0); return r; }, put(value) { saved = JSON.parse(JSON.stringify(value)); } }; }, abort() { tx.onabort?.(); } }; return tx; } }; request.onsuccess(); }); return request; } };
}
const entry = text => ({ id: 'e', title: '雨夜', source: { mode: 'bedtime', id: 's', title: '' }, blocks: [{ type: 'text', text }] });

test('一次批注多页：提示里带各页文字；回来的结果宽松收下', async () => {
    const f = await preparationFixture();
    const j = await f.api('core/handJournal.js');
    const copy = value => vm.runInContext(`JSON.parse(${JSON.stringify(JSON.stringify(value))})`, f.sandbox);
    const pages = [j.createJournalPage(copy({ id: 'a', createdAt: 1, title: '雨夜', entries: [entry('差一点泡烂发绳')] })), j.createJournalPage(copy({ id: 'b', createdAt: 2, title: '集市', entries: [] }))];
    const prompt = j.journalAnnotationPrompt(pages, { charName: '方祁洛', userName: '阿宁' });
    assert.match(prompt, /你是方祁洛/);
    assert.ok(prompt.includes('差一点泡烂发绳') && prompt.includes('"pageId":"a"'));
    const notes = j.parseJournalAnnotations(copy({ notes: [{ pageId: 'a', text: '下次我给你撑伞。' }, { pageId: 'zz', text: '不存在' }, { pageId: 'b', text: '  ' }, { pageId: 'a', text: '重复' }], extra: 1 }), pages);
    assert.deepEqual(JSON.parse(JSON.stringify(notes)), { a: '下次我给你撑伞。' });
    assert.deepEqual(JSON.parse(JSON.stringify(j.parseJournalAnnotations(null, pages))), {});
});

test('批注写入：清掉「等批注」；找不到的页跳过；版式可换可存', async () => {
    const f = await preparationFixture();
    const j = await f.api('core/handJournal.js');
    const store = j.createJournalStore({ indexedDB: fakeIndexedDB(), currentScope: () => 'chat' });
    await store.append('chat', [j.createJournalPage({ id: 'a', createdAt: 1, title: '雨夜', entries: [], annotationWanted: true }), j.createJournalPage({ id: 'b', createdAt: 2, title: '集市', entries: [] })]);
    assert.equal((await store.read('chat'))[0].annotationWanted, true);
    await store.annotate('chat', { a: { text: '下次我给你撑伞。', at: 5, by: '方祁洛' }, gone: { text: 'x', at: 5 } });
    await store.layout('chat', 'b', 'timeline');
    const [a, b] = await store.read('chat');
    assert.equal(a.annotation.text, '下次我给你撑伞。');
    assert.equal(a.annotation.by, '方祁洛');
    assert.equal('annotationWanted' in a, false);
    assert.equal(b.layout, 'timeline');
    await store.layout('chat', 'b', 'nonsense');
    assert.equal('layout' in (await store.read('chat'))[1], false, '认不出的版式退回默认');
});

test('搭便车：只在最后一步、有等批注的页时加这一段；字段从正文里拆走', async () => {
    const f = await preparationFixture();
    const cap = await f.api('generation/achievementCapture.js');
    const copy = value => vm.runInContext(`JSON.parse(${JSON.stringify(JSON.stringify(value))})`, f.sandbox);
    assert.equal(cap.achievementPromptSuffix(), '', '没武装时不加');
    cap.armAchievementCapture(copy({ journalPages: [], charName: '方祁洛', userName: '阿宁' }));
    assert.equal(cap.achievementPromptSuffix().includes('journalNotes'), false, '没有等批注的页时只有成就');
    cap.finishAchievementCapture();
    cap.armAchievementCapture(copy({ journalPages: [{ pageId: 'a', text: '雨夜' }], charName: '方祁洛', userName: '阿宁' }));
    const suffix = cap.achievementPromptSuffix();
    assert.ok(suffix.includes('"achievement"') && suffix.includes('journalNotes') && suffix.includes('"pageId":"a"'));
    const body = cap.stripAchievementField(copy({ entries: [1], achievement: { title: 't' }, journalNotes: [{ pageId: 'a', text: '撑伞' }, { pageId: 'x', text: '别的' }] }));
    assert.deepEqual(Object.keys(body), ['entries'], '正文里不留这两个字段');
    assert.deepEqual(JSON.parse(JSON.stringify(cap.takeJournalNotes())), { a: '撑伞' });
    assert.equal(cap.finishAchievementCapture().title, 't');
    const host = await read('../src/autoMemory/moduleHost.js');
    assert.match(host, /carryAchievement \? await journal_piggyback\.wantedJournalPages\(\)/);
    assert.match(host, /journal_piggyback\.saveJournalNotes\(wanted\.scope, journalNotes/);
});

test('界面：版式、摘句、批注按钮、夹进手帐都接上了', async () => {
    const view = await read('../src/ui/handJournalView.js');
    for (const needle of ['data-journal-layout-new', 'data-journal-layout=', 'data-journal-quote-floor', 'data-journal-quote-preview', 'data-journal-annotate', 'rmt-journal-annotation', 'rmt-journal-layout-'])
        assert.ok(view.includes(needle), needle);
    assert.match(view, /会发 1 次文字请求/);
    assert.equal(/temperatureCeiling/.test(view), false, '不限温度');
    for (const file of ['../src/ui/expandedCgView.js', '../src/ui/autoMemoryShell.js', '../src/ui/albumView.js'])
        assert.ok((await read(file)).includes('data-rmt-journal-clip'), file);
    assert.match(await read('../src/ui/overlayClickTargets.js'), /journal_clip\.clipToJournal\(clipButton\.dataset\.rmtJournalClip\)/);
    assert.match(await read('../src/ui/journalClip.js'), /annotationWanted: true/);
});
