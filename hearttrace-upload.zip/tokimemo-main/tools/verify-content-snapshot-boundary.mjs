// Synthetic long archive build -> content partial -> reload -> continue, no paid provider.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import http from 'node:http';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const repoRoot = path.resolve(process.env.CONTENT_SNAPSHOT_ROOT || path.join(path.dirname(fileURLToPath(import.meta.url)), '..'));
const outputDir = path.resolve(process.env.CONTENT_SNAPSHOT_OUTPUT || path.join(repoRoot, 'artifacts', 'content-snapshot-boundary'));
const prefix = '/scripts/extensions/third-party/hearttrace/';
const build = JSON.parse(await readFile(path.join(repoRoot, 'manifest.json'), 'utf8')).js;
const sha = value => createHash('sha256').update(value).digest('hex');
const artifactNames = ['index.js', 'dist/heartbeatMemories.bundle.js'];
const artifactHashes = Object.fromEntries(await Promise.all(artifactNames.map(async name => [name, sha(await readFile(path.join(repoRoot, name)))])));
const scene = '小月、林舟、沈砚和阿青在庭院一起栽花。林舟扶住花苗，沈砚递来工具，阿青和小月浇水。';

const selectors = {
    menu: '#heartbeat_memories_menu_item', archiveTab: '.rmt-workspace-tabs [data-rmt-workspace-tab="archive"]',
    settingsTab: '.rmt-workspace-tabs [data-rmt-workspace-tab="settings"]',
    import: '[data-rmt-action="import-memory"]', picker: '.rmt-participant-dialog',
    single: '[data-rmt-card-type="single"]', multi: '[data-rmt-card-type="multi"]',
    book: '[data-rmt-participant-book]', entry: '[data-rmt-participant-entry]', name: '[data-rmt-participant-name]',
    confirm: '[data-rmt-participant-confirm]', close: '[data-rmt-participant-close]',
    status: '[data-rmt-participant-status]', reopen: '[data-rmt-action="participants-picker"]',
};
const chunkReply = { memories: [{ title: '一起栽花', summary: scene, anchors: ['庭院', '花苗'],
    participants: ['小月', '林舟', '沈砚', '阿青'], messageStart: 1, messageEnd: 1 }] };
const profileReply = {
    archiveName: '一起栽花', archiveSummary: '住户在庭院共同照料花苗。', keywords: ['庭院', '花苗'],
    relationshipReading: { char: '认真配合', user: '共同投入', relation: '一起劳动', tension: '尚无明确矛盾', direction: '合作逐渐熟悉' },
    verdictStyle: 'quiet-life',
    archiveVerdict: '一盆花的生长还需要往后的许多日子，彼此的配合也从这样具体的小事开始。他们没有急着给关系下定义，只把注意力放在眼前需要完成的事情上。在彼此都愿意投入的这段时间里，默契获得了一个可以慢慢生长的位置。故事没有把未来提前写好，留下的只是这次共同劳动，以及下一回仍有机会一起照料的期待。',
    verdictSources: [{ memoryId: 'M001', anchor: '庭院' }],
};

function hostPage(seed) {
    return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<style>*{box-sizing:border-box}body{margin:0;font-family:sans-serif;background:#eee}#extensionsMenu,#extensions_settings2{padding:8px}</style>
</head><body><div id="extensions_settings2"></div><div id="extensionsMenu"></div><script>
const seed=${JSON.stringify(seed).replace(/</g, '\\u003c')};
const copy=value=>value==null?value:JSON.parse(JSON.stringify(value));
const metadataKey='participants-host-metadata',settingsKey='participants-host-settings';
const calls={requests:JSON.parse(localStorage.getItem('snapshot-calls')||'[]'),books:[],metadataSaves:0,settingsSaves:0,notices:[]};
const profile={id:'participants-profile',name:'Synthetic profile',mode:'cc',api:'openai',model:'fixture-model','secret-id':'synthetic-only'};
let replyKind=localStorage.getItem('snapshot-stage')||'archive';
const context={characterId:0,groupId:null,chatId:seed.chatId,name1:'小月',name2:seed.cardName,
 characters:[{name:seed.cardName,avatar:'fixture.png',data:{name:seed.cardName,description:seed.description,personality:'按各自世界书人物资料行动。'}}],
 chat:[{is_user:true,name:'小月',mes:seed.scene}],powerUserSettings:{persona_description:'温和的花店店主。'},
 chatMetadata:JSON.parse(localStorage.getItem(metadataKey)||JSON.stringify(seed.metadata)),
 extensionSettings:JSON.parse(localStorage.getItem(settingsKey)||JSON.stringify({heartbeatMemories:{apiConnectionMode:'profile',connectionProfileId:profile.id,
 useCurrentChatExternalMemory:false,useActivatedWorldInfo:false,maxTokens:12000},connectionManager:{profiles:[profile]}})),
 getCurrentChatId(){return this.chatId},getCharacterCardFields(){return copy(this.characters[0].data)},
 getRequestHeaders:()=>({'Content-Type':'application/json'}),getTokenCountAsync:async()=>100,
 getWorldInfoNames:()=>['人物书'],loadWorldInfo:async name=>{calls.books.push(name);return {entries:{
 1:{uid:1,comment:'林舟',key:['林舟'],content:'林舟黑发蓝眼，认真而克制，住在现代都市的共用书房。这个条目也可以由用户确认用于另一人。'},
 2:{uid:2,comment:'沈砚',key:['沈砚'],content:'沈砚白发绿眼，喜欢整理书架，和其他住户共用书房。'}}}},
 saveMetadataDebounced(){calls.metadataSaves++;localStorage.setItem(metadataKey,JSON.stringify(context.chatMetadata))},
 saveSettingsDebounced(){calls.settingsSaves++;localStorage.setItem(settingsKey,JSON.stringify(context.extensionSettings))},
 eventTypes:{},eventSource:{on(){},off(){}},
 ConnectionManagerRequestService:{validateProfile:()=>({selected:'openai',source:'openai'}),
 async sendRequest(profileId,messages,outputTokens,options,overridePayload){
  const payload={secret_id:profile['secret-id'],model:profile.model,...overridePayload};
  if(profileId!==profile.id||payload.secret_id!=='synthetic-only')throw new Error('Unexpected profile route');
  calls.requests.push({profileId,messages:copy(messages),outputTokens,payload:copy(payload),hasSignal:options?.signal instanceof AbortSignal,replyKind});
  localStorage.setItem('snapshot-calls',JSON.stringify(calls.requests));
  let response;
  if(replyKind==='archive'){
   const count=calls.requests.filter(row=>row.replyKind==='archive').length;
   if(count>2)throw new Error('Unexpected archive retry or extra model request');
   response=count===1?seed.chunkReply:seed.profileReply;
  }else{
   const text=messages.map(row=>row.content||'').join('\\n');
   if(text.includes('EXISTING_ALBUM_INDEX_JSON'))response=seed.albumIndex;
   else if(replyKind==='fail')throw Object.assign(new Error('Synthetic interruption after successful album index'),{code:'RMT_MANUAL_HTTP',status:400});
   else response=text.includes('ALBUM_RELATIONSHIP_FULL_ARCHIVE_JSON')?seed.relationship:seed.comments;
  }
  return {content:JSON.stringify(response)};
 }} };
globalThis.SillyTavern={getContext:()=>context};
globalThis.toastr=Object.fromEntries(['error','warning','info','success'].map(level=>[level,(...args)=>calls.notices.push({level,message:args.map(String).join(' ')})]));
async function decode(value){if(value?.format!=='gzip-base64-v1')return copy(value);return JSON.parse(await new Response(new Blob([Uint8Array.from(atob(value.data),ch=>ch.charCodeAt(0))]).stream().pipeThrough(new DecompressionStream('gzip'))).text())}
async function snapshot(){return {bank:copy(context.chatMetadata.heartbeatMemoriesArchiveV3),cache:await decode(context.chatMetadata.heartbeatMemoriesTheaterV3),
 cardName:context.name2,characterName:context.characters[0].name,chat:copy(context.chat),metadata:copy(context.chatMetadata)}}
async function canonical(){
 const names=await indexedDB.databases();if(!names.some(row=>row.name==='heartbeatMemoriesArchiveBackupsV1'))return [];
 const db=await new Promise((resolve,reject)=>{const r=indexedDB.open('heartbeatMemoriesArchiveBackupsV1');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)});
 try{const rows=await new Promise((resolve,reject)=>{const tx=db.transaction('archives','readonly'),r=tx.objectStore('archives').getAll();r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)});
 return await Promise.all(rows.map(async row=>({...row,cache:await decode(row.cache)})))}finally{db.close()}
}
globalThis.__fixture={calls,snapshot,canonical,setReplyKind:value=>{replyKind=value;localStorage.setItem('snapshot-stage',value)},advanceChatAndApi(){context.chat.push({is_user:true,name:'小月',mes:'NEW_CHAT_ONLY'});context.extensionSettings.connectionManager.profiles[0].model='changed-model';context.saveSettingsDebounced()},seed:copy(seed)};
</script><script type="module" src="${prefix}${build}"></script></body></html>`;
}


let activeSeed;
const routes={bundle:0,source:[],external:[],unexpected:[]};
const server=http.createServer(async(req,res)=>{
 const url=new URL(req.url,'http://127.0.0.1');res.setHeader('Cache-Control','no-store');
 if(url.pathname.startsWith(prefix)){
  const name=decodeURIComponent(url.pathname.slice(prefix.length)),file=path.resolve(repoRoot,name);
  if(!file.startsWith(repoRoot+path.sep)||name.startsWith('src/')){routes.source.push(name);res.writeHead(403);return res.end()}
  try{const bytes=await readFile(file);if(name.startsWith('dist/'))routes.bundle++;res.setHeader('Content-Type','text/javascript; charset=utf-8');return res.end(bytes)}catch{routes.unexpected.push(name);res.writeHead(404);return res.end()}
 }
 if(url.pathname==='/thumbnail'||url.pathname.startsWith('/characters/')){res.setHeader('Content-Type','image/svg+xml');return res.end('<svg xmlns="http://www.w3.org/2000/svg"/>')}
 if(url.pathname==='/favicon.ico'){res.writeHead(204);return res.end()}
 if(url.pathname!=='/'){routes.unexpected.push(url.pathname);res.writeHead(500);return res.end()}
 res.setHeader('Content-Type','text/html; charset=utf-8');res.end(hostPage(activeSeed));
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const origin=`http://127.0.0.1:${server.address().port}`;
await mkdir(outputDir,{recursive:true});
const browser=await chromium.launch({headless:true,...(process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE?{executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE}:{})});
const report={hashes:artifactHashes,routes,cases:[],evidence:'Public menu -> shipped index/dist; real archive build, native IndexedDB; simulated host/provider',unverified:['real TT/iOS','real model/provider','operating-system background suspension']};
async function waitState(page,predicate,label){
 const end=Date.now()+20000;let value;
 do{value=await page.evaluate(()=>__fixture.snapshot());if(predicate(value))return value;await new Promise(resolve=>setTimeout(resolve,100))}while(Date.now()<end);
 throw new Error('Timeout: '+label+'; notices='+JSON.stringify(await page.evaluate(()=>__fixture.calls.notices)));
}
async function openAlbum(page){
 await page.locator('.rmt-workspace-tabs [data-rmt-workspace-tab="content"]').click();
 await page.locator('[data-rmt-workspace-group="memory"]').click();
 await page.locator('[data-rmt-workspace-route="album"]').click();
}
try{
 for(const width of (process.env.CONTENT_SNAPSHOT_WIDTHS||'390,1280').split(',').map(Number)){
  const row={width,status:'running'};report.cases.push(row);
  activeSeed={chatId:'snapshot-'+width,cardName:'林舟',scene,metadata:{},chunkReply,profileReply,
   description:'现代都市，角色认真克制。'+'完整角色原资料。'.repeat(process.env.CONTENT_SNAPSHOT_SMALL ? 40 : 52000),
   albumIndex:{title:'相簿启动验证',entries:[{id:'CG01',title:'庭院已完成画面',desc:'林舟站在花架旁。',date:'2008/05/18',unlocked:true,category:'日常',sourceMemoryIds:['M001'],sourceMemoryAnchor:'庭院'}]},
   relationship:{charState:'同伴',userState:'共同参与',relationshipState:'同伴',relationshipSummary:'在庭院一起栽花。',relationshipSourceMemoryIds:['M001'],relationshipSourceMemoryAnchor:'庭院'},
   comments:{items:[{id:'CG01',comments:Array.from({length:6},(_,i)=>`这是已经完成的第${i+1}句共同回忆，此刻正看着照片里的花架与光线。`)}]}};
  const ctx=await browser.newContext({viewport:{width,height:900}}),page=await ctx.newPage();
  page.on('dialog',dialog=>dialog.accept());const errors=[];page.on('pageerror',error=>errors.push(String(error)));
  await ctx.route('**/*',async route=>{const url=route.request().url();if(url.startsWith(origin)||url.startsWith('data:'))return route.continue();routes.external.push(url);return route.abort()});
  try{
   await page.goto(origin);await page.locator(selectors.menu).click();await page.locator(selectors.archiveTab).click();
   await page.locator(selectors.import).click();await page.locator(selectors.single).click();
   const built=await waitState(page,s=>s.bank?.memories?.length&&s.bank?.archiveImportProgress?.nextBatch===1,'archive completed');
   const original=JSON.stringify(built.bank),progress=JSON.stringify(built.bank.archiveImportProgress);
   row.progressChars=progress.length;row.archiveSha256=sha(original);row.progressSha256=sha(progress);
   // Measure the old snapshot's bank + two selected-card copies. Production does
   // not receive injected synthetic progress: this checkpoint came from the UI build.
   row.oldMinimumSnapshotChars=original.length+activeSeed.description.length*2;
   if(!process.env.CONTENT_SNAPSHOT_SMALL)assert.ok(row.oldMinimumSnapshotChars>1200000,'fixture must exceed the existing snapshot boundary before the fix');
   assert.equal((await page.evaluate(()=>__fixture.calls.requests)).length,2,'archive needs one chunk and one profile');
   await page.evaluate(()=>__fixture.setReplyKind('fail'));await openAlbum(page);
   await page.locator('[data-rmt-generate-mode="album"]').click();
   const stopped=await waitState(page,s=>Object.values(s.cache?.__generationDraftsV2?.records||{}).some(r=>r.result?.mode==='album'&&r.journal?.failureCode),'partial album durably saved');
   const [draftId,draft]=Object.entries(stopped.cache.__generationDraftsV2.records).find(([,r])=>r.result?.mode==='album');
   assert.equal(draft.result.session.entries[0].title,'庭院已完成画面');
   if(!process.env.CONTENT_SNAPSHOT_SMALL)assert.equal(draft.journal.contentSnapshot.memoryBank.archiveImportProgress,undefined);
   assert.equal(draft.journal.contentSnapshot.memoryBank.archiveImportPaused,undefined);
   assert.equal(JSON.stringify(stopped.bank),original,'original build checkpoint must survive content generation');
   row.snapshotChars=JSON.stringify(draft.journal.contentSnapshot).length;
   const completed=draft.journal.segments.filter(s=>s.state==='complete');assert.equal(completed.length,1);
   await page.getByText('庭院已完成画面',{exact:false}).filter({visible:true}).first().waitFor();
   await page.getByText('庭院已完成画面',{exact:false}).filter({visible:true}).first().scrollIntoViewIfNeeded();
   await page.screenshot({path:path.join(outputDir,`partial-${width}.png`),fullPage:true});
   await page.reload();await page.locator(selectors.menu).click();await openAlbum(page);
   await page.getByText('庭院已完成画面',{exact:false}).filter({visible:true}).first().waitFor();
   await page.evaluate(()=>{__fixture.advanceChatAndApi();__fixture.setReplyKind('resume')});
   await page.locator(selectors.archiveTab).click();
   const retry=page.locator('[data-rmt-recovery-mode="album"]');
   await retry.first().click();
   const done=await waitState(page,s=>s.cache?.album?.entries?.[0]?.comments?.length===6,'completed album');
   assert.equal(JSON.stringify(done.bank),original);
   const calls=await page.evaluate(()=>__fixture.calls.requests);
   const indexes=calls.filter(c=>c.messages.some(m=>m.content.includes('EXISTING_ALBUM_INDEX_JSON')));
   assert.equal(indexes.length,1,'saved successful index must not request again');
   const native=await page.evaluate(()=>__fixture.canonical());assert.ok(native.some(r=>r.cache?.album?.entries?.[0]?.comments?.length===6));
   assert.equal(errors.length,0,errors.join('\n'));
   row.providerCalls=calls.length;row.completedIndexCalls=indexes.length;row.completedComments=6;row.nativeIndexedDB=true;
   row.partialVisibleAfterReload=true;row.originalArchiveUnchanged=true;row.apiChangeAndNewChatContinued=true;
   row.requests=calls.map(c=>({stage:c.replyKind,promptSha256:sha(JSON.stringify(c.messages)),outputTokens:c.outputTokens}));
   await openAlbum(page);await page.locator('[data-rmt-album-memory="CG01"]').click();
   await page.getByText(activeSeed.comments.items[0].comments[0],{exact:false}).filter({visible:true}).first().waitFor();row.completedTextRead=true;
   await page.screenshot({path:path.join(outputDir,`completed-${width}.png`),fullPage:true});row.status='passed';
  }catch(error){row.status='failed';row.error=String(error.stack||error);row.notices=await page.evaluate(()=>__fixture.calls.notices).catch(()=>[]);await page.screenshot({path:path.join(outputDir,`failed-${width}.png`),fullPage:true}).catch(()=>{});await writeFile(path.join(outputDir,`failed-${width}.html`),await page.content());}
  finally{await ctx.close();await writeFile(path.join(outputDir,'report.json'),JSON.stringify(report,null,2))}
 }
 assert.ok(report.cases.every(row=>row.status==='passed'),'one or more lifecycle checks failed');
 assert.ok(routes.bundle>0);assert.deepEqual(routes.source,[]);assert.deepEqual(routes.external,[]);assert.deepEqual(routes.unexpected,[]);
}finally{await browser.close();await new Promise(resolve=>server.close(resolve));await writeFile(path.join(outputDir,'report.json'),JSON.stringify(report,null,2))}
console.log(JSON.stringify({passed:report.cases.length,outputDir}));
