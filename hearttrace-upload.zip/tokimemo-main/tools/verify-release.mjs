import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';

const root = path.resolve(process.argv[2] || '.');
const files = execFileSync('git', ['ls-files', '--cached', '--others', '--exclude-standard', '-z'], { cwd: root, encoding: 'utf8' }).split('\0').filter(Boolean);
const scripts = [...new Set(files)].filter(file => /\.(?:js|mjs)$/.test(file));
for (const file of scripts) execFileSync(process.execPath, ['--check', path.join(root, file)], { stdio: 'pipe' });
execFileSync('git', ['diff', '--check'], { cwd: root, stdio: 'pipe' });
const bundle = fs.readFileSync(path.join(root, 'dist/heartbeatMemories.bundle.js'));
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'manifest.json'), 'utf8'));
const checks = { version: manifest.version, syntaxFiles: scripts.length, syntaxExit: 0, diffCheckExit: 0,
    bundleSha256: crypto.createHash('sha256').update(bundle).digest('hex'),
    testedEnvironment: 'Node VM production modules and bundle; host/provider/storage boundaries replaced; not phone or live SillyTavern' };
fs.mkdirSync(path.join(root, 'verification'), { recursive: true });
fs.writeFileSync(path.join(root, 'verification/checks.json'), JSON.stringify(checks, null, 2) + '\n');
console.log(JSON.stringify(checks));
