import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { pathToFileURL } from 'node:url';

// The same public-boundary regressions can run against the untouched installer.
const target = process.env.HEARTTRACE_TEST_ROOT;
const base = target ? pathToFileURL(`${target.replace(/\/$/, '')}/tools/`) : new URL('./', import.meta.url);
const { preparationFixture } = await import(new URL('preparation-harness-r8481.mjs', base));
const { relayIndexedDB } = await import(new URL('relay-idb-fixture.mjs', base));
const plain = value => JSON.parse(JSON.stringify(value));

async function setup({ draftKind = 'v2', transfer = true, frozen = true } = {}) {
    const f = await preparationFixture({ hostOverrides: { chatId: 'A', saveMetadataDebounced: async () => {} } });
    f.sandbox.Blob = Blob;
    f.sandbox.indexedDB = relayIndexedDB();
    vm.runInContext('structuredClone = v => v === undefined ? undefined : JSON.parse(JSON.stringify(v))', f.sandbox);
    const copy = value => vm.runInContext(`JSON.parse(${JSON.stringify(JSON.stringify(value))})`, f.sandbox);
    const backup = await f.api('archive/backupStore.js'); backup.setArchiveBackupBackendForTests(null);
    const cache = await f.api('core/cache.js'), groups = await f.api('archive/groups.js');
    const relay = await f.api('archive/relay.js'), prep = await f.api('archive/relayPreparation.js');
    const constants = await f.api('core/constants.js'), records = await f.api('core/cacheRecords.js');
    const context = await f.api('core/context.js'), recovery = await f.api('generation/recovery.js');
    const source = await f.api('core/recoverySourcePolicy.js');
    const memory = copy({ version: 3, chatId: 'A', archiveRevision: 'ra', characterName: '岚', userName: '阿宁',
        sourceMessageCount: 1, sourceFingerprint: 'prefix-A',
        memories: [{ id: 'M100', title: '书页', summary: '一起读书', anchors: ['书'], messageStart: 1, messageEnd: 1 }] });
    const handle = await recovery.createGenerationRecovery({ origin: context.captureTaskOrigin(f.host, 'ra'),
        mode: 'cabinet', draftId: 'A-open', pageId: 'cabinet', settingsIdentity: source.recoverySettingsIdentity(f.host),
        sourcePolicy: await source.recoverySourcePolicy(f.host),
        ...(frozen ? { contentSnapshot: copy({ memoryBank: memory, fields: {}, cardFields: {} }) } : {}) });
    const journal = plain(handle.journal);
    const aCache = copy({ chatId: 'A', archiveRevision: 'ra', updatedAt: 1,
        ...(draftKind === 'v2' ? { __generationDraftsV2: { version: 1, records: { 'A-open': { status: 'open', journal } } } }
            : { __generationRecoveryV1: { cabinet: journal }, phoneGenerationDraftV1: {
                kind: 'phone-draft', chatId: 'A', archiveRevision: 'ra', completedApps: [{ id: 'notes', text: 'paid success' }] } }) });
    f.host.chatMetadata[constants.MEMORY_KEY] = memory;
    f.host.chatMetadata[constants.CACHE_KEY] = aCache;
    groups.upsertArchiveIndex(f.host, memory);
    const aEntry = groups.getArchiveIndex(f.host).find(row => row.chatId === 'A');
    await backup.seedArchiveBackup(aEntry, memory, aCache);
    const mirrors = { A: f.host.chatMetadata };
    const switchTo = chatId => {
        f.host.chatId = chatId; f.host.chatMetadata = mirrors[chatId] || (mirrors[chatId] = {});
        f.state.runtimeSessionCache.clear(); f.state.pendingCompressedCacheWrites.clear();
    };
    const loadSnapshot = async entry => {
        const stored = await backup.readArchiveBackupState(entry);
        return { ...entry, memory: stored.record.memory, cache: stored.record.cache, backupOnly: false };
    };
    if (transfer) {
        switchTo('B');
        const preview = await relay.previewArchiveRelay(aEntry.entryId, { loadSnapshot });
        await relay.commitArchiveRelay(preview);
    }
    const current = () => f.repo.getImportedMemory(f.host);
    const entry = () => cache.archiveBackupEntryForContext(f.host, current());
    const readCache = async () => {
        const row = (await backup.readArchiveBackupState(entry())).record;
        return records.hydrateBackupCacheValue(row.cache, row.memory.chatId, row.archiveRevision);
    };
    const append = async (preserveDerivedCache = true) => {
        const previous = current();
        return cache.saveImportedMemory(f.host, copy({ ...previous, archiveRevision: previous.archiveRevision + '-new',
            memories: [...previous.memories, { id: 'M101', title: 'B 的书页', summary: '继续读书', sourceChatId: 'B' }] }),
        f.host.chatId, { preserveDerivedCache, expectedPreviousArchiveState: { present: true, revision: previous.archiveRevision } });
    };
    return { f, copy, backup, cache, groups, relay, prep, constants, records, context, recovery, source, journal,
        current, entry, readCache, append, switchTo, loadSnapshot, aEntry };
}

test('relay: hidden A draft does not block a new B generation and stays byte-identical', async () => {
    const x = await setup();
    assert.equal(x.cache.loadGenerationRecovery('cabinet', x.f.host), null);
    const signature = await x.cache.claimLiveModeGeneration('cabinet', x.f.host, x.current(), { pageId: 'cabinet' });
    assert.ok(signature);
    assert.deepEqual(plain((await x.readCache()).__generationDraftsV2.records['A-open'].journal), x.journal);
    assert.equal(x.f.providerCalls, 0, 'admission itself never requests the model');
});

test('relay: explicitly selecting an A draft in B still refuses to replay the wrong request', async () => {
    const x = await setup();
    await assert.rejects(x.cache.claimLiveModeGeneration('cabinet', x.f.host, x.current(), { draftId: 'A-open', pageId: 'cabinet' }),
        error => error.code === 'RMT_RECOVERY_SOURCE_CHANGED' && error.archiveInputCategory === 'chat');
    assert.equal(x.f.providerCalls, 0);
});

test('ordinary same-chat drafts still enforce real character and source changes', async () => {
    for (const change of ['character', 'selection']) {
        const x = await setup({ transfer: false, frozen: false });
        if (change === 'character') x.f.host.characters[0].description = '真正改过的角色卡';
        else x.f.host.extensionSettings.heartbeatMemories.useActivatedWorldInfo = false;
        await assert.rejects(x.cache.claimLiveModeGeneration('cabinet', x.f.host, x.current(), { pageId: 'cabinet' }),
            error => error.code === 'RMT_RECOVERY_SOURCE_CHANGED' && error.archiveInputCategory === change);
        assert.deepEqual(plain((await x.readCache()).__generationDraftsV2.records['A-open'].journal), x.journal);
        assert.equal(x.f.providerCalls, 0);
    }
});

test('relay: a B-owned unfinished request still protects B against a changed source', async () => {
    const x = await setup();
    const origin = x.context.captureTaskOrigin(x.f.host, x.current().archiveRevision);
    const b = await x.recovery.createGenerationRecovery({ origin, mode: 'cabinet', draftId: 'B-open', pageId: 'cabinet',
        settingsIdentity: x.source.recoverySettingsIdentity(x.f.host), sourcePolicy: await x.source.recoverySourcePolicy(x.f.host) });
    assert.equal(await x.cache.saveGenerationRecovery(x.f.host, x.current(), 'cabinet', b.journal, origin), true);
    x.f.host.characters[0].description = 'B 中真正改过的角色卡';
    await assert.rejects(x.cache.claimLiveModeGeneration('cabinet', x.f.host, x.current(), { pageId: 'cabinet' }),
        error => error.code === 'RMT_RECOVERY_SOURCE_CHANGED' && error.archiveInputCategory === 'character');
    assert.deepEqual(plain((await x.readCache()).__generationDraftsV2.records['A-open'].journal), x.journal);
    assert.equal(x.f.providerCalls, 0);
});

test('relay: draft-only cache survives archive append/rebuild and remains readable on handback', async () => {
    for (const preserveDerivedCache of [true, false]) {
        const x = await setup({ draftKind: 'legacy' });
        const before = plain(x.prep.relayPreservedDraftRows(await x.readCache()));
        assert.equal(before.length, 2);
        await x.append(preserveDerivedCache);
        assert.deepEqual(plain(x.prep.relayPreservedDraftRows(await x.readCache())), before);
        const bEntry = x.entry();
        x.switchTo('A');
        const preview = await x.relay.previewArchiveRelay(bEntry.entryId, { loadSnapshot: x.loadSnapshot });
        await x.relay.commitArchiveRelay(preview);
        const returned = await x.readCache();
        assert.deepEqual(plain(returned.__generationRecoveryV1.cabinet), x.journal);
        assert.equal(x.prep.relayPreservedDraftRows(returned).find(row => row.key === 'phoneGenerationDraftV1').value.completedApps[0].text, 'paid success');
        assert.equal(x.current().memories.at(-1).id, 'M101');
        assert.equal(x.f.providerCalls, 0);
    }
});

test('relay: failed archive persistence retains the holder, drafts and original revision', async () => {
    const x = await setup({ draftKind: 'legacy' });
    const oldMemory = plain(x.current()), oldCache = plain(await x.readCache());
    x.f.sandbox.indexedDB.control.failWrite = 1;
    await assert.rejects(x.append());
    assert.deepEqual(plain(x.current()), oldMemory);
    assert.deepEqual(plain(await x.readCache()), oldCache);
    assert.equal(x.f.providerCalls, 0);
});

test('coverage: only B memories cover B floors; A remains available as history', async () => {
    const f = await preparationFixture(), coverage = await f.api('archive/coverageRanges.js');
    const memories = [{ id: 'M100', sourceKind: 'chat', sourceChatId: 'A', messageStart: 1, messageEnd: 3 },
        { id: 'M101', sourceKind: 'chat', sourceChatId: 'B.jsonl', messageStart: 3, messageEnd: 3 }];
    const before = plain(memories);
    const runs = coverage.buildFloorCoverage({ chatId: 'B', totalFloors: 3, memories });
    assert.deepEqual(plain(runs), [{ kind: 'open', start: 1, end: 2 }, { kind: 'memory', start: 3, end: 3 }]);
    assert.deepEqual(plain(coverage.coverageGapSlices(runs)), [{ kind: 'open', start: 1, end: 2, fullEnd: 2 }]);
    assert.deepEqual(memories, before);
});

test('coverage: untagged legacy memories stay local; current scanned and summary floors remain covered', async () => {
    const f = await preparationFixture(), coverage = await f.api('archive/coverageRanges.js');
    const memories = [{ id: 'M001', messageStart: 1, messageEnd: 1 },
        { id: 'M002', sourceChatId: 'A', messageStart: 2, messageEnd: 4 }];
    const runs = coverage.buildFloorCoverage({ chatId: 'B', totalFloors: 4, memories, summaryFloors: [2],
        coveredRanges: [{ start: 3, end: 3 }] });
    assert.deepEqual(plain(runs), [{ kind: 'memory', start: 1, end: 1 }, { kind: 'summary', start: 2, end: 2 },
        { kind: 'scanned', start: 3, end: 3 }, { kind: 'open', start: 4, end: 4 }]);
    assert.deepEqual(plain(coverage.memoryFloorSpans(memories)), [{ start: 1, end: 4 }], 'old callers without chat scope remain compatible');
});

test('coverage: real relay stamps untagged old memory before showing B gaps and A handback coverage', async () => {
    const x = await setup();
    const coverage = await x.f.api('archive/coverageRanges.js');
    assert.equal(x.current().memories[0].sourceChatId, 'A');
    assert.deepEqual(plain(coverage.buildFloorCoverage({ chatId: 'B', totalFloors: 1, memories: x.current().memories })),
        [{ kind: 'open', start: 1, end: 1 }]);
    const bEntry = x.entry(); x.switchTo('A');
    await x.relay.commitArchiveRelay(await x.relay.previewArchiveRelay(bEntry.entryId, { loadSnapshot: x.loadSnapshot }));
    assert.deepEqual(plain(coverage.buildFloorCoverage({ chatId: 'A', totalFloors: 1, memories: x.current().memories })),
        [{ kind: 'memory', start: 1, end: 1 }]);
});
