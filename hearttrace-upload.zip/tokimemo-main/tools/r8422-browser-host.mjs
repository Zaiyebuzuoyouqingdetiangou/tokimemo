// Browser-only test harness. Real DOM and native IndexedDB; synthetic ST context
// and provider. This is NOT a live SillyTavern, TT or paid model test.
import * as R from '../src/archive/repository.js';
import * as C from '../src/core/constants.js';
import * as B from '../src/archive/importBatches.js';
import * as context from '../src/core/context.js';
import * as settings from '../src/core/settings.js';
import * as backup from '../src/archive/backupStore.js';
import * as groups from '../src/archive/groups.js';
import * as ledger from '../src/archive/sourceLedger.js';
import * as overlay from '../src/ui/overlay.js';
import * as trace from '../src/core/taskTrace.js';
import { state } from '../src/core/state.js';
const clone = value => structuredClone(value);
const fixture = window.fixture = { ready: false, notices: [], errors: [], requests: JSON.parse(localStorage.getItem('r8422-fixture-calls') || '[]') };
const observer = new PerformanceObserver(list => fixture.longTasks.push(...list.getEntries().map(row => ({ duration: row.duration, startTime: row.startTime }))));
fixture.longTasks = []; observer.observe({ entryTypes: ['longtask'] });
const profile = { id: 'r8422-browser-profile', name: 'Synthetic', mode: 'cc', api: 'openai', model: 'fixture-model', 'secret-id': 'fixture-only' };
const ctx = { characterId: 0, groupId: null, chatId: 'r8422-native-chat', name1: '小月', name2: '林舟',
    characters: [{ name: '林舟', avatar: 'native-fixture.png', data: { name: '林舟', description: '现代花店店主；这是合成测试人设。', personality: '认真。' } }],
    chat: [{ is_user: true, name: '小月', mes: '两人在庭院栽花。' }],
    chatMetadata: JSON.parse(localStorage.getItem('r8422-fixture-metadata') || '{}'),
    powerUserSettings: { persona_description: '这是合成测试用户。' },
    extensionSettings: { [C.EXTENSION_SETTINGS_KEY]: { apiConnectionMode: 'profile', connectionProfileId: profile.id,
        useCurrentChatExternalMemory: false, useActivatedWorldInfo: false, maxTokens: 12000, themeMode: 'default' },
        connectionManager: { profiles: [profile] } },
    getCurrentChatId() { return this.chatId; },
    getCharacterCardFields() { return clone(this.characters[this.characterId].data); },
    getTokenCountAsync: async () => 100, // Clearly synthetic; not a real model tokenizer.
    getRequestHeaders: () => ({}), saveSettingsDebounced() {},
    saveMetadataDebounced() { localStorage.setItem('r8422-fixture-metadata', JSON.stringify(this.chatMetadata)); },
    ConnectionManagerRequestService: {
        validateProfile: () => ({ selected: 'openai', source: 'openai' }),
        async sendRequest(_id, messages, responseLength, _options, overridePayload) {
            const payload = { secret_id: profile['secret-id'], model: profile.model, ...overridePayload };
            if (payload.secret_id !== 'fixture-only') throw new Error('Unexpected fixture credentials');
            const prompt = messages.map(row => row.content).join('\n');
            const marker = 'EXTERNAL_MEMORY_JSON:\n', pos = prompt.lastIndexOf(marker);
            const rows = pos >= 0 ? JSON.parse(prompt.slice(pos + marker.length)) : [];
            fixture.requests.push({ ids: rows.map(row => row.externalId), chars: prompt.length,
                bytes: new TextEncoder().encode(prompt).byteLength, responseLength });
            localStorage.setItem('r8422-fixture-calls', JSON.stringify(fixture.requests));
            if (fixture.failRequestAt === fixture.requests.length) throw Object.assign(new Error('Synthetic provider failure'), { code: 'RMT_JSON_INVALID' });
            if (fixture.pauseNext) { fixture.pauseNext = false; await new Promise(resolve => { fixture.release = resolve; }); }
            return { content: JSON.stringify({ memories: rows.slice(0, 1).map(row => ({
                title: `${row.content.slice(0, 10)}的共同记忆`, summary: `林舟和小月的共同经历：${row.content.slice(0, 60)}`,
                anchors: [row.content.slice(0, 6), row.content.slice(-6)], sourceExternalIds: [row.externalId],
                sourceExternalAnchor: row.content.slice(0, 6), participants: ['林舟', '小月'],
            })) }) };
        },
    },
};
globalThis.SillyTavern = { getContext: () => ctx };
globalThis.toastr = Object.fromEntries(['info', 'warning', 'error', 'success'].map(kind => [kind, message => fixture.notices.push({ kind, message })]));
globalThis.confirm = () => true;
window.addEventListener('error', event => fixture.errors.push(String(event.message)));
window.addEventListener('unhandledrejection', event => fixture.errors.push(String(event.reason?.stack || event.reason)));
fixture.ctx = ctx; fixture.state = state;
fixture.snapshot = async () => {
    const bank = R.getImportedMemory(ctx);
    const entry = groups.currentCharacterArchiveProbe(ctx, bank);
    entry.entryId = context.archiveIndexEntryId(entry);
    const durable = await backup.readArchiveBackup(entry);
    const p = bank?.[B.IMPORT_PROGRESS_KEY];
    return { memoryCount: bank?.memories.length || 0, progress: p ? B.progressTotals(p) : null,
        cursor: p?.nextBatch ?? null, coverage: bank?.coverageMode, canonicalRevision: bank?.archiveRevision,
        backupRevision: durable?.archiveRevision, backupCursor: durable?.memory?.[B.IMPORT_PROGRESS_KEY]?.nextBatch ?? null,
        pendingSave: R.getCurrentArchiveImportRecoverySummary(ctx)?.awaitingCommit || false,
        requests: fixture.requests, notices: fixture.notices, errors: fixture.errors, longTasks: fixture.longTasks,
        trace: trace.taskTraceSnapshot() };
};
fixture.theme = mode => { settings.updatePluginSettings({ themeMode: mode }); overlay.openOverlay(); overlay.showChooser(); };
fixture.abortOneNativeWrite = () => {
    const put = IDBObjectStore.prototype.put;
    IDBObjectStore.prototype.put = function (value, ...args) {
        const request = put.call(this, value, ...args);
        if (this.name === C.ARCHIVE_BACKUP_STORE_NAME && value?.memory?.[B.IMPORT_PROGRESS_KEY]) {
            IDBObjectStore.prototype.put = put; this.transaction.abort();
        }
        return request;
    };
};
fixture.reopen = () => { overlay.openOverlay(); overlay.showChooser(); };
try {
    if (!localStorage.getItem('r8422-fixture-initialized')) {
        R.setMemoryWorldInfoSelection(ctx, { books: [] });
        const snap = await context.buildChatSnapshot(ctx, { completeSource: true, readRange: settings.getPluginSettings(ctx).chatReadRange });
        const bank = { version: C.MEMORY_VERSION, chatId: ctx.chatId, archiveRevision: 'native-seed', characterName: ctx.name2, userName: ctx.name1,
            archiveName: '庭院旧档案', archiveSummary: '原有成果保持可读。', createdAt: 1, updatedAt: 1,
            sourceMessageCount: snap.totalMessages, sourceFingerprint: `${snap.fingerprint}:none`, fullSourceFingerprint: snap.fullFingerprint,
            externalMemoryFingerprint: 'none', chatReadRange: snap.readRange,
            memories: [{ id: 'M001', title: '庭院栽花', summary: '两人在庭院栽花。', anchors: ['庭院'] }] };
        ctx.chatMetadata[C.MEMORY_KEY] = bank;
        const entry = groups.currentCharacterArchiveProbe(ctx, bank); entry.entryId = context.archiveIndexEntryId(entry);
        await backup.seedArchiveBackup(entry, bank, null);
        const rows = Array.from({ length: 610 }, (_, index) => ({ sourceId: `native-${index}`,
            content: (`资料${String(index).padStart(5, '0')}：庭院共同经历。` + '春'.repeat(1000)).slice(0, 993) + `尾${String(index).padStart(6, '0')}` }));
        await ledger.upsertMemorySourceLedger(R.memorySourceScopeForContext(ctx), { provider: 'synthetic-native-file', label: '合成61万字来源',
            revision: 'native-r1', sourceKind: 'file-user-confirmed-history-summary',
            coverage: { status: 'complete', returned: rows.length, total: rows.length }, records: rows });
        ctx.saveMetadataDebounced();
        localStorage.setItem('r8422-fixture-initialized', 'true');
    }
    overlay.openOverlay(); overlay.showChooser();
    fixture.ready = true;
} catch (error) { fixture.errors.push(String(error.stack)); fixture.ready = true; }
