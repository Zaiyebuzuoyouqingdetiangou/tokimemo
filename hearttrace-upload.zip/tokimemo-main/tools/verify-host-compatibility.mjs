// Offline host-contract integration. Official source snippets + mocked local provider;
// this does not launch SillyTavern or contact a model provider.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';
import { createHostContextAdapter, readArchiveRowMetadata } from '../src/core/hostCompatibility.js';
import * as api from '../src/core/independentApi.js';

const referenceRoot = path.resolve(process.argv[2] || fileURLToPath(new URL('../../../references/', import.meta.url)));
const read = (v, name) => fs.readFileSync(path.join(referenceRoot, `${v}-${name}`), 'utf8');
const versions = ['1.13.0','1.13.1','1.13.2','1.13.3','1.13.4','1.13.5','1.14.0','1.15.0','1.16.0','1.17.0','1.18.0','1.19.0'];
const results = [];
for (const version of versions) {
    const modern = ['1.18.0','1.19.0'].includes(version);
    const nativeDebounce = !['1.13.0','1.13.1','1.13.2'].includes(version);
    const nativeMetadata = !version.startsWith('1.13.');
    const source = read(version,'public_scripts_st-context.js');
    assert.equal(source.includes('getWorldInfoNames:'),modern,`${version}: list capability`);
    assert.equal(source.includes('saveMetadataDebounced,'),nativeDebounce,`${version}: save capability`);
    assert.equal(read(version,'src_endpoints_characters.js').includes('request.body.metadata'),nativeMetadata);

    const shared = read(version,'public_scripts_extensions_shared.js');
    const classSource = shared.slice(shared.indexOf('export class ConnectionManagerRequestService')).replace('export class','class');
    assert(classSource.startsWith('class '));
    const requests = [];
    const profile = {id:'dedicated',mode:'cc',api:'custom',model:'profile-model','api-url':'https://mock.invalid/v1','secret-id':'selected-profile-secret'};
    const live = {chatId:'A',characterId:0,groupId:null,chatMetadata:{},
        extensionSettings:{disabledExtensions:[],connectionManager:{profiles:[profile]}},
        CONNECT_API_MAP:{custom:{selected:'openai',source:'custom'}},
        ChatCompletionService:{processRequest:async (...args)=>{requests.push(args);return {choices:[{message:{content:'fixture'}}]};}},
    };
    const service = vm.runInNewContext(classSource+'\nConnectionManagerRequestService;',{
        SillyTavern:{getContext:()=>live},proxies:[],console,CONNECT_API_MAP:live.CONNECT_API_MAP,t:parts=>parts.join(''),
    });
    if (modern) {
        assert.equal(api.assertConnectionManagerProfileSupport(service),true);
        await service.sendRequest('dedicated',[{role:'user',content:'unchanged prompt'}],1234,{includePreset:false,includeInstruct:false,extractData:false,stream:false},{model:'override-model'});
        assert.equal(requests.length,1);
        assert.equal(requests[0][0].secret_id,'selected-profile-secret');
        assert.equal(requests[0][0].model,'override-model');
        assert.equal(requests[0][0].messages[0].content,'unchanged prompt');
    } else {
        assert.throws(()=>api.assertConnectionManagerProfileSupport(service),{code:'RMT_PROFILE_CAPABILITY'});
        assert.equal(requests.length,0);
    }

    // Execute the unmodified official debounce implementation against controlled timers.
    const extensionSource = read(version,'public_scripts_extensions.js');
    const start = extensionSource.indexOf('export function cancelDebouncedMetadataSave()');
    const end = extensionSource.indexOf('/**',start);
    const debounceSource = extensionSource.slice(start,end).replaceAll('export function','function');
    let active = live, timerId = 0, writes = [];
    const timers = new Map();
    live.saveMetadata = async()=>writes.push(active.chatId);
    const host = vm.runInNewContext('let saveMetadataTimeout = null;\n'+debounceSource+'\n({saveMetadataDebounced,cancelDebouncedMetadataSave});',{
        getContext:()=>active,console:{debug(){},warn(){}},debounce_timeout:{relaxed:1000},
        setTimeout:(fn)=>{const id=++timerId;timers.set(id,fn);return id;},clearTimeout:id=>timers.delete(id),
    });
    if (nativeDebounce) live.saveMetadataDebounced = host.saveMetadataDebounced;
    const world = {world_names:['角色设定','历史']};
    if (modern) live.getWorldInfoNames = ()=>[...world.world_names];
    const adapt = createHostContextAdapter({getContext:()=>active,loadExtensions:async()=>host,loadWorldInfo:async()=>world});
    const adapted = adapt(live);
    assert.deepEqual(await adapted.getWorldInfoNames(),['角色设定','历史']);
    await adapted.saveMetadataDebounced();
    assert.equal(timers.size,1);
    // clearChat uses this same cancellation function before loading another chat.
    host.cancelDebouncedMetadataSave();
    active = {...live,chatId:'B',chatMetadata:{}};
    if (!nativeDebounce) delete active.saveMetadataDebounced;
    for (const fn of timers.values()) await fn();
    assert.equal(writes.length,0);
    await adapt(active).saveMetadataDebounced();
    for (const [id,fn] of [...timers]) {timers.delete(id);await fn();}
    assert.deepEqual(writes,['B']);

    let fileReads=0;
    const metadata={archive:'原内容'};
    const row={file_name:'旧聊天.jsonl',...(nativeMetadata?{chat_metadata:metadata}:{})};
    const restored=await readArchiveRowMetadata({getRequestHeaders:()=>({})},'角色.png',row,{
        fetchImpl:async()=>{fileReads++;return {ok:true,json:async()=>[{chat_metadata:metadata}]};},
    });
    assert.equal(restored.chat_metadata.archive,'原内容');
    assert.equal(fileReads,nativeMetadata?0:1);
    results.push({version,nativeDebounce,worldList:modern?'native':'adapter',profile:modern?'secret-bound':'manual-required',metadata:nativeMetadata?'native':'file-read',result:'pass'});
}

// The actual manual transport and streaming parser, using an in-process zero-cost provider.
const settings={manualApiBaseUrl:'https://mock.invalid/v1',manualApiKey:'fixture-only-key',manualApiModel:'fixture-model',temperature:0.6};
const headers={getRequestHeaders:()=>({'X-CSRF-Token':'fixture'})};
let generated=0;
const json=await api.requestManualApiCompletion(settings,headers,[{role:'user',content:'unchanged prompt'}],1234,{
    fetchImpl:async(url,init)=>{generated++;assert.equal(url,'/api/backends/chat-completions/generate');const body=JSON.parse(init.body);assert.equal(body.chat_completion_source,'custom');assert.equal(body.model,'fixture-model');assert.equal(body.messages[0].content,'unchanged prompt');return new Response(JSON.stringify({choices:[{message:{content:'普通回复'}}]}),{headers:{'content-type':'application/json'}});},
});
assert.equal(json,'普通回复');
const stream=await api.requestManualApiCompletion({...settings,manualApiStreaming:true},headers,[{role:'user',content:'unchanged prompt'}],1234,{
    fetchImpl:async()=>{generated++;return new Response('data: {"choices":[{"delta":{"content":"流式"},"finish_reason":null}]}\n\ndata: {"choices":[{"delta":{"content":"回复"},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n',{headers:{'content-type':'text/event-stream'}});},
});
assert.equal(api.extractIndependentResponseContent(stream),'流式回复');
assert.equal(generated,2);
console.log(JSON.stringify({kind:'offline-official-source-contracts',versions:results,manualTransport:'JSON + SSE pass',paidRequests:0,realHost:'not run'},null,2));
