// Shipped bundle + actual floor-style mirroring in Happy DOM. This is not a
// browser geometry or iPhone/TT test. Only exposes a private styling seam.
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
const { Window } = await import(pathToFileURL(process.env.HAPPY_DOM_PATH).href);
const window = new Window({ url: 'https://localhost/' }), document = window.document;
let requests = 0;
const host = { characterId: 0, name1: 'User', name2: 'Char', chatId: 'A',
    characters: [{ name: 'Char', avatar: 'char.png', data: { name: 'Char', description: 'fixture' } }],
    chat: [], chatMetadata: {}, extensionSettings: {}, getCurrentChatId() { return this.chatId; }, saveSettingsDebounced() {} };
const sandbox = vm.createContext({ console, document, window, navigator: window.navigator, location: window.location,
    SillyTavern: { getContext: () => host }, fetch: () => { requests++; throw new Error('Unexpected request'); },
    TextEncoder, TextDecoder, URL, URLSearchParams, Blob, Response, CompressionStream, DecompressionStream,
    AbortController, DOMException, crypto: globalThis.crypto, performance, queueMicrotask,
    setTimeout, clearTimeout, setInterval, clearInterval, btoa, atob });
vm.runInContext('structuredClone = v => v === undefined ? undefined : JSON.parse(JSON.stringify(v))', sandbox);
let source = await readFile(new URL('../dist/heartbeatMemories.bundle.js', import.meta.url), 'utf8');
const hook = '__m_ui_autoMemoryShell_js.startAutoMemoryShell = startAutoMemoryShell;';
assert.ok(source.includes(hook));
source = source.replace(hook, hook + '\nglobalThis.__styleLetterForTest = mirrorModuleCss;');
const paths = [...source.matchAll(/^\/\/ MODULE: (.+)$/gm)].map(match => match[1]);
const expose = '\nexport const modules = {' + paths.map(p => JSON.stringify(p) + ':__m_' + p.replace(/[^a-zA-Z0-9]/g, '_')).join(',') + '};';
const compiled = new vm.SourceTextModule(source + expose, { context: sandbox });
await compiled.link(() => { throw new Error('Unexpected external import'); }); await compiled.evaluate();
const m = compiled.namespace.modules, view = m['autoMemory/incrementalView.js'];
vm.runInContext('__styleLetterForTest()', sandbox);
assert.ok(document.getElementById('rmt-floor-module-css'));
const saved = { kind: 'adv', events: [
    { id: 'old', title: '旧轮次', sourceMemoryIds: ['M001'], adv: { paragraphs: ['不混入'] } },
    { id: 'one', title: '初次化形与穿衣困惑', date: '九月二十八日', cgDesc: '檐下的灯照亮了回家的路。', sourceMemoryIds: ['M002'], adv: { paragraphs: ['我把外衣递给你。', '我们一起走回家。'] } },
    { id: 'two', title: '只有索引的另一篇' + '很长的标题'.repeat(10), cgDesc: '长街边，两人停下脚步。', sourceMemoryIds: ['M002'], adv: null },
] };
const before = JSON.stringify(saved), projected = view.incrementalProjection(saved, { sourceMemoryIds: ['M002'] });
document.body.innerHTML = '<div id="chat"><div class="mes"><div class="rmt-floor-shell"><article class="rmt-heart-letter"><div class="rmt-heart-letter-paper"><div class="rmt-floor-body"></div></div></article></div></div></div>';
const body = document.querySelector('.rmt-floor-body'); body.innerHTML = view.roundReadingHtml(projected.session);
const reader = body.querySelector('.rmt-letter-adv'); assert.ok(reader);
assert.equal(reader.children.length, 2);
assert.ok([...reader.children].every(node => node.tagName === 'ARTICLE'));
assert.equal(body.querySelectorAll('.rmt-adv-mobile-picker,.rmt-event-list,button,script').length, 0);
assert.equal(body.querySelectorAll('.rmt-letter-adv-para').length, 2);
assert.equal(body.querySelectorAll('[role="status"]').length, 1);
assert.ok(body.textContent.includes('长街边，两人停下脚步。'));
assert.ok(!body.textContent.includes('旧轮次'));
const style = node => window.getComputedStyle(node);
assert.equal(style(reader).gridTemplateColumns, 'minmax(0,1fr)');
assert.equal(style(body.querySelector('.rmt-letter-adv-meta')).display, 'flex');
assert.equal(style(body.querySelector('.rmt-letter-adv-meta')).flexWrap, 'wrap');
assert.equal(style(body.querySelector('.rmt-letter-adv-para')).minHeight, '0');
assert.equal(style(body.querySelector('.rmt-letter-adv-event h3')).whiteSpace, 'normal');
const first = body.innerHTML; body.innerHTML = view.roundReadingHtml(projected.session);
assert.equal(body.innerHTML, first); assert.equal(JSON.stringify(saved), before); assert.equal(requests, 0);
console.log(JSON.stringify({ ok: true, events: 2, savedParagraphs: 2, missingProseStatuses: 1,
    requests, mirroredStyles: true, reopensUnchanged: true, nativeBrowser: false,
    checks: ['full-width reading column', 'wrapping metadata and long titles', 'no artificial paragraph height', 'scene and saved prose', 'round filtering', 'balanced article structure'] }));
await window.happyDOM.close();
