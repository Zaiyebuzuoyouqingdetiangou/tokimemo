// r84.177 · 手动 API Key：设备存不进加密钥匙时只在本次打开期间可用（不报「未能保存」）；
// Key 不在这台设备上时给出准确提示。挑今生的缩略图直接加载；倾斜只在横拖卡片时停。
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { harness } from './runtime-harness.mjs';

async function credentialApi(backend) {
    const h = await harness({ messages: 2, bundle: true });
    h.module('core/localRecoveryStore.js').setLocalRecoveryBackendForTests(backend);
    return h.module('core/manualCredentialStore.js');
}

test('存不进加密钥匙：报「本次打开期间可用」，不是「未能保存」', async () => {
    const api = await credentialApi({ read: async () => null, compare: async () => { const e = new Error('x'); e.code = 'RMT_LOCAL_CLONE'; throw e; } });
    await assert.rejects(api.saveManualCredential('https://api.example.com/v1', 'sk-test'), error => error.code === 'RMT_MANUAL_KEY_SESSION_ONLY');
});

test('其他存储失败仍按原来的「未能保存」处理', async () => {
    const api = await credentialApi({ read: async () => null, compare: async () => { const e = new Error('x'); e.code = 'RMT_LOCAL_STORAGE'; throw e; } });
    await assert.rejects(api.saveManualCredential('https://api.example.com/v1', 'sk-test'), error => error.code === 'RMT_MANUAL_KEY_STORAGE');
});

test('这台设备上没有这把 Key：给出准确提示', async () => {
    const api = await credentialApi({ read: async () => null, compare: async () => 1 });
    await assert.rejects(api.readManualCredential('https://api.example.com/v1', 'credential:12345678-1234-1234-1234-123456789abc'), error => error.code === 'RMT_MANUAL_KEY_NOT_ON_DEVICE');
});

test('设置：只在本次可用时不算保存失败；界面有对应说明', async () => {
    const settings = await readFile(new URL('../src/core/settings.js', import.meta.url), 'utf8');
    assert.match(settings, /return \{ credentialSaved: false, sessionOnly: true, modelSaved: !!model \}/);
    const ui = await readFile(new URL('../src/ui/settingsPanelParts.js', import.meta.url), 'utf8');
    assert.match(ui, /result\.sessionOnly \?/);
    const store = await readFile(new URL('../src/core/localRecoveryStore.js', import.meta.url), 'utf8');
    assert.match(store, /cloneFailed \? failure\('RMT_LOCAL_CLONE'\)/);
});

test('挑今生：缩略图直接加载、不显示记忆编号；倾斜只在横拖时停', async () => {
    const card = await readFile(new URL('../src/ui/pastLivesCard.js', import.meta.url), 'utf8');
    assert.equal(/rmt-card-choice-picture"><img[^>]*loading="lazy"/.test(card), false);
    assert.equal(card.includes("sharedMemoryIds.join('、')"), false);
    assert.match(card, /drag\.horizontal = true; stopSensor\(\);/);
    assert.equal(/pointerdown[\s\S]{0,200}stopSensor\(\); drag =/.test(card), false);
});
